已读当前修订helper033ba879…：Content owner/generation各只读取一次，非空检查先于Surface一致性判断。R14-PAINT-SUBJECT-IDENTITY-001静态关闭，null/null或空字符串不再被当成已知身份。

原255/opacity1/4.5/shadow-md与非none预期不变；此报告不声称16case全通过，也不把DOM标记等同Runtime身份认证。0新增finding、partial/ABSTAIN；无测试/浏览器/源码修改。
