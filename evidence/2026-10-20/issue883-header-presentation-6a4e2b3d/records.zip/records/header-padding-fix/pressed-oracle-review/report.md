# Header narrow pressed-position oracle conflict

The new original-file run is **6 passed / 10 failed**, with no setup skip. Its eight Shadcn cases now pass both 1440px Runtime/Family controls, including 36px geometry and real Surface alpha255/shadow expectations. At390px each reaches the Runtime held press: recorded height44, pressed=true, y282. All eight stop at the original line294 coordinate poll expecting the old +1px displacement. The390px Family and later popup/focus sequence is not covered by this outcome.

Current **draft** `P-SHADCN-SELECT-TRIGGER-STATE-DRIVEN-STYLES` (64–65) explicitly forbids displacement for both default and ghost; its open-question text (97–98) explicitly withdraws the former `translate-y-px`. Current draft T case title and notes require no displacement. The actual prototype contains no translate rule; its existing unit assertions at113–122 and245–256 retain pressed=true while requiring translate-y-px absent. These four source files are byte-identical in main042 and head2189. That comparison is not a new main execution.

The older P/T revision summaries and the unit title at line101 still mention one-pixel feedback. Their historical/title wording does not override current criteria or the executable assertions; those original bytes are retained here.

This establishes an obsolete **Header fixture motion expectation**, not a reason to add a Prototype transform or relax geometry tolerance. The bounded proposed reconciliation is `pressedY = hovered.y`, keeping the existing held-state poll, both coordinate checks and original precision, all inputs and deadlines. No edit or subsequent green result is claimed in this report. The two Brutalist/React focus-token failures remain independent.

Exact raw/result/source hashes and all eight sample mappings are in `report.json`. Review scope is peer analysis and partial/ABSTAIN, not formal approval or whole-file acceptance.
