# Preparing-only Select focus return candidate

This private V2 replaces the unexecuted all-phase proposal with a preparing-only branch. The old e4c6d5b… patch and its reports remain unchanged.

The candidate snapshots the existing public transitionState once after the original focus-scope deactivation/current guard. Only `preparing` returns focus early. It must do so before `overlay.close`: the existing asOverlay open watcher can synchronously call the bound presence.leave, so public Root.close may retire the preparing view inside that call, earlier than Base’s explicit leave. The measured native Escape path had already set Overlay open false and instead retired in the later explicit leave. Both reach the same portable first-retirement boundary.

All other phases retain the original Overlay.close → current guard → explicit leave → guards/blocked completion → focus order. The local focus closure contains the exact original eligibility and calls. The extra current-presentation check short-circuits unless preparing. No unconditional extra Context read is introduced; the one added public State read is the explicit phase decision.

Only early preparing focus catches a failure. While still current, the original close sequence is attempted; finally preserves the first raw focus failure. Reopen/retirement from focus skips the old close. Nonpreparing focus/leave errors retain their original ordering. No lower-level falsy error policy is changed. Earlier facts()+settle reopen/Error controls are **entering**, not entered; the separate original raw0 failure remains failed and is not included as a successful control.

The private regression suggestions use the existing full structure with **no facts() geometry stub** and explicitly assert transitionState===preparing before closing. They retain public Root.close/setElementProps and normal native focus APIs. If the real preparing prerequisite is not reached, that is a retained control failure rather than a reason to set a private flag or add waiting. The original Header d196 full-parts20-matcher red remains untouched.

Static AST comparison verifies the exact old focus subtree and ordinary-phase cleanup/focus sequence after expanding the local closure. No proposal was applied or executed here. Root owns one original red→candidate validation and the existing controlled/beforeLeave/owner regression combinations. Peer/privateproposal, partial/ABSTAIN; no formal approval.
