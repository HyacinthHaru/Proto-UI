实际Header fixture a73ff808…相对c81只有两处变化：在原focus snapshot前以默认1秒poll等待当前anchor active+精确ring-2 token；pressedY归回hovered.y。撤销两处即可逐字恢复c81，其余原输入/断言/90秒deadline保留。

readiness符合active React notification≠commit边界与现有native-link测试惯例；原快照时点有意改变。pressedY=0由draft P-SHADCN-SELECT-TRIGGER-STATE-DRIVEN-STYLES明确无pressed displacement及既有question撤回旧translate-y-px支持，不是仅因实现没有位移就删期待。draft状态不升格。

05:11:10–05:15:30 UTC原完整16case无filter实际16/16、exit0，测试字节a73与执行收据完全一致，六个已记录dirty输入前后稳定。这是98932加候选的执行，不是cleanhead/未来commitCI；新drain gap与历史所有红继续独立保留。0具体finding、partial/ABSTAIN，不是GitHub批准或完整视觉验收。
