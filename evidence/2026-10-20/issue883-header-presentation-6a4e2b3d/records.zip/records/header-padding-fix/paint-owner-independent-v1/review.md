按 draft P-SHADCN-SELECT-CONTENT-CURRENT-VISUAL-SURFACE，完整组合的 Content 是定位 frame，Surface 承担 paint。本候选对 Shadcn 改读唯一同标记 Surface、Brutalist 继续读 Content，归属方向正确。原 opacity 1、alpha 255、contrast >=4.5、shadow-md/非 none，以及全部输入、deadline、几何/焦点/pressed-Y 预期均未放宽；settled 和 contrast 函数字节完全保留。

保留一个 P3：R14-PAINT-SUBJECT-IDENTITY-001。当前相等判断会让两边 owner/gen 同为 null 的未知身份也通过。建议从 Content 各读一次非空 owner/generation，缺失时用现有 Error 拒绝，再与 Surface 比较；不改预期值。真实已捕获 WC/light 场景的标记均非空，因此这不是把该场景的正确 paint 数据判错。

原 owner-probe 的 subject 数据只覆盖一个 WC/light Runtime popup，不证明其它16case，也不修 React native-link ring 问题。结论 partial/ABSTAIN，V1此项未关闭；未运行、修改或批准产品/测试。
