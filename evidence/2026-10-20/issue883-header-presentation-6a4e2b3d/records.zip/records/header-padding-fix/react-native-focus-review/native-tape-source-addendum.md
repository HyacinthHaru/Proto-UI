04:31:17.833869–04:31:31.293641 UTC 的私有原生单例实际为 1 fail / 15 filtered。205 条同步 tape、0 drop、observerError=false，仍在原 brand index0 的 ring-2 断言失败。四组 focusVisible=true（ordinal156、191、196、201）均通过实际 alive/connected/isActive，随后原 Homepage surface/text setProps 都返回；记录的 Surface 为同 owner homepage-home-brand / generation3、connected、同 selected Surface，仍没有 ring token。

这次证据排除了该样本的“没聚焦/不是 focus-visible/所有 true facts 都被 bridge inactive 拦下/读错 Surface”，将未知边界缩到 renderer.setProps 内及以后。它没有观察 renderer 的 ownsLease 和 propsMap early return，不能把桥函数返回当成已完成 Props 投射。

源码表明 Runtime.update 同步 startUpdate/renderCommit，effects-port.requestFlush 同步，createVisualSink 路径直接写 data-pui-style；不能笼统归到 queueMicrotask 或 React 延迟。React 的 RawPropsSource invalidation 在 effect 中，Props.syncFromHost 受 rawDirty 控制，这是下一层具体可观测边界，不是已证根因。

新的私有 renderer tape 已准备但未由本审查者应用或执行：只记录原 guard 的一次实际结果、propsMap/ref、own-data focusVisible、flushSync 类型和 update 调用；仍保留原返回/异常、输入、断言、deadline。报告维持 partial/ABSTAIN，不是 GitHub approval，不提出盲目等待或强制 ring。原 setup0case、04:17双case红与早先 index1 红均保留独立来源。
