本次04:56:25.634337–04:56:39.101239 UTC仍是1 fail/15 filtered。focus-decoded有4个测量sample，不是4个case：index0品牌、index1导航ref0、index2导航ref1的ring均通过；真正红在index3，/zh-cn/whitepaper/0-preface/，owner homepage-home-navigation-desktop/ref home-link-2，nativeFocusVisible=true。

brand-only finalization在首sample98条、最终118条，只证明本次品牌对象完成Props/effects/done链，不能用来解释后面的导航红。全局projectionTape最终405条、丢149条，也不能称原失败分支取证完整。

原brand红在这个更有观测负担的arm中通过，不等于生产已修复，也不证明具体observer效应机制。唯一下一取证需要先改对实际owner/ref筛选，并保留原断言和一次有界执行；不增加等待或新探针种类。结论partial/ABSTAIN。
