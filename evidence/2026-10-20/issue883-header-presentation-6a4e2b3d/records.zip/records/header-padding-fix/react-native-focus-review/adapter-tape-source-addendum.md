04:50:51–04:51:05 UTC 的原单例仍 1 fail / 15 filtered，实际 base 已是98932e8/tree086f加私有诊断，不能重标为2189原源运行。72条记录、0drop/error：ordinal58观察到false→true、same=false、1subscriber、autoUpdate=true/controller存在；59/60原通知前后返回；61原RawPropsSource.get返回true；62自动update返回。最终原focus-visible为true，但旧token仍无ring。

因此“Adapter丢props/未发通知”不再是本次首分歧解释。下一未知是Props解析report、原commit ack/done以及实际effects输出。源码已有Props.watchAll→Rule重评估和updated阶段重算，不能补造第二条状态路径。

已准备一个有判别价值的私有三文件增量：只读原kernel.applyRaw结果、React实际effects tokens/写出、原pending guard与done前后，使用实际RawPropsSource对象的WeakMap关联；不额外get/sync/evaluate，不改dirty/guard/await/输入/断言。原调用次数、guard AST以及64matcher/106await静态保持。根据结果一次区分Props解析、commit未结算、Rule/Feedback计划、写后覆盖，再决定是否需要修复；不直接责怪Compiler/IR或React调度。

审查者仅准备与读取私有证据，没有执行/应用本增量。结论partial/ABSTAIN，非GitHub批准。
