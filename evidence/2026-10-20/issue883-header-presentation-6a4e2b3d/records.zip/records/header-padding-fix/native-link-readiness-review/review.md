最后有界arm的真实失败是index1、desktop-nav/home-link-surface-0，Source2共77条、0drop/error。3951.700ms原applyRaw报告input和nextResolved.focusVisible=true，随后version10进入onCommit；到3962.300ms原快照仍无ring，未记录该version的layout ack/done/effects。只能表述截至该快照尚未观察到commit结算，不填补后续完成时刻。

active A-REACT-18-19-0001-D明确notification不等同render commit；draft HC-PROPS-SOURCE-0001-C同向。P-BASE/BRUTALIST-SURFACE及T-SURFACE-0001要求原生语义所有权和被动presentation，没有键盘RPC返回就同步paint的额外保证。同仓site-native-links.browser.test.ts第417/466行已在原生Shift+Tab后poll真实ring再采样。

因此建议仅加一个fixture readiness precondition：在原focused snapshot前复用headerLinkPaint，同一次读取要求当前anchor active且原ring-2成立，默认1秒poll、原90秒case不变。原两assert和全部输入/geometry/color/pressed期待均保留；永久缺ring或失焦仍失败。快照代码保持，采样时间有意延后，不能声称旧immediate时序不变，也不能把旧红改叫flake/已通过。

recommended.patch仅私有建议，未apply/run。先以无tape的原Reactlight/dark覆盖验证，后完整16保留其它真实红；停止扩展探针。结论0设计finding、partial/ABSTAIN，不是生产修复完成或GitHub批准。
