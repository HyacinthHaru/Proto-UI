# Bounded query drain: cross-source review

No specific source finding was identified in the normal frozen3file delta: helperab13d078…, caller365e6079…, unitcaa0ab58…. The currently injected worktree caller is excluded. The reviewer did not implement this bounded-drain delta; earlier utility observer authorship is disclosed.

Independent static comparison confirms all171 complete matcher expressions,76 input expressions,case names/deadlines,the mobile case and original timedoption-click/query/verdict block unchanged. Both browser-loaded expressions are byte-identical. A single diagnostic deadline is created outside the batchloop; each batch gets remainingtime and the memoized finish operation cannot renew it. allSettled/race observe originalPromisess without replacing,cancelling,resolving or rejudging them.

When observation expires, completeAtDrainPoint remainsfalse, pendingmetadata is retained and earlyhook collection/restoration is skipped. The existing errorcapture/rethrow path can continue. After the original context.close attempt, incomplete disposal only records actualclose success, marks captureunusable/restorationAttemptedfalse and detaches. It does not Runtime.evaluate or claimrestored. The complete-drain owner-token branch is unchanged. Timercleanup is in finally; invalid/exhaustedbudget allocates no timer.

ActualNodeunit validation at05:29:48–49UTC is4passed/0failed. Those tests cover later originalresolution afterexpiry,permanentlyunsettled observation,originalvalue/Error/raw0 identity and timercleanup,plus exhaustedbudget. Their fakeclock is not a nativebrowserhang. The appliedreceipt binds the normalcandidate while otherHeader/Base candidates were present; no clean989execution is asserted.

The1000ms diagnostic budget is not a hard realtime bound under Nodeeventloopstarvation. Existing otherRPC/file/contextclose failure semantics are unchanged; contextCloseSucceeded=false stays an explicitfailedcleanup boundary rather than a restoredclaim. The actual caller fault-injection execution remains unassessed until root supplies its terminal and source-restoration receipt; this report does not pre-label that run green.

Exactsource/result hashes and the preservation checks are in report.json/static-audit.json. Partial/ABSTAIN, no formalapproval or hostedcause claim. No newexecution or mutation was performed by this reviewer.
