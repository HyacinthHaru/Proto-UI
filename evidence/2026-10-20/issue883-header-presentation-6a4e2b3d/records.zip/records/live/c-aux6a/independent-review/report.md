# 6a4e2b3d 四项 auxiliary workflow 有界分流

四个原日志及获取回执 SHA/bytes 全部吻合；checkout 均直接为 `6a4e2b3d…`（Dialog 的 candidate 与 subject 两个 checkout 也相同），tree 为 `41adb199…`。这些不是主22 run的synthetic checkout。结论 **partial / ABSTAIN**；没有来源或计数不一致，实际红和未知原因仍保留。

| 辅助 job | 首个可证失败 | 可确认范围 | 不能推出 |
|---|---|---|---|
| Accordion 118478609180 | apt update 对 Microsoft Ubuntu noble InRelease 返回403，exit100 | 安装阶段，尚未输入面检查/原生25 | Accordion实现红、flake |
| Dialog 118478610723 | positive reporting control 的 processTimedOut=true，verifier71要求false；Node116/117 | candidate-owned Node证据验证器控制，matched浏览器步骤前 | Dialog原生几何红或重新校准结果 |
| Native-links 118478611704 | 原1818的facts.visible 10s，9过1红 | sidebar当前文章在实际scroll owner中的可见性 | Header ring失败、具体owner或时序根因 |
| Search 118478611685 | 7项initial-ready566 + 8项Docs role987；15过15红 | 两个独立readiness边界 | Search激活callback失败、Pagefind故障、永久role丢失 |

Dialog 的 `onProcessTimeout()` 是 reporter 接口实际设置该字段的位置；当前正向 control 的失败与单独的负向 process-timeout control 不是同一项。原控制只生成合成的8个预期断言失败，不启动浏览器或产品源。因此不能把此 job 记作 matched native candidate 红；也不能为了通过而去掉 integrity gate。stdout 未提供正向 child 的完整 timeout 原因，应保留未知。

Native-links 的现有 `facts()` 已能读出 nearest scroll owner、link/owner几何、scrollTop、documentY、projection marker。原poll只返回visible，所以日志不能辨别missing owner与具体越界或哪次调度未完成。PageFrame→sidebar current visibility 的rAF/fonts/MO/resize/contents-open/manual-yield是app布局路径。它不等于Header焦点ring；可在不改原predicate/deadline的前提下保留同一次facts对象，而不是给产品加等待或猜CSS。

Search987发生在 `revealHeaderPreferences` 和所有runtime切换之前。其role来自SSR family SelectTrigger→site controls注册→WC Adapter→Base Trigger的combobox声明；当前draft P要求该role，但未规定原生导航RPC结束后1000ms必达的通用同步保证。保留原1s验收，不据此擅改oracle。七项initial-ready则采用另一套浏览器1000ms观察窗，原失败后owner已经ready的捕获不能回填窗口；这些失败还没有调用Search open/close业务。原fixture用Astro dev并明确不声称生产Pagefind index。

没有新增测试、浏览器、下载或source修改，也没有把父任务正在/刚完成的本地Search控制当成本报告的官方结论。建议仅保留现有同次查询的返回值/时点与明确后置的目标身份，进一步诊断前不认定C根因或提交修复。
