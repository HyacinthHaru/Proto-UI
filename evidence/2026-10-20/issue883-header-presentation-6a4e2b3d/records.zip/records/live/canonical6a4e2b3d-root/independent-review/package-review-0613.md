# 6a4e2b3d package job 独立核对

原 job `118479547390` 日志有 **45 条不同 package 的实际 build 记录 / 47 public packages**，随后是 **47 manifest** 核验与 **9 个 policy tests 全通过**。不能写成 47 个实际构建，也不能借用旧 44 数。

九项 measurement 全部按原行提取并保存 gzip、ceiling、超额、minified 和 SHA256；结果为 **4 PASS / 5 ADVISORY**，不是严格预算全绿。实际工具链为 Node 24.21.0、zlib 1.3.2.1-motley-8002e91、esbuild 0.25.12、Linux x64。相邻 consumer diagnostic 两项没有并入九项 policy。

与历史 98932 的九项比较：[{"path": "<R14>/live/canonical98932/118461110979.log", "sha256": "1d0e3da205fe2d07d0798e09f70f34de5f0e32234725bfcb829220ae3985e904", "allNineEqual": true, "differentEntries": []}]

准确 checkout 为 `6da7be99…`，tree 等于 6a 的 `41adb199…`。使用 root 缓存及已保留来源回执，没有新下载或运行验证。0 具体来源/计数 finding，partial / ABSTAIN；全 CI 仍须按后续实际终态记录。
