# 6a4e2b3d canonical CI 最终独立核对

准确 run **39377429538** 已 completed FAILURE，**22 jobs / 13 success / 9 failure**。结论是 **partial / ABSTAIN**，没有来源或计数不一致 finding；保留下面的实际失败，不是全 CI 通过或 GitHub 批准。

实际 synthetic checkout 为 `6da7be999c6054700279c0c180891f589c5bea12`，tree `41adb1995907dde0fecd8a0bda72431aa952547f` 等于产品 `6a4e2b3d…`，parents 为 main `042f…` 和该产品 head。全部 22 原日志、获取回执、完整 run/jobs 快照及 Git 对象均逐 SHA 绑定。

| Shard | 完整 summary | Passed | Failed | Skipped | 终态边界 |
|---|---:|---:|---:|---:|---|
| 1 | 否 | — | — | — | exit124 |
| 2 | 否 | — | — | — | exit124 |
| 3 | 是 | 58 | 3 | 0 | exit1 |
| 4 | 是 | 122 | 2 | 0 | exit1 |
| 5 | 是 | 88 | 2 | 15 | exit1 |
| 6 | 是 | 169 | 0 | 0 | success |
| 7 | 否 | — | — | — | exit124 |
| 8 | 否 | — | — | — | exit124 |

仅完整 3/4/5/6 子集合计 **437 passed / 7 failed / 15 skipped**，没有八片总数。每片已出现的文件结果和失败标题均保存在 JSON，超时没有抹掉已完成文件，也没有被补成完整执行。

当前 Homepage 文件 **9/9** 实际通过；Brutalist 原 poll fulfilled **770.190141 ms**，三次返回 shadcn/shadcn/brutalist。verdict 时无 pending，1000ms 独立 post-verdict budget 的实际 drain **0.196125 ms**，没有到期，完整结算；utility 恢复并 detached、0 drops/errors。这只证明本次 settled 路径，未在本次官方 run 演练永久 pending 的到期分支，也不解释历史 timeout 的原因。12 个 mobile stages 为 **390 → 430 → 320**，本次无 rejection，不能反推旧失败。

Header **16/16** 在 shard8 原日志明确通过，包含两 family×四 runtime×light/dark；该片随后仍 exit124。原完整 settings 旅程在 shard1 原日志明确通过，但不使整片成功。Collapsible36、color9、Tooltip2、Field25、overlay-scrollbar16、ScrollCorner2 等当前文件通过事实与各自分片边界同时保留。

未决实际失败包括：Shadow Template preset 两个 5s timeout、Liquid portal 一个 containment measurement、React dark first-reveal、Search readiness/Docs runtime 值多项、DemoMatrix 四项、family opacity 两项、S4 paint/S4/S5、Brutalist Checkbox shadow、sidebar current-article、Brutalist Tabs/Dropdown 和 Liquid material。部分位于未完成片，不能把文件名相同视为同根因、继承或 flake；也没有以本地 native136 阳性覆盖这些官方红。

General 在 `check:public-docs` **78 drift** 后停止，未执行 Vitest。Types 为 **936 / 0 errors / 0 warnings / 14 hints**。Package 为 **45 个实际 build / 47 public packages、47 manifests、9 policy tests pass、4 PASS / 5 ADVISORY budgets**。九项测量值及 hash 已逐项核对；advisory 不等于严格预算通过。

Git/原断言/owner17 的源绑定与本地执行报告仍保留各自 precommit 时间；这里没有把它们重标为 canonical Node 执行。核对过程中不运行测试/浏览器、不下载新产物、不修改源码或 GitHub。交叉接手造成的十次重复日志 GET 已披露并保留；后续全部使用 root 缓存。
