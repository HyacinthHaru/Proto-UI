#!/usr/bin/env python3
"""One-shot same-head utility7 analysis from the actual original log; no execution/network."""
from pathlib import Path
from decimal import Decimal as D
import importlib.util,json,hashlib,datetime
R=Path(__file__).resolve().parent.parent; B=R/'live/canonical98932';O=B/'derived-utility-seven-v1'
if O.exists():raise FileExistsError(O)
spec=importlib.util.spec_from_file_location('mainfive',Path(__file__).with_name('reconcile-98932.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
job=118461123949; lp=B/f'{job}.log';raw=lp.read_bytes();meta=m.load(lp.with_suffix('.json'));assert meta['sha256']==m.sha(raw) and meta['head']==m.HEAD and meta['run']==m.RUN
lines=m.strip_log(raw)
def one(tag):
 rows=m.markers(lines,tag);assert len(rows)==1 and 'value' in rows[0],tag;return rows[0]
queryrow=one('[family-query-observation]'); timingrow=one('[family-commit-poll-timing]'); verdictrow=one('[family-query-verdict]')
q=queryrow['value'];t=timingrow['value'];p=t['familyCommitTiming'];f=t['familyMutationTiming']['facts'];u=q['utility'];uf=u['collection']['facts'];calls=p['calls'];reads=uf['reads']
main=m.load(B/'derived-reconciliation-v1/reconciliation.json');shard=next(x for x in main['shards'] if x['shard']==2);five=shard['familyTiming'][0]
reasons=[]
def require(ok,reason):
 if not ok:reasons.append(reason)
require(five['writerUsable'] is True,'five main writer conditions incomplete')
require(q['mode']=='hybrid' and q['enabled']=={'node':True,'writerMO':True,'utility':True},'hybrid flags unavailable')
require(q['source']==t['source'] and q['source']['sha']=='665c0661c56f4e54a4dcbb489f6b180dc9550308' and q['source']['dirty'] is False,'source mismatch')
require(q['verdict']['outcome']==p['outcome'] and q['verdict']['nodeMs']==p['finishedMs'],'frozen verdict mismatch')
require(u['available'] is True and u['usable'] is True and u['errors']==[],'utility setup/error status')
require(u['install']['exceptionDetails'] is None and u['collection']['exceptionDetails'] is None,'utility evaluation exception')
for k in ['ownerMatched','wrapperStillOwned','restored','currentRootSame','rootConnected']:require(uf.get(k) is True,k)
require(u.get('detached') is True and not u.get('contextDestroyed') and not u.get('contextsCleared'),'context/session cleanup')
require(uf.get('droppedReads')==0 and uf.get('observerError') is False and not uf.get('captureError') and not uf.get('restoreError') and not uf.get('slotCleanupError'),'utility drop/error')
require(q.get('errors')==[] and q.get('ledgerError') is False and q.get('droppedNodeRows')==0,'Node/ledger error')
for k in ['droppedPendingRows','issuedAfterDrain','pendingObservedAtReport']:require(q.get(k)==0,k)
require(q['wait']['completeAtDrainPoint'] is True and q['wait']['droppedOutcomeRows']==0,'drain coverage')
require(q['referenceCountAtVerdict']==q['referenceCountAfterDrain']==q['referenceCountAtReport']==q['wait']['drainedReferences']==p['totalCalls']==len(calls)==uf['totalReads']==len(reads),'independent counts')
require([x.get('value') for x in calls]==[x.get('value') for x in reads],'order/value pairing')
require([x['ordinal'] for x in reads]==list(range(1,len(reads)+1)),'ordinal sequence')
require(u['selectedContext']['auxData']['frameId']==u['mainFrame']['id'] and u['selectedContext']['auxData']['isDefault'] is False,'actual utility main-frame metadata')
origins=[f['timeOrigin'],f['collectedTimeOrigin'],u['install']['facts']['timeOrigin'],uf['timeOrigin'],*[x['timeOrigin'] for x in t['familyMutationTiming']['calibration']]]
require(len({D(str(x)) for x in origins})==1,'same observed browser timeOrigin')
require(u['nodeTimeOrigin']==p['timeOrigin'],'same Node timeOrigin')
brackets=[{'sample':x['sample'],'source':'main-world writer/MO','limits':[D(v) for v in x['exactDecimalOffset']]} for x in five['allRawCalibrationSamples']]
for name,phase,page in [('utility-install',u['install'],u['install']['facts']['pageMs']),('utility-collect',u['collection'],uf['pageMs'])]:
 a,b,v=[D(str(x)) for x in [phase['nodeStartedMs'],phase['nodeReturnedMs'],page]];require(a<=b,name+' reversed bracket');brackets.append({'sample':name,'source':'utility realm','limits':[a-v,b-v]})
lo=max(x['limits'][0] for x in brackets);hi=min(x['limits'][1] for x in brackets);require(lo<=hi,'all7 intersection empty')
start=D(str(p['startedMs']));rejected=D(str(p['finishedMs']));rel=lambda v:[float(D(str(v))+lo-start),float(D(str(v))+hi-start)]
pairs=[]
for i,(c,g) in enumerate(zip(calls,reads),1):
 a,b=[D(str(g[k])) for k in ['beforeMs','afterMs']];cs,cr=[D(str(c[k])) for k in ['startedMs','returnedMs']]
 require(a<=b,'getter bracket reversed')
 pairs.append({'ordinal':i,'nodeCall':c['call'],'value':g.get('value'),'nativeOutcome':g.get('outcome'),'utilityRelativePollMs':[float(a+lo-start),float(b+hi-start)],'utilityInvocationAfterRejectionMs':[float(a+lo-rejected),float(a+hi-rejected)],'nodeStartRelativeMs':float(cs-start),'nodeReturnRelativeMs':float(cr-start),'nodeReturnAfterRejectionMs':float(cr-rejected),'preGetterIntervalMs':[float(a+lo-cs),float(a+hi-cs)],'getterToNodeSettlementIntervalMs':[float(cr-b-hi),float(cr-b-lo)],'reportedGetterSpanMs':float(b-a)})
root=m.load(B/'query-timing-root-reconciliation.json');diff=[float(lo-D(str(root['sevenBracketIntersectionNodeMinusPageMs'][0]))),float(hi-D(str(root['sevenBracketIntersectionNodeMinusPageMs'][1])))]
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':m.HEAD,'tree':m.TREE,'run':m.RUN,'job':job,'kind':'Same-head raw-log utility7 arithmetic only; no new execution','log':m.record(lp),'downloadReceipt':m.record(lp.with_suffix('.json')),'checkoutBinding':m.record(B/'checkout-git-object.json'),'markerLines':{'query':queryrow['line'],'timing':timingrow['line'],'verdict':verdictrow['line']},'fiveBracketReport':m.record(B/'derived-reconciliation-v1/reconciliation.json'),'mainFiveIntersectionMs':five['conditionalAllFiveIntersectionMs'],'sevenBrackets':[{'sample':x['sample'],'source':x['source'],'exactDecimalLimits':[str(v) for v in x['limits']]} for x in brackets],'conditionalAllSevenIntersectionMs':[float(lo),float(hi)],'exactDecimalAllSevenIntersection':[str(lo),str(hi)],'rootReportArithmeticDifferenceMs':diff,'rootReport':m.record(B/'query-timing-root-reconciliation.json'),'independentUsableChecks':{'usable':not reasons,'unavailableReasons':reasons,'pairing':'Conditional ordinal/count/order/value correspondence, not protocol query IDs'},'poll':{'outcome':p['outcome'],'originalRejectionRelativeMs':float(rejected-start),'frozenRejectionSnapshot':p['rejectionSnapshot'],'pendingAtVerdict':q['pendingAtVerdictCount'],'drainedReferences':q['wait']['drainedReferences'],'postVerdictWaitMs':float(D(str(q['wait']['finishedMs']))-D(str(q['wait']['startedMs']))),'pendingAtReport':q['pendingObservedAtReport']},'nativeWriterFinishRelativeMs':[rel(x['finishedMs']) for x in f['writes']],'MODeliveryRelativeMs':[rel(x['deliveredMs']) for x in f['deliveries']],'conditionalPairs':pairs,'rawQuery':q,'rawTiming':t,'limits':['All7 samples retained; original5 method stays separately reported. Numerical equality of5/7 intersections in this run does not make them the same method.','Same observed browser origin and approximate constant relative clock offset/rate assumed. No independent drift/quantization or zero-overhead bound.','Read ordinals are not Node request IDs. Count/order/value conditions are necessary but not independent proof of1:1identity.','This hybrid run captured a third getter after the original rejection under those assumptions. It does not partition selector/renderer/protocol/network/Node scheduling or explain older2189 getter execution.','Native dataset writer completion is not whole family transaction success; late drained success does not revise the original failed matcher.','This run exercises one pending-at-verdict request that actually settles. An indefinitely unsettled Promise remains a cleanup robustness gap, because existing drainage has no independent bound before failure capture/rethrow/context.close.','Local3mode controls belong to their recorded dirty source epoch and do not quantify hosted instrumentation effect.'],'disposition':'partial/ABSTAIN; arithmetic/source review, no formal approval'}
O.mkdir();(O/'reconciliation.json').write_text(json.dumps(report,indent=2)+'\n');(O/'reconciliation.md').write_text(f"# Exact98932 utility7 observation\n\nOriginal rejection +{report['poll']['originalRejectionRelativeMs']}ms; pending at verdict {q['pendingAtVerdictCount']}. All7 conditional offset intersection {report['conditionalAllSevenIntersectionMs']}ms. Third observed getter +{pairs[2]['utilityRelativePollMs']}ms; original Node return +{pairs[2]['nodeReturnRelativeMs']}ms. Post-verdict wait {report['poll']['postVerdictWaitMs']}ms. Original result remains rejected.\n\nAll5 writer samples remain separately reported; both methods happen to have the same intersection here. No subset substitution, protocol-ID claim, pure queue/network partition, old-head inference or overall approval. The indefinitely unsettled-request cleanup gap is not closed by this finite drain. See JSON for raw objects, independentconditions and everybracket.\n")
print(json.dumps({'output':str(O),'usable':not reasons,'reasons':reasons,'all7':[float(lo),float(hi)],'third':pairs[2],'counts':len(reads),'reportSHA256':m.sha((O/'reconciliation.json').read_bytes())},indent=2))
