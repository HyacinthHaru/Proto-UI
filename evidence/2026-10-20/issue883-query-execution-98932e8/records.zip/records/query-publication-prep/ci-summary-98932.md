# Exact98932 canonical checkpoint

Run39371457764 completed failure with22jobs:13success/9failure. All22 original log/download hashes and syntheticcheckout665c0661→tree086f are bound. Only shards1/3/4/5/6 have full summaries: **648passed/36failed/15skipped**. Shards2/7/8 exit124 and have no whole-shard summary. No all8 test total is claimed.

General stops at78public-docs drift before ordinaryVitest. Types:935files/0errors/0warnings/14hints. Package:44 actual build records out of47 publicpackages,47manifest checks,9policy tests,4PASS/5ADVISORY budget rows. These are separate facts, not all-budgetPASS.

Homepage is8passed/1failed. Mobile reached all12stage records and its original case passed; this is not a fix or first-failure explanation for older mobile negatives. The original Brutalist poll rejected at+1000.939018ms with request3 pending. It settled at+1106.093828ms; actual post-verdict drain took104.897409ms. Allfive writer/MO brackets are analysed separately from allseven utility-inclusive brackets, even though this run's intersections are numerically identical. Under the recorded same-origin/stable-rate assumptions, the third observed utility getter itself was at+[1104.813795,1105.710299]ms. Original failure remains failure.

Feedback6283933166 confirms the narrower instrumented observation and requests an indefinitely-unsettled-request cleanup control. Count/order/value correspondence is not protocol-ID pairing; no pure renderer,selector,network,transport or Node-event-loop cause is isolated. No older2189 getter timestamp or late success is relabelled. Later local Header/Base candidates are outside this exact989CI epoch. Partial/ABSTAIN, no formal approval.
