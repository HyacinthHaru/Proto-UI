#!/usr/bin/env python3
"""One-shot local reconciliation only. No polling, network, subprocess or test execution.
Read the completed watcher snapshot and its exact downloaded logs. Never rewrite inputs.
Output is refused if it exists; use a fresh --out-dir for an explicitly revised report.
"""
from pathlib import Path
from collections import Counter
from decimal import Decimal
import argparse, datetime, hashlib, json, math, re
HEAD = '98932e8132ae4f3e1dacb9bf5967ebac481953ab'
TREE = '086f2d336a5adbdc5849dfb77aca7ee194a513cd'
RUN = 39371457764
ROOT = Path(__file__).resolve().parent.parent
D = lambda x: Decimal(str(x))
sha = lambda b: hashlib.sha256(b).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def record(p):
    p = Path(p); data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': sha(data)}
def numeric(x): return type(x) in (int, float) and math.isfinite(x)
def strip_log(data):
    text = re.sub(r'\x1b\[[0-9;]*m', '', data.decode())
    return [re.sub(r'^\d{4}-\d\d-\d\dT\S+\s+', '', line) for line in text.splitlines()]
def counts(text):
    return {key: sum(int(n) for n, word in re.findall(r'(\d+)\s+(passed|failed|skipped|todo)\b', text.lower()) if word == key)
            for key in ('passed', 'failed', 'skipped', 'todo')}
def markers(lines, tag):
    rows = []
    for i, line in enumerate(lines, 1):
        if tag not in line: continue
        tail = line.split(tag, 1)[1].strip()
        try:
            value, consumed = json.JSONDecoder().raw_decode(tail)
            rows.append({'line': i, 'value': value, 'trailingText': tail[consumed:].strip()})
        except Exception as error:
            rows.append({'line': i, 'parseError': str(error), 'rawText': tail})
    return rows

def checkout_markers(lines):
    values = []
    for i, line in enumerate(lines):
        if re.search(r'git log -1 --format=[\'\"]?%H', line):
            for j in range(i + 1, min(i + 6, len(lines))):
                match = re.fullmatch(r'\s*([a-f0-9]{40})\s*', lines[j])
                if match: values.append({'line': j + 1, 'sha': match.group(1)}); break
    return values

def parse_summary(lines):
    file_rows = [{'line': i, 'text': line.strip(), 'counts': counts(line)} for i, line in enumerate(lines, 1) if re.match(r'^\s*Test Files\s+', line)]
    test_rows = [{'line': i, 'text': line.strip(), 'counts': counts(line)} for i, line in enumerate(lines, 1) if re.match(r'^\s*Tests\s+', line)]
    exits = [{'line': i, 'code': int(m.group(1))} for i, line in enumerate(lines, 1)
             if (m := re.search(r'Process completed with exit code (\d+)', line))]
    complete = bool(file_rows and test_rows)
    return {'fileSummaries': file_rows, 'testSummaries': test_rows,
            'finalReportedFiles': file_rows[-1] if file_rows else None,
            'finalReportedTests': test_rows[-1] if test_rows else None,
            'hasFullVitestSummary': complete, 'exitCodes': exits,
            'deadline124Seen': any(x['code'] == 124 for x in exits),
            'incompleteBoundary': None if complete else 'No full file+test summary; individual file results do not establish the whole shard total.'}

def file_results(lines):
    result = []
    pattern = re.compile(r'^\s*([✓❯×])\s+((?:apps|packages|scripts)/\S+\.(?:test|spec)\.[^\s]+)\s+\((\d+) tests?(?:\s*\|([^)]*))?\)\s*(.*)$')
    for i, line in enumerate(lines, 1):
        m = pattern.match(line)
        if not m: continue
        result.append({'line': i, 'statusMarker': m.group(1), 'file': m.group(2),
                       'reportedTotal': int(m.group(3)), 'reportedBreakdown': m.group(4),
                       'explicitCounts': counts(m.group(4) or ''), 'durationText': m.group(5), 'rawLine': line.strip()})
    return result

def timing_analysis(row, checkout_shas, tree_bound):
    if 'parseError' in row: return {'line': row['line'], 'writerUsable': False, 'reasons': ['marker JSON parse failed'], 'raw': row}
    raw = row['value']; reasons = []
    try:
        p = raw['familyCommitTiming']; m = raw['familyMutationTiming']; f = m.get('facts') or {}
        source = raw.get('source') or {}; observed_source_ok = source.get('sha') in checkout_shas and source.get('dirty') is False
        if not observed_source_ok: reasons.append('marker source does not match observed checkout or is not clean')
        if m.get('errors') != []: reasons.append('main observer/RPC errors missing or nonempty')
        if p.get('observerError') is not False or p.get('droppedCalls') != 0: reasons.append('Node observer error/drop condition not satisfied')
        for key in ('writerObserverError',):
            if f.get(key) is not False: reasons.append(key + ' is not explicitly false')
        if f.get('observerError', 'missing') is not None: reasons.append('MO observer error condition not satisfied')
        for key in ('droppedWrites', 'droppedRecords', 'pendingDroppedRecords'):
            if f.get(key) != 0: reasons.append(key + ' is missing or nonzero')
        for key in ('datasetRestored', 'currentRootSame', 'connected'):
            if f.get(key) is not True: reasons.append(key + ' is not true')
        calibration = m.get('calibration') or []
        if len(calibration) != 3: reasons.append('expected all three post-verdict samples')
        if any(x.get('currentRootSame') is not True for x in calibration): reasons.append('calibration root identity not retained')
        origins = [f.get('timeOrigin'), f.get('collectedTimeOrigin'), *[x.get('timeOrigin') for x in calibration]]
        if not all(numeric(x) for x in origins) or len({str(x) for x in origins}) != 1: reasons.append('main samples lack one observed timeOrigin')
        intervals = []
        samples = [('setup', m.get('setup') or {}, f.get('setupPageMs')), ('collect', m.get('collect') or {}, f.get('collectedPageMs'))]
        samples += [(f'post-{i}', x, x.get('pageMs')) for i, x in enumerate(calibration, 1)]
        for name, bracket, page in samples:
            s, r = bracket.get('nodeStartedMs'), bracket.get('nodeReturnedMs')
            if not all(numeric(x) for x in [s, r, page]) or s > r:
                intervals.append({'sample': name, 'unavailable': True, 'raw': bracket, 'pageMs': page}); reasons.append(name + ' sample incomplete'); continue
            limits = [D(s) - D(page), D(r) - D(page)]
            intervals.append({'sample': name, 'nodeStartedMs': s, 'nodeReturnedMs': r, 'pageMs': page, 'offsetMs': [float(x) for x in limits], 'exactDecimalOffset': [str(x) for x in limits]})
        good = [x for x in intervals if 'offsetMs' in x]
        intersection = None
        if len(good) == 5 and len(samples) == 5:
            bounds = [max(D(x['exactDecimalOffset'][0]) for x in good), min(D(x['exactDecimalOffset'][1]) for x in good)]
            if bounds[0] <= bounds[1]: intersection = bounds
            else: reasons.append('all-five offset intersection is empty; do not choose a best subset')
        else: reasons.append('not all five samples complete')
        if not numeric(p.get('startedMs')) or not numeric(p.get('finishedMs')): reasons.append('poll boundary times incomplete')
        writes = f.get('writes')
        if not isinstance(writes, list) or not writes: reasons.append('no complete captured native family write')
        else:
            for x in writes:
                if not numeric(x.get('startedMs')) or not numeric(x.get('finishedMs')) or x['startedMs'] > x['finishedMs']:
                    reasons.append('writer bracket incomplete/reversed')
        mapped_writes, mapped_mo = [], []
        complete_mechanical = not reasons
        if complete_mechanical and intersection:
            start = D(p['startedMs'])
            for x in writes:
                mapped_writes.append({'raw': x, 'relativeToPollMs': [float(D(x['startedMs']) + intersection[0] - start), float(D(x['finishedMs']) + intersection[1] - start)], 'meaning': 'Native attribute-write call bracket only; returned true is not entire transaction success.'})
            for x in f.get('deliveries', []):
                if numeric(x.get('deliveredMs')):
                    mapped_mo.append({'raw': x, 'relativeToPollMs': [float(D(x['deliveredMs']) + intersection[0] - start), float(D(x['deliveredMs']) + intersection[1] - start)], 'meaning': 'MO callback delivery, not DOM mutation instant.'})
        calls = p.get('calls') or []; settled = []
        for x in calls:
            if numeric(x.get('returnedMs')) and numeric(p.get('startedMs')):
                y = {'call': x.get('call'), 'value': x.get('value'), 'error': x.get('error'), 'returnRelativeMs': float(D(x['returnedMs']) - D(p['startedMs']))}
                if p.get('outcome') == 'rejected' and numeric(p.get('finishedMs')): y['returnAfterRejectionMs'] = float(D(x['returnedMs']) - D(p['finishedMs']))
                settled.append(y)
        if not tree_bound: reasons.append('exact checkout tree binding absent; source-bound usable claim withheld')
        return {'line': row['line'], 'raw': raw, 'mechanicallyCompleteUnderClockAssumptions': complete_mechanical,
                'exactCheckoutTreeBound': tree_bound, 'writerUsable': complete_mechanical and tree_bound,
                'unavailableReasons': reasons, 'allRawCalibrationSamples': intervals,
                'conditionalAllFiveIntersectionMs': [float(x) for x in intersection] if intersection else None,
                'conditionalIntersectionWidthMs': float(intersection[1]-intersection[0]) if intersection else None,
                'writerMappedIntervals': mapped_writes, 'MODeliveryMappedIntervals': mapped_mo,
                'pollOutcome': p.get('outcome'), 'pollElapsedMs': float(D(p['finishedMs'])-D(p['startedMs'])) if numeric(p.get('startedMs')) and numeric(p.get('finishedMs')) else None,
                'querySettlements': settled, 'rejectionSnapshot': p.get('rejectionSnapshot'),
                'limits': ['All five samples must be retained; no shortest/best-sample selection.', 'Same document and approximately constant relative offset/rate assumed; clock quantization/drift/observer overhead unbounded.', 'This function uses exactly5 main-world samples. Utility install/collect7-sample analysis is a separate same-head report.', 'The captured write bracket is not whole transaction completion; getter invocation analysis belongs to the separate same-head utility report.']}
    except Exception as error:
        return {'line': row['line'], 'raw': raw, 'writerUsable': False, 'unavailableReasons': ['analysis could not safely derive complete timing: ' + str(error)]}

def mobile_analysis(lines, checkout_shas, tree_bound, predicates):
    rejected = markers(lines, '[mobile-shell-rejection]'); stages = markers(lines, '[mobile-shell-stages]')
    for row in rejected:
        if 'value' not in row: continue
        value = row['value']; row['originalPredicate'] = predicates.get(value.get('stage'))
        row['markerSourceMatchesCheckout'] = (value.get('source') or {}).get('sha') in checkout_shas and (value.get('source') or {}).get('dirty') is False
        row['exactCheckoutTreeBound'] = tree_bound
        row['classification'] = 'Frozen original poll rejection before added browser RPC' if row['originalPredicate'] and 'Matcher did not succeed in 1000ms' in value.get('message', '') else 'Other/unknown original stage; do not force attribution to a poll'
        row['originalStack'] = value.get('stack'); row['originalCause'] = value.get('cause'); row['width'] = value.get('width')
    capture_errors = [{'line': i, 'text': line.split('[mobile-shell-capture-error]', 1)[1].strip()} for i, line in enumerate(lines, 1) if '[mobile-shell-capture-error]' in line]
    return {'frozenRejections': rejected, 'allStageRecords': stages, 'captureErrors': capture_errors,
            'boundary': 'Use frozen stage/width/stack, not late snapshots. No rejection marker is not proof of pass; consult actual file/case results. Original timeout/inputs/predicates unchanged.'}

def mobile_source_predicates(source):
    source=Path(source); raw=source.read_bytes()
    if sha(raw) != 'a2e2c176da464aba702748335a2b6adaa88caf50776e233361ae8798ecb1e074':
        raise ValueError('Mobile source is not the exact98932 committed Homepage file')
    lines=raw.decode().splitlines(); result={}
    for stage, fragment, callback, expected in [
        ('menu-ready', "expect.poll(() => header.getAttribute('data-site-menu-ready'))", "header.getAttribute('data-site-menu-ready')", ''),
        ('navigation-close-from-contents', "expect.poll(() => menu.getAttribute('aria-expanded')).toBe('false')", "menu.getAttribute('aria-expanded')", 'false'),
    ]:
        stage_hits=[i for i,line in enumerate(lines) if "stage = '"+stage+"';" in line]
        if len(stage_hits)!=1:raise ValueError('Mobile stage is not unique: '+stage)
        anchor=stage_hits[0]
        hits=[i+1 for i in range(anchor,min(anchor+10,len(lines))) if fragment in lines[i]]
        if len(hits)!=1:raise ValueError('Mobile predicate adjacent to stage not unique: '+stage)
        result[stage]={'sourceLine':hits[0],'callback':callback,'expected':expected,'sourceSHA256':sha(raw)}
    return result

def review_all_job_logs(base, jobs, binding):
    rows=[]; critical={}
    for job in jobs:
        lp=base/f"{job['id']}.log";mp=lp.with_suffix('.json')
        raw=lp.read_bytes(); meta=load(mp)
        if meta.get('head')!=HEAD or meta.get('run')!=RUN or meta.get('job')!=job['id'] or meta.get('sha256')!=sha(raw) or meta.get('bytes')!=len(raw):
            raise ValueError('Job log binding mismatch: '+str(job['id']))
        lines=strip_log(raw); checkouts=checkout_markers(lines)
        bound=bool(checkouts) and all(x['sha']==HEAD or (binding and x['sha']==binding['sha']) for x in checkouts)
        row={'jobId':job['id'],'name':job['name'],'conclusion':job['conclusion'],'log':record(lp),'downloadReceipt':record(mp),'checkouts':checkouts,'exactCheckoutTreeBound':bound}
        rows.append(row)
        if job['name']=='test-general':
            drift=[{'line':i,'count':int(m.group(1)),'text':line} for i,line in enumerate(lines,1) if (m:=re.match(r'^\[public-docs\] (\d+) drift issue',line))]
            vitest=[{'line':i,'text':line} for i,line in enumerate(lines,1) if re.match(r'^\s*RUN\s+v\d',line)]
            critical['general']={**row,'docsDrift':drift,'vitestRunHeaders':vitest,'summary':parse_summary(lines),'boundary':'Printed shell recipe is not execution. Public docs guard failed before ordinary Vitest; no general-suite pass/count claimed.'}
        if job['name']=='type-check':
            results=[]
            for i,line in enumerate(lines):
                m=re.match(r'^Result \((\d+) files\):',line)
                if m: results.append({'line':i+1,'files':int(m.group(1)),'followingLines':lines[i+1:i+4]})
            critical['types']={**row,'results':results}
        if job['name']=='public_package_build':
            actual=[{'line':i,'package':m.group(1),'text':line} for i,line in enumerate(lines,1) if (m:=re.match(r'^\[build:packages\] (@\S+) \d+ms \d+ files',line))]
            totals=[{'line':i,'built':int(m.group(1)),'publicTotal':int(m.group(2))} for i,line in enumerate(lines,1) if (m:=re.match(r'^\[build:packages\] complete: (\d+)/(\d+) public packages',line))]
            manifests=[{'line':i,'count':int(m.group(1))} for i,line in enumerate(lines,1) if (m:=re.match(r'^checked (\d+) public manifests',line))]
            budgets=[{'line':i,'status':m.group(1),'text':line} for i,line in enumerate(lines,1) if (m:=re.match(r'^(PASS|ADVISORY) ',line))]
            policy=[{'line':i,'text':line} for i,line in enumerate(lines,1) if re.match(r'^[ℹ#] (?:tests|pass|fail) \d+',line)]
            critical['package']={**row,'actualBuildRecords':actual,'actualBuildCount':len(actual),'uniqueBuiltPackages':len({x['package'] for x in actual}),'declaredComplete':totals,'manifestChecks':manifests,'policyLines':policy,'budgetRows':budgets,'budgetStatusCounts':dict(Counter(x['status'] for x in budgets)),'boundary':'Changed-package actual build count and47manifest checks are distinct; advisory rows are not budgetPASS.'}
    return rows,critical

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=ROOT/'live/canonical98932')
    parser.add_argument('--out-dir', type=Path, default=ROOT/'live/canonical98932/derived-reconciliation')
    parser.add_argument('--checkout-binding', type=Path, help='Optional saved direct Git-commit API object with top-level sha and tree.sha; no fetch is performed')
    parser.add_argument('--homepage-source', type=Path, default=ROOT/'query-publication-prep/git-sources/apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts')
    args = parser.parse_args(); base=args.input_dir.resolve(); out=args.out_dir.resolve()
    if not base.is_relative_to(ROOT) or not out.is_relative_to(ROOT): raise ValueError('Use R14 private paths only')
    if out.exists(): raise FileExistsError('Output exists; choose a fresh out-dir, never overwrite a prior report')
    terminal=base/'canonical-terminal.json'; data=load(terminal)
    if data.get('head')!=HEAD or data['run'].get('head_sha')!=HEAD or data['run'].get('id')!=RUN: raise ValueError('Wrong run/head; do not combine epochs')
    if data.get('completePagination') is not True or data['run'].get('status')!='completed' or any(x.get('status')!='completed' for x in data['jobs']): raise ValueError('Complete terminal snapshot not available; no polling or fallback to mutable latest.json')
    if data['run'].get('head_commit',{}).get('tree_id')!=TREE: raise ValueError('Head tree identity differs')
    jobs=data['jobs']; browser=[]
    for job in jobs:
        m=re.search(r'^test-browser\s*\(([1-8])/8(?:,|\))',job['name'])
        if m: browser.append((int(m.group(1)),job))
    if sorted(x[0] for x in browser)!=list(range(1,9)): raise ValueError('Exactly eight distinct ordinary shards are required')
    binding=load(args.checkout_binding) if args.checkout_binding else None
    if binding and (not re.fullmatch('[a-f0-9]{40}',binding.get('sha','')) or binding.get('tree',{}).get('sha')!=TREE): raise ValueError('Supplied checkout Git object does not bind expected tree')
    predicates=mobile_source_predicates(args.homepage_source)
    all_job_logs,critical_jobs=review_all_job_logs(base,jobs,binding)
    rows=[]; gaps=[]
    for shard,job in sorted(browser):
        lp=base/f"{job['id']}.log";mp=lp.with_suffix('.json')
        row={'shard':shard,'jobId':job['id'],'name':job['name'],'status':job['status'],'conclusion':job['conclusion']}
        if not lp.exists() or not mp.exists(): row['unavailable']='Downloaded original log/receipt absent';rows.append(row);gaps.append(shard);continue
        raw=lp.read_bytes();meta=load(mp)
        if meta.get('head')!=HEAD or meta.get('run')!=RUN or meta.get('job')!=job['id'] or meta.get('sha256')!=sha(raw) or meta.get('bytes')!=len(raw): raise ValueError(f'Log metadata/hash mismatch for shard{shard}')
        lines=strip_log(raw);checkouts=checkout_markers(lines);check_shas={x['sha'] for x in checkouts}
        tree_bound=bool(check_shas) and all(x==HEAD or (binding and x==binding['sha']) for x in check_shas)
        summary=parse_summary(lines);files=file_results(lines)
        relevant=[x for x in files if re.search(r'homepage|shadow|dialog|field|select|portal|collapsible',x['file'],re.I)]
        case_lines=[{'line':i,'text':line.strip()} for i,line in enumerate(lines,1) if re.match(r'^\s*[✓×]\s+',line) and re.search(r'Homepage|Shadow|Dialog|mobile shell|retains brutalist|Field|Select|Collapsible',line,re.I)]
        row.update(log=record(lp),downloadReceipt=record(mp),checkouts=checkouts,exactCheckoutTreeBound=tree_bound,summary=summary,allReportedFileResults=files,relevantFileResults=relevant,relevantCaseLines=case_lines,
                   familyTiming=[timing_analysis(x,check_shas,tree_bound) for x in markers(lines,'[family-commit-poll-timing]')],mobile=mobile_analysis(lines,check_shas,tree_bound,predicates))
        rows.append(row)
    complete=[x for x in rows if x.get('summary',{}).get('hasFullVitestSummary')]
    subtotal={key:sum(x['summary']['finalReportedTests']['counts'][key] for x in complete) for key in ['passed','failed','skipped','todo']}
    report={'schemaVersion':1,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'One-shot read-only existing canonical evidence reconciliation; no new execution/network/polling',
            'head':HEAD,'tree':TREE,'run':RUN,'terminalSnapshot':record(terminal),'snapshotAt':data.get('at'),'runStatus':data['run']['status'],'runConclusion':data['run']['conclusion'],
            'jobCount':len(jobs),'jobConclusions':dict(Counter(x['conclusion'] for x in jobs)),'jobs':[{'id':x['id'],'name':x['name'],'status':x['status'],'conclusion':x['conclusion']} for x in jobs],
            'writerMethod':'Exactly5 main-world writer/MO setup/collection/calibration brackets. Utility7 analysis is separate, not substituted here.','mobileSource':record(args.homepage_source),'mobilePredicates':predicates,'allJobLogBindings':all_job_logs,'criticalJobs':critical_jobs,'checkoutGitObject':record(args.checkout_binding) if args.checkout_binding else None,'shards':rows,'missingLogShards':gaps,'completeSummaryShards':[x['shard'] for x in complete],
            'completeSummaryOnlyTests':subtotal,'allEightTestTotalsKnown':len(complete)==8 and not gaps,
            'incompleteSummaryShards':[x['shard'] for x in rows if not x.get('summary',{}).get('hasFullVitestSummary')],
            'deadline124Shards':[x['shard'] for x in rows if x.get('summary',{}).get('deadline124Seen')],
            'globalPassClaim':False,'disposition':'partial','reviewDecision':'ABSTAIN','limits':['Totals cover only shards with both explicit file and test summaries; never extrapolate partial file results.',
            'No old-head/arm data or dedicated workflow counts substitute for these eight ordinary shards.','No new causal classification merely because a source is unchanged or a local test passed.','Source/clock/data gaps remain explicit; public projection requires later path/privacy sanitization.']}
    out.mkdir(parents=True)
    (out/'reconciliation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    md=['# Exact98932 canonical reconciliation','',f"Run{RUN}: {report['runConclusion']}; {len(jobs)} jobs, {report['jobConclusions']}.",'','| Shard | Job conclusion | Full summary | Reported tests | Exit124 |','|---|---|---|---|---|']
    for x in rows:
        s=x.get('summary',{});md.append(f"| {x['shard']}/8 | {x['conclusion']} | {s.get('hasFullVitestSummary',False)} | {s.get('finalReportedTests',{}).get('text') if s.get('finalReportedTests') else 'unknown'} | {s.get('deadline124Seen','unknown')} |")
    md+=['',f"Complete-summary subset {report['completeSummaryShards']}: {subtotal}. All-eight totals known: {report['allEightTestTotalsKnown']}.",'','Inspect the JSON for each original file/case line, frozen mobile rejection stage/width/stack, all five main-world calibration samples and explicit writer usability reasons. A native attribute-write bracket is not full transaction success. No private utility-arm timing or historical-head counts are reused. Missing/errored/dropped/unrestored observations remain unavailable. This is partial/ABSTAIN and not an approval or all-CI pass.']
    (out/'reconciliation.md').write_text('\n'.join(md)+'\n')
    print(json.dumps({'output':str(out),'json':record(out/'reconciliation.json'),'markdown':record(out/'reconciliation.md'),'completeSubset':report['completeSummaryShards'],'tests':subtotal,'missingLogs':gaps},indent=2))
    return 2 if gaps else 0
if __name__=='__main__': raise SystemExit(main())
