(() => {
  const ownerToken = "STATIC_OWNER_TOKEN";
  const key = Symbol.for("proto-ui.test.utility-data-family-observation");
  if (Object.prototype.hasOwnProperty.call(globalThis, key))
    return { available: false, reason: 'observation-slot-already-owned' };
  const roots = document.querySelectorAll('[data-homepage-runtime]');
  if (roots.length !== 1) return { available: false, reason: 'root-not-unique', count: roots.length };
  const root = roots[0];
  const prototype = Element.prototype;
  const original = Object.getOwnPropertyDescriptor(prototype, 'getAttribute');
  if (!original || typeof original.value !== 'function')
    return { available: false, reason: 'getAttribute-data-descriptor-unavailable' };
  const native = original.value;
  const apply = Reflect.apply;
  const now = performance.now.bind(performance);
  const reads = [];
  let totalReads = 0, droppedReads = 0, observerError = false;
  function observed(...args) {
    let row;
    try {
      if (this === root && args[0] === 'data-family') {
        totalReads++;
        if (reads.length < 64) {
          row = { ordinal: totalReads, beforeMs: now() };
          reads.push(row);
        } else droppedReads++;
      }
    } catch { observerError = true; }
    try {
      const value = apply(native, this, args);
      try {
        if (row) { row.afterMs = now(); row.value = value; row.outcome = 'returned'; }
      } catch { observerError = true; }
      return value;
    } catch (error) {
      try {
        if (row) { row.afterMs = now(); row.outcome = 'threw'; row.error = String(error); }
      } catch { observerError = true; }
      throw error;
    }
  }
  const controller = {
    collectAndRestore(requestOwnerToken) {
      if (requestOwnerToken !== ownerToken ||
          Object.getOwnPropertyDescriptor(globalThis, key)?.value !== controller)
        return { unavailable: 'observation-owner-mismatch', ownerMatched: false, restored: false };
      const result = { ownerMatched: true, wrapperStillOwned: false, restored: false };
      const errorText = error => { try { return String(error); } catch { return 'diagnostic error'; } };
      try {
        Object.assign(result, { timeOrigin: performance.timeOrigin, pageMs: now(),
          totalReads, droppedReads, observerError, reads: reads.map(row => ({ ...row })),
          currentRootSame: document.querySelector('[data-homepage-runtime]') === root,
          rootConnected: root.isConnected });
      } catch (error) { result.captureError = errorText(error); }
      finally {
        try {
          result.wrapperStillOwned = Object.getOwnPropertyDescriptor(prototype, 'getAttribute')?.value === observed;
          if (result.wrapperStillOwned) {
            Object.defineProperty(prototype, 'getAttribute', original);
            const restored = Object.getOwnPropertyDescriptor(prototype, 'getAttribute');
            result.restored = restored?.value === native && restored.configurable === original.configurable &&
              restored.enumerable === original.enumerable && restored.writable === original.writable;
          }
        } catch (error) { result.restoreError = errorText(error); }
        try { if (globalThis[key] === controller) delete globalThis[key]; }
        catch (error) { result.slotCleanupError = errorText(error); }
      }
      return result;
    }
  };
  Object.defineProperty(controller, 'ownerToken', { value: ownerToken });
  Object.defineProperty(globalThis, key, { configurable: true, value: controller });
  try {
    Object.defineProperty(prototype, 'getAttribute', { ...original, value: observed });
  } catch (error) {
    if (globalThis[key] === controller) delete globalThis[key];
    return { available: false, reason: 'install-failed', error: String(error) };
  }
  return { available: true, timeOrigin: performance.timeOrigin, pageMs: now(),
    rootConnected: root.isConnected, nativeFunctionSource: Function.prototype.toString.call(native) };
})()
