(() => {
  const ownerToken = "STATIC_OWNER_TOKEN";
  const controller = Object.getOwnPropertyDescriptor(globalThis, Symbol.for("proto-ui.test.utility-data-family-observation"))?.value;
  if (!controller) return { unavailable: 'observation-slot-missing', ownerMatched: false };
  if (Object.getOwnPropertyDescriptor(controller, 'ownerToken')?.value !== ownerToken)
    return { unavailable: 'observation-owner-mismatch', ownerMatched: false };
  return controller.collectAndRestore(ownerToken);
})()
