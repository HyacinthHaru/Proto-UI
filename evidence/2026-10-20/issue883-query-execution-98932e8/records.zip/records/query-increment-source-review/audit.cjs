const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process');
const W='<PRODUCT_ROOT>';
const R='<R14>';
const O=__dirname;
const ts=require(W+'/node_modules/typescript');
const sha=v=>crypto.createHash('sha256').update(v).digest('hex');
const git=(...a)=>cp.execFileSync('git',a,{cwd:W,encoding:'utf8'});
const caller='apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts';
const helper='apps/www/src/content/docs/zh-cn/family-query-observer.ts';
const base=git('show','HEAD:'+caller), current=fs.readFileSync(W+'/'+caller,'utf8'), helperText=fs.readFileSync(W+'/'+helper,'utf8');
const v2=R+'/header-padding-fix/query-observer-proposal-v2';
const privateCaller=fs.readFileSync(v2+'/homepage.candidate.ts','utf8'),privateHelper=fs.readFileSync(v2+'/family-query-observer.ts','utf8');
const sf=(name,text,kind=ts.ScriptKind.TS)=>ts.createSourceFile(name,text,ts.ScriptTarget.Latest,true,kind);
const files=[sf('base.ts',base),sf('current.ts',current),sf('helper.ts',helperText),sf('v2-caller.ts',privateCaller),sf('v2-helper.ts',privateHelper)];
const walk=(n,f)=>{f(n);ts.forEachChild(n,c=>walk(c,f));};
function sig(n){const s=[n.kind];if(ts.isIdentifier(n)||ts.isStringLiteral(n)||ts.isNumericLiteral(n)||ts.isNoSubstitutionTemplateLiteral(n)||[ts.SyntaxKind.TemplateHead,ts.SyntaxKind.TemplateMiddle,ts.SyntaxKind.TemplateTail].includes(n.kind))s.push(n.text);ts.forEachChild(n,c=>s.push(sig(c)));return s;}
const eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b), printer=ts.createPrinter({removeComments:true});
const p=(n,f)=>printer.printNode(ts.EmitHint.Unspecified,n,f);
const failures=[];const must=(v,s)=>{if(!v)failures.push(s)};
function inspect(f){const matchers=[],cases=[];let mobile;walk(f,n=>{if(ts.isCallExpression(n)&&ts.isPropertyAccessExpression(n.expression)&&/^to[A-Z]/.test(n.expression.name.text)){const receiver=p(n.expression.expression,f);if(/^expect(?:\(|\.|\s)/.test(receiver))matchers.push({method:n.expression.name.text,args:n.arguments.map(a=>p(a,f)),receiver,node:n})}if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&n.expression.text==='it'){cases.push({title:p(n.arguments[0],f),timeout:n.arguments[2]?p(n.arguments[2],f):null});if(ts.isStringLiteral(n.arguments[0])&&n.arguments[0].text.startsWith('uses the same mobile shell'))mobile=n.getText(f);}});return{matchers,cases,mobile};}
const [b,c]=files.slice(0,2).map(inspect);
must(files.every(f=>f.parseDiagnostics.length===0),'outer TS parse');
must(eq(sig(files[1]),sig(files[3])),'formatted caller AST equals V2');
must(eq(sig(files[2]),sig(files[4])),'formatted helper AST equals V2');
must(b.matchers.length===171&&c.matchers.length===171,'171 matchers');
must(eq(b.matchers.map(({method,args})=>({method,args})),c.matchers.map(({method,args})=>({method,args}))),'matcher methods/expected args');
const changedReceivers=b.matchers.map((m,i)=>m.receiver===c.matchers[i].receiver?null:i).filter(n=>n!==null);
must(eq(changedReceivers,[143]),'only family poll receiver changes');
let removedLedger=0;
const removeLedger=ctx=>{const visit=n=>{if(ts.isTryStatement(n)&&n.tryBlock.statements[0]?.getText(files[1]).includes('familyQueryRequests.push({ request, call })')){removedLedger++;return undefined;}return ts.visitEachChild(n,visit,ctx)};return n=>ts.visitNode(n,visit);};
const reverted=ts.transform(c.matchers[143].node,[removeLedger]).transformed[0];
must(removedLedger===1&&eq(sig(reverted),sig(b.matchers[143].node)),'only original Promise bookkeeping inside changed matcher');
must(eq(b.cases,c.cases),'case names/deadlines unchanged');must(b.mobile===c.mobile,'mobile whole bytes unchanged');

const expressionRows=[];
function embedded(name){let declaration;walk(files[2],n=>{if(ts.isVariableDeclaration(n)&&ts.isIdentifier(n.name)&&n.name.text===name)declaration=n;});const init=declaration.initializer;let template=init.body;if(ts.isTaggedTemplateExpression(template))template=template.template;must(ts.isTemplateExpression(template),name+' template shape');let value=template.head.text;const substitutions=[];for(const span of template.templateSpans){const expression=p(span.expression,files[2]);substitutions.push(expression);if(expression==='JSON.stringify(ownerToken)')value+='"STATIC_OWNER_TOKEN"';else if(expression==='JSON.stringify(slotName)')value+='"proto-ui.test.utility-data-family-observation"';else throw new Error('Unknown template input '+expression);value+=span.literal.text;}return{value,substitutions};}
for(const name of ['installExpression','collectExpression']){
 const {value,substitutions}=embedded(name),filename='/'+name+'.js',file=sf(filename,value,ts.ScriptKind.JS);
 const host=ts.createCompilerHost({allowJs:true,noLib:true,noResolve:true});host.getSourceFile=(p)=>p===filename?file:undefined;host.fileExists=p=>p===filename;host.readFile=p=>p===filename?value:undefined;host.writeFile=()=>{};
 const program=ts.createProgram([filename],{allowJs:true,noLib:true,noResolve:true,noEmit:true},host),checker=program.getTypeChecker();
 const unbound=new Set();
 walk(file,n=>{if(!ts.isIdentifier(n))return;const q=n.parent;
  if((ts.isPropertyAccessExpression(q)&&q.name===n)||((ts.isPropertyAssignment(q)||ts.isMethodDeclaration(q)||ts.isPropertyDeclaration(q))&&q.name===n)||((ts.isVariableDeclaration(q)||ts.isParameter(q)||ts.isFunctionDeclaration(q)||ts.isFunctionExpression(q)||ts.isBindingElement(q))&&q.name===n))return;
  const symbol=ts.isShorthandPropertyAssignment(q)?checker.getShorthandAssignmentValueSymbol(q):checker.getSymbolAtLocation(n);
  if(!symbol)unbound.add(n.text);
 });
 const expectedGlobals=new Set(['Object','Symbol','globalThis','document','Element','Reflect','performance','String','Function','undefined']);
 const unknown=[...unbound].filter(x=>!expectedGlobals.has(x));
 const row={name,sha256:sha(value),substitutions,parseDiagnostics:file.parseDiagnostics.length,unboundGlobals:[...unbound].sort(),unknownReferences:unknown,selfContained:unknown.length===0};
 expressionRows.push(row);must(file.parseDiagnostics.length===0&&unknown.length===0,name+' browser expression parse/self-contained');
 fs.writeFileSync(O+'/'+name+'.js',value+'\n');
}
const stablePaths=['packages/adapters/base/src/events/web-event-router.ts','packages/adapters/base/test/event-router-work.test.ts'];
const stable=stablePaths.map(p=>{const actual=fs.readFileSync(W+'/'+p),head=cp.execFileSync('git',['show','HEAD:'+p],{cwd:W});return{path:p,workingSHA256:sha(actual),headSHA256:sha(head),exact:actual.equals(head)};});
must(stable.every(x=>x.exact),'router and17 owner tests same HEAD');
const ownerSF=sf('owner.ts',fs.readFileSync(W+'/'+stablePaths[1],'utf8'));let ownerCases=0;
walk(ownerSF,n=>{if(!ts.isCallExpression(n))return;if(ts.isIdentifier(n.expression)&&n.expression.text==='it')ownerCases++;else if(ts.isCallExpression(n.expression)&&ts.isPropertyAccessExpression(n.expression.expression)&&n.expression.expression.expression.getText(ownerSF)==='it'&&n.expression.expression.name.text==='each'&&ts.isArrayLiteralExpression(n.expression.arguments[0]))ownerCases+=n.expression.arguments[0].elements.length;});must(ownerCases===17,'17 expanded owner cases preserved');
const park=JSON.parse(fs.readFileSync(R+'/header-padding-fix/parked-header-candidate/park-receipt.json','utf8'));
const parked=park.files.map(x=>({path:x.path,currentRestoredToHEAD:sha(fs.readFileSync(W+'/'+x.path))===x.baselineSha256,parkedCandidateSHAExact:sha(fs.readFileSync(R+'/header-padding-fix/parked-header-candidate/'+x.path))===x.candidateSha256}));must(parked.every(x=>x.currentRestoredToHEAD&&x.parkedCandidateSHAExact),'Header candidates retained/restored');
const ownerPrior=JSON.parse(fs.readFileSync(R+'/postcommit-node129/vitest.json','utf8')).testResults.find(x=>x.name.endsWith('/'+stablePaths[1]));
const result={at:new Date().toISOString(),kind:'Read-only static source binding. No tests, browser, downloads or worktree changes.',mode:'human-assisted/current-user',assessment:'unassessed',disposition:'partial/ABSTAIN',formalApproval:false,authorParticipation:'This agent prepared the V2 candidate; this is a peer final source audit, not a fresh formal independent technical approval.',head:git('rev-parse','HEAD').trim(),tree:git('rev-parse','HEAD^{tree}').trim(),dirty:git('status','--short'),source:[{path:caller,sha256:sha(current),baseSHA256:sha(base),v2SHA256:sha(privateCaller)},{path:helper,sha256:sha(helperText),v2SHA256:sha(privateHelper)}],formatting:{callerASTEqualsV2:eq(sig(files[1]),sig(files[3])),helperASTEqualsV2:eq(sig(files[2]),sig(files[4])),parseDiagnostics:files.map(f=>f.parseDiagnostics.length)},preservation:{matcherCounts:[b.matchers.length,c.matchers.length],matcherMethodsExpectedArgumentsExact:true,changedReceiverIndexes:changedReceivers,changedReceiverIsOnlyDeclaredLedger:removedLedger===1&&eq(sig(reverted),sig(b.matchers[143].node)),caseNamesDeadlines:b.cases,caseNamesDeadlinesExact:eq(b.cases,c.cases),mobileWholeBytesExact:b.mobile===c.mobile,originalTimedSegmentByteIdentical:false,modePolicy:'All modes retain original Node observations and actual Promise ledger. Hybrid adds writer/MO and utility; native-only retains writer/MO without utility; node-only disables both DOM observations.'},browserExpressions:expressionRows,routerAndOwnerControls:{files:stable,expandedCaseCount:ownerCases,priorExecutionReference:{path:R+'/postcommit-node129/vitest.json',sha256:sha(fs.readFileSync(R+'/postcommit-node129/vitest.json')),pass:ownerPrior?.assertionResults.filter(x=>x.status==='passed').length,failed:ownerPrior?.assertionResults.filter(x=>x.status==='failed').length,scope:'Historical exact2189 source execution; no new owner17 execution by this audit.'}},parkedHeaderCandidates:parked,lateSettlement:{sourceOrder:['original poll query Promise and original return remain; only reference ledger inserted','original fulfilled/rejected outcome and rejection snapshot freeze before wait','uncapped actual Promise reference ledger drained with allSettled; displayed records cap64 only','own-token collection/restoration after registered requests settle','incomplete ledger defers cleanup until original context closure'],limits:['The original matcher1000ms remains unchanged; owning180000ms case budget still bounds work. A hanging original request can consume post-verdict cleanup time and leave capture incomplete.','Ledger wait observes already-issued requests; future unissued Vitest retries are not awaited or cancelled. issuedAfterDrain makes coverage false; no promise of forever-quiescent getter activity.','Local three-mode original-Brutalist controls were all positive with pendingAtVerdict0. They do not execute the timeout+pending branch.','Protocol has no query call ID pairing. Same-arm count,order,value,noextra reads,root/context/origin,drop/error/restore conditions are required before conditional clock correspondence.','No inference of pure network/pure browser queue time or timing-neutral instrumentation.','This audit does not claim the currently root-owned native120 run has passed.']},findings:[],staticFailures:failures};
if(failures.length)result.findings=failures.map(x=>({id:'STATIC-BINDING-CHECK',message:x}));
fs.writeFileSync(O+'/report.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({source:result.source,matcherCounts:result.preservation.matcherCounts,formatting:result.formatting,expressionRows,ownerCases,findings:result.findings},null,2));if(failures.length)process.exitCode=1;
