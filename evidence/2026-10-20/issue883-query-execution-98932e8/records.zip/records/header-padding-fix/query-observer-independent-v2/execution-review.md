V2 ownership 两个真实 Chrome 控制通过：busy 第二 observer 未恢复第一份 hook；真实安装后人为丢 ACK 的控制仍用自己 token 恢复原 descriptor，并保持 available/usable=false。原 native 函数身份/flags、context/browser cleanup 均对账。此前 named-import 与 TDZ 两次失败均在控制执行前，保留为0执行。

原 Brutalist journey 的实际顺序是 hybrid→native-only→node-only，各1 pass/8 filtered，源码 b402、helper b5c6 前后稳定。原 poll 分别396.332292、405.682750、399.581083 ms fulfilled；三次 verdict 都0pending，所以没有实际覆盖 timeout后pending-drain路径。React hreflang warning继续保留。

Hybrid实际2条utility读对2条Node读。按原五个writer/MO时钟括号交集[8290.124041,8290.548916] ms，第一查询开始到getter条件区间111.186666–111.611541 ms，getter后到Node返回0.210625–0.635500 ms；第二为232.487541–232.912416 ms及0.234709–0.659584 ms。加入同次utility install/collect两括号可进一步收窄交集，上述较宽五括号算术没有错误。两个getter前后tick相同不能称耗时0。

这些只是本地有观测候选的条件分段：无protocol call ID，依赖无额外匹配读、相同root/realm以及稳定等速时钟。前段不等于纯浏览器排队，后段不等于纯网络。不能回填旧2189/Linux红或声称productionfix；静态异常透传也不冒充实际throw控制。结论0新增finding、partial/ABSTAIN，不是GitHub批准。
