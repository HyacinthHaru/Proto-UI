V2 helper b5c6eca5… 对 R14-QUERY-OBSERVER-OWNER-001 的静态修正成立。collect 在调用 controller 前检查本次随机 owner token，controller 再核 token 与全局同对象；碰到已有 slot 的第二 observer 无权恢复第一份 hook。未知 install ACK 仍可凭自己的 token 尝试恢复，失败 ACK 不会被重写为可用采样。

原 observed getter 函数字节完全未变，仍恰好一次 Reflect.apply，返回值和原异常对象优先。Homepage caller 仍为已审 b402c5a0…；171 matcher/76 input 与原 Promise 交付、判定前后边界继承前次静态核对。

本报告 0 open static findings，partial/ABSTAIN；实际双 observer、丢 ACK 与三模式控制尚不在本报告的执行范围。allSettled 只排空已登记请求，后置采样延后、未来 retry 和无 protocol call ID 的限制继续适用。未运行或批准测试，未修改工作树。
