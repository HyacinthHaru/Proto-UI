本轮只读审查保留 1 个具体 finding：R14-QUERY-OBSERVER-OWNER-001。helper 3d6f57… 在 observation-slot-already-owned 时拒绝安装，但 Node 侧仍保留 chosen/session，随后 collectExpression 仅凭全局 Symbol 调用原 controller，会错误收集并恢复另一 observer 的 hook。需要按每次尝试的 owner token 约束远端 collect/restore，同时允许未知安装响应时用同一 token 回收自己；不能只靠 available 布尔值。

实际静态校验绑定读取期间更新的 homepage b402c5a0…、helper 3d6f57…、patch bb2f6ffd…；初始 22e/b408 并未被重标。171 个 matcher 方法与参数、76 个输入调用及顺序、case 名称和 deadline、整段 mobile case 均保持。原 getter 表达式及原 Promise 返回保持；critical block 新增 ledger，不能称逐字不变。移除该唯一新增段后才与原 critical bytes 完全相同。

原 reject 时刻和 snapshot 先冻结，再等待已登记的真实 Promise。原生 getter 的返回/原异常对象在审阅函数中优先于日志失败。Vitest 2.1.9 的在途检查仍可能在 timeout 后安排后续 retry，因此 allSettled 只能证明排空当时已登记请求；它不是取消或未来完整性的证明。失败后的 DOM/PNG 会因等待而推后，应标后置采样；外层 test timeout 等异常终止仍可能限制收集。

三模式都是有观测开销的控制。hybrid 选取真实已有 main-frame utility context，未新建 world；其计数依赖 exact root/data-family，不能以无 capture 反证 getter 未执行。Node/utility 配对无 protocol call ID，必须保留无额外同类读取、同 context、同臂时钟区间等条件。

结论 partial/ABSTAIN，V1 ownership finding 未关闭；未 apply、执行测试/浏览器、改工作树或外部写入，也不构成 GitHub approval。
