import assert from 'node:assert/strict';
import { randomUUID, createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { launchBrowser } from '<PRODUCT_ROOT>/apps/www/src/content/docs/zh-cn/browser-harness.ts';
import { prepareUtilityFamilyReadObservation } from '../query-observer-proposal-v2/family-query-observer.ts';

// Private diagnostic-helper controls. No application or original Homepage acceptance claim.
const worktree = '<PRODUCT_ROOT>';
const output = process.argv[2];
if (!output || !path.isAbsolute(output)) throw new Error('Provide a fresh absolute output directory.');
await mkdir(output, { recursive: false });
const self = fileURLToPath(import.meta.url);
const helper = fileURLToPath(new URL('../query-observer-proposal-v2/family-query-observer.ts', import.meta.url));
const harness = path.join(worktree, 'apps/www/src/content/docs/zh-cn/browser-harness.ts');
const digest = async (file: string) => createHash('sha256').update(await readFile(file)).digest('hex');
const binding = async () => ({
  head: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: worktree, encoding: 'utf8' }).trim(),
  tree: execFileSync('git', ['rev-parse', 'HEAD^{tree}'], { cwd: worktree, encoding: 'utf8' }).trim(),
  dirty: execFileSync('git', ['status', '--short'], { cwd: worktree, encoding: 'utf8' }),
  sources: Object.fromEntries(await Promise.all([self, helper, harness].map(async p => [p, await digest(p)]))),
});
const report: any = {
  startedAt: new Date().toISOString(), node: process.version,
  scope: 'Real Chromium, private DOM fixture, existing browser harness, unchanged V2 helper. Not a Homepage or C behavior acceptance run.',
  before: await binding(), controls: [], errors: [], browserClosed: false,
};
const errorText = (e: unknown) => { try { return String(e); } catch { return 'unstringifiable error'; } };
let browser: Awaited<ReturnType<typeof launchBrowser>> | undefined;

async function runControl(kind: 'busy-owner' | 'lost-install-ack') {
  const row: any = { kind, startedAt: new Date().toISOString(), passed: false, pageErrors: [], cleanupErrors: [] };
  report.controls.push(row);
  const context = await browser!.newContext({ viewport: { width: 800, height: 600 } });
  const page = await context.newPage();
  page.setDefaultTimeout(10_000);
  page.on('pageerror', e => row.pageErrors.push(e.message));
  const observers: Awaited<ReturnType<typeof prepareUtilityFamilyReadObservation>>[] = [];
  const restoreNodeMethods: Array<() => void> = [];
  let audit: any;
  let selected: any;
  const auditKey = `proto-ui.private.utility-descriptor-control.${randomUUID()}`;
  async function evaluate(expression: string) {
    const result = await audit.send('Runtime.evaluate', {
      expression, uniqueContextId: selected.uniqueId, returnByValue: true, silent: true,
    });
    assert.equal(result.exceptionDetails, undefined, 'Descriptor audit must use the selected live utility realm');
    return result.result.value;
  }
  const inspectExpression = `(() => {
    const original = globalThis[Symbol.for(${JSON.stringify(auditKey)})];
    const current = Object.getOwnPropertyDescriptor(Element.prototype, 'getAttribute');
    return { descriptorStored: !!original,
      sameFunction: !!original && current?.value === original.value,
      sameFlags: !!original && current?.configurable === original.configurable &&
        current?.enumerable === original.enumerable && current?.writable === original.writable,
      nativeSource: current && Function.prototype.toString.call(current.value) };
  })()`;
  try {
    await page.setContent('<!doctype html><main data-homepage-runtime data-family="shadcn">Private query ownership control</main>');
    // An ordinary locator read establishes the real Playwright utility context.
    row.initialValue = await page.locator('[data-homepage-runtime]').getAttribute('data-family');
    assert.equal(row.initialValue, 'shadcn');
    audit = await context.newCDPSession(page);
    const contexts: any[] = [];
    audit.on('Runtime.executionContextCreated', ({ context: c }: any) => contexts.push(c));
    await audit.send('Runtime.enable');
    const { frameTree } = await audit.send('Page.getFrameTree');
    const matches = contexts.filter(c => c.auxData?.frameId === frameTree.frame.id && c.auxData?.isDefault === false &&
      c.name.startsWith('__playwright_utility_world_') && typeof c.uniqueId === 'string');
    assert.equal(matches.length, 1, 'Exactly one actual main-frame utility context is required');
    selected = matches[0];
    row.frame = frameTree.frame;
    row.selectedContext = selected;
    row.originalDescriptor = await evaluate(`(() => {
      const key = Symbol.for(${JSON.stringify(auditKey)});
      if (Object.prototype.hasOwnProperty.call(globalThis, key)) throw new Error('Audit descriptor slot already owned');
      const value = Object.getOwnPropertyDescriptor(Element.prototype, 'getAttribute');
      Object.defineProperty(globalThis, key, { configurable: true, value });
      return { nativeSource: Function.prototype.toString.call(value.value),
        configurable: value.configurable, enumerable: value.enumerable, writable: value.writable };
    })()`);

    if (kind === 'busy-owner') {
      const first = await prepareUtilityFamilyReadObservation(page);
      observers.push(first);
      assert.equal(first.report.available, true);
      assert.equal(first.report.selectedContext.uniqueId, selected.uniqueId);
      row.afterFirstInstall = await evaluate(inspectExpression);
      assert.equal(row.afterFirstInstall.sameFunction, false);
      const second = await prepareUtilityFamilyReadObservation(page);
      observers.push(second);
      assert.equal(second.report.available, false);
      assert.equal(second.report.install.facts.reason, 'observation-slot-already-owned');
      assert.equal(second.report.selectedContext.uniqueId, selected.uniqueId);
      row.second = await second.collectAndRestore();
      assert.equal(row.second.collection.facts.ownerMatched, false);
      assert.equal(row.second.collection.facts.unavailable, 'observation-owner-mismatch');
      assert.equal(row.second.detached, true);
      row.afterSecondCollect = await evaluate(inspectExpression);
      assert.equal(row.afterSecondCollect.sameFunction, false, 'Second collection must leave first wrapper installed');
      row.value = await page.locator('[data-homepage-runtime]').getAttribute('data-family');
      row.first = await first.collectAndRestore();
      assert.equal(row.value, 'shadcn');
      assert.equal(row.first.collection.facts.totalReads, 1);
      assert.equal(row.first.collection.facts.reads[0].value, row.value);
      assert.equal(row.first.collection.facts.ownerMatched, true);
      assert.equal(row.first.collection.facts.wrapperStillOwned, true);
      assert.equal(row.first.collection.facts.restored, true);
      assert.equal(row.first.detached, true);
      assert.equal(row.first.usable, true);
    } else {
      // Control transport only: forward a real install, then suppress its successful response.
      // The helper source and all browser-side install/collect expressions remain unchanged.
      const ownNewSession = Object.getOwnPropertyDescriptor(context, 'newCDPSession');
      const nativeNewSession = context.newCDPSession;
      let suppressed = 0;
      Object.defineProperty(context, 'newCDPSession', { configurable: true, writable: true,
        value: async (...args: any[]) => {
          const session: any = await Reflect.apply(nativeNewSession, context, args);
          const ownSend = Object.getOwnPropertyDescriptor(session, 'send');
          const nativeSend = session.send;
          Object.defineProperty(session, 'send', { configurable: true, writable: true,
            value: async (method: string, params: any) => {
              const result = await Reflect.apply(nativeSend, session, [method, params]);
              if (method === 'Runtime.evaluate' && params?.expression?.includes("Object.defineProperty(controller, 'ownerToken'") && suppressed === 0) {
                suppressed++;
                row.suppressedInstallResponse = { actualAvailable: result.result.value?.available,
                  actualExceptionDetails: result.exceptionDetails ?? null, uniqueContextId: params.uniqueContextId };
                throw new Error('PRIVATE_CONTROL_INSTALL_ACK_SUPPRESSED_AFTER_REAL_COMPLETION');
              }
              return result;
            },
          });
          restoreNodeMethods.push(() => {
            if (ownSend) Object.defineProperty(session, 'send', ownSend);
            else delete session.send;
          });
          return session;
        },
      });
      restoreNodeMethods.push(() => {
        if (ownNewSession) Object.defineProperty(context, 'newCDPSession', ownNewSession);
        else delete (context as any).newCDPSession;
      });
      const observer = await prepareUtilityFamilyReadObservation(page);
      observers.push(observer);
      while (restoreNodeMethods.length) restoreNodeMethods.pop()!();
      row.nodeTransportMethodsRestored = true;
      assert.equal(suppressed, 1);
      assert.equal(row.suppressedInstallResponse.actualAvailable, true);
      assert.equal(row.suppressedInstallResponse.actualExceptionDetails, null);
      assert.equal(row.suppressedInstallResponse.uniqueContextId, selected.uniqueId);
      assert.equal(observer.report.available, false, 'Helper did not receive the successful install acknowledgment');
      assert.equal(observer.report.selectedContext.uniqueId, selected.uniqueId);
      row.afterLostAck = await evaluate(inspectExpression);
      assert.equal(row.afterLostAck.sameFunction, false, 'Actual install still owns a wrapper despite lost acknowledgment');
      row.value = await page.locator('[data-homepage-runtime]').getAttribute('data-family');
      row.observer = await observer.collectAndRestore();
      assert.equal(row.value, 'shadcn');
      assert.equal(row.observer.collection.facts.ownerMatched, true);
      assert.equal(row.observer.collection.facts.totalReads, 1);
      assert.equal(row.observer.collection.facts.reads[0].value, row.value);
      assert.equal(row.observer.collection.facts.wrapperStillOwned, true);
      assert.equal(row.observer.collection.facts.restored, true);
      assert.equal(row.observer.detached, true);
      assert.equal(row.observer.usable, false, 'Lost-ack setup error must not be relabelled usable capture');
      assert.equal(row.observer.errors.filter((e: any) => e.phase === 'setup' && e.error.includes('PRIVATE_CONTROL_INSTALL_ACK_SUPPRESSED')).length, 1);
    }
    row.finalDescriptor = await evaluate(inspectExpression);
    assert.equal(row.finalDescriptor.sameFunction, true, 'Same realm native getter identity restored');
    assert.equal(row.finalDescriptor.sameFlags, true, 'Same realm descriptor flags restored');
    assert.deepEqual(row.pageErrors, []);
    row.passed = true;
  } catch (error) {
    row.error = errorText(error);
    throw error;
  } finally {
    while (restoreNodeMethods.length) {
      try { restoreNodeMethods.pop()!(); } catch (e) { row.cleanupErrors.push({ phase: 'node-transport', error: errorText(e) }); }
    }
    for (const observer of observers.reverse()) {
      try { await observer.collectAndRestore(); } catch (e) { row.cleanupErrors.push({ phase: 'helper', error: errorText(e) }); }
    }
    if (audit) {
      if (selected) try { await evaluate(`delete globalThis[Symbol.for(${JSON.stringify(auditKey)})]`); }
      catch (e) { row.cleanupErrors.push({ phase: 'audit-slot', error: errorText(e) }); }
      try { await audit.detach(); row.auditDetached = true; }
      catch (e) { row.cleanupErrors.push({ phase: 'audit-detach', error: errorText(e) }); }
    }
    try { await context.close(); row.contextClosed = true; }
    catch (e) { row.cleanupErrors.push({ phase: 'context-close', error: errorText(e) }); }
    row.finishedAt = new Date().toISOString();
    if (row.cleanupErrors.length) row.passed = false;
    await writeFile(path.join(output, `${kind}.json`), JSON.stringify(row, null, 2));
  }
}
try {
  browser = await launchBrowser();
  report.browser = browser.version();
  for (const kind of ['busy-owner', 'lost-install-ack'] as const) {
    try { await runControl(kind); } catch (e) { report.errors.push({ kind, error: errorText(e) }); }
  }
} catch (error) { report.errors.push({ phase: 'launch', error: errorText(error) }); }
finally {
  if (browser) try { await browser.close(); report.browserClosed = true; }
  catch (e) { report.errors.push({ phase: 'browser-close', error: errorText(e) }); }
  report.after = await binding();
  report.finishedAt = new Date().toISOString();
  report.sourceStable = JSON.stringify(report.before) === JSON.stringify(report.after);
  report.passed = report.controls.length === 2 && report.controls.every((row: any) => row.passed) &&
    report.errors.length === 0 && report.browserClosed && report.sourceStable;
  await writeFile(path.join(output, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ output, passed: report.passed, controls: report.controls.map((row: any) => ({ kind: row.kind, passed: row.passed })) }));
  if (!report.passed) process.exitCode = 1;
}
