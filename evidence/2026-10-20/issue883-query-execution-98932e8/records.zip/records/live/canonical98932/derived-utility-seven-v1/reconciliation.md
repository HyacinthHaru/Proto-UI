# Exact98932 utility7 observation

Original rejection +1000.939018ms; pending at verdict 1. All7 conditional offset intersection [116110.422785, 116111.31928900002]ms. Third observed getter +[1104.8137949999825, 1105.7102990000058]ms; original Node return +1106.093828ms. Post-verdict wait 104.897409ms. Original result remains rejected.

All5 writer samples remain separately reported; both methods happen to have the same intersection here. No subset substitution, protocol-ID claim, pure queue/network partition, old-head inference or overall approval. The indefinitely unsettled-request cleanup gap is not closed by this finite drain. See JSON for raw objects, independentconditions and everybracket.
