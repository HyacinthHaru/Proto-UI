# Minimal failure-only plan

Prepare only one original mobile-shell case. Keep both original poll closures/matchers, all three width iterations, inputs, geometry/focus expectations and90s deadline unchanged. Add Node stage/width assignments around the existing steps; resetting the stage after each poll prevents a later ordinary assertion from being labelled as a poll failure.

At the original rejection, persist the stage, width, source/test identity, original error/stack/cause and Node times before any additional browser RPC. Any capture error is separate and cannot replace the original error. The original context-close finally remains intact. Optionally follow with one bounded read of public Header/menu/Contents/generation/activeElement state, recording its own request/return times. No observer, extra input, setter, poll, retry, forced click or timeout change is needed to identify which poll failed.

A late-ready snapshot cannot establish readiness before the deadline. If the first poll fails, distinguish initialization/marker publication from protocol response timing. If the second fails, distinguish command activation/current generation from app mutual-exclusion delivery. A local positive does not close the Linux red. Failed snapshot transport is retained as missing evidence.

This plan is not applied or executed. Root owns any next run. CLI needs an explicit recipient ACK through the already-delivered902/890 routing and a real owner repair, not another unchanged isolated run or a repeated message.
