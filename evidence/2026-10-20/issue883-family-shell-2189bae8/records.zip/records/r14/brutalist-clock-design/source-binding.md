Source binding — Brutalist clock design

Current clean source: `de2272060fd47cd5b37991e4f7a049c254beabda`, tree `3db4ccee88a9df35c4b71633f0792f6ca0c6b2b0`. This is a read-only binding; no candidate implementation or execution is claimed.

| Source | SHA256 |
| --- | --- |
| apps/www/src/components/Homepage/homepage-runtime-client.ts | `7a12e6617e41fa569e22bb08cf6f54a469890df24a66816e65931ee2abbafdb2` |
| apps/www/src/components/PrototypePreviewer/projection-scope.ts | `9d0fc44ed3ea0655d53099a47699e1c4f6ab367ef3005bd5c6719b1d3f5936f1` |
| apps/www/src/components/site-library-family.ts | `17fcefcdf85abc148f0b8fd94e66200403790f903a1beae310658d84571cad01` |
| apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts | `3f9f491dcaa2466308a886c0bd28a553443ee76bc1bf4eb4412b9b1bf81df8f4` |
| apps/www/src/content/docs/zh-cn/browser-harness.ts | `e3792a3e0003b79385c3aae90b08728c51d7564bf1abd16a32a47ff9f37fca9d` |
| packages/adapters/base/src/events/web-event-router.ts | `921f1fe504efe7fed8a549a6a16d0eb3398b5381985260cbc72b0c36462b4d5e` |
| packages/adapters/base/test/event-router-work.test.ts | `521fb46243202f84204a36c9259959d91c3ee7eb293df39053cfbd8b5555326d` |
| spec/decisions/D-HOST-PROTOTYPE-PROJECTION-SCOPE-0001.yaml | `ce4279bd7373fde1d0986ef870328e2279d494df1a6a88cbce427c4eff20f4bb` |
| spec/tests/T-HOST-PROTOTYPE-PROJECTION-SCOPE-0001.yaml | `50f71d5f030787287e561d208231ca440c95ff100e1db3e3d04c2b03a12eadec` |
| internal/records/2026-10-05-homepage-runtime-preference-intent.md | `53c96cc59d69c13d72996058aa0b390530c6a1102879daa98269864eee64edff` |
| internal/records/2026-10-05-passive-shell-theme-transaction.md | `a858329d8125d026ec318f6c64ac0c24b16f05e1851ff0f4473f4c528acfd763` |
| node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core/package.json | `16a25dbd7368a87af8b58a45c6216b9cec5a91a72cf704533344701997ebde22` |
| node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core/lib/client/locator.js | `9c4fa569fd160b2f5a3204615967499f925deca68fc6846af13e0cdbfde87135` |
| node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core/lib/client/frame.js | `f3eeec1734312b518d488763365f7b3f877284bf92c01edc267bdbb1648ef8c7` |
| node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core/lib/client/page.js | `409b11561b319e8dfb4d1ec3f8b126fb32ab19e894fae529edbeae57c056ae84` |
| node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core/lib/server/frames.js | `fa67e7a3755a79cf0e0ac96b6930987ec2bcc643f60735c6ec748066f7c3e16b` |
| node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core/lib/server/frameSelectors.js | `e78a076ee10ebd6127e092229b70201603ded190322e4d76e6f0cdcbb2517723` |
| node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core/lib/server/selectors.js | `b2edcf2a1cf2a04e82de47df2e1e5807c7342f38516a4c963afff0194a54b897` |
| node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core/lib/server/chromium/crPage.js | `08f14f9abc4bde5b36a0679889de05e8c3c0ebbf7e15c3bafc3639830e01c174` |
| node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core/lib/server/dispatchers/frameDispatcher.js | `59c3fd3d39f0dfe8424c50810d035cf74ad44d845d143b7ca7dbcd6d5ead6096` |
| node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core/types/types.d.ts | `af3c4dcb64b945e01285bc0494e1cfa384fac43b08713a56fc3043c8f861553a` |
| node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core/types/protocol.d.ts | `99a323dc5a6e506c78b69913b32beba93453bcd87aae8b507520234f387a4c30` |
| node_modules/.pnpm/vitest@2.1.9_@types+node@25.6.2_happy-dom@15.11.7_lightningcss@1.32.0/node_modules/vitest/dist/chunks/vi.DgezovHB.js | `b196854dc043716fc0fe066c45e3de657f402dbe64f3c012f4a134b90d305fde` |

The original Node timed-poll block is 1185 bytes, SHA256 `7fd2509a68c405ec0f329ed102181b161e7f38ffee4cfbe7cded2542626bd675`. It contains one timed getAttribute expression and returns that same request Promise. The current browser test is byte-identical to the earlier171-matcher static audit; the current total is313 awaits, not the original308.

The17keyboard-owner source file and router implementation are included above as preservation inputs; this review did not rerun them. Maintainer6271132955 is read from the cached complete comments snapshot, not treated as independent execution or formal approval.
