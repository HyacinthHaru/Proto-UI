Canonical2189 terminal and hosted clock addendum

**0 specific source/count/arithmetic discrepancies; partial / ABSTAIN.** Current functional failures remain. No tests, browser runs, downloads, Actions mutations, product edits, external writes or new pixel reviews were performed.

Canonical run39346804518 completedFAILURE: **22jobs13success/9failure**. Raw job checkouts identify `b09e8ad66790860a8d01ed5d9a919d221f04ed80`; the retained Git API object binds its tree to `c357d6efd0146c5846d1493f4db188dd8eaaaceb`, exactly the PR head2189tree. Its parents are main042f and2189. No synthetic checkout SHA is rewritten as the PR head.

|Shard|Job|Complete test result|
|---|---|---|
|1|118383991551|216 pass / 24 fail / 0 skip|
|2|118383991435|exit124; no full summary|
|3|118383991501|58 pass / 3 fail / 0 skip|
|4|118383992313|122 pass / 2 fail / 0 skip|
|5|118383991421|88 pass / 2 fail / 15 skip|
|6|118383991470|169 pass / 0 fail / 0 skip|
|7|118383991398|113 pass / 1 fail / 0 skip|
|8|118383991523|exit124; no full summary|

Only shards1/3/4/5/6/7 total **766pass/32fail/15skip**. Shards2/8 exit124 without full summaries. No all-eight total is known. In incomplete shard2, Homepage itself reports **8pass/1fail**: original Brutalist familycommit fails; the mobile documentation-shell case explicitly passes.

For job118383991435, the stdout timing object matches the root parse and the existing artifact's failure/lifecycle JSONs field-for-field. All three extra calibration samples are present; all five browser origins agree; root/connection agree; Proxy restoration is true; observererrors/drops are clear. Using every raw interval gives conditional Node-minus-page offset **[103799.953950,103805.082677]ms**, width5.128727ms.

|Event|Node-relative recorded/conditional time|
|---|---:|
|Query1 returns shadcn|7.685184ms|
|Query2 returns shadcn|335.770214ms|
|Query3 starts|386.309502ms|
|Native family attribute-write bracket|757.861917–763.090644ms|
|MO callback delivery|888.961917–894.090644ms|
|Original poll rejection observed|1000.532239ms|
|Same query3 returns brutalist|1082.459065ms|

The third request is still unresolved in the frozen rejection snapshot and returns **81.926826ms after rejection**. Under the documented same-document/stable-relative-clock assumptions, this instrumented attribute write and MOdelivery fall before the nominal1000ms deadline. That is narrower evidence than the historicalDE straddling interval. It does **not** make the original matcher pass or prove that the full family transaction/ready/publication sequence completed within the deadline.

The native write bracket and MOdelivery are distinct; their reported same-browser separation is131ms. There is no utility getter timestamp in this hosted default run. Its remaining query interval cannot be called pure browser queue or pure network, and privatearm3's different local getter measurements cannot be imported. Timerquantization, drift and instrumentationoverhead have no independently measured bound; decimal precision does not supply one. The later generation2ready capture remains post-rejection, after extra collection/calibration RPCs.

Mobile logs have all12stages for390→430→320 and an explicitpass line. Menu-readypoll-to-followingstage intervals are811.177694,574.519143,636.807775ms; navigation-close-to-followingstage intervals are2.500855,3.298566,2.310150ms. These are adjacent Node observations, not browser mutation timestamps. No new rejection exists from which to diagnose the older mobile failure.

The already retained artifact12232795304 is58,721,962bytes, SHA256 `317e491a679590935e852e5bfc0e774c7e13a528a90feb838557453ac7ac4396`,230members. This audit rechecked its whole-file SHA and read only the sourceSHA plus two timing JSON members through ZIP CRC checking. Root's separate inventory records allmemberCRC/hash checking; this audit does not claim to have repeated that or viewed the PNG. SourceSHA and all selected timing objects agree with the raw log and exact checkout.

HistoricalDD/DE and precommit/privatearm reports remain unchanged. The clean2189 local120/0 result also remains separate from this hosted8/1Homepage file and globally failedCI. This addendum does not provide formal approval, complete C acceptance or a new production repair.
