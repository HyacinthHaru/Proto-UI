Final2189 source and execution binding

**0 specific source/count finding; partial / ABSTAIN.** This is a read-only peer audit. No tests, browser runs, downloads, product edits, GitHub writes or new image views were performed.

Exact commit `2189bae8f3e39ed9708f79576f6bc6b0c6660192` has tree `c357d6efd0146c5846d1493f4db188dd8eaaaceb` and parent `de2272060fd47cd5b37991e4f7a049c254beabda`. The working tree is clean. The sole changed file is `homepage-dogfood.browser.test.ts`,171 additions/0 deletions, SHA256 `e97adac9e292cb11e5ff8a104b4a554c5d158283cba476c34d9ad79ab55dbff9`, exactly equal to reviewed arm2. Both trees contain11330 tracked blobs: **one changed and11329 other mode/kind/blob entries strictly unchanged**. Production code, dependencies, lockfiles and Dialog keeper are unchanged. SSH signature verifies G; Author/Committer are HyacinthHaru with the allowed email, one DCO and no coauthor. Root's retained normal-push receipt binds remote and PR head to2189 at00:17:54UTC; this audit made no new remote query.

The prior static proof applies by exact committed bytes: original171 matcher methods/receivers/arguments, names/deadlines, original mobile control-body AST and two polls, and the option-click through poll-finish bytes are preserved. Original17-owner/router inputs remain exact DE bytes. R14-WRITER-OBSERVER-THROW-001 remains closed in arm2 source, without claiming a forced native exception branch ran.

Clean postcommit Node129 ran **2026-10-20 00:19:45.851–00:20:16.985UTC**, Node24.21.0,max2/min1: **1803pass/4fail/0pending**, exit1. All1807 file+case identities and verdicts match the previous DE129 run. The same four CheckboxGroup authored-token assertions remain; keyboard-owner17/17 and Dialog2/2 pass. This neither produces an all-green result nor reopens/expands the already accepted Dialog fixture evidence scope.

Clean postcommit native ran **00:21:05.227–00:22:43.933UTC**,max1/min1: **Shadow111 + Homepage9 =120/120**, exit0. The test-owned server and all58 sidecar source records identify clean2189. The48 captures are not new visual acceptance in this audit. Page/ring failures are empty in the family records; the existing React hreflang warning and initial connection-refused server-readiness attempts remain visible. Both postcommit receipts' `sourceInputs` maps are empty: `sourceInputsStable=true` must not be described as a full loaded-input/metafile census.

The new Brutalist stdout and lifecycle timing objects are identical. Original poll fulfillment is **392.358083ms**. Its same query returns are shadcn at2.623458ms, shadcn at121.748041ms and brutalist at392.329250ms. All three post-verdict calibrations completed, all browser origins/root identities agree, the Proxy was restored, all observer/error/drop conditions are clear, and the write start is finite.

Using **all five** RPC intervals gives conditional Node-minus-page offset `[60122.3045829761581,60122.7029160715256]ms`, width0.3983330953675ms. Relative to poll start:

| Observation | Conditional interval |
| --- | --- |
| Forwarded native family write |272.236833–272.6351660953675ms|
| MO callback delivery |321.0368329523162–321.4351660476837ms|

The same-browser reported write→MO delay is approximately48.8ms. The write's equal before/after ticks do **not** imply zero native duration. These conditional intervals precede this local run's original1000ms deadline, under the recorded same-document/stable relative-rate assumptions. No independent quantization/drift bound exists; this does not locate or repair the old hosted failures. The Proxy and setup affect scheduling, the writer is not full transaction completion, and MO delivery is not a setter timestamp.

The mobile success stages independently retain390→430→320. At every width, both `menu-ready` and `navigation-close-from-contents` have their expected following stages; there is no mobile rejection marker in this run. These adjacent Node samples bound successful steps, not exact DOM transitions or a cause for historical rejection.

Precommit arm2 remains **DE+dirty e97adac9,9/9 at00:00:37–00:01:49UTC**. Private utility arm3 remains **DE+different582835a6 source,1pass/8filtered at00:08:41–00:09:01UTC**, restored before commit. Its getter instrumentation is absent from the committed default file. Neither is relabelled as the clean2189 native120 run. No new hosted CI conclusion or formal approval is asserted.
