# Selected dedicated CI review — exact2189

Seventeen completed jobs were read and checked against download SHA/size and the full saved job pages. Job conclusions are13success/4failure. This is a selected job set, not all workflows or ordinary canonicalCI. No new confirmed C production source defect is established from these logs alone. Current measurable failures remain registered and are not dismissed as inherited.

| Scope | Actual result / source boundary |
|---|---|
| Browser suite repair evidence / focused-browser (118381253794) | 3files27pass: ScrollEndFollow6, BaseImage17, BrutalistSpinner4 |
| Dialog available-space matched evidence / matched-browser (baseline) (118381253551) | 8 reported test failures:7 geometric historical journeys plus1 unavailable ShadcnVue2 entry; job success is expected classifier success, not8passes |
| Dialog available-space matched evidence / matched-browser (candidate) (118381253846) | Current2189 candidate8/8 original Dialog journeys pass |
| Field family native evidence / browser-evidence (118381252735) | 25/25 Field native cases pass |
| Overlay portal direction native evidence / browser-evidence (118381253218) | 8/8 original Overlay portal direction cases pass |
| Select draft projection evidence / browser-evidence (118381252770) | 24/24 Select draft projection cases pass |
| Header Select elevation evidence / capture (flat) (118381253076) | 8/8 historical-negative controls; onlyBrutalist4runtimes×2themes. Not a Shadcn baseline and not currentfamily acceptance. |
| Header Select elevation evidence / capture (family) (118381253319) | Current family8pass/8fail; all8 Shadcn cases fail exactdesktop36px assertion with actual38px |
| Collapsible projection evidence / browser-evidence (118381253263) | 36/36 Collapsible projection cases pass; full file summary present |
| Homepage visual evidence / isolated-controls (native-links, site-native-links) (118381253302) | 9pass/1fail native links; original10s current-sidebar-link visible predicate returns false |
| Homepage visual evidence / mobile-navigation-reading (118381253303) | Custom mobile-navigation-reading job success; no Vitest count in this log |
| Homepage visual evidence / isolated-controls (runtime-box, runtime-preview-surface, runtime-preview-evidence) (118381253359) | 2files33pass: runtime-preview-surface16 +runtime-preview-evidence17 |
| Homepage visual evidence / isolated-controls (code-surface-grammar, code-surface-grammar) (118381253421) | Code surface grammar9/9pass |
| Homepage visual evidence / isolated-controls (copy-commands, site-copy-commands) (118381253555) | Copy commands14/14pass |
| Homepage visual evidence / isolated-controls (code-surfaces, code-surfaces) (118381253579) | Code surfaces7/7pass |
| Homepage visual evidence / isolated-controls (search-commands, site-search-commands) (118381253589) | Search commands13pass/17fail:6initial-ready deadline,3homepage geometry,8Docs initialrole1000ms |
| Homepage visual evidence / visual-density (118381254310) | Custom density job failure:8named Shadcn home variants fail primary.height32±1 predicate; no complete Vitest summary |

The historicalDialog job succeeds because its expected-negative classifier accepted8reportedfailures:7realgeometry journeys plus1ShadcnVue2 unavailable entry. Its product subject is15d864 and its probe is2189; it is not8currentproductfailures. The candidate8/8 is separately real. Header flat8/8 likewise tests only historicalBrutalist8856, not currentShadcn. The later empty-ghost step of currentHeaderfamily is explicitly skipped.

CurrentHeaderfamily8Shadcn cases fail actual38 vs36±0.5. Main042 alreadycontainswrapValue/height:auto; thisPR adds onlyexplicitHeader minHeight inthosecompositionpaths. A measured padding/lineheight/boxsizing control is necessary before selecting a fix. DefaultsharedShadcn no-padding tests must remain.

Native-links has one10s currentarticle-visible failure; the log recordsfalse but notwidth orscrollownergeometry, so missingowner/clipping/lifetime are still distinguishable hypotheses. Search17 failures split into6initialdeadline,3desktopgeometry and8Docsrole initialization polls before reveal/runtimeinteraction. The density customdriver records8Shadcn-home primaryheight failures but doesnotprinttheactualheight. These are notoneestablishedcause.

Two successful jobs actuallyusedNode24.22.0/Chrome155.0.8059.84 whileotherloggedHomepagejobs usedNode24.21.0/Chrome155.0.8059.39. Field25 usesitsdocumentedasync-traceopt-in. No environmentidentity or uninstrumented timing claim is added.

No newtest/browser/artifactdownload/sourcechange/GitHubwrite occurred. Root alone coordinatesanypurposefulnextcontrol. Partial/ABSTAIN; noformalapprovalorwholeportfolioacceptance.
