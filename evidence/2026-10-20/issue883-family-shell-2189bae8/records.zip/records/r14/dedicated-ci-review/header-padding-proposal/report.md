# Header responsive padding — source and actual red

The original private diagnostic ran at physical2189 plus exactly20readonly test-observation lines. It retained the entire original case and failed1case/15filtered at desktop1440 Runtime control: height38px, min-height36px, line-height20px, padding8+8px, borders1+1px, border-box, inlineheight:auto and noinlinepaddingBlock. The inherited paddingvariable is0.25rem. Root restored the original test byte-for-byte; this review did notrun anything.

This measured auto-height path explains38px as20+8+8+1+1. The36pxminimum cannot reduce that natural height. The expected h9/py2/textsm/border tokens and their actualcomputedproperties arepresent, so this sample doesnotidentify aCollector omission. It shows the WebsiteHeader responsivepadding choice isnotreaching the Shadcncompleteparts trigger.

wrapValue andheight:auto arealready inmain042; they were notintroduced bythisPR. The onlyowned delta inthese2compositionpaths since main is the explicitminHeight field/spread andtwoHomepageopt-ins. The October4consumer record already records the38/40intrinsic issue andresponsivepadding approach; the later991integrationomitsgenericpaddingforShadcnparts. That is source origin, not a blanketinherited exemption orproof of a freshmain-run result.

The privatecandidate adds optional app-internal paddingBlock:string, consumesit onlywhenexplicit, andopts onlyHomepage Runtime/Family into theexistingresponsivevariable. It retains height:auto, min-height36/44, full-valuewrapping, genericShadcndefaultno-padding, Prototypeh8/h9/py2recipes, original16caseoracles and90sdeadline. No fixedheightfallback orshareddefaultpadding is added.

Predicted arithmetic isdesktop30pxnaturalboundedbymin36, compact38pxnaturalboundedbymin44; multilinecontentcanstillgrow. These are predicted consequences, not a greenresult. Root should run theunchangeddefault-negative controls andoriginal16nativecases onthenewexactcandidate, keepingall2189clock/CIevidence initsownepoch. TheP-ShadcnTriggerdefinition isdraft; no lifecyclepromotionorpublicAPIchange isproposed.

See candidate.patch for the2-source5-lineproposal, report.json forexactrawreceipts/hashes/sourceanchors, and siblingheader-height-probe for theoriginalred. Peer/partial/ABSTAIN; noformalapproval.
