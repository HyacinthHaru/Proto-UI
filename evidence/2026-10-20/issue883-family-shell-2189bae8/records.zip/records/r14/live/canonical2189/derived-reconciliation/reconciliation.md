# Exact2189 canonical reconciliation

Run39346804518: failure; 22 jobs, {'success': 13, 'failure': 9}.

| Shard | Job conclusion | Full summary | Reported tests | Exit124 |
|---|---|---|---|---|
| 1/8 | failure | True | Tests  24 failed | 216 passed (240) | False |
| 2/8 | failure | False | unknown | True |
| 3/8 | failure | True | Tests  3 failed | 58 passed (61) | False |
| 4/8 | failure | True | Tests  2 failed | 122 passed (124) | False |
| 5/8 | failure | True | Tests  2 failed | 88 passed | 15 skipped (105) | False |
| 6/8 | success | True | Tests  169 passed (169) | False |
| 7/8 | failure | True | Tests  1 failed | 113 passed (114) | False |
| 8/8 | failure | False | unknown | True |

Complete-summary subset [1, 3, 4, 5, 6, 7]: {'passed': 766, 'failed': 32, 'skipped': 15, 'todo': 0}. All-eight totals known: False.

Inspect the JSON for each original file/case line, frozen mobile rejection stage/width/stack, all five main-world calibration samples and explicit writer usability reasons. A native attribute-write bracket is not full transaction success. No private utility-arm timing or historical-head counts are reused. Missing/errored/dropped/unrestored observations remain unavailable. This is partial/ABSTAIN and not an approval or all-CI pass.
