# Private utility arm3 reconciliation

Actual execution was DE plus arm2 plus the private utility helper, not clean DE or canonical CI. The20.052s wrapper finished exit0 with one original Brutalist case passed and eight filtered. Executed test SHA `582835a604957756f3c5f2ffa9eb030c1b7d9facab707112be21d8e32b16978b`; restoration returns to exact arm2 `e97adac9e292cb11e5ff8a104b4a554c5d158283cba476c34d9ad79ab55dbff9`.

All seven observed page timeOrigin values are equal, and both Node observers use the same Node timeOrigin. Retaining every sample gives:

| Conditional offset set (Node minus page, ms) | Intersection | Width |
|---|---|---|
| Main-world setup, collect,3post RPCs | 10037.586125–10038.216958 | 0.630833 |
| Utility install, collect | 10037.632083–10038.073291 | 0.441208 |
| Common7 | 10037.632083–10038.073291 | 0.441208 |

These bounds assume one stable document clock and approximately constant relative offset/rate. Equal timeOrigin is supporting evidence, not calibration of drift/quantization. Utility collection is later in the same journey. No previous arm offsets were borrowed.

| Read | Actual value | Node call duration(ms) | Node start→utility read(ms) | Utility read→Node settlement(ms) |
|---|---|---:|---:|---:|
| 1 | shadcn | 109.137458 | 108.431708–108.872916 | 0.264542–0.705750 |
| 2 | brutalist | 264.205625 | 263.478750–263.919958 | 0.285667–0.726875 |

Node.totalCalls=2 and utility.totalReads=2; both values/order and contained intervals match, with no drops/observer errors. The actual main-frame utility context, native getter descriptor, root identity, identity restoration and CDP detach were recorded. No protocol call ID was injected, so this is conditional count/order/value/time correspondence.

The native family-write bracket maps to 302.047583–302.488791ms relative to poll start; MO delivery maps to 356.047583–356.488791ms. Within the shared reported page clock the MO follows the write by54ms and the second getter follows the MO by67.9ms. The poll fulfilled after424.773125ms. Those are this positive arm’s observations, not original Linux-failure facts.

The longer portion in both samples precedes the actual utility getter; it can include client/server dispatch, selector resolution/retry and browser scheduling. The tail includes serialization/transport/Node processing. Do not label them pure browser queue or pure network delay. Equal before/after timestamps reflect reported precision, not zero work. The writer records a native write bracket, not full publication completion; MO records delivery.

CDP setup and getter instrumentation can change timing. The exact original deadline and original error policy remain; this positive does not explain or close the hosted red. No new execution, download, product change, external write or pixel review was performed here. Partial/ABSTAIN; this reviewer authored the plan and is not claiming formal independent approval.
