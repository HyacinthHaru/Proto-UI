import { afterAll, expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import { definePrototype } from '@proto.ui/core';
import * as autocomplete from '[workspace]/packages/prototypes/base/src/autocomplete';
import * as combobox from '[workspace]/packages/prototypes/base/src/combobox';
import * as command from '[workspace]/packages/prototypes/base/src/command';
import { formRoot } from '[workspace]/packages/prototypes/base/src/form';
import { FORM_FAMILY } from '[workspace]/packages/prototypes/base/src/form/shared';
import { createRuntimeSession } from '@proto.ui/runtime';
import {
  ANATOMY_INSTANCE_TOKEN_CAP,
  ANATOMY_PARENT_CAP,
  ANATOMY_GET_PROTO_CAP,
  ANATOMY_ROOT_TARGET_CAP,
} from '@proto.ui/module-anatomy';
import { CONTEXT_INSTANCE_TOKEN_CAP, CONTEXT_PARENT_CAP } from '@proto.ui/module-context';
import { EVENT_ROOT_TARGET_CAP, EVENT_GLOBAL_TARGET_CAP } from '@proto.ui/module-event';
import { EXPOSE_EVENT_SINK_CAP } from '@proto.ui/module-expose-event';
import {
  AS_TRIGGER_INSTANCE_CAP,
  AS_TRIGGER_PARENT_CAP,
  AS_TRIGGER_GET_PROTO_CAP,
} from '@proto.ui/module-as-trigger';
import { EXPOSES_RECORD_SINK_CAP } from '@proto.ui/module-expose-state';

function runtimeHarness() {
  const parents = new Map<any, any>(),
    protos = new Map<any, any>();
  let actionCallback = (_name: string) => {};
  const actions: string[] = [];
  function make(proto: any, parent: any = null, props: any = {}) {
    const listeners = new Map<string, Set<any>>();
    const target = {
      addEventListener(type: string, fn: any) {
        if (!listeners.has(type)) listeners.set(type, new Set());
        listeners.get(type)!.add(fn);
      },
      removeEventListener(type: string, fn: any) {
        listeners.get(type)?.delete(fn);
      },
      dispatchEvent(event: Event) {
        for (const fn of [...(listeners.get(event.type) ?? [])]) fn(event);
        return true;
      },
    } as unknown as EventTarget;
    parents.set(target, parent);
    protos.set(target, proto);
    let exposes: any;
    const session = createRuntimeSession(proto, {
      prototypeName: proto.name,
      getRawProps: () => props,
      schedule: (fn) => fn(),
      scheduleDelay: (ms, fn) => {
        const id = setTimeout(fn, ms);
        return { cancel: () => clearTimeout(id) };
      },
      commit: (_c, s) => s?.done(),
      onRuntimeReady(w) {
        w.attach('anatomy', [
          [ANATOMY_INSTANCE_TOKEN_CAP, target],
          [ANATOMY_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [ANATOMY_GET_PROTO_CAP, (t: any) => protos.get(t)],
          [ANATOMY_ROOT_TARGET_CAP, (t: any) => t],
        ]);
        w.attach('context', [
          [CONTEXT_INSTANCE_TOKEN_CAP, target],
          [CONTEXT_PARENT_CAP, (t: any) => parents.get(t) ?? null],
        ]);
        w.attach('event', [
          [EVENT_ROOT_TARGET_CAP, () => target],
          [EVENT_GLOBAL_TARGET_CAP, () => target],
        ]);
        w.attach('as-trigger', [
          [AS_TRIGGER_INSTANCE_CAP, target],
          [AS_TRIGGER_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [AS_TRIGGER_GET_PROTO_CAP, (t: any) => protos.get(t)],
        ]);
        w.attach('expose-state', [
          [
            EXPOSES_RECORD_SINK_CAP,
            (x: any) => {
              exposes = x;
            },
          ],
        ]);
        w.attach('expose-event', [
          [
            EXPOSE_EVENT_SINK_CAP,
            (name: string) => {
              actions.push(name);
              if (
                name === 'valueChange' ||
                name === 'execute' ||
                name === 'openChange' ||
                name === 'validationRequest'
              )
                actionCallback(name);
            },
          ],
        ]);
      },
    });
    return {
      session,
      target,
      get exposes() {
        return exposes;
      },
    };
  }

  return {
    make,
    actions,
    setActionCallback(fn: (name: string) => void) {
      actionCallback = fn;
    },
  };
}



import { toastRoot } from '[workspace]/packages/prototypes/base/src/toast';
import { TOAST_CONTEXT } from '[workspace]/packages/prototypes/base/src/toast/shared';
import { FORM_CONTEXT } from '[workspace]/packages/prototypes/base/src/form/shared';

const observations: any[]=[];
afterAll(()=>writeFileSync(__dirname+'/observations.json',JSON.stringify(observations,null,2)));
it.each(['normal','unmount','remount'] as const)('Toast open State observer %s must reconcile its next view Context',async operation=>{
 const {make,actions}=runtimeHarness();const changes:any[]=[];const toast=make(toastRoot,null,{defaultOpen:true,duration:0});
 const reader=definePrototype({name:'review-toast-context-reader',setup(def){let current:any;def.context.subscribe(TOAST_CONTEXT,(_run,value)=>{changes.push({value,epoch:toast.session.mountEpoch,phase:toast.session.mountPhase});});def.lifecycle.onCreated(run=>{current=run;});def.expose.method('read',()=>current.context.read(TOAST_CONTEXT));}});
 const child=make(reader,toast.target);await toast.session.mount();await child.session.mount();
 const initial=child.session.invokeInCallbackScope(()=>child.exposes.read());const waits:Promise<void>[]=[];let once=false;
 toast.exposes.open.subscribe((e:any)=>{if(e.type!=='next'||e.next!==false||once||operation==='normal')return;once=true;waits.push(toast.session.unmount());if(operation==='remount')waits.push(toast.session.mount());});
 try{
  toast.session.invokeInCallbackScope(()=>toast.exposes.close());
  const immediate={open:toast.exposes.open.get(),context:child.session.invokeInCallbackScope(()=>child.exposes.read()),epoch:toast.session.mountEpoch,phase:toast.session.mountPhase};
  await Promise.all(waits);if(operation==='unmount')await toast.session.mount();
  const final={open:toast.exposes.open.get(),context:child.session.invokeInCallbackScope(()=>child.exposes.read()),epoch:toast.session.mountEpoch,phase:toast.session.mountPhase};
  observations.push({kind:'toast',operation,initial,immediate,final,changes,actions:[...actions]});
  expect(final.phase).toBe('mounted');expect(final.open).toBe(false);expect(final.context.open).toBe(final.open);
 }finally{await child.session.dispose();await toast.session.dispose();}
});
it.each(['unmount','dispose','remount','nested'] as const)('Form pending observer during cancel: %s',async operation=>{
 const {make,actions}=runtimeHarness();const calls:number[]=[];const notifications:any[]=[];let form:any;
 const fields=[0,1].map(index=>definePrototype({name:'review-pending-field-'+index,setup(def){
  def.anatomy.claim(FORM_FAMILY,{role:'field'});const pending=def.state.bool('pending',true);def.expose.method('complete',()=>pending.set(false,'completed control'));
  def.expose.method('__formField',()=>({name:'field-'+index,value:'valid',disabled:false,available:true,implicitSubmit:false,validity:{status:'valid',invalid:false,pending:pending.get(),dirty:false,touched:false,filled:true,focused:false,flags:[],errors:[]}}));def.expose.method('validate',()=>{calls.push(index);});
 }}));
 form=make(formRoot);const first=make(fields[0],form.target),second=make(fields[1],form.target);
 const observerProto=definePrototype({name:'review-form-context-observer',setup(def){let current:any;def.context.subscribe(FORM_CONTEXT,(_run,value)=>{notifications.push({at:'context',value,epoch:form.session.mountEpoch,phase:form.session.mountPhase,instance:form.session.instancePhase});});def.lifecycle.onCreated(run=>{current=run;});def.expose.method('read',()=>current.context.read(FORM_CONTEXT));}});
 const observer=make(observerProto,form.target);for(const p of [form,first,second,observer])await p.session.mount();
 const waits:Promise<void>[]=[];let once=false,nested:unknown;
 try{
  expect(form.session.invokeInCallbackScope(()=>form.exposes.requestSubmit())).toBe(true);expect(form.exposes.pending.get()).toBe(true);notifications.length=0;calls.length=0;actions.length=0;
  form.exposes.pending.subscribe((e:any)=>{if(e.type!=='next'||e.next!==false||once)return;once=true;notifications.push({at:'observer-start',epoch:form.session.mountEpoch});
   if(operation==='nested'){first.session.invokeInCallbackScope(()=>first.exposes.complete());second.session.invokeInCallbackScope(()=>second.exposes.complete());nested=form.session.invokeInCallbackScope(()=>form.exposes.requestSubmit());}
   else{waits.push(form.session[operation==='dispose'?'dispose':'unmount']());if(operation==='remount')waits.push(form.session.mount());}
   notifications.push({at:'observer-return',epoch:form.session.mountEpoch,phase:form.session.mountPhase});
  });
  const accepted=form.session.invokeInCallbackScope(()=>form.exposes.requestSubmit());notifications.push({at:'outer-return',epoch:form.session.mountEpoch,phase:form.session.mountPhase});await Promise.all(waits);
  if(operation==='unmount')await form.session.mount();
  const final=operation==='dispose'?{instance:form.session.instancePhase}:{pending:form.exposes.pending.get(),submitted:form.exposes.submitted.get(),context:observer.session.invokeInCallbackScope(()=>observer.exposes.read()),epoch:form.session.mountEpoch,phase:form.session.mountPhase};
  observations.push({kind:'form-cancel',operation,accepted,nested,calls:[...calls],notifications,actions:[...actions],final});expect(accepted).toBe(true);
  if(operation==='nested'){expect(nested).toBe(true);expect(calls).toEqual([0,1]);expect(actions).toEqual(['submit']);expect(final.context).toEqual({disabled:false,pending:false,submitted:true});}
  else{expect(calls).toEqual([]);expect(actions).toEqual([]);if(operation!=='dispose')expect(final.context).toEqual({disabled:false,pending:false,submitted:false});}
 }finally{for(const p of [observer,second,first,form])await p.session.dispose();}
});
