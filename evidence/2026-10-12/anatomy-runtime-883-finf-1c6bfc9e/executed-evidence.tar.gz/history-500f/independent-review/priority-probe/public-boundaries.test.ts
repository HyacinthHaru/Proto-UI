import { afterAll, expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import { definePrototype } from '@proto.ui/core';
import * as autocomplete from '[workspace]/packages/prototypes/base/src/autocomplete';
import * as combobox from '[workspace]/packages/prototypes/base/src/combobox';
import * as command from '[workspace]/packages/prototypes/base/src/command';
import { formRoot } from '[workspace]/packages/prototypes/base/src/form';
import { FORM_FAMILY } from '[workspace]/packages/prototypes/base/src/form/shared';
import { createRuntimeSession } from '@proto.ui/runtime';
import {
  ANATOMY_INSTANCE_TOKEN_CAP,
  ANATOMY_PARENT_CAP,
  ANATOMY_GET_PROTO_CAP,
  ANATOMY_ROOT_TARGET_CAP,
} from '@proto.ui/module-anatomy';
import { CONTEXT_INSTANCE_TOKEN_CAP, CONTEXT_PARENT_CAP } from '@proto.ui/module-context';
import { EVENT_ROOT_TARGET_CAP, EVENT_GLOBAL_TARGET_CAP } from '@proto.ui/module-event';
import { EXPOSE_EVENT_SINK_CAP } from '@proto.ui/module-expose-event';
import {
  AS_TRIGGER_INSTANCE_CAP,
  AS_TRIGGER_PARENT_CAP,
  AS_TRIGGER_GET_PROTO_CAP,
} from '@proto.ui/module-as-trigger';
import { EXPOSES_RECORD_SINK_CAP } from '@proto.ui/module-expose-state';

function runtimeHarness() {
  const parents = new Map<any, any>(),
    protos = new Map<any, any>();
  let actionCallback = (_name: string) => {};
  const actions: string[] = [];
  function make(proto: any, parent: any = null, props: any = {}) {
    const listeners = new Map<string, Set<any>>();
    const target = {
      addEventListener(type: string, fn: any) {
        if (!listeners.has(type)) listeners.set(type, new Set());
        listeners.get(type)!.add(fn);
      },
      removeEventListener(type: string, fn: any) {
        listeners.get(type)?.delete(fn);
      },
      dispatchEvent(event: Event) {
        for (const fn of [...(listeners.get(event.type) ?? [])]) fn(event);
        return true;
      },
    } as unknown as EventTarget;
    parents.set(target, parent);
    protos.set(target, proto);
    let exposes: any;
    const session = createRuntimeSession(proto, {
      prototypeName: proto.name,
      getRawProps: () => props,
      schedule: (fn) => fn(),
      scheduleDelay: (ms, fn) => {
        const id = setTimeout(fn, ms);
        return { cancel: () => clearTimeout(id) };
      },
      commit: (_c, s) => s?.done(),
      onRuntimeReady(w) {
        w.attach('anatomy', [
          [ANATOMY_INSTANCE_TOKEN_CAP, target],
          [ANATOMY_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [ANATOMY_GET_PROTO_CAP, (t: any) => protos.get(t)],
          [ANATOMY_ROOT_TARGET_CAP, (t: any) => t],
        ]);
        w.attach('context', [
          [CONTEXT_INSTANCE_TOKEN_CAP, target],
          [CONTEXT_PARENT_CAP, (t: any) => parents.get(t) ?? null],
        ]);
        w.attach('event', [
          [EVENT_ROOT_TARGET_CAP, () => target],
          [EVENT_GLOBAL_TARGET_CAP, () => target],
        ]);
        w.attach('as-trigger', [
          [AS_TRIGGER_INSTANCE_CAP, target],
          [AS_TRIGGER_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [AS_TRIGGER_GET_PROTO_CAP, (t: any) => protos.get(t)],
        ]);
        w.attach('expose-state', [
          [
            EXPOSES_RECORD_SINK_CAP,
            (x: any) => {
              exposes = x;
            },
          ],
        ]);
        w.attach('expose-event', [
          [
            EXPOSE_EVENT_SINK_CAP,
            (name: string) => {
              actions.push(name);
              if (
                name === 'valueChange' ||
                name === 'execute' ||
                name === 'openChange' ||
                name === 'validationRequest'
              )
                actionCallback(name);
            },
          ],
        ]);
      },
    });
    return {
      session,
      target,
      get exposes() {
        return exposes;
      },
    };
  }

  return {
    make,
    actions,
    setActionCallback(fn: (name: string) => void) {
      actionCallback = fn;
    },
  };
}


const observations: any[] = [];
afterAll(() => writeFileSync(__dirname + '/observations.json', JSON.stringify(observations, null, 2)));
for (const topology of ['trigger', 'root', 'both'] as const)
  it.each(['unmount', 'dispose', 'remount'] as const)(`combobox ${topology}-only topology: %s`, async operation => {
    const { make, actions, setActionCallback } = runtimeHarness();
    let focused = 0;
    const inputProto = definePrototype({ name: 'review-focus-input', setup(def) {
      def.anatomy.claim(combobox.COMBOBOX_FAMILY, { role: 'input' });
      def.expose.method('focusSelf', () => { focused++; });
    }});
    const root = make(combobox.comboboxRoot, null, { defaultOpen: false });
    const input = make(inputProto, root.target), trigger = make(combobox.comboboxTrigger, root.target);
    for (const p of [root,input,trigger]) await p.session.mount();
    setActionCallback(name => {
      if (name !== 'openChange') return;
      if (topology !== 'root') void trigger.session[operation === 'dispose' ? 'dispose' : 'unmount']();
      if (topology !== 'trigger') void root.session[operation === 'dispose' ? 'dispose' : 'unmount']();
      if (operation === 'remount') {
        if (topology !== 'trigger') void root.session.mount();
        if (topology !== 'root') void trigger.session.mount();
      }
    });
    let error: any;
    try {
      try { trigger.target.dispatchEvent(new Event('press.commit')); } catch(e) { error = e; }
      observations.push({ topology, operation, focused, actions: [...actions], error: error && {code:error.code,message:error.message} });
      if(topology === 'root' && operation === 'dispose') expect(error?.code).toBe('ANATOMY_CLAIM_INVALID');
      else expect(error).toBeUndefined();
      expect(focused).toBe(topology === 'root' && operation !== 'dispose' ? 1 : 0);
      expect(actions).toEqual(['openChange']);
    } finally { for (const p of [trigger,input,root]) await p.session.dispose(); }
  });
it.each(['unmount','dispose','remount'] as const)('autocomplete close Trigger-only: %s', async operation => {
  const {make,actions,setActionCallback}=runtimeHarness();let focused=0;
  const inputProto=definePrototype({name:'review-autocomplete-input',setup(def){def.anatomy.claim(autocomplete.AUTOCOMPLETE_FAMILY,{role:'input'});def.expose.method('focusSelf',()=>{focused++;});}});
  const root=make(autocomplete.autocompleteRoot,null,{defaultOpen:true}), input=make(inputProto,root.target), trigger=make(autocomplete.autocompleteTrigger,root.target);
  for(const p of [root,input,trigger]) await p.session.mount();
  setActionCallback(name=>{if(name==='openChange'){void trigger.session[operation==='dispose'?'dispose':'unmount']();if(operation==='remount') void trigger.session.mount();}});
  try {expect(()=>trigger.target.dispatchEvent(new Event('press.commit'))).not.toThrow();expect(actions).toEqual(['openChange']);expect(focused).toBe(0);observations.push({topology:'autocomplete-trigger-only',operation,focused,actions:[...actions]});}
  finally{for(const p of [trigger,input,root]) await p.session.dispose();}
});
it('Command Trigger preserves normal input-focus action without popup request',async()=>{
 const {make,actions}=runtimeHarness();let focused=0;
 const inputProto=definePrototype({name:'review-command-input',setup(def){def.anatomy.claim(command.COMMAND_FAMILY,{role:'input'});def.expose.method('focusSelf',()=>{focused++;});}});
 const root=make(command.commandRoot),input=make(inputProto,root.target),trigger=make(command.commandTrigger,root.target);
 for(const p of [root,input,trigger])await p.session.mount();
 try{expect(()=>trigger.target.dispatchEvent(new Event('press.commit'))).not.toThrow();expect(actions).toEqual([]);expect(focused).toBe(1);observations.push({topology:'command-normal',actions:[...actions],focused});}finally{for(const p of [trigger,input,root])await p.session.dispose();}
});
function formFixture(){
 const h=runtimeHarness(),calls:number[]=[];
 const fields=[0,1].map(index=>definePrototype({name:'review-form-field-'+index,setup(def){
  def.anatomy.claim(FORM_FAMILY,{role:'field'});
  def.expose.method('__formField',()=>({name:'field-'+index,value:'valid',disabled:false,available:true,implicitSubmit:false,validity:{status:'valid',invalid:false,pending:false,dirty:false,touched:false,filled:true,focused:false,flags:[],errors:[]}}));
  def.expose.event('validationRequest',{payload:'json'});let current:any;def.lifecycle.onCreated(run=>{current=run;});
  def.expose.method('validate',()=>{calls.push(index);current.expose.emit('validationRequest',{});});
  def.expose.method('resetValidation',()=>{calls.push(index);});
 }}));
 const form=h.make(formRoot),first=h.make(fields[0],form.target),second=h.make(fields[1],form.target);
 return {...h,form,first,second,calls,async mount(){for(const p of [form,first,second])await p.session.mount();},async dispose(){for(const p of [second,first,form])await p.session.dispose();}};
}
it('nested accepted submission owns the validation continuation without busy rejection',async()=>{
 const h=formFixture();await h.mount();let once=false,nested:unknown;
 h.setActionCallback(name=>{if(name==='validationRequest'&&!once){once=true;nested=h.form.session.invokeInCallbackScope(()=>h.form.exposes.requestSubmit());}});
 try{const accepted=h.form.session.invokeInCallbackScope(()=>h.form.exposes.requestSubmit());expect(accepted).toBe(true);expect(nested).toBe(true);expect(h.calls).toEqual([0,0,1]);expect(h.actions.filter(x=>x==='submit')).toHaveLength(1);expect(h.form.exposes.pending.get()).toBe(false);expect(h.form.exposes.submitted.get()).toBe(true);observations.push({form:'nested-submit',accepted,nested,calls:h.calls,actions:h.actions});}finally{await h.dispose();}
});
it('resetValidation with alive nullable run keeps void and resets retained state',async()=>{
 const h=formFixture();await h.mount();
 try{expect(h.form.session.invokeInCallbackScope(()=>h.form.exposes.requestSubmit())).toBe(true);expect(h.form.exposes.submitted.get()).toBe(true);await h.form.session.unmount();h.calls.length=0;const result=h.form.session.invokeInCallbackScope(()=>h.form.exposes.resetValidation());expect(result).toBeUndefined();expect(h.form.exposes.submitted.get()).toBe(false);expect(h.calls).toEqual([]);await h.form.session.mount();expect(h.form.session.invokeInCallbackScope(()=>h.form.exposes.requestSubmit())).toBe(true);expect(h.calls).toEqual([0,1]);observations.push({form:'nullable-retained-run',result:String(result),calls:h.calls,submitted:h.form.exposes.submitted.get()});}finally{await h.dispose();}
});
it('created never-mounted Form still accepts submit and void validation reset',async()=>{
 const h=formFixture();try{expect(h.form.session.invokeInCallbackScope(()=>h.form.exposes.requestSubmit())).toBe(true);expect(h.form.exposes.submitted.get()).toBe(true);expect(h.form.session.invokeInCallbackScope(()=>h.form.exposes.resetValidation())).toBeUndefined();expect(h.calls).toEqual([0,1,0,1]);expect(h.form.exposes.submitted.get()).toBe(false);observations.push({form:'never-mounted',calls:h.calls,actions:h.actions});}finally{await h.dispose();}
});
