import { afterAll, expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import { definePrototype } from '@proto.ui/core';
import * as autocomplete from '[workspace]/packages/prototypes/base/src/autocomplete';
import * as combobox from '[workspace]/packages/prototypes/base/src/combobox';
import * as command from '[workspace]/packages/prototypes/base/src/command';
import { formRoot } from '[workspace]/packages/prototypes/base/src/form';
import { FORM_FAMILY } from '[workspace]/packages/prototypes/base/src/form/shared';
import { createRuntimeSession } from '@proto.ui/runtime';
import {
  ANATOMY_INSTANCE_TOKEN_CAP,
  ANATOMY_PARENT_CAP,
  ANATOMY_GET_PROTO_CAP,
  ANATOMY_ROOT_TARGET_CAP,
} from '@proto.ui/module-anatomy';
import { CONTEXT_INSTANCE_TOKEN_CAP, CONTEXT_PARENT_CAP } from '@proto.ui/module-context';
import { EVENT_ROOT_TARGET_CAP, EVENT_GLOBAL_TARGET_CAP } from '@proto.ui/module-event';
import { EXPOSE_EVENT_SINK_CAP } from '@proto.ui/module-expose-event';
import {
  AS_TRIGGER_INSTANCE_CAP,
  AS_TRIGGER_PARENT_CAP,
  AS_TRIGGER_GET_PROTO_CAP,
} from '@proto.ui/module-as-trigger';
import { EXPOSES_RECORD_SINK_CAP } from '@proto.ui/module-expose-state';

function runtimeHarness() {
  const parents = new Map<any, any>(),
    protos = new Map<any, any>();
  let actionCallback = (_name: string) => {};
  const actions: string[] = [];
  function make(proto: any, parent: any = null, props: any = {}) {
    const listeners = new Map<string, Set<any>>();
    const target = {
      addEventListener(type: string, fn: any) {
        if (!listeners.has(type)) listeners.set(type, new Set());
        listeners.get(type)!.add(fn);
      },
      removeEventListener(type: string, fn: any) {
        listeners.get(type)?.delete(fn);
      },
      dispatchEvent(event: Event) {
        for (const fn of [...(listeners.get(event.type) ?? [])]) fn(event);
        return true;
      },
    } as unknown as EventTarget;
    parents.set(target, parent);
    protos.set(target, proto);
    let exposes: any;
    const session = createRuntimeSession(proto, {
      prototypeName: proto.name,
      getRawProps: () => props,
      schedule: (fn) => fn(),
      scheduleDelay: (ms, fn) => {
        const id = setTimeout(fn, ms);
        return { cancel: () => clearTimeout(id) };
      },
      commit: (_c, s) => s?.done(),
      onRuntimeReady(w) {
        w.attach('anatomy', [
          [ANATOMY_INSTANCE_TOKEN_CAP, target],
          [ANATOMY_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [ANATOMY_GET_PROTO_CAP, (t: any) => protos.get(t)],
          [ANATOMY_ROOT_TARGET_CAP, (t: any) => t],
        ]);
        w.attach('context', [
          [CONTEXT_INSTANCE_TOKEN_CAP, target],
          [CONTEXT_PARENT_CAP, (t: any) => parents.get(t) ?? null],
        ]);
        w.attach('event', [
          [EVENT_ROOT_TARGET_CAP, () => target],
          [EVENT_GLOBAL_TARGET_CAP, () => target],
        ]);
        w.attach('as-trigger', [
          [AS_TRIGGER_INSTANCE_CAP, target],
          [AS_TRIGGER_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [AS_TRIGGER_GET_PROTO_CAP, (t: any) => protos.get(t)],
        ]);
        w.attach('expose-state', [
          [
            EXPOSES_RECORD_SINK_CAP,
            (x: any) => {
              exposes = x;
            },
          ],
        ]);
        w.attach('expose-event', [
          [
            EXPOSE_EVENT_SINK_CAP,
            (name: string) => {
              actions.push(name);
              if (
                name === 'valueChange' ||
                name === 'execute' ||
                name === 'openChange' ||
                name === 'validationRequest'
              )
                actionCallback(name);
            },
          ],
        ]);
      },
    });
    return {
      session,
      call<T>(fn: () => T): T {
        let result!: T;
        session.invokeInCallbackScope(() => { result = fn(); });
        return result;
      },
      target,
      get exposes() {
        return exposes;
      },
    };
  }

  return {
    make,
    actions,
    setActionCallback(fn: (name: string) => void) {
      actionCallback = fn;
    },
  };
}



import { numberFieldRoot } from '[workspace]/packages/prototypes/base/src/number-field';
import { calendarRoot } from '[workspace]/packages/prototypes/base/src/calendar';
import { inputOtpRoot } from '[workspace]/packages/prototypes/base/src/input-otp';
import { dataTableRoot, DATA_TABLE_CONTEXT } from '[workspace]/packages/prototypes/base/src/data-table';
import { accordionRoot } from '[workspace]/packages/prototypes/base/src/accordion';
import { ACCORDION_FAMILY } from '[workspace]/packages/prototypes/base/src/accordion/shared';
import { toastRoot } from '[workspace]/packages/prototypes/base/src/toast';
import { TOAST_CONTEXT } from '[workspace]/packages/prototypes/base/src/toast/shared';
const observations:any[]=[];afterAll(()=>writeFileSync(__dirname+'/created-observations.json',JSON.stringify(observations,null,2)));
const cases=[
{name:'Number Field',proto:numberFieldRoot,props:{},state:'value',request:(x:any)=>x.requestValue(2),event:'valueChange'},
{name:'Calendar',proto:calendarRoot,props:{defaultMonth:'2026-10'},state:'month',request:(x:any)=>x.requestMonth('2026-11'),event:'monthChange'},
{name:'OTP',proto:inputOtpRoot,props:{},state:'value',request:(x:any)=>x.requestValue('123456'),event:'valueChange'},
{name:'Data Table',proto:dataTableRoot,props:{},context:DATA_TABLE_CONTEXT,request:(x:any)=>x.requestSort('name'),event:'sortChange'},
];
for(const c of cases)it.each([false,true])(`${c.name} created-only request dispose=%s`,async retire=>{
 const {make,actions}=runtimeHarness();const root=make(c.proto,null,c.props);let child:any,armed=false,observed=0,error:any,result:any;
 const observe=()=>{if(!armed)return;observed++;armed=false;if(retire)void root.session.dispose();};
 if(c.context){const observer=definePrototype({name:'review-created-observer',setup(def){def.context.subscribe(c.context,observe);}});child=make(observer,root.target);}
 if(c.state)root.exposes[c.state].subscribe((e:any)=>{if(e.type==='next')observe();});
 try{expect(root.session.mountPhase).toBe('detached');armed=true;try{result=root.call(()=>c.request(root.exposes));}catch(e){error=e;}
  observations.push({name:c.name,retire,observed,result,phase:root.session.mountPhase,instance:root.session.instancePhase,actions:[...actions],error:error&&{code:error.code,message:error.message}});
  expect(observed).toBe(1);expect(error).toBeUndefined();expect(result).toBe(true);if(retire)expect(actions).toEqual([]);else expect(actions).toContain(c.event);
 }finally{if(child)await child.session.dispose();await root.session.dispose();}
});
it('Accordion keeps a live currentRun after view unmount',async()=>{
 const {make,actions}=runtimeHarness();const root=make(accordionRoot);const item=make(definePrototype({name:'review-detached-accordion-item',setup(def){def.anatomy.claim(ACCORDION_FAMILY,{role:'item'});def.expose.state('value',def.state.string('value','one'));def.expose.state('disabled',def.state.bool('disabled',false));}}),root.target);
 await root.session.mount();await item.session.mount();try{await root.session.unmount();const accepted=root.call(()=>root.exposes.requestOpen('one',true));const count=root.exposes.openCount.get();observations.push({name:'Accordion detached',accepted,count,phase:root.session.mountPhase,actions:[...actions]});expect(accepted).toBe(true);expect(count).toBe(1);expect(actions).toContain('openChange');}finally{await item.session.dispose();await root.session.dispose();}
});
it('Toast preserves an already detached instance close and current Context',async()=>{
 const {make,actions}=runtimeHarness();const root=make(toastRoot,null,{defaultOpen:true,duration:0});const reader=make(definePrototype({name:'review-detached-toast-reader',setup(def){let run:any;def.context.subscribe(TOAST_CONTEXT);def.lifecycle.onCreated(r=>{run=r;});def.expose.method('read',()=>run.context.read(TOAST_CONTEXT));}}),root.target);
 await root.session.mount();await reader.session.mount();try{await root.session.unmount();root.call(()=>root.exposes.close());const value=root.exposes.open.get(),ctx=reader.call(()=>reader.exposes.read());observations.push({name:'Toast detached',value,ctx,phase:root.session.mountPhase,actions:[...actions]});expect(value).toBe(false);expect(ctx.open).toBe(false);}finally{await reader.session.dispose();await root.session.dispose();}
});
