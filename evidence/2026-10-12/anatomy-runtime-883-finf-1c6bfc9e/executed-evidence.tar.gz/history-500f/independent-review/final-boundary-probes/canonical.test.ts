import { afterAll, expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import { definePrototype } from '@proto.ui/core';
import { createRuntimeSession } from '@proto.ui/runtime';
import {
  ANATOMY_INSTANCE_TOKEN_CAP,
  ANATOMY_PARENT_CAP,
  ANATOMY_GET_PROTO_CAP,
  ANATOMY_ROOT_TARGET_CAP,
} from '@proto.ui/module-anatomy';
import { CONTEXT_INSTANCE_TOKEN_CAP, CONTEXT_PARENT_CAP } from '@proto.ui/module-context';
import { EVENT_ROOT_TARGET_CAP, EVENT_GLOBAL_TARGET_CAP } from '@proto.ui/module-event';
import { EXPOSE_EVENT_SINK_CAP } from '@proto.ui/module-expose-event';
import {
  AS_TRIGGER_INSTANCE_CAP,
  AS_TRIGGER_PARENT_CAP,
  AS_TRIGGER_GET_PROTO_CAP,
} from '@proto.ui/module-as-trigger';
import { EXPOSES_RECORD_SINK_CAP } from '@proto.ui/module-expose-state';
import { fieldRoot, fieldControl } from '[workspace]/packages/prototypes/base/src/field';
import {
  TEXT_CONTROL_HOST_CAP,
  TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
} from '@proto.ui/module-text-control';
import { numberFieldRoot } from '[workspace]/packages/prototypes/base/src/number-field';
import { dataTableRoot, DATA_TABLE_CONTEXT } from '[workspace]/packages/prototypes/base/src/data-table';
import { calendarRoot } from '[workspace]/packages/prototypes/base/src/calendar';
import { toastRoot } from '[workspace]/packages/prototypes/base/src/toast';
import { TOAST_CONTEXT } from '[workspace]/packages/prototypes/base/src/toast/shared';
import { checkboxGroupRoot } from '[workspace]/packages/prototypes/base/src/checkbox-group';
import { CHECKBOX_GROUP_FAMILY } from '[workspace]/packages/prototypes/base/src/checkbox-group/shared';
import { carouselRoot, CAROUSEL_FAMILY } from '[workspace]/packages/prototypes/base/src/carousel';
import { accordionRoot } from '[workspace]/packages/prototypes/base/src/accordion';
import { ACCORDION_FAMILY } from '[workspace]/packages/prototypes/base/src/accordion/shared';
import { contextMenuRoot } from '[workspace]/packages/prototypes/base/src/context-menu';
import { treeRoot, TREE_FAMILY } from '[workspace]/packages/prototypes/base/src/tree';
import { inputOtpRoot } from '[workspace]/packages/prototypes/base/src/input-otp';
import { menubarRoot, menubarTrigger, MENUBAR_FAMILY } from '[workspace]/packages/prototypes/base/src/menubar';
function runtimeHarness() {
  const parents = new Map<any, any>(),
    protos = new Map<any, any>();
  let actionCallback = (_name: string) => {};
  const actions: string[] = [];
  const details: any[] = [];
  function make(proto: any, parent: any = null, props: any = {}) {
    const listeners = new Map<string, Set<any>>();
    const target = {
      addEventListener(type: string, fn: any) {
        if (!listeners.has(type)) listeners.set(type, new Set());
        listeners.get(type)!.add(fn);
      },
      removeEventListener(type: string, fn: any) {
        listeners.get(type)?.delete(fn);
      },
      dispatchEvent(event: Event) {
        for (const fn of [...(listeners.get(event.type) ?? [])]) fn(event);
        return true;
      },
    } as unknown as EventTarget;
    parents.set(target, parent);
    protos.set(target, proto);
    let exposes: any,
      connection: any,
      textValue = '';
    const session = createRuntimeSession(proto, {
      prototypeName: proto.name,
      getRawProps: () => props,
      schedule: (fn) => fn(),
      scheduleDelay: (ms, fn) => {
        const id = setTimeout(fn, ms);
        return { cancel: () => clearTimeout(id) };
      },
      commit: (_c, s) => s?.done(),
      onRuntimeReady(w) {
        if (proto === fieldControl)
          w.attach('text-control', [
            [
              TEXT_CONTROL_HOST_CAP,
              {
                attach(c: any) {
                  connection = c;
                  textValue = c.patch.value ?? c.patch.defaultValue ?? '';
                  return {
                    update(patch: any) {
                      if (typeof patch.value === 'string') textValue = patch.value;
                    },
                    snapshot: () => ({ value: textValue, composing: false }),
                    dispose() {},
                  };
                },
              },
            ],
            [
              TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
              (fn: () => void) => session.invokeInCallbackScope(fn),
            ],
          ]);
        w.attach('anatomy', [
          [ANATOMY_INSTANCE_TOKEN_CAP, target],
          [ANATOMY_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [ANATOMY_GET_PROTO_CAP, (t: any) => protos.get(t)],
          [ANATOMY_ROOT_TARGET_CAP, (t: any) => t],
        ]);
        w.attach('context', [
          [CONTEXT_INSTANCE_TOKEN_CAP, target],
          [CONTEXT_PARENT_CAP, (t: any) => parents.get(t) ?? null],
        ]);
        w.attach('event', [
          [EVENT_ROOT_TARGET_CAP, () => target],
          [EVENT_GLOBAL_TARGET_CAP, () => target],
        ]);
        w.attach('as-trigger', [
          [AS_TRIGGER_INSTANCE_CAP, target],
          [AS_TRIGGER_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [AS_TRIGGER_GET_PROTO_CAP, (t: any) => protos.get(t)],
        ]);
        w.attach('expose-state', [
          [
            EXPOSES_RECORD_SINK_CAP,
            (x: any) => {
              exposes = x;
            },
          ],
        ]);
        w.attach('expose-event', [
          [
            EXPOSE_EVENT_SINK_CAP,
            (name: string, detail: any) => {
              actions.push(name);
              details.push({name,detail});
              actionCallback(name);
            },
          ],
        ]);
      },
    });
    return {
      session,
      call<T>(fn: () => T): T {
        let result!: T;
        session.invokeInCallbackScope(() => { result = fn(); });
        return result;
      },
      setProps(next: any) { props=next; session.controller.applyRawProps(next); },
      target,
      input(value: string) {
        textValue = value;
        connection.onEvent({
          type: 'input',
          value,
          composing: true,
          data: 'x',
          inputType: 'insertText',
        });
      },
      change(value: string) { textValue=value; connection.onEvent({type:"change",value,composing:false}); },
      get exposes() {
        return exposes;
      },
    };
  }

  return {
    make,
    actions,
    details,
    setActionCallback(fn: (name: string) => void) {
      actionCallback = fn;
    },
  };
}


const observations:any[]=[];afterAll(()=>writeFileSync(__dirname+'/canonical-observations.json',JSON.stringify(observations,null,2)));
it.each(['request','commit'] as const)('Number Field preserves same-epoch nested canonical %s',async method=>{
 const {make,actions,details,setActionCallback}=runtimeHarness();const root=make(numberFieldRoot);await root.session.mount();let once=false,nested:unknown;
 setActionCallback(name=>{if(name==='valueChange'&&!once){once=true;nested=root.call(()=>root.exposes.requestValue(4));}});
 try{if(method==='commit')root.call(()=>root.exposes.requestInput('2',true));const accepted=root.call(()=>method==='commit'?root.exposes.commitValue():root.exposes.requestValue(2));expect(nested).toBe(true);if(method==='request')expect(accepted).toBe(true);expect(root.exposes.value.get()).toBe(4);expect(root.exposes.draft.get()).toBe('4');if(method==='commit')expect(details.filter(x=>x.name==='valueCommit')).toEqual([{name:'valueCommit',detail:{value:4}}]);observations.push({kind:'number',method,accepted,nested,actions,details,value:root.exposes.value.get(),draft:root.exposes.draft.get()});}finally{await root.session.dispose();}
});
it.each(['input','change'] as const)('Field Control keeps controlled-owner canonical reread after %s',async event=>{
 const {make,actions,details,setActionCallback}=runtimeHarness();const field=make(fieldRoot),control=make(fieldControl,field.target,{value:'initial'});await field.session.mount();await control.session.mount();let once=false;
 setActionCallback(name=>{if(name===(event==='input'?'valueChange':'change')&&!once){once=true;control.setProps({value:'owner-response'});}});
 try{control[event]('user-edit');expect(once).toBe(true);expect(control.exposes.value.get()).toBe('owner-response');expect(details.find(x=>x.name===(event==='input'?'valueChange':'change'))?.detail.value).toBe('user-edit');observations.push({kind:'field',event,actions,details,value:control.exposes.value.get()});}finally{await control.session.dispose();await field.session.dispose();}
});
