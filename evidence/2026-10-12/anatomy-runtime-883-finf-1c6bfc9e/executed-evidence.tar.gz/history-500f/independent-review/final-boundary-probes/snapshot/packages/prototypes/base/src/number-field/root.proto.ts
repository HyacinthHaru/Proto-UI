import { FIELD_CONTEXT } from '../field/shared';
import {
  defineAsHook,
  definePrototype,
  type DefHandle,
  type RunHandle,
  type RendererHandle,
} from '@proto.ui/core';
import { finite, range, quantize } from '../progress/range';
import { NUMBER_FIELD_CONTEXT, NUMBER_FIELD_FAMILY } from './shared';
import type {
  NumberFieldRootProps,
  NumberFieldRootExposes,
  NumberFieldRootAsHookContract,
} from './types';
function setup(def: DefHandle<NumberFieldRootProps, NumberFieldRootExposes>) {
  def.anatomy.claim(NUMBER_FIELD_FAMILY, { role: 'root' });
  def.props.define({
    value: { type: 'number', empty: 'fallback' },
    defaultValue: { type: 'number', empty: 'fallback' },
    min: { type: 'number', empty: 'fallback' },
    max: { type: 'number', empty: 'fallback' },
    step: { type: 'number', empty: 'fallback', validator: (v) => Number.isFinite(v) && v > 0 },
    disabled: { type: 'boolean', empty: 'fallback' },
    readOnly: { type: 'boolean', empty: 'fallback' },
    ariaLabel: { type: 'string', empty: 'fallback' },
    name: { type: 'string', empty: 'fallback' },
  });
  def.props.setDefaults({
    defaultValue: 0,
    min: 0,
    max: 100,
    step: 1,
    disabled: false,
    readOnly: false,
    ariaLabel: '',
    name: '',
  });
  const value = def.state.numberDiscrete('value', 0),
    draft = def.state.string('draft', '0'),
    disabled = def.state.bool('disabled', false),
    readOnly = def.state.bool('readOnly', false);
  def.expose.state('value', value);
  def.expose.state('draft', draft);
  def.expose.state('disabled', disabled);
  def.expose.state('readOnly', readOnly);
  def.expose.event('valueChange', { payload: 'json' });
  def.expose.event('valueCommit', { payload: 'json' });
  def.context.provide(NUMBER_FIELD_CONTEXT, {
    value: 0,
    draft: '0',
    min: 0,
    max: 100,
    step: 1,
    disabled: false,
    readOnly: false,
    controlDisabled: false,
    controlReadOnly: false,
    label: '',
    name: '',
  });
  let run: RunHandle<NumberFieldRootProps> | null = null;
  let viewEpoch = 0;
  const normalize = (v: number) => {
    const p = run?.props.get(),
      b = range(p?.min, p?.max);
    return quantize(v, b.min, b.max, finite(p?.step, 1));
  };
  const publish = () => {
    if (!run) return;
    const current = run,
      epoch = viewEpoch;
    const p = run.props.get();
    disabled.set(
      !!p.disabled || !!run.context.tryRead(FIELD_CONTEXT)?.disabled,
      'reason: number policy'
    );
    if (run !== current || viewEpoch !== epoch) return;
    readOnly.set(
      !!p.readOnly || !!run.context.tryRead(FIELD_CONTEXT)?.readOnly,
      'reason: number policy'
    );
    if (run !== current || viewEpoch !== epoch) return;
    run.context.update(NUMBER_FIELD_CONTEXT, {
      value: value.get(),
      draft: draft.get(),
      ...range(p.min, p.max),
      step: finite(p.step, 1),
      disabled: disabled.get(),
      readOnly: readOnly.get(),
      controlDisabled: !!p.disabled,
      controlReadOnly: !!p.readOnly,
      label: p.ariaLabel ?? '',
      name: p.name ?? '',
    });
  };
  const request = (next: number, notify = true) => {
    if (!run || disabled.get() || readOnly.get() || !Number.isFinite(next)) return false;
    const current = run,
      epoch = viewEpoch;
    next = normalize(next);
    if (next === value.get()) return false;
    if (!run.props.isProvided('value')) value.set(next, 'reason: number accepted value');
    if (run !== current || viewEpoch !== epoch) return true;
    publish();
    if (run !== current || viewEpoch !== epoch) return true;
    run.expose.emit('valueChange', { value: next });
    if (run !== current || viewEpoch !== epoch) return true;
    const report =
      notify && run?.anatomy.partsOf(NUMBER_FIELD_FAMILY, 'input')[0]?.getExpose('__fieldInput');
    if (typeof report === 'function') report();
    return true;
  };
  def.expose.method('requestValue', (next) => {
    const current = run,
      epoch = viewEpoch;
    const changed = request(next);
    if (run !== current || viewEpoch !== epoch) return changed;
    draft.set(String(value.get()), 'reason: number public request text');
    if (run !== current || viewEpoch !== epoch) return changed;
    publish();
    return changed;
  });
  const commit = () => {
    if (!run || disabled.get() || readOnly.get()) return;
    const current = run,
      epoch = viewEpoch;
    const text = draft.get().trim();
    if (text !== '' && Number.isFinite(Number(text))) request(Number(text));
    if (run !== current || viewEpoch !== epoch) return;
    draft.set(String(value.get()), 'reason: number canonical commit');
    if (run !== current || viewEpoch !== epoch) return;
    publish();
    if (run !== current || viewEpoch !== epoch) return;
    run.expose.emit('valueCommit', { value: value.get() });
  };
  def.expose.method('requestInput', (text, composing = false) => {
    if (!run || disabled.get() || readOnly.get() || typeof text !== 'string') return false;
    const current = run,
      epoch = viewEpoch;
    draft.set(text, 'reason: number draft input');
    if (run !== current || viewEpoch !== epoch) return true;
    publish();
    if (run !== current || viewEpoch !== epoch) return true;
    if (!composing && text.trim() !== '' && Number.isFinite(Number(text)))
      request(Number(text), false);
    return true;
  });
  def.expose.method('commitValue', commit);
  def.expose.method('stepBy', (direction) => {
    if (!Number.isFinite(direction)) return false;
    const current = run,
      epoch = viewEpoch;
    const changed = request(value.get() + direction * finite(run?.props.get().step, 1));
    if (run !== current || viewEpoch !== epoch) return changed;
    draft.set(String(value.get()), 'reason: number step');
    if (run !== current || viewEpoch !== epoch) return changed;
    publish();
    if (run !== current || viewEpoch !== epoch) return changed;
    if (changed) run?.expose.emit('valueCommit', { value: value.get() });
    return changed;
  });
  def.context.trySubscribe(FIELD_CONTEXT, () => publish());
  let initialValue: number = 0;
  def.expose.method('resetValue', () => {
    if (!run) return false;
    const next = normalize(initialValue);
    if (!run.props.isProvided('value')) value.set(next, 'reason: number-field value reset');
    draft.set(String(value.get()), 'reason: number reset text');
    publish();
    if (run.props.isProvided('value')) run.expose.emit('valueChange', { value: next });
    return true;
  });
  def.lifecycle.onCreated((current) => {
    run = current;
    value.set(
      normalize(
        finite(
          current.props.isProvided('value')
            ? current.props.get().value
            : current.props.get().defaultValue,
          0
        )
      ),
      'reason: number initialize'
    );
    draft.set(String(value.get()), 'reason: number initialize text');
    initialValue = value.get();
    publish();
  });
  def.lifecycle.onMounted((current) => {
    run = current;
    publish();
  });
  def.props.watchAll((current, next, previous) => {
    run = current;
    const valueChanged =
      next.value !== previous.value ||
      next.min !== previous.min ||
      next.max !== previous.max ||
      next.step !== previous.step;
    if (valueChanged) {
      value.set(
        normalize(
          current.props.isProvided('value') ? finite(current.props.get().value, 0) : value.get()
        ),
        'reason: number controlled or bounds'
      );
      draft.set(String(value.get()), 'reason: number owner text');
    }
    publish();
  });
  def.lifecycle.onUnmounted(() => {
    viewEpoch++;
    run = null;
  });
  def.lifecycle.onBeforeDispose(() => {
    run = null;
  });
  return (r: RendererHandle<any>) => r.slot();
}
export const asNumberFieldRoot = defineAsHook<
  NumberFieldRootProps,
  NumberFieldRootExposes,
  NumberFieldRootAsHookContract
>({ name: 'as-number-field-root', setup });
export default definePrototype({ name: 'base-number-field-root', setup });
