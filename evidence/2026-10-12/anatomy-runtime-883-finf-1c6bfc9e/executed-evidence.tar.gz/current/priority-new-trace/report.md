# 新 C 退休边界只读核验

结论：准确 pending merge tree `450026e4faf345f9ae96b1f88698bba01612511b` 上有 4 项可复现 P2；本地判断为 **partial / ABSTAIN**。这不是 GitHub review，也不接受整个 Finf。

源码来自 `500f1326` 与 foundation `661dcbcf` 的组合树。所有实际加载的 336 个 tracked inputs 均逐项 SHA256 / Git blob 对账到该树；私有 loader 不读取 root 随后正在编辑的产品字节。完整清单见 [binding.json](binding.json)。普通运行使用 Node 24.21.0、pnpm 10.32.1、Vitest 2.1.9；没有运行浏览器、构建或全量 suite。

- **ISSUE883-FORM-VALIDATION-THROW-001** — `form/root.proto.ts:148`：唯一 Error 从 Field validate 原样抛出，但 Form pending 留为 true；稍后的真实 Anatomy Field 通知会把已放弃请求变为 submit。正常控制通过；旧 traversal 先接受 nested 新请求再抛错的控制也通过，修复只能取消仍由旧 invocation 拥有的 waiting/pending。
- **ISSUE883-SEARCH-POPUP-RETIREMENT-001** — `search-primitives/family.ts:188`：Autocomplete / Combobox 的 openPopup 与 setInputValue 在 open observer 退休后仍发旧事件；dispose 会在 publish 读取已 disposed State。Command 为 inline，openPopup/close 无 popup 变化，评论中“Command popup”不成立。requestQuery / __navigate 的后续操作也须沿调用链复核，不能仅在 helper return。
- **ISSUE883-MENU-ROOT-RETIREMENT-001** — `menu-primitives/family.ts:121`：Menubar / Navigation Menu 在 value observer 退休后继续 valueChange 或触发 ANATOMY_PHASE_VIOLATION。合法 created、从 defaultValue 关闭的 control 证明不能用“必须 mounted”来挡住缺陷；terminal 失效也须覆盖未首次 mount 的 owner。
- **ISSUE883-DRAWER-SNAP-RETIREMENT-001** — `drawer/snap.ts:210`：真实 Root / Content 已取得 admission、open、fractional extent；公开 requestSnapPoint 与 typed axis-end 都可在 snapPoint observer 退休后发旧 snapPointChange 或访问 disposed State。修复还须停止轴输入 caller 后续 cancel；不能更改 geometry、snap 模型、threshold 或 admission lease。

校准后的 40 个小型控制为 **27 failed / 13 passed**，未报告 unhandled。`priority-run.log` 是 13/7；`menu-drawer-v2-run.log` 是 14/6。第一版 `menu-drawer-run.log` 的 18/2 全部保留：其中四个 created 菜单“打开尚未注册 Trigger”的前提不成立；两个 Drawer normal 断言误计启动 `beforeEnter`。修正只变私有探针：created 使用已有 defaultValue 的合法关闭，Drawer 保留全部事件但仅判定本次 snapPointChange。不能把这六项计作产品失败。

权威边界：active `C-LIFECYCLE-0008` 区分 alive view detach 与 terminal dispose；`C-LIFECYCLE-0002/0005`、`C-STATE-0011/0012`、`C-EXPOSE-STATE-0001`、Anatomy 与 Drawer 对应实体均按 **draft** 使用。旧 `form-completion` / `search-selection-completion` / `notification-completion` 是未编目的 draft；旧 Search 文档明确没有认证 State/context 事件前重入，旧 Notification 仅列 Menu Trigger 而非 Root。本次需要最小 draft 明确新 caller 边界，不能把测试反例冒称已有稳定产品保证。特别保留 broad lifecycle callback error-recovery 未决，不改 Runtime/State/Event 的共同策略。

Form Field 是同 family 的公开角色 fixture；Menu 使用真实 Root/Trigger；Drawer 使用真实 Root/Content 和正式 admission，但 axis samples 由测试送入公开 exposed consumer seam。没有 native pointer、几何、浏览器焦点、AT 或全 Adapter 结论。Controlled proposals、Search keyboard/close、Drawer 其它 notification 点目前是源码检查和修复时应验证的范围，不虚构已经执行。

既有 `500f` 零剩余发现仅适用于上一轮声明范围，不能覆盖这些新反馈。四份产品文件虽然与 500f 同字节，本轮实跑仍单独绑定新组合树；其后 root 修复的 working bytes 尚不在这份结论内。
