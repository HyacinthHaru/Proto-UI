import { afterAll, expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import { runtimeHarness } from './runtime-harness';
import * as menubar from '[workspace]/packages/prototypes/base/src/menubar';
import * as navigation from '[workspace]/packages/prototypes/base/src/navigation-menu';
import * as drawer from '[workspace]/packages/prototypes/base/src/drawer';
const observations:any[]=[];
afterAll(()=>writeFileSync(__dirname+'/menu-drawer-v2-observations.json',JSON.stringify(observations,null,2)));
const errorFact=(error:any)=>error&&({name:error.name,code:error.code,message:error.message,stack:error.stack});
for(const [family,rootProto,triggerProto] of [['menubar',menubar.menubarRoot,menubar.menubarTrigger],['navigation-menu',navigation.navigationMenuRoot,navigation.navigationMenuTrigger]] as const)
for(const lifetime of ['mounted','created'] as const)
it.each(lifetime==='mounted'?['normal','unmount','dispose','remount'] as const:['normal','dispose'] as const)(`${family} ${lifetime} value observer %s`,async operation=>{
 const {make,actions}=runtimeHarness();const requested=lifetime==='created'?'':'tools';const root=make(rootProto,null,lifetime==='created'?{defaultValue:'tools'}:{}),trigger=make(triggerProto,root.target,{value:'tools'});
 if(lifetime==='mounted'){await root.session.mount();await trigger.session.mount();}
 let once=false;const waits:Promise<void>[]=[];
 root.exposes.value.subscribe((e:any)=>{if(e.type!=='next'||e.next!==requested||once||operation==='normal')return;once=true;waits.push(root.session[operation==='dispose'?'dispose':'unmount']());if(operation==='remount')waits.push(root.session.mount());});
 let error:any,accepted:any;
 try{try{accepted=root.call(()=>root.exposes.requestValue(requested));}catch(e){error=e;}await Promise.all(waits);
  observations.push({kind:'menu',family,lifetime,operation,accepted,error:errorFact(error),actions:[...actions],phase:root.session.mountPhase,epoch:root.session.mountEpoch,instance:root.session.instancePhase});
  expect(error).toBeUndefined();expect(accepted).toBe(true);expect(actions).toEqual(operation==='normal'?['valueChange']:[]);
 }finally{await trigger.session.dispose();await root.session.dispose();}
});
for(const entry of ['requestSnapPoint','axis-end'] as const)
it.each(['normal','unmount','dispose','remount'] as const)(`Drawer ${entry} snap observer %s`,async operation=>{
 const {make,actions}=runtimeHarness();const root=make(drawer.drawerRoot,null,{defaultOpen:true});
 const content=make(drawer.drawerContent,root.target,{snapPoints:[0.5,1],defaultSnapPoint:1,enterDuration:0,leaveDuration:0});
 await root.session.mount();await content.session.mount();let once=false;const waits:Promise<void>[]=[];
 const initial={open:content.exposes.open.get(),snapPoint:content.exposes.snapPoint.get(),extentValid:content.exposes.extentValid.get()};
 content.exposes.snapPoint.subscribe((e:any)=>{if(e.type!=='next'||e.next!==0.5||once||operation==='normal')return;once=true;waits.push(content.session[operation==='dispose'?'dispose':'unmount']());if(operation==='remount')waits.push(content.session.mount());});
 let error:any;
 try{try{content.call(()=>{if(entry==='requestSnapPoint')content.exposes.requestSnapPoint(0.5);else{content.exposes.__onAxisInput({phase:'start',position:1,delta:0,totalDelta:0});content.exposes.__onAxisInput({phase:'end',position:0.5,delta:-0.5,totalDelta:-0.5});}});}catch(e){error=e;}await Promise.all(waits);
  observations.push({kind:'drawer',entry,operation,initial,error:errorFact(error),actions:[...actions],phase:content.session.mountPhase,epoch:content.session.mountEpoch,instance:content.session.instancePhase});
  expect(initial).toEqual({open:true,snapPoint:1,extentValid:true});expect(error).toBeUndefined();expect(actions.filter(name=>name==='snapPointChange')).toEqual(operation==='normal'?['snapPointChange']:[]);
 }finally{await content.session.dispose();await root.session.dispose();}
});
