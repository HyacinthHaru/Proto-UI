import { afterAll, expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import { definePrototype } from '@proto.ui/core';
import { runtimeHarness } from './runtime-harness';
import { formRoot } from '[workspace]/packages/prototypes/base/src/form';
import { FORM_FAMILY } from '[workspace]/packages/prototypes/base/src/form/shared';
import * as autocomplete from '[workspace]/packages/prototypes/base/src/autocomplete';
import * as combobox from '[workspace]/packages/prototypes/base/src/combobox';
import * as command from '[workspace]/packages/prototypes/base/src/command';
const observations:any[]=[];
afterAll(()=>writeFileSync(__dirname+'/priority-observations.json',JSON.stringify(observations,null,2)));
const errorFact=(error:any)=>error&&({name:error.name,code:error.code,message:error.message,stack:error.stack});
for(const operation of ['normal','throw','nested-then-throw'] as const) it('Form validation '+operation,async()=>{
 const {make,actions}=runtimeHarness();const sentinel=new Error('review unique validation failure');let form:any,first=true,fieldPending=false,nested:any;
 const fieldProto=definePrototype({name:'review-throwing-field',setup(def){
  def.anatomy.claim(FORM_FAMILY,{role:'field'});let current:any;def.lifecycle.onCreated(run=>current=run);
  def.expose.method('__formField',()=>({name:'field',value:'stable',disabled:false,available:true,implicitSubmit:false,validity:{status:'valid',invalid:false,pending:fieldPending,dirty:false,touched:false,filled:true,focused:false,flags:[],errors:[]}}));
  def.expose.method('validate',()=>{if(!first||operation==='normal')return;first=false;if(operation==='nested-then-throw'){fieldPending=true;nested=form.call(()=>form.exposes.requestSubmit());}throw sentinel;});
  def.expose.method('notify',()=>{fieldPending=false;const notify=current.anatomy.partsOf(FORM_FAMILY,'root')[0].getExpose('__fieldChanged');notify();});
 }});
 form=make(formRoot);const field=make(fieldProto,form.target);await form.session.mount();await field.session.mount();
 let error:any,result:any;
 try{
  try{result=form.call(()=>form.exposes.requestSubmit());}catch(e){error=e;}
  const beforeNotify={pending:form.exposes.pending.get(),submitted:form.exposes.submitted.get(),actions:[...actions]};
  field.call(()=>field.exposes.notify());
  const afterNotify={pending:form.exposes.pending.get(),submitted:form.exposes.submitted.get(),actions:[...actions]};
  observations.push({kind:'form',operation,result,nested,sameError:error===sentinel,error:errorFact(error),beforeNotify,afterNotify});
  if(operation==='normal'){expect(error).toBeUndefined();expect(result).toBe(true);expect(beforeNotify).toEqual({pending:false,submitted:true,actions:['submit']});expect(afterNotify.actions).toEqual(['submit']);}
  else{expect(error).toBe(sentinel);if(operation==='throw'){expect(beforeNotify.pending).toBe(false);expect(afterNotify.actions).toEqual([]);}else{expect(nested).toBe(true);expect(beforeNotify.pending).toBe(true);expect(afterNotify.actions).toEqual(['submit']);}}
 }finally{await field.session.dispose();await form.session.dispose();}
});
for(const [family,proto] of [['autocomplete',autocomplete.autocompleteRoot],['combobox',combobox.comboboxRoot]] as const)
for(const entry of ['openPopup','setInputValue'] as const)
it.each(['normal','unmount','dispose','remount'] as const)(`${family} ${entry} open observer %s`,async operation=>{
 const {make,actions}=runtimeHarness();const root=make(proto,null,{defaultOpen:false});await root.session.mount();const waits:Promise<void>[]=[];let once=false;
 root.exposes.open.subscribe((e:any)=>{if(e.type!=='next'||!e.next||once||operation==='normal')return;once=true;waits.push(root.session[operation==='dispose'?'dispose':'unmount']());if(operation==='remount')waits.push(root.session.mount());});
 let error:any;
 try{try{root.call(()=>entry==='openPopup'?root.exposes.openPopup():root.exposes.setInputValue('needle'));}catch(e){error=e;}
  await Promise.all(waits);observations.push({kind:'search',family,entry,operation,error:errorFact(error),actions:[...actions],phase:root.session.mountPhase,epoch:root.session.mountEpoch,instance:root.session.instancePhase});
  expect(error).toBeUndefined();expect(actions).toEqual(operation==='normal'?(entry==='openPopup'?['openChange']:['openChange','inputValueChange']):[]);
 }finally{await root.session.dispose();}
});
it('Command remains inline and openPopup is a no-op',async()=>{const {make,actions}=runtimeHarness();const root=make(command.commandRoot);await root.session.mount();let observed=0;root.exposes.open.subscribe((e:any)=>{if(e.type==='next')observed++;});try{root.call(()=>root.exposes.openPopup());root.call(()=>root.exposes.close());expect(root.exposes.open.get()).toBe(true);expect(observed).toBe(0);expect(actions).toEqual([]);observations.push({kind:'command-inline',open:true,observed,actions});}finally{await root.session.dispose();}});
