准确提交 `b1e62928c205e318da615a77b4e457f1736fd7de` / tree `24cebffe7e6e8a2547b5106edde2cc9674e77d69` 已绑定，parent为`1c6bfc9e433d19990c01bbc5fdfbdcb43ff5dbd8`。两文件commit bytes与已审快照完全一致，SSH签名/Author/Committer/匹配DCO/no-coauthor均核验。

新8case的325个loaded tracked inputs全等于b1e；来源仍为1c6+候选snapshot，保留原19:06:14 +08:00实际执行。旧40case的336个inputs也逐项等于b1e，本次2个改动路径交集为0，因此**没有重跑**；来源仍为450026+四snapshot，保留原17:52:16 +08:00执行。

没有剩余具体源码finding，保持partial/ABSTAIN。没有碰root当前general/fullcommand句柄，也未将新CI或DCO App提前计绿。详细逐项Gitblob/SHA见同名JSON。
