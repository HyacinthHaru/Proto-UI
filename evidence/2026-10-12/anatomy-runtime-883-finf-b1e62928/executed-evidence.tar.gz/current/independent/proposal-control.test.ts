import {afterAll,it,expect} from 'vitest';
import {writeFileSync} from 'node:fs';
import {runtimeHarness} from './payload-runtime-harness';
import {sliderValuesRoot} from '[workspace]/packages/prototypes/base/src/slider';
const observations:any[]=[];afterAll(()=>writeFileSync(__dirname+'/proposal-observations.json',JSON.stringify(observations,null,2)));
for(const controlled of [false,true])it(`phase failure preserves previous proposal and owner controlled=${controlled}`,async()=>{
 const {make,eventDetails}=runtimeHarness();const root=make(sliderValuesRoot,null,controlled?{value:10}:{defaultValue:10});await root.session.mount();const error=new Error('phase prior-proposal failure');let caught:any;
 try{
  expect(root.call(()=>root.exposes.requestValue(20))).toBe(true);
  const priorOwner=root.call(()=>root.exposes.getValue());
  const off=root.exposes.phase.subscribe((e:any)=>{if(e.type==='next'&&e.next==='notifying')throw error;});
  try{root.call(()=>root.exposes.requestValue(30));}catch(e){caught=e;}finally{off();}
  const beforeCompletion={sameError:caught===error,phase:root.exposes.phase.get(),owner:root.call(()=>root.exposes.getValue()),lateCancel:root.call(()=>root.exposes.cancelValueChange()),events:[...eventDetails]};
  const firstCommit=root.call(()=>root.exposes.commitValue()),secondCommit=root.call(()=>root.exposes.commitValue());
  const committed=eventDetails.filter(x=>x.name==='valueCommit');const retry=root.call(()=>root.exposes.requestValue(40));
  observations.push({controlled,priorOwner,beforeCompletion,firstCommit,secondCommit,committed,retry,finalOwner:root.call(()=>root.exposes.getValue()),finalPhase:root.exposes.phase.get()});
  expect(caught).toBe(error);expect(priorOwner).toBe(controlled?10:20);expect(beforeCompletion.owner).toBe(priorOwner);expect(beforeCompletion.phase).toBe('notifying');expect(beforeCompletion.lateCancel).toBe(false);expect(beforeCompletion.events.map(x=>x.name)).toEqual(['valueChange']);expect(firstCommit).toBe(true);expect(secondCommit).toBe(false);expect(committed).toHaveLength(1);expect(committed[0].payload.value).toBe(20);expect(retry).toBe(true);expect(root.call(()=>root.exposes.getValue())).toBe(controlled?10:40);expect(root.exposes.phase.get()).toBe('idle');
 }finally{await root.session.dispose();}
});
