import {afterAll,it,expect} from 'vitest';
import {writeFileSync} from 'node:fs';
import {definePrototype} from '@proto.ui/core';
import {runtimeHarness} from './runtime-harness';
import {sliderValuesRoot} from '[workspace]/packages/prototypes/base/src/slider';
import {asTransition} from '[workspace]/packages/prototypes/base/src/transition';
import {createTransitionMachine} from '[workspace]/packages/prototypes/base/src/transition/machine';
const observations:any[]=[];afterAll(()=>writeFileSync(__dirname+'/observations.json',JSON.stringify(observations,null,2)));
for(const failure of [false,true])it(`Slider Values phase observer throws=${failure}`,async()=>{
 const {make,actions}=runtimeHarness();const root=make(sliderValuesRoot,null,{defaultValue:10});await root.session.mount();const sentinel=new Error('unique phase observer failure');let triggered=0,error:any,first:any;
 const off=root.exposes.phase.subscribe((e:any)=>{if(e.type==='next'&&e.next==='notifying'){triggered++;if(failure)throw sentinel;}});
 try{try{first=root.call(()=>root.exposes.requestValue(20));}catch(e){error=e;}off();const beforeRetry={phase:root.exposes.phase.get(),ready:root.exposes.ready.get(),value:root.call(()=>root.exposes.getValue())};const second=root.call(()=>root.exposes.requestValue(30));
  observations.push({kind:'slider-values',failure,triggered,sameError:error===sentinel,error:error&&{message:error.message,stack:error.stack},first,beforeRetry,second,afterRetry:{phase:root.exposes.phase.get(),value:root.call(()=>root.exposes.getValue())},actions,instance:root.session.instancePhase,mount:root.session.mountPhase});
  if(failure)expect(error).toBe(sentinel);else expect(error).toBeUndefined();expect(second).toBe(true);expect(root.call(()=>root.exposes.getValue())).toBe(30);
 }finally{off();await root.session.dispose();}
});
for(const failure of [false,true])it(`actual cold Transition host beforeEnter sink throws=${failure}`,async()=>{
 const {make,actions,setActionCallback}=runtimeHarness();const sentinel=new Error('unique beforeEnter sink failure');let throws=0;const proto=definePrototype({name:'review-cold-public-hook',setup(){asTransition().configure({coldEntryPreparation:true,appear:true});}});
 const owner=make(proto,null,{defaultOpen:true});setActionCallback(name=>{if(name==='beforeEnter'&&failure){throws++;throw sentinel;}});await owner.session.mount();const start=owner.exposes.transitionState.get();let error:any;
 try{try{owner.call(()=>owner.exposes.capturePreparation()?.());}catch(e){error=e;}const released=owner.exposes.transitionState.get();owner.call(()=>owner.exposes.complete());observations.push({kind:'actual-transition',failure,start,released,final:owner.exposes.transitionState.get(),throws,error:error&&{message:error.message},actions:[...actions]});expect(start).toBe('preparing');expect(error).toBeUndefined();expect(released).toBe('entering');expect(owner.exposes.transitionState.get()).toBe('entered');expect(throws).toBe(failure?1:0);
 }finally{await owner.session.dispose();}
});
for(const failure of [false,true])it(`internal cold-machine driver observation throws=${failure}`,()=>{
 let state:any='closed',emitCount=0;const events:string[]=[],presence:boolean[]=[],timers:any[]=[];const sentinel=new Error('direct driver failure');
 const m=createTransitionMachine({getState:()=>state,setState:s=>state=s,getInterrupt:()=> 'reverse',requiresColdPreparation:()=>true,getDuration:()=>100,setViewPresent:p=>presence.push(p),schedule:(_ms,fn)=>{const t={fn,canceled:false};timers.push(t);return{cancel(){t.canceled=true;}};},emit:e=>{events.push(e);if(e==='beforeEnter'&&failure&&emitCount++===0)throw sentinel;}});
 m.initialize(true,true);m.mounted();const release=m.capturePreparation()!;let error:any;try{release();}catch(e){error=e;}const afterFirst=state;m.enter();release();const afterRetries=state;observations.push({kind:'internal-driver-only',failure,errorSame:error===sentinel,afterFirst,afterRetries,events,presence,timers:timers.length});if(failure){expect(error).toBe(sentinel);expect(afterRetries).toBe('preparing');expect(timers).toHaveLength(0);}else{expect(error).toBeUndefined();expect(afterRetries).toBe('entering');expect(timers).toHaveLength(1);}m.dispose();
});
