// Prepared, not executed. Caller supplies a browser from the repository's
// browser-harness.launchBrowser(), the served fixture URL and an output path.
import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';

export async function runKeyboardOwnerCases(browser, url, outputFile) {
  const cases = [];
  const cleanupErrors = [];
  for (const input of [
    { label: 'Enter', nativeKey: 'Enter' },
    { label: 'Space', nativeKey: ' ' },
  ]) {
    const context = await browser.newContext({ viewport: { width: 800, height: 600 } });
    const page = await context.newPage();
    const pageErrors = [];
    const consoleErrors = [];
    page.on('pageerror', (error) =>
      pageErrors.push({ message: error.message, stack: error.stack })
    );
    page.on('console', (message) => {
      if (message.type() === 'error') consoleErrors.push(message.text());
    });
    let stage = 'bootstrap';
    let before;
    let after;
    try {
      await page.goto(url, { waitUntil: 'load' });
      assert.equal(
        await page.evaluate(() => typeof window.__keyboardOwnerFixture?.read),
        'function'
      );
      stage = 'focus';
      await page.locator('#child').click();
      before = await page.evaluate(() => window.__keyboardOwnerFixture.read());
      assert.equal(before.activeElement, 'child');
      stage = 'native-key';
      await page.keyboard.press(input.label);
      after = await page.evaluate(() => window.__keyboardOwnerFixture.read());
      stage = 'native-input-control';
      assert.deepEqual(pageErrors, []);
      const keys = after.nativeEvents
        .slice(before.nativeEvents.length)
        .filter((event) => event.type === 'keydown' && event.key === input.nativeKey);
      assert.equal(keys.length, 1);
      assert.equal(keys[0].isTrusted, true);
      assert.equal(keys[0].target, 'child');
      const current = after.deliveries.filter((event) => event.nativeId === keys[0].id);
      const counts = {
        root: current.filter((event) => event.kind === 'child.rootKey').length,
        global: current.filter((event) => event.kind === 'child.globalKey').length,
      };
      stage = 'router-assert';
      assert.deepEqual(counts, { root: 1, global: 1 });
      assert.deepEqual(pageErrors, []);
      cases.push({
        key: input.label,
        outcome: 'passed',
        before,
        after,
        counts,
        pageErrors,
        consoleErrors,
      });
    } catch (error) {
      cases.push({
        key: input.label,
        outcome: stage === 'router-assert' ? 'assertion-failed' : 'execution-error',
        stage,
        error: { message: error.message, stack: error.stack },
        before,
        after,
        pageErrors,
        consoleErrors,
      });
    } finally {
      await page
        .evaluate(() => window.__keyboardOwnerFixture?.dispose())
        .catch((error) => {
          cleanupErrors.push({
            key: input.label,
            phase: 'fixture-dispose',
            message: error.message,
          });
        });
      await context.close().catch((error) => {
        cleanupErrors.push({ key: input.label, phase: 'context-close', message: error.message });
      });
    }
  }
  const result = {
    browser: browser.version(),
    cases,
    passed: cases.filter((x) => x.outcome === 'passed').length,
    cleanupErrors,
    success: cases.every((x) => x.outcome === 'passed') && cleanupErrors.length === 0,
  };
  await writeFile(outputFile, JSON.stringify(result, null, 2) + '\n');
  return result;
}
