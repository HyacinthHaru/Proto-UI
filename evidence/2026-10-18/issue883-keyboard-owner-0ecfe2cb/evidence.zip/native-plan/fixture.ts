// Private host-contract fixture. Imports resolve to the actual repository sources.
// This is not a Prototype-family demo or an Adapter/AT acceptance claim.
import { createWebProtoEventRouter } from '@fixture/router-source';
import { createInstanceTreeMarkers } from '@fixture/instance-tree-source';

const tree = createInstanceTreeMarkers('@proto.ui/adapter-vue/__proto_instance');
const proto = { name: 'native-keyboard-child-owner', setup: () => undefined };
const parent = document.createElement('div');
const child = document.createElement('div');
parent.id = 'parent';
child.id = 'child';
parent.textContent = 'Parent with a press consumer';
child.textContent = 'Focused child with a key.down consumer';
child.tabIndex = 0;
parent.append(child);
document.body.append(parent);
const parentToken = tree.markProtoInstance(parent, proto);
const childToken = tree.markProtoInstance(child, proto);
const outer = createWebProtoEventRouter({
  rootEl: parent,
  instanceToken: parentToken,
  isEnabled: () => true,
});
const inner = createWebProtoEventRouter({
  rootEl: child,
  instanceToken: childToken,
  isEnabled: () => true,
});

const nativeIds = new WeakMap<Event, number>();
let nextId = 0;
const idFor = (event: Event) => {
  let id = nativeIds.get(event);
  if (id === undefined) nativeIds.set(event, (id = ++nextId));
  return id;
};
const targetId = (target: EventTarget | null) =>
  target instanceof Element ? target.id || target.tagName : String(target);
const nativeEvents: unknown[] = [];
const deliveries: unknown[] = [];
const observeNative = (event: KeyboardEvent) => {
  nativeEvents.push({
    id: idFor(event),
    type: event.type,
    key: event.key,
    isTrusted: event.isTrusted,
    target: targetId(event.target),
    composedPath: event.composedPath().map(targetId),
    at: performance.now(),
  });
};
document.addEventListener('keydown', observeNative, { capture: true, passive: true });
document.addEventListener('keyup', observeNative, { capture: true, passive: true });
const observeDelivery = (kind: string) => (event: Event) => {
  // nativeEvent is the actual host-local payload field in createProtoEventPayload.
  const native = (event as CustomEvent).detail.nativeEvent as KeyboardEvent;
  deliveries.push({
    kind,
    nativeId: idFor(native),
    key: native.key,
    isTrusted: native.isTrusted,
    target: targetId(native.target),
    at: performance.now(),
  });
};
outer.rootTarget.addEventListener('press.commit', observeDelivery('parent.press'));
inner.rootTarget.addEventListener('key.down', observeDelivery('child.rootKey'));
inner.globalTarget.addEventListener('key.down', observeDelivery('child.globalKey'));

// This object is fixture-owned recording/control, not a product flag or exposed API.
(window as any).__keyboardOwnerFixture = {
  read: () => ({
    activeElement: targetId(document.activeElement),
    parentConnected: parent.isConnected,
    childConnected: child.isConnected,
    nativeEvents,
    deliveries,
  }),
  dispose: () => {
    inner.dispose();
    outer.dispose();
    document.removeEventListener('keydown', observeNative, true);
    document.removeEventListener('keyup', observeNative, true);
    tree.unbindProtoInstance(childToken, child);
    tree.unbindProtoInstance(parentToken, parent);
    parent.remove();
  },
};
