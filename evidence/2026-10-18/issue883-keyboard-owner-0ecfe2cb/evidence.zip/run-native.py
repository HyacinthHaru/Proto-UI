from pathlib import Path
import http.server,threading,functools,subprocess,json,datetime,hashlib
r=Path(__file__).parent;w=Path('<SOURCE_ROOT>');dist=w/'apps/www/dist'
assert dist.is_dir()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
files=[{'path':str(p.relative_to(dist)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(dist.rglob('*')) if p.is_file()]
(r/'website-build/members.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip(),'files':files,'boundary':'Complete local static build output inventory, not a dependency closure'},indent=2)+'\n')
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(dist)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url='http://127.0.0.1:'+str(server.server_port);receipt={'startedAt':now(),'baseUrl':url,'root':str(dist),'files':len(files),'jobs':[]}
try:
 for name,tests,selector in [('head-native-C',['demo-collapsible-projections.browser.test.ts','demo-shadcn-tooltip.browser.test.ts','demo-brutalist-button.browser.test.ts','demo-field-family.browser.test.ts'],None),('head-native-settings',['home-demo-runtime.browser.test.ts'],'completes the settings task')]:
  env={'PROTO_UI_BROWSER_BASE_URL':url,'CHROME_PATH':'<CHROMIUM_APP>/Contents/MacOS/Google Chrome','PROTO_UI_RUNTIME_EVIDENCE_DIR':str(r/name/'evidence')};args=['corepack','pnpm@10.32.1','exec','vitest','run',*['apps/www/src/content/docs/zh-cn/'+p for p in tests]]
  if selector:args+=['--testNamePattern='+selector]
  args+=['--maxWorkers=1','--minWorkers=1','--reporter=json','--outputFile='+str(r/name/'vitest.json')]
  code=subprocess.run(['python3',str(r/'run-check.py'),name,json.dumps(env),*args],cwd=w).returncode;receipt['jobs'].append({'name':name,'exit':code})
  if code:break
finally:
 server.shutdown();server.server_close();thread.join();receipt.update(endedAt=now(),serverClosed=True);(r/'native-server-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(0 if all(j['exit']==0 for j in receipt['jobs'])and len(receipt['jobs'])==2 else 1)
