# Final keyboard-owner P2 source binding

**No specific finding; partial / ABSTAIN.** Signed commit `0ecfe2cb76236aa37fee78730423a72a0ddebb7c` has tree `3db37329aae1b2cc3466ab08852b2a9eea6b9d52` and parent `0b68e7ec96f5857a6e1b7b6463b192c695ee753f`. The working tree was clean at this read-only check.

Exactly two paths changed: the router’s claim condition and the43-line Enter/Space regression insertion, for48 additions and1 deletion. Both committed Git blobs exactly equal the reviewed working candidate:

- Router SHA256: `921f1fe504efe7fed8a549a6a16d0eb3398b5381985260cbc72b0c36462b4d5e`.
- Test SHA256: `521fb46243202f84204a36c9259959d91c3ee7eb293df39053cfbd8b5555326d`.

All other tracked paths and modes remain equal to the parent. `git verify-commit` succeeds with the existing SSH signing key. Author and Committer are both **HyacinthHaru <hyacinth@haru.ac>**, with one matching DCO and no co-author. The saved PR921 readback names this exact new head; this reviewer made no new remote request or write.

The root’s identical-fixture result remains **15 passed /2 failed →17 passed /0 failed**, with all original15 cases retained. Types are **934 files /0 errors /0 warnings /14 hints**. Those runs occurred before commit at0b68 plus the frozen two-file candidate; this exact Git binding does not relabel them as postcommit execution. The broader98-file run, new native validation and new canonical CI are outside this report’s reviewed results.

The claim-only fix prevents a semantically non-owning physical ancestor from installing the new cross-root keyboard lock. It keeps the valid Item claim before callbacks can retire the view and return focus to Trigger. It does not redefine legacy ancestor press delivery, listener multiplicity, once/abort behavior, global key ordering or unclaimed Portal fallback. The initial broader whole-helper rejection suggestion was explicitly withdrawn as unnecessary for the reported P2.

The trace handoff validator returned terminal=true and blocked=false. That workflow result and this independent source binding do not constitute GitHub approval, a backend identity attestation or full acceptance. No reviewer source edit, test, browser, commit or external write occurred.
