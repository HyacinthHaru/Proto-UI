# Keyboard-owner P2: independent read-only review

**No specific finding in the current two-file candidate; partial / ABSTAIN.** The production candidate is the smallest change needed for the reported false keyboard-owner claim. The reviewer did not edit source or run tests.

The reviewed source adds `shouldRouteToCurrentRoot(native)` only to the condition that writes `KEYBOARD_PRESS_OWNER`. It leaves dispatch, per-root seen state, follow-up-click suppression, global key ordering and listener lifecycle code unchanged. Router SHA256: `921f1fe504efe7fed8a549a6a16d0eb3398b5381985260cbc72b0c36462b4d5e`; test SHA256: `521fb46243202f84204a36c9259959d91c3ee7eb293df39053cfbd8b5555326d`.

The root’s formal identical fixture is **15 passed / 2 failed → 17 passed**. Both original failures are the marked child Enter/Space cases: root key.down is0 while global key.down is1, against expected1/1. The new43-line block uses actual instance markers and router functions in the existing HappyDOM fixture. Removing it restores every original15-case byte. These are synthetic host-unit events, not new native-browser evidence.

The ordering issue is real. A physical ancestor and the global containment tail can enter the helper before an ownership check. With the candidate, a non-owning ancestor can retain its historical press delivery but cannot acquire the new cross-root lock. Its later global path returns at the existing per-root seen check, so it cannot reacquire that lock during the same event. The child’s key.down route remains available.

A valid Item owner still records the native-event owner **before** its callback can retire the Item and return focus to Trigger. Moving the claim after callback delivery would reopen the original Select failure. Fresh native events and unclaimed Portal/active fallback keep their original paths. Root key routing and onGlobal remain distinct.

The earlier suggestion to reject the whole helper was broader than this P2: it would also change ancestor press delivery and once consumption. It is withdrawn as a requirement here. The current regression does not require a new universal press-delivery policy. Keeping legacy behavior does not certify every historical routing choice as a stable guarantee.

The exact baseline functions are `createProxyTarget` and `createRebindableEventTarget`. `__hasProtoListeners` is live registration demand, not business-level acceptance. There is no existing `consumer.accept` return protocol to infer or expose; `dispatchEvent`’s boolean is not a handled signal. Once/abort/capture cleanup and distinct EventKernel registration wrappers remain unchanged. Portable Event options remain prohibited; direct Adapter EventTarget tests do not expand that API.

Draft `C-EVENT-0003-E` governs the root/global owner boundary; `C-EVENT-0005` preserves independent registrations; `C-AS-TRIGGER-0001` preserves group, surface and opaque identity distinctions. Their lifecycle/status is unchanged. The suitable description is **“a semantically admitted route with a live press registration pins the native keyboard owner before callback delivery.”**

The original Select retirement/fresh-event case, unmarked empty-descendant case, unclaimed Portal case, registration fanout, once/abort/capture controls, follow-up click cleanup and remaining original tests all stay in the17-case result. The new tests do not assert a new ancestor press count policy. Wider validation, native evidence, exact commit/CI binding and maintainer acceptance remain separate.
