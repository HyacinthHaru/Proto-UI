# Keyboard-owner P2: executed evidence review

**No source or count mismatch found; partial / ABSTAIN.** This review inspected the actual native pair, source graph, existing formal tests and new postcommit runs. It ran no tests or browser and did not view the48capture pixels.

The native pair ran **2026-10-18 13:18:33.771–13:18:36.129 UTC**, on clean `0ecfe2cb76236aa37fee78730423a72a0ddebb7c`, Node24.21.0, esbuild0.25.12 and Chrome155.0.8059.80. The actual browser metafile has **four tracked inputs and one private fixture per arm**. Baseline overrides only `web-event-router.ts` with its exact0b68Gitblob; the other three tracked inputs come from0ecfe and are byte-identical to0b68. The same frozen fixture and driver run both arms. The HTML shells match.

For both Enter and Space, the driver verifies one trusted native keydown at the focused child and counts deliveries for that same native-event identity. Baseline records **root0/global1** and fails the router assertion for both keys; candidate records **root1/global1** and passes both. Parent press remains observed once in both arms, which corroborates the chosen claim-only compatibility boundary. The pair runner’s exit0 means the expected negative/positive outcomes were obtained; it does not turn baseline into a pass.

This is real Chrome input into the actual shared router and marker implementation on a private host-contract page. It is not a Vue framework mount merely because the real marker namespace is Vue, nor a full four-Adapter/Prototype/AT journey. The metafile is the browser-bundle graph, not the complete Node/Playwright/tooling closure. No fake trusted event, app callback replacement or product owner/state flag is used.

The first baseline Enter retains one console404 message without a captured URL. It is not labelled a favicon or silently removed. All page-error and cleanup-error arrays are empty. The runner records browser/server closed, and the read-only check found no listener on55758 or62171. This is observed cleanup, not a complete resource-leak proof.

The other actual runs bind clean exact0ecfe:

| Run | Result | Actual UTC interval |
| --- | --- | --- |
| Postcommit combination |98files,1303passed,0failed,0skipped|13:12:20.839–13:12:38.586|
| Original native C files |4files,71passed:Collapsible36/Tooltip2/Button8/Field25|13:14:08.472–13:17:05.819|
| Original settings case |1passed,10filtered; originaltwo-family/four-runtime loop|13:17:05.865–13:17:17.418|

The default event-router-work file contributes17passes inside the98file run; it is not added again to1303. The earlier formal15/2→17/0 remains precommit evidence under the identical finaltestSHA. The originalsettings file was not fully run—all10othercases were filtered.

The website runs used a complete localstatic build with3836files, served at62171 after a successful clean0ecfe build. This is not anActionsartifact. Its inventory is anoutput census, not a complete networkrequest-body or loaded-source closure.

All **48captures** have matching exact0ecfe/clean sidecars: **40Field plus8BrutalistButton**. They are only counted and hash/source checked here. **Pixels are unassessed in this audit** pending the assigned visual review; capture is not visual acceptance, whole-page readability or AT conformance.

Preparation files retain their earlier planned/not-run wording; later actual receipts establish execution. Earlier independent reports’ pending boundaries are likewise preserved. This append-only audit does not rewrite raw evidence or confer GitHub approval/global acceptance.
