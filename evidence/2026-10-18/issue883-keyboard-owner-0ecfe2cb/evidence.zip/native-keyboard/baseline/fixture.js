// packages/adapters/base/src/events/pointer-contact.ts
var cells = /* @__PURE__ */ new WeakMap();
function cell(host) {
  let value = cells.get(host);
  if (!value) {
    value = { value: null, listeners: /* @__PURE__ */ new Set() };
    cells.set(host, value);
  }
  return value;
}
function createWebPointerContactWriter(host) {
  const state = cell(host), owner = {};
  state.owner = owner;
  const publish = (sample) => {
    if (state.owner !== owner) return;
    state.value = Object.freeze({ ...sample });
    for (const listener of state.listeners) {
      try {
        listener(state.value);
      } catch (error) {
        queueMicrotask(() => {
          throw error;
        });
      }
    }
  };
  if (state.value?.active) publish({ ...state.value, active: false, reason: "replaced" });
  return { publish, nextSession: () => (state.value?.session ?? 0) + 1 };
}

// packages/adapters/base/src/gestures/web-move-click-arbitration.ts
var contacts = /* @__PURE__ */ new WeakMap();
var consumed = /* @__PURE__ */ new WeakMap();
function retire(target, pointerId) {
  const records = contacts.get(target);
  const current = records?.get(pointerId);
  if (current?.legacyTimer !== null && current?.legacyTimer !== void 0)
    clearTimeout(current.legacyTimer);
  records?.delete(pointerId);
  if (records?.size === 0) contacts.delete(target);
}
function pointerType(event) {
  return ["mouse", "touch", "pen"].includes(event.pointerType) ? event.pointerType : "unknown";
}
function retireSuperseded(target, event) {
  const kind = pointerType(event);
  for (const current of contacts.get(target)?.values() ?? []) {
    if (current.pointerId === event.pointerId || event.isPrimary !== false && event.button === 0 && current.pointerType === kind)
      retire(target, current.pointerId);
  }
}
function observeDirectionalPointerDown(target, event) {
  retireSuperseded(target, event);
}
function observeDirectionalPointerUp(target, event) {
  const current = contacts.get(target)?.get(event.pointerId);
  if (!current || current.released) return;
  current.released = true;
  current.legacyRelease = event;
  current.legacyTimer = setTimeout(() => retire(target, event.pointerId), 0);
}
function suppressDirectionalClick(target, event) {
  if (event.detail === 0) return false;
  if (consumed.get(event) === target) return true;
  const records = contacts.get(target);
  if (!records) return false;
  const pointer = event;
  const hasPointerIdentity = typeof pointer.pointerId === "number" && pointer.pointerId >= 0;
  const candidates = hasPointerIdentity ? [records.get(pointer.pointerId)].filter((c) => !!c) : [...records.values()].filter((c) => c.released && c.legacyRelease);
  if (candidates.length !== 1) return false;
  const current = candidates[0];
  if (!current.released) return false;
  const release = current.legacyRelease;
  const matches = hasPointerIdentity ? pointer.pointerId === current.pointerId && (!pointer.pointerType || pointerType(pointer) === current.pointerType) : !!release && event.button === release.button && event.clientX === release.clientX && event.clientY === release.clientY;
  if (!matches) return false;
  consumed.set(event, target);
  retire(target, current.pointerId);
  return true;
}

// packages/adapters/base/src/events/web-event-router.ts
var PRESS_COMMIT_EMITTED_ROOTS = Symbol.for("@proto.ui/router/press-commit-emitted-roots");
var KEYBOARD_PRESS_OWNER = Symbol.for("@proto.ui/router/keyboard-press-owner");
var PROTO_PARENT_INSTANCE_MARK = Symbol.for("@proto.ui/adapter-base/__proto_parent_instance");
var PROTO_INSTANCE_MARKS = [
  Symbol.for("@proto.ui/adapter-web-component/__proto_instance"),
  Symbol.for("@proto.ui/adapter-react/__proto_instance"),
  Symbol.for("@proto.ui/adapter-vue/__proto_instance"),
  Symbol.for("@proto.ui/adapter-vue2/__proto_instance")
];
var TRIGGER_OWNER_MARK = Symbol.for("@proto.ui/as-trigger/confirm-owner");
var REJECTED_TRIGGER_ROUTE = Symbol("rejected-trigger-route");
var GLOBAL_ROOT_EVENT_TYPES = {
  pointerdown: "pointer.down",
  pointermove: "pointer.move",
  pointerup: "pointer.up",
  pointercancel: "pointer.cancel",
  click: "press.commit",
  contextmenu: "context.menu"
};
var isDomNode = (value) => !!value && typeof value.nodeType === "number";
var isHtmlElement = (value) => isDomNode(value) && value.nodeType === 1 && value.namespaceURI === "http://www.w3.org/1999/xhtml";
var isShadowRoot = (value) => isDomNode(value) && value.nodeType === 11 && "host" in value;
var payloadStateByNativeEvent = /* @__PURE__ */ new WeakMap();
var activeRouterByRoot = /* @__PURE__ */ new WeakMap();
function createWebProtoEventRouter(opt) {
  const protoRootBus = new EventTarget();
  const protoGlobalBus = new EventTarget();
  const physicalRootDeliveries = /* @__PURE__ */ new WeakSet();
  const rootEl = opt.rootEl;
  const globalEl = opt.globalEl ?? window;
  const routerIdentity = {};
  activeRouterByRoot.set(rootEl, routerIdentity);
  const isEnabled = () => activeRouterByRoot.get(rootEl) === routerIdentity && opt.isEnabled();
  const contactWriter = createWebPointerContactWriter(rootEl);
  let suppressFollowupDirectClick = false;
  let contact = null;
  const sampled = /* @__PURE__ */ new WeakSet();
  function endContact(reason) {
    if (!contact) return;
    const value = { ...contact.value, active: false, reason };
    contact = null;
    contactWriter.publish(value);
  }
  function sampleContact(native) {
    if (sampled.has(native)) return;
    sampled.add(native);
    const pointerId = Number.isFinite(native.pointerId) ? native.pointerId : 0;
    if (native.type === "pointerdown") {
      if (typeof native.button === "number" && native.button !== 0 || native.isPrimary === false)
        return;
      endContact("replaced");
      const rect2 = rootEl.getBoundingClientRect();
      if (![rect2.x, rect2.y, rect2.width, rect2.height, native.clientX, native.clientY].every(
        Number.isFinite
      ) || rect2.width <= 0 || rect2.height <= 0)
        return;
      contact = {
        pointerId,
        rect: rect2,
        startX: native.clientX,
        startY: native.clientY,
        value: {
          active: true,
          session: contactWriter.nextSession(),
          x: 0.5,
          y: 0.5,
          deltaX: 0,
          deltaY: 0,
          reason: "down"
        }
      };
    }
    if (!contact || contact.pointerId !== pointerId) return;
    if (native.type === "pointercancel") {
      endContact("cancel");
      return;
    }
    const { rect, startX, startY } = contact;
    if (Number.isFinite(native.clientX) && Number.isFinite(native.clientY)) {
      const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
      contact.value = {
        ...contact.value,
        x: clamp((native.clientX - rect.x) / rect.width, 0, 1),
        y: clamp((native.clientY - rect.y) / rect.height, 0, 1),
        deltaX: clamp((native.clientX - startX) / rect.width, -1, 1),
        deltaY: clamp((native.clientY - startY) / rect.height, -1, 1),
        reason: native.type === "pointerdown" ? "down" : "move"
      };
    }
    if (native.type === "pointerup") {
      endContact("up");
      return;
    }
    contactWriter.publish(contact.value);
  }
  function emit(target, type, native) {
    if (target === protoRootBus && ["pointer.down", "pointer.move", "pointer.up", "pointer.cancel"].includes(type))
      sampleContact(native);
    const ev = new CustomEvent(type, { detail: createProtoEventPayload(type, native) });
    target.dispatchEvent(ev);
  }
  function emitFromPhysicalRoot(type, native) {
    if (GLOBAL_ROOT_EVENT_TYPES[native.type] === type) physicalRootDeliveries.add(native);
    emit(protoRootBus, type, native);
  }
  function emitPressCommitOnce(native) {
    if (hasPressCommitBeenEmittedForRoot(native)) return;
    const keyboard = native;
    if (native.type === "keydown" && keyboard[KEYBOARD_PRESS_OWNER]) return;
    if (native.type === "keydown" && rootProxy.__hasProtoListeners("press.commit")) {
      keyboard[KEYBOARD_PRESS_OWNER] = opt.instanceToken ?? rootEl;
    }
    markPressCommitEmittedForRoot(native);
    suppressFollowupDirectClick = true;
    emit(protoRootBus, "press.commit", native);
  }
  function isCommitKey(key) {
    return key === "Enter" || key === " ";
  }
  function isNativeMouseClick(event) {
    const candidate = event;
    return event.type === "click" && typeof candidate.detail === "number" && typeof candidate.clientX === "number" && typeof candidate.clientY === "number" && typeof candidate.button === "number";
  }
  function isWithinRoot(target) {
    return target === rootEl || isDomNode(target) && rootEl.contains(target);
  }
  function getLinkedProtoParent(target) {
    if (!isHtmlElement(target)) return null;
    const linkedParent = target[PROTO_PARENT_INSTANCE_MARK];
    return isHtmlElement(linkedParent) ? linkedParent : null;
  }
  function isProtoInstanceNode(target) {
    if (!isHtmlElement(target)) return false;
    return PROTO_INSTANCE_MARKS.some((mark) => target[mark] === true);
  }
  function getTriggerRouteOwner(target) {
    if (!isHtmlElement(target)) return null;
    const owner = target[TRIGGER_OWNER_MARK];
    if (owner === true) return target;
    return owner && (typeof owner === "object" || typeof owner === "function") ? owner : null;
  }
  function getNearestProtoInstance(target, visited = /* @__PURE__ */ new Set()) {
    let cur = isDomNode(target) ? target : null;
    while (cur) {
      if (visited.has(cur)) return null;
      visited.add(cur);
      if (isShadowRoot(cur)) {
        cur = cur.host;
        continue;
      }
      if (isProtoInstanceNode(cur)) return cur;
      const linkedParent = getLinkedProtoParent(cur);
      if (linkedParent && linkedParent !== cur) {
        cur = linkedParent;
        continue;
      }
      cur = cur.parentNode;
    }
    return null;
  }
  function getNearestTriggerOwner(target, visited = /* @__PURE__ */ new Set()) {
    let cur = isDomNode(target) ? target : null;
    while (cur) {
      if (visited.has(cur)) return null;
      visited.add(cur);
      if (isShadowRoot(cur)) {
        cur = cur.host;
        continue;
      }
      const owner = getTriggerRouteOwner(cur);
      if (owner) return owner;
      cur = cur.parentNode;
    }
    return null;
  }
  function resolveOwningTrigger(native, options) {
    if (opt.resolveSemanticEventRoute) {
      const visited2 = /* @__PURE__ */ new Set();
      if (typeof native.composedPath === "function") {
        for (const entry of native.composedPath()) {
          const resolution2 = opt.resolveSemanticEventRoute(entry, visited2);
          if (!resolution2) continue;
          return resolution2.accepted ? resolution2.surface : REJECTED_TRIGGER_ROUTE;
        }
      }
      const resolution = opt.resolveSemanticEventRoute(native.target, visited2);
      if (resolution) {
        return resolution.accepted ? resolution.surface : REJECTED_TRIGGER_ROUTE;
      }
      if (options?.includeActiveFallback !== false) {
        const active2 = rootEl.ownerDocument.activeElement;
        const activeResolution = opt.resolveSemanticEventRoute(active2, visited2);
        if (activeResolution) {
          return activeResolution.accepted ? activeResolution.surface : REJECTED_TRIGGER_ROUTE;
        }
      }
    }
    if (opt.resolveEventRouteOwner) {
      if (typeof native.composedPath === "function") {
        for (const entry of native.composedPath()) {
          const owner = opt.resolveEventRouteOwner(entry);
          if (owner) return owner;
        }
      }
      const targetOwner2 = opt.resolveEventRouteOwner(native.target);
      if (targetOwner2) return targetOwner2;
      if (options?.includeActiveFallback !== false) {
        const active2 = rootEl.ownerDocument.activeElement;
        const activeOwner = opt.resolveEventRouteOwner(active2);
        if (activeOwner) return activeOwner;
      }
    }
    const visited = /* @__PURE__ */ new Set();
    if (typeof native.composedPath === "function") {
      for (const entry of native.composedPath()) {
        const owner = getNearestTriggerOwner(entry, visited);
        if (owner) return owner;
      }
    }
    const targetOwner = getNearestTriggerOwner(native.target, visited);
    if (targetOwner) return targetOwner;
    if (options?.includeActiveFallback === false) return null;
    const active = rootEl.ownerDocument.activeElement;
    return getNearestTriggerOwner(active, visited);
  }
  function resolveOwningProtoInstance(native, options) {
    const visited = /* @__PURE__ */ new Set();
    if (typeof native.composedPath === "function") {
      for (const entry of native.composedPath()) {
        const owner = getNearestProtoInstance(entry, visited);
        if (owner) return owner;
      }
    }
    const targetOwner = getNearestProtoInstance(native.target, visited);
    if (targetOwner) return targetOwner;
    if (options?.includeActiveFallback === false) return null;
    const active = rootEl.ownerDocument.activeElement;
    return getNearestProtoInstance(active, visited);
  }
  function shouldRouteToCurrentRoot(native, options) {
    const acceptedOwner = native[KEYBOARD_PRESS_OWNER];
    if (native.type === "keydown" && acceptedOwner && acceptedOwner !== (opt.instanceToken ?? rootEl))
      return false;
    if (opt.isSemanticEventRouteCandidate) {
      const targets = typeof native.composedPath === "function" ? native.composedPath() : [];
      if (native.target) targets.push(native.target);
      if (options?.includeActiveFallback !== false && rootEl.ownerDocument.activeElement)
        targets.push(rootEl.ownerDocument.activeElement);
      if (!opt.isSemanticEventRouteCandidate(rootEl, targets)) return false;
    }
    const triggerOwner = resolveOwningTrigger(native, options);
    if (triggerOwner === REJECTED_TRIGGER_ROUTE) return false;
    if (triggerOwner) return triggerOwner === (opt.instanceToken ?? rootEl);
    const owner = resolveOwningProtoInstance(native, options);
    if (owner) return owner === rootEl;
    return isWithinRoot(native.target);
  }
  function shouldRouteGlobalRootEvent(native, options) {
    const hasMappedListener = rootProxy.__hasProtoListeners(GLOBAL_ROOT_EVENT_TYPES[native.type]);
    const resetsPressCommit = native.type === "pointerdown" && rootProxy.__hasProtoListeners("press.commit");
    const consumesPendingPressCommit = native.type === "click" && suppressFollowupDirectClick;
    if (!hasMappedListener && !resetsPressCommit && !consumesPendingPressCommit) return false;
    if (physicalRootDeliveries.has(native) && typeof native.composedPath === "function" && native.composedPath().includes(rootEl)) {
      physicalRootDeliveries.delete(native);
      return false;
    }
    if (isWithinRoot(native.target)) return false;
    return shouldRouteToCurrentRoot(native, options);
  }
  function getPressCommitEmittedRoots(native) {
    const seen = native[PRESS_COMMIT_EMITTED_ROOTS];
    if (seen instanceof Set) return seen;
    const next = /* @__PURE__ */ new Set();
    native[PRESS_COMMIT_EMITTED_ROOTS] = next;
    return next;
  }
  function hasPressCommitBeenEmittedForRoot(native) {
    return getPressCommitEmittedRoots(native).has(rootEl);
  }
  function markPressCommitEmittedForRoot(native) {
    getPressCommitEmittedRoots(native).add(rootEl);
  }
  function hasFocusedDescendant() {
    const active = rootEl.ownerDocument.activeElement;
    return isDomNode(active) && rootEl.contains(active);
  }
  function shouldSuppressFollowupClick(native) {
    if (!suppressFollowupDirectClick) return false;
    if (native.detail !== 0) {
      suppressFollowupDirectClick = false;
      return false;
    }
    suppressFollowupDirectClick = false;
    return true;
  }
  const unsubs = [];
  unsubs.push(
    listen(rootEl, "pointerdown", (e) => {
      observeDirectionalPointerDown(rootEl, e);
      if (!isEnabled()) return;
      if (!shouldRouteToCurrentRoot(e, { includeActiveFallback: false })) return;
      suppressFollowupDirectClick = false;
      emitFromPhysicalRoot("pointer.down", e);
    })
  );
  unsubs.push(
    listen(rootEl, "pointermove", (e) => {
      if (!isEnabled()) return;
      emitFromPhysicalRoot("pointer.move", e);
    })
  );
  unsubs.push(
    listen(rootEl, "pointerup", (e) => {
      observeDirectionalPointerUp(rootEl, e);
      if (!isEnabled()) return;
      emitFromPhysicalRoot("pointer.up", e);
    })
  );
  unsubs.push(
    listen(rootEl, "pointercancel", (e) => {
      observeDirectionalPointerUp(rootEl, e);
      if (!isEnabled()) return;
      emitFromPhysicalRoot("pointer.cancel", e);
    })
  );
  unsubs.push(
    listen(rootEl, "pointerenter", (e) => {
      if (!isEnabled()) return;
      emit(protoRootBus, "pointer.enter", e);
    })
  );
  unsubs.push(
    listen(rootEl, "pointerleave", (e) => {
      if (!isEnabled()) return;
      emit(protoRootBus, "pointer.leave", e);
    })
  );
  unsubs.push(
    listen(rootEl, "lostpointercapture", (e) => {
      if (!isEnabled() || !shouldRouteToCurrentRoot(e, { includeActiveFallback: false })) return;
      if (!contact || contact.pointerId !== e.pointerId) return;
      endContact("lostcapture");
      emit(protoRootBus, "pointer.cancel", e);
    })
  );
  unsubs.push(
    listen(globalEl, "blur", (e) => {
      endContact("blur");
      if (isEnabled()) emit(protoRootBus, "press.cancel", e);
    })
  );
  unsubs.push(
    listen(globalEl, "pointerdown", (e) => {
      observeDirectionalPointerDown(rootEl, e);
      if (!isEnabled()) {
        endContact("cancel");
        return;
      }
      if (contact && !sampled.has(e) && e.button === 0 && e.isPrimary !== false)
        endContact("replaced");
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      suppressFollowupDirectClick = false;
      emit(protoRootBus, "pointer.down", e);
    })
  );
  unsubs.push(
    listen(globalEl, "pointermove", (e) => {
      if (!isEnabled()) {
        endContact("cancel");
        return;
      }
      if (contact) sampleContact(e);
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      emit(protoRootBus, "pointer.move", e);
    })
  );
  unsubs.push(
    listen(globalEl, "pointerup", (e) => {
      observeDirectionalPointerUp(rootEl, e);
      if (!isEnabled()) {
        endContact("cancel");
        return;
      }
      if (contact) sampleContact(e);
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      emit(protoRootBus, "pointer.up", e);
    })
  );
  unsubs.push(
    listen(globalEl, "pointercancel", (e) => {
      observeDirectionalPointerUp(rootEl, e);
      if (!isEnabled()) {
        endContact("cancel");
        return;
      }
      if (contact) sampleContact(e);
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      emit(protoRootBus, "pointer.cancel", e);
    })
  );
  unsubs.push(
    listen(globalEl, "keydown", (e) => {
      if (!isEnabled()) return;
      emit(protoGlobalBus, "key.down", e);
      if (rootProxy.__hasProtoListeners("key.down") && shouldRouteToCurrentRoot(e)) {
        emit(protoRootBus, "key.down", e);
      }
      if (!isCommitKey(e.key)) {
        suppressFollowupDirectClick = false;
        return;
      }
      if (!rootProxy.__hasProtoListeners("press.commit")) return;
      if (shouldRouteToCurrentRoot(e)) {
        emitPressCommitOnce(e);
        return;
      }
      if (!isWithinRoot(e.target)) return;
      if (!hasFocusedDescendant()) return;
      emitPressCommitOnce(e);
    })
  );
  unsubs.push(
    listen(rootEl, "keydown", (e) => {
      if (!isEnabled()) return;
      if (!isCommitKey(e.key)) return;
      emitPressCommitOnce(e);
    })
  );
  unsubs.push(
    listen(globalEl, "keyup", (e) => {
      if (!isEnabled()) return;
      emit(protoGlobalBus, "key.up", e);
      if (rootProxy.__hasProtoListeners("key.up") && shouldRouteToCurrentRoot(e)) {
        emit(protoRootBus, "key.up", e);
      }
      if (isCommitKey(e.key)) queueMicrotask(() => suppressFollowupDirectClick = false);
    })
  );
  unsubs.push(
    listen(rootEl, "click", (e) => {
      if (!isEnabled()) return;
      if (!isNativeMouseClick(e)) return;
      if (!shouldRouteToCurrentRoot(e)) return;
      if (suppressDirectionalClick(rootEl, e) || shouldSuppressFollowupClick(e)) return;
      emitFromPhysicalRoot("press.commit", e);
    })
  );
  unsubs.push(
    listen(globalEl, "click", (e) => {
      if (!isEnabled()) return;
      if (!isNativeMouseClick(e)) return;
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      if (suppressDirectionalClick(rootEl, e) || shouldSuppressFollowupClick(e)) return;
      emit(protoRootBus, "press.commit", e);
    })
  );
  unsubs.push(
    listen(rootEl, "contextmenu", (e) => {
      if (!isEnabled()) return;
      emitFromPhysicalRoot("context.menu", e);
    })
  );
  unsubs.push(
    listen(globalEl, "contextmenu", (e) => {
      if (!isEnabled()) return;
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      emit(protoRootBus, "context.menu", e);
    })
  );
  const rootProxy = createProxyTarget({
    protoBus: protoRootBus,
    // hostTarget：先工作假设= rootEl；未来可以换成更准确的 host 专用 target
    hostTarget: rootEl,
    focusEventTarget: opt.focusEventTarget,
    isEnabled
    // 注：rootProxy 不做“解释”，只做“路由 + gating”
  });
  const globalProxy = createProxyTarget({
    protoBus: protoGlobalBus,
    hostTarget: globalEl,
    isEnabled
  });
  return {
    /** Inject these into EVENT_*_TARGET_CAP */
    rootTarget: rootProxy,
    globalTarget: globalProxy,
    /** Adapter-private ingress for a trusted physical host target. */
    dispatchHostRootEvent(type, event) {
      rootProxy.__dispatchHost(type, event);
    },
    dispose() {
      endContact("unmount");
      if (activeRouterByRoot.get(rootEl) === routerIdentity) activeRouterByRoot.delete(rootEl);
      for (const u of unsubs.splice(0)) u();
      rootProxy.__dispose?.();
      globalProxy.__dispose?.();
    }
  };
}
function listen(t, type, cb) {
  t.addEventListener(type, cb);
  return () => t.removeEventListener(type, cb);
}
function createProtoEventPayload(type, native) {
  const target = {
    type,
    nativeEvent: native,
    target: native?.target,
    key: typeof native?.key === "string" ? native.key : void 0,
    repeat: typeof native?.repeat === "boolean" ? native.repeat : void 0,
    shiftKey: typeof native?.shiftKey === "boolean" ? native.shiftKey : void 0,
    altKey: typeof native?.altKey === "boolean" ? native.altKey : void 0,
    ctrlKey: typeof native?.ctrlKey === "boolean" ? native.ctrlKey : void 0,
    metaKey: typeof native?.metaKey === "boolean" ? native.metaKey : void 0,
    requestDefaultPrevented: typeof native?.preventDefault === "function" ? () => native.preventDefault() : void 0,
    preventDefault: typeof native?.preventDefault === "function" ? () => native.preventDefault() : void 0,
    stopPropagation: typeof native?.stopPropagation === "function" ? () => native.stopPropagation() : void 0
  };
  if (!native || typeof native !== "object" && typeof native !== "function") return target;
  let sharedState = payloadStateByNativeEvent.get(native);
  if (!sharedState) {
    sharedState = {};
    payloadStateByNativeEvent.set(native, sharedState);
  }
  const state = sharedState;
  return new Proxy(target, {
    get(obj, prop) {
      if (prop in obj) return obj[prop];
      return state[prop];
    },
    set(obj, prop, value) {
      if (prop in obj) obj[prop] = value;
      else state[prop] = value;
      return true;
    },
    has(obj, prop) {
      return prop in obj || prop in state;
    }
  });
}
function createProxyTarget(args) {
  const hostListeners = [];
  const protoListeners = [];
  function wrapWithGate(cb) {
    return (ev) => {
      if (!args.isEnabled()) return;
      cb(ev);
    };
  }
  function parseType(type) {
    if (type.startsWith("host:")) {
      return { kind: "host", inner: type.slice("host:".length) };
    }
    return { kind: "proto", inner: type };
  }
  const api = {
    addEventListener(type, cb, options) {
      const p = parseType(String(type));
      if (p.kind === "proto") {
        const signal = options?.signal;
        if (!cb || signal?.aborted) return;
        const capture = typeof options === "boolean" ? options : Boolean(options?.capture);
        const once = Boolean(options?.once);
        if (protoListeners.some((r) => r.type === p.inner && r.cb === cb && r.capture === capture))
          return;
        const record = {
          type: p.inner,
          cb,
          options,
          capture,
          wrapped: void 0,
          cleanup: () => {
          }
        };
        record.cleanup = () => {
          const index = protoListeners.indexOf(record);
          if (index < 0) return;
          protoListeners.splice(index, 1);
          args.protoBus.removeEventListener(p.inner, record.wrapped, capture);
          signal?.removeEventListener("abort", record.cleanup);
        };
        record.wrapped = (event) => {
          if (once) record.cleanup();
          if (typeof cb === "function") cb.call(args.protoBus, event);
          else cb.handleEvent(event);
        };
        args.protoBus.addEventListener(p.inner, record.wrapped, {
          capture,
          once,
          signal,
          passive: Boolean(options?.passive)
        });
        protoListeners.push(record);
        signal?.addEventListener("abort", record.cleanup, { once: true });
        return;
      }
      const wrapped = wrapWithGate(cb);
      const target = p.inner === "focus" || p.inner === "blur" ? args.focusEventTarget ?? args.hostTarget : args.hostTarget;
      hostListeners.push({ type: p.inner, target, cb, options, wrapped });
      target.addEventListener(p.inner, wrapped, options);
    },
    removeEventListener(type, cb, options) {
      const p = parseType(String(type));
      if (p.kind === "proto") {
        const capture = typeof options === "boolean" ? options : Boolean(options?.capture);
        protoListeners.find((r) => r.type === p.inner && r.cb === cb && r.capture === capture)?.cleanup();
        return;
      }
      for (let i = hostListeners.length - 1; i >= 0; i--) {
        const r = hostListeners[i];
        if (r.type !== p.inner) continue;
        if (r.cb !== cb) continue;
        if (!Object.is(r.options, options)) continue;
        (r.target ?? args.hostTarget).removeEventListener(p.inner, r.wrapped, options);
        hostListeners.splice(i, 1);
        return;
      }
    },
    dispatchEvent(ev) {
      return args.protoBus.dispatchEvent(ev);
    },
    __hasProtoListeners(type) {
      return protoListeners.some((r) => r.type === type);
    },
    /** Private adapter ingress; does not emit another public DOM event. */
    __dispatchHost(type, event) {
      for (const listener of hostListeners) {
        if (listener.type !== type) continue;
        listener.wrapped?.(event);
      }
    },
    // best-effort cleanup (not required by EventTarget)
    __dispose() {
      for (const r of [...protoListeners]) r.cleanup();
      for (const r of hostListeners.splice(0)) {
        (r.target ?? args.hostTarget).removeEventListener(
          r.type,
          // @ts-ignore
          r.wrapped,
          r.options
        );
      }
    }
  };
  return api;
}

// packages/adapters/base/src/platform/instance-tree.ts
var PROTO_PARENT_INSTANCE = Symbol.for("@proto.ui/adapter-base/__proto_parent_instance");
var TRIGGER_OWNER_MARK2 = Symbol.for("@proto.ui/as-trigger/confirm-owner");
var isDomNode2 = (value) => !!value && typeof value.nodeType === "number";
var isHtmlElement2 = (value) => isDomNode2(value) && value.nodeType === 1 && value.namespaceURI === "http://www.w3.org/1999/xhtml";
var isShadowRoot2 = (value) => isDomNode2(value) && value.nodeType === 11 && "host" in value;
function createRebindableEventTarget() {
  let target = null;
  const registrations = [];
  const remove = (registration) => {
    const index = registrations.indexOf(registration);
    if (index < 0) return;
    registrations.splice(index, 1);
    target?.removeEventListener(registration[0], registration[5], registration[2]);
    if (registration[7]) registration[6]?.removeEventListener("abort", registration[7]);
  };
  const bridge = {
    addEventListener(type, listener, options) {
      if (!listener) return;
      const capture = typeof options === "boolean" ? options : options?.capture === true;
      if (registrations.some(
        (entry) => entry[0] === type && entry[1] === listener && entry[2] === capture
      )) {
        return;
      }
      const signal = typeof options === "boolean" ? void 0 : options?.signal;
      if (signal?.aborted) return;
      const registration = [
        type,
        listener,
        capture,
        typeof options === "boolean" ? false : options?.passive === true,
        typeof options === "boolean" ? false : options?.once === true,
        void 0,
        signal
      ];
      registration[5] = function(event) {
        if (registration[4]) remove(registration);
        if (typeof listener === "function") listener.call(this, event);
        else listener.handleEvent(event);
      };
      if (signal) {
        registration[7] = () => remove(registration);
        signal.addEventListener("abort", registration[7], { once: true });
      }
      registrations.push(registration);
      target?.addEventListener(type, registration[5], {
        capture,
        passive: registration[3]
      });
    },
    removeEventListener(type, listener, options) {
      if (!listener) return;
      const capture = typeof options === "boolean" ? options : options?.capture === true;
      const registration = registrations.find(
        (entry) => entry[0] === type && entry[1] === listener && entry[2] === capture
      );
      if (registration) remove(registration);
    },
    dispatchEvent(event) {
      return target?.dispatchEvent(event) ?? false;
    },
    setTarget(nextTarget) {
      if (target === nextTarget) return;
      if (target) {
        for (const entry of registrations) {
          target.removeEventListener(entry[0], entry[5], entry[2]);
        }
      }
      target = nextTarget;
      if (target) {
        for (const entry of registrations) {
          target.addEventListener(entry[0], entry[5], {
            capture: entry[2],
            passive: entry[3]
          });
        }
      }
    },
    getTarget() {
      return target;
    }
  };
  return bridge;
}
function writeProtoParentMark(instance, parent2) {
  const target = instance;
  if (parent2) {
    target[PROTO_PARENT_INSTANCE] = parent2;
    return;
  }
  delete target[PROTO_PARENT_INSTANCE];
}
function readProtoParentMark(instance) {
  const mark = instance[PROTO_PARENT_INSTANCE];
  return isHtmlElement2(mark) ? mark : null;
}
function createInstanceTreeMarkers(symbolName, options = {}) {
  const PROTO_INSTANCE = Symbol.for(symbolName);
  const PROTO_BY_INSTANCE = /* @__PURE__ */ new WeakMap();
  const TOKEN_BY_INSTANCE = /* @__PURE__ */ new WeakMap();
  const INSTANCE_BY_TOKEN = /* @__PURE__ */ new WeakMap();
  const PROTO_BY_TOKEN = /* @__PURE__ */ new WeakMap();
  const PARENT_BY_TOKEN = /* @__PURE__ */ new WeakMap();
  const OWNER_PARENT_TOKENS = /* @__PURE__ */ new WeakSet();
  const CHILDREN_BY_TOKEN = /* @__PURE__ */ new WeakMap();
  const TRIGGER_GROUP_ANCHOR_BY_TOKEN = /* @__PURE__ */ new WeakMap();
  const EVENT_TARGET_BY_TOKEN = /* @__PURE__ */ new WeakMap();
  const BOUND_EVENT_TARGET_BY_TOKEN = /* @__PURE__ */ new WeakMap();
  const TRIGGER_GROUP_MEMBERS_BY_ANCHOR = /* @__PURE__ */ new WeakMap();
  const TRIGGER_GROUP_SURFACE_BY_ANCHOR = /* @__PURE__ */ new WeakMap();
  const TRIGGER_SURFACE_LISTENERS = /* @__PURE__ */ new WeakMap();
  const TRIGGER_TOKENS = /* @__PURE__ */ new WeakSet();
  function notifySurfaceListeners(token, failures) {
    for (const listener of [...TRIGGER_SURFACE_LISTENERS.get(token) ?? []]) {
      try {
        listener();
      } catch (error) {
        if (failures.length === 0) failures.push(error);
      }
    }
  }
  function notifyTriggerSurface(owner) {
    syncTriggerGroupEventTargets(owner);
    const members = TRIGGER_GROUP_MEMBERS_BY_ANCHOR.get(owner);
    if (!members) return;
    const surface = TRIGGER_GROUP_SURFACE_BY_ANCHOR.get(owner);
    const failures = [];
    const memberSnapshot = [...members];
    for (const member of memberSnapshot) {
      const memberRoot = INSTANCE_BY_TOKEN.get(member);
      if (memberRoot && member !== surface) options.releaseTriggerSurface?.(memberRoot);
      notifySurfaceListeners(member, failures);
    }
    if (!memberSnapshot.includes(owner)) {
      notifySurfaceListeners(owner, failures);
    }
    if (failures.length) throw failures[0];
  }
  function notifyInstanceLifecycle(token) {
    const failures = [];
    notifySurfaceListeners(token, failures);
    if (failures.length) throw failures[0];
  }
  function syncTriggerGroupEventTargets(owner) {
    for (const member of TRIGGER_GROUP_MEMBERS_BY_ANCHOR.get(owner) ?? []) {
      syncLogicalEventTarget(member);
    }
  }
  function registerTriggerMember(token, owner, makeSurface) {
    let members = TRIGGER_GROUP_MEMBERS_BY_ANCHOR.get(owner);
    if (!members) {
      members = /* @__PURE__ */ new Set();
      TRIGGER_GROUP_MEMBERS_BY_ANCHOR.set(owner, members);
    }
    members.delete(token);
    members.add(token);
    const currentSurface = TRIGGER_GROUP_SURFACE_BY_ANCHOR.get(owner);
    let parent2 = currentSurface ? PARENT_BY_TOKEN.get(currentSurface) : void 0;
    let currentIsDeeper = false;
    while (parent2) {
      if (parent2 === token) {
        currentIsDeeper = true;
        break;
      }
      parent2 = PARENT_BY_TOKEN.get(parent2);
    }
    if (makeSurface && !currentIsDeeper || !currentSurface) {
      const previousRoot = currentSurface ? INSTANCE_BY_TOKEN.get(currentSurface) : null;
      TRIGGER_GROUP_SURFACE_BY_ANCHOR.set(owner, token);
      const nextRoot = INSTANCE_BY_TOKEN.get(token);
      if (previousRoot && previousRoot !== nextRoot) {
        options.releaseTriggerSurface?.(previousRoot);
      }
    } else if (makeSurface && currentIsDeeper) {
      const supersededRoot = INSTANCE_BY_TOKEN.get(token);
      const currentRoot = currentSurface ? INSTANCE_BY_TOKEN.get(currentSurface) : null;
      if (supersededRoot && supersededRoot !== currentRoot) {
        options.releaseTriggerSurface?.(supersededRoot);
      }
    }
  }
  function unregisterTriggerMember(token, owner = TRIGGER_GROUP_ANCHOR_BY_TOKEN.get(token) ?? token) {
    const members = TRIGGER_GROUP_MEMBERS_BY_ANCHOR.get(owner);
    if (!members?.delete(token)) return;
    if (TRIGGER_GROUP_SURFACE_BY_ANCHOR.get(owner) !== token) return;
    const connected = Array.from(members).filter(
      (member) => INSTANCE_BY_TOKEN.get(member)?.isConnected
    );
    const fallback = connected.at(-1) ?? Array.from(members).at(-1) ?? owner;
    TRIGGER_GROUP_SURFACE_BY_ANCHOR.set(owner, fallback);
    notifyTriggerSurface(owner);
  }
  function syncLogicalEventTarget(token) {
    const bridge = getLogicalEventTarget(token);
    const owner = TRIGGER_GROUP_ANCHOR_BY_TOKEN.get(token) ?? token;
    const surface = TRIGGER_GROUP_SURFACE_BY_ANCHOR.get(owner) ?? owner;
    if (surface !== token) {
      bridge.setTarget(getLogicalEventTarget(surface));
      return;
    }
    bridge.setTarget(BOUND_EVENT_TARGET_BY_TOKEN.get(token) ?? null);
  }
  function isRegisteredTrigger(token) {
    const owner = TRIGGER_GROUP_ANCHOR_BY_TOKEN.get(token) ?? token;
    return TRIGGER_GROUP_MEMBERS_BY_ANCHOR.get(owner)?.has(token) === true;
  }
  function assertContinuousTriggerChain(token, parent2, declaredAnchor) {
    const reject = () => {
      throw new Error(
        "[as-trigger] Trigger group must be a continuous chain; sibling Trigger branches are not supported."
      );
    };
    if (parent2 && (isRegisteredTrigger(parent2) || declaredAnchor === parent2)) {
      for (const sibling of CHILDREN_BY_TOKEN.get(parent2) ?? []) {
        if (sibling !== token && isRegisteredTrigger(sibling)) reject();
      }
    }
    let childCount = 0;
    for (const child2 of CHILDREN_BY_TOKEN.get(token) ?? []) {
      if (isRegisteredTrigger(child2) && ++childCount > 1) reject();
    }
  }
  function mergeTriggerGroup(token, owner) {
    assertContinuousTriggerChain(token, PARENT_BY_TOKEN.get(token), owner);
    const previousOwner = TRIGGER_GROUP_ANCHOR_BY_TOKEN.get(token) ?? token;
    if (previousOwner !== owner) unregisterTriggerMember(token, previousOwner);
    TRIGGER_GROUP_ANCHOR_BY_TOKEN.set(token, owner);
    TRIGGER_TOKENS.add(token);
    registerTriggerMember(token, owner, true);
    token[TRIGGER_OWNER_MARK2] = owner;
    projectTriggerGroupAnchor(token);
    syncLogicalEventTarget(token);
    notifyTriggerSurface(owner);
  }
  function recomputeTriggerGroup(token) {
    if (!isRegisteredTrigger(token)) return;
    let owner = token;
    let parent2 = PARENT_BY_TOKEN.get(token);
    while (parent2 && isRegisteredTrigger(parent2)) {
      owner = parent2;
      parent2 = PARENT_BY_TOKEN.get(parent2);
    }
    mergeTriggerGroup(token, owner);
  }
  function recomputeTriggerBranch(token) {
    recomputeTriggerGroup(token);
    for (const child2 of CHILDREN_BY_TOKEN.get(token) ?? []) {
      recomputeTriggerBranch(child2);
    }
  }
  function setLogicalParentInternal(token, parent2) {
    const previous = PARENT_BY_TOKEN.get(token);
    if (previous === parent2 || !previous && !parent2) return;
    if (isRegisteredTrigger(token)) assertContinuousTriggerChain(token, parent2);
    if (previous) CHILDREN_BY_TOKEN.get(previous)?.delete(token);
    if (parent2) {
      PARENT_BY_TOKEN.set(token, parent2);
      let children = CHILDREN_BY_TOKEN.get(parent2);
      if (!children) {
        children = /* @__PURE__ */ new Set();
        CHILDREN_BY_TOKEN.set(parent2, children);
      }
      children.add(token);
    } else {
      PARENT_BY_TOKEN.delete(token);
    }
    recomputeTriggerBranch(token);
  }
  function projectTriggerGroupAnchor(token) {
    const root = INSTANCE_BY_TOKEN.get(token);
    if (!root) return;
    const owner = TRIGGER_GROUP_ANCHOR_BY_TOKEN.get(token);
    if (owner && TRIGGER_TOKENS.has(token)) {
      root[TRIGGER_OWNER_MARK2] = owner;
    } else delete root[TRIGGER_OWNER_MARK2];
  }
  function createLogicalInstance(proto2) {
    const token = {};
    PROTO_BY_TOKEN.set(token, proto2);
    TRIGGER_GROUP_ANCHOR_BY_TOKEN.set(token, token);
    return token;
  }
  function bindLogicalParent(token, parent2, options2) {
    if (options2?.authority === "owner") {
      const previous = PARENT_BY_TOKEN.get(token);
      if (previous !== parent2 && (previous || parent2) && isRegisteredTrigger(token)) {
        assertContinuousTriggerChain(token, parent2);
      }
      OWNER_PARENT_TOKENS.add(token);
    }
    setLogicalParentInternal(token, parent2);
  }
  function markProtoInstance(el, proto2, token = createLogicalInstance(proto2), clearMissingParent = false) {
    const parentRoot = getProtoParent(el);
    const parentToken2 = parentRoot ? TOKEN_BY_INSTANCE.get(parentRoot) : void 0;
    if (TRIGGER_TOKENS.has(token)) {
      assertContinuousTriggerChain(
        token,
        OWNER_PARENT_TOKENS.has(token) ? PARENT_BY_TOKEN.get(token) : parentToken2 ?? PARENT_BY_TOKEN.get(token)
      );
    }
    el[PROTO_INSTANCE] = true;
    PROTO_BY_INSTANCE.set(el, proto2);
    TOKEN_BY_INSTANCE.set(el, token);
    INSTANCE_BY_TOKEN.set(token, el);
    PROTO_BY_TOKEN.set(token, proto2);
    projectTriggerGroupAnchor(token);
    if (TRIGGER_TOKENS.has(token)) {
      const owner = TRIGGER_GROUP_ANCHOR_BY_TOKEN.get(token) ?? token;
      registerTriggerMember(token, owner, true);
      notifyTriggerSurface(owner);
    } else {
      notifyInstanceLifecycle(token);
    }
    if (!OWNER_PARENT_TOKENS.has(token) && (parentToken2 || clearMissingParent)) {
      setLogicalParentInternal(token, parentToken2 ?? null);
    }
    for (const descendant of el.querySelectorAll("*")) {
      const descendantToken = TOKEN_BY_INSTANCE.get(descendant);
      if (!descendantToken || OWNER_PARENT_TOKENS.has(descendantToken)) continue;
      const nearestParent = getProtoParent(descendant);
      if (nearestParent !== el) continue;
      setLogicalParentInternal(descendantToken, token);
    }
    return token;
  }
  function unbindProtoInstance(token, el) {
    const current = INSTANCE_BY_TOKEN.get(token);
    if (!current || el && current !== el) return;
    const wasTrigger = TRIGGER_TOKENS.has(token);
    INSTANCE_BY_TOKEN.delete(token);
    TOKEN_BY_INSTANCE.delete(current);
    PROTO_BY_INSTANCE.delete(current);
    delete current[PROTO_INSTANCE];
    delete current[TRIGGER_OWNER_MARK2];
    unregisterTriggerMember(token);
    notifyInstanceLifecycle(token);
  }
  function mergeLogicalTriggerGroup(token, anchor) {
    mergeTriggerGroup(token, anchor);
    for (const child2 of CHILDREN_BY_TOKEN.get(token) ?? []) recomputeTriggerBranch(child2);
    queueMicrotask(() => {
      notifyTriggerSurface(anchor);
      queueMicrotask(() => notifyTriggerSurface(anchor));
    });
  }
  function getLogicalTriggerGroupAnchor(token) {
    return TRIGGER_GROUP_ANCHOR_BY_TOKEN.get(token) ?? token;
  }
  function getLogicalEventRouteSurfaceForTarget(target) {
    let cur = isDomNode2(target) ? target : null;
    const visited = /* @__PURE__ */ new Set();
    while (cur) {
      if (visited.has(cur)) return null;
      visited.add(cur);
      if (isShadowRoot2(cur)) {
        cur = cur.host;
        continue;
      }
      if (isHtmlElement2(cur)) {
        const token = TOKEN_BY_INSTANCE.get(cur);
        if (token) {
          const owner = TRIGGER_GROUP_ANCHOR_BY_TOKEN.get(token) ?? token;
          return TRIGGER_GROUP_SURFACE_BY_ANCHOR.get(owner) ?? token;
        }
        const linkedParent = readProtoParentMark(cur) ?? PROTO_PARENT_BY_INSTANCE.get(cur) ?? null;
        if (linkedParent && linkedParent !== cur) {
          cur = linkedParent;
          continue;
        }
      }
      cur = cur.parentNode;
    }
    return null;
  }
  function resolveLogicalTriggerEventRouteForTarget(target, visited = /* @__PURE__ */ new Set()) {
    let cur = isDomNode2(target) ? target : null;
    while (cur) {
      if (visited.has(cur)) return null;
      visited.add(cur);
      if (isShadowRoot2(cur)) {
        cur = cur.host;
        continue;
      }
      if (isHtmlElement2(cur)) {
        const token = TOKEN_BY_INSTANCE.get(cur);
        if (token && TRIGGER_TOKENS.has(token)) {
          const owner = TRIGGER_GROUP_ANCHOR_BY_TOKEN.get(token) ?? token;
          const surface = TRIGGER_GROUP_SURFACE_BY_ANCHOR.get(owner) ?? token;
          return { matched: true, accepted: token === surface, surface };
        }
        const linkedParent = readProtoParentMark(cur) ?? PROTO_PARENT_BY_INSTANCE.get(cur) ?? null;
        if (linkedParent && linkedParent !== cur) {
          cur = linkedParent;
          continue;
        }
      }
      cur = cur.parentNode;
    }
    return null;
  }
  function isLogicalEventRouteCandidate(root, targets) {
    const path = new Set(targets);
    if (path.has(root)) return true;
    const visited = /* @__PURE__ */ new Set();
    const reachesRoot = (start) => {
      let node = isDomNode2(start) ? start : null;
      while (node) {
        if (node === root) return true;
        if (visited.has(node)) return false;
        visited.add(node);
        if (isHtmlElement2(node)) {
          const linked = readProtoParentMark(node) ?? PROTO_PARENT_BY_INSTANCE.get(node);
          if (linked && linked !== node && reachesRoot(linked)) return true;
        }
        node = isShadowRoot2(node) ? node.host : node.parentNode;
      }
      return false;
    };
    for (const target of targets) {
      if (!isDomNode2(target)) continue;
      if (isHtmlElement2(target)) {
        const linked = readProtoParentMark(target) ?? PROTO_PARENT_BY_INSTANCE.get(target);
        if (linked && !path.has(linked) && reachesRoot(linked)) return true;
      }
      const parent2 = isShadowRoot2(target) ? target.host : target.parentNode;
      if (parent2 && !path.has(parent2) && reachesRoot(parent2)) return true;
    }
    return false;
  }
  function getLogicalTriggerSurfaceOwner(token) {
    const owner = TRIGGER_GROUP_ANCHOR_BY_TOKEN.get(token) ?? token;
    return TRIGGER_GROUP_SURFACE_BY_ANCHOR.get(owner) ?? token;
  }
  function getLogicalTriggerSurfaceRoot(token) {
    return INSTANCE_BY_TOKEN.get(getLogicalTriggerSurfaceOwner(token)) ?? null;
  }
  function subscribeLogicalTriggerSurface(token, listener) {
    let listeners = TRIGGER_SURFACE_LISTENERS.get(token);
    if (!listeners) {
      listeners = /* @__PURE__ */ new Set();
      TRIGGER_SURFACE_LISTENERS.set(token, listeners);
    }
    listeners.add(listener);
    return () => listeners?.delete(listener);
  }
  function getLogicalEventTarget(token) {
    let target = EVENT_TARGET_BY_TOKEN.get(token);
    if (!target) {
      target = createRebindableEventTarget();
      EVENT_TARGET_BY_TOKEN.set(token, target);
    }
    return target;
  }
  function bindLogicalEventTarget(token, target) {
    BOUND_EVENT_TARGET_BY_TOKEN.set(token, target);
    syncLogicalEventTarget(token);
  }
  function unbindLogicalEventTarget(token, target) {
    const bridge = EVENT_TARGET_BY_TOKEN.get(token);
    const bound = BOUND_EVENT_TARGET_BY_TOKEN.get(token);
    if (!bridge || target && bound !== target) return;
    BOUND_EVENT_TARGET_BY_TOKEN.delete(token);
    syncLogicalEventTarget(token);
  }
  const PROTO_PARENT_BY_INSTANCE = /* @__PURE__ */ new WeakMap();
  function setProtoParent(instance, parent2) {
    if (parent2) {
      PROTO_PARENT_BY_INSTANCE.set(instance, parent2);
      writeProtoParentMark(instance, parent2);
    } else {
      PROTO_PARENT_BY_INSTANCE.delete(instance);
      writeProtoParentMark(instance, null);
    }
    const token = TOKEN_BY_INSTANCE.get(instance);
    if (!token || OWNER_PARENT_TOKENS.has(token)) return;
    const parentRoot = parent2 ? isProtoInstance(parent2) ? parent2 : getProtoParent(parent2) : null;
    const parentToken2 = parentRoot ? TOKEN_BY_INSTANCE.get(parentRoot) : void 0;
    setLogicalParentInternal(token, parentToken2 ?? null);
  }
  function clearProtoParentProjection(instance) {
    PROTO_PARENT_BY_INSTANCE.delete(instance);
    writeProtoParentMark(instance, null);
  }
  function getProtoParent(instance) {
    let cur = readProtoParentMark(instance) ?? PROTO_PARENT_BY_INSTANCE.get(instance) ?? instance.parentNode;
    while (cur) {
      if (isShadowRoot2(cur)) {
        cur = cur.host;
        continue;
      }
      if (isProtoInstance(cur)) return cur;
      if (isHtmlElement2(cur)) {
        const linkedParent = readProtoParentMark(cur) ?? PROTO_PARENT_BY_INSTANCE.get(cur) ?? null;
        if (linkedParent && linkedParent !== cur) {
          cur = linkedParent;
          continue;
        }
      }
      cur = cur.parentNode;
    }
    return null;
  }
  function getPrototypeByInstance(instance) {
    return PROTO_BY_INSTANCE.get(instance) ?? null;
  }
  function getLogicalParent(token) {
    return PARENT_BY_TOKEN.get(token) ?? null;
  }
  function getLogicalRoot(token) {
    return INSTANCE_BY_TOKEN.get(token) ?? null;
  }
  function getLogicalPrototype(token) {
    return PROTO_BY_TOKEN.get(token) ?? null;
  }
  function isProtoInstance(node) {
    if (!node) return false;
    return node[PROTO_INSTANCE] === true;
  }
  return {
    PROTO_INSTANCE,
    createLogicalInstance,
    bindLogicalParent,
    markProtoInstance,
    unbindProtoInstance,
    setProtoParent,
    clearProtoParentProjection,
    getProtoParent,
    getPrototypeByInstance,
    getLogicalParent,
    getLogicalRoot,
    getLogicalPrototype,
    mergeLogicalTriggerGroup,
    getLogicalTriggerGroupAnchor,
    /** @deprecated Use mergeLogicalTriggerGroup. */
    setLogicalEventRouteOwner: mergeLogicalTriggerGroup,
    /** @deprecated Use getLogicalTriggerGroupAnchor. */
    getLogicalEventRouteOwner: getLogicalTriggerGroupAnchor,
    getLogicalEventRouteSurfaceForTarget,
    resolveLogicalTriggerEventRouteForTarget,
    isLogicalEventRouteCandidate,
    getLogicalTriggerSurfaceOwner,
    getLogicalTriggerSurfaceRoot,
    subscribeLogicalTriggerSurface,
    getLogicalEventTarget,
    bindLogicalEventTarget,
    unbindLogicalEventTarget,
    isProtoInstance
  };
}

// ../../../task-state/proto-ui-883/keyboard-owner-p2-20261018T1302Z/native-plan/fixture.ts
var tree = createInstanceTreeMarkers("@proto.ui/adapter-vue/__proto_instance");
var proto = { name: "native-keyboard-child-owner", setup: () => void 0 };
var parent = document.createElement("div");
var child = document.createElement("div");
parent.id = "parent";
child.id = "child";
parent.textContent = "Parent with a press consumer";
child.textContent = "Focused child with a key.down consumer";
child.tabIndex = 0;
parent.append(child);
document.body.append(parent);
var parentToken = tree.markProtoInstance(parent, proto);
var childToken = tree.markProtoInstance(child, proto);
var outer = createWebProtoEventRouter({
  rootEl: parent,
  instanceToken: parentToken,
  isEnabled: () => true
});
var inner = createWebProtoEventRouter({
  rootEl: child,
  instanceToken: childToken,
  isEnabled: () => true
});
var nativeIds = /* @__PURE__ */ new WeakMap();
var nextId = 0;
var idFor = (event) => {
  let id = nativeIds.get(event);
  if (id === void 0) nativeIds.set(event, id = ++nextId);
  return id;
};
var targetId = (target) => target instanceof Element ? target.id || target.tagName : String(target);
var nativeEvents = [];
var deliveries = [];
var observeNative = (event) => {
  nativeEvents.push({
    id: idFor(event),
    type: event.type,
    key: event.key,
    isTrusted: event.isTrusted,
    target: targetId(event.target),
    composedPath: event.composedPath().map(targetId),
    at: performance.now()
  });
};
document.addEventListener("keydown", observeNative, { capture: true, passive: true });
document.addEventListener("keyup", observeNative, { capture: true, passive: true });
var observeDelivery = (kind) => (event) => {
  const native = event.detail.nativeEvent;
  deliveries.push({
    kind,
    nativeId: idFor(native),
    key: native.key,
    isTrusted: native.isTrusted,
    target: targetId(native.target),
    at: performance.now()
  });
};
outer.rootTarget.addEventListener("press.commit", observeDelivery("parent.press"));
inner.rootTarget.addEventListener("key.down", observeDelivery("child.rootKey"));
inner.globalTarget.addEventListener("key.down", observeDelivery("child.globalKey"));
window.__keyboardOwnerFixture = {
  read: () => ({
    activeElement: targetId(document.activeElement),
    parentConnected: parent.isConnected,
    childConnected: child.isConnected,
    nativeEvents,
    deliveries
  }),
  dispose: () => {
    inner.dispose();
    outer.dispose();
    document.removeEventListener("keydown", observeNative, true);
    document.removeEventListener("keyup", observeNative, true);
    tree.unbindProtoInstance(childToken, child);
    tree.unbindProtoInstance(parentToken, parent);
    parent.remove();
  }
};
