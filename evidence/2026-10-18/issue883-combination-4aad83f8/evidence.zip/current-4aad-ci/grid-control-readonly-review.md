# 4aad parent-grid 控制：只读复核

结论：单独加 `grid-cols-1` 不能作为本项修复。B 阶段虽把 Root 收到14px，但其 `scrollWidth=82/clientWidth=14`，新增68px内部溢出；原 `scrollWidth <= clientWidth + 1` 仍不满足。原320px/200%、合法 Content padding 和全部几何标准均应保留。

实际执行是父代理于2026-10-17 18:22:30–18:22:33 UTC 对4aad官方完整预览产物的一个独立 WC/English/light 控制（Chrome155.0.8059.80），不是原36项suite。本次只读核对原记录；driver与server均exit0、errors=[]只说明诊断完成。源码仍clean `4aad83f80ab29e0a5d4f3c0b63af17e3dcf64e06` / `cd35b1f9f6d60c24a99c886ccca9958af0e4227b`。

| 阶段 | 父grid宽/track | Root宽 | Root client/scroll | Root left/right |
| --- | --- | --- | --- | --- |
| A before |46 /170.609px|170.609375|171/171|149 /319.609375|
| B single-track |46 /14px|14|14/82|153 /167|
| A′ restored |46 /170.609px|170.609375|171/171|153 /323.609375|

24层实际祖先把可用宽度连起来：共享 `main-pane` 256px、横向padding各40px → `main` 176px；material scene176px、padding各64px → mount/runtime surface48px；surface左右各1pxborder → demoBox46px；demoBox左右各16pxpadding → 内容宽14px。当前Root的 `grid w-full min-w-0 max-w-full` 与Content的合法 `p-4` 均实际存在。对应源码是 `TwoColumnContent.astro:6`、`preview-material-scene.ts:14–49`、`demo-renderer.ts:1014–1034`，以及demo的顺序单列children；完整Git blob/SHA/永久链接见JSON。通用 `grid-cols-1` 投射已有支持，这并不说明它能单独解决该组合。

证据指向共享阅读容器/Previewer material scene/demo包含块的组合约束。它没有建立新的C Anatomy/Runtime epoch或instance退役失效，也不决定应该由哪一层删padding或改变布局。保持既有app/material责任边界，不将问题转交C，也不宣称已修或接受。

A′只恢复了宽度，坐标比A偏移4px；原记录没有 `window.scrollX`，因此不能称完美A/B/A或解释偏移原因。24层链仍被截断，最外256px来源尚未完整采集。Linux原suite的177.4375px与此Mac产物170.609375px不同，不能把本控制称为精确Linux复现或归因字体。

3张原PNG已经逐张实际查看并SHA绑定：Header遮挡上部、长组件超出视口；B图呈单字/碎片极窄竖排；恢复图右侧有裁切。PNG在facts之后请求，不是原数值的原子画面。未编辑、重编码或补拍。原Linux32pass/4fail与独立focus8pass/36filtered保留；未作AT/完整视觉/光学/平台验收。

报告：[grid-control-readonly-review.json](./grid-control-readonly-review.json)。原控制：[observations.json](../collapsible-grid-control/actual/observations.json)。评估状态：human-assisted、unassessed、partial/ABSTAIN。
