4aad普通CI失败分流已完成，结论仍为human-assisted / unassessed / partial / ABSTAIN。CI39056665955终态22jobs=12success/10failure；完整3/4/5/6/7仅合计541pass/17fail/15skip，1/2/8原900s退出124，无完整summary，不能计算all8测试总数。当前color9/9包含mountedrecommit确已通过。

两处确认的fixture漂移交各family/test owner，不作为C生产修复：

- Checkbox：job117467020075:585，原test327，wc/light pressed-shadow期待变化，但draft P-BRUTALIST-CHECKBOX-STATE-PRESENTATION明确press不改变几何或阴影。data-pressed和几何原断言此前已过；保留它们和释放/语义检查，仅按规则校准阴影，不能加生产shadow迁就旧测试。T浏览器实现本已planned。
- Liquid disabled：job117467020006:562，原test124，两个theme opacity1对0.5。当前P及C-LIQUID-GLASS-COMMAND-INTERACTION明确不降低whole-hostopacity，COMMAND_DISABLED也无opacity。维护者可只修Liquid分支期望，保留Bootstrap0.65与全部语义/disabled准入。日志没有具体runtime标签，不补造。

Tooltip仍是实质未知边界：job117467020075:596，Vue2 pressed-scale1000ms一直none，P明确要求scale[0.98]，不能删断言。一次获授权下载当前artifact12110327633，SHA81463925fb36c8c13114898d39fef0d1e3af12c99aa322b1833aa97afb58eb74，13698052B，262members；只提取failure.json。8records/dropped0表明真实pointerdown/mousedown命中同一connectedidentity1/currentCount1，rect/scroll不变，最终仍无scale token、transform/scale/变量。Observer不读pressed状态或逻辑epoch，不能断定Runtime、RuleFeedback或逻辑owner谁负责；诊断也明确pageSourceRevision未单独attest。

S4/S5两语种均先停整页所有previewer的data-inited/host-child前置60s门槛，尚未调用各自journey，不能声称关闭/编辑生命周期出现反例。S4paint只有150s总超时，无具体await或重绘反例。旧main042的S5同line29红仅保留历史，不冒充新组合配对证明。

最后shard1还留下两个具体C调查入口：Shadcn/Vue设置任务在Home→ArrowDown→Enter后listbox持续data-open/entered，30s隐藏等待失败，尚未到textarea填写/重置；Shadow原生DOM portal mounted/removed/restored对象deepEqual失败，但日志未给哪项不同，不能直接断言unmountrestore坏了。另55项Liquidportal文件确实54pass1css-zoomfail，这个完成文件结果可保留，不能据此补齐整个超时分片。Search的1s未ready/nullowner记录、其余Header/Material/布局失败也均保留原因未知。

23个相关测试/P/T/实现blob与main042逐字相同；这是源码保存事实，不是相同行为、完整依赖闭包或继承归因。完整来源、稳定ID、首分歧日志行、authority与最小下一步见JSON。未改源、运行测试/native或GitHub写入。
