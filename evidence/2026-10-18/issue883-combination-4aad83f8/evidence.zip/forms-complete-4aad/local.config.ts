import base from "<SOURCE_ROOT>/vitest.config.ts";
import fs from "node:fs";
import path from "node:path";
const repo = "<SOURCE_ROOT>";
const input =
  "<PRIVATE_STATE>/forms-complete-4aad/local.browser.test.ts";
const output =
  "<PRIVATE_STATE>/forms-complete-4aad";
export default {
  ...base,
  root: repo,
  cacheDir: path.join(output, "vite-cache"),
  plugins: [
    {
      name: "explicit-private-built-form-diagnostic",
      enforce: "pre",
      load(id) {
        if (
          path.relative(repo, id.split("?")[0].replace(/^\/@fs/, "")) ===
          "apps/www/src/content/docs/zh-cn/finf-representative-features.browser.test.ts"
        )
          return fs.readFileSync(input, "utf8");
        return null;
      },
    },
    ...(base.plugins ?? []),
  ],
  test: {
    ...base.test,
    include: [
      "apps/www/src/content/docs/zh-cn/finf-representative-features.browser.test.ts",
    ],
    maxWorkers: 1,
    minWorkers: 1,
    fileParallelism: false,
    reporters: ["verbose", "json"],
    outputFile: { json: path.join(output, "vitest.json") },
  },
};
