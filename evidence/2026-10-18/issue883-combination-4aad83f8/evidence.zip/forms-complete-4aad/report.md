# 4aad Form 完整行为验证

准确4aad已构建预览的两条独立 React 流程均通过：Shadcn与Brutalist各1case，共2/2。实际native为2026-10-17 18:38:32–18:38:40 UTC，server18:38:41 exit0；原官方颜色测试并未改写或重跑，颜色红项保留。

每条流程完成：空值提交→首编辑器焦点/required错误/Label与Error IDREF；填displayName后的完整提交；reset全部默认值；reset后再次invalid；实际点击数量+、填写OTP、点击SMS，再完整提交；再次reset后新提交。六个公开status快照精确为五字段：

| 每family提交 | displayName | quantity | code | level | channels |
| --- | --- | --- | --- | --- | --- |
|1|Form behavior one|2|12|25|email|
|2|Form behavior two|3|1234|25|email,sms|
|3|After reset|2|12|25|email|

此次没有app callback override。原 `form-primitives-demo.shared.ts:136–139` 的onSubmit写公开status，本driver读取实际文本；不能据此宣称callback次数或submissionId已测。原生事件记录共20trusted点击、8trusted input和8trusted change；另记录2个React runtime tab的untrusted click，未算作native。无State/Props/privateflag/expose调用。

两family的pageErrors、consoleErrors、failedRequests均为空。两次invalid首焦点与IDREF断言均执行通过。reset后的旧status保留是原report仅在submit写status的行为；它没有被当成当前field值，后续提交验证了新快照。

配色仍明确失败：两family均 `labelEqualsError=false`、`labelChanged=false`；Shadcn标签/Field为lab(2.75381 0 0)，错误为lab(48.4493 77.4328 61.5452)；Brutalist标签黑、错误rgb(159,18,57)。14张原PNG全部逐张view，直观看到错误为红、label仍深色；其余状态值、reset和完整status一致。14份DOM/AX已读；是Previewer裁图，不是全页面/AT/完整视觉验收。

来源：head `4aad83f80ab29e0a5d4f3c0b63af17e3dcf64e06`，tree `cd35b1f9f6d60c24a99c886ccca9958af0e4227b`；11329 tracked inputs前后相同且clean。真实existingpublisher在flock保护下刷新lease，run39056666060/artifact12109493824的3835文件逐SHA等原ZIP且运行前后无变化；149个实际请求路径绑定到builtmembers。执行Nodev24.21.0/pnpm10.32.1/Chrome155.0.8059.80，Darwinarm64，原1365×1000/light/zh-CN/UTC上下文及原timeouts。私有Vitest配置以明确的独立test替换测试模块加载，不修改应用builtbytes，不冒充officialsuite。

限制：无async/retirement/controlled/reentrant场景，无其他Adapter、dark/narrow、slider拖动、辅助技术或光学验收；没有证明全部C语义或旧CI根因关闭。原官方10/2配色红保持独立。此次未修改产品、未commit/push/外写。所有自有测试/browser/server终态，端口57804无listener。

[机器报告](./report.json) · [逐图review](./visual-review.json) · [DOM/AX review](./dom-ax-review.json) · [真实run收据](./native-receipt.json)。评估human-assisted、unassessed、partial/ABSTAIN。
