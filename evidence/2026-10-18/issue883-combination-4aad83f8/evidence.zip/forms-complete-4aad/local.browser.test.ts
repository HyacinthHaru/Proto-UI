// @vitest-environment node
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import {
  chromium,
  type Browser,
  type Page,
  type Locator,
} from "playwright-core";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
const output = process.env.PUI_FORM_BUILT_OUTPUT!;
const baseUrl = process.env.PUI_FORM_BUILT_URL!;
const binding = JSON.parse(
  await readFile(path.join(output, "source-binding.json"), "utf8"),
);
const RUNTIME_LABELS = {
  wc: "Web Components",
  react: "React",
  vue: "Vue",
  vue2: "Vue 2",
} as const;
type RuntimeId = keyof typeof RUNTIME_LABELS;
let browser: Browser;
let failed = false;
const requestPaths = new Set<string>();
async function paint(locator: Locator) {
  return locator.evaluate((element) => {
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    const range = document.createRange();
    range.selectNodeContents(element);
    const textRect = range.getBoundingClientRect();
    return {
      rect: {
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
        right: rect.right,
        bottom: rect.bottom,
      },
      textWidth: textRect.width,
      display: style.display,
      visibility: style.visibility,
      color: style.color,
      background: style.backgroundColor,
      shadow: style.boxShadow,
      border: [
        style.borderTopWidth,
        style.borderRightWidth,
        style.borderBottomWidth,
        style.borderLeftWidth,
      ],
      borderColor: style.borderBottomColor,
      radius: style.borderRadius,
      padding: [
        style.paddingTop,
        style.paddingRight,
        style.paddingBottom,
        style.paddingLeft,
      ],
      font: style.font,
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      outline: style.outline,
      opacity: style.opacity,
      clientWidth: element.clientWidth,
      scrollWidth: element.scrollWidth,
      scrollLeft: element.scrollLeft,
      overflowX: style.overflowX,
      ariaSelected: element.getAttribute("aria-selected"),
      ariaChecked: element.getAttribute("aria-checked"),
    };
  });
}

async function hasFocus(locator: Locator) {
  return locator.evaluate((element) => {
    let active = document.activeElement;
    while (active?.shadowRoot?.activeElement)
      active = active.shadowRoot.activeElement;
    while (active) {
      if (element === active || element.contains(active)) return true;
      const root = active.getRootNode();
      active = root instanceof ShadowRoot ? root.host : null;
    }
    return false;
  });
}

// Suite-local: fixed projections and generic embeds own different real Tabs shells.
// Do not fall back to the obsolete Select control or change the shared harness.
async function runtimeControls(previewer: Locator) {
  const fixed =
    (await previewer.getAttribute("data-projection-mode")) === "fixed-family";
  return previewer.locator(
    fixed
      ? '[data-projection-scope][data-projection-state="ready"] [data-projection-control="runtime"][data-runtime-tabs]'
      : "[data-runtime-tabs-mount] [data-runtime-tabs-root]",
  );
}

async function runtimeTab(previewer: Locator, runtime: RuntimeId) {
  return (await runtimeControls(previewer)).getByRole("tab", {
    name: RUNTIME_LABELS[runtime],
    exact: true,
  });
}

// This function is serialized into the page; keep every dependency inside it.
function inspectRuntime(
  root: HTMLElement,
  request: {
    runtime: RuntimeId;
    label: string;
    readySelector: string;
    count: number;
  },
) {
  const { runtime, label, readySelector, count } = request;
  const fixed = root.dataset.projectionMode === "fixed-family";
  const scopes = root.querySelectorAll<HTMLElement>("[data-projection-scope]");
  const scope = scopes.length === 1 ? scopes[0] : null;
  const hosts = root.querySelectorAll<HTMLElement>(".host");
  const host = hosts.length === 1 ? hosts[0] : null;
  const controls = root.querySelectorAll<HTMLElement>(
    fixed
      ? '[data-projection-scope][data-projection-state="ready"] [data-projection-control="runtime"][data-runtime-tabs]'
      : "[data-runtime-tabs-mount] [data-runtime-tabs-root]",
  );
  const control = controls.length === 1 ? controls[0] : null;
  const selected = control?.querySelectorAll<HTMLElement>(
    '[role="tab"][aria-selected="true"]',
  );
  const tab = selected?.length === 1 ? selected[0] : null;
  const content = fixed
    ? scope?.querySelector<HTMLElement>("[data-projection-content]")
    : host;
  const committed = fixed
    ? scope?.dataset.projectionRuntime
    : (
        root as HTMLElement & {
          __previewer__?: { getCurrentRuntime(): string | null };
        }
      ).__previewer__?.getCurrentRuntime();
  const surfaces = content?.querySelectorAll<HTMLElement>(
    '.pui-runtime-preview-surface[data-demo-ref="__website_runtime_preview_surface__"]',
  );
  const surface = surfaces?.length === 1 ? surfaces[0] : null;
  const firstRoot = surface?.querySelector<HTMLElement>("[data-pui-root]");
  const unavailable = (element: HTMLElement | null | undefined) => {
    if (!element?.isConnected) return true;
    for (
      let current: HTMLElement | null = element;
      current;
      current = current.parentElement
    ) {
      if (
        current.inert ||
        current.matches(
          '[inert], [hidden], [aria-hidden="true"], [aria-busy="true"], [aria-disabled="true"], [data-previewer-startup-pending], [data-previewer-startup-shell]',
        )
      )
        return true;
      const style = getComputedStyle(current);
      if (style.display === "none" || style.visibility === "hidden")
        return true;
    }
    return false;
  };
  const framework = !firstRoot
    ? null
    : firstRoot.tagName.startsWith("WC-")
      ? "wc"
      : (firstRoot as HTMLElement & { __vue__?: unknown }).__vue__
        ? "vue2"
        : host?.hasAttribute("data-v-app") || firstRoot.closest("[data-v-app]")
          ? "vue"
          : Object.keys(surface!).some((key) => key.startsWith("__reactFiber$"))
            ? "react"
            : null;
  const targetCount = surface?.querySelectorAll(readySelector).length ?? 0;
  const problems: string[] = [];
  if (!host || !content || controls.length !== 1)
    problems.push("missing-or-ambiguous-shell");
  if (
    fixed &&
    (scopes.length !== 1 || scope?.dataset.projectionState !== "ready")
  )
    problems.push("projection-not-ready");
  if (!fixed && scopes.length) problems.push("unexpected-fixed-scope");
  if (committed !== runtime) problems.push("runtime-not-committed");
  if (
    !tab ||
    tab.textContent?.trim() !== label ||
    (!fixed && tab.dataset.runtimeTab !== runtime)
  )
    problems.push("runtime-tab-not-selected");
  if (
    unavailable(host) ||
    unavailable(control) ||
    unavailable(tab) ||
    unavailable(surface)
  )
    problems.push("shell-not-interactive");
  if (
    root.querySelector(
      "[data-previewer-startup-pending], [data-previewer-startup-shell], .proto-previewer__skeleton",
    )
  )
    problems.push("startup-pending");
  if (
    !surface?.hasAttribute("data-pui-root") ||
    Array.from(content?.querySelectorAll("[data-pui-root]") ?? []).some(
      (element) => element !== surface && !surface?.contains(element),
    )
  )
    problems.push("missing-or-extra-demo-surface");
  if (framework !== runtime) problems.push("wrong-framework");
  if (!firstRoot || targetCount !== count)
    problems.push("target-controls-not-ready");
  return {
    ready: problems.length === 0,
    shell: fixed ? "fixed-family" : "generic",
    committedRuntime: committed ?? null,
    selectedLabel: tab?.textContent?.trim() ?? null,
    surfaceCount: surfaces?.length ?? 0,
    framework,
    targetCount,
    problems,
  };
}

async function waitForRealRuntime(
  previewer: Locator,
  runtime: RuntimeId,
  readySelector: string,
  count: number,
) {
  await expect
    .poll(
      () =>
        previewer.evaluate(inspectRuntime, {
          runtime,
          label: RUNTIME_LABELS[runtime],
          readySelector,
          count,
        }),
      { timeout: 20_000 },
    )
    .toMatchObject({ ready: true });
}

async function selectRealRuntime(
  page: Page,
  previewer: Locator,
  runtime: RuntimeId,
  readySelector: string,
  count: number,
) {
  const tab = await runtimeTab(previewer, runtime);
  await tab.waitFor({ state: "visible" });
  if ((await tab.getAttribute("aria-selected")) !== "true") await tab.click();
  await waitForRealRuntime(previewer, runtime, readySelector, count);
  await expect
    .poll(async () =>
      (await runtimeTab(previewer, runtime)).getAttribute("aria-selected"),
    )
    .toBe("true");
}

async function keyboardReach(page: Page, target: Locator) {
  for (let attempt = 0; attempt < 30; attempt++) {
    if (await hasFocus(target)) return;
    await page.keyboard.press("Tab");
  }
  throw new Error("Target was not reached by 30 real Tab key presses.");
}

const json = (file: string, value: unknown) =>
  writeFile(path.join(output, file), JSON.stringify(value, null, 2) + "\n");
async function journey(family: string) {
  if (failed)
    throw new Error(
      "Prior actual failure retained; subsequent family not started",
    );
  const context = await browser.newContext({
    viewport: { width: 1440, height: 1000 },
    locale: "en-US",
    colorScheme: "light",
  });
  const page = await context.newPage();
  page.setDefaultTimeout(15_000);
  const errors: unknown[] = [],
    consoleErrors: unknown[] = [],
    failedRequests: unknown[] = [],
    states: unknown[] = [],
    submissions: unknown[] = [];
  let phase = "setup",
    failure: unknown = null;
  page.on("pageerror", (error) =>
    errors.push({
      phase,
      at: new Date().toISOString(),
      message: error.message,
      stack: error.stack,
    }),
  );
  page.on("console", (message) => {
    if (message.type() === "error")
      consoleErrors.push({
        phase,
        at: new Date().toISOString(),
        text: message.text(),
      });
  });
  page.on("requestfailed", (request) =>
    failedRequests.push({
      phase,
      url: request.url(),
      error: request.failure(),
    }),
  );
  page.on("request", (request) => {
    const url = new URL(request.url());
    if (url.origin === new URL(baseUrl).origin) requestPaths.add(url.pathname);
  });
  await context.addInitScript(() => {
    const events: unknown[] = [];
    Object.defineProperty(window, "__formBuiltNativeEvents", { value: events });
    for (const type of [
      "pointerdown",
      "pointerup",
      "click",
      "input",
      "change",
      "keydown",
    ])
      document.addEventListener(
        type,
        (event) => {
          const el = event.target instanceof Element ? event.target : null;
          events.push({
            at: performance.now(),
            type,
            isTrusted: event.isTrusted,
            tag: el?.localName,
            role: el?.getAttribute("role"),
            label: el?.getAttribute("aria-label"),
            text: el?.textContent?.trim().slice(0, 80),
            key: event instanceof KeyboardEvent ? event.key : undefined,
          });
        },
        true,
      );
  });
  const previewer = page.locator("[data-previewer-id]").first();
  const form = previewer.locator('[data-demo-ref="form"]');
  const editor = form.getByRole("textbox", {
    name: "displayName",
    exact: true,
  });
  const label = form.getByText("displayName", { exact: true });
  const field = label.locator("..");
  const quantity = form.getByRole("spinbutton", {
    name: "Quantity · 数量",
    exact: true,
  });
  const code = form.getByRole("textbox", {
    name: "Code · 验证码",
    exact: true,
  });
  const level = form.getByRole("slider", { name: "Level · 等级", exact: true });
  const email = form.getByRole("checkbox", {
    name: "Email · 邮件",
    exact: true,
  });
  const sms = form.getByRole("checkbox", { name: "SMS · 短信", exact: true });
  const submit = form.getByRole("button", { name: /Validate and submit/ });
  const reset = form.getByRole("button", { name: /Reset values/ });
  const status = previewer.locator('[data-demo-ref="status"]');
  const values = (
    displayName: string,
    quantity = 2,
    code = "12",
    channels = ["email"],
  ) => ({ displayName, quantity, code, level: 25, channels });
  const capture = async (state: string, extra: unknown = {}) => {
    const prefix = `${family}-${state}`;
    const facts = {
      state,
      phase,
      at: new Date().toISOString(),
      status: await status.textContent(),
      displayName: await editor.inputValue(),
      quantity: await quantity.inputValue(),
      code: await code.inputValue(),
      level: await level.getAttribute("aria-valuenow"),
      email: await email.getAttribute("aria-checked"),
      sms: await sms.getAttribute("aria-checked"),
      invalid: await editor.getAttribute("aria-invalid"),
      errorId: await editor.getAttribute("aria-errormessage"),
      labelId: await label.getAttribute("id"),
      labelledBy: await editor.getAttribute("aria-labelledby"),
      focused: await hasFocus(editor),
      extra,
    };
    await json(prefix + ".json", facts);
    await writeFile(path.join(output, prefix + ".html"), await page.content());
    await writeFile(
      path.join(output, prefix + ".ax.txt"),
      await page.locator("body").ariaSnapshot(),
    );
    await page.evaluate(() => document.fonts.ready);
    await previewer.screenshot({
      path: path.join(output, prefix + ".png"),
      animations: "disabled",
      timeout: 10_000,
    });
    states.push({
      ...facts,
      png: prefix + ".png",
      sha256: createHash("sha256")
        .update(await readFile(path.join(output, prefix + ".png")))
        .digest("hex"),
      captureBoundary: "facts then DOM/AX then PNG; not atomic",
    });
  };
  const assertDefaults = async () => {
    await expect.poll(() => editor.inputValue()).toBe("");
    await expect.poll(() => quantity.inputValue()).toBe("2");
    await expect.poll(() => code.inputValue()).toBe("12");
    expect(await level.getAttribute("aria-valuenow")).toBe("25");
    await expect.poll(() => email.getAttribute("aria-checked")).toBe("true");
    await expect.poll(() => sms.getAttribute("aria-checked")).toBe("false");
  };
  const assertInvalid = async () => {
    const prior = await status.textContent();
    await submit.click();
    await expect.poll(() => editor.getAttribute("aria-invalid")).toBe("true");
    await expect.poll(() => hasFocus(editor)).toBe(true);
    const id = await editor.getAttribute("aria-errormessage");
    expect(id).toBeTruthy();
    const error = form.locator(`[id=${JSON.stringify(id)}]`);
    expect(await error.isVisible()).toBe(true);
    expect(await error.textContent()).toMatch(/required/i);
    expect(await editor.getAttribute("aria-labelledby")).toBe(
      await label.getAttribute("id"),
    );
    expect(await status.textContent()).toBe(prior);
    return error;
  };
  const assertSubmitted = async (expected: unknown) => {
    await submit.click();
    await expect
      .poll(() => editor.getAttribute("aria-invalid"))
      .not.toBe("true");
    await expect
      .poll(() => editor.getAttribute("aria-errormessage"))
      .toBe(null);
    await expect
      .poll(async () => JSON.parse((await status.textContent())!))
      .toEqual(expected);
    submissions.push({
      at: new Date().toISOString(),
      statusText: await status.textContent(),
      expected,
      observed: JSON.parse((await status.textContent())!),
      observation:
        "Original app-authored onSubmit status, no callback override; no submissionId claim",
    });
  };
  try {
    phase = "navigate";
    await page.clock.setFixedTime("2026-10-10T12:00:00Z");
    const response = await page.goto(
      `${baseUrl}/en/ui-libraries/${family}/form/`,
      { waitUntil: "networkidle" },
    );
    expect(response?.status()).toBe(200);
    await previewer.waitFor({ state: "visible" });
    phase = "select-react";
    await selectRealRuntime(
      page,
      previewer,
      "react",
      '[data-demo-ref="form"]',
      1,
    );
    await assertDefaults();
    const rest = { editor: await paint(editor), label: await paint(label) };
    await capture("rest", rest);
    phase = "invalid-submit";
    const error = await assertInvalid();
    expect(await status.textContent()).not.toContain('"displayName"');
    const invalid = {
      field: await paint(field),
      label: await paint(label),
      editor: await paint(editor),
      error: await paint(error),
    };
    await capture("invalid-submit-first-focus", {
      ...invalid,
      originalColorPredicates: {
        labelEqualsField: invalid.label.color === invalid.field.color,
        labelEqualsError: invalid.label.color === invalid.error.color,
        labelChanged: invalid.label.color !== rest.label.color,
        editorUnchanged: invalid.editor.color === rest.editor.color,
      },
      boundary:
        "Original visual assertions preserved in archived official source; separate behavior evidence, not a paint pass",
    });
    phase = "corrected-submit";
    await editor.fill("Form behavior one");
    await assertSubmitted(values("Form behavior one"));
    await capture("corrected-submit", {
      restoredLabelColor: (await paint(label)).color,
      originalRestLabelColor: rest.label.color,
    });
    phase = "reset";
    await reset.click();
    await assertDefaults();
    expect(await editor.getAttribute("aria-invalid")).not.toBe("true");
    expect(await editor.getAttribute("aria-errormessage")).toBe(null);
    await capture("reset");
    phase = "invalid-after-reset";
    await assertInvalid();
    phase = "edit-composite-values";
    await editor.fill("Form behavior two");
    await form.getByRole("button", { name: "+", exact: true }).click();
    await expect.poll(() => quantity.inputValue()).toBe("3");
    await code.fill("1234");
    expect(await code.inputValue()).toBe("1234");
    await sms.click();
    await expect.poll(() => sms.getAttribute("aria-checked")).toBe("true");
    const rows = { email: await paint(email), sms: await paint(sms) };
    for (const row of Object.values(rows))
      expect(row.border).toEqual(["0px", "0px", "0px", "0px"]);
    await capture("edited", rows);
    phase = "composite-submit";
    await assertSubmitted(
      values("Form behavior two", 3, "1234", ["email", "sms"]),
    );
    await capture("composite-submit");
    phase = "reset-composite-and-fresh-submit";
    await reset.click();
    await assertDefaults();
    expect(await editor.getAttribute("aria-invalid")).not.toBe("true");
    expect(await editor.getAttribute("aria-errormessage")).toBe(null);
    await editor.fill("After reset");
    await assertSubmitted(values("After reset"));
    await capture("after-reset-submit");
    expect(errors).toEqual([]);
  } catch (error) {
    failed = true;
    failure = error;
    await capture("failed", { error: String(error) }).catch((captureError) =>
      states.push({ phase, captureError: String(captureError) }),
    );
    throw error;
  } finally {
    const inputs = await page
      .evaluate(() => (window as any).__formBuiltNativeEvents)
      .catch((error) => ({ error: String(error) }));
    await json(family + "-receipt.json", {
      binding,
      family,
      phase,
      result: failure ? "failed" : "passed",
      failure:
        failure instanceof Error
          ? { message: failure.message, stack: failure.stack }
          : failure,
      states,
      submissions,
      inputs,
      errors,
      consoleErrors,
      failedRequests,
      runtime: "react",
      browser: browser.version(),
      node: process.version,
      limits: [
        "Separate behavior evidence, not original official suite or color acceptance",
        "No callback override/IDs; five-field status only",
        "Original app/backend built bytes retained",
        "No async/retirement/AT/other-adapter acceptance",
      ],
    });
    await context.close();
  }
}
beforeAll(async () => {
  await mkdir(output, { recursive: true });
  browser = await chromium.launch({
    executablePath:
      "<CHROMIUM_APP>/Contents/MacOS/Google Chrome",
    headless: true,
    chromiumSandbox: true,
    args: [
      "--disable-dev-shm-usage",
      "--host-resolver-rules=MAP *.preview.localhost 127.0.0.1",
    ],
  });
  await json("environment.json", {
    node: process.version,
    platform: process.platform,
    arch: process.arch,
    chrome: browser.version(),
    baseUrl,
    head: binding.head,
    tree: binding.tree,
    pid: process.pid,
    observer:
      "Passive native input event sidecar only; no app callback override",
  });
}, 180_000);
afterAll(async () => {
  await json("requested-built-paths.json", [...requestPaths].sort());
  await browser?.close();
}, 30_000);
describe("Private4aad built-artifact Form behavior, separate from visual acceptance", () => {
  for (const family of ["shadcn", "brutalist"])
    it(family + " React complete behavior", () => journey(family), 120_000);
});
