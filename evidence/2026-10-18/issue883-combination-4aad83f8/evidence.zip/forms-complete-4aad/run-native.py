from pathlib import Path
import subprocess, json, hashlib, datetime, fcntl, os, socket, select, zipfile
R = Path(__file__).parent
W = Path('<SOURCE_ROOT>')
P = R.parent / 'preview-latest' / 'publisher'
HEAD = '4aad83f80ab29e0a5d4f3c0b63af17e3dcf64e06'
RUN = 39056666060
GEN = 'p921-r39056666060-a1'
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda b: hashlib.sha256(b).hexdigest()
def save(name, data):
    path = R / name
    if path.exists(): raise RuntimeError('Refuse evidence overwrite: ' + str(path))
    path.write_text(json.dumps(data, indent=2) + '\n')
def git(*args): return subprocess.check_output(['git', *args], cwd=W, text=True).strip()
def api(path): return json.loads(subprocess.check_output(['gh', 'api', path], text=True))
def source():
    assert git('rev-parse', 'HEAD') == HEAD
    assert not git('status', '--porcelain')
    entries = []
    raw = subprocess.check_output(['git', 'ls-tree', '-rz', '--full-tree', HEAD], cwd=W)
    for entry in raw.split(b'\0'):
        if not entry: continue
        meta, name = entry.split(b'\t', 1)
        mode, kind, blob = meta.decode().split()
        path = name.decode(); target = W / path
        data = os.readlink(target).encode() if target.is_symlink() else target.read_bytes()
        entries.append({'path': path, 'mode': mode, 'kind': kind, 'blob': blob, 'sha256': sha(data)})
    return {'at': now(), 'head': HEAD, 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain'), 'entries': entries}
def site_files():
    return [{'path': str(p.relative_to(P / 'sites' / GEN)), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted((P / 'sites' / GEN).rglob('*')) if p.is_file()]
env = os.environ.copy()
env['PATH'] = '<HOME>/.codex/task-state/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:' + env['PATH']
for key in ['GITHUB_ACTIONS','CANDIDATE_SHA','PUI_FINF_FEATURE_GROUP','PUI_FINF_FEATURE_EVIDENCE_DIR','PUI_BROWSER_EXTERNAL_SERVER_URL','PUI_BROWSER_TRACE']:
    env.pop(key, None)
receipt = {'start': now(), 'head': HEAD, 'run': RUN, 'artifact': 12109493824, 'generation': GEN, 'scope': 'Separate private built-artifact two-React-family Form behavior; no original official color acceptance', 'sourceDirty': False, 'steps': []}
server = None
server_log = None
try:
    save('source-before.json', source())
    save('launcher-environment.json', {'at': now(), 'node': subprocess.check_output(['node','--version'],env=env,text=True).strip(), 'pnpm': subprocess.check_output(['corepack','pnpm@10.32.1','--version'],cwd=W,env=env,text=True).strip(), 'platform': os.uname().sysname, 'arch': os.uname().machine, 'PATH': env['PATH'], 'wrapperPID': os.getpid(), 'driverFiles': [{'path': str(R / n), 'sha256': sha((R / n).read_bytes())} for n in ['run-native.py','local.browser.test.ts','local.config.ts']]})
    pr, run = api('repos/Proto-UI/Proto-UI/pulls/921'), api('repos/Proto-UI/Proto-UI/actions/runs/' + str(RUN))
    assert pr['head']['sha'] == run['head_sha'] == HEAD
    assert pr['state'] == 'open' and run['status'] == 'completed' and run['conclusion'] == 'success'
    save('publisher-live-read.json', {'at': now(), 'pr': pr, 'run': run})
    save('publisher-config.json', {'root': str(P), 'ghPath': '/opt/homebrew/bin/gh'})
    args = ['node','scripts/preview/publish.mjs',str(R / 'publisher-config.json'),'--locked']
    start = now()
    with (P / '.publish.lock').open('a+') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        with (R / 'publisher-refresh.log').open('x') as log:
            result = subprocess.run(args,cwd=W,env=env,pass_fds=(lock.fileno(),),stdout=log,stderr=subprocess.STDOUT,timeout=120)
    current = json.loads((P / 'current.json').read_text())
    save('publisher-refresh-receipt.json', {'start':start,'end':now(),'exit':result.returncode,'argv':args,'serialization':'Realfcntl.flockheldonexistingpublisherroot/.publish.lock forchildlifetime; inheritedfd','current':current})
    assert result.returncode == 0
    entry = next(x for x in current['previews'] if x['pr'] == '921')
    assert entry['head_sha'] == HEAD and entry['status'] == 'ready' and entry['generation'] == GEN
    assert int(entry['binding']['run_id']) == RUN and int(entry['binding']['artifact_id']) == 12109493824
    save('admitted-binding.json',entry)
    before_files = site_files()
    archive = R.parent / 'preview-latest' / 'actual-artifact.zip'
    with zipfile.ZipFile(archive) as z:
        members = {i.filename: {'path': i.filename, 'bytes': i.file_size, 'sha256': sha(z.read(i))} for i in z.infolist() if not i.is_dir()}
    assert {x['path']:x for x in before_files} == members
    save('built-files-before.json', {'head':HEAD,'run':RUN,'artifact':12109493824,'archiveSha256':sha(archive.read_bytes()),'fileCount':len(before_files),'expandedBytes':sum(x['bytes'] for x in before_files),'allMembersExact':True,'files':before_files})
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0)); port = sock.getsockname()[1]
    save('server-config.json', {'root':str(P),'domain':'preview.localhost','port':port,'bind':'127.0.0.1'})
    serve = "import {readFile} from 'node:fs/promises';import {createPreviewServer} from " + json.dumps(str(W / 'scripts/preview/serve.mjs')) + ";const config=JSON.parse(await readFile(new URL('./server-config.json',import.meta.url),'utf8'));const server=createPreviewServer(config);server.listen(config.port,config.bind,()=>console.log(JSON.stringify({listening:server.address()})));process.on('SIGTERM',()=>server.close(()=>process.exit(0)));\n"
    (R / 'serve-current.mjs').write_text(serve)
    server_log = (R / 'server.log').open('x')
    server = subprocess.Popen(['node',str(R / 'serve-current.mjs')],cwd=W,env=env,stdout=subprocess.PIPE,stderr=server_log,text=True)
    ready,_,_ = select.select([server.stdout],[],[],20)
    if not ready: raise RuntimeError('Previewserverdidnotannounceboundport')
    line = server.stdout.readline(); server_log.write(line); server_log.flush(); assert json.loads(line)['listening']['port'] == port
    receipt['serverPID'] = server.pid; receipt['port'] = port
    env['PUI_FORM_BUILT_OUTPUT'] = str(R)
    env['PUI_FORM_BUILT_URL'] = f'http://{GEN}.preview.localhost:{port}'
    argv = ['corepack','pnpm@10.32.1','exec','vitest','run','--config',str(R/'local.config.ts'),'--no-file-parallelism']
    receipt['command'] = argv; receipt['nativeStart'] = now()
    with (R / 'native.log').open('x') as log:
        child = subprocess.Popen(argv,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT)
        receipt['runnerPID'] = child.pid
        save('running-handle.json', {'at':now(),'wrapperPID':os.getpid(),'serverPID':server.pid,'runnerPID':child.pid,'argv':argv,'head':HEAD,'port':port})
        print(json.dumps({'started':True,'runnerPID':child.pid,'serverPID':server.pid,'port':port,'head':HEAD}),flush=True)
        try: receipt['exit'] = child.wait(timeout=270)
        except subprocess.TimeoutExpired:
            child.terminate(); receipt['outerDeadlineExceeded'] = True
            try: child.wait(timeout=10)
            except subprocess.TimeoutExpired: child.kill();child.wait()
            receipt['exit'] = child.returncode
    receipt['nativeEnd'] = now()
    after_files = site_files()
    save('built-files-after.json', {'files':after_files,'sameAsBefore':after_files==before_files})
    assert after_files == before_files
    save('source-after.json',source())
    before_source = json.loads((R / 'source-before.json').read_text())
    after_source = json.loads((R / 'source-after.json').read_text())
    receipt['trackedInputsUnchanged'] = before_source['entries'] == after_source['entries']
    assert receipt['trackedInputsUnchanged']
    req = R / 'requested-built-paths.json'
    if req.exists():
        rows=[]
        for pathname in json.loads(req.read_text()):
            member=pathname.lstrip('/')
            if member.endswith('/'):member+='index.html'
            if member in members: rows.append({'requestPath':pathname,**members[member]})
            else: rows.append({'requestPath':pathname,'member':None})
        save('requested-built-input-binding.json',{'head':HEAD,'artifact':12109493824,'rows':rows,'boundary':'Servedbuiltmembers,notindividualTSsourceexecutionclaim'})
except BaseException as error:
    receipt['error'] = {'type':type(error).__name__,'message':str(error)}
    receipt.setdefault('exit',1)
    raise
finally:
    if server:
        server.terminate()
        try:server.wait(timeout=20)
        except subprocess.TimeoutExpired:server.kill();server.wait();receipt['serverForcedKill']=True
        receipt['serverExit']=server.returncode
    if server_log:server_log.close()
    receipt['end']=now()
    save('native-receipt.json',receipt)
    print(json.dumps({'ended':True,'exit':receipt.get('exit'),'serverExit':receipt.get('serverExit'),'end':receipt['end']}),flush=True)
