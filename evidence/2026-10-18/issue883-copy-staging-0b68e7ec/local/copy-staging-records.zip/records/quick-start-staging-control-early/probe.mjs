import {createRequire} from 'node:module';
import {writeFile} from 'node:fs/promises';
const require=createRequire('<SOURCE_ROOT>/apps/www/package.json');
const {chromium}=require('playwright-core');
const out=new URL('./',import.meta.url).pathname;
const result={startedAt:new Date().toISOString(),sourceHead:'cc3e5670a3a83d4f797fa2af7d942aae876b0f2b',artifact:12121993854,scope:'One wc390dark live diagnostic A/B/A, no test modification or pass claim',rows:[]};
const browser=await chromium.launch({executablePath:'<CHROMIUM_APP>/Contents/MacOS/Google Chrome',headless:true,args:['--no-sandbox']});
try { const page=await browser.newPage({viewport:{width:390,height:1000},colorScheme:'dark'});await page.addInitScript(()=>{
 const read=label=>({label,at:performance.now(),clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,staging:[...document.querySelectorAll('.site-copy-mount > [data-projection-generation-state="staging"]')].map(e=>({box:e.getBoundingClientRect().toJSON(),child:e.querySelector('.site-copy-command')?.getBoundingClientRect().toJSON(),overflow:getComputedStyle(e).overflow}))});
 const watch=new MutationObserver(()=>{
  if(window.__stageControl || document.documentElement.scrollWidth-document.documentElement.clientWidth<=1)return;
  const elements=[...document.querySelectorAll('.site-copy-mount > [data-projection-generation-state="staging"]')];if(!elements.length)return;
  const rows=[read('A-original')];const old=elements.map(e=>({value:e.style.getPropertyValue('overflow'),priority:e.style.getPropertyPriority('overflow')}));
  for(const e of elements)e.style.overflow='clip';rows.push(read('B-only-copy-staging-overflow-clip'));
  elements.forEach((e,i)=>{if(old[i].value)e.style.setProperty('overflow',old[i].value,old[i].priority);else e.style.removeProperty('overflow')});rows.push(read('A-restored'));window.__stageControl={rows,intervened:elements.length};watch.disconnect();
 });watch.observe(document,{subtree:true,childList:true,attributes:true});
});await page.goto('http://127.0.0.1:57824/zh-cn/start-here/quick-start/#_top',{waitUntil:'domcontentloaded'});await page.waitForFunction(()=>window.__stageControl,null,{timeout:10000});result.control=await page.evaluate(()=>window.__stageControl);result.rows=result.control.rows;
result.exit=0;
} catch(e){result.exit=1;result.error=String(e)} finally {await browser.close();result.browserClosed=true;result.endedAt=new Date().toISOString();await writeFile(out+'observations.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result.rows))}process.exitCode=result.exit;
