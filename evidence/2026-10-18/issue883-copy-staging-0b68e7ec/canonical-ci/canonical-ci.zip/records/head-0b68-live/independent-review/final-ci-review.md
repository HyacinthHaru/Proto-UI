# 0b68 final CI review

CI **39092692003** is **completed / failure**, with **22 terminal jobs: 13 success and 9 failure**. The final paged snapshot completed at **03:37:13 UTC**, with main remaining `042f1e57…`, PR head remaining `0b68e7ec…`, no reviews, no inline comments or review threads, and no collection errors. An empty review list is not approval.

All eight ordinary logs select actual checkout `e1da47770df00be90e2350b4ef34513c83899549`. Its saved Git API tree equals exact 0b68 tree `ef466bb2f3fe4f253f7fd8aeae1f7958b86a443e`.

| Ordinary shard | Passed | Failed | Skipped | Terminal evidence |
| --- | ---: | ---: | ---: | --- |
| 1/8 | 219 | 21 | 0 | Complete 240-test report, exit 1 |
| 2/8 | — | — | — | Original 900-second deadline, exit 124; no final summary |
| 3/8 | 58 | 3 | 0 | Complete report |
| 4/8 | 122 | 2 | 0 | Complete report |
| 5/8 | 88 | 2 | 15 | Complete report |
| 6/8 | 169 | 0 | 0 | Complete report |
| 7/8 | 113 | 1 | 0 | Complete report |
| 8/8 | — | — | — | Original 900-second deadline, exit 124; no final summary |

The **six complete reports total 769 passed / 29 failed / 15 skipped (813 tests)**. Shard 1 completed this time; it must not inherit cc3’s timeout status. Only shards 2 and 8 are incomplete. There is **no all-eight test total**. The earlier 550/8/15 subtotal remains an accurate five-report checkpoint and is not the final completed-report sum.

Current original cases explicitly pass: **QuickStart 20** in ordinary shard 8, the **settings case** in shard 1, **Tooltip 2**, **Field 25**, **color 9**, **Collapsible 36**, and **Scroll Corner 2**. Dedicated QuickStart separately passes the original 20 and four fragment controls; dedicated Collapsible passes 36. These separate executions are not added to the ordinary subtotal. The Homepage file still has two other failed cases.

Types finish **934 files / 0 errors / 0 warnings / 14 hints**. Package execution is **42 actual builds out of the 47 public-package inventory**, followed by **47 manifest checks**, nine passing policy tests, and nine measurement rows: **4 PASS / 5 ADVISORY**. All nine normalized measurements, including gzip, minified bytes and hashes, equal cc3. General stops before Vitest at the same 78 ordered public-docs diagnostics. Neither manifest count nor 62 installed workspace projects is the build count, and advisory is not strict green.

Current residuals remain concrete:

- **Shadow closeout:** the full original diff now shows mounted/body and removed facts matching, but the restored node is neither parented to nor queryable from its origin. Its mechanism remains unresolved.
- **Brutalist Dialog:** the original direct-body reader finds no mask/content pair. The log does not prove that no such surface exists elsewhere or establish a lifecycle cause.
- **S1/S2:** original case, hover and click deadlines remain red; later lifecycle assertions may not execute. Some names become visible because this run progressed farther.
- **Brutalist React Header:** two cases lack the original `ring-2` token after focus. Failure-time logical state and owner timing were not captured.
- **Shadcn Card:** four cases differ at expected `rgb(93, 100, 107)` versus `lab(48.496 0 0)`. This is not assumed to be equivalent-color serialization.
- **Drawer:** incomplete shard 2 retains an original shadow sample of 28.13 against `<15`, without enough phase/owner evidence to assign a cause here.

S4/S5 initialization, S4 paint click and the prior family recipe/oracle residuals remain. The new Scroll Corner pass does not assign a cause to its earlier 158px red or demonstrate that Copy CSS repaired Scroll. Newly visible failure names do not, by themselves, prove new source defects. This review establishes no additional production regression attributable to the three-line Copy CSS and manufactures no patch.

The Copy repair now has exact-head official QuickStart evidence in both ordinary and dedicated execution, including the eight former narrow-overflow cases. Its historical cc3 failures and all failed controls are preserved. All CI jobs are terminal, but two ordinary test workloads are incomplete and the overall run failed. The conclusion remains **partial / ABSTAIN**, not full CI green, full C acceptance or GitHub approval.

Only existing raw logs and metadata were read. No tests, browser, download, Actions mutation, source edit or publication occurred. The two prior incremental reports remain unchanged.
