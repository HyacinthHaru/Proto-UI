# Select keyboard owner 候选交叉只读审查

冻结production26013177…与test469976b9…未发现具体finding（0），保持human-assisted、unassessed、partial/ABSTAIN；不是GitHubAPPROVE，也没有运行额外测试。

候选在实际press.commit消费者接受keydown时、调用protocolbus之前保存私有nativeEvent owner。消费后同keydown不能再次press；foreignowner的root key.down在activeElementfallback之前被拒绝。无press消费者不写owner，未被认领的真实Portalactivefallback仍可工作。新keydown对象未带mark，正常新输入仍可打开。`onGlobal`投递、click/keyup/physicalroot原Set、后随zero-detailclick抑制及listener注册实现未改。

C-EVENT-0003-E的root归属与C-EVENT-0005的独立registration分开处理：标记在busdispatch之前，不在各callback内部，因此没有新增registration去重。原host:*／Proto并存、once/signal/capture/removal、Portal重绑等12项正文逐字保留。新Symbol不进入投射payload的读取面，不新增PrototypeAPI或全局重入锁。

来源明确分四阶段：初版press-only红14/1保留；正式v2同test `b0b192fcabf83ead5711102feaf6b409759dec77342d8d190af0862a84c452bf` 实际baseline14/1（新Trigger keys1/presses1）→candidate15/15。之后Prettier仅重排两处新增cleanup.push，最终test `469976b9…` 单独执行15/15。没有把不同test字节说成原样同一run。

新增3case分别覆盖旧owner退休回焦同keydown、无消费者不抢占、未认领Portal正常回退；主case还断言globalkey照常及后续新Trigger键可用。以上为HappyDOM syntheticKeyboardEvent，不替代原生。原native时间线属于4aad旧完整artifact：一个原settingscase在Vue迭代失败，值已commit、关闭、回焦后无第二keydown却重开；WC/React仅走到后续迭代，不能报为两个独立passingtests；Vue2/Brutalist未到达。当前candidate的真实Homepage/组合结果仍由root另行执行。

[完整source/test/run hashes与边界](./report.json) · [冻结diff](./reviewed.patch)。不宣称所有键盘/复用Event对象/AT/fullCI或Issue关闭。
