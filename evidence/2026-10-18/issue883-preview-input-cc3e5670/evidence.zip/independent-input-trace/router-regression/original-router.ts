// packages/adapters/base/src/events/web-event-router.ts
import { createWebPointerContactWriter, type WebPointerContact } from './pointer-contact';
import {
  observeDirectionalPointerDown,
  observeDirectionalPointerUp,
  suppressDirectionalClick,
} from '../gestures/web-move-click-arbitration';

type Unsub = () => void;
const PRESS_COMMIT_EMITTED_ROOTS = Symbol.for('@proto.ui/router/press-commit-emitted-roots');
const PROTO_PARENT_INSTANCE_MARK = Symbol.for('@proto.ui/adapter-base/__proto_parent_instance');
const PROTO_INSTANCE_MARKS = [
  Symbol.for('@proto.ui/adapter-web-component/__proto_instance'),
  Symbol.for('@proto.ui/adapter-react/__proto_instance'),
  Symbol.for('@proto.ui/adapter-vue/__proto_instance'),
] as const;
const TRIGGER_OWNER_MARK = Symbol.for('@proto.ui/as-trigger/confirm-owner');
const REJECTED_TRIGGER_ROUTE = Symbol('rejected-trigger-route');
const GLOBAL_ROOT_EVENT_TYPES: Record<string, string> = {
  pointerdown: 'pointer.down',
  pointermove: 'pointer.move',
  pointerup: 'pointer.up',
  pointercancel: 'pointer.cancel',
  click: 'press.commit',
  contextmenu: 'context.menu',
};

type ElementWithSymbols = HTMLElement & Record<symbol, unknown>;
const isDomNode = (value: unknown): value is Node =>
  !!value && typeof (value as Node).nodeType === 'number';
const isHtmlElement = (value: unknown): value is HTMLElement =>
  isDomNode(value) &&
  value.nodeType === 1 &&
  (value as Element).namespaceURI === 'http://www.w3.org/1999/xhtml';
const isShadowRoot = (value: unknown): value is ShadowRoot =>
  isDomNode(value) && value.nodeType === 11 && 'host' in value;

export type SemanticEventRouteResolution = {
  matched: true;
  accepted: boolean;
  surface: object;
};

type Listener = {
  type: string;
  target?: EventTarget;
  cb: any;
  options?: any;
  wrapped?: any;
};

const payloadStateByNativeEvent = new WeakMap<object, Record<PropertyKey, unknown>>();
const activeRouterByRoot = new WeakMap<HTMLElement, object>();

export function createWebProtoEventRouter(opt: {
  rootEl: HTMLElement;
  /** Physical native editor ingress for focus/blur only; no event redispatch. */
  focusEventTarget?: EventTarget;
  instanceToken?: object;
  /** Official tree's conservative reachability filter; never grants delivery. */
  isSemanticEventRouteCandidate?: (root: HTMLElement, targets: EventTarget[]) => boolean;
  resolveSemanticEventRoute?: (
    target: EventTarget | null,
    /** Query-local visited ancestors; never retained across routing decisions. */
    visited?: Set<Node>
  ) => SemanticEventRouteResolution | null;
  /** @deprecated Use resolveSemanticEventRoute so non-surface hits can be rejected. */
  resolveEventRouteOwner?: (target: EventTarget | null) => object | null;
  globalEl?: EventTarget; // window by default
  isEnabled: () => boolean; // bridge to eventGate
}) {
  // proto semantic bus: press.*, pointer.*, key.*, context.menu...
  const protoRootBus = new EventTarget();
  const protoGlobalBus = new EventTarget();
  const physicalRootDeliveries = new WeakSet<Event>();

  const rootEl = opt.rootEl;
  const globalEl = opt.globalEl ?? window;
  const routerIdentity = {};
  activeRouterByRoot.set(rootEl, routerIdentity);
  const isEnabled = () => activeRouterByRoot.get(rootEl) === routerIdentity && opt.isEnabled();
  const contactWriter = createWebPointerContactWriter(rootEl);
  let suppressFollowupDirectClick = false;
  let contact: {
    pointerId: number;
    rect: DOMRect;
    startX: number;
    startY: number;
    value: WebPointerContact;
  } | null = null;
  const sampled = new WeakSet<Event>();
  function endContact(reason: WebPointerContact['reason']) {
    if (!contact) return;
    const value = { ...contact.value, active: false, reason };
    contact = null;
    contactWriter.publish(value);
  }
  function sampleContact(native: PointerEvent) {
    if (sampled.has(native)) return;
    sampled.add(native);
    const pointerId = Number.isFinite(native.pointerId) ? native.pointerId : 0;
    if (native.type === 'pointerdown') {
      if ((typeof native.button === 'number' && native.button !== 0) || native.isPrimary === false)
        return;
      endContact('replaced');
      const rect = rootEl.getBoundingClientRect();
      if (
        ![rect.x, rect.y, rect.width, rect.height, native.clientX, native.clientY].every(
          Number.isFinite
        ) ||
        rect.width <= 0 ||
        rect.height <= 0
      )
        return;
      contact = {
        pointerId,
        rect,
        startX: native.clientX,
        startY: native.clientY,
        value: {
          active: true,
          session: contactWriter.nextSession(),
          x: 0.5,
          y: 0.5,
          deltaX: 0,
          deltaY: 0,
          reason: 'down',
        },
      };
    }
    if (!contact || contact.pointerId !== pointerId) return;
    if (native.type === 'pointercancel') {
      endContact('cancel');
      return;
    }
    const { rect, startX, startY } = contact;
    if (Number.isFinite(native.clientX) && Number.isFinite(native.clientY)) {
      const clamp = (value: number, min: number, max: number) =>
        Math.max(min, Math.min(max, value));
      contact.value = {
        ...contact.value,
        x: clamp((native.clientX - rect.x) / rect.width, 0, 1),
        y: clamp((native.clientY - rect.y) / rect.height, 0, 1),
        deltaX: clamp((native.clientX - startX) / rect.width, -1, 1),
        deltaY: clamp((native.clientY - startY) / rect.height, -1, 1),
        reason: native.type === 'pointerdown' ? 'down' : 'move',
      };
    }
    if (native.type === 'pointerup') {
      endContact('up');
      return;
    }
    contactWriter.publish(contact.value);
  }

  // --- helper: emit proto event to proto bus ---
  function emit(target: EventTarget, type: string, native: any) {
    if (
      target === protoRootBus &&
      ['pointer.down', 'pointer.move', 'pointer.up', 'pointer.cancel'].includes(type)
    )
      sampleContact(native);
    const ev = new CustomEvent(type, { detail: createProtoEventPayload(type, native) });
    target.dispatchEvent(ev);
  }

  function emitFromPhysicalRoot(type: string, native: Event) {
    if (GLOBAL_ROOT_EVENT_TYPES[native.type] === type) physicalRootDeliveries.add(native);
    emit(protoRootBus, type, native);
  }

  function emitPressCommitOnce(native: Event) {
    if (hasPressCommitBeenEmittedForRoot(native)) return;
    markPressCommitEmittedForRoot(native);
    suppressFollowupDirectClick = true;
    emit(protoRootBus, 'press.commit', native);
  }

  function isCommitKey(key: string) {
    return key === 'Enter' || key === ' ';
  }

  function isNativeMouseClick(event: Event): event is MouseEvent {
    const candidate = event as MouseEvent;
    return (
      event.type === 'click' &&
      typeof candidate.detail === 'number' &&
      typeof candidate.clientX === 'number' &&
      typeof candidate.clientY === 'number' &&
      typeof candidate.button === 'number'
    );
  }

  function isWithinRoot(target: EventTarget | null) {
    return target === rootEl || (isDomNode(target) && rootEl.contains(target));
  }

  function getLinkedProtoParent(target: EventTarget | null): HTMLElement | null {
    if (!isHtmlElement(target)) return null;
    const linkedParent = (target as ElementWithSymbols)[PROTO_PARENT_INSTANCE_MARK];
    return isHtmlElement(linkedParent) ? linkedParent : null;
  }

  function isProtoInstanceNode(target: EventTarget | null): target is HTMLElement {
    if (!isHtmlElement(target)) return false;
    return PROTO_INSTANCE_MARKS.some((mark) => (target as ElementWithSymbols)[mark] === true);
  }

  function getTriggerRouteOwner(target: EventTarget | null): object | HTMLElement | null {
    if (!isHtmlElement(target)) return null;
    const owner = (target as ElementWithSymbols)[TRIGGER_OWNER_MARK];
    if (owner === true) return target;
    return owner && (typeof owner === 'object' || typeof owner === 'function')
      ? (owner as object)
      : null;
  }

  function getNearestProtoInstance(
    target: EventTarget | null,
    visited = new Set<Node>()
  ): HTMLElement | null {
    let cur: Node | null = isDomNode(target) ? target : null;
    while (cur) {
      if (visited.has(cur)) return null;
      visited.add(cur);

      if (isShadowRoot(cur)) {
        cur = cur.host;
        continue;
      }

      if (isProtoInstanceNode(cur)) return cur;

      const linkedParent = getLinkedProtoParent(cur);
      if (linkedParent && linkedParent !== cur) {
        cur = linkedParent;
        continue;
      }

      cur = cur.parentNode;
    }
    return null;
  }

  function getNearestTriggerOwner(
    target: EventTarget | null,
    visited = new Set<Node>()
  ): object | HTMLElement | null {
    let cur: Node | null = isDomNode(target) ? target : null;
    while (cur) {
      if (visited.has(cur)) return null;
      visited.add(cur);
      if (isShadowRoot(cur)) {
        cur = cur.host;
        continue;
      }
      const owner = getTriggerRouteOwner(cur);
      if (owner) return owner;
      cur = cur.parentNode;
    }
    return null;
  }

  function resolveOwningTrigger(
    native: Event,
    options?: { includeActiveFallback?: boolean }
  ): object | HTMLElement | null | typeof REJECTED_TRIGGER_ROUTE {
    if (opt.resolveSemanticEventRoute) {
      const visited = new Set<Node>();
      if (typeof native.composedPath === 'function') {
        for (const entry of native.composedPath()) {
          const resolution = opt.resolveSemanticEventRoute(entry, visited);
          if (!resolution) continue;
          return resolution.accepted ? resolution.surface : REJECTED_TRIGGER_ROUTE;
        }
      }
      const resolution = opt.resolveSemanticEventRoute(native.target, visited);
      if (resolution) {
        return resolution.accepted ? resolution.surface : REJECTED_TRIGGER_ROUTE;
      }
      if (options?.includeActiveFallback !== false) {
        const active = rootEl.ownerDocument.activeElement;
        const activeResolution = opt.resolveSemanticEventRoute(active, visited);
        if (activeResolution) {
          return activeResolution.accepted ? activeResolution.surface : REJECTED_TRIGGER_ROUTE;
        }
      }
    }
    if (opt.resolveEventRouteOwner) {
      if (typeof native.composedPath === 'function') {
        for (const entry of native.composedPath()) {
          const owner = opt.resolveEventRouteOwner(entry);
          if (owner) return owner;
        }
      }
      const targetOwner = opt.resolveEventRouteOwner(native.target);
      if (targetOwner) return targetOwner;
      if (options?.includeActiveFallback !== false) {
        const active = rootEl.ownerDocument.activeElement;
        const activeOwner = opt.resolveEventRouteOwner(active);
        if (activeOwner) return activeOwner;
      }
    }
    const visited = new Set<Node>();
    if (typeof native.composedPath === 'function') {
      for (const entry of native.composedPath()) {
        const owner = getNearestTriggerOwner(entry, visited);
        if (owner) return owner;
      }
    }
    const targetOwner = getNearestTriggerOwner(native.target, visited);
    if (targetOwner) return targetOwner;
    if (options?.includeActiveFallback === false) return null;
    const active = rootEl.ownerDocument.activeElement;
    return getNearestTriggerOwner(active, visited);
  }

  function resolveOwningProtoInstance(
    native: Event,
    options?: { includeActiveFallback?: boolean }
  ) {
    const visited = new Set<Node>();
    if (typeof native.composedPath === 'function') {
      for (const entry of native.composedPath()) {
        const owner = getNearestProtoInstance(entry, visited);
        if (owner) return owner;
      }
    }
    const targetOwner = getNearestProtoInstance(native.target, visited);
    if (targetOwner) return targetOwner;
    if (options?.includeActiveFallback === false) return null;
    const active = rootEl.ownerDocument.activeElement;
    return getNearestProtoInstance(active, visited);
  }

  function shouldRouteToCurrentRoot(native: Event, options?: { includeActiveFallback?: boolean }) {
    if (opt.isSemanticEventRouteCandidate) {
      const targets = typeof native.composedPath === 'function' ? native.composedPath() : [];
      if (native.target) targets.push(native.target);
      if (options?.includeActiveFallback !== false && rootEl.ownerDocument.activeElement)
        targets.push(rootEl.ownerDocument.activeElement);
      if (!opt.isSemanticEventRouteCandidate(rootEl, targets)) return false;
    }
    const triggerOwner = resolveOwningTrigger(native, options);
    if (triggerOwner === REJECTED_TRIGGER_ROUTE) return false;
    if (triggerOwner) return triggerOwner === (opt.instanceToken ?? rootEl);

    const owner = resolveOwningProtoInstance(native, options);
    if (owner) return owner === rootEl;
    return isWithinRoot(native.target);
  }

  function shouldRouteGlobalRootEvent(
    native: Event,
    options?: { includeActiveFallback?: boolean }
  ) {
    // Keep native listener order and Portal fallback semantics. An instance
    // without a consumer has no root delivery to resolve. pointerdown also
    // resets the keyboard follow-up click state for press consumers.
    const hasMappedListener = rootProxy.__hasProtoListeners(GLOBAL_ROOT_EVENT_TYPES[native.type]);
    const resetsPressCommit =
      native.type === 'pointerdown' && rootProxy.__hasProtoListeners('press.commit');
    // A once/aborted listener can disappear during the keyboard commit before
    // its native zero-detail follow-up click arrives. That click still owns
    // this root's pending suppression state, so route it before applying the
    // ordinary no-demand fast path. Unrelated routes cannot consume the flag.
    const consumesPendingPressCommit = native.type === 'click' && suppressFollowupDirectClick;
    if (!hasMappedListener && !resetsPressCommit && !consumesPendingPressCommit) return false;
    // A Shadow boundary retargets native.target for the global listener. Skip
    // only input already delivered by this physical root; a path-only check
    // would incorrectly consume a real global/slot fallback with no root ingress.
    if (
      physicalRootDeliveries.has(native) &&
      typeof native.composedPath === 'function' &&
      native.composedPath().includes(rootEl)
    ) {
      physicalRootDeliveries.delete(native);
      return false;
    }
    if (isWithinRoot(native.target)) return false;
    return shouldRouteToCurrentRoot(native, options);
  }

  type EventWithSymbols = Event & Record<symbol, Set<EventTarget> | undefined>;

  function getPressCommitEmittedRoots(native: Event): Set<EventTarget> {
    const seen = (native as EventWithSymbols)[PRESS_COMMIT_EMITTED_ROOTS];
    if (seen instanceof Set) return seen;
    const next = new Set<EventTarget>();
    (native as EventWithSymbols)[PRESS_COMMIT_EMITTED_ROOTS] = next;
    return next;
  }

  function hasPressCommitBeenEmittedForRoot(native: Event) {
    return getPressCommitEmittedRoots(native).has(rootEl);
  }

  function markPressCommitEmittedForRoot(native: Event) {
    getPressCommitEmittedRoots(native).add(rootEl);
  }

  function hasFocusedDescendant() {
    const active = rootEl.ownerDocument.activeElement;
    return isDomNode(active) && rootEl.contains(active);
  }

  function shouldSuppressFollowupClick(native: MouseEvent) {
    // Keyboard direct activation of a native descendant button often synthesizes
    // a follow-up click with detail===0. The semantic keyboard commit has already
    // been emitted on keydown, so suppress the zero-detail click once here.
    if (!suppressFollowupDirectClick) return false;
    if (native.detail !== 0) {
      suppressFollowupDirectClick = false;
      return false;
    }
    suppressFollowupDirectClick = false;
    return true;
  }

  // -------------------------
  // (A) 固定监听：解释“协议语义事件”
  // -------------------------
  // 这些是你愿意为每个组件实例支付的固定成本（尽量少）
  const unsubs: Unsub[] = [];

  // pointer -> pointer.*
  unsubs.push(
    listen(rootEl, 'pointerdown', (e) => {
      observeDirectionalPointerDown(rootEl, e);
      if (!isEnabled()) return;
      // C-EVENT-0003-E: the root path uses the same owner boundary as its
      // global/portal fallback. A descendant owner's input is not our input.
      if (!shouldRouteToCurrentRoot(e, { includeActiveFallback: false })) return;
      suppressFollowupDirectClick = false;
      emitFromPhysicalRoot('pointer.down', e);
    })
  );
  unsubs.push(
    listen(rootEl, 'pointermove', (e) => {
      if (!isEnabled()) return;
      emitFromPhysicalRoot('pointer.move', e);
    })
  );
  unsubs.push(
    listen(rootEl, 'pointerup', (e) => {
      observeDirectionalPointerUp(rootEl, e);
      if (!isEnabled()) return;
      emitFromPhysicalRoot('pointer.up', e);
    })
  );
  unsubs.push(
    listen(rootEl, 'pointercancel', (e) => {
      observeDirectionalPointerUp(rootEl, e);
      if (!isEnabled()) return;
      emitFromPhysicalRoot('pointer.cancel', e);
    })
  );
  unsubs.push(
    listen(rootEl, 'pointerenter', (e) => {
      if (!isEnabled()) return;
      emit(protoRootBus, 'pointer.enter', e);
    })
  );
  unsubs.push(
    listen(rootEl, 'pointerleave', (e) => {
      if (!isEnabled()) return;
      emit(protoRootBus, 'pointer.leave', e);
    })
  );

  unsubs.push(
    listen(rootEl, 'lostpointercapture', (e: PointerEvent) => {
      if (!isEnabled() || !shouldRouteToCurrentRoot(e, { includeActiveFallback: false })) return;
      // Normal pointerup already ended this contact. Its implicit capture
      // release must not cancel surviving hover or a later keyboard gesture.
      if (!contact || contact.pointerId !== e.pointerId) return;
      endContact('lostcapture');
      emit(protoRootBus, 'pointer.cancel', e);
    })
  );
  unsubs.push(
    listen(globalEl, 'blur', (e) => {
      endContact('blur');
      if (isEnabled()) emit(protoRootBus, 'press.cancel', e);
    })
  );

  // portal fallback: globally mounted nodes do not bubble pointer events to rootEl
  unsubs.push(
    listen(globalEl, 'pointerdown', (e) => {
      observeDirectionalPointerDown(rootEl, e);
      if (!isEnabled()) {
        endContact('cancel');
        return;
      }
      // A fresh primary gesture elsewhere retires the old visual session,
      // without routing that new gesture into this semantic owner.
      if (contact && !sampled.has(e) && e.button === 0 && e.isPrimary !== false)
        endContact('replaced');
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      suppressFollowupDirectClick = false;
      emit(protoRootBus, 'pointer.down', e);
    })
  );

  unsubs.push(
    listen(globalEl, 'pointermove', (e) => {
      if (!isEnabled()) {
        endContact('cancel');
        return;
      }
      if (contact) sampleContact(e);
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      emit(protoRootBus, 'pointer.move', e);
    })
  );

  unsubs.push(
    listen(globalEl, 'pointerup', (e) => {
      observeDirectionalPointerUp(rootEl, e);
      if (!isEnabled()) {
        endContact('cancel');
        return;
      }
      if (contact) sampleContact(e);
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      emit(protoRootBus, 'pointer.up', e);
    })
  );

  unsubs.push(
    listen(globalEl, 'pointercancel', (e) => {
      observeDirectionalPointerUp(rootEl, e);
      if (!isEnabled()) {
        endContact('cancel');
        return;
      }
      if (contact) sampleContact(e);
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      emit(protoRootBus, 'pointer.cancel', e);
    })
  );

  // key -> key.* (global)
  unsubs.push(
    listen(globalEl, 'keydown', (e: KeyboardEvent) => {
      if (!isEnabled()) return;
      emit(protoGlobalBus, 'key.down', e);
      if (rootProxy.__hasProtoListeners('key.down') && shouldRouteToCurrentRoot(e)) {
        emit(protoRootBus, 'key.down', e);
      }
      if (!isCommitKey(e.key)) {
        suppressFollowupDirectClick = false;
        return;
      }
      if (!rootProxy.__hasProtoListeners('press.commit')) return;
      if (shouldRouteToCurrentRoot(e)) {
        emitPressCommitOnce(e);
        return;
      }
      if (!isWithinRoot(e.target)) return;
      if (!hasFocusedDescendant()) return;
      emitPressCommitOnce(e);
    })
  );

  unsubs.push(
    listen(rootEl, 'keydown', (e: KeyboardEvent) => {
      if (!isEnabled()) return;
      if (!isCommitKey(e.key)) return;
      emitPressCommitOnce(e);
    })
  );

  unsubs.push(
    listen(globalEl, 'keyup', (e: KeyboardEvent) => {
      if (!isEnabled()) return;
      emit(protoGlobalBus, 'key.up', e);
      if (rootProxy.__hasProtoListeners('key.up') && shouldRouteToCurrentRoot(e)) {
        emit(protoRootBus, 'key.up', e);
      }
      if (isCommitKey(e.key)) queueMicrotask(() => (suppressFollowupDirectClick = false));
    })
  );

  // click -> press.commit (root)
  // 只响应真实的 MouseEvent；由 event.emit() 分发的 CustomEvent 不触发 press.commit，
  // 避免组件暴露的合成 click 事件（如 asButton）导致重复 toggle。
  unsubs.push(
    listen(rootEl, 'click', (e) => {
      if (!isEnabled()) return;
      if (!isNativeMouseClick(e)) return;
      if (!shouldRouteToCurrentRoot(e)) return;
      if (suppressDirectionalClick(rootEl, e) || shouldSuppressFollowupClick(e)) return;
      emitFromPhysicalRoot('press.commit', e);
    })
  );

  unsubs.push(
    listen(globalEl, 'click', (e) => {
      if (!isEnabled()) return;
      if (!isNativeMouseClick(e)) return;
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      if (suppressDirectionalClick(rootEl, e) || shouldSuppressFollowupClick(e)) return;
      emit(protoRootBus, 'press.commit', e);
    })
  );

  // contextmenu -> context.menu
  unsubs.push(
    listen(rootEl, 'contextmenu', (e) => {
      if (!isEnabled()) return;
      emitFromPhysicalRoot('context.menu', e);
    })
  );

  unsubs.push(
    listen(globalEl, 'contextmenu', (e) => {
      if (!isEnabled()) return;
      if (!shouldRouteGlobalRootEvent(e, { includeActiveFallback: false })) return;
      emit(protoRootBus, 'context.menu', e);
    })
  );

  // -------------------------
  // (B) 懒绑定：host:* host-bound events
  // -------------------------
  const rootProxy = createProxyTarget({
    protoBus: protoRootBus,
    // hostTarget：先工作假设= rootEl；未来可以换成更准确的 host 专用 target
    hostTarget: rootEl,
    focusEventTarget: opt.focusEventTarget,
    isEnabled,
    // 注：rootProxy 不做“解释”，只做“路由 + gating”
  });

  const globalProxy = createProxyTarget({
    protoBus: protoGlobalBus,
    hostTarget: globalEl,
    isEnabled,
  });

  return {
    /** Inject these into EVENT_*_TARGET_CAP */
    rootTarget: rootProxy as EventTarget,
    globalTarget: globalProxy as EventTarget,
    /** Adapter-private ingress for a trusted physical host target. */
    dispatchHostRootEvent(type: string, event: Event) {
      rootProxy.__dispatchHost(type, event);
    },

    dispose() {
      endContact('unmount');
      if (activeRouterByRoot.get(rootEl) === routerIdentity) activeRouterByRoot.delete(rootEl);
      for (const u of unsubs.splice(0)) u();
      rootProxy.__dispose?.();
      globalProxy.__dispose?.();
    },
  };
}

function listen(t: any, type: string, cb: (ev: any) => void): Unsub {
  t.addEventListener(type, cb as any);
  return () => t.removeEventListener(type, cb as any);
}

function createProtoEventPayload(type: string, native: any) {
  const target: Record<PropertyKey, unknown> = {
    type,
    nativeEvent: native,
    target: native?.target,
    key: typeof native?.key === 'string' ? native.key : undefined,
    repeat: typeof native?.repeat === 'boolean' ? native.repeat : undefined,
    shiftKey: typeof native?.shiftKey === 'boolean' ? native.shiftKey : undefined,
    altKey: typeof native?.altKey === 'boolean' ? native.altKey : undefined,
    ctrlKey: typeof native?.ctrlKey === 'boolean' ? native.ctrlKey : undefined,
    metaKey: typeof native?.metaKey === 'boolean' ? native.metaKey : undefined,
    requestDefaultPrevented:
      typeof native?.preventDefault === 'function' ? () => native.preventDefault() : undefined,
    preventDefault:
      typeof native?.preventDefault === 'function' ? () => native.preventDefault() : undefined,
    stopPropagation:
      typeof native?.stopPropagation === 'function' ? () => native.stopPropagation() : undefined,
  };

  if (!native || (typeof native !== 'object' && typeof native !== 'function')) return target;

  let sharedState = payloadStateByNativeEvent.get(native);
  if (!sharedState) {
    sharedState = {};
    payloadStateByNativeEvent.set(native, sharedState);
  }
  const state = sharedState;

  return new Proxy(target, {
    get(obj, prop) {
      if (prop in obj) return obj[prop];
      return state[prop];
    },
    set(obj, prop, value) {
      if (prop in obj) obj[prop] = value;
      else state[prop] = value;
      return true;
    },
    has(obj, prop) {
      return prop in obj || prop in state;
    },
  });
}

function createProxyTarget(args: {
  protoBus: EventTarget;
  hostTarget: EventTarget;
  focusEventTarget?: EventTarget;
  isEnabled: () => boolean;
}) {
  // 记录已转发到 host 的监听器，便于 remove 时精确解绑
  const hostListeners: Listener[] = [];
  const protoListeners: (Listener & { capture: boolean; cleanup: () => void })[] = [];

  // 为 host-bound 分支加 gating：eventGate disable 后，这些也不应该再进 proto 回调
  // 这点非常关键，否则“unmount 后还能触发回调”的竞态会回来。
  function wrapWithGate(cb: any) {
    return (ev: any) => {
      if (!args.isEnabled()) return;
      cb(ev);
    };
  }

  function parseType(type: string) {
    if (type.startsWith('host:')) {
      return { kind: 'host' as const, inner: type.slice('host:'.length) };
    }
    return { kind: 'proto' as const, inner: type };
  }

  const api: any = {
    addEventListener(type: string, cb: any, options?: any) {
      const p = parseType(String(type));

      if (p.kind === 'proto') {
        const signal = options?.signal;
        if (!cb || signal?.aborted) return;
        const capture = typeof options === 'boolean' ? options : Boolean(options?.capture);
        const once = Boolean(options?.once);
        if (protoListeners.some((r) => r.type === p.inner && r.cb === cb && r.capture === capture))
          return;
        const record = {
          type: p.inner,
          cb,
          options,
          capture,
          wrapped: undefined as any,
          cleanup: () => {},
        };
        record.cleanup = () => {
          const index = protoListeners.indexOf(record);
          if (index < 0) return;
          protoListeners.splice(index, 1);
          args.protoBus.removeEventListener(p.inner, record.wrapped, capture);
          signal?.removeEventListener('abort', record.cleanup);
        };
        record.wrapped = (event: Event) => {
          if (once) record.cleanup();
          if (typeof cb === 'function') cb.call(args.protoBus, event);
          else cb.handleEvent(event);
        };
        args.protoBus.addEventListener(p.inner, record.wrapped, {
          capture,
          once,
          signal,
          passive: Boolean(options?.passive),
        });
        protoListeners.push(record);
        signal?.addEventListener('abort', record.cleanup, { once: true });
        return;
      }

      // host:*
      const wrapped = wrapWithGate(cb);
      const target =
        p.inner === 'focus' || p.inner === 'blur'
          ? (args.focusEventTarget ?? args.hostTarget)
          : args.hostTarget;
      hostListeners.push({ type: p.inner, target, cb, options, wrapped } as any);
      target.addEventListener(p.inner, wrapped as any, options);
    },

    removeEventListener(type: string, cb: any, options?: any) {
      const p = parseType(String(type));

      if (p.kind === 'proto') {
        const capture = typeof options === 'boolean' ? options : Boolean(options?.capture);
        protoListeners
          .find((r) => r.type === p.inner && r.cb === cb && r.capture === capture)
          ?.cleanup();
        return;
      }

      // latest-first removal aligns with your v0 matching习惯
      for (let i = hostListeners.length - 1; i >= 0; i--) {
        const r: any = hostListeners[i];
        if (r.type !== p.inner) continue;
        if (r.cb !== cb) continue;
        // options 匹配这里先用 Object.is（和 DOM 一样复杂就复杂了）
        // 你若坚持“plain object shallow compare”，可以把 sameOptions 搬进来
        if (!Object.is(r.options, options)) continue;

        (r.target ?? args.hostTarget).removeEventListener(p.inner, r.wrapped as any, options);
        hostListeners.splice(i, 1);
        return;
      }
    },

    dispatchEvent(ev: Event) {
      // 对外暴露的 dispatch：默认只派发到 protoBus
      // （hostTarget 的 dispatch 由真实 DOM 自己完成）
      return args.protoBus.dispatchEvent(ev);
    },

    __hasProtoListeners(type: string) {
      return protoListeners.some((r) => r.type === type);
    },

    /** Private adapter ingress; does not emit another public DOM event. */
    __dispatchHost(type: string, event: Event) {
      for (const listener of hostListeners) {
        if (listener.type !== type) continue;
        listener.wrapped?.(event);
      }
    },
    // best-effort cleanup (not required by EventTarget)
    __dispose() {
      for (const r of [...protoListeners]) r.cleanup();
      // 主动解绑所有已懒绑定的 host listener，避免残留
      for (const r of hostListeners.splice(0)) {
        (r.target ?? args.hostTarget).removeEventListener(
          r.type,
          // @ts-ignore
          r.wrapped as any,
          r.options
        );
      }
    },
  };

  return api;
}
