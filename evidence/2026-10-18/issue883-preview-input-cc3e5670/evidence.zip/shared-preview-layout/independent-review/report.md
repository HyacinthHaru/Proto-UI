六文件布局候选静态交叉审阅0具体finding，partial/ABSTAIN。3处app布局与3个直接单元变更已逐SHA绑定；非splash仅去重复inlinegutter，splash/TOC/slot原字节保留；scene仅block2rem与inline min(2rem,8%)，其余lease/provider/guard/observer/cleanup字节不变；Liquid demo显式单列。原36browser源未改。

8%以containingblock inline width为基准；只有在明确256px包含块假设下，单侧20.48px、scene内容215.04px，后续约181.04px是未测条件算术。旧all-edgepadding控制不代表当前inline-only+docs-gutter候选。已读取父线程3files33pass与78files1235pass；本报告不提前称运行中的native通过或光学/全页面验收。
