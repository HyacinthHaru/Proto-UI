# 共享预览窄屏布局：源码与候选

基线为clean4aad/treecd35；现在冻结6个本地改动（3处app布局、3个直接单元文件），28+/4−，尚未提交。root已明确采用方案并拥有后续验证。本agent只做source/authority追踪、编辑与格式检查，没有启动native、build或unit测试。

归属是网站consumer的阅读与Previewer包含块组合，不是新证实的Runtime/Anatomy生命周期缺陷。draft `P-LIQUID-GLASS-COLLAPSIBLE[-CONTENT]-VISUAL-SAFETY` 的min-width、max-width、长词换行、scalablepadding和focus空间保留；原T native320px/200%/scroll+1及所有36case保持。没有修改spec或稳定准入。

最小候选：

- `TwoColumnContent.astro` 仅非splash的px-5→px-0。global.container-wrapper已经负责1rem外gutter，md原本也是0；splash的px-1/md:px-6、block阅读inset、TOC/Header与完整页面内容不变。
- `preview-material-scene.ts` 改为block2rem、inline min(2rem,8%)。它是当前用户已批准的app响应式布局选择，不是新公开数值保证；保留max32rem、visiblecanvas、provider、sourcelease、coverage/DPRbudget和Portal资源逻辑。
- Liquid Collapsible demo的既有单列box加已支持的grid-cols-1，明确track从实际内容宽度收缩；不修改任何part合法token，也不添加组件名compiler例外。

既有原Linux红项Root宽177.4375/right320.4375；单独gridminmax负控制Root14但scroll82/client14，不能作为修复。新root控制仅scene padding+grid能把Root收为113.84375/client114/scroll114，但文本仍很窄；该script实际改四边padding（`style.padding`），不是只inline，Root top也变。当前候选保留block2rem并另去重复阅读gutter，所以不能把该控制冒称完整候选已跑。静态预计320/root32的scene176→256、mount约215、Root约181；这只是可检验预测，不能替代原browser几何。

直接单元分别保护outergutter与splash分支、scene block/inline spacing来源、真实DemoSpec的有界单列；HappyDOM/source checks不提供浏览器几何或光学证据。原scene sourcelease/边界/资源检查和原36浏览器断言都未放宽。近期09a7ec70c修复已明确scene独占preview spacing且撤销第二层Runtime reserve，本候选保留该边界，只使共享app横向留白在小容器中有界。

baseline原bytes/SHA在baseline/与source-baseline.json，候选bytes在candidate/，精确diff为candidate.patch。ProductPrettier完成，gitdiffcheck0。尚无candidate native通过声明；root随后运行3unit与原36和共享受影响组合，任何新失败保持原断言调查。

[机器source/authority报告](./source-trace-report.json) · [全部候选hash](./candidate-change.json)。human-assisted、unassessed、partial/ABSTAIN，无GitHub批准或发布。
