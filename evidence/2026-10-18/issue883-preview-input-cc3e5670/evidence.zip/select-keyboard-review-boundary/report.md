# Select 键盘回焦重入：候选审查边界

本报告只读固定554597 Git对象，当前candidate尚未审查；独审正在写入的working tests不计作原有覆盖。原4aad builtartifact时间线已显示值已提交、Content关闭、焦点回Trigger后，在没有第二次keydown的情况下再open；它不支持“尚未commit值”的归因，也不独自证明具体哪条Router ingress。

首要authority是draft `C-EVENT-0003-E`：root语义只投递实际交互owner。`C-EVENT-0005`同时要求每个独立registration保留独立callback，不能以全局dedup/stopPropagation修复归属。`press.*`仍为activation intent，`key.*`仍为输入通道，不增加Host私有对象到PrototypeAPI。

当前globalkeydown先投递global key，再可投递root key，然后重新解析pressowner；解析在原target/path无owner时可以读当前activeElement。rootEl keydown另有直接emitPressCommitOnce路径。现有去重是per-root/event，不能自动阻止同一输入被另一个root认领。这两个入口应由窄red区分；不能仅按静态代码宣布根因。

候选至少需要保留：旧Item退休/回焦同keydown不再激活Trigger；真正外部Portal/slot、缺少物理root ingress时的active fallback；正常新Trigger输入；global key、多个listener、host:*与proto并存；keyup清理及zero-detail click抑制、repeat、once/abort/dispose。原event-router-work的Portal rebind/Shadow/slot等控制保持。不能添加全局重入锁、停native传播或靠多等一次关闭掩盖重开。

直接消费者是Select Item→选值/关闭→Trigger回焦；共享Router也被四Adapter和ContextMenu/Tabs/Button/RadioGroup/ToggleGroup消费，后者只是影响面，不表示已有同因失败。后续需原Homepage settings键盘journey验证真实组合，不能用unit绿代替。

[逐路径Git blob/SHA与审查清单](./report.json)。不执行native/tests/build、不改源码、不外写；human-assisted、unassessed、partial/ABSTAIN。
