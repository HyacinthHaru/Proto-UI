from pathlib import Path
import subprocess,hashlib,json,datetime,os,sys
W=Path('<SOURCE_ROOT>');P=Path(__file__).parent;phase=sys.argv[1];now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();H=lambda b:hashlib.sha256(b).hexdigest()
paths=['packages/adapters/base/test/event-router-work.test.ts','packages/adapters/base/src/events/web-event-router.ts']
def source():return {p:H((W/p).read_bytes())for p in paths}
def git(*args):return subprocess.check_output(['git',*args],cwd=W,text=True).strip()
env=os.environ.copy();env['PATH']='<HOME>/.codex/task-state/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:'+env['PATH'];cmd=['corepack','pnpm@10.32.1','exec','vitest','run',paths[0],'--maxWorkers=1','--minWorkers=1','--reporter=verbose','--reporter=json','--outputFile='+str(P/(phase+'-vitest.json'))]
receipt={'start':now(),'phase':phase,'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'statusBefore':git('status','--porcelain'),'sourceBefore':source(),'command':cmd,'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'scope':'Existingactualeventrouterworkfixture+acceptedkeyboardownerretirementandfresh/no-consumer/Portalcontrols. HappyDOMsyntheticKeyboardEvent;notnative. Source554597+thissamefixture.'}
(P/(phase+'-working.patch')).write_text(git('diff','--no-ext-diff'))
with (P/(phase+'.log')).open('x')as log:
 r=subprocess.run(cmd,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
receipt.update({'end':now(),'exit':r.returncode,'sourceAfter':source(),'statusAfter':git('status','--porcelain'),'logSHA256':H((P/(phase+'.log')).read_bytes())});receipt['twoInputHashesStable']=receipt['sourceBefore']==receipt['sourceAfter'];d=json.loads((P/(phase+'-vitest.json')).read_text());receipt['counts']={k:d.get(k)for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']};(P/(phase+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));
