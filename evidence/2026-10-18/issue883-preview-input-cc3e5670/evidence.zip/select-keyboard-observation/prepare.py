from pathlib import Path
import subprocess,hashlib,json,difflib
P=Path(__file__).parent;W=Path('<SOURCE_ROOT>');rel='apps/www/src/content/docs/zh-cn/home-demo-runtime.browser.test.ts';head='4aad83f80ab29e0a5d4f3c0b63af17e3dcf64e06';raw=subprocess.check_output(['git','show',head+':'+rel],cwd=W);s=raw.decode();(P/'original.browser.test.ts').write_bytes(raw)
observer=r'''
function observeSelectKeyboard(trigger: Element) {
  const doc = trigger.ownerDocument, win = doc.defaultView!;
  const ids = new WeakMap<object, number>(); let nextId = 0, stopped = false, dropped = 0;
  const id = (value: object | null) => { if (!value) return null; if (!ids.has(value)) ids.set(value, ++nextId); return ids.get(value); };
  const markers = ['web-component', 'react', 'vue', 'vue2'].map((name) => [name, Symbol.for(`@proto.ui/adapter-${name}/__proto_instance`)] as const);
  const ownerMark = Symbol.for('@proto.ui/as-trigger/confirm-owner');
  const parentMark = Symbol.for('@proto.ui/adapter-base/__proto_parent_instance');
  const describe = (node: any) => {
    if (!(node instanceof win.Element)) return node ? { identity: id(node), node: node.constructor?.name } : null;
    const owner = node[ownerMark], parent = node[parentMark];
    const attrs = Object.fromEntries(['id','role','tabindex','data-demo-ref','data-value','data-active','data-selected','data-open','data-is-present','data-transition-state','data-disabled','aria-disabled','aria-selected','aria-expanded','aria-controls','data-pui-view-pending','data-pui-view-detached','data-pui-view-revealing','data-projection-prototype','data-projection-runtime','data-projection-owner','data-projection-generation','data-projection-generation-state'].map((name) => [name,node.getAttribute(name)]));
    return { identity: id(node), node: node.localName, connected: node.isConnected, attrs,
      instanceMarkers: markers.filter(([,symbol]) => node[symbol] === true).map(([name]) => name),
      triggerOwner: owner === true ? { self: true, identity: id(node) } : owner && (typeof owner === 'object' || typeof owner === 'function') ? { identity: id(owner) } : null,
      logicalParent: parent instanceof win.Element ? { identity: id(parent), node: parent.localName, ref: parent.getAttribute('data-demo-ref') } : null,
      tokens: node.getAttribute('data-pui-style'), text: ['combobox','option'].includes(node.getAttribute('role')??'') ? node.textContent?.trim().slice(0,180) : null };
  };
  const chain = (start: Element | null) => { const rows=[];let node=start;for(let depth=0;node&&depth<12;depth++,node=node.parentElement)rows.push(describe(node));return {rows,truncated:node!==null}; };
  const records: unknown[]=[];
  const sample = (phase: string, event?: Event) => {
    if(stopped)return;
    if(records.length>=128){records.splice(1,1);dropped++;}
    const portal=doc.getElementById(trigger.getAttribute('aria-controls')??'');
    records.push({phase,time:win.performance.now(),trigger:describe(trigger),active:describe(doc.activeElement),portal:describe(portal),
      options:portal?Array.from(portal.querySelectorAll('[role="option"]')).slice(0,16).map(describe):[],
      triggerAncestors:chain(trigger),activeAncestors:chain(doc.activeElement),
      event:event?{type:event.type,trusted:event.isTrusted,key:event instanceof win.KeyboardEvent?event.key:null,target:describe(event.target),path:event.composedPath().slice(0,16).map(describe),pathTruncated:event.composedPath().length>16}:null});
  };
  const onEvent=(event:Event)=>{sample('native-capture',event);win.queueMicrotask(()=>sample(`capture-microtask:${event.type}`));};
  const events=['keydown','keyup','pointerdown','pointerup','click','focusin','focusout'];
  for(const type of events)doc.addEventListener(type,onEvent,true);
  const mutation=new win.MutationObserver(()=>sample('attribute-mutation'));
  mutation.observe(doc.body,{subtree:true,attributes:true,attributeFilter:['data-open','data-active','data-selected','data-value','aria-expanded','aria-selected','data-is-present','data-transition-state']});
  sample('installed-before-original-focus');
  return {freeze(){sample('original-keyboard-boundary-final');stopped=true;mutation.disconnect();for(const type of events)doc.removeEventListener(type,onEvent,true);return {records,dropped,boundary:'Nativecapture/microtasks/attributeobserver plus final boundary; not atomic, microtask is not dispatch completion; only existing DOM/marker facts, no logical private state.'};}};
}
'''
anchor="const HOME_ROUTE = '/zh-cn/';";assert s.count(anchor)==1;s=s.replace(anchor,observer+'\n'+anchor,1)
start=s.index('          // Exercise actual Select keyboard navigation and its focus-return boundary.')
end=s.index('          await summary.focus();',start)
block=s[start:end];assert block.count("await page.keyboard.press('Enter');")==2
replacement='''          const selectObservation = await view.evaluateHandle(observeSelectKeyboard);
          let selectFailure = false;
          try {
'''+block+'''          } catch (error) {
            selectFailure = true;
            throw error;
          } finally {
            try {
              const directory = process.env.PROTO_UI_SELECT_OBSERVATION_DIR!;
              await mkdir(directory, { recursive: true });
              const observed = await selectObservation.evaluate((observer) => observer.freeze());
              const prefix = `${family}-${runtime}`;
              await writeFile(path.join(directory, `${prefix}.json`), JSON.stringify({
                servedSource: { head: '4aad83f80ab29e0a5d4f3c0b63af17e3dcf64e06', artifact: 12109493824, baseUrl },
                family, runtime, failed: selectFailure, browser: browser.version(), capturedAt: new Date().toISOString(), observed,
              }, null, 2) + '\\n');
              if (selectFailure) {
                await writeFile(path.join(directory, `${prefix}.html`), await page.content());
                await writeFile(path.join(directory, `${prefix}.ax.txt`), await page.locator('body').ariaSnapshot());
                await page.screenshot({ path: path.join(directory, `${prefix}.png`), timeout: 3000 });
              }
            } catch (diagnosticError) {
              console.error('[select-readonly-observation-unavailable]', String(diagnosticError));
            } finally {
              await selectObservation.dispose().catch(() => {});
            }
          }
'''
s=s[:start]+replacement+s[end:];(P/'diagnostic.browser.test.ts').write_text(s)
config = (
    'import base from '+json.dumps(str(W/'vitest.config.ts'))+';\n'
    + "import fs from 'node:fs'; import path from 'node:path';\n"
    + 'const repo='+json.dumps(str(W))+', target='+json.dumps(rel)+', input='+json.dumps(str(P/'diagnostic.browser.test.ts'))+';\n'
    + 'export default {...base,root:repo,cacheDir:'+json.dumps(str(P/'vite-cache'))+",plugins:[{name:'private-select-keyboard-readonly-observation',enforce:'pre',load(id){if(path.relative(repo,id.split('?')[0].replace(/^\\/@fs/,''))===target)return fs.readFileSync(input,'utf8');return null;}},...(base.plugins??[])],test:{...base.test,include:[target],fileParallelism:false,maxWorkers:1,minWorkers:1,reporters:['verbose','json'],outputFile:{json:"+json.dumps(str(P/'vitest.json'))+'}}};\n'
)
(P/'private.config.ts').write_text(config)
(P/'diagnostic.patch').write_text(''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True),s.splitlines(keepends=True),fromfile=rel,tofile='private-diagnostic/'+rel)))
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(P/'source-binding.json').write_text(json.dumps({'servedHead':head,'artifact':12109493824,'baseUrl':'http://127.0.0.1:57821','originalTestPath':rel,'originalTestSHA256':H(P/'original.browser.test.ts'),'diagnosticTestSHA256':H(P/'diagnostic.browser.test.ts'),'privateConfigSHA256':H(P/'private.config.ts'),'originalKeyboardBlockByteIdentical':block in s,'originalAssertionAndTimeoutChanges':False,'originalCaseTimeoutMs':240000,'externalWatchdogSeconds':150,'instrumentation':'One initial read-only evaluateHandle per runtime keyboard segment; only passive native-event/mutation observers, no new input/State/Props/flags/callback replacement. Extra post-boundary evaluation and failure-only DOM/AX/PNG can affect scheduling; original case includes its existing later React/native composition diagnostics unchanged.','sourceBoundary':'Nodecheckout canadvancewhileRootcommitsunchangedcandidatebytes; servedapp remainsoriginal4aadartifact. Notcandidateappnativevalidation.'},indent=2)+'\n')
print(json.dumps({'prepared':str(P),'original':H(P/'original.browser.test.ts'),'diagnostic':H(P/'diagnostic.browser.test.ts'),'config':H(P/'private.config.ts')}))
