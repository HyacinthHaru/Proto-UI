from pathlib import Path
import subprocess,hashlib,json,datetime,os,signal,time
P=Path(__file__).parent;W=Path('<SOURCE_ROOT>');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();H=lambda b:hashlib.sha256(b).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=W,text=True).strip();test='apps/www/src/content/docs/zh-cn/home-demo-runtime.browser.test.ts'
env=os.environ.copy();env['PATH']='<HOME>/.codex/task-state/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:'+env['PATH'];env['PROTO_UI_BROWSER_BASE_URL']='http://127.0.0.1:57821';env['CHROME_PATH']='<CHROMIUM_APP>/Contents/MacOS/Google Chrome';env['PROTO_UI_SELECT_OBSERVATION_DIR']=str(P/'observations')
cmd=['corepack','pnpm@10.32.1','exec','vitest','run','--config',str(P/'private.config.ts'),'--testNamePattern','^Homepage Runtime demobox browser smoke completes the settings task and resets local state through both libraries and all runtimes$']
files=['original.browser.test.ts','diagnostic.browser.test.ts','private.config.ts','source-binding.json'];receipt={'start':now(),'servedHead':'4aad83f80ab29e0a5d4f3c0b63af17e3dcf64e06','servedArtifact':12109493824,'baseUrl':env['PROTO_UI_BROWSER_BASE_URL'],'nodeCheckoutBefore':git('rev-parse','HEAD'),'statusBefore':git('status','--porcelain'),'productTestBeforeSHA256':H((W/test).read_bytes()),'privateFiles':{n:H((P/n).read_bytes())for n in files},'command':cmd,'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'GITHUB_ACTIONS_InheritedValue':env.get('GITHUB_ACTIONS'),'setGITHUB_ACTIONS':False,'originalCaseTimeoutMs':240000,'outerWatchdogSeconds':150,'executionBoundary':'Private diagnostic module override;originalpublickeyboardloop/expectations unchanged; servedpage original4aadartifact, notNodecheckoutcandidate.'}
with(P/'run.log').open('x')as log:
 p=subprocess.Popen(cmd,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);receipt['pid']=p.pid;receipt['pgid']=p.pid;(P/'running.json').write_text(json.dumps(receipt,indent=2)+'\n')
 try:receipt['exit']=p.wait(timeout=150)
 except subprocess.TimeoutExpired:
  receipt['outerWatchdogTriggered']=True;os.killpg(p.pid,signal.SIGTERM)
  try:receipt['exit']=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);receipt['exit']=p.wait()
receipt.update({'end':now(),'nodeCheckoutAfter':git('rev-parse','HEAD'),'statusAfter':git('status','--porcelain'),'productTestAfterSHA256':H((W/test).read_bytes()),'logSHA256':H((P/'run.log').read_bytes())});receipt['productTestUntouched']=receipt['productTestBeforeSHA256']==receipt['productTestAfterSHA256'];result=P/'vitest.json'
if result.exists():
 d=json.loads(result.read_text());receipt['vitestCounts']={k:d.get(k)for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','success']}
ps=subprocess.run(['ps','-axo','pid=,pgid=,command='],text=True,capture_output=True);receipt['remainingOwnProcessGroup']=[l.strip()for l in ps.stdout.splitlines()if len(l.split(None,2))>=2 and l.split(None,2)[1]==str(p.pid)]
(P/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
