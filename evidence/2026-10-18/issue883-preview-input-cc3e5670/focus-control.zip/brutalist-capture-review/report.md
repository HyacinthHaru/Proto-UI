# Brutalist narrow capture review

All **8 original PNG files** were individually opened with `view_image` and matched to their JSON sidecars. No source, count or metadata mismatch was found in this bounded review. The conclusion remains **partial / ABSTAIN**.

These are the **precommit 4aad + eight working files** captures from the first native combination, executed **2026-10-18 02:02:16.107726–02:03:42.118179 UTC** against the complete local site at `http://127.0.0.1:57822`. Every sidecar retains `source.sha=4aad83f80ab29e0a5d4f3c0b63af17e3dcf64e06` and `dirty=true`. The later 11329-file binding to `554597` does not turn them into postcommit evidence. They are not the final `cc3` execution.

The actual combination was **3 files / 46 passed / 0 failed / 0 skipped**. The Brutalist file contributed **8 cases**: four interaction cases and four reflow cases. Each reflow case captured 100% and 200%, yielding these eight PNGs; PNG count is not a separate test count.

| Original PNG | Captured UTC | Runtime | Root font | PNG pixels | Visual boundary |
| --- | --- | --- | --- | --- | --- |
| react-320-font-100.png | 2026-10-18T02:03:38.163Z | react | 100% | 288×446 | Button grid visible; right tab labels clipped. |
| react-320-font-200.png | 2026-10-18T02:03:38.294Z | react | 200% | 256×1686 | Mobile Header obscures Mint/part of Lavender; narrow multi-line wrapping. |
| vue-320-font-100.png | 2026-10-18T02:03:39.914Z | vue | 100% | 288×446 | Button grid visible; right tab labels clipped. |
| vue-320-font-200.png | 2026-10-18T02:03:40.052Z | vue | 200% | 256×1686 | Mobile Header obscures Mint/part of Lavender; narrow multi-line wrapping. |
| vue2-320-font-100.png | 2026-10-18T02:03:41.709Z | vue2 | 100% | 288×446 | Button grid visible; right tab labels clipped. |
| vue2-320-font-200.png | 2026-10-18T02:03:41.842Z | vue2 | 200% | 256×1686 | Mobile Header obscures Mint/part of Lavender; narrow multi-line wrapping. |
| wc-320-font-100.png | 2026-10-18T02:03:36.290Z | wc | 100% | 288×446 | Button grid visible; right tab labels clipped. |
| wc-320-font-200.png | 2026-10-18T02:03:36.436Z | wc | 200% | 256×1686 | Mobile Header obscures Mint/part of Lavender; narrow multi-line wrapping. |

At **100%**, all ten button examples are visible in the captured host area. The top Runtime tab strip is cropped on the right. At **200%**, all four captures show the mobile Header over the upper-middle button column; Mint and part of Lavender are obscured. Labels split into short, sometimes mid-word lines. These are real capture limitations even though the measured button and text rectangles satisfy the original containment assertions.

All sidecars record a **320×1000 viewport**. The screenshot target was the `.host` element, producing **288×446** PNGs at 100% and **256×1686** PNGs at 200%; these are not whole-page screenshots. The original test changes the root font size relative to its initial computed value, not browser zoom or OS accessibility scaling. Geometry facts were sampled before screenshot capture, while `capturedAt` was recorded afterward.

React, Vue and Vue2 have byte-identical 200% PNGs. Each actual file was still separately opened and retains its distinct execution metadata. Byte duplication does not create an extra run or establish runtime identity from pixels alone.

The sidecars carry runtime labels and source/timing metadata, but no Runtime mount-epoch, owner-retirement or disposal-completion trace. This review establishes the provenance and visible limits of these eight images; it does not claim full lifecycle, whole-page, AT or GitHub approval. No browser, test, download, raw-file edit or external publication was performed.
