import subprocess,datetime,os,json,pathlib,hashlib,signal
r=pathlib.Path(__file__).parent;w=pathlib.Path('<SOURCE_ROOT>');node='<HOME>/.codex/task-state/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin/node';now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();git=lambda *a:subprocess.check_output(['git',*a],cwd=w,text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d={'start':now(),'headBefore':git('rev-parse','HEAD'),'statusBefore':git('status','--porcelain'),'scriptSHA256':sha(r/'probe.mjs'),'argv':[node,str(r/'probe.mjs')],'watchdogSeconds':60,'newTestOrProductionSourceMutation':False}
with (r/'run.log').open('x') as f:
 p=subprocess.Popen(d['argv'],cwd=w,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);d['pid']=p.pid;d['pgid']=p.pid
 try:d['exit']=p.wait(timeout=60)
 except subprocess.TimeoutExpired:
  d['watchdogTriggered']=True;os.killpg(p.pid,signal.SIGTERM)
  try:d['exit']=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);d['exit']=p.wait()
d.update({'end':now(),'headAfter':git('rev-parse','HEAD'),'statusAfter':git('status','--porcelain'),'scriptSHA256After':sha(r/'probe.mjs'),'logSHA256':sha(r/'run.log')});ps=subprocess.check_output(['ps','-axo','pid=,pgid=,command='],text=True);d['remainingOwnProcessGroup']=[l.strip()for l in ps.splitlines()if len(l.split(None,2))>=2 and l.split(None,2)[1]==str(p.pid)];(r/'receipt.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
