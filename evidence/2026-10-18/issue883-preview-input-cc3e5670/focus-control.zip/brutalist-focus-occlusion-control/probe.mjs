import {createRequire} from 'node:module';
import {writeFile} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
const req=createRequire('<SOURCE_ROOT>/apps/www/package.json');
const {chromium}=req('playwright-core');
const dir=path.dirname(new URL(import.meta.url).pathname);
const result={start:new Date().toISOString(),sourceHead:'cc3e5670a3a83d4f797fa2af7d942aae876b0f2b',servedBuild:'Parent-bound complete local build; no source modification by this control',baseUrl:'http://127.0.0.1:57822',route:'/en/ui-libraries/brutalist/components/button/',viewport:{width:320,height:1000},scope:'One WC consumer, root font 200%; explicit programmatic Mint focus followed by three native Tabs; immediate readonly geometry/hit-test samples, not an original test rerun',rows:[],pageErrors:[],exit:1};
let browser,context,observer;
try{
 browser=await chromium.launch({executablePath:'<CHROMIUM_APP>/Contents/MacOS/Google Chrome',headless:true,args:['--disable-dev-shm-usage','--no-sandbox']});result.browser=browser.version();
 context=await browser.newContext({viewport:result.viewport});const page=await context.newPage();page.setDefaultTimeout(10000);page.on('pageerror',e=>result.pageErrors.push(e.message));
 await page.goto(result.baseUrl+result.route,{waitUntil:'networkidle',timeout:20000});
 const preview=page.locator('[data-previewer-id]').first();await preview.waitFor({state:'visible'});
 await page.waitForFunction(()=>{const p=document.querySelector('[data-previewer-id]');return p?.__previewer__?.getCurrentRuntime?.()==='wc'&&!p.querySelector('.proto-previewer__skeleton')},null,{timeout:10000});
 const selector='[data-projection-content] .pui-runtime-preview-surface[data-demo-ref="__website_runtime_preview_surface__"] [data-pui-root]';const buttons=preview.locator(selector);assert.equal(await buttons.count(),10);
 result.initialRootFont=await page.evaluate(()=>getComputedStyle(document.documentElement).fontSize);
 await page.evaluate(size=>document.documentElement.style.fontSize=size,`${parseFloat(result.initialRootFont)*2}px`);await page.evaluate(()=>document.fonts.ready);
 result.rootFontAfter=await page.evaluate(()=>getComputedStyle(document.documentElement).fontSize);
 observer=await page.evaluateHandle(()=>{const rows=[];const describe=e=>e instanceof Element?{tag:e.localName,text:e.textContent?.trim().slice(0,80),role:e.getAttribute('role'),ref:e.getAttribute('data-demo-ref')}:null;const f=e=>rows.push({type:e.type,key:e.key??null,trusted:e.isTrusted,at:performance.now(),target:describe(e.target),active:describe(document.activeElement)});for(const n of ['keydown','keyup','focusin'])document.addEventListener(n,f,true);return{finish(){for(const n of ['keydown','keyup','focusin'])document.removeEventListener(n,f,true);return rows;}}});
 const snapshot=async(label,index)=>buttons.nth(index).evaluate((el,label)=>{
  const desc=e=>e instanceof Element?{tag:e.localName,role:e.getAttribute('role'),ref:e.getAttribute('data-demo-ref'),text:e.textContent?.trim().slice(0,80),class:e.getAttribute('class')}:null;
  const rect=e=>e.getBoundingClientRect().toJSON();const cs=getComputedStyle(el);const b=el.getBoundingClientRect();const point={x:b.left+b.width/2,y:b.top+b.height/2};const hit=document.elementFromPoint(point.x,point.y);const headers=[...new Set(document.querySelectorAll('header,[role="banner"],.header,.site-header'))].map(h=>{const s=getComputedStyle(h);return{element:desc(h),rect:rect(h),position:s.position,zIndex:s.zIndex,visibility:s.visibility,display:s.display,scrollPaddingTop:s.scrollPaddingTop}});
  const actual=document.activeElement;return{label,at:performance.now(),runtime:document.querySelector('[data-previewer-id]')?.__previewer__?.getCurrentRuntime?.(),target:desc(el),targetRect:rect(el),active:desc(actual),activeRect:actual instanceof Element?rect(actual):null,activeIsTarget:actual===el||el.contains(actual),targetConnected:el.isConnected,center:point,hit:desc(hit),centerHitsTarget:hit===el||el.contains(hit),centerInViewport:point.x>=0&&point.x<innerWidth&&point.y>=0&&point.y<innerHeight,headers,viewport:{width:innerWidth,height:innerHeight,scrollX,scrollY,visual:visualViewport?{offsetTop:visualViewport.offsetTop,offsetLeft:visualViewport.offsetLeft,width:visualViewport.width,height:visualViewport.height,scale:visualViewport.scale}:null},styles:{scrollMarginTop:cs.scrollMarginTop,scrollMarginBottom:cs.scrollMarginBottom,scrollMarginBlockStart:cs.scrollMarginBlockStart,rootScrollPaddingTop:getComputedStyle(document.documentElement).scrollPaddingTop,rootScrollBehavior:getComputedStyle(document.documentElement).scrollBehavior,bodyScrollPaddingTop:getComputedStyle(document.body).scrollPaddingTop},document:{scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth,scrollHeight:document.documentElement.scrollHeight}};
 },label);
 assert.equal((await buttons.nth(1).textContent()).trim(),'Mint');await buttons.nth(1).focus();result.rows.push(await snapshot('programmatic-focus-Mint-setup',1));
 for(const [index,label] of [[2,'native-Tab-Lavender'],[3,'native-Tab-Coral'],[4,'native-Tab-Sky']]){
  await page.keyboard.press('Tab');result.rows.push(await snapshot(label,index));
  if(index===2){await page.screenshot({path:path.join(dir,'viewport-after-native-Tab-Lavender.png'),fullPage:false,timeout:5000});result.screenshotCapturedAt=new Date().toISOString();result.screenshotAfterSample=await snapshot('after-viewport-screenshot-Lavender',index);}
 }
 result.events=await observer.evaluate(o=>o.finish());await observer.dispose();observer=null;result.exit=0;
}catch(e){result.error={message:e.message,stack:e.stack};console.error(e);}
finally{try{await observer?.evaluate(o=>o.finish());await observer?.dispose();}catch(e){result.observerCleanupError=String(e);}try{await context?.close();await browser?.close();result.browserClosed=true;}catch(e){result.cleanupError=String(e);}result.end=new Date().toISOString();await writeFile(path.join(dir,'observations.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({exit:result.exit,start:result.start,end:result.end,rows:result.rows.map(x=>({label:x.label,focused:x.activeIsTarget,rect:x.targetRect,headerbottom:x.headers.map(h=>h.rect.bottom),centerHitsTarget:x.centerHitsTarget,hit:x.hit,scrollY:x.viewport.scrollY}))}));}
process.exitCode=result.exit;
