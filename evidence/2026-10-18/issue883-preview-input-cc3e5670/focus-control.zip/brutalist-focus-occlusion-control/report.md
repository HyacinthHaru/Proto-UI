# Brutalist focus and Header occlusion control

**No focus-occlusion counterexample was observed in this one control.** The run completed in about three seconds, **2026-10-18 02:47:26.653723–02:47:29.757924 UTC**, exit 0. The checkout was clean `cc3e5670a3a83d4f797fa2af7d942aae876b0f2b` before and after; the page was the parent-bound complete local build at `http://127.0.0.1:57822/en/ui-libraries/brutalist/components/button/`. Chrome was 155.0.8059.80.

The fresh context used a **320×1000 viewport**, confirmed WC runtime, and root font **16px → 32px**. Programmatic focus on Mint was explicitly setup. Exactly three trusted native Tab keydowns then moved focus to Lavender, Coral and Sky. No product/test source, owner/state flags, timeout or original assertion was changed.

| Stage | Focus target | Top–bottom | Header bottom | Center hits target | scrollY |
| --- | --- | --- | --- | --- | --- |
| programmatic-focus-Mint-setup | Mint | 458–542 | 192 | True | 1282 |
| native-Tab-Lavender | Lavender | 574–698 | 192 | True | 1282 |
| native-Tab-Coral | Coral | 730–814 | 192 | True | 1282 |
| native-Tab-Sky | Sky | 846–926 | 192 | True | 1282 |

The Header computes to **position: sticky**, bottom **192px**. All four sampled target rectangles, including Mint setup, were below it and inside the viewport; each center hit the target element. Target scroll-margin-top and root scroll-padding-top were both 0px. The focus setup placed the page at scrollY 1282; no further document scroll occurred across these three Tabs. This is an observation of this sequence, not a general proof of browser focus-scrolling policy.

I opened the new `viewport-after-native-Tab-Lavender.png` directly. Lavender has a full visible focus outline below the Header. Mint, Coral and Sky are not covered by it; the next Surface button is cropped by the bottom of the viewport. This is one current viewport screenshot, not a replacement or recapture of the older host screenshots.

The old 200% `.host` screenshots retain their real Header overlap at their own capture position. That overlap alone does **not** demonstrate a C focus defect. This limited control supports no production change; narrow text wrapping and capture-scope limitations remain. It does not establish whole-page, all-runtime or AT acceptance.

The browser was closed, its owned process group is empty, and the native slot has been released. The parent-owned static server was left running. The conclusion remains **partial / ABSTAIN**; no external write or approval occurred.
