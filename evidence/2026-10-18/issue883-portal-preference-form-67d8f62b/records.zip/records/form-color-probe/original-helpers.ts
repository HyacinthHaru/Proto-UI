async function paint(locator: Locator) {
  return locator.evaluate((element) => {
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    const range = document.createRange();
    range.selectNodeContents(element);
    const textRect = range.getBoundingClientRect();
    return {
      rect: {
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
        right: rect.right,
        bottom: rect.bottom,
      },
      textWidth: textRect.width,
      display: style.display,
      visibility: style.visibility,
      color: style.color,
      background: style.backgroundColor,
      shadow: style.boxShadow,
      border: [
        style.borderTopWidth,
        style.borderRightWidth,
        style.borderBottomWidth,
        style.borderLeftWidth,
      ],
      borderColor: style.borderBottomColor,
      radius: style.borderRadius,
      padding: [style.paddingTop, style.paddingRight, style.paddingBottom, style.paddingLeft],
      font: style.font,
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      outline: style.outline,
      opacity: style.opacity,
      clientWidth: element.clientWidth,
      scrollWidth: element.scrollWidth,
      scrollLeft: element.scrollLeft,
      overflowX: style.overflowX,
      ariaSelected: element.getAttribute('aria-selected'),
      ariaChecked: element.getAttribute('aria-checked'),
    };
  });
}

async function hasFocus(locator: Locator) {
  return locator.evaluate((element) => {
    let active = document.activeElement;
    while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
    while (active) {
      if (element === active || element.contains(active)) return true;
      const root = active.getRootNode();
      active = root instanceof ShadowRoot ? root.host : null;
    }
    return false;
  });
}

// Suite-local: fixed projections and generic embeds own different real Tabs shells.
// Do not fall back to the obsolete Select control or change the shared harness.
async function runtimeControls(previewer: Locator) {
  const fixed = (await previewer.getAttribute('data-projection-mode')) === 'fixed-family';
  return previewer.locator(
    fixed
      ? '[data-projection-scope][data-projection-state="ready"] [data-projection-control="runtime"][data-runtime-tabs]'
      : '[data-runtime-tabs-mount] [data-runtime-tabs-root]'
  );
}

async function runtimeTab(previewer: Locator, runtime: RuntimeId) {
  return (await runtimeControls(previewer)).getByRole('tab', {
    name: RUNTIME_LABELS[runtime],
    exact: true,
  });
}

// This function is serialized into the page; keep every dependency inside it.
function inspectRuntime(
  root: HTMLElement,
  request: { runtime: RuntimeId; label: string; readySelector: string; count: number }
) {
  const { runtime, label, readySelector, count } = request;
  const fixed = root.dataset.projectionMode === 'fixed-family';
  const scopes = root.querySelectorAll<HTMLElement>('[data-projection-scope]');
  const scope = scopes.length === 1 ? scopes[0] : null;
  const hosts = root.querySelectorAll<HTMLElement>('.host');
  const host = hosts.length === 1 ? hosts[0] : null;
  const controls = root.querySelectorAll<HTMLElement>(
    fixed
      ? '[data-projection-scope][data-projection-state="ready"] [data-projection-control="runtime"][data-runtime-tabs]'
      : '[data-runtime-tabs-mount] [data-runtime-tabs-root]'
  );
  const control = controls.length === 1 ? controls[0] : null;
  const selected = control?.querySelectorAll<HTMLElement>('[role="tab"][aria-selected="true"]');
  const tab = selected?.length === 1 ? selected[0] : null;
  const content = fixed ? scope?.querySelector<HTMLElement>('[data-projection-content]') : host;
  const committed = fixed
    ? scope?.dataset.projectionRuntime
    : (
        root as HTMLElement & { __previewer__?: { getCurrentRuntime(): string | null } }
      ).__previewer__?.getCurrentRuntime();
  const surfaces = content?.querySelectorAll<HTMLElement>(
    '.pui-runtime-preview-surface[data-demo-ref="__website_runtime_preview_surface__"]'
  );
  const surface = surfaces?.length === 1 ? surfaces[0] : null;
  const firstRoot = surface?.querySelector<HTMLElement>('[data-pui-root]');
  const unavailable = (element: HTMLElement | null | undefined) => {
    if (!element?.isConnected) return true;
    for (let current: HTMLElement | null = element; current; current = current.parentElement) {
      if (
        current.inert ||
        current.matches(
          '[inert], [hidden], [aria-hidden="true"], [aria-busy="true"], [aria-disabled="true"], [data-previewer-startup-pending], [data-previewer-startup-shell]'
        )
      )
        return true;
      const style = getComputedStyle(current);
      if (style.display === 'none' || style.visibility === 'hidden') return true;
    }
    return false;
  };
  const framework = !firstRoot
    ? null
    : firstRoot.tagName.startsWith('WC-')
      ? 'wc'
      : (firstRoot as HTMLElement & { __vue__?: unknown }).__vue__
        ? 'vue2'
        : host?.hasAttribute('data-v-app') || firstRoot.closest('[data-v-app]')
          ? 'vue'
          : Object.keys(surface!).some((key) => key.startsWith('__reactFiber$'))
            ? 'react'
            : null;
  const targetCount = surface?.querySelectorAll(readySelector).length ?? 0;
  const problems: string[] = [];
  if (!host || !content || controls.length !== 1) problems.push('missing-or-ambiguous-shell');
  if (fixed && (scopes.length !== 1 || scope?.dataset.projectionState !== 'ready'))
    problems.push('projection-not-ready');
  if (!fixed && scopes.length) problems.push('unexpected-fixed-scope');
  if (committed !== runtime) problems.push('runtime-not-committed');
  if (!tab || tab.textContent?.trim() !== label || (!fixed && tab.dataset.runtimeTab !== runtime))
    problems.push('runtime-tab-not-selected');
  if (unavailable(host) || unavailable(control) || unavailable(tab) || unavailable(surface))
    problems.push('shell-not-interactive');
  if (
    root.querySelector(
      '[data-previewer-startup-pending], [data-previewer-startup-shell], .proto-previewer__skeleton'
    )
  )
    problems.push('startup-pending');
  if (
    !surface?.hasAttribute('data-pui-root') ||
    Array.from(content?.querySelectorAll('[data-pui-root]') ?? []).some(
      (element) => element !== surface && !surface?.contains(element)
    )
  )
    problems.push('missing-or-extra-demo-surface');
  if (framework !== runtime) problems.push('wrong-framework');
  if (!firstRoot || targetCount !== count) problems.push('target-controls-not-ready');
  return {
    ready: problems.length === 0,
    shell: fixed ? 'fixed-family' : 'generic',
    committedRuntime: committed ?? null,
    selectedLabel: tab?.textContent?.trim() ?? null,
    surfaceCount: surfaces?.length ?? 0,
    framework,
    targetCount,
    problems,
  };
}

async function waitForRealRuntime(
  previewer: Locator,
  runtime: RuntimeId,
  readySelector: string,
  count: number
) {
  await expect
    .poll(
      () =>
        previewer.evaluate(inspectRuntime, {
          runtime,
          label: RUNTIME_LABELS[runtime],
          readySelector,
          count,
        }),
      { timeout: 20_000 }
    )
    .toMatchObject({ ready: true });
}

async function selectRealRuntime(
  page: Page,
  previewer: Locator,
  runtime: RuntimeId,
  readySelector: string,
  count: number
) {
  const tab = await runtimeTab(previewer, runtime);
  await tab.waitFor({ state: 'visible' });
  if ((await tab.getAttribute('aria-selected')) !== 'true') await tab.click();
  await waitForRealRuntime(previewer, runtime, readySelector, count);
  await expect
    .poll(async () => (await runtimeTab(previewer, runtime)).getAttribute('aria-selected'))
    .toBe('true');
}

