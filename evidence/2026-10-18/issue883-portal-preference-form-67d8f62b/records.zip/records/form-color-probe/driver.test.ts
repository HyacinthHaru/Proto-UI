// Private causal diagnostic. Prepared only; no official-suite/CI admission claim.
import { beforeAll, afterAll, describe, it, expect } from '<PRODUCT_ROOT>/node_modules/vitest/dist/index.js';
import { launchBrowser, type RuntimeId } from '<PRODUCT_ROOT>/apps/www/src/content/docs/zh-cn/browser-harness.ts';
import type { Browser, Page, Locator } from '<PRODUCT_ROOT>/apps/www/node_modules/playwright-core';
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const W = '<PRODUCT_ROOT>';
const HERE = path.dirname(fileURLToPath(import.meta.url));
const OUTPUT = process.env.FORM_COLOR_OUTPUT ?? path.join(HERE, 'execution');
const BASE_URL = process.env.FORM_COLOR_BASE_URL?.replace(/\/$/, '');
const HOST_CLOCK = '2026-10-10T12:00:00Z';
const CONTEXT = { viewport: { width: 1365, height: 1000 }, colorScheme: 'light' as const, locale: 'zh-CN', timezoneId: 'UTC' };
const RUNTIME_LABELS = { wc: 'Web Components', react: 'React', vue: 'Vue', vue2: 'Vue 2' } as const;
const ARTIFACT_ROOT = '<TASK_STATE>/keyboard-owner-p2-20261018T1302Z/preview-0ec/publisher/sites/p921-r39130514939-a1';
const sha = (bytes: Buffer | string) => createHash('sha256').update(bytes).digest('hex');
const json = (name: string, value: unknown) => writeFile(path.join(OUTPUT, name), JSON.stringify(value, null, 2) + '\n');
const errorRecord = (error: unknown) => error instanceof Error
  ? { name: error.name, message: error.message, stack: error.stack }
  : { rawType: typeof error, value: String(error) };
const currentGit = () => ({
  head: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: W, encoding: 'utf8' }).trim(),
  tree: execFileSync('git', ['rev-parse', 'HEAD^{tree}'], { cwd: W, encoding: 'utf8' }).trim(),
  status: execFileSync('git', ['status', '--porcelain'], { cwd: W, encoding: 'utf8' }),
});
let browser: Browser;
let startedAt: string;
let sourceBefore: any;
const cases: any[] = [];
const cleanupErrors: unknown[] = [];
const contexts = new Set<any>();

async function paint(locator: Locator) {
  return locator.evaluate((element) => {
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    const range = document.createRange();
    range.selectNodeContents(element);
    const textRect = range.getBoundingClientRect();
    return {
      rect: {
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
        right: rect.right,
        bottom: rect.bottom,
      },
      textWidth: textRect.width,
      display: style.display,
      visibility: style.visibility,
      color: style.color,
      background: style.backgroundColor,
      shadow: style.boxShadow,
      border: [
        style.borderTopWidth,
        style.borderRightWidth,
        style.borderBottomWidth,
        style.borderLeftWidth,
      ],
      borderColor: style.borderBottomColor,
      radius: style.borderRadius,
      padding: [style.paddingTop, style.paddingRight, style.paddingBottom, style.paddingLeft],
      font: style.font,
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      outline: style.outline,
      opacity: style.opacity,
      clientWidth: element.clientWidth,
      scrollWidth: element.scrollWidth,
      scrollLeft: element.scrollLeft,
      overflowX: style.overflowX,
      ariaSelected: element.getAttribute('aria-selected'),
      ariaChecked: element.getAttribute('aria-checked'),
    };
  });
}

async function hasFocus(locator: Locator) {
  return locator.evaluate((element) => {
    let active = document.activeElement;
    while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
    while (active) {
      if (element === active || element.contains(active)) return true;
      const root = active.getRootNode();
      active = root instanceof ShadowRoot ? root.host : null;
    }
    return false;
  });
}

// Suite-local: fixed projections and generic embeds own different real Tabs shells.
// Do not fall back to the obsolete Select control or change the shared harness.
async function runtimeControls(previewer: Locator) {
  const fixed = (await previewer.getAttribute('data-projection-mode')) === 'fixed-family';
  return previewer.locator(
    fixed
      ? '[data-projection-scope][data-projection-state="ready"] [data-projection-control="runtime"][data-runtime-tabs]'
      : '[data-runtime-tabs-mount] [data-runtime-tabs-root]'
  );
}

async function runtimeTab(previewer: Locator, runtime: RuntimeId) {
  return (await runtimeControls(previewer)).getByRole('tab', {
    name: RUNTIME_LABELS[runtime],
    exact: true,
  });
}

// This function is serialized into the page; keep every dependency inside it.
function inspectRuntime(
  root: HTMLElement,
  request: { runtime: RuntimeId; label: string; readySelector: string; count: number }
) {
  const { runtime, label, readySelector, count } = request;
  const fixed = root.dataset.projectionMode === 'fixed-family';
  const scopes = root.querySelectorAll<HTMLElement>('[data-projection-scope]');
  const scope = scopes.length === 1 ? scopes[0] : null;
  const hosts = root.querySelectorAll<HTMLElement>('.host');
  const host = hosts.length === 1 ? hosts[0] : null;
  const controls = root.querySelectorAll<HTMLElement>(
    fixed
      ? '[data-projection-scope][data-projection-state="ready"] [data-projection-control="runtime"][data-runtime-tabs]'
      : '[data-runtime-tabs-mount] [data-runtime-tabs-root]'
  );
  const control = controls.length === 1 ? controls[0] : null;
  const selected = control?.querySelectorAll<HTMLElement>('[role="tab"][aria-selected="true"]');
  const tab = selected?.length === 1 ? selected[0] : null;
  const content = fixed ? scope?.querySelector<HTMLElement>('[data-projection-content]') : host;
  const committed = fixed
    ? scope?.dataset.projectionRuntime
    : (
        root as HTMLElement & { __previewer__?: { getCurrentRuntime(): string | null } }
      ).__previewer__?.getCurrentRuntime();
  const surfaces = content?.querySelectorAll<HTMLElement>(
    '.pui-runtime-preview-surface[data-demo-ref="__website_runtime_preview_surface__"]'
  );
  const surface = surfaces?.length === 1 ? surfaces[0] : null;
  const firstRoot = surface?.querySelector<HTMLElement>('[data-pui-root]');
  const unavailable = (element: HTMLElement | null | undefined) => {
    if (!element?.isConnected) return true;
    for (let current: HTMLElement | null = element; current; current = current.parentElement) {
      if (
        current.inert ||
        current.matches(
          '[inert], [hidden], [aria-hidden="true"], [aria-busy="true"], [aria-disabled="true"], [data-previewer-startup-pending], [data-previewer-startup-shell]'
        )
      )
        return true;
      const style = getComputedStyle(current);
      if (style.display === 'none' || style.visibility === 'hidden') return true;
    }
    return false;
  };
  const framework = !firstRoot
    ? null
    : firstRoot.tagName.startsWith('WC-')
      ? 'wc'
      : (firstRoot as HTMLElement & { __vue__?: unknown }).__vue__
        ? 'vue2'
        : host?.hasAttribute('data-v-app') || firstRoot.closest('[data-v-app]')
          ? 'vue'
          : Object.keys(surface!).some((key) => key.startsWith('__reactFiber$'))
            ? 'react'
            : null;
  const targetCount = surface?.querySelectorAll(readySelector).length ?? 0;
  const problems: string[] = [];
  if (!host || !content || controls.length !== 1) problems.push('missing-or-ambiguous-shell');
  if (fixed && (scopes.length !== 1 || scope?.dataset.projectionState !== 'ready'))
    problems.push('projection-not-ready');
  if (!fixed && scopes.length) problems.push('unexpected-fixed-scope');
  if (committed !== runtime) problems.push('runtime-not-committed');
  if (!tab || tab.textContent?.trim() !== label || (!fixed && tab.dataset.runtimeTab !== runtime))
    problems.push('runtime-tab-not-selected');
  if (unavailable(host) || unavailable(control) || unavailable(tab) || unavailable(surface))
    problems.push('shell-not-interactive');
  if (
    root.querySelector(
      '[data-previewer-startup-pending], [data-previewer-startup-shell], .proto-previewer__skeleton'
    )
  )
    problems.push('startup-pending');
  if (
    !surface?.hasAttribute('data-pui-root') ||
    Array.from(content?.querySelectorAll('[data-pui-root]') ?? []).some(
      (element) => element !== surface && !surface?.contains(element)
    )
  )
    problems.push('missing-or-extra-demo-surface');
  if (framework !== runtime) problems.push('wrong-framework');
  if (!firstRoot || targetCount !== count) problems.push('target-controls-not-ready');
  return {
    ready: problems.length === 0,
    shell: fixed ? 'fixed-family' : 'generic',
    committedRuntime: committed ?? null,
    selectedLabel: tab?.textContent?.trim() ?? null,
    surfaceCount: surfaces?.length ?? 0,
    framework,
    targetCount,
    problems,
  };
}

async function waitForRealRuntime(
  previewer: Locator,
  runtime: RuntimeId,
  readySelector: string,
  count: number
) {
  await expect
    .poll(
      () =>
        previewer.evaluate(inspectRuntime, {
          runtime,
          label: RUNTIME_LABELS[runtime],
          readySelector,
          count,
        }),
      { timeout: 20_000 }
    )
    .toMatchObject({ ready: true });
}

async function selectRealRuntime(
  page: Page,
  previewer: Locator,
  runtime: RuntimeId,
  readySelector: string,
  count: number
) {
  const tab = await runtimeTab(previewer, runtime);
  await tab.waitFor({ state: 'visible' });
  if ((await tab.getAttribute('aria-selected')) !== 'true') await tab.click();
  await waitForRealRuntime(previewer, runtime, readySelector, count);
  await expect
    .poll(async () => (await runtimeTab(previewer, runtime)).getAttribute('aria-selected'))
    .toBe('true');
}


async function capture(page: Page, previewer: Locator, id: string, stage: string, observation: unknown, captures: any[]) {
  await page.evaluate(() => document.fonts.ready);
  const name = `${id}-${stage}.png`;
  await previewer.screenshot({ path: path.join(OUTPUT, name), animations: 'disabled', timeout: 10_000 });
  const bytes = await readFile(path.join(OUTPUT, name));
  const row = { stage, file: name, sha256: sha(bytes), bytes: bytes.length, observation, capturedAt: new Date().toISOString(), scope: 'Previewer locator region; not whole-page or AT acceptance.' };
  captures.push(row);
  await json(`${id}-${stage}.json`, row);
}

async function collectCausalFacts(page: Page, field: Locator, label: Locator, editor: Locator, error: Locator, token: string) {
  const handles = await Promise.all([field.elementHandle(), label.elementHandle(), editor.elementHandle(), error.elementHandle()]);
  try {
    assert(handles.every(Boolean), 'All four original journey targets must still exist.');
    return await page.evaluate(({ field, label, editor, error, token }: any) => {
      const info = (el: HTMLElement) => {
        const style = getComputedStyle(el); const rect = el.getBoundingClientRect();
        return { tag: el.tagName, id: el.id, className: el.className, connected: el.isConnected,
          attributes: Object.fromEntries(Array.from(el.attributes).map((a: Attr) => [a.name, a.value])),
          color: style.color, backgroundColor: style.backgroundColor, display: style.display, visibility: style.visibility,
          opacity: style.opacity, transition: style.transition, font: style.font,
          destructive: style.getPropertyValue('--pui-destructive'), destructiveInk: style.getPropertyValue('--pui-destructive-ink'),
          foreground: style.getPropertyValue('--pui-foreground'), inlineColor: el.style.color,
          rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height, right: rect.right, bottom: rect.bottom } };
      };
      const ancestors: HTMLElement[] = [];
      for (let node = label.parentElement; node; node = node.parentElement) ancestors.push(node);
      const targets: Record<string, HTMLElement> = { field, label, editor, error };
      ancestors.forEach((el, index) => { targets[`labelAncestor${index}`] = el; });
      const decodeCss = (value: string) => value.replace(/\\([\da-f]{1,6})\s?|\\(.)/gi,
        (_all, hex, simple) => hex ? String.fromCodePoint(parseInt(hex, 16)) : simple);
      const selectorTokens = (selector: string) => Array.from(selector.matchAll(/\[data-pui-style\s*~=\s*(?:"((?:\\.|[^"\\])*)"|'((?:\\.|[^'\\])*)'|([^\]\s]+))\s*\]/g),
        (m) => decodeCss(m[1] ?? m[2] ?? m[3] ?? ''));
      const matching = (selector: string) => Object.fromEntries(Object.entries(targets).map(([name, el]) => {
        try { return [name, { matches: el.matches(selector) }]; }
        catch (failure) { return [name, { unavailable: String(failure) }]; }
      }));
      const sheets: any[] = [], conditions: any[] = [], plainInk: any[] = [], declarations: any[] = [], unreadable: any[] = [];
      const visited = new Set<CSSStyleSheet>(); let rulesRead = 0;
      const readSheet = (sheet: CSSStyleSheet, ancestry: unknown[]) => {
        if (visited.has(sheet)) return; visited.add(sheet);
        const sheetInfo = { href: sheet.href, disabled: sheet.disabled, media: sheet.media.mediaText,
          ownerTag: (sheet.ownerNode as Element | null)?.nodeName ?? null };
        sheets.push(sheetInfo);
        let list: CSSRuleList;
        try { list = sheet.cssRules; }
        catch (failure) { unreadable.push({ sheet: sheetInfo, error: String(failure) }); return; }
        walk(list, [...ancestry, sheetInfo]);
      };
      const walk = (rules: CSSRuleList, ancestry: unknown[]) => {
        for (const rule of Array.from(rules)) {
          rulesRead++;
          if (rule instanceof CSSStyleRule) {
            const tokens = selectorTokens(rule.selectorText);
            const matches = matching(rule.selectorText);
            const row = { selector: rule.selectorText, tokens, cssText: rule.style.cssText, ancestry, matches };
            if (tokens.includes(token)) conditions.push(row);
            if (tokens.includes(token.split(':').at(-1)!)) plainInk.push(row);
            const props = ['color', '--pui-destructive', '--pui-destructive-ink', '--pui-foreground'];
            if (props.some((p) => rule.style.getPropertyValue(p)) && Object.values(matches).some((v: any) => v.matches))
              declarations.push({ ...row, properties: Object.fromEntries(props.map((p) => [p, { value: rule.style.getPropertyValue(p), priority: rule.style.getPropertyPriority(p) }])) });
          }
          if (rule instanceof CSSImportRule) {
            if (rule.styleSheet) readSheet(rule.styleSheet, [...ancestry, { importHref: rule.href, media: rule.media.mediaText }]);
            else unreadable.push({ importHref: rule.href, error: 'styleSheet unavailable' });
          } else if ('cssRules' in rule) {
            const group: any = { type: rule.constructor.name };
            if ('conditionText' in rule) group.conditionText = rule.conditionText;
            if ('name' in rule) group.name = rule.name;
            if (rule instanceof CSSMediaRule) group.active = matchMedia(rule.conditionText).matches;
            if (typeof CSSSupportsRule !== 'undefined' && rule instanceof CSSSupportsRule) group.active = CSS.supports(rule.conditionText);
            try { walk((rule as CSSGroupingRule).cssRules, [...ancestry, group]); }
            catch (failure) { unreadable.push({ ancestry, group, error: String(failure) }); }
          }
        }
      };
      for (const sheet of Array.from(document.styleSheets)) readSheet(sheet, []);
      for (const sheet of document.adoptedStyleSheets) readSheet(sheet, [{ adopted: true }]);
      return { sampledPerformanceTime: performance.now(), fixedPageDate: new Date().toISOString(),
        theme: { className: document.documentElement.className, dataTheme: document.documentElement.dataset.theme },
        environment: { viewport: { width: innerWidth, height: innerHeight }, locale: navigator.language,
          resolvedLocale: new Intl.DateTimeFormat().resolvedOptions().locale, timeZone: new Intl.DateTimeFormat().resolvedOptions().timeZone, devicePixelRatio },
        field: info(field), label: info(label), editor: info(editor), error: info(error),
        labelParentIsCapturedField: label.parentElement === field,
        labelAncestorChain: ancestors.map(info),
        activeElement: document.activeElement instanceof HTMLElement ? info(document.activeElement) : null,
        targetToken: token, fieldHasInvalidAttribute: field.hasAttribute('data-invalid'),
        fieldHasExactTargetToken: (field.getAttribute('data-pui-style') ?? '').split(/\s+/).includes(token),
        css: { sheets, rulesRead, exactConditionalRules: conditions, plainErrorInkRules: plainInk,
          matchingColorDeclarations: declarations, unreadable,
          boundary: 'Matching declarations and grouping conditions only; this is not a hand-implemented cascade winner or a substitute for computed color.' } };
    }, { field: handles[0], label: handles[1], editor: handles[2], error: handles[3], token });
  } finally { for (const handle of handles) await handle?.dispose(); }
}

async function runJourney(family: 'shadcn' | 'brutalist', mode: 'color' | 'continuation') {
  const id = `${family}-${mode}`;
  const row: any = { id, family, mode, startedAt: new Date().toISOString(), source: 'Exact 0ec official artifact, not current source execution',
    contextOptions: CONTEXT, fixedClock: HOST_CLOCK, pageErrors: [], consoleErrors: [], blockedRequests: [], diagnosticErrors: [], captures: [],
    assertionsPassed: [], observedColorFailure: null, cleanupErrors: [], contextClosed: false,
    claim: mode === 'color' ? 'Private preservation of original pre-color and color predicates; not the official guarded suite.' : 'Independent continuation diagnostic; never counted as an original-suite pass.' };
  const context = await browser.newContext(CONTEXT); contexts.add(context);
  let page: Page | undefined, previewer: Locator | undefined, primary: unknown;
  let originalColorFailure: unknown;
  try {
    page = await context.newPage(); page.setDefaultTimeout(15_000);
    page.on('pageerror', (e) => row.pageErrors.push({ name: e.name, message: e.message, stack: e.stack }));
    page.on('console', (m) => { if (m.type() === 'error') row.consoleErrors.push({ text: m.text(), location: m.location() }); });
    await context.route('**/*', (request) => {
      const url = new URL(request.request().url());
      if (['http:', 'https:'].includes(url.protocol) && url.origin !== new URL(BASE_URL!).origin) {
        row.blockedRequests.push(`${url.origin}${url.pathname}`); return request.abort();
      }
      return request.continue();
    });
    await page.clock.setFixedTime(HOST_CLOCK);
    const route = `/en/ui-libraries/${family}/form/`;
    const response = await page.goto(`${BASE_URL}${route}`, { waitUntil: 'networkidle' });
    expect(response?.status()).toBe(200);
    const received = await response!.body(); const expected = await readFile(path.join(ARTIFACT_ROOT, route.slice(1), 'index.html'));
    expect(sha(received)).toBe(sha(expected));
    row.documentBinding = { route, responseURL: response!.url(), bytes: received.length, responseSHA256: sha(received), admittedMemberSHA256: sha(expected), equal: true };
    previewer = page.locator('[data-previewer-id]').first(); await previewer.waitFor({ state: 'visible' });
    await selectRealRuntime(page, previewer, 'react', '[data-demo-ref="form"]', 1);
    row.runtime = await previewer.evaluate(inspectRuntime, { runtime: 'react', label: 'React', readySelector: '[data-demo-ref="form"]', count: 1 });
    const form = previewer.locator('[data-demo-ref="form"]');
    const editor = form.locator('input').first(); const label = form.getByText('displayName', { exact: true }); const field = label.locator('..');
    const submit = form.getByRole('button', { name: /Validate and submit/ });
    const rest = { editor: await paint(editor), label: await paint(label) }; row.rest = rest;
    await capture(page, previewer, id, 'rest', rest, row.captures);
    await submit.click();
    await expect.poll(() => editor.getAttribute('aria-invalid')).toBe('true'); row.assertionsPassed.push('editor-invalid');
    await expect.poll(() => hasFocus(editor)).toBe(true); row.assertionsPassed.push('first-editor-focus');
    const errorId = await editor.getAttribute('aria-errormessage'); expect(errorId).toBeTruthy();
    const error = form.locator(`[id=${JSON.stringify(errorId)}]`);
    expect(await error.isVisible()).toBe(true); expect(await error.textContent()).toMatch(/required/i);
    expect(await editor.getAttribute('aria-labelledby')).toBe(await label.getAttribute('id'));
    expect(await previewer.locator('[data-demo-ref="status"]').textContent()).not.toContain('"displayName"');
    row.assertionsPassed.push('visible-required-error', 'error-idref', 'label-idref', 'no-submitted-displayName');
    const invalid = { field: await paint(field), label: await paint(label), editor: await paint(editor), error: await paint(error), errorText: await error.textContent(), errorId, firstEditorFocused: await hasFocus(editor) };
    row.invalid = invalid;
    await capture(page, previewer, id, 'invalid-submit-first-focus', invalid, row.captures);
    row.colorComparisons = { labelEqualsField: invalid.label.color === invalid.field.color, labelEqualsError: invalid.label.color === invalid.error.color, labelDiffersFromRest: invalid.label.color !== rest.label.color, editorEqualsRest: invalid.editor.color === rest.editor.color };
    if (mode === 'color') {
      try {
        expect(invalid.label.color).toBe(invalid.field.color); row.assertionsPassed.push('original596');
        expect(invalid.label.color).toBe(invalid.error.color); row.assertionsPassed.push('original597');
        expect(invalid.label.color).not.toBe(rest.label.color); row.assertionsPassed.push('original598');
        expect(invalid.editor.color).toBe(rest.editor.color); row.assertionsPassed.push('original599');
      } catch (failure) { originalColorFailure = failure; row.observedColorFailure = errorRecord(failure); }
    }
    const token = family === 'shadcn' ? 'data-[invalid]:text-destructive' : 'data-[invalid]:text-destructive-ink';
    try {
      row.causalFacts = await collectCausalFacts(page, field, label, editor, error, token);
      row.causalTiming = mode === 'color' ? 'After the original color assertions (including any failure), not their earlier paint sampling time.' : 'After invalid paint capture in the independent continuation context.';
      await json(`${id}-causal-facts.json`, row.causalFacts);
    } catch (failure) { row.diagnosticErrors.push({ stage: 'causal-facts', ...errorRecord(failure) }); }
    if (originalColorFailure) throw originalColorFailure;
    if (mode === 'continuation') {
      await editor.fill('Finf sample'); await submit.click();
      await expect.poll(() => editor.getAttribute('aria-invalid')).not.toBe('true');
      await expect.poll(() => editor.getAttribute('aria-errormessage')).toBe(null);
      await expect.poll(() => previewer!.locator('[data-demo-ref="status"]').textContent()).toContain('"displayName":"Finf sample"');
      expect((await paint(label)).color).toBe(rest.label.color);
      row.assertionsPassed.push('corrected-invalid-cleared', 'corrected-error-relation-cleared', 'corrected-submit-status', 'corrected-label-restored');
      row.correctedStatus = await previewer.locator('[data-demo-ref="status"]').textContent();
      await capture(page, previewer, id, 'corrected-submit', { editor: await paint(editor), label: await paint(label), value: await editor.inputValue(), status: row.correctedStatus }, row.captures);
      await editor.fill('Finf sample'); expect(await editor.inputValue()).toBe('Finf sample');
      await form.getByRole('button', { name: /Reset values/ }).click();
      await expect.poll(() => editor.inputValue()).toBe(''); row.assertionsPassed.push('reset-default-value');
      await capture(page, previewer, id, 'reset', { value: await editor.inputValue() }, row.captures);
      await editor.fill('Finf sample');
      const email = form.getByRole('checkbox', { name: 'Email · 邮件', exact: true }); const sms = form.getByRole('checkbox', { name: 'SMS · 短信', exact: true });
      await sms.click(); await expect.poll(() => sms.getAttribute('aria-checked')).toBe('true');
      const rows = { email: await paint(email), sms: await paint(sms) };
      await capture(page, previewer, id, 'edited', { editedValue: await editor.inputValue(), resetObserved: true, rows }, row.captures);
      for (const item of Object.values(rows)) expect(item.border).toEqual(['0px', '0px', '0px', '0px']);
      row.assertionsPassed.push('edited-checkbox', 'original-row-borders');
    }
    expect(row.pageErrors).toEqual([]);
  } catch (failure) { primary = failure; row.error = errorRecord(failure); }
  finally {
    if (page && previewer) {
      for (const [kind, collect] of [['dom', () => previewer!.evaluate((el) => el.outerHTML)], ['aria', () => previewer!.ariaSnapshot()]] as const) {
        try { await writeFile(path.join(OUTPUT, `${id}-terminal-${kind}.txt`), await collect()); }
        catch (failure) { row.diagnosticErrors.push({ stage: kind, ...errorRecord(failure) }); }
      }
      try { await capture(page, previewer, id, primary ? 'failed' : 'final', { terminal: true, timing: 'After any earlier failure; not assertion-time pixels.' }, row.captures); }
      catch (failure) { row.diagnosticErrors.push({ stage: 'terminal-capture', ...errorRecord(failure) }); }
      try { row.environment = await page.evaluate(() => ({ locale: navigator.language, resolvedLocale: new Intl.DateTimeFormat().resolvedOptions().locale, timeZone: new Intl.DateTimeFormat().resolvedOptions().timeZone, now: new Date().toISOString(), viewport: { width: innerWidth, height: innerHeight }, devicePixelRatio, theme: document.documentElement.dataset.theme, htmlClass: document.documentElement.className })); }
      catch (failure) { row.diagnosticErrors.push({ stage: 'environment', ...errorRecord(failure) }); }
    }
    try { await context.close(); row.contextClosed = true; contexts.delete(context); }
    catch (failure) { row.cleanupErrors.push(errorRecord(failure)); if (!primary) primary = failure; }
    row.endedAt = new Date().toISOString(); row.result = primary ? (originalColorFailure === primary ? 'observed-color-failure' : 'failed') : 'passed';
    cases.push(row); await json(`${id}.json`, row);
  }
  if (primary) throw primary;
}

beforeAll(async () => {
  startedAt = new Date().toISOString(); await mkdir(OUTPUT, { recursive: true });
  assert(BASE_URL, 'FORM_COLOR_BASE_URL is required; the driver never starts/builds a server.');
  assert(['127.0.0.1', 'localhost', '[::1]'].includes(new URL(BASE_URL).hostname), 'Only the explicitly supplied loopback artifact server is allowed.');
  assert.notEqual(process.env.GITHUB_ACTIONS, 'true', 'This is a private local diagnostic, not the official guarded workflow.');
  const preparation = JSON.parse(await readFile(path.join(HERE, 'preparation.json'), 'utf8'));
  for (const item of preparation.frozenFiles) expect(sha(await readFile(item.path))).toBe(item.sha256);
  sourceBefore = { git: currentGit(), driverSHA256: sha(await readFile(fileURLToPath(import.meta.url))), preparationSHA256: sha(await readFile(path.join(HERE, 'preparation.json'))), declaredInputs: preparation.frozenFiles };
  await json('source-before.json', sourceBefore);
  browser = await launchBrowser();
  await json('started.json', { startedAt, baseURL: BASE_URL, browserVersion: browser.version(), node: process.version, platform: process.platform, architecture: process.arch, context: CONTEXT, fixedClock: HOST_CLOCK, officialSuiteImported: false, serverOwnedByDriver: false, harnessProfile: 'Existing launchBrowser(): headless, --disable-dev-shm-usage, --no-sandbox. Distinct from official chromiumSandbox:true.' });
}, 30_000);

afterAll(async () => {
  for (const context of contexts) {
    try { await context.close(); contexts.delete(context); }
    catch (failure) { cleanupErrors.push({ contextClose: errorRecord(failure) }); }
  }
  let browserClosed = false;
  try { await browser?.close(); browserClosed = Boolean(browser); }
  catch (failure) { cleanupErrors.push({ browserClose: errorRecord(failure) }); }
  const endedAt = new Date().toISOString();
  await mkdir(OUTPUT, { recursive: true });
  await json('run-receipt.json', { startedAt, endedAt, servedHead: '0ecfe2cb76236aa37fee78730423a72a0ddebb7c', run: 39130514939, artifact: 12137477831, baseURL: BASE_URL, sourceBefore, gitAfter: currentGit(), driverSHA256After: sha(await readFile(fileURLToPath(import.meta.url))), cases: cases.map(({ id, result, observedColorFailure, contextClosed }) => ({ id, result, observedColorFailure, contextClosed })), collectedExpected: 4, completedCases: cases.length, remainingContexts: contexts.size, browserClosed, cleanupErrors, serverOwnedByDriver: false, serverCleanup: 'External artifact server remains root-owned; this driver does not stop it.', boundary: 'Private causal/continuation diagnostics; original color failures remain failures. No official-suite, all-Form, remote-host or AT acceptance.' });
  expect(cleanupErrors).toEqual([]);
}, 30_000);

describe.sequential('Private exact-0ec Form color causal and separate continuation observations', () => {
  for (const family of ['shadcn', 'brutalist'] as const) {
    it(`${family}: retain original invalid color predicates`, () => runJourney(family, 'color'), 120_000);
    it(`${family}: independent continuation after invalid capture`, () => runJourney(family, 'continuation'), 120_000);
  }
});
