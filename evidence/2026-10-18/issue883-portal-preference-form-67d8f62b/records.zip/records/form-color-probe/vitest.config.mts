import { defineConfig } from '<PRODUCT_ROOT>/node_modules/vitest/dist/config.js';
export default defineConfig({
  root: "<PRODUCT_ROOT>",
  test: {
    include: ["<R11>/form-color-probe/driver.test.ts"],
    environment: 'node',
    maxWorkers: 1,
    minWorkers: 1,
    fileParallelism: false,
    pool: 'forks',
    testTimeout: 120000,
    hookTimeout: 30000,
  },
});
