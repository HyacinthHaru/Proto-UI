import ts from '<PRODUCT_ROOT>/node_modules/typescript/lib/typescript.js';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const cwd = '<PRODUCT_ROOT>';
const head = '67d8f62b4bb2ea4048638b524ab7910ed98604c5';
const base = 'f30a3a1674d89b1600ab0be6af8dcf2d35152e62';
const ownerHead = '0ecfe2cb76236aa37fee78730423a72a0ddebb7c';
const p = 'apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts';
const get = (ref, path) => execFileSync('git', ['show', `${ref}:${path}`], { cwd, encoding: 'utf8' });
const sha = (s) => createHash('sha256').update(s).digest('hex');
function root(n) {
  while (n) {
    if (ts.isIdentifier(n)) return n.text;
    if (ts.isCallExpression(n) || ts.isPropertyAccessExpression(n) || ts.isElementAccessExpression(n) || ts.isNonNullExpression(n)) n = n.expression;
    else return null;
  }
  return null;
}
function matchers(source) {
  const sf = ts.createSourceFile(p, source, ts.ScriptTarget.Latest, true);
  assert.equal(sf.parseDiagnostics.length, 0);
  const result = [];
  function visit(n) {
    if (ts.isCallExpression(n) && ts.isPropertyAccessExpression(n.expression) && /^to[A-Z]/.test(n.expression.name.text) && root(n) === 'expect') result.push(n.getText(sf));
    ts.forEachChild(n, visit);
  }
  visit(sf);
  return result;
}
const old = get(base, p), current = get(head, p), a = matchers(old), b = matchers(current);
assert.equal(a.length, 171); assert.deepEqual(a, b);
const originalOwner = matchers(get(ownerHead, p)); assert.deepEqual(originalOwner, b);
const vuePath = 'packages/adapters/vue2/test/select.test.ts';
const vueOld = get(base, vuePath), vueCurrent = get(head, vuePath);
const prefix = vueCurrent.split("\nit('returns Shadcn Trigger focus", 1)[0].replace("import * as shadcn from '../../../prototypes/shadcn/src/select';\n", '');
assert.equal(prefix.trimEnd(), vueOld.trimEnd());
const vueOriginalMatchers = matchers(vueOld), vueCurrentMatchers = matchers(vueCurrent);
assert.deepEqual(vueCurrentMatchers.slice(0, vueOriginalMatchers.length), vueOriginalMatchers);
const ownerPaths = ['packages/adapters/base/src/events/web-event-router.ts', 'packages/adapters/base/test/event-router-work.test.ts'];
const preservedOwner = ownerPaths.map((path) => {
  const before = get(ownerHead, path), after = get(head, path); assert.equal(before, after);
  return { path, originalHead: ownerHead, currentHead: head, sha256: sha(after), byteEqual: true };
});
const result = { method: 'Read-only TypeScript AST/exact Git source comparison, no tests', head, base, homepage: { priorOwnerHead: ownerHead, oldSHA256: sha(old), currentSHA256: sha(current), matcherChains: b.length, orderedMatcherChainsByteEqual: true, orderedMatcherChainArraySHA256: sha(JSON.stringify(b)) }, vue2: { originalSHA256: sha(vueOld), currentSHA256: sha(vueCurrent), originalWholeThreeCasePrefixPreservedExceptNewImport: true, originalMatcherCount: vueOriginalMatchers.length, currentMatcherCount: vueCurrentMatchers.length, originalMatchersPrefixEqual: true }, keyboardOwner: preservedOwner };
writeFileSync(new URL('./assertion-binding.json', import.meta.url), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
