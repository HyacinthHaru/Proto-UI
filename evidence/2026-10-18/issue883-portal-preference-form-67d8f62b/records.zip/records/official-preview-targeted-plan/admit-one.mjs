// Prepared private single-target admission. This is not the unfiltered publisher CLI.
import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile, readdir, stat, lstat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { githubClient } from '<PRODUCT_ROOT>/scripts/preview/publish.mjs';
import { resolvePreviewBuild, admitPreviewBuild } from '<PRODUCT_ROOT>/scripts/preview/build-admission.mjs';
import { downloadVerifiedArtifact, materializeBoundedZip, extractBoundedZip } from '<PRODUCT_ROOT>/scripts/preview/extract-artifact.mjs';
import { sanitizePreviewTree, PREVIEW_LIMITS } from '<PRODUCT_ROOT>/scripts/preview/sanitize-tree.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const tuplePath = path.resolve(process.argv[2] ?? '');
assert(path.dirname(tuplePath) === here, 'The frozen target tuple must be in this private plan directory.');
const target = JSON.parse(await readFile(tuplePath, 'utf8'));
assert.equal(target.status, 'frozen-final-target');
assert.equal(target.pr, 921);
assert(/^[0-9a-f]{40}$/.test(target.head) && /^[0-9a-f]{40}$/.test(target.tree));
for (const key of ['run', 'job', 'attempt', 'artifact', 'bytes']) assert(Number.isSafeInteger(target[key]) && target[key] > 0, key);
assert(/^[0-9a-f]{64}$/.test(target.sha256));
const output = path.resolve(process.argv[3] ?? '');
assert(output === path.join(here, `execution-${target.head.slice(0, 12)}-r${target.run}`), 'Use only the exact-target execution directory.');
assert.equal(process.env.PUI_PREVIEW_NATIVE_LOCK_HELD, '1', 'The parent must hold its actual fcntl lock for this child lifetime.');
assert.notEqual(process.env.NODE_TLS_REJECT_UNAUTHORIZED, '0', 'TLS verification must remain enabled.');
assert.equal(PREVIEW_LIMITS.maxExpandedBytes, 100 * 1024 * 1024);
const expected = Object.freeze({ pr: String(target.pr), head_sha: target.head, run_id: String(target.run), run_attempt: String(target.attempt), artifact_id: String(target.artifact) });
const expectedBytes = target.bytes;
const expectedSHA256 = target.sha256;
const expectedName = `intranet-preview-${target.pr}-${target.head}-${target.attempt}`;
const jobId = target.job;
const startedAt = new Date().toISOString();
const startMs = Date.now();
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const save = (name, value) => writeFile(path.join(output, name), JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const gh = '<HOMEBREW>/bin/gh';
const api = endpoint => JSON.parse(execFileSync(gh, ['api', endpoint], { encoding: 'utf8', timeout: 30000, maxBuffer: 8 * 1024 * 1024 }));
let downloadCalls = 0;
try {
  const token = execFileSync(gh, ['auth', 'token', '--hostname', 'github.com'], { encoding: 'utf8', timeout: 20000, maxBuffer: 16384 }).trim();
  // Token is memory-only: never write it, put it in argv, or forward it to a blob host.
  const signal = AbortSignal.timeout(240000);
  const github = githubClient(token, signal);
  const context = { repo: { owner: 'Proto-UI', repo: 'Proto-UI' } };
  const resolved = await resolvePreviewBuild({ github, context, runId: Number(expected.run_id), kind: 'success', expected });
  await save('resolved-live-binding.json', { at: new Date().toISOString(), ...resolved });
  const job = api(`repos/Proto-UI/Proto-UI/actions/jobs/${jobId}`);
  assert.equal(job.run_id, Number(expected.run_id));
  assert.equal(job.status, 'completed'); assert.equal(job.conclusion, 'success');
  await save('producer-job.json', job);
  const artifact = api(`repos/Proto-UI/Proto-UI/actions/artifacts/${expected.artifact_id}`);
  assert.equal(artifact.name, expectedName); assert.equal(artifact.size_in_bytes, expectedBytes);
  assert.equal(artifact.digest, `sha256:${expectedSHA256}`); assert.equal(artifact.expired, false);
  assert.equal(artifact.workflow_run.id, Number(expected.run_id));
  await save('artifact-metadata.json', artifact);
  // Use the real, unfiltered recency guard. Other metadata may be read to rule
  // out a newer eligible build; no other PR artifact is downloaded or materialized.
  const before = await admitPreviewBuild({ github, context, runId: Number(expected.run_id), kind: 'success', expected: resolved.binding });
  await save('pre-download-admission.json', { at: new Date().toISOString(), binding: before });
  const downloadStarted = new Date().toISOString();
  downloadCalls++;
  const bytes = await downloadVerifiedArtifact({
    token, repository: 'Proto-UI/Proto-UI', artifactId: Number(expected.artifact_id), runId: Number(expected.run_id),
    fetchImpl: (url, init) => fetch(url, { ...init, signal: AbortSignal.any([signal, ...(init?.signal ? [init.signal] : [])]) }),
  });
  assert.equal(bytes.length, expectedBytes); assert.equal(sha(bytes), expectedSHA256);
  await writeFile(path.join(output, 'actual-artifact.zip'), bytes, { flag: 'wx', mode: 0o600 });
  await save('artifact-download-receipt.json', { start: downloadStarted, end: new Date().toISOString(), expected, bytes: bytes.length, sha256: sha(bytes), downloadCalls, source: 'One actual downloadVerifiedArtifact return Buffer, saved before passing that same Buffer to admission materialization. No second download for comparison.' });
  const extracted = path.join(output, 'extracted');
  const tree = path.join(output, 'site');
  const extraction = await materializeBoundedZip(bytes, extracted);
  const sanitation = await sanitizePreviewTree({ source: extracted, output: tree });
  const index = await stat(path.join(tree, 'index.html')); assert(index.isFile() && index.size > 0);
  const members = extractBoundedZip(bytes);
  async function names(dir, prefix = '') {
    const result = [];
    for (const entry of await readdir(dir, { withFileTypes: true })) {
      const name = prefix ? `${prefix}/${entry.name}` : entry.name;
      const file = path.join(dir, entry.name), info = await lstat(file);
      assert(!info.isSymbolicLink());
      if (info.isDirectory()) result.push(...await names(file, name));
      else { assert(info.isFile()); result.push(name); }
    }
    return result.sort();
  }
  const actual = await names(tree), listed = [...members.keys()].sort();
  assert.deepEqual(actual, listed);
  const rows = [];
  for (const name of listed) {
    const raw = members.get(name), local = await readFile(path.join(tree, ...name.split('/')));
    assert.equal(local.length, raw.length, name); assert.equal(sha(local), sha(raw), name);
    rows.push({ path: name, bytes: raw.length, rawSHA256: sha(raw), sanitizedSHA256: sha(local), equal: true });
  }
  await save('all-member-preservation.json', { at: new Date().toISOString(), expected, archiveSHA256: sha(bytes), files: rows.length, html: rows.filter(row => row.path.endsWith('.html')).length, expandedBytes: rows.reduce((n, row) => n + row.bytes, 0), memberNamesExact: true, allMemberBytesEqual: true, extraction, sanitation, limitsUnchanged: PREVIEW_LIMITS, rows });
  const after = await admitPreviewBuild({ github, context, runId: Number(expected.run_id), kind: 'success', expected: resolved.binding });
  assert(Date.now() - startMs <= 240000, 'The admission/materialization exceeded the existing freshness window.');
  await save('post-materialization-admission.json', { at: new Date().toISOString(), binding: after });
  await save('admission-receipt.json', { start: startedAt, end: new Date().toISOString(), status: 'admitted', readyForLocalNativeControl: true, binding: after, directory: tree, downloadCalls, archiveBytes: bytes.length, archiveSHA256: sha(bytes), sourceHead: expected.head_sha, sourceTree: target.tree, publisherCLIExecuted: false, globalPublisherCurrentJSONCreated: false, publicationScope: 'Only PR921 exact head/run/attempt/artifact admitted and materialized under the actual local lock, using the existing real guard/downloader/extractor/sanitizer. This is an embedded single-target admission, not the unfiltered publish CLI or remote deployment.' });
  console.log(JSON.stringify({ status: 'admitted', binding: after, directory: tree, downloadCalls, files: rows.length, html: rows.filter(row => row.path.endsWith('.html')).length, expandedBytes: rows.reduce((n, row) => n + row.bytes, 0), sha256: sha(bytes), publisherCLIExecuted: false }));
} catch (error) {
  await save('admission-failure.json', { start: startedAt, end: new Date().toISOString(), expected, downloadCalls, error: { name: error?.name, message: String(error?.message ?? error), stack: error?.stack }, readyForLocalNativeControl: false }).catch(() => {});
  console.error('Single-target preview admission failed; preserved local failure receipt.');
  process.exitCode = 1;
}
