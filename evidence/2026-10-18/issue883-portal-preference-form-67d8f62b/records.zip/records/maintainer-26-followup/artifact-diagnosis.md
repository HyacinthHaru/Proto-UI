# Official26 Brutalist failure — actual artifact diagnosis

**The original1s failure remains a failure. Its first divergence is now exactly located at family-commit, before the breakpoint/owner/portal loops.** It is not yet evidence of owner loss or a persistent mixed generation, and it is not labelled a new regression or flaky event.

The original test selected Brutalist, then its Header data-family poll failed within1000ms. Both the failure and lifecycle JSON contain empty records/ringFailures arrays. The family-ready call and per-runtime retention samples had not been reached.

The subsequent failure-catch evaluation already sees Header and showcase ready on Brutalist/WC generation2. The controller snapshot agrees; all12 observed Header generation records are connected and active2 with distinct owner names. The current WC-Brutalist family Trigger is connected, shows Brutalist, and no current related family Portal resolves. Page and console error arrays are empty. These facts show the wanted state at a later sample, not its timing during the rejected poll. No last poll value, RPC interval, actual commit time or precise rejection timestamp was saved.

The recorded capturedAt16:12:18.096Z is assigned by save after page.evaluate and before the PNG. The PNG is later again. I actually viewed the390×844 image: the disclosed blue Brutalist panel and Web Components/Brutalist values are visible, followed by the upper gallery; there is no visible error banner or open family options popup. This single viewport crop is not an assertion-time frame, wholepage/AT/focus/lease acceptance.

Root's one verified artifact12142609776 is58,258,583bytes with SHA2560e72f57125138f8b1a00b10336b13556723f869dc72f1900b6e42057dcbca343. I read its230-member central directory and independently compared the four selected JSON/PNG/source member bytes to the retained archive. Both JSONs and source-sha.txt bind clean synthetic checkout0a36d014… with treeebe62d… equal to26d4245. No second download occurred.

No C production patch is justified from this snapshot alone. The smallest proposed next discriminator would time only each original getAttribute call/result/exception and the rejection, keeping the1000ms predicate and inputs unchanged; optionally pair it with a read-only attribute observation. No such new observation or test-source edit was performed. Do not add a wait, backfill the later ready state, or use later67 success as a causal explanation of this26 result.

Parent-reported new67 fullnative120/120 and officialartifact3/3 remain separate unreviewed later-source facts in this report; current67CI is not declared green. Human-assisted/current-user, unassessed, partial/ABSTAIN. Exact hashes and source/timing limits are in artifact-diagnosis.json.
