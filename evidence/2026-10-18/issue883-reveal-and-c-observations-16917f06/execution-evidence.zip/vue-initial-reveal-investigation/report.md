唯一Vue initial-dark诊断真实1fail/7filtered，16:43:04.251–16:43:08.865 UTC。原12rAF/输入/断言/30s不变，只加同步transition/getAnimations字段以及原断言失败后DOM/AX/PNG。执行后两临时文件已还原：test为两行Switch candidate8a991624，fixture原main；index6852，PG无剩余。

首个记录到的可见Button样本alpha0.0913383、pending=false、revealing=false；真实CSSTransition background-color从rgba(0,0,0,0)到目标alpha0.2，duration150ms/currentTime49.968ms/running，缓动progress×0.2与实际alpha吻合；tokens已是bg-destructive/20，inlineBackground为空。另有visibility hidden→visible与padding等transition。这不是猜测light0.1→dark0.2。Button/outline/probe记录11个可见样本，其他3组12；原采样回调总数12，未新增rAF。

这支持Vue首次presentation/reveal缺口，现有React共享revealing guard是有据的最小方向，不是修改Button配方或放宽首帧断言。同步观察存在少量额外读取开销，未重跑求红。

唯一failure PNG已实际查看，1100×1400后置dark界面可读、无明显裁切；它已是后置稳定画面，不补造首帧像素。DOM和真实CDP AX亦在断言失败后采集，均不是AT验收。原失败与所有raw保持。partial/ABSTAIN，无外写/生产修复。
