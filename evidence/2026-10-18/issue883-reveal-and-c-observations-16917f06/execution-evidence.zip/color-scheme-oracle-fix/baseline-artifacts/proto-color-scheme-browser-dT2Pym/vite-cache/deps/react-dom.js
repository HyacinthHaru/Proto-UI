import {
  require_react_dom
} from "./chunk-WDOFVE2G.js";
import "./chunk-MZYAG665.js";
import "./chunk-BUSYA2B4.js";
export default require_react_dom();
