准确main042原8casebaseline已完成，实际exit1、8fail、0pass/0filtered；没有预先修正任何期待。窗口2026-10-17T16:32:17.846860+00:00—2026-10-17T16:32:35.718460+00:00，Nodev24.21.0 / pnpm10.32.1 / Chrome155.0.8059.80，macOS。11328tracked前后逐字一致、clean。runner进程组已结束，native槽已释放。

首分歧分三组：

- 四个lifetime都在原182行Switch alpha0.075等待失败，原cause是实际0.12。后面的stats/物理identity/typedraft/lease/remount/Transition/dispose断言尚未执行。
- WC/React/Vue2 initial-dark都在Switch旧期待失败，原12可见样本均0.12、pendingfalse；没有用未来绿结果覆盖它们。
- Vue initial-dark先在Button失败。Button/Probe11可见帧中前8alpha为.00653811、.035057、.0915973、.139212、.167438、.184111、.193748、.198594，后3为.2；Outline同样前8中间值后3为.045。全部pendingfalse且首token已正确dark。这是当前main真实初始可见过程，不是旧Linux截图或推测；仍不能仅凭终态认定CSS动画准入或C reveal根因。

原测试自带12JSON完整保留，pageerrors均为空。**PNG0**：所有case在自己截图步骤之前失败，所以没有可view原图，也没有补造/借用旧图。fixture原有resourceprobe和12帧采样保留，未加私有observer/输入/timeout。

已准备私有最小patch，仅Switch182与521两处.075→.12：当前draft P-SHADCN-SWITCH-STATE-DRIVEN-STYLES明确dark unchecked bg-input/80；fixtureinputalpha.15，实际因此.12。T-RULE-COLOR-SCHEME-0001-CASE-BROWSER-PAINT映射原八case，不改变其它颜色、语义或生命周期准入。

原testSHA `c6dfd9c020f1f3aea436925a22628596e217555c060ac143f690872c23d9c0a7`；私有candidateSHA `8a991624c064eb488bc6007138e7d9ede1dd0931fc7e6a3076ec0530fad61a14`；patchSHA `86a048dc9a08fabddf4d1cd382906f5481413f85f44e855d4cc0ac129fcb6a35`。**candidate未应用、未执行**；产品保持原mainclean。完整cause见baseline.log/baseline-vitest.json，逐帧数组见baseline-artifacts与baseline-report.json，权威/blob见authority-map.json。

下一步由root决定何时应用两值oracle候选并展开后续真实验证；Vue首显需按实际frame/transition/reveal边界另行判别，不能靠改.2、删首帧、增加sleep或延timeout解决。human-assisted/current-user，unassessed/partial/ABSTAIN。
