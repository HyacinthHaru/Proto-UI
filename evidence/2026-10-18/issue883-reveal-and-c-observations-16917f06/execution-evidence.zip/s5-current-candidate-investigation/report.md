S5本次诊断已结束并逐字恢复原test，未继续执行。实际来源是042+root冻结3filecandidate+临时catch，**不是cleanmain**。Vitest终态1fail/1filtered，主失败是原150000mscase总超时（150005.84ms）；原waitForFunction60000ms错误在16:51:52.255才到catch，此时页面已关闭。

必须纠正终态通知的过早表述：只有original-error.json与capture-receipt.json成功写入。facts/DOM/AX/PNG四项均Targetclosed，**没有原图可view，也没有nonready/panel/lazy实测**。先前“已保存facts/DOM/AX/PNG”不正确，已单独留下capture-claim-correction.json；原log/receipt未改。

新增实测事实是原pageerror数组18条相同消息：`[shadcn-tabs-trigger]rule token "transition-all":used-value-rounding; fix: companion or change/remove token`。原listener只存message，不能反推18个独立实例或全部属于S5。

静态唯一错误分支在WC `shadow-split-effects.ts`468–474：transition-all与多候选borderwidth或已appliedwidthvector变化同时出现时严格拒绝。此前loop已做recipe/tokenreceipt检查，所以不能因泛化fix文字就说缺companion文件。现行TabsTrigger default有border+transition-all、underline有border-0/border-b-2，可能参与该策略，但实际RootStyleEntries/widthvector未捕获，不能冒称精确操作数已证。

D-FEEDBACK-STYLE-ROLE-RESOLUTION-0001-O要求motion中间帧/反向协调，不允许以移除拒绝guard代替证据；T-WEB-COMPONENT-SHADOW-S2-0001明示animatedborderwidth仍排除/拒绝，既有unit也刻意验证变化/条件/重叠宽度被拒。当前首个具体异常归WCsplitpresentation/admission与family/companion兼容边界候选，应交Shadow/Compiler/IR owner；未建立CAnatomy/退役缺陷。不能删transition-all或放宽compiler来绿。

源码中DemoMatrix没有给这些previewer套data-adapter-panel且lazy默认false，但本次实际nonready节点未知；合法hiddenpanel延迟和具体初始化异常都不能从静态代码代替现场事实。18条错误与全页ready超时的因果也未闭合。

source和差异完整绑定见report.json。原S5SHA34b12b447efbb041dddbe807795a9eaf936c3362c8629b3941bf21ee3b6e564d精确恢复；root3files前后零变化，59231无监听、进程组已清空。无新增run/产品fix/提交或外部写；human-assisted/current-user，unassessed/partial/ABSTAIN。
