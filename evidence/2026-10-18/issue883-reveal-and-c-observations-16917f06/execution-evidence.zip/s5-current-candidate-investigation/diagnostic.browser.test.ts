// @vitest-environment node
import type { Browser } from 'playwright-core';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { launchBrowser, startServer, stopServer } from './browser-harness';
import { runS5Journey } from '../../../../../../scripts/analysis/shadow-s5-journey.mjs';

let browser: Browser;
let baseUrl: string;
beforeAll(async () => {
  baseUrl = await startServer('/zh-cn/internal/demo-matrix/');
  browser = await launchBrowser();
}, 150_000);
afterAll(async () => {
  await browser?.close();
  await stopServer();
}, 60_000);
describe.sequential('S5 native editor acceptance paths', () => {
  for (const locale of ['zh-cn', 'en'])
    it(`${locale}: Light/split/mixed native editing`, async () => {
      const context = await browser.newContext({
        viewport: { width: 1440, height: 1100 },
        colorScheme: 'light',
      });
      const page = await context.newPage();
      const errors: string[] = [];
      page.on('pageerror', (e) => errors.push(e.message));
      try {
        await page.goto(`${baseUrl}/${locale}/internal/demo-matrix/#shadow-split-s5`);
        await page.waitForFunction(
          () => {
            const previews = [...document.querySelectorAll('[data-previewer-id]')];
            return (
              previews.length > 0 &&
              previews.every(
                (el) =>
                  el.getAttribute('data-inited') === '1' &&
                  (el.querySelector('.host')?.childElementCount ?? 0) > 0
              )
            );
          },
          undefined,
          { timeout: 60_000 }
        );
        page.on('framenavigated', (frame) => {
          if (frame === page.mainFrame()) errors.push(`Unexpected navigation: ${frame.url()}`);
        });
        await runS5Journey(page);
        await page.setViewportSize({ width: 320, height: 900 });
        await page.waitForTimeout(250);
        expect(
          await page.locator('[data-shadow-s5]').evaluate((el) => el.scrollWidth > el.clientWidth)
        ).toBe(false);
        expect(errors).toEqual([]);
      } catch (error) {
        const caughtAt = new Date().toISOString();
        const captureErrors: Array<{ stage: string; error: string }> = [];
        try {
          const { mkdir, writeFile } = await import('node:fs/promises');
          const directory = '<PRIVATE_STATE>/s5-current-candidate-investigation/artifacts';
          await mkdir(directory, { recursive: true });
          const originalError = error instanceof Error
            ? { name: error.name, message: error.message, stack: error.stack,
                cause: error.cause instanceof Error
                  ? { name: error.cause.name, message: error.cause.message, stack: error.cause.stack }
                  : String(error.cause ?? '') }
            : { value: String(error) };
          await writeFile(`${directory}/original-error.json`, JSON.stringify({
            caughtAt, originalError, pageErrors: errors,
            scope: 'Failure-only capture after the original assertion rejected; not a pre-failure or first-visible sample.',
          }, null, 2));
          try {
            const sampleStartedAt = new Date().toISOString();
            const facts = await page.evaluate(() => {
              const describe = (element: Element | null) => {
                if (!element) return null;
                const el = element as HTMLElement;
                const style = getComputedStyle(el);
                const rect = el.getBoundingClientRect();
                return { tag: el.localName, id: el.id, connected: el.isConnected,
                  attributes: Object.fromEntries(Array.from(el.attributes, a => [a.name, a.value])),
                  hidden: el.hidden, inert: el.inert, display: style.display,
                  visibility: style.visibility, opacity: style.opacity,
                  rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
                  childElementCount: el.childElementCount };
              };
              const previews = Array.from(document.querySelectorAll<HTMLElement>('[data-previewer-id]'), (root, index) => {
                const host = root.querySelector<HTMLElement>('.host');
                const panels: unknown[] = [];
                for (let panel = root.closest<HTMLElement>('[data-adapter-panel]'); panel;
                     panel = panel.parentElement?.closest<HTMLElement>('[data-adapter-panel]') ?? null)
                  panels.push(describe(panel));
                const ready = root.getAttribute('data-inited') === '1' && (host?.childElementCount ?? 0) > 0;
                return { index, ready, root: describe(root), host: describe(host), panels,
                  fallback: root.querySelector('.proto-previewer__skeleton')?.textContent,
                  previewErrors: root.textContent?.includes('[Preview Error]') ?? false,
                  projection: Array.from(root.querySelectorAll('[data-projection-scope]'), describe),
                  hostChildren: host ? Array.from(host.children, describe) : [] };
              });
              const scenes = Array.from(document.querySelectorAll<HTMLElement>('[data-shadow-s5]'), (scene) => ({
                root: describe(scene), app: describe(scene.querySelector('[data-s5-app]')),
                profiles: Array.from(scene.querySelectorAll('[data-s5-profile]'), describe),
                lightEditors: Array.from(scene.querySelectorAll('input,textarea'), describe),
                shadowHosts: Array.from(scene.querySelectorAll('*')).filter(el => el.shadowRoot).map(el => ({
                  host: describe(el), shadowHTML: el.shadowRoot!.innerHTML,
                  editors: Array.from(el.shadowRoot!.querySelectorAll('input,textarea'), describe) })),
              }));
              return { sampledAt: new Date().toISOString(), performanceNow: performance.now(),
                url: location.href, readyCount: previews.filter(p => p.ready).length,
                previewCount: previews.length, nonReady: previews.filter(p => !p.ready),
                allPanels: Array.from(document.querySelectorAll('[data-adapter-panel]'), describe),
                activeElement: describe(document.activeElement), scenes };
            });
            await writeFile(`${directory}/facts.json`, JSON.stringify({
              caughtAt, sampleStartedAt, sampleCompletedAt: new Date().toISOString(), facts,
            }, null, 2));
          } catch (captureError) { captureErrors.push({ stage: 'facts', error: String(captureError) }); }
          try { await writeFile(`${directory}/dom.html`, await page.content()); }
          catch (captureError) { captureErrors.push({ stage: 'dom', error: String(captureError) }); }
          try { await writeFile(`${directory}/aria.txt`, await page.locator('body').ariaSnapshot({ timeout: 10_000 })); }
          catch (captureError) { captureErrors.push({ stage: 'aria', error: String(captureError) }); }
          try { await page.screenshot({ path: `${directory}/failure.png`, fullPage: false, timeout: 10_000 }); }
          catch (captureError) { captureErrors.push({ stage: 'png', error: String(captureError) }); }
          await writeFile(`${directory}/capture-receipt.json`, JSON.stringify({
            caughtAt, completedAt: new Date().toISOString(), captureErrors,
          }, null, 2));
        } catch (captureError) {
          console.error('[s5-failure-capture]', String(captureError));
        }
        throw error;
      } finally {
        await context.close();
      }
    }, 150_000);
});
