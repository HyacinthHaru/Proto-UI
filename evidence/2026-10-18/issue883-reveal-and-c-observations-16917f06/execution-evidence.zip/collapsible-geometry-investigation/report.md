当前042f原Liquid/WC/320px/200%单case实跑1pass、35filtered，16:34:19.466–16:34:33.136 UTC，exit0。原375e2199测试字节未改；11328 tracked快照前后相同，index6852保持、运行后clean。所属进程结束，57157无监听。

没有复现，因此没有失败geometry/PNG，也未重复追红。旧Linux四项320.4375>320保留；不能归因Root、Content、祖先material布局、字体或Runtime disposal。原320/输入/timeout均保留。详见authority-and-probe-plan；partial/ABSTAIN。
