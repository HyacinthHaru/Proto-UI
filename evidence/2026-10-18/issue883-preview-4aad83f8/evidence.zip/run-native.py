from pathlib import Path
import subprocess,json,datetime,hashlib,socket,os,time
r=Path(__file__).parent;w=Path('<SOURCE_ROOT>');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();env=os.environ.copy();env['PATH']='<HOME>/.codex/task-state/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:'+env['PATH'];entry=json.loads((r/'admitted-binding.json').read_text());assert entry['head_sha']=='4aad83f80ab29e0a5d4f3c0b63af17e3dcf64e06';sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();binding={'head':entry['head_sha'],'run':int(entry['binding']['run_id']),'artifact':int(entry['binding']['artifact_id']),'generation':entry['generation'],'port':port};(r/'verified-binding.json').write_text(json.dumps(binding,indent=2)+'\n');(r/'server-config.json').write_text(json.dumps({'root':str(r/'publisher'),'domain':'preview.localhost','port':port,'bind':'127.0.0.1'})+'\n');serverSource="import {readFile} from 'node:fs/promises';import {createPreviewServer} from '<SOURCE_ROOT>/scripts/preview/serve.mjs';const config=JSON.parse(await readFile(new URL('./server-config.json',import.meta.url),'utf8'));const server=createPreviewServer(config);server.listen(config.port,config.bind,()=>console.log(JSON.stringify({listening:server.address()})));process.on('SIGTERM',()=>server.close(()=>process.exit(0)));";(r/'serve-current.mjs').write_text(serverSource);receipt={'start':now(),**binding,'drivers':[],'scope':'ActualcurrentGitHubartifactadmittedbyexistingtrustedpublisher; temporarylocalserver, preference-selectedruntime, per-copy confirmedclipboard sentinel thennativeclick/equality; notremoteserviceorallpagesvisual/AT'}
with (r/'server.log').open('x')as log:
 server=subprocess.Popen(['node',str(r/'serve-current.mjs')],cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT);receipt['serverPID']=server.pid
 try:
  ready=False
  for _ in range(100):
   if server.poll()is not None:raise RuntimeError('Server ended before native run')
   try:
    with socket.create_connection(('127.0.0.1',port),timeout=.2):ready=True;break
   except OSError:time.sleep(.1)
  assert ready
  for name in ['native-shadcn-interactions.mjs','native-brutalist-copy.mjs']:
   path=r/name;row={'path':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'start':now()}
   with (r/(name+'.log')).open('x')as out:p=subprocess.run(['node',str(path)],cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT)
   row.update({'exit':p.returncode,'end':now()});receipt['drivers'].append(row)
   if p.returncode:raise RuntimeError('Native driver failed: '+name)
  receipt['exit']=0
 except Exception as ex:receipt['exit']=1;receipt['error']=str(ex)
 finally:
  server.terminate()
  try:receipt['serverExit']=server.wait(timeout=10)
  except subprocess.TimeoutExpired:server.kill();receipt['serverExit']=server.wait();receipt['serverKilledAfterGracefulTimeout']=True
  receipt['end']=now();(r/'native-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));raise SystemExit(receipt['exit'])
