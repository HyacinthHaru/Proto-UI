import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { launchBrowser } from '<MATERIAL_FIX_ROOT>/apps/www/src/content/docs/zh-cn/browser-harness.ts';
import { readResizeGeometry, resizeGeometryStyles } from '<MATERIAL_FIX_ROOT>/experiments/material-v2/resize-geometry.ts';
const root='<STATE_ROOT>/main-checkpoint-post-verdict/source-product';
const out='<STATE_ROOT>/geometry-browser-control';
await fs.mkdir(out,{recursive:true});
const server=createServer(async(req,res)=>{
 try {const name=path.resolve(root,'.'+(new URL(req.url,'http://local').pathname==='/'?'/index.html':new URL(req.url,'http://local').pathname));assert.ok(name.startsWith(root+path.sep));res.setHeader('content-type',({'.html':'text/html','.css':'text/css','.js':'text/javascript'})[path.extname(name)]??'application/octet-stream');res.end(await fs.readFile(name));}catch{res.writeHead(404).end();}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await launchBrowser();let context;
const receipt={kind:'Precommit exact helper on retained real main product; owned CSS wrong-size injection is a negative control, not original native product acceptance',browser:browser.version(),steps:[]};
function originalAssertions(s){const outset=Math.ceil(Math.max(s.width,s.height)*0.08+1);assert.equal(s.paintWidth,s.width+2*outset);assert.equal(s.paintHeight,s.height+2*outset);}
try {
 context=await browser.newContext({viewport:{width:1000,height:840}});const page=await context.newPage();await page.goto(`http://127.0.0.1:${server.address().port}/`);
 await page.waitForFunction(()=>[...document.querySelectorAll('[data-demo-ref="regular"]')].length===4&&[...document.querySelectorAll('[data-demo-ref="regular"]')].every(e=>e.dataset.materialQuality==='self-optical'));
 const cdp=await context.newCDPSession(page);
 async function sample(name){
  const original=await page.evaluate(()=>[...document.querySelectorAll('[data-demo-ref="regular"]')].map(e=>{const r=e.getBoundingClientRect(),p=getComputedStyle(e,'::before');return {runtime:e.closest('[data-runtime]').dataset.runtime,width:r.width,height:r.height,paintWidth:parseFloat(p.width),paintHeight:parseFloat(p.height),quality:e.dataset.materialQuality,sourceRevision:Number(e.dataset.materialSourceRevision)}}));
  const snapshot=await cdp.send('DOMSnapshot.captureSnapshot',{computedStyles:resizeGeometryStyles});await fs.writeFile(path.join(out,name+'-snapshot.json'),JSON.stringify(snapshot));
  const measured=readResizeGeometry(snapshot,original,page.url());receipt.steps.push({name,original,measured});return measured;
 }
 const initial=await sample('initial');initial.forEach(originalAssertions);
 const corruption=await page.addStyleTag({content:'[data-runtime="wc"] [data-demo-ref="regular"]::before { width: calc(var(--pui-material-width) + 1px) !important; }'});
 try {const wrong=await sample('wrong-width');assert.throws(()=>originalAssertions(wrong.find(r=>r.runtime==='wc')),assert.AssertionError);wrong.filter(r=>r.runtime!=='wc').forEach(originalAssertions);receipt.originalWidthEqualityRejectedInjectedOnePixel=true;}finally{await corruption.evaluate(e=>e.remove());}
 const restored=await sample('restored');restored.forEach(originalAssertions);receipt.restored=true;await page.screenshot({path:path.join(out,'restored.png')});
 await cdp.detach();
} catch(e) {receipt.error=String(e.stack??e);throw e;}finally{await context?.close();await browser.close();await new Promise(r=>server.close(r));receipt.cleanupFinished=true;await fs.writeFile(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2));}
console.log('real four-runtime geometry: original positive, injected1px rejected, exact restored');
