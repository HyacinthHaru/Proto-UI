import fs from 'node:fs';
import cp from 'node:child_process';
import ts from '<MATERIAL_FIX_ROOT>/node_modules/typescript/lib/typescript.js';
import assert from 'node:assert/strict';
const root='<MATERIAL_FIX_ROOT>';
const filename='experiments/material-v2/continuous-browser.test.mjs';
const old=cp.execFileSync('git',['show','4db5275154fbc80b393c27d6148b8403e7c61361:'+filename],{cwd:root,encoding:'utf8'});
const current=fs.readFileSync(root+'/'+filename,'utf8');
function collect(text){const source=ts.createSourceFile(filename,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const assertions=[],operations=[];
 function visit(node){if(ts.isCallExpression(node)){const name=node.expression.getText(source);const value=ts.createPrinter({removeComments:true}).printNode(ts.EmitHint.Unspecified,node,source);if(name.startsWith('assert.'))assertions.push(value);if(/^(page\.(mouse|keyboard)\.|page\.(waitForTimeout|waitForFunction|setViewportSize|emulateMedia)$)/.test(name))operations.push(value);}ts.forEachChild(node,visit);}visit(source);return {assertions,operations};}
const a=collect(old),b=collect(current);let i=0;for(const value of b.assertions)if(value===a.assertions[i])i++;assert.equal(i,a.assertions.length);assert.deepEqual(a.operations,b.operations);const result={originalAssertionCalls:a.assertions.length,allOriginalAssertionsRetainedInOrder:true,originalNativeWaitViewportPreferenceCalls:a.operations.length,originalOperationsByteEquivalentAST:true,additionalAssertions:b.assertions.length-a.assertions.length};fs.writeFileSync('<STATE_ROOT>/original-operations-binding.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
