# 本次 delivery 原件只读复核

结论：**0具体记录一致性finding；partial / ABSTAIN。** 离线重算1362项，通过本次准确源码的运行、geometry、事件、资源、probe/report及PNG字节绑定。没有新测试/浏览器、网络、源码/Git/GitHub写入，未作GitHubAPPROVE或校准接受。

**Material准确e439**（tree`ebb24f8d14409aca08177352b9a1fc5deea9ed9a`）于2026-11-05T07:27:14–07:28:25UTC实际完成六步骤，全部exit0；每步记录相同head、trackedStatus空。source及packed continuous均`execution=passed`、各42条完整flow，记录错误数组均空；普通路径也各自exit0。这里的42是顺序flow记录，不是42个独立测试。packed明确仍使用私有Liquid prototype源码，不扩大为全公共安装包验收。build manifest中的pending-browser-evidence是构建时标记，不能覆盖后来的continuous终态。

从两份原`resize-layout-snapshot.json`独立重建四runtime物理root及直接before伪元素：全部host为133.609375×38，paint为157.609375×62，保留原CSSOM width157.609。原outset=`ceil(max(width,height)*.08+1)`=12，精确相等断言仍成立，无epsilon或四舍五入。节点backendID、主frame、neutral transform/zoom、零边框padding、sourceRevision及**各surface自己的materialFrame**都与原冻结surface相符，不能把四runtime的frame值误写成一个全局frame。21个后续记录frame逐项对应原timeline片段、旧图释放数4、activation counts不变、所录范围无旧revision回写。

两路径合计16个原blur arm逐条与各自完整native timeline匹配：8个default arm无中间window blur，记录count4→5；8个disabled arm实际trusted down→window-target blur→匹配up，count5→5，CDP false与main true restore记录兑现，cleanupErrors空。辅助页已关闭的restore/detach是明确skip，不冒称ACK。这是本次回归结果，不将其归为e439单独实现的新router能力。

最终dispose中，material的`contexts/consumers/pendingImages/decodedImages`两侧全部0。它们是material资源计数，不是浏览器进程数量；源程序随后await context/browser/server关闭且命令正常exit0，未另造OS进程扫描证据。

**视频失败保留：** source54帧、packed56帧，均`encoded:false`；libx264原错误为1300×813高度不能被2整除，没有有效编码MP4成功主张。现有capture cadence亦不能证明UI frame-rate，更不构成全optical、perceptual或performance接受。

**Dialog独立准确aab**（tree`8e7b28c85a6d900d385e12cdd7d9a561eabf65d3`）本地原8case全部通过，196行=120geometry+24Title+52action；fixed15d用同候选标签aab和同三probe字节实际0pass/8fail，33行=21geometry+4Title+8failure。三输入为50f13884/3b425734/4bbc332f，已核候选Git、两份executed-probe与baseline私有三文件归档；全部149张PNG引用SHA一致，仅字节审计，没有看图。两runner.reportSha256均逐字匹配vitest.json；process-exit、finishedCalls1、closeFinished=true，runner/unhandled/suite errors空，未timeout/cancel。

baseline保留3个inset0、4个Title box overlap504、1个ShadcnVue2未提供；是7个进入原生journey的首390阶段失败加1个availability边界，不能称8个完整产品journey。四个Title文字Range overlap仍0。Node24.21来自同一固定toolchain的pair table/launcher绑定，两个实际browser记录都为155.0.8059.39。本地配对没有调用历史classifier，也没有接受新校准。它不同于旧官方2ca的Node24.22/Chrome156不同patch配对，绝不互相重标。

baseline生成资源与probe四文件归档SHA/字节数均已核对。当前只读回看，baseline临时worktree已恢复旧own352af、tracked clean；candidate worktree为aab。该观察是恢复后的状态，不伪造此前CAS命令回执。Material e439与Dialog aab按各自source epoch表达，不声称一个新的合并树已同时验证。

以下原红完整保留：

- main4db两组私有post-verdict原断言仍157.609 !=157.609375，均source/packed红；不是e439重跑。
- C54两continuous仍rendered-contrast-unsafe红，停止于40条flow；不被e43942条完成覆盖。
- e439修前Dialog原8项为4pass/4fail，四Shadcn原transitionProperty=`all`断言红。
- 原sidebar在e439与aab两次都是0pass/1fail/8filtered，原line954的sidebar count0 !=1；expanded的1s检查与后续单读count不混成新的归还deadline。

详见`audit.json`完整核对与输入SHA索引、`report.json`机器摘要及`restoration-readback.json`。没有全main/全浏览器/全optical/performance、部署或治理接受主张。
