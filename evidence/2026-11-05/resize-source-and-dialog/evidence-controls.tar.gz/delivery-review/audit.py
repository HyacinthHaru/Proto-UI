from pathlib import Path
import json,hashlib,subprocess,collections,math,re,datetime
D=Path(__file__).parent;R=D.parent;W=Path('<MATERIAL_FIX_ROOT>');E='e439f958d42bb8edc4efbb5bd6ead767a86d6efd';A='aab98dd4c5b8e9ee6bfa246d82b9b97f7b1ba229';B='15d864de54210c2eebc4f4b2fec6235324989989';RT=['wc','react','vue','vue2']
errors=[];checks=0;inputs={}
def sha(b):return hashlib.sha256(b).hexdigest()
def record(p):
 p=Path(p);b=p.read_bytes();v={'path':str(p.relative_to(R)) if p.is_relative_to(R) else str(p),'bytes':len(b),'sha256':sha(b)};inputs[v['path']]=v;return v
def read(p):record(p);return json.loads(Path(p).read_text())
def check(ok,label,detail=None):
 global checks
 checks+=1
 if not ok:errors.append({'check':label,'detail':detail})
def git(*a):return subprocess.check_output(['git','-C',str(W),*a])
def artifactSource(h,p):
 b=git('show',h+':'+p);return {'head':h,'path':p,'gitBlob':git('rev-parse',h+':'+p).decode().strip(),'sha256':sha(b),'bytes':len(b)}
sourceBindings=[]
for h,paths in [(E,['experiments/material-v2/continuous-browser.test.mjs','experiments/material-v2/resize-geometry.ts','experiments/material-v2/build-browser.mjs']), (A,['apps/www/src/content/docs/zh-cn/dialog-available-space.browser.test.ts','apps/www/src/content/docs/zh-cn/browser-harness.ts','scripts/test/server-readiness.mjs','scripts/test/dialog-run-integrity-reporter.mjs'])]:
 for p in paths:sourceBindings.append(artifactSource(h,p))
mat=read(R/'products-e439f95/receipt.json');check(mat['head']==E and mat['tree']==git('rev-parse',E+'^{tree}').decode().strip(),'material exact head/tree')
check(len(mat['steps'])==6 and all(s['exitCode']==0 and s['sourceHeadAfter']==E and s['trackedStatusAfter']=='' for s in mat['steps']),'material six actual zero exits and clean head')
check(mat['allStepsPassed'] is True and mat['node']=='v24.21.0','material terminal metadata')
materials={}
flowExpected={'trusted native down/move/out/in/up with live source':4,'native CDP touchCancel':4,'native explicit fixture releasePointerCapture':8,'focus second page':8,'reducedMotion':4,'delayed real decode then source revoke':1,'resize invalidates pending old decode and recovers new geometry':1,'WebGL actual context loss/recovery':1,'actual CSS rejection, idle and external-change recovery':6,'resource and timing observations':1,'matched real WebGL controls':1,'actual owned source pixel replacement':1,'dispose':1,'actual browser screencast':1}
for arm in ['source','packed']:
 p=R/'products-e439f95'/(arm+'-continuous');j=read(p/'result.json');snap=read(p/'resize-layout-snapshot.json');timeline=read(p/'timeline.json');build=read(R/'products-e439f95'/(arm+'-product/source.json'));ordinary=read(R/'products-e439f95'/(arm+'-ordinary/result.json'))
 for kind in ['build','ordinary','continuous']:record(R/'products-e439f95'/(arm+'-'+kind+'.log'))
 app=record(R/'products-e439f95'/(arm+'-product/app.js'));check(app['sha256']==build['assetSha256']==j['source']['assetSha256'],'material '+arm+' actual app bytes')
 check(build==j['source'] and build['revision']==E and build['dirty'] is False,'material '+arm+' source manifest equality')
 check(ordinary['revision']==E and ordinary['dirty'] is False and ordinary['execution']=='passed' and not ordinary.get('failure'),'material '+arm+' ordinary actual pass')
 check(j['execution']=='passed' and not j.get('failure') and j['errors']==[] and j['browser']=='155.0.8059.39','material '+arm+' continuous actual pass')
 check(len(j['results'])==42 and collections.Counter(r['flow'] for r in j['results'])==flowExpected,'material '+arm+' full42 flow scope')
 cp=j['resizeCheckpoint'];check(cp['releasedOldImages']==4 and cp['after']['counts']==cp['before']['counts'] and cp['after']['staleOldImage'] is False,'material '+arm+' original resize guards')
 check(cp['after']['frames']==timeline['frames'][cp['boundary']['index']:cp['boundary']['index']+len(cp['after']['frames'])],'material '+arm+' checkpoint actual timeline slice')
 doc=snap['documents'][0];strings=snap['strings'];nodes=doc['nodes'];lay=doc['layout'];attrs=lambda i:dict(zip([strings[v] for v in nodes['attributes'][i][::2]],[strings[v] for v in nodes['attributes'][i][1::2]]))
 hosts=[i for i in range(len(nodes['nodeName'])) if attrs(i).get('data-demo-ref')=='regular'];check(len(hosts)==4,'material '+arm+' exactly4 snapshot hosts')
 geometry=[]
 for i,frozen in enumerate(cp['after']['surfaces']):
  runtime=frozen['runtime'];matches=[]
  for hi in hosts:
   ai=hi;rt=None
   while ai>=0:
    rt=rt or attrs(ai).get('data-runtime')
    if ai in lay['nodeIndex'] and nodes['nodeType'][ai]==1:
     st=[strings[x] for x in lay['styles'][lay['nodeIndex'].index(ai)]];check(st[2:6]==['none']*4 and st[6]=='1','material '+arm+' neutral ancestry '+runtime)
    ai=nodes['parentIndex'][ai]
   if rt==runtime:matches.append(hi)
  check(len(matches)==1,'material '+arm+' unique runtime '+runtime);hi=matches[0];ha=attrs(hi)
  before=[ni for ni,si in zip(nodes['pseudoType']['index'],nodes['pseudoType']['value']) if nodes['parentIndex'][ni]==hi and strings[si]=='before'];check(len(before)==1,'material '+arm+' direct pseudo '+runtime);bi=before[0]
  hp=lay['nodeIndex'].index(hi);bp=lay['nodeIndex'].index(bi);hb=lay['bounds'][hp];pb=lay['bounds'][bp];ps=[strings[x] for x in lay['styles'][bp]]
  check(len(ps)==15 and ps[2:6]==['none']*4 and ps[6]=='1' and all(float(re.match(r'[-+0-9.]+',s).group())==0 for s in ps[7:]),'material '+arm+' pseudo physical unit guards '+runtime)
  check(ha.get('data-pui-material-carrier')=='contact-v1' and ha.get('data-material-frame')==frozen['materialFrame'] and bool(frozen['materialFrame']),'material '+arm+' same frozen frame '+runtime)
  check(ha.get('data-material-quality')==frozen['quality']=='self-optical' and int(ha['data-material-source-revision'])==frozen['sourceRevision']==cp['boundary']['sources'][i]['revision'],'material '+arm+' same source revision '+runtime)
  check(hb[2:]==[frozen['width'],frozen['height']],'material '+arm+' same frozen host geometry '+runtime)
  derived={**frozen,'paintWidth':pb[2],'paintHeight':pb[3],'cssomPaintWidth':frozen['paintWidth'],'cssomPaintHeight':frozen['paintHeight'],'frameId':strings[doc['frameId']],'hostBackendNodeId':nodes['backendNodeId'][hi],'paintBackendNodeId':nodes['backendNodeId'][bi],'hostBounds':hb,'paintBounds':pb}
  check(derived==cp['geometry'][i],'material '+arm+' recomputed fractional record '+runtime)
  outset=math.ceil(max(hb[2:])*.08+1);check(pb[2]==hb[2]+outset*2 and pb[3]==hb[3]+outset*2,'material '+arm+' exact original outset arithmetic '+runtime)
  check(all(fr['controls'][i]['data']['materialQuality']!='self-optical' or int(fr['controls'][i]['data']['materialSourceRevision'])==cp['boundary']['sources'][i]['revision'] for fr in cp['after']['frames']),'material '+arm+' no stale revision in observed frames '+runtime)
  geometry.append({'runtime':runtime,'hostWidth':hb[2],'hostHeight':hb[3],'paintWidth':pb[2],'paintHeight':pb[3],'cssomPaintWidth':frozen['paintWidth'],'materialFrame':frozen['materialFrame'],'sourceRevision':frozen['sourceRevision'],'hostBackendNodeId':nodes['backendNodeId'][hi],'paintBackendNodeId':nodes['backendNodeId'][bi],'snapshotNodeIndices':[hi,bi],'exactOutset':outset})
 blur=[]
 for r in [r for r in j['results'] if r['flow']=='focus second page']:
  events=r['native'];di=next((i for i,e in enumerate(events) if e.get('type')=='pointerdown' and e.get('trust') and e.get('pointerType')=='mouse' and e.get('runtime')==r['runtime'] and e.get('control')=='regular'),-1)
  check(di>=0,'material '+arm+' real down '+r['runtime']);down=events[di];ui=next((i for i,e in enumerate(events) if i>di and e.get('type')=='pointerup' and e.get('trust') and e.get('pointerId')==down['pointerId'] and e.get('pointerType')==down['pointerType']),-1)
  check(ui>di,'material '+arm+' matching up '+r['runtime']);windowBlur=any(e['type']=='blur' and e.get('trust') and e.get('windowTarget') for e in events[di+1:ui]);check(windowBlur==r['disableFocusEmulation']==r['trustedWindowBlurBeforeUp'],'material '+arm+' blur arm actual event order '+r['runtime'])
  check(r['error'] is None and r['cleanupErrors']==[] and all(o.get('error') is None and (o.get('completedAt') is not None or 'at' in o) for o in r['operations']),'material '+arm+' blur operation outcomes '+r['runtime'])
  if r['disableFocusEmulation']:
   check(r['activationCountBefore']==r['activationCountAfter'],'material '+arm+' original no activation '+r['runtime'])
   for name in ['main.focusEmulation(false)','other.focusEmulation(false)','main.focusEmulation(true)-restore']:check(any(o['name']==name and o.get('completedAt') is not None for o in r['operations']),'material '+arm+' CDP fulfilled '+name+' '+r['runtime'])
  check(any(timeline['native'][i:i+len(events)]==events for i in range(len(timeline['native'])-len(events)+1)),'material '+arm+' blur raw timeline association '+r['runtime'])
  blur.append({'runtime':r['runtime'],'disableFocusEmulation':r['disableFocusEmulation'],'trustedWindowBlurBeforeUp':windowBlur,'countBefore':r['activationCountBefore'],'countAfter':r['activationCountAfter'],'nativeEvents':len(events),'cleanupErrors':len(r['cleanupErrors'])})
 check([(r['runtime'],r['disableFocusEmulation']) for r in blur]==[(rt,d) for rt in RT for d in [False,True]],'material '+arm+' 8 original blur arms')
 dispose=next(r for r in j['results'] if r['flow']=='dispose');met=dispose['state']['metrics'];check(all(met[x]==0 for x in ['contexts','consumers','pendingImages','decodedImages']),'material '+arm+' final material resource zero')
 video=j['results'][-1]['video'];frames=read(p/'recording/frames.json');check(video['encoded'] is False and 'height not divisible by 2 (1300x813)' in video['error'] and video['capturedFrames']==len(frames),'material '+arm+' explicit video encoding failure')
 materials[arm]={'result':record(p/'result.json'),'topExecution':j['execution'],'flows':len(j['results']),'flowCounts':dict(collections.Counter(r['flow'] for r in j['results'])),'browser':j['browser'],'sourceMode':build['packageMode'],'privatePrototype':build['privatePrototype'],'nestedBuildManifestExecution':build['execution'],'appSha256':app['sha256'],'resize':{'geometry':geometry,'releasedOldImages':cp['releasedOldImages'],'observedFrames':len(cp['after']['frames']),'countsUnchanged':cp['after']['counts'],'staleOldImageObserved':cp['after']['staleOldImage']},'blurArms':blur,'finalDispose':dispose['state'],'video':video,'recordedErrors':j['errors']}
# Dialog local pair: raw reports, exact3 source bytes, row identities and PNG references.
pair=read(R/'dialog-fixed-pair-binding.json');check(pair['candidate']==A and pair['baseline']==B and pair['calibrationAccepted'] is False,'dialog pair source labels')
probeFiles=pair['files'];check(len(probeFiles)==3,'dialog three inputs')
for f in probeFiles:
 check(sha(git('show',A+':'+f['path']))==f['sha256'],'dialog candidate Git '+f['path']);p=R/'fixed-baseline-executed-inputs'/f['path'];check(record(p)['sha256']==f['sha256'],'dialog archived baseline '+f['path'])
reporter=next(s['sha256'] for s in sourceBindings if s['path'].endswith('reporter.mjs'));dialogs={}
for name,subject,wantpass in [('dialog-fixed-native',A,8),('dialog-fixed-baseline',B,0)]:
 p=R/name;rec=read(p/'receipt.json');v=read(p/'vitest.json');ri=read(p/'runner-integrity.json');o=read(p/'dialog-available-space/observations.json');record(p/'browser.log');record(p/'executed-probe.ts')
 check(rec['head']==subject and rec['probeSha256']==probeFiles[0]['sha256'] and sha((p/'executed-probe.ts').read_bytes())==probeFiles[0]['sha256'],'dialog exact executed probe '+name)
 check(o['sourceSha']==subject and o['probeSha']==A and o['subject']==('candidate' if wantpass else 'baseline') and o['browser']=='155.0.8059.39','dialog actual subject/probe/browser '+name)
 check(ri['reportSha256']==sha((p/'vitest.json').read_bytes())==pair[name]['reportSha256'] and ri['reporterSha256']==reporter,'dialog report/source SHA '+name)
 check(rec['exitCode']==ri['exitCode']==(0 if wantpass else 1) and ri['phase']=='process-exit' and ri['finishedCalls']==1 and ri['closeStarted'] and ri['closeFinished'] and not ri['processTimedOut'] and not ri['cancelled'] and ri['runnerErrors']==[] and ri['unhandledErrors']==[] and all(not f['suiteErrors'] for f in ri['files']),'dialog terminal/cleanup '+name)
 check(v['numTotalTests']==8 and v['numPassedTests']==wantpass and v['numFailedTests']==8-wantpass and v['numPendingTests']==0,'dialog case counts '+name)
 rows=o['observations'];check(len({r['id'] for r in rows})==len(rows),'dialog unique row IDs '+name);types=collections.Counter();imageCount=0;cases=[]
 for r in rows:
  rid=r['id'];check(r['sourceSha']==subject,'dialog row source '+rid)
  if 'image' in r:
   im=r['image'];pic=p/'dialog-available-space'/im['file'];check(im['file']==rid+'.png' and record(pic)['sha256']==im['sha256'],'dialog original image reference '+rid);imageCount+=1
  if 'data' in r:
   types['geometry']+=1;m=r['data']['maskIdentity'];co=m['coordinates'];fam,rt=rid.split('-')[:2]
   check(m['status']=='resolved' and all(m[k]==1 for k in ['rootCount','contentCount','triggerCount','maskCount']) and co['family']==fam and co['runtime']==rt and bool(co['owner']) and bool(co['generation']),'dialog unique physical identity '+rid)
   check(all(el['attributes'].get('data-projection-'+k)==val for el in [m['content'],*m['masks'],*m['triggers']] for k,val in co.items()),'dialog shared coordinates '+rid)
   check(m['masks'][0]['rect']==r['data']['mask'] and m['content']['rect']==r['data']['rect'] and m['triggers'][0]['attributes']['aria-controls']==m['content']['attributes']['id'],'dialog rect and controlled-id '+rid)
  elif rid.endswith('title-clearance'):
   types['title']+=1;f=r['fact'];check(f['titleOverlapArea']==(0 if wantpass else 504) and all(l['overlapArea']==0 for l in f['lines']),'dialog title bounds '+rid)
  elif '-action-' in rid:types['action']+=1
  elif rid.endswith('-failure'):types['failure']+=1
 for c in v['testResults'][0]['assertionResults']:
  msg=c['failureMessages'][0].split('\n')[0] if c['failureMessages'] else None;cases.append({'name':c['fullName'],'status':c['status'],'firstFailure':msg})
 check(types==({'geometry':120,'title':24,'action':52} if wantpass else {'geometry':21,'title':4,'failure':8}),'dialog complete row scope '+name,dict(types))
 if not wantpass:
  msgs=collections.Counter(c['firstFailure'] for c in cases);check(msgs=={'AssertionError: expected 0 to be greater than or equal to 15':3,'AssertionError: CloseIcon must not cover the Title box: expected 504 to be +0 // Object.is equality':4,'Error: RuntimeNotOffered:shadcn/vue2:["wc","react","vue"]':1},'dialog original 3/4/1 red partition',dict(msgs))
 dialogs[name]={'receipt':record(p/'receipt.json'),'head':subject,'probeLabel':o['probeSha'],'counts':{k:v[k] for k in ['numPassedTests','numFailedTests','numPendingTests']},'rows':len(rows),'rowTypes':dict(types),'pngReferencesVerified':imageCount,'runner':ri,'browser':o['browser'],'cases':cases}
manifest=read(R/'fixed-baseline-generated-manifest.json')
for f in manifest['files']:check(record(R/'fixed-baseline-generated-and-probe'/f['path'])['sha256']==f['sha256'] and (R/'fixed-baseline-generated-and-probe'/f['path']).stat().st_size==f['bytes'],'baseline preserved generated/probe '+f['path'])
for p in ['run-dialog-fixed-native.py','run-dialog-fixed-baseline.py','run-products-e439f95.py']:record(R/p)
# Keep preceding red epochs and exact strong-sidebar oracle separately.
reds=[]
for name in ['main-post-verdict','main-checkpoint-post-verdict','products-c54f252']:
 rr=read(R/name/'receipt.json')
 for arm in ['source','packed']:
  p=R/name/(arm+'-continuous/result.json');j=read(p);check(j['execution']=='failed' and bool(j.get('failure')),'preserved material red '+name+'/'+arm)
  reds.append({'kind':'material','directory':name+'/'+arm+'-continuous','head':rr['head'],'result':record(p),'execution':j['execution'],'failure':j['failure'],'flowRows':len(j['results']),'privateDiagnosticCopy':name.startswith('main-')})
for name in ['dialog-candidate','sidebar-current-original','sidebar-dialog-fix-original']:
 p=R/name;rec=read(p/'receipt.json');v=read(p/'vitest.json');ri=read(p/'runner-integrity.json');check(rec['exitCode']==1 and ri['reportSha256']==sha((p/'vitest.json').read_bytes()),'preserved UI red '+name)
 reds.append({'kind':'dialog-before-fix' if name=='dialog-candidate' else 'original-sidebar','directory':name,'head':rec['head'],'counts':{k:v[k] for k in ['numPassedTests','numFailedTests','numPendingTests']},'failures':[{'name':x['fullName'],'message':x['failureMessages'][0]} for x in v['testResults'][0]['assertionResults'] if x['status']=='failed']})
review={'kind':'Local exact-epoch delivery raw evidence audit','generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'disposition':'partial/ABSTAIN','formalApproval':False,'calibrationAccepted':False,'checks':checks,'findings':errors,'sourceBindings':sourceBindings,'materials':materials,'materialReceipt':record(R/'products-e439f95/receipt.json'),'dialogs':dialogs,'dialogPairBinding':record(R/'dialog-fixed-pair-binding.json'),'baselineGeneratedArchiveVerified':True,'preservedRedEpochs':reds,'inputIndex':list(inputs.values()),'limitations':['No browser/test/source/Git/GitHub mutation was performed. This audit only reads retained local evidence and immutable source.','Two42-flow arrays are sequential recorded milestones, not84 independent test cases.','Packed mode explicitly retains private Liquid prototype source and is not an all-public-package installation acceptance.','Video encoded=false on both paths remains an evidence debt even though the test command exits0; capture cadence is not UI frame-rate proof.','Final contexts/consumers/pendingImages/decodedImages zero are material resource counters. Browser/server cleanup is supported by normal awaited-finally exit, not a new OS process sweep.','Geometry frame identity guards tie snapshot to the already-frozen material sample; this is not global optical, performance, all-browser or semantic acceptance.','This aab/15d local pair uses the same declared Node24.21 toolchain and recorded Chrome155, distinct from the old2ca official runs with differing Node24.22 and Chrome156 patches.','Local pair wrappers run Vitest and integrity reporter, not the historical calibration classifier. No accepted calibration registration is inferred.','PNG hash verification is not pixel review; no screenshot was opened here.']}
(D/'audit.json').write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'checks':checks,'findings':errors,'materialFlows':{k:v['flows'] for k,v in materials.items()},'dialogCounts':{k:{'counts':v['counts'],'rows':v['rows'],'images':v['pngReferencesVerified']} for k,v in dialogs.items()},'auditSha256':sha((D/'audit.json').read_bytes())},indent=2))
