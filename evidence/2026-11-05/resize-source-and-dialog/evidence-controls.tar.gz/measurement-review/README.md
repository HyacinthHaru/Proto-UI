原严格等式的对象是实际实现的扩展 paint carrier 外框，基准是未由材质变形的 host border box。它不直接测 shader 可见轮廓；GPU栅格宽度本来会ceil，也不等于CSS carrier的小数宽度。

实际 source/packed 两条原L1000失败均保留。后置同次数据四runtime均为 host133.609375×38、before157.609375×62，outset12，严格物理尺寸等式在该后置快照成立；CSSOM字符串却为157.609px。offsetRects和BoxModel.width为整数158，不可作为精度替代。border quads独立读数与snapshot宽高一致。

Chrome155锁定revision3ff源码已核：snapshot.bounds来自绝对布局边界转document坐标；offsetRects经int，BoxModel.width/height显式Round。captureSnapshot会推动style/layout到CompositingInputsClean；quads单独请求也会更新layout，因此都不能冒称原assertion时刻或零干扰。

一次snapshot方案可以是等义读取修正候选，前提是同document/frame、原四runtime唯一host与直属before、同quality/sourceRevision、snapshot host尺寸严格等原冻结BCR，且保留zero-border/padding、transform/individual-transform/zoom中性和原geometry epoch。原断言/4RAF/输入/期限保持；不使用变量自证、整数、容差、补wait或重试。缺失/歧义应显式失败。

本报告只读复核源码与已终态数据，未审实际tracked替换diff或运行新测试。原红不能回填，draft authority不升级；partial/ABSTAIN。
