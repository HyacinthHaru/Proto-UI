import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { launchBrowser } from '<MATERIAL_FIX_ROOT>/apps/www/src/content/docs/zh-cn/browser-harness.ts';
const root='<STATE_ROOT>/products-c54f252/source-product';
const out='<STATE_ROOT>/replacement-source-control';await fs.mkdir(out,{recursive:true});
const server=createServer(async(req,res)=>{try{const filename=path.resolve(root,'.'+(req.url==='/'?'/index.html':req.url));assert.ok(filename.startsWith(root+path.sep));res.setHeader('content-type',({'.html':'text/html','.js':'text/javascript','.css':'text/css'})[path.extname(filename)]??'application/octet-stream');res.end(await fs.readFile(filename));}catch{res.writeHead(404).end();}});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await launchBrowser();let context;const result={kind:'Owned real program/frame fixture control: unchanged black foreground/clear variant, original unsafe palette and proposed admissible replacement; not full consumer acceptance',browser:browser.version()};
try{context=await browser.newContext({viewport:{width:1000,height:840}});const page=await context.newPage();await page.goto(`http://127.0.0.1:${server.address().port}/`);await page.waitForFunction(()=>document.documentElement.dataset.ready==='true');
 result.observed=await page.evaluate(()=>{
  const baseline=window.v2Material.controls()[0];const scene=window.v2Material.scenes()[0];
  function replace(first){scene.lease.draw((ctx,w,h)=>{ctx.fillStyle=first;ctx.fillRect(0,0,w,h);ctx.fillStyle='#fcda32';for(let x=0;x<w;x+=20)ctx.fillRect(x,0,8,h);});}
  replace('#0735ce');let unsafe=null;try{window.v2Material.controls();}catch(error){unsafe=String(error.message);}
  replace('#c3d5fc');const replacement=window.v2Material.controls()[0];scene.redraw();
  return {unsafe,validImage:replacement.image,sourceImageChanged:baseline.image!==replacement.image,geometryEqual:JSON.stringify(baseline.geometry)===JSON.stringify(replacement.geometry),foregroundAndVariant:'fixed browser-entry controls(): black / clear',metrics:window.v2Material.metrics()};
 });assert.equal(result.observed.unsafe,'rendered-contrast-unsafe');assert.equal(result.observed.sourceImageChanged,true);assert.equal(result.observed.geometryEqual,true);await fs.writeFile(path.join(out,'valid-replacement.png'),Buffer.from(result.observed.validImage.split(',')[1],'base64'));delete result.observed.validImage;
}catch(e){result.error=String(e.stack??e);throw e;}finally{await context?.close();await browser.close();await new Promise(r=>server.close(r));result.cleanupFinished=true;await fs.writeFile(path.join(out,'receipt.json'),JSON.stringify(result,null,2));}console.log(JSON.stringify(result));
