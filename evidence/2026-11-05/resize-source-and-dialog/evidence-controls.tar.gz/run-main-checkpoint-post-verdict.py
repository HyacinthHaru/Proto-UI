import os,pathlib,subprocess,json,datetime,time
root=pathlib.Path('<MATERIAL_FIX_ROOT>');out=pathlib.Path('<STATE_ROOT>/main-checkpoint-post-verdict');out.mkdir(exist_ok=True);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='4db5275154fbc80b393c27d6148b8403e7c61361';assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
env=os.environ.copy();env['PATH']='<TASK_STATE_ROOT>/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:/opt/homebrew/bin:'+env['PATH'];env['CHROME_PATH']='<TASK_STATE_ROOT>/proto-ui-883/continue-20261023T123632Z/browser-source/cache/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing';env['CANDIDATE_SHA']=head
r=dict(head=head,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),kind='Actual real source and emitted-public-package product paths. Private Liquid prototype source boundary remains explicit in source.json. No new timeouts/assertions changed.',node=subprocess.check_output(['node','--version'],env=env,text=True).strip(),resourceBoundForThisRemainingLocalPhase=900,steps=[]);start=time.monotonic()
def run(name,cmd):
 row=dict(name=name,command=cmd,startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());r['steps'].append(row);(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 with (out/(name+'.log')).open('w') as log:
  try:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=max(1,900-(time.monotonic()-start)));row['exitCode']=p.returncode
  except subprocess.TimeoutExpired:row['outerResourceTimeout']=True;row['exitCode']=124
 row['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();row['sourceHeadAfter']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();row['trackedStatusAfter']=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=root,text=True).strip();assert row['sourceHeadAfter']==head and row['trackedStatusAfter']=='';(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(name,row['exitCode'],flush=True);return row['exitCode']
for mode in ['source','packed']:
 build=out/(mode+'-product');args=['node','--import','tsx','experiments/material-v2/build-browser.mjs',str(build)]+(['--packed'] if mode=='packed' else[])
 if run(mode+'-build',args)!=0:continue
 run(mode+'-ordinary',['node','--import','tsx','experiments/material-v2/browser.test.mjs',str(build),str(out/(mode+'-ordinary'))])
 if time.monotonic()-start>=900:break
 run(mode+'-continuous',['node','--import','tsx','<STATE_ROOT>/continuous-checkpoint-post-verdict.mjs',str(build),str(out/(mode+'-continuous'))])
r['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['allStepsPassed']=len(r['steps'])==6 and all(x['exitCode']==0 for x in r['steps']);(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print('real product phase terminal',r['allStepsPassed'])
