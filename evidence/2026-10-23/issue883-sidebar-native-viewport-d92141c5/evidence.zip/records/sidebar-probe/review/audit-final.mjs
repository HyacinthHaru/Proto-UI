import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const D = path.dirname(fileURLToPath(import.meta.url));
const P = path.dirname(D);
const ts = createRequire('<WORKTREE>/package.json')('typescript');
const digest = (data) => crypto.createHash('sha256').update(data).digest('hex');
const title = 'reveals the current article in only the sidebar scroll owner and yields to manual scrolling';
const actionNames = new Set(['press', 'click', 'dblclick', 'focus', 'fill', 'check', 'uncheck', 'hover', 'tap', 'move', 'down', 'up', 'wheel', 'insertText']);
function inspect(name) {
  const source = fs.readFileSync(path.join(P, name), 'utf8');
  const file = ts.createSourceFile(name, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  let targetCase, outerTry;
  function locate(node) {
    if (ts.isCallExpression(node) && node.expression.getText(file) === 'it' && node.arguments[0]?.text === title) targetCase = node;
    ts.forEachChild(node, locate);
  }
  locate(file);
  if (!targetCase) throw new Error('Target original case absent');
  function locateTry(node) {
    if (ts.isTryStatement(node) && node.tryBlock.getText(file).includes('await page.goto') && node.finallyBlock?.getText(file).includes('await context.close()')) outerTry = node;
    ts.forEachChild(node, locateTry);
  }
  locateTry(targetCase);
  if (!outerTry) throw new Error('Target original try/finally absent');
  function collect(skipTargetFinally) {
    const out = { cases: [], assertions: [], inputs: [], polls: [], waits: [], budgets: [], closes: [], evaluates: [], CDP: [] };
    function visit(node) {
      if (skipTargetFinally && node === outerTry.finallyBlock) return;
      if (ts.isCallExpression(node)) {
        const callee = node.expression.getText(file).replace(/\s+/g, '');
        const text = node.getText(file);
        if (['it', 'beforeAll', 'afterAll'].includes(callee)) {
          const index = callee === 'it' ? 2 : 1;
          out.budgets.push({ callee, timeout: node.arguments[index]?.getText(file) ?? null });
          if (callee === 'it') out.cases.push({ title: node.arguments[0].getText(file), timeout: node.arguments[index]?.getText(file) ?? null });
        }
        if (ts.isPropertyAccessExpression(node.expression)) {
          const method = node.expression.name.text;
          if (actionNames.has(method)) out.inputs.push(text);
          if (['waitFor', 'waitForFunction', 'waitForURL', 'waitForLoadState'].includes(method)) out.waits.push(text);
          if (method === 'evaluate' || method === 'evaluateAll') out.evaluates.push(text);
          if (callee === 'expect.poll') out.polls.push(text);
          if (callee === 'context.close') out.closes.push(text);
          if (callee === 'cdp.send') out.CDP.push({ method: node.arguments[0]?.text, args: node.arguments.slice(1).map(a => a.getText(file)) });
          let receiver = node.expression.expression;
          while (ts.isPropertyAccessExpression(receiver)) receiver = receiver.expression;
          if (ts.isCallExpression(receiver) && ['expect', 'expect.poll'].includes(receiver.expression.getText(file).replace(/\s+/g, ''))) out.assertions.push(text);
        }
      }
      ts.forEachChild(node, visit);
    }
    visit(file);
    return out;
  }
  const raw = collect(false), beforeOriginalFinally = collect(true);
  return { path: name, sha256: digest(source), parseDiagnostics: file.parseDiagnostics.map(d => ts.flattenDiagnosticMessageText(d.messageText, '\n')), raw, beforeOriginalFinally,
    targetCaseTimeout: targetCase.arguments[2].getText(file), targetFinallyLine: file.getLineAndCharacterOfPosition(outerTry.finallyBlock.getStart(file)).line + 1,
    targetCatchText: outerTry.catchClause?.getText(file) ?? null };
}
const original = inspect('original.ts'), candidate = inspect(process.argv[2] ?? 'prepared-final.ts');
const checks = {};
for (const key of ['cases', 'assertions', 'inputs', 'polls', 'waits', 'budgets']) checks[key + 'BeforeOriginalFinallyEqual'] = JSON.stringify(original.beforeOriginalFinally[key]) === JSON.stringify(candidate.beforeOriginalFinally[key]);
checks.originalCloseCallSitesEqual = JSON.stringify(original.raw.closes) === JSON.stringify(candidate.raw.closes);
checks.sameOriginalPathEvaluateCallSiteCount = original.beforeOriginalFinally.evaluates.length === candidate.beforeOriginalFinally.evaluates.length;
const result = { kind: 'Static TS parse and full call-text preservation audit; no test execution', original, candidate, checks,
  counts: { originalCases: original.raw.cases.length, originalMatcherCallSites: original.raw.assertions.length, originalInputCallSites: original.raw.inputs.length,
    originalPollCallSites: original.raw.polls.length, postVerdictAddedMatcherCallSites: candidate.raw.assertions.length - original.raw.assertions.length,
    postVerdictAddedInputCallSites: candidate.raw.inputs.length - original.raw.inputs.length, postVerdictAddedPollCallSites: candidate.raw.polls.length - original.raw.polls.length },
  noExecution: true };
fs.writeFileSync(path.join(D, candidate.path.replace(/\.ts$/, '') + '.ast-audit.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ candidateSHA256: candidate.sha256, checks, counts: result.counts, parseDiagnostics: candidate.parseDiagnostics }));
