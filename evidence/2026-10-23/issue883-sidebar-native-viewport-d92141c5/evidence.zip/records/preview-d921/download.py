from pathlib import Path
import subprocess,json,hashlib,datetime,zipfile
R=Path(__file__).parent;A=R/'artifacts';A.mkdir(exist_ok=False)
source=json.loads((R.parent/'native-viewport-fix/canonical-ci/summary-selected-2.json').read_text());p=source['runs']['preview'];assert p['id']==40041038753 and p['conclusion']=='success'
rows=[]
for name,aid in [('site.zip',12539113546),('binding.zip',12538978807)]:
 metadata=next(x for x in p['artifacts']if x['id']==aid);target=A/name;start=datetime.datetime.now(datetime.timezone.utc).isoformat();argv=['gh','api','repos/Proto-UI/Proto-UI/actions/artifacts/'+str(aid)+'/zip']
 with target.open('xb')as output:q=subprocess.run(argv,stdout=output,stderr=subprocess.PIPE,cwd='<WORKTREE>')
 (A/(name+'.stderr')).write_bytes(q.stderr);data=target.read_bytes();receipt={'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':q.returncode,'argv':argv,'artifact':metadata,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'downloadAttempts':1};(A/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');assert q.returncode==0 and len(data)==metadata['size_in_bytes']and 'sha256:'+receipt['sha256']==metadata['digest'];rows.append(receipt)
with zipfile.ZipFile(A/'binding.zip')as z:
 assert z.testzip()is None;names=z.namelist();assert names==['binding.txt'];text=z.read('binding.txt').decode();assert text=='921 d92141c57ebab192f3741e7336c1ec0f24b61c5c\n';(R/'binding.txt').write_text(text)
(R/'artifact-binding.json').write_text(json.dumps({'sourceHead':source['head'],'sourceTree':'8dda1bb967cc066db4036e7e085cb7d5c93ebd75','run':p['id'],'job':p['jobs'][0]['id'],'downloads':rows,'bindingText':text,'source':'Actualofficialuploadartifact; wholezip retained; no standaloneproducer-dir equivalence asserted'},indent=2)+'\n');print(json.dumps({'downloaded':[(x['artifact']['id'],x['bytes'],x['sha256'])for x in rows],'binding':text}))
