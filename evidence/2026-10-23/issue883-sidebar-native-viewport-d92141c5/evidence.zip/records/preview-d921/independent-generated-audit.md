# Independent generated-artifact difference audit

This bounded read-only review compares the actual4d artifact12506103874 with d921 artifact12539113546. It preserves both extracted trees and does not execute JavaScript, tests, browsers or network requests. No SequenceMatcher was used.

The supplied root audit paired2408 chunks and classified2001 byte-identical,352 filename-only and55 residual. I rehashed every old/new residual pair and checked the407 filename-map entries form a bijection with existing targets; the complete graph pairing itself is reused from the supplied audit.

TypeScript parsing and actual import/export binding inspection explain35 of the55 residual chunks under deliberately narrow projections. The `site-shadcn-controls` body before its export declaration is exactly equal after filename projection; its243 exported local bindings are the same, with aliases O→Q, Q→R, R→O, T→U and U→T. Another34 consumer bodies are exactly equal after only observed filename replacement and symbol-bound imported-reference normalization. No named import is unresolved and the54 consumer old/new files have no parse diagnostics. **20 consumer bodies remain unclassified**; their paths are in the JSON report. This is not proof of whole-bundle semantic equivalence or every observable name/namespace behavior.

All669 HTML page paths are preserved.19 files are raw-byte identical;15 more require only the observed filename replacements. After also mapping only source-declared per-page random identities, **all669 complete HTML strings match exactly**. This includes all corresponding label/id/for/ARIA IDREF occurrences. Besides AdapterSelect/LanguageSelect and previewer `pp-` IDs, the last7 pages needed the source-declared HomeDemoPreviewer projection, CodeExample, WikiTerm and InstallCommandCard identities. No markup or reference was removed to obtain equality. Hydrated DOM behavior was not exercised.

All635 Pagefind fragment URLs are preserved.141 structured JSON objects are already equal;494 changed objects differ in anchors. Content, word_count, filters and meta are equal for every fragment. Applying the corresponding page HTML identity map makes **all635 full fragment JSON objects equal**. The `.pf_meta` binary files were not semantically decoded, so complete binary-index equivalence, ranking and retrieval remain unverified.

The unresolved20 JS bodies and binary-index boundary remain explicit. No Compiler/CLI/source fix, visual acceptance, whole-bundle behavior claim or formal approval follows from this audit. **Disposition: partial / ABSTAIN.**
