from pathlib import Path
from html.parser import HTMLParser
import json,gzip,re,hashlib,collections,subprocess,datetime
P=Path(__file__).resolve().parent;O=Path('<TASK_STATE>/continue-20261023T123632Z/preview-4d4a/extracted');N=P/'extracted';m=json.loads((P/'generated-filename-map.json').read_text());base={Path(k).name:Path(v).name for k,v in m.items()};rx=re.compile('|'.join(re.escape(x) for x in sorted(base,key=len,reverse=True)));norm=lambda s:rx.sub(lambda x:base[x[0]],s)
class Attrs(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.ids=[];self.refs=[]
 def handle_starttag(self,t,attrs):
  for k,v in attrs:
   if k=='id':self.ids.append(v)
   if k in ['for','aria-labelledby','aria-describedby','aria-controls','aria-owns','aria-activedescendant'] and v:self.refs.append((k,v.split()))
def tokens(s):
 # Observed generated identities only. Match full adapter-label IDs and previewer root token prefixes.
 labels=list(dict.fromkeys(re.findall(r'\bid="([^"]+-label-[a-z0-9]+)"',s)));pps=list(dict.fromkeys(re.findall(r'\bpp-[a-z0-9]+\b',s)));return labels,pps
rows=[];maps={}
oldhtml={str(p.relative_to(O)) for p in O.rglob('*.html')};newhtml={str(p.relative_to(N)) for p in N.rglob('*.html')};assert oldhtml==newhtml
for rel in sorted(oldhtml):
 a=(O/rel).read_text();b=(N/rel).read_text();x=norm(a);ta,tb=tokens(x),tokens(b);mapping={};valid=all(len(u)==len(v) for u,v in zip(ta,tb))
 if valid:
  mapping={u:v for us,vs in zip(ta,tb) for u,v in zip(us,vs)};valid=len(set(mapping.values()))==len(mapping)
 if mapping and valid:
  r=re.compile('|'.join(re.escape(x) for x in sorted(mapping,key=len,reverse=True)));projected=r.sub(lambda z:mapping[z[0]],x)
 else:projected=x
 equal=projected==b;pa=Attrs();pb=Attrs();pa.feed(a);pb.feed(b)
 # Exact all ID and all supported IDREF attribute comparisons under the observed bijection.
 def sub(v):
  if not mapping or not valid:return v
  return r.sub(lambda z:mapping[z[0]],v)
 idok=[sub(z) for z in pa.ids]==pb.ids;refok=[(k,[sub(z) for z in vs]) for k,vs in pa.refs]==pb.refs
 rows.append({'path':rel,'sameBytes':a==b,'filenameOnly':x==b,'randomLabelCount':len(ta[0]),'previewerIdCount':len(ta[1]),'identityPairingBijective':valid,'allIDsCorrespond':idok,'allIDREFAttributesCorrespond':refok,'exactAfterFilenameAndObservedIdentityProjection':equal})
 maps[rel]=mapping
fragments=[]
def readfrags(root):
 out={}
 for p in (root/'pagefind/fragment').glob('*.pf_fragment'):
  raw=gzip.decompress(p.read_bytes());assert raw.startswith(b'pagefind_dcd');d=json.loads(raw[len(b'pagefind_dcd'):]);assert d['url'] not in out;out[d['url']]=(p,d)
 return out
x,y=readfrags(O),readfrags(N);assert x.keys()==y.keys()
for url,(p,a) in x.items():
 q,b=y[url];rel=url.lstrip('/')+'index.html' if url.endswith('/') else url.lstrip('/');mapping=maps.get(rel,{})
 def replace(v):
  if isinstance(v,str):
   for old,new in mapping.items():v=v.replace(old,new)
   return v
  if isinstance(v,list):return [replace(i) for i in v]
  if isinstance(v,dict):return {k:replace(val) for k,val in v.items()}
  return v
 top=[k for k in set(a)|set(b) if a.get(k)!=b.get(k)]
 fragments.append({'url':url,'old':p.name,'new':q.name,'sameStructuredJSON':a==b,'changedTopLevelKeys':top,'sameAfterPageHTMLIdentityProjection':replace(a)==b,'contentEqual':a['content']==b['content'],'wordCountEqual':a['word_count']==b['word_count'],'filtersEqual':a['filters']==b['filters'],'metaEqual':a['meta']==b['meta']})
meta=[]
for root in [O,N]:
 for p in sorted((root/'pagefind').glob('*.pf_meta')):
  b=gzip.decompress(p.read_bytes());meta.append({'epoch':'old' if root==O else 'new','path':str(p.relative_to(root)),'decompressedBytes':len(b),'prefixHex':b[:24].hex(),'interpretation':'Binary Pagefind metadata; no unsupported format inference or search-behavior claim.'})
source=[];W='<WORKTREE>'
for path in ['apps/www/src/components/override/AdapterSelect.astro','apps/www/src/components/PrototypePreviewer/PrototypePreviewer.astro']:
 b=subprocess.check_output(['git','show','d92141c57ebab192f3741e7336c1ec0f24b61c5c:'+path],cwd=W);source.append({'path':path,'sha256':hashlib.sha256(b).hexdigest(),'randomLines':[{'line':i,'text':s} for i,s in enumerate(b.decode().splitlines(),1) if 'Math.random' in s]})
result={'html':{'pages':len(rows),'samePaths':True,'sameBytes':sum(r['sameBytes'] for r in rows),'filenameOnlyIncludingSame':sum(r['filenameOnly'] for r in rows),'exactAfterIdentityAndFilenameProjection':sum(r['exactAfterFilenameAndObservedIdentityProjection'] for r in rows),'IDMismatches':[r['path'] for r in rows if not r['allIDsCorrespond']],'IDREFMismatches':[r['path'] for r in rows if not r['allIDREFAttributesCorrespond']],'residual':[r for r in rows if not r['exactAfterFilenameAndObservedIdentityProjection']],'rows':rows},'pagefind':{'fragments':len(fragments),'sameURLSet':True,'sameStructuredJSON':sum(r['sameStructuredJSON'] for r in fragments),'sameAfterPageHTMLIdentityProjection':sum(r['sameAfterPageHTMLIdentityProjection'] for r in fragments),'contentAndMetadataEqual':all(r['contentEqual'] and r['wordCountEqual'] and r['filtersEqual'] and r['metaEqual'] for r in fragments),'residual':[r for r in fragments if not r['sameAfterPageHTMLIdentityProjection']],'fragmentsByURL':fragments,'binaryMetadata':meta},'source':source,'limits':['Identity correspondence is observed per-page document order, not a claim of identical random generator state.','Exact transformed-string/structured comparison does not exercise live DOM hydration, search retrieval, rendering or accessibility.','Binary .pf_meta format is not decoded; its logical search-index identity remains unverified.']}
(P/'independent-generated-html-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'HTML':{k:v for k,v in result['html'].items() if k not in ['rows','residual']},'htmlResidual':len(result['html']['residual']),'pagefind':{k:v for k,v in result['pagefind'].items() if k not in ['fragmentsByURL','binaryMetadata','residual']},'pagefindResidual':len(result['pagefind']['residual'])}))
