from pathlib import Path
import json,re,hashlib,datetime
R=Path(__file__).parent;A=Path('<TASK_STATE>/continue-20261023T123632Z/preview-4d4a/extracted');B=R/'extracted'
old=json.loads((A/'proto-ui-bundle-graph.json').read_text());new=json.loads((B/'proto-ui-bundle-graph.json').read_text())
def key(c):return(c['name'],c['facadeModuleId'],tuple(sorted(c['moduleIds'])))
om={key(x):x for x in old['chunks']};nm={key(x):x for x in new['chunks']};assert len(om)==len(old['chunks'])and len(nm)==len(new['chunks']);assert set(om)==set(nm)
mapping={om[k]['fileName']:nm[k]['fileName']for k in om if om[k]['fileName']!=nm[k]['fileName']};basenames={Path(a).name:Path(b).name for a,b in mapping.items()};assert len(basenames)==len(mapping)
token=re.compile(rb'[A-Za-z0-9_$.-]+\.(?:js|css)(?![A-Za-z0-9])')
lookup={a.encode():b.encode()for a,b in basenames.items()}
def project(data):return token.sub(lambda m:lookup.get(m.group(),m.group()),data)
unchanged=0;normalized_equal=[];residual=[]
for k in om:
 a=om[k]['fileName'];b=nm[k]['fileName'];aa=(A/a).read_bytes();bb=(B/b).read_bytes()
 if aa==bb:unchanged+=1
 elif project(aa)==bb:normalized_equal.append({'old':a,'new':b})
 else:
  pp=project(aa);i=next((i for i,(x,y)in enumerate(zip(pp,bb))if x!=y),min(len(pp),len(bb)))
  residual.append({'old':a,'new':b,'oldBytes':len(aa),'newBytes':len(bb),'oldSHA256':hashlib.sha256(aa).hexdigest(),'newSHA256':hashlib.sha256(bb).hexdigest(),'firstDelta':i,'oldSnippetAfterFilenameProjection':pp[max(0,i-120):i+240].decode(errors='replace'),'newSnippet':bb[max(0,i-120):i+240].decode(errors='replace')})
html_equal=0;html_projected=[];html_residual=[]
for b in sorted(B.rglob('*.html')):
 rel=b.relative_to(B);a=A/rel;assert a.exists();aa=a.read_bytes();bb=b.read_bytes()
 if aa==bb:html_equal+=1
 elif project(aa)==bb:html_projected.append(str(rel))
 else:html_residual.append(str(rel))
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual4dartifact vs actuald921artifact, no source orartifactedits; filenameprojection is analysis only','oldArtifact':12506103874,'newArtifact':12539113546,'chunks':len(om),'matchedBy':'Unique name+facadeModuleId+sortedmoduleIds','renamedChunks':len(mapping),'sameByteChunks':unchanged,'equalAfterExactObservedFilenameProjection':normalized_equal,'residualChunks':residual,'html':{'sameBytes':html_equal,'equalAfterExactObservedFilenameProjection':html_projected,'residual':html_residual},'limits':'Chunkfilenamesonlynormalizedusingactualgraphbijection; residualcode stillrequiresowncontentreview. Thisdoesnotestablishbrowserrender/behavior/ATacceptance.'}
(R/'generated-difference-audit.json').write_text(json.dumps(report,indent=2)+'\n');(R/'generated-filename-map.json').write_text(json.dumps(mapping,indent=2)+'\n');print(json.dumps({'chunks':len(om),'renamed':len(mapping),'sameBytes':unchanged,'equalAfterFilenameProjection':len(normalized_equal),'residualChunks':residual,'HTMLsame':html_equal,'HTMLprojected':len(html_projected),'HTMLresidual':len(html_residual)},indent=2))
