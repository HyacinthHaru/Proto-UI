import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { execFileSync } from 'node:child_process';
import { once } from 'node:events';
import { readFile, writeFile, mkdir, readdir, lstat } from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import readyPredicate from './ready-predicate.mjs';

const directory = path.dirname(fileURLToPath(import.meta.url));
const input = path.dirname(directory);
const output = path.resolve(process.argv[2] || '');
if (!process.argv[2] || !output.startsWith(directory + path.sep)) throw Error('Use a new output directory under native-qa');
await mkdir(output, { recursive: false });
const now = () => new Date().toISOString();
const digest = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const errorText = (error) => { try { return String(error); } catch { return '[unprintable error]'; } };
const save = (name, value) => writeFile(path.join(output, name), JSON.stringify(value, null, 2) + '\n');
const preparation = JSON.parse(await readFile(path.join(directory, 'source-preparation.json'), 'utf8'));
const binding = JSON.parse(await readFile(path.join(input, 'final-binding.json'), 'utf8'));
const inventoryBytes = await readFile(path.join(input, 'members.json'));
const inventory = JSON.parse(inventoryBytes);
const members = new Map(inventory.map((member) => [member.path, member]));
const mime = JSON.parse(await readFile(path.join(directory, 'mime-types.json'), 'utf8'));
const root = path.join(input, 'extracted');
const require = createRequire(path.join(preparation.playwright.packageRoot, 'package.json'));
assert.equal(JSON.parse(await readFile(path.join(preparation.playwright.packageRoot, 'package.json'))).version, '1.58.2');
const { chromium } = require(preparation.playwright.packageRoot);
const chrome = process.env.CHROME_PATH;
assert.equal(chrome, "<TASK_STATE>/continue-20261023T123632Z/browser-source/cache/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing");
assert.equal(process.version, 'v24.21.0');
assert.equal(binding.head, 'd92141c57ebab192f3741e7336c1ec0f24b61c5c');
assert.equal(binding.tree, '8dda1bb967cc066db4036e7e085cb7d5c93ebd75');
assert.equal(binding.sourceMode, 'official-actions-artifact');
assert.equal(binding.producerRun, 40041038753);
assert.equal(binding.producerJob, 120711921726);
assert.equal(binding.completeSiteArtifact.artifactId, 12539113546);
assert.equal(binding.exactSourceBinding, true);
assert.equal(binding.producerDefaultAdmission.counts.pass, 1);
assert.equal(binding.producerDefaultAdmission.counts.fail, 0);
assert.equal(binding.producerDefaultAdmission.counts.skipped, 0);
assert.equal(inventory.length, binding.completeSiteArtifact.files);
assert(inventory.every(member => member.type === 'file'));
assert.equal(members.size, inventory.length);
const worktree = '<WORKTREE>';
const gitRead = (...args) => execFileSync('git', args, { cwd: worktree, encoding: 'utf8' }).trim();
assert.equal(gitRead('rev-parse', 'HEAD'), binding.head);
assert.equal(gitRead('rev-parse', 'HEAD^{tree}'), binding.tree);
assert.equal(gitRead('status', '--porcelain'), '');
assert.equal(digest(inventoryBytes), binding.completeSiteArtifact.memberInventorySHA256);
assert.equal(digest(await readFile(path.join(directory, 'ready-predicate.mjs'))), preparation.readiness.generatedSHA256);
const receipt = { start: now(), head: binding.head, tree: binding.tree, artifactId: binding.completeSiteArtifact.artifactId,
  producerRun: binding.producerRun, producerJob: binding.producerJob,
  artifactSHA256: binding.completeSiteArtifact.archiveSHA256, sourceMode: binding.sourceMode,
  finalBindingSHA256: digest(await readFile(path.join(input, 'final-binding.json'))),
  node: process.version, playwright: '1.58.2', chrome, contexts: [], errors: [], cleanup: {},
  scope: 'Two fresh-context observations of an exactd921 official Actions artifact only; plain loopback static server, not Actions, publisher/live admission or Search1s/269 acceptance.' };
const serverRequests = [];
const sockets = new Set();
let server, browser, origin;
async function verifyCompleteTree() {
  const found = [];
  async function walk(dir) {
    for (const entry of await readdir(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name); const stat = await lstat(full);
      assert(!stat.isSymbolicLink(), full);
      if (stat.isDirectory()) await walk(full);
      else { assert(stat.isFile(), full); found.push(path.relative(root, full).split(path.sep).join('/')); }
    }
  }
  await walk(root); assert.deepEqual(found.sort(), [...members.keys()].sort());
  let bytes = 0;
  for (const [name, member] of members) {
    const data = await readFile(path.join(root, name)); assert.equal(data.length, member.size, name);
    assert.equal(digest(data), member.sha256, name); bytes += data.length;
  }
  return { at: now(), files: found.length, bytes, allManifestHashesEqual: true, pruned: false };
}
function bounded(promise, milliseconds, label) {
  let timer;
  return Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(Error(`${label} observation deadline`)), milliseconds); })])
    .finally(() => clearTimeout(timer));
}
async function observation(page) {
  return page.evaluate(() => {
    const read = (element) => {
      if (!element) return null;
      const css = getComputedStyle(element);
      return { tag: element.tagName, connected: element.isConnected, rect: element.getBoundingClientRect().toJSON(),
        attributes: Object.fromEntries(Array.from(element.attributes).filter(({ name }) =>
          /^(data-(?:pui|projection|material|previewer|demo|theme|runtime|site)|aria-)/.test(name) || name === 'role').map(({ name, value }) => [name, value])),
        css: { width: css.width, height: css.height, minHeight: css.minHeight, paddingTop: css.paddingTop,
          paddingBottom: css.paddingBottom, boxSizing: css.boxSizing, display: css.display, fontSize: css.fontSize, zoom: css.zoom } };
    };
    const previewer = document.querySelector('[data-previewer-id]');
    const scope = previewer?.querySelector('[data-projection-scope]');
    return { at: globalThis.performance.now(), timeOrigin: globalThis.performance.timeOrigin, url: location.href,
      viewport: { width: innerWidth, height: innerHeight, dpr: devicePixelRatio },
      rootFont: getComputedStyle(document.documentElement).fontSize, rootZoom: getComputedStyle(document.documentElement).zoom,
      theme: document.documentElement.dataset.theme ?? null, darkClass: document.documentElement.classList.contains('dark'),
      prefersDark: matchMedia('(prefers-color-scheme: dark)').matches,
      reducedMotion: matchMedia('(prefers-reduced-motion: reduce)').matches,
      language: navigator.language, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, fontStatus: document.fonts.status,
      header: read(document.querySelector('[data-docs-site-header]')),
      headerRuntime: Array.from(document.querySelectorAll('.site-header-runtime')).map((element) => ({ ...read(element), text: element.textContent?.trim() })),
      main: read(document.querySelector('.main-pane')), previewer: read(previewer), scope: read(scope),
      committedRuntime: previewer?.__previewer__?.getCurrentRuntime?.() ?? null,
      panel: read(previewer?.querySelector('[data-panel="preview"]')),
      content: read(scope?.querySelector('[data-projection-content]')),
      menuTriggers: Array.from(previewer?.querySelectorAll('[aria-haspopup="menu"]') ?? []).map(read),
      scenes: Array.from(document.querySelectorAll('[data-material-scene]')).map((scene) => ({ scene: read(scene), flow: read(scene.children[1]) })),
      overflow: { documentScrollWidth: document.documentElement.scrollWidth, documentClientWidth: document.documentElement.clientWidth,
        documentScrollHeight: document.documentElement.scrollHeight, documentClientHeight: document.documentElement.clientHeight,
        bodyScrollWidth: document.body.scrollWidth, bodyClientWidth: document.body.clientWidth,
        horizontalDelta: document.documentElement.scrollWidth - document.documentElement.clientWidth,
        scrollX, scrollY }, activeElement: read(document.activeElement) };
  });
}
async function runContext(viewport) {
  const name = `${viewport.width}x${viewport.height}`;
  const result = { name, viewport, start: now(), independentObservationBudgetMs: 60000, pageErrors: [], console: [],
    offOriginBlocked: [], websocketBlocked: [], embeddedRequests: [], failedRequests: [], responses: [], verificationErrors: [], captureErrors: [], cleanup: {} };
  receipt.contexts.push(result);
  const context = await browser.newContext({ viewport, colorScheme: 'light', serviceWorkers: 'block' });
  const initial = await context.storageState(); result.freshStorage = { cookies: initial.cookies.length, origins: initial.origins.length, suppliedStorageState: false };
  assert.equal(initial.cookies.length, 0); assert.equal(initial.origins.length, 0);
  const pending = new Set(); let page; const deadline = Date.now() + 60000;
  const remaining = (cap) => { const n = Math.min(cap, deadline - Date.now()); if (n <= 0) throw Error('Independent page observation60s expired'); return n; };
  try {
    await context.route('**/*', async (route) => {
      const request = route.request(), url = new URL(request.url());
      if (url.protocol === 'data:' || url.protocol === 'blob:') { result.embeddedRequests.push({ url: url.protocol, resourceType: request.resourceType() }); return route.continue(); }
      if (url.origin !== origin) { result.offOriginBlocked.push({ url: url.href, resourceType: request.resourceType() }); return route.abort('blockedbyclient'); }
      return route.continue();
    });
    await context.routeWebSocket('**/*', async (route) => { result.websocketBlocked.push({ url: route.url() }); await route.close({ code: 1008, reason: 'Local static observation has no websocket transport' }); });
    page = await context.newPage(); page.setDefaultTimeout(20000);
    page.on('pageerror', (error) => result.pageErrors.push(errorText(error)));
    page.on('console', (message) => result.console.push({ type: message.type(), text: message.text(), location: message.location() }));
    page.on('requestfailed', (request) => result.failedRequests.push({ url: request.url(), resourceType: request.resourceType(), error: request.failure() }));
    page.on('response', (response) => {
      const work = (async () => {
        const url = new URL(response.url()); const row = { url: response.url(), status: response.status(), resourceType: response.request().resourceType(), headers: await response.allHeaders() };
        result.responses.push(row);
        if (url.protocol !== 'http:' || url.origin !== origin) { row.notArtifactHTTP = true; return; }
        if (row.status >= 300 && row.status < 400) { row.redirect = row.headers.location; return; }
        if (row.status !== 200) { result.verificationErrors.push({ url: row.url, status: row.status }); return; }
        let relative = decodeURIComponent(url.pathname).slice(1); if (!relative || relative.endsWith('/')) relative += 'index.html';
        const member = members.get(relative); row.member = relative;
        const bytes = await response.body(); row.bytes = bytes.length; row.sha256 = digest(bytes);
        row.expectedSHA256 = member?.sha256 ?? null; row.expectedBytes = member?.size ?? null;
        row.expectedMime = mime[path.extname(relative).toLowerCase()] ?? 'application/octet-stream';
        row.byteEqual = !!member && row.bytes === member.size && row.sha256 === member.sha256;
        row.mimeEqual = row.headers['content-type'] === row.expectedMime;
        if (!row.byteEqual || !row.mimeEqual) result.verificationErrors.push({ url: row.url, member: relative, byteEqual: row.byteEqual, mimeEqual: row.mimeEqual });
      })().catch((error) => result.verificationErrors.push({ url: response.url(), error: errorText(error) }));
      pending.add(work); work.finally(() => pending.delete(work));
    });
    // The missing trailing slash deliberately exercises the existing directory308 rule.
    const navigation = await page.goto(origin + '/en/ui-libraries/liquid-glass/dropdown-menu', { waitUntil: 'networkidle', timeout: remaining(30000) });
    result.navigation = { status: navigation?.status(), finalURL: page.url(), redirectedFrom: navigation?.request().redirectedFrom()?.url() ?? null };
    assert.equal(navigation?.status(), 200); assert.equal(page.url(), origin + '/en/ui-libraries/liquid-glass/dropdown-menu/');
    const previewer = page.locator('[data-previewer-id]').first(); await previewer.waitFor({ state: 'visible', timeout: remaining(20000) });
    const previewerId = await previewer.getAttribute('data-previewer-id', { timeout: remaining(20000) }); assert(previewerId);
    await page.waitForFunction(readyPredicate, { previewerId, expectedCount: 2, readySelector: '[aria-haspopup="menu"]', runtime: 'wc', label: 'Web Components' }, { timeout: remaining(20000) });
    result.readiness = { passed: true, observedAt: now(), previewerId, runtime: 'wc', expectedMenuTriggerCount: 2, sourcePredicateSHA256: preparation.readiness.generatedSHA256 };
    result.state = await bounded(observation(page), remaining(5000), 'state');
    assert.equal(result.state.rootFont, '16px'); assert.equal(result.state.prefersDark, false); assert.equal(result.state.darkClass, false); assert.equal(result.state.committedRuntime, 'wc');
  } catch (error) { result.originalFailureCaptured = true; result.originalError = errorText(error); }
  finally {
    if (page && !page.isClosed()) {
      if (!result.state) try { result.failureState = await bounded(observation(page), 3000, 'failure state'); } catch (error) { result.captureErrors.push(errorText(error)); }
      try { const png = path.join(output, `${name}.png`); await page.screenshot({ path: png, fullPage: true, timeout: 5000 }); const bytes = await readFile(png); result.png = { file: path.basename(png), fullPage: true, sha256: digest(bytes), bytes: bytes.length, width: bytes.readUInt32BE(16), height: bytes.readUInt32BE(20) }; } catch (error) { result.captureErrors.push(errorText(error)); }
      try { await bounded(Promise.allSettled([...pending]), 5000, 'response body drain'); } catch (error) { result.captureErrors.push(errorText(error)); }
    }
    try { await context.close(); result.cleanup.contextCloseResolved = true; } catch (error) { result.cleanup.contextError = errorText(error); }
    try { await bounded(Promise.allSettled([...pending]), 5000, 'closed response drain'); } catch (error) { result.captureErrors.push(errorText(error)); }
    result.cleanup.responseReadsPending = pending.size;
    result.local404 = result.responses.filter(row => row.status === 404 && row.url.startsWith(origin));
    result.consoleErrors = result.console.filter(row => row.type === 'error');
    result.diagnosticCounts = { pageErrors: result.pageErrors.length, consoleErrors: result.consoleErrors.length,
      requestFailed: result.failedRequests.length, local404: result.local404.length,
      offOriginBlocked: result.offOriginBlocked.length, websocketBlocked: result.websocketBlocked.length,
      verificationErrors: result.verificationErrors.length, captureErrors: result.captureErrors.length };
    result.verifiedHTTPResponses = result.responses.filter(row => row.byteEqual && row.mimeEqual).length;
    result.uniqueVerifiedMembers = new Set(result.responses.filter(row => row.byteEqual).map(row => row.member)).size;
    result.end = now();
    result.ok = !result.originalFailureCaptured && !!result.readiness?.passed && !!result.png && result.pageErrors.length === 0 && result.consoleErrors.length === 0 && result.failedRequests.length === 0 && result.local404.length === 0 && result.verificationErrors.length === 0 && result.captureErrors.length === 0 && result.offOriginBlocked.length === 0 && result.websocketBlocked.length === 0 && pending.size === 0 && result.cleanup.contextCloseResolved === true;
    await save(`${name}.json`, result);
  }
}
try {
  receipt.integrityBefore = await verifyCompleteTree();
  server = createServer(async (request, response) => {
    const record = { at: now(), method: request.method, url: request.url, host: request.headers.host }; serverRequests.push(record);
    const reply = (status, text, extra = {}) => { record.status = status; response.writeHead(status, { 'Cache-Control': 'no-store, max-age=0', 'X-Content-Type-Options': 'nosniff', ...extra }); response.end(request.method === 'HEAD' ? undefined : text); };
    try {
      if (!['GET', 'HEAD'].includes(request.method)) return reply(405, 'Read-only local diagnostic');
      if (request.headers.host !== new URL(origin).host) return reply(404, 'Unknown local origin');
      const raw = String(request.url).split('?')[0]; const decoded = decodeURIComponent(raw);
      if (!decoded.startsWith('/') || /[\\\u0000-\u001f\u007f]/.test(decoded) || decoded.split('/').some(p => p === '.' || p === '..')) return reply(400, 'Invalid path');
      const filename = path.resolve(root, '.' + decoded); if (!filename.startsWith(root + path.sep) && filename !== root) return reply(400, 'Invalid path');
      let info; try { info = await lstat(filename); } catch (error) { if (error.code === 'ENOENT' || error.code === 'ENOTDIR') return reply(404, 'Not found'); throw error; }
      if (info.isSymbolicLink()) return reply(404, 'Not found');
      if (info.isDirectory() && !decoded.endsWith('/')) return reply(308, '', { Location: raw + '/' + String(request.url).slice(raw.length) });
      const target = info.isDirectory() ? path.join(filename, 'index.html') : filename;
      const relative = path.relative(root, target).split(path.sep).join('/'); const member = members.get(relative); if (!member) return reply(404, 'Not in complete artifact');
      const bytes = await readFile(target); assert.equal(digest(bytes), member.sha256, relative); assert.equal(bytes.length, member.size, relative);
      record.member = relative; record.sha256 = digest(bytes); record.bytes = bytes.length;
      return reply(200, bytes, { 'Content-Type': mime[path.extname(target).toLowerCase()] ?? 'application/octet-stream', 'Content-Length': bytes.length });
    } catch (error) { record.error = errorText(error); if (!response.headersSent) reply(503, 'Local diagnostic server error'); else response.destroy(); }
  });
  server.on('connection', socket => { sockets.add(socket); socket.on('close', () => sockets.delete(socket)); });
  server.listen(0, '127.0.0.1'); await once(server, 'listening'); origin = `http://127.0.0.1:${server.address().port}`; receipt.origin = origin;
  browser = await chromium.launch({ executablePath: chrome, headless: true, args: ['--disable-dev-shm-usage', '--no-sandbox'], timeout: 30000 });
  receipt.chromiumVersion = browser.version(); assert.equal(receipt.chromiumVersion, '155.0.8059.39');
  for (const viewport of [{ width: 1440, height: 1100 }, { width: 320, height: 1000 }]) await runContext(viewport);
} catch (error) { receipt.errors.push(errorText(error)); }
finally {
  if (browser) { try { await browser.close(); receipt.cleanup.browserCloseResolved = true; receipt.cleanup.browserConnectedAfter = browser.isConnected(); } catch (error) { receipt.cleanup.browserError = errorText(error); } }
  if (server) { try { server.closeAllConnections(); await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve())); receipt.cleanup.serverCloseResolved = true; receipt.cleanup.serverListeningAfter = server.listening; receipt.cleanup.socketsRemaining = sockets.size; } catch (error) { receipt.cleanup.serverError = errorText(error); } }
  try { receipt.integrityAfter = await verifyCompleteTree(); } catch (error) { receipt.errors.push(errorText(error)); }
  receipt.end = now(); receipt.success = receipt.errors.length === 0 && receipt.contexts.length === 2 && receipt.contexts.every(c => c.ok) && receipt.cleanup.browserCloseResolved && receipt.cleanup.serverCloseResolved;
  receipt.boundaries = ['No style/state injection, saved preferences, simulated input, new build or asset pruning.', 'Observed same-origin HTTP200 bodies are individually hash/size/MIME compared with full artifact manifest; redirects are metadata and generated data/blob resources are separately identified, not falsely mapped to static files.', 'FullPage PNG follows recorded readiness/state; it is not first-visible-frame, optical, all-site-pages/allAdapters/AT/installed-package/motion acceptance.', 'This independent60s observation window is not Search original1s or the269-case suite. Failure capture/drain is post-verdict and does not change that observation verdict.', 'Browser.close/context.close and HTTP.close completion are recorded; no unmeasured physical process hard-deadline/OSexit-code claim.'];
  await save('server-requests.json', serverRequests); await save('receipt.json', receipt); console.log(JSON.stringify({ success: receipt.success, output, contexts: receipt.contexts.map(c => ({ name: c.name, ok: c.ok, error: c.originalError, verifiedHTTPResponses: c.verifiedHTTPResponses })), cleanup: receipt.cleanup }));
}
process.exitCode = receipt.success ? 0 : 1;
