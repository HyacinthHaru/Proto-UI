import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {extractBoundedZip,materializeBoundedZip} from '<WORKTREE>/scripts/preview/extract-artifact.mjs';
const root=path.dirname(fileURLToPath(import.meta.url)),target=path.join(root,'extracted');
try {await fs.lstat(target);throw new Error('Refuse existing extraction target');} catch(error) {if(error.code!=='ENOENT')throw error;}
const data=await fs.readFile(path.join(root,'artifacts/site.zip'));
const files=extractBoundedZip(data);
const rows=[...files].sort(([a],[b])=>a.localeCompare(b,'en')).map(([name,value])=>({path:name,type:'file',size:value.length,sha256:crypto.createHash('sha256').update(value).digest('hex')}));
const materialized=await materializeBoundedZip(data,target);if(materialized.files!==rows.length)throw new Error('Complete extraction mismatch');
await fs.writeFile(path.join(root,'members.json'),JSON.stringify(rows,null,2)+'\n');
const old=JSON.parse(await fs.readFile('<TASK_STATE>/continue-20261023T123632Z/preview-4d4a/members.json','utf8'));
const oldMap=new Map(old.map(x=>[x.path,x]));const added=rows.filter(x=>!oldMap.has(x.path));const nextMap=new Map(rows.map(x=>[x.path,x]));const removed=old.filter(x=>!nextMap.has(x.path));const changed=rows.filter(x=>oldMap.has(x.path)&&oldMap.get(x.path).sha256!==x.sha256).map(x=>({path:x.path,before:oldMap.get(x.path),after:x}));
const summary={sourceHead:'d92141c57ebab192f3741e7336c1ec0f24b61c5c',files:rows.length,html:rows.filter(x=>x.path.endsWith('.html')).length,expandedBytes:rows.reduce((a,x)=>a+x.size,0),compressedBytes:data.length,completeFilesRetained:true,pagesOrResourcesPruned:0,defaultBoundedExtractor:true,scope:'Newofficialartifact fullyextracted. Not independentproducerdirectory; no freshnativepreviewjourney yet.',differenceFromPreviousActual4dArtifact:{added,removed,changed,unchanged:rows.length-added.length-changed.length}};
await fs.writeFile(path.join(root,'extraction-summary.json'),JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify({...summary,differenceFromPreviousActual4dArtifact:{added:added.length,removed:removed.length,changed:changed.length,unchanged:summary.differenceFromPreviousActual4dArtifact.unchanged}}));
