from pathlib import Path
import json,re,gzip,subprocess,hashlib
P=Path(__file__).resolve().parent;O=Path('<TASK_STATE>/continue-20261023T123632Z/preview-4d4a/extracted');N=P/'extracted';d=json.loads((P/'independent-generated-html-audit.json').read_text());m=json.loads((P/'generated-filename-map.json').read_text());names={Path(k).name:Path(v).name for k,v in m.items()};rx=re.compile('|'.join(re.escape(x) for x in names));maps={};rows=[]
patterns=[r'\bid="([^"]+-label-[a-z0-9]+)"',r'\b(pp-[a-z0-9]+)\b',r'\b(home-demo-previewer-projection-[a-z0-9]+)\b',r'\b(code-example-[a-z0-9]+)\b',r'\b(install-command-[a-z0-9]+)\b',r'\bid="(wiki-term-[^"]+-[a-z0-9]{8})"']
for row in d['html']['residual']:
 rel=row['path'];a=rx.sub(lambda z:names[z[0]],(O/rel).read_text());b=(N/rel).read_text();mapping={};sizes=[]
 for pattern in patterns:
  x=list(dict.fromkeys(re.findall(pattern,a)));y=list(dict.fromkeys(re.findall(pattern,b)));assert len(x)==len(y),(rel,pattern);mapping.update(zip(x,y));sizes.append(len(x))
 assert len(set(mapping.values()))==len(mapping)
 r=re.compile('|'.join(re.escape(x) for x in sorted(mapping,key=len,reverse=True)));projected=r.sub(lambda z:mapping[z[0]],a);maps[rel]=(mapping,r)
 rows.append({'path':rel,'identityCategoryCounts':sizes,'bijection':True,'exactAfterFilenameAndAdditionalSourceDeclaredIdentityProjection':projected==b})
fr=[]
for row in d['pagefind']['residual']:
 a=json.loads(gzip.decompress((O/'pagefind/fragment'/row['old']).read_bytes())[12:]);b=json.loads(gzip.decompress((N/'pagefind/fragment'/row['new']).read_bytes())[12:]);rel=row['url'].lstrip('/')+'index.html';mp,r=maps[rel]
 def sub(x):
  if isinstance(x,str):return r.sub(lambda z:mp[z[0]],x)
  if isinstance(x,list):return [sub(y) for y in x]
  if isinstance(x,dict):return {k:sub(v) for k,v in x.items()}
  return x
 fr.append({'url':row['url'],'exactStructuredJSONAfterPageIdentityProjection':sub(a)==b})
source=[]
for rel in ['apps/www/src/components/CodeExample.astro','apps/www/src/components/WikiTerm.astro','apps/www/src/components/InstallCommandCard.astro','apps/www/src/components/PrototypePreviewer/HomeDemoPreviewer.astro']:
 b=subprocess.check_output(['git','show','d92141c57ebab192f3741e7336c1ec0f24b61c5c:'+rel],cwd='<WORKTREE>');source.append({'path':rel,'sha256':hashlib.sha256(b).hexdigest(),'randomLines':[{'line':i,'text':l} for i,l in enumerate(b.decode().splitlines(),1) if 'Math.random' in l]})
result={'source':source,'htmlAdditionalSeven':rows,'pagefindAdditionalFive':fr,'htmlFinalExactCount':d['html']['exactAfterIdentityAndFilenameProjection']+sum(x['exactAfterFilenameAndAdditionalSourceDeclaredIdentityProjection'] for x in rows),'pagefindFinalExactCount':d['pagefind']['sameAfterPageHTMLIdentityProjection']+sum(x['exactStructuredJSONAfterPageIdentityProjection'] for x in fr),'method':'Exact full-text/structured-value projection with per-page source-declared identity bijections; original files unmodified.'}
(P/'independent-generated-tail-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
