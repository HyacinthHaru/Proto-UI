from pathlib import Path
import json,zipfile,hashlib,datetime
R=Path(__file__).parent;receipts=[]
for name in ['site.zip','binding.zip']:
 p=R/'artifacts'/name;v=json.loads((R/'artifacts'/(name+'.receipt.json')).read_text());b=p.read_bytes();assert v['exit']==0 and len(b)==v['artifact']['size_in_bytes']and hashlib.sha256(b).hexdigest()==v['sha256']and 'sha256:'+v['sha256']==v['artifact']['digest'];receipts.append(v)
with zipfile.ZipFile(R/'artifacts/binding.zip')as z:
 assert z.namelist()==['binding.txt']and z.testzip()is None;text=z.read('binding.txt').decode()
expected='PR=921\nHEAD=d92141c57ebab192f3741e7336c1ec0f24b61c5c\n';assert text==expected
(R/'binding.txt').write_text(text)
(R/'binding-parser-correction.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalAttempt':'download.py after successful one-timebinarydownloads failed its localbinding assertion','wrongPremise':'One-line PR+space+SHA; not actualworkflowoutput','correctContract':'.github/workflows/intranet-preview-build.yml:69 prints PR= and HEAD= on separate lines before contributorcode','actualText':text,'originalScriptPreserved':True,'downloadsRepeated':False,'notAnArtifactOrTestFailure':True},indent=2)+'\n')
(R/'artifact-binding.json').write_text(json.dumps({'sourceHead':'d92141c57ebab192f3741e7336c1ec0f24b61c5c','sourceTree':'8dda1bb967cc066db4036e7e085cb7d5c93ebd75','run':40041038753,'job':120711921726,'downloads':receipts,'bindingText':text,'scope':'Actualofficialuploadartifact, wholeZIP retained. Producer-dist versus preuploadZIP is canonicaljob evidence; localdownloadedZIP versus ownextraction is separateadmission.'},indent=2)+'\n');print(text)
