实时只读同步覆盖 2026-10-23T22:54:35.601682+00:00 至 2026-10-23T22:57:13.772868+00:00 UTC（新加坡时间2026-10-24早间），非原子快照；head/main首尾一致，HTTP/GraphQL读取errors=[]，所有分页完整。没有测试、browser、源码更改、Actions操作、日志或artifact下载。

main仍81339ddce9b6fc9b488331e10a533884ace96593。#921仍OPEN、Ready、head4d4a7ec071dd83756444cbebf5a4c8b3bea81bcf，base81339，MERGEABLE/BLOCKED/REVIEW_REQUIRED；76comments、0reviews、0reviewThreads。#926仍OPEN Draft、head67e8392b1a8c7c4701679a373f5d630545a525aa，APIbase6d318afced7c9e6d4a99c5b6a9b175746560b3a9（与当前main另列，不能自动替换），MERGEABLE/BLOCKED/REVIEW_REQUIRED；36comments、0reviews/threads。Issue883仍open、22comments，最后更新时间2026-10-18T03:53:08Z。

反馈完整对账：对比R21已保存的完整评论，#921只新增作者自己的6367557477，创建14:43:58、编辑15:01:17UTC，正是前轮已发布终态checkpoint；其余75条无编辑。#92636条、#88322条完全无新增/编辑/删除。没有新的外部作者反馈或formalreview。

#921当前head所有CI：38workflow runs全部终态，28success/10failure；106check-runs（filter=all）为71success/35failure；105个latestjob全部终态70success/35failure，103artifact仅metadata。主CI39965405460仍真实FAILURE，22jobs13success/9failure。Vercel单独的commitstatus为failure，description是Authorization required to deploy；它不是测试用例失败，也未进行授权操作。

#926当前head：41workflow runs全部终态，21success/19failure/1cancelled；129check-runs为67success/59failure/3cancelled；114个latestjob全部终态60success/52failure/2cancelled，93artifact仅metadata。主CI39856421967为FAILURE，22jobs12success/10failure。Vercel保留2条历史status，最新是success，较早pending不是当前待执行。check-runs的all历史与jobs的latest口径不同，不能混作同一统计集合。

原始状态、全部评论、reviewThreads（含nested分页逻辑）、check/status/run/job/artifact页与每次读取SHA回执均在本目录；ci921/workflow-index.json和ci926/workflow-index.json列每run的精确终态。metadata不提供新的实际用例/失败predicate结论，已有C失败仍按旧source-bound报告索引，不重标为本轮执行。
