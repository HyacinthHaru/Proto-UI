`Browser.setContentsSize` 是当前可用的精确内容尺寸接口：本地Playwright1.58.2协议要求windowId及至少一个正整数width/height，单位DIP。与指定outer bounds的`setWindowBounds`不同，固定155源码先读实际contents size，再把“目标content−当前content”差加到window bounds；没有写死87。它要求normal窗口与可用activecontents，并刻意绕过会限制screenworkarea的BrowserView.SetContentsSize。[155原实现](https://chromium.googlesource.com/chromium/src/+/refs/tags/155.0.8059.39/chrome/browser/devtools/protocol/browser_handler.cc#209)

155的BrowserView.GetBounds是widget window bounds，而GetContentsSize是active contents container size。Root实测outer1440×900→1440×987、requested content1440×900，在无其它bounds变化/约束的假设下，与原contents height813的算式900+(900−813)=987一致；这是根据源码和控制结果的推断，不是内部GetContentsSize直接读数。87可包含Chrome UI/frame/contentlayout占用，不能唯一命名为macOS原生装饰常量。[BrowserView定义](https://chromium.googlesource.com/chromium/src/+/refs/tags/155.0.8059.39/chrome/browser/ui/views/frame/browser_view.cc#2168)

145.0.7632.6与155.0.8059.39的fullChrome和headless-shell源码均实现该API。155已由本次实际ACK验证；145这里只确认源码支持，没有运行145控制。fullChrome加headlessflag与headless-shell是不同二进制路径，不能用shell的直接containerbounds实现解释fullChromeUI差。[145实现](https://chromium.googlesource.com/chromium/src/+/refs/tags/145.0.7632.6/chrome/browser/devtools/protocol/browser_handler.cc#201) / [155 shell实现](https://chromium.googlesource.com/chromium/src/+/refs/tags/155.0.8059.39/headless/lib/browser/protocol/browser_handler.cc#137)

本地PWcrPage.js728–786明确：headless时insets为0；headfulDarwin才补2×80。它并行发setWindowBounds与Emulation.setDeviceMetricsOverride，不调用setContentsSize。因此CSS viewport1440×900本身并不证明nativecontents也达到该尺寸。源到实际的归属只限此已读版本，不引用旧139/141问题作根因。

Root已保存控制为同ownerID1、同CSS点(176,883.5)、CSS1440×900/DPR1：A1 9021→9021；B设置exactcontent后9021→8621；A2恢复outerbounds后8621→8621。没有重置所有初始状态，不能称完美同态ABA。外框恢复ACK/读回明确；没有在本审查中再执行。

有界候选可以只在该case自有newPage后、原goto前，用真实windowId请求声明的width×900内容尺寸并detach；不加87/200魔数、不改CSS/原输入/1s/180s，也不扩全harness。源码返回success只代表SetBounds调用完成，不证明compositor barrier。1440控制不能代替320/390或145执行；Root后续focused三宽绿另有其source/receipt，不回填本报告。

固定155 tag解析为3ff7ac5a9224be9156d7f8703a06e22890aafd34；CFT metadata revision1697595对应branch point，不是releasecommit本身。[固定tag](https://chromium.googlesource.com/chromium/src/+/refs/tags/155.0.8059.39) 所有本地/primarysource SHA、行号、原HTTPS读取失败与成功回执及事实/推断/unknown分栏保存在report.json。无W修改、browser/test/CDPmutation或发布。partial/ABSTAIN，非正式批准。
