import fs from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const directory = path.dirname(fileURLToPath(import.meta.url));
const parent = path.dirname(directory);
const candidateName = 'candidate.ts';
const ts = createRequire('<WORKTREE>/package.json')('typescript');
const hash = (source) => crypto.createHash('sha256').update(source).digest('hex');
const original = execFileSync('git', ['show', '4d4a7ec071dd83756444cbebf5a4c8b3bea81bcf:apps/www/src/content/docs/zh-cn/site-native-links.browser.test.ts'], {cwd:'<WORKTREE>',encoding:'utf8'});
const candidate = fs.readFileSync(path.join(parent, candidateName), 'utf8');
const actions = new Set(['press', 'click', 'dblclick', 'focus', 'fill', 'check', 'uncheck', 'hover', 'tap', 'move', 'down', 'up', 'wheel', 'insertText']);
const layoutNames = new Set(['getBoundingClientRect', 'getComputedStyle', 'clientHeight', 'scrollHeight', 'clientWidth', 'scrollWidth', 'offsetHeight', 'offsetWidth']);
function inspect(source) {
  const file = ts.createSourceFile('source.ts', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const result = { parseDiagnostics: file.parseDiagnostics.map(d => ts.flattenDiagnosticMessageText(d.messageText, '\n')), cases: [], assertions: [], inputs: [], polls: [], waits: [], lifecycleBudgets: [], closeCalls: [], layoutCounts: {}, timers: [], evaluates: 0 };
  const at = (node) => file.getLineAndCharacterOfPosition(node.getStart(file)).line + 1;
  const text = (node) => node.getText(file);
  function visit(node) {
    if (ts.isCallExpression(node)) {
      const callee = text(node.expression).replace(/\s+/g, '');
      if (['it', 'beforeAll', 'afterAll'].includes(callee)) {
        const record = { callee, timeout: node.arguments[callee === 'it' ? 2 : 1] ? text(node.arguments[callee === 'it' ? 2 : 1]) : null };
        result.lifecycleBudgets.push(record);
        if (callee === 'it') result.cases.push({ title: text(node.arguments[0]), timeout: record.timeout });
      }
      if (callee === 'setTimeout') result.timers.push({ line: at(node), call: text(node) });
      if (ts.isPropertyAccessExpression(node.expression)) {
        const method = node.expression.name.text;
        if (actions.has(method)) result.inputs.push(text(node));
        if (['waitFor', 'waitForFunction', 'waitForURL', 'waitForLoadState'].includes(method)) result.waits.push(text(node));
        if (method === 'evaluate' || method === 'evaluateAll') result.evaluates++;
        if (callee === 'context.close') result.closeCalls.push(text(node));
        if (callee === 'expect.poll') result.polls.push(text(node));
        let receiver = node.expression.expression;
        while (ts.isPropertyAccessExpression(receiver)) receiver = receiver.expression;
        if (ts.isCallExpression(receiver) && ['expect', 'expect.poll'].includes(text(receiver.expression).replace(/\s+/g, ''))) result.assertions.push(text(node));
        if (layoutNames.has(method)) result.layoutCounts[method] = (result.layoutCounts[method] ?? 0) + 1;
      }
      if (callee === 'getComputedStyle') result.layoutCounts.getComputedStyle = (result.layoutCounts.getComputedStyle ?? 0) + 1;
    }
    if (ts.isPropertyAccessExpression(node) && layoutNames.has(node.name.text) && !ts.isCallExpression(node.parent)) result.layoutCounts[node.name.text] = (result.layoutCounts[node.name.text] ?? 0) + 1;
    ts.forEachChild(node, visit);
  }
  visit(file);
  return result;
}
const a = inspect(original), b = inspect(candidate);
const equal = (key) => JSON.stringify(a[key]) === JSON.stringify(b[key]);
const checks = Object.fromEntries(['cases', 'assertions', 'inputs', 'polls', 'waits', 'lifecycleBudgets', 'closeCalls', 'layoutCounts'].map(key => [key + 'Preserved', equal(key)]));
const report = {
  kind: 'Static TypeScript AST/source-text comparison only',
  candidate: candidateName, originalSHA256: hash(original), candidateSHA256: hash(candidate),
  checks, counts: { caseDeclarations: a.cases.length, assertionCallSites: a.assertions.length, inputCallSites: a.inputs.length,
    pollCallSites: a.polls.length, originalEvaluateCallSites: a.evaluates, candidateEvaluateCallSites: b.evaluates,
    originalCloseCallSites: a.closeCalls.length, candidateCloseCallSites: b.closeCalls.length },
  original: a, candidateAnalysis: b, noExecution: true,
};
const output = path.join(directory, candidateName.replace(/\.ts$/, '') + '.ast-audit.json');
fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ output, originalSHA256: report.originalSHA256, candidateSHA256: report.candidateSHA256, checks, counts: report.counts, parseDiagnostics: b.parseDiagnostics }));
