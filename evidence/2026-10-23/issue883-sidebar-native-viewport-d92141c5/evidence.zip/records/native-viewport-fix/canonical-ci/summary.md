# d921 canonical CI metadata checkpoint

Read-only observation: **2026-10-23T23:42:57.505096+00:00 through 2026-10-23T23:43:26.893945+00:00**. Pagination completed with **0 API errors**. This is a non-atomic, **nonterminal** checkpoint; no further polling was performed.

The PR head is `d92141c57ebab192f3741e7336c1ec0f24b61c5c` and its source Git tree is `8dda1bb967cc066db4036e7e085cb7d5c93ebd75`. Head and main (`81339ddce9b6fc9b488331e10a533884ace96593`) are identical at the beginning and end. PR #921 is OPEN, non-draft, MERGEABLE / BLOCKED, with REVIEW_REQUIRED. Its 76 comments, 0 reviews and 0 review threads have no additions or edits relative to the earlier R22 read.

The main CI **40041038837** is queued. Its **8 actually materialized jobs are all queued**:

| Job | ID | State |
|---|---:|---|
| rust | 120711921785 | queued |
| public_package_plan | 120711921923 | queued |
| rust-interop | 120711921957 | queued |
| lockstep-check | 120711921985 | queued |
| rust-macos | 120711922001 | queued |
| type-check | 120711922010 | queued |
| test-plan | 120711922012 | queued |
| release-scan | 120711922090 | queued |

**test-general, browser shards and public_package_build have not materialized in this read.** No plan-derived shard count, Vitest count, package count or runtime result is claimed. The preview run **40041038753**, job **120711921726**, is queued and has **0 artifact metadata entries**. No new-head site artifact or admission result is available in this checkpoint.

The workflow list contains **38 runs: 5 success, 1 failure, 9 in progress, 23 queued**. The separate earlier check read contains **92 check runs: 5 success, 20 in progress, 67 queued** and 39 suites. Later per-run reads contain **91 materialized latest jobs: 7 success, 1 failure, 16 in progress, 67 queued**, plus **11 artifact metadata entries**. This time difference is retained; these are not one atomic status matrix.

The observed failed workflow is Bootstrap state-controls evidence, run **40041038833**, job **120711921844**. This checkpoint contains metadata only and does not identify its predicate or attribute it to C. Vercel separately reports “Authorization required to deploy.” No review, acceptance or runtime interpretation is inferred.

All run and job IDs, timestamps, pagination totals and artifact metadata are in `summary.json` and the original endpoint files. The check-URL/run-list union covers all 38 current-head runs; no referenced different-head run was included as current.

| Workflow | Run ID | Observed state | Jobs / artifacts |
|---|---:|---|---:|
| Material source specialization | 40041038699 | completed / success | 1 / 2 |
| Matched reading reference evidence | 40041038821 | in_progress / — | 1 / 0 |
| Bounded preference source evidence | 40041038801 | completed / success | 1 / 1 |
| Overlay portal direction native evidence | 40041038748 | completed / success | 1 / 1 |
| Homepage visual evidence | 40041038971 | in_progress / — | 9 / 3 |
| Accordion family native evidence | 40041038692 | queued / — | 1 / 0 |
| TOC shared motion evidence | 40041038752 | queued / — | 1 / 0 |
| Passive atom documentation evidence | 40041038795 | queued / — | 1 / 0 |
| Finf representative feature screenshots | 40041038783 | queued / — | 18 / 0 |
| CI | 40041038837 | queued / — | 8 / 0 |
| Finf Button ghost component evidence | 40041038807 | queued / — | 1 / 0 |
| Dialog available-space matched evidence | 40041038737 | queued / — | 2 / 0 |
| Website startup and theme evidence | 40041038812 | queued / — | 2 / 0 |
| Intranet preview build PR #921 | 40041038753 | queued / — | 1 / 0 |
| Private initial optical paint evidence | 40041038725 | queued / — | 1 / 0 |
| Liquid Glass material and library evidence | 40041039071 | queued / — | 11 / 0 |
| Static Template style evidence | 40041039103 | queued / — | 1 / 0 |
| Actual transition GIF source frames | 40041039107 | queued / — | 4 / 0 |
| Brutalist contrast audit evidence | 40041038898 | queued / — | 5 / 0 |
| Runtime layout and loading mask native evidence | 40041038847 | queued / — | 2 / 0 |
| Header Select elevation evidence | 40041038863 | queued / — | 2 / 0 |
| Documentation image preview evidence | 40041038853 | queued / — | 1 / 0 |
| Select target alignment evidence | 40041039007 | queued / — | 1 / 0 |
| V2 Web optical artifact evidence | 40041038889 | queued / — | 1 / 0 |
| Field family native evidence | 40041038791 | queued / — | 1 / 0 |
| Finf Button ghost native evidence | 40041038792 | queued / — | 1 / 0 |
| Liquid Surface elevation control evidence | 40041039085 | queued / — | 1 / 0 |
| Quick-start first-frame native evidence | 40041038869 | queued / — | 1 / 0 |
| Liquid Card candidate producer evidence | 40041038958 | in_progress / — | 1 / 1 |
| Collapsible projection evidence | 40041038789 | in_progress / — | 1 / 0 |
| Bootstrap state-controls evidence | 40041038833 | completed / failure | 1 / 1 |
| Native typography evidence | 40041038738 | in_progress / — | 1 / 0 |
| Select draft projection evidence | 40041038735 | in_progress / — | 1 / 0 |
| Library Card first-frame evidence | 40041038786 | in_progress / — | 1 / 0 |
| Static hit inset native evidence | 40041038856 | completed / success | 1 / 1 |
| Browser suite repair evidence | 40041038858 | in_progress / — | 1 / 0 |
| Whitepaper diagram evidence | 40041038911 | completed / success | 1 / 1 |
| Experimental Compiler Button SSR evidence | 40041038925 | in_progress / — | 1 / 0 |

The exact source Git object is verified. Job checkout trees are not yet verified by execution logs. The REST mergeability SHA is a provisional PR ref, not proof that a job checked out that commit. No raw logs, media, tests, browsers, Actions mutations or W/E changes were performed for this checkpoint. Old 4d4a execution evidence remains historical.

**Disposition: partial / ABSTAIN.** This records live metadata and its limits; it is not a formal review approval.
