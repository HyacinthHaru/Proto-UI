# d921 selected completed-job evidence

This additive read covers four terminal jobs and one exact Accordion artifact on **d92141c57ebab192f3741e7336c1ec0f24b61c5c**, tree **8dda1bb967cc066db4036e7e085cb7d5c93ebd75**. Original logs were fetched once; no test, browser, Actions mutation or site ZIP download was performed. The earlier complete metadata snapshot remains unchanged.

Package/types actually checked out synthetic merge **6baaeba8797abfa90c9f5dc63e56947979bd1cea**. Its Git API tree equals d921; its parents are main81339 andd921. Preview and Accordion directly checked out d921. All four logs identify Node24.21.0 and Ubuntu24.04; package measurement records linux/x64, esbuild0.25.12 and zlib1.3.2.1-motley-8002e91.

| Job | Actual result |
|---|---|
| public_package_build120712818575 | 47/47 public packages,47 manifests,9/9 policy tests;4PASS and5ADVISORY budget measurements |
| type-check120711922010 | 943 files,0 errors,0 warnings,14 hints |
| Preview120711921726 | Producer own-source admission1/1;3837 files,104015942 expanded bytes |
| Accordion120711921246 | Workflow guards32/32;original native cases25/25 |

The nine budget measurements retain their strict numeric limits:

| Entry | gzip / strict ceiling | Excess | Policy result |
|---|---:|---:|---|
| lucide/icons/x | 1737 / 3000 | 0 | PASS |
| lucide root | 635749 / 700000 | 0 | PASS |
| core root | 8940 / 7600 | 1340 | ADVISORY |
| runtime root | 90651 / 78500 | 12151 | ADVISORY |
| adapter-react root | 143381 / 106000 | 37381 | ADVISORY |
| adapter-vue root | 142838 / 106000 | 36838 | ADVISORY |
| adapter-web-component root | 170111 / 132000 | 38111 | ADVISORY |
| prototypes-base/button | 3948 / 6000 | 0 | PASS |
| prototypes-shadcn/button | 4952 / 7000 | 0 | PASS |

ADVISORY success does not turn the five overruns into strict passes. Two consumer diagnostics are separate from these nine measurements.

The preview producer reports651 built pages. Its admission compared its own3837-file dist directory with its own pre-upload ZIP (**21186597B**) and passed1 test. Actions then uploaded a separate **21120725B** site archive, artifact12539113546, digest`c77232153b23dde39b37c238a9d2245cbe21b8a136c0b7e6a3c17d52cf37825f`. That archive was not downloaded here; no total HTML-file count, local admission, rendered page or publisherReady claim is added.

Accordion artifact **12539846032** was downloaded once: **6570148B**, SHA256`6de117c1b3149e63d619c2b6fb46dddc364fa68d5b3443447b44e22c3d7d8f02`. All185 unique regular safe members, including90 PNGs, were recomputed for CRC/SHA and extracted-byte equality. PNG pixels were not viewed. Artifact source-sha is d921; the two actual Vite transform receipts mechanically reproduce from exact d921 source, and all7 pinned Playwright1.58.2 source hashes match.

The same successful Space→freshEnter sequence is captured in79 main-world rows, with0 drops/errors. Spaceeventmain:1 at6833.9ms reaches root enabled6834.9 and one press.commit6835.2–6838.8, changing expanded true→false. The target gate disables6924.8 and enables6975.5. FreshEntereventmain:28 at6984.8 reaches enabled6985.2 and one press.commit6985.5–6988.5, changing false→true. Both events target/activate the same physicalmain:2 trigger with keyboardowner/tokenmain:18, routermain:20 and publicReact projectiongeneration2.

The original Space-close poll9/call@2546 passes in51.471604ms; freshEnter poll10/call@2550 passes in24.513023ms. Each has attempt1 and one exact original getter batch. The latter selector samples7044.1–7044.9ms and getter returns true with equal sampled timestamps7045.0; this is0ms at recorded resolution, not a measured zero-cost getter or clock tick. Enter press.after still has controls=null; the later stop sample has the expected controls restored. The journal stops at the next originalTab7132.2. Later finalActiveVue/gen3 is not substituted for input-time React focus.

All6 captured SDK requests settle with matching batches;0 pending/errors/drops and6 evaluator guards pass. contextClosed/disposed are true. **transportComplete remains false**, and complete captured mapping is narrower than all19 poll pairs or every transport event. Observer cost, asynchronous reaction/patch timing, null-event gate attribution and uncalibrated clock limits remain. This is a new positive run and does not explain or erase any earlier natural failure.

At the selected23:50:42–23:50:46 metadata read, main CI40041038837 was still nonterminal, with21 actually materialized jobs. No whole-CI result is inferred. **Disposition: partial / ABSTAIN; no formal approval or maintainer acceptance.**
