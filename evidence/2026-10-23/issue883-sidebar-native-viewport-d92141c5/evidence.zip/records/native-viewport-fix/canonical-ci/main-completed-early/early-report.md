已完成 4 个已终态 job 的一次原日志下载和只读核验，结论为 partial / ABSTAIN，不构成 GitHub 批准。

4 份原日志均 checkout `6baaeba8797abfa90c9f5dc63e56947979bd1cea`；已保存 Git API 对象的 tree 为 `8dda1bb967cc066db4036e7e085cb7d5c93ebd75`，与准确产品 d921 相同，parents 为 main81339 与 d921。本报告不更新根 00:03:29–33 UTC 主 CI 仍 in_progress 的历史快照，不读取其它运行日志。

| Job | 实际结果 | 可证边界 |
|---|---|---|
| General120712889827 | public-docs78项分类漂移，exit1 | 前置15个Node视频解码控制通过；随后公共文档gate失败，repository Vitest未执行 |
| Browser5/8 120712889974 | CJK字体安装step原3分钟超时 | 原日志正在下载61.2MB fonts-noto-cjk；browser执行step实际skipped，不能填Vitest跳过或通过数 |
| Browser3/8 120712890116 | 完整58pass/3fail/0skip | 10文件；LiquidGlass light/dark disabled opacity1≠0.5两红；S4整个case150s超时一红 |
| Browser6/8 120712889965 | 完整169pass/0fail/0skip | 10文件，含真实投射scope5、available-space8、BrutalistButton8、ScrollArea1、focus-intent90 |

仅两个完整分片的小计为227pass/3fail/0skip，不能称8分片总数。

精确的 owner 边界：opacity预期0.5来自LiquidGlass分支，Bootstrap分支预期0.65。当前 draft `P-LIQUID-GLASS-BUTTON-COMMAND-INTERACTION` 与 `C-LIQUID-GLASS-COMMAND-INTERACTION-0001-FOCUS` 明确禁用状态不降低整体host透明度；`COMMAND_DISABLED`也不含opacity。这是原style-test oracle与当前draft方向的具体矛盾。原test、定义和实现的Git blob在main81339/4d/d921均相同；这不是main实际运行证据。当前用户要求保留原断言，交LiquidGlass定义/样式test owner确认迁移，不在本轮改0.5→1、写hostopacity或提升draft保证。原两红继续计入CI。

S4只有150000ms整体deadline，日志未给内部等待栈；不能据测试名断言发生关闭后重绘，也不能归为CLI、owner或focus缺陷。四份材料没有证明当前8行sidebar fixture造成新C生产缺陷。

所有raw日志、job metadata、下载argv/时间/exit/SHA收据均保留；4次GET各一次，无artifact下载、状态轮询、测试、浏览器、源码或外部写入。
