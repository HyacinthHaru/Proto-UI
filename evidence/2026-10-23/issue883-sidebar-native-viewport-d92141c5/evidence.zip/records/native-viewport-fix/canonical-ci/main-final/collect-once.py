from pathlib import Path
import datetime,json,hashlib,subprocess,concurrent.futures,re
P=Path(__file__).resolve().parent;C=P.parent;d=json.loads((C/'summary-selected-4.json').read_text());r=d['runs']['primary'];assert d['head']=='d92141c57ebab192f3741e7336c1ec0f24b61c5c' and r['status']=='completed' and r['conclusion']=='failure';assert len(r['jobs'])==22 and all(j['status']=='completed' for j in r['jobs'])
selected=[]
for j in r['jobs']:
 m=re.search(r'test-browser \((\d+)/8',j['name'])
 if m and int(m[1]) in [1,2,4,7,8]:selected.append((int(m[1]),j))
assert len(selected)==5

def get(pair):
 shard,j=pair;p=P/f"{j['id']}.log";assert not p.exists();(P/f"{j['id']}.metadata-selected.json").write_text(json.dumps(j,indent=2)+'\n');argv=['gh','api',f"repos/Proto-UI/Proto-UI/actions/jobs/{j['id']}/logs"];s=datetime.datetime.now(datetime.timezone.utc).isoformat();res=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90);p.write_bytes(res.stdout);(P/f"{j['id']}.stderr").write_bytes(res.stderr);rec={'shard':shard,'jobId':j['id'],'argv':argv,'startedAt':s,'completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':res.returncode,'bytes':len(res.stdout),'sha256':hashlib.sha256(res.stdout).hexdigest(),'readOnly':True,'attempt':1};(P/f"{j['id']}.download-receipt.json").write_text(json.dumps(rec,indent=2)+'\n');assert res.returncode==0;return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for rec in pool.map(get,sorted(selected)):print(json.dumps(rec),flush=True)
print(json.dumps({'done':True,'logsDownloaded':5,'artifactsDownloaded':0}),flush=True)
