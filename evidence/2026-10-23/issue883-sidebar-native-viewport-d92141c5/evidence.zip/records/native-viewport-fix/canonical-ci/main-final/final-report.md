# d921 primary CI terminal reconciliation

Run40041038837 is completed FAILURE in the00:12:51–00:12:55UTC complete selected read: **22 actual jobs,13 success/9 failure, allterminal**. Every browser rawlog prints syntheticcheckout`6baaeba8797abfa90c9f5dc63e56947979bd1cea`; its existingGitAPIobject maps to source tree`8dda1bb967cc066db4036e7e085cb7d5c93ebd75`, identical tod921. This is not a reuse of old4d results or causes.

Only five newlyterminal logs were fetched once. ExistingGeneral/browser3/5/6 logs were reused. No artifact/media download, test/browser, CI mutation or W/E edit occurred.

| Shard | Job | Actual report boundary |
|---|---:|---|
| 1 | 120712890012 | partial browser output; bounded runtime exit124; no full summary |
| 2 | 120712889991 | partial browser output; bounded runtime exit124; no full summary |
| 3 | 120712890116 | Complete 58pass/3fail/0skip |
| 4 | 120712890044 | Complete 122pass/2fail/0skip |
| 5 | 120712889974 | CJK installation setup failure; no browser execution |
| 6 | 120712889965 | Complete 169pass/0fail/0skip |
| 7 | 120712889933 | partial browser output; bounded runtime exit124; no full summary |
| 8 | 120712889904 | partial browser output; bounded runtime exit124; no full summary |

**Only complete3/4/6 sum to349passed/5failed/0skipped (354 tests).** Shards1/2/7/8 exit124 without fullsummary. Shard5 times out installingCJK at3minutes and does not executebrowser tests.

**The exactsidebar case passes onnewLinux**: shard8log460,16309ms; NativeLinks10,Controls10 andHeader16 also complete. Shard1Shadow111/Portal55/Home11 andshard7Accordion25 pass theirfiles. None of this makes timed-outshards orallC green.

Search30 has16passed/14failed:6initialready assertionsfalse and8originalDocsrole1s failures. Eachready failure has one browser observation afterdeadline (71–693ms),commandCount0 and getter notcalled; it cannot prove targetabsence throughout theoriginalwindow. EachDocs failure has1originalpendingrequest which fulfillscombobox duringthe separate2s postverdictbudget (106.434–802.909ms observed drain),with0newrequests/drops/errors. Complete-at-drain doesnot meanquiescence. No SDKphaseartifact wasdownloaded here. The first complete UI appearance remains unmeasured; lateSDK/Promise settlement doesnot prove puretransport causality.

Homepage9 has8passed/1Brutalistfamily1s fail. Threeactualqueries returnshadcn,shadcn,brutalist; thirdNode return is78.437541ms afterrejection. Same-logwriter/MO/utility recordings have a conditional7-bracketoffsetintersection; writer maps to772.625–773.522ms andMOdelivery892.925–893.722ms afterpollstart, whilethirdutilityread maps to1077.425–1078.222ms. Theseassume a stableadditiveclockoffset, includeobserver/RPCcost anddo notidentify anenginequeue/rootcause.

Shard4 has122passed/2failed. BothS4zh/en cases time out after**60000ms** atline28 waiting for everyglobalpreviewer tohave data-inited=1 and a nonempty.host, before runS4Journey. No failingpreviewerDOMstate is in thislog. My earlyprogress30s wording was corrected immediately; rawlog/source say60s. This isnot yet a provenDialoggeometry orproductiondefect.

Shard7Checkboxfails wc/light/pressed-shadow: actualbefore/after arebothnone,at theoriginalnot.toBe(beforeShadow) comparator. Shard8twoopticalcases time out at20s waitForFunction without aninternalstack beforethe later124 exit. Ownership andcausesremainunknown; no family/CLI fix is inferred. EarlierGeneral78docclassification,shard3opacity/timing failures andCJKsetupremain recorded. Aggregatefailure ismetadataonly; noaggregate logwasrequested.

**partial / ABSTAIN.** Allnewresults belong tod921; earlierpending snapshots andv1capsule areunchanged. No whole-CIgreen,all-Cacceptance,formalapproval orsame-cause-as-old4d claim.
