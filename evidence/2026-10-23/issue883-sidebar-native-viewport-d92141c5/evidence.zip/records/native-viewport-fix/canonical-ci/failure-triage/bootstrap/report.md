# d921 Bootstrap failure triage

The already-terminal run **40041038833**, job **120711921844**, checked out **d92141c57ebab192f3741e7336c1ec0f24b61c5c** (raw log line126). The exact Git API commit object maps it to tree **8dda1bb967cc066db4036e7e085cb7d5c93ebd75**. Its raw log was fetched once; no browser, test, Actions mutation or media download was performed.

The workflow reached its actual Vitest command and completed **4 files / 45 tests: 44 passed, 1 failed**, exit1. The **15 browser cases passed**. Earlier Node workflow guards passed9/9 and preset checks passed12/12. Initial loopback startup ECONNREFUSED attempts eventually reached HTTP200 and did not cause this failure.

The sole failure is `packages/prototypes/bootstrap-2-3-2/test/controls.test.ts:219:22`, “closes the whole source vocabulary through the physical translator”:

```ts
expect(tokens).toEqual([...DRAFT_FAMILY_STYLE_TOKENS[name]]);
```

The full logged array difference contains **414 collected tokens versus437 expected, with23 expected-only tokens**; the exact list is preserved in report.json. This is the Bootstrap whole-source vocabulary / CLI collection and generated preset boundary. The log does not identify which side should change. It is not a native window-size predicate or a setup timeout. The current8-line source delta only changes `site-native-links.browser.test.ts`; the six directly inspected Bootstrap/CLI/workflow source files have identical4d andd921 bytes. This supports keeping the triage separate from the sidebar fixture repair, without claiming that unchanged sources prove any general absence of C effects.

The prior4d metadata already recorded Bootstrap run39965405496 / job120453845731 as failure. The exact old job log was not available in the bounded existing CI directories reviewed, so no identical old predicate or root cause is asserted and no old log was fetched. The appropriate next step is source/generator reconciliation by the Bootstrap vocabulary and CLI collector-preset owners, preserving this equality assertion. No other family work is claimed.

The one new log is100659 bytes, SHA256 `e5078c6e4adc4fea2edc8d39eeff51d432b76537e6eacb9fab9a51d7da81dcb9`. Artifact12539536765 was reported uploaded with49 files, but only its metadata was read; no media pixels or member CRC are claimed. The earlier nonterminal CI summary remains byte-for-byte unchanged. This report is additive.

**Disposition: partial / ABSTAIN.** No formal approval, flaky classification, infrastructure attribution or production cause is inferred.
