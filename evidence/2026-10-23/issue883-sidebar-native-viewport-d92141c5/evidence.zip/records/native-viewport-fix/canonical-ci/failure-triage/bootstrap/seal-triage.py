from pathlib import Path
import json,re,hashlib,subprocess,datetime
P=Path(__file__).resolve().parent; C=P.parent.parent; R=C.parent.parent
W=Path('<WORKTREE>')
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
D=read(C/'complete-data.json')['ci']['921'];run=next(x for x in D['currentHeadRuns'] if x['id']==40041038833);job=next(x for x in D['jobsAndArtifacts'][str(run['id'])]['jobs']['rows'] if x['id']==120711921844)
log=P/'job-120711921844.log';raw=log.read_text();ls=[re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',x) for x in raw.splitlines()]
assert 'd92141c57ebab192f3741e7336c1ec0f24b61c5c' in ls[125]
block=ls[519:958];expected=[];received=[];missing=[]
for l in block:
 m=re.match(r'([ +\-]?)\s*(".*"),?$',re.sub(r'^\S+\s','',l))
 if not m:continue
 value=json.loads(m[2])
 if m[1]!='+':expected.append(value)
 if m[1]!='-':received.append(value)
 if m[1]=='-':missing.append(value)
assert (len(received),len(expected),len(missing))==(414,437,23)
sourcePaths=['packages/prototypes/bootstrap-2-3-2/test/controls.test.ts','packages/cli/src/services/prototype-style-tokens.ts','packages/cli/src/generated/draft-family-style-tokens.ts','packages/cli/src/services/proto-style-css.ts','apps/www/src/content/docs/zh-cn/demo-bootstrap-state-controls.browser.test.ts',run['path'].split('@')[0]]
bindings=[]
for f in sourcePaths:
 by={}
 for h in ['4d4a7ec071dd83756444cbebf5a4c8b3bea81bcf','d92141c57ebab192f3741e7336c1ec0f24b61c5c']:
  b=subprocess.check_output(['git','show',h+':'+f],cwd=W)
  by[h]={'gitBlob':subprocess.check_output(['git','rev-parse',h+':'+f],cwd=W).decode().strip(),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 bindings.append({'path':f,'byHead':by,'sameBytes':len({v['sha256'] for v in by.values()})==1})
oldD=read(R/'live/complete-data.json')['ci']['921'];oldrun=next(x for x in oldD['currentHeadRuns'] if x['name']=='Bootstrap state-controls evidence');oldjob=oldD['jobsAndArtifacts'][str(oldrun['id'])]['jobs']['rows'][0]
git=read(C/'head-git-object.json')
report={
 'schemaVersion':1,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewDisposition':'partial/ABSTAIN','scope':'Single already-terminal Bootstrap job, one raw-log download, cached exact-head metadata and bounded immutable-source comparison. No additional polling or execution.',
 'sourceHead':git['sha'],'sourceTree':git['tree']['sha'],'run':{k:run[k] for k in ['id','name','head_sha','status','conclusion','html_url','path','created_at','updated_at']},'job':{k:job[k] for k in ['id','name','status','conclusion','started_at','completed_at','html_url']},
 'rawLog':{'path':str(log.relative_to(R)),'bytes':log.stat().st_size,'sha256':sha(log),'lines':len(ls)},'downloadReceipt':{'path':str((P/'download-receipt.json').relative_to(R)),'sha256':sha(P/'download-receipt.json')},
 'sourceBinding':{'checkoutLogLine':126,'actualCheckoutSha':git['sha'],'expectedHeadGuardLogLines':[154,174],'sourceGitObject':{'path':str((C/'head-git-object.json').relative_to(R)),'sha256':sha(C/'head-git-object.json')},'binding':'The log prints the full d921 checkout SHA; the already-read Git API object maps that exact commit to tree8dda. No synthetic checkout or separate unobserved working tree is assumed.'},
 'commands':{'setup':['node --test scripts/test/bootstrap-state-controls-evidence.test.mjs','corepack pnpm@10.32.1 check:styles:preset'],'vitest':['corepack','pnpm@10.32.1','exec','vitest','run','packages/prototypes/bootstrap-2-3-2/test/controls.test.ts','apps/www/src/content/docs/zh-cn/native-editor-evidence.test.ts','apps/www/src/content/docs/zh-cn/bootstrap-disabled-paint.test.ts','apps/www/src/content/docs/zh-cn/demo-bootstrap-state-controls.browser.test.ts','--maxWorkers=1','--minWorkers=1'],'vitestCommandLogLines':[296,302]},
 'results':{'setupNodeGuardTests':{'passed':9,'failed':0,'logLines':[261,264]},'stylePresetNodeTests':{'passed':12,'failed':0,'logLines':[288,291]},'vitest':{'files':4,'filesPassed':3,'filesFailed':1,'tests':45,'passed':44,'failed':1,'exitCode':1,'summaryLogLines':[964,967],'exitLogLine':1082},'files':[{'path':'apps/www/src/content/docs/zh-cn/demo-bootstrap-state-controls.browser.test.ts','passed':15,'failed':0,'logLines':[490,505]},{'path':'apps/www/src/content/docs/zh-cn/native-editor-evidence.test.ts','passed':9,'failed':0,'logLines':[506,506]},{'path':'packages/prototypes/bootstrap-2-3-2/test/controls.test.ts','passed':10,'failed':1,'logLines':[507,509]},{'path':'apps/www/src/content/docs/zh-cn/bootstrap-disabled-paint.test.ts','passed':10,'failed':0,'logLines':[510,510]}]},
 'failure':{'case':'bootstrap-2-3-2: Base state/text parts (simulated WC host) > closes the whole source vocabulary through the physical translator','path':'packages/prototypes/bootstrap-2-3-2/test/controls.test.ts','line':219,'column':22,'predicate':'expect(tokens).toEqual([...DRAFT_FAMILY_STYLE_TOKENS[name]])','receivedExpression':'await collectProtoStyleTokens(`packages/prototypes/${name}/src`)','expectedSource':'packages/cli/src/generated/draft-family-style-tokens.ts','receivedCount':len(received),'expectedCount':len(expected),'missingExpectedTokens':missing,'logDiffLines':[520,958],'stackLogLines':[960,963],'classification':'Actual Node source-vocabulary equality failure after successful browser execution; not setup failure, timeout, or native window geometry assertion.'},
 'scopeAssessment':{'observedResponsibility':'Bootstrap whole-source vocabulary / CLI collection and generated preset projection boundary. This entry point alone does not establish which side is incorrect.','currentDelta':subprocess.check_output(['git','diff','--name-only','4d4a7ec071dd83756444cbebf5a4c8b3bea81bcf',git['sha']],cwd=W).decode().splitlines(),'sourceBindings':bindings,'cProductionCauseProved':False,'nativeViewportFixRegressedProved':False,'nextOwnerAction':'Route the 23-token equality mismatch to the Bootstrap vocabulary / CLI collector-preset owners for exact source and generator reconciliation. Preserve the predicate; do not auto-update the expected table or weaken the guard. No ownership claim or fix is made here.','notClaimed':['This is not evidence that every C behavior passes.','Unchanged source bytes do not by themselves exclude shared-runtime or collection effects.','No maintainer acceptance, formal approval, infrastructure/flaky attribution, or new product defect cause is inferred.']},
 'historical4dIndex':{'metadataSource':str((R/'live/complete-data.json').relative_to(R)),'metadataSHA256':sha(R/'live/complete-data.json'),'runId':oldrun['id'],'jobId':oldjob['id'],'head':oldrun['head_sha'],'conclusion':oldrun['conclusion'],'scope':'The earlier complete metadata read proves the same named workflow failed on4d. No exact old Bootstrap job raw log was found in the bounded existing R21 CI directories; no old log was downloaded. Therefore identical old predicate/cause is not claimed.','sameRelevantSourceBytes':all(b['sameBytes'] for b in bindings)},
 'artifacts':{'uploadReportedFileCount':49,'id':12539536765,'bytes':1458174,'reportedSHA256':'9eafe3d5a9aaac6767716694495c7fad5f1cdd786cf99fb61f77f1f6e9670c4d','downloaded':False,'memberCRCVerified':False},
 'checkpointBoundary':{'summaryJSONSHA256':sha(C/'summary.json'),'summaryMDSHA256':sha(C/'summary.md'),'unchanged':True,'description':'This later single-log triage is additive to the23:42:57–23:43:26 metadata checkpoint; it does not update the queued/running state of other workflows.'},
 'notPerformed':['No Actions mutation/rerun/cancel','No test/browser execution','No W/E source edit','No artifact/media download','No all-CI repoll','No old log redownload']}
(P/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
md=f'''# d921 Bootstrap failure triage

The already-terminal run **40041038833**, job **120711921844**, checked out **{git['sha']}** (raw log line126). The exact Git API commit object maps it to tree **{git['tree']['sha']}**. Its raw log was fetched once; no browser, test, Actions mutation or media download was performed.

The workflow reached its actual Vitest command and completed **4 files / 45 tests: 44 passed, 1 failed**, exit1. The **15 browser cases passed**. Earlier Node workflow guards passed9/9 and preset checks passed12/12. Initial loopback startup ECONNREFUSED attempts eventually reached HTTP200 and did not cause this failure.

The sole failure is `packages/prototypes/bootstrap-2-3-2/test/controls.test.ts:219:22`, “closes the whole source vocabulary through the physical translator”:

```ts
expect(tokens).toEqual([...DRAFT_FAMILY_STYLE_TOKENS[name]]);
```

The full logged array difference contains **414 collected tokens versus437 expected, with23 expected-only tokens**; the exact list is preserved in report.json. This is the Bootstrap whole-source vocabulary / CLI collection and generated preset boundary. The log does not identify which side should change. It is not a native window-size predicate or a setup timeout. The current8-line source delta only changes `site-native-links.browser.test.ts`; the six directly inspected Bootstrap/CLI/workflow source files have identical4d andd921 bytes. This supports keeping the triage separate from the sidebar fixture repair, without claiming that unchanged sources prove any general absence of C effects.

The prior4d metadata already recorded Bootstrap run39965405496 / job120453845731 as failure. The exact old job log was not available in the bounded existing CI directories reviewed, so no identical old predicate or root cause is asserted and no old log was fetched. The appropriate next step is source/generator reconciliation by the Bootstrap vocabulary and CLI collector-preset owners, preserving this equality assertion. No other family work is claimed.

The one new log is100659 bytes, SHA256 `{sha(log)}`. Artifact12539536765 was reported uploaded with49 files, but only its metadata was read; no media pixels or member CRC are claimed. The earlier nonterminal CI summary remains byte-for-byte unchanged. This report is additive.

**Disposition: partial / ABSTAIN.** No formal approval, flaky classification, infrastructure attribution or production cause is inferred.
'''
(P/'report.md').write_text(md)
(P/'source-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
(P/'log-excerpts.json').write_text(json.dumps({'rawLogSHA256':sha(log),'blocks':[{'lines':[a,b],'text':'\n'.join(ls[a-1:b])} for a,b in [(123,126),(154,174),(244,264),(286,308),(488,515),(944,973),(1082,1103)]]},indent=2)+'\n')
(P/'manifest.json').write_text(json.dumps({'files':[{'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(P.iterdir()) if f.is_file() and f.name!='manifest.json']},indent=2)+'\n')
print(json.dumps({n:sha(P/n) for n in ['report.json','report.md','manifest.json']}))
