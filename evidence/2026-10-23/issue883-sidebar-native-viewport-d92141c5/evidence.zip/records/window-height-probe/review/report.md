两次post-verdict A/B/A已核真实原件，原1fail/9filtered不改。height臂实际900/1100/900，CSSmetrics不变、四个原生wheel fullpath都含同nav identity1，结果9021→9021、9021→8621、8621→8621。原e431的readback/identity guard不足由本次完整raw补足执行证明，不要求重跑，也不说旧代码已有这些guard。

contents臂明确请求1440×900 DIP，outer实际900→987→900；CSS viewport1440×900/content1690不变，同ownerID1，仍A失败/B移动400/恢复A失败。87只是外窗口读回差，不能叫已测RenderWidget尺寸或Chrome inset根因。

结果支持native window/contents操作关联，不能完全剥离resize失效重建。B移动后恢复A起点8621、命中另一anchor，虽同owner/点仍不是全条件相同的逆向实验。没有写offset归位。适合下一步原fixture初始化使用其声明的nativecontents参数，不支持+200、OS分支、CSS修复或扩大超时。partial/ABSTAIN。
