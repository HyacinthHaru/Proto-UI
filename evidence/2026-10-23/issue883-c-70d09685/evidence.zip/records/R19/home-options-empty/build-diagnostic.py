from pathlib import Path
import subprocess,json,hashlib,datetime
R=Path(__file__).parents[1];D=R/'home-options-empty';W=Path('<WORKTREE>');base='apps/www/src/content/docs/zh-cn/home-demo-runtime.browser.test.ts';dest='apps/www/src/content/docs/zh-cn/home-options-diagnostic.browser.test.ts';source=(W/base).read_text();title='uses unframed responsive task layout, real control feedback and four executable runtimes';a=source.index("  it('"+title);b=source.index("  it('",a+7);section=source[a:b];prefix='''      const nodeQueries: unknown[] = [];
      const locatorPrototype = Object.getPrototypeOf(page.locator('body'));
      const originalText = Object.getOwnPropertyDescriptor(locatorPrototype, 'allTextContents')!;
      Object.defineProperty(locatorPrototype, 'allTextContents', {
        ...originalText,
        value: function (...args: unknown[]) {
          const started = { atMs: performance.now(), epochMs: Date.now(), selector: this._selector };
          const promise = Reflect.apply(originalText.value, this, args);
          void promise.then((value: unknown) => {
            nodeQueries.push({ ...started, settledMs: performance.now(), settledEpochMs: Date.now(), value });
          }, (error: unknown) => {
            nodeQueries.push({ ...started, settledMs: performance.now(), settledEpochMs: Date.now(), error: String(error) });
          });
          return promise;
        },
      });
      await page.addInitScript(() => {
        const ids = new WeakMap<Element, number>(); let next = 0; let stopped = false; let last = ''; let dropped = 0; let queries = 0;
        const rows: unknown[] = []; const inputs: unknown[] = [];
        const id = (e: Element) => { if (!ids.has(e)) ids.set(e, ++next); return ids.get(e); };
        const attrs = (e: Element) => ({ node: id(e), tag: e.tagName, id: e.id, role: e.getAttribute('role'), hidden: e.hasAttribute('hidden'), inert: e.hasAttribute('inert'), ariaHidden: e.getAttribute('aria-hidden'), pending: e.hasAttribute('data-pui-view-pending'), revealing: e.hasAttribute('data-pui-view-revealing'), stage: e.getAttribute('data-projection-generation-state'), owner: e.getAttribute('data-projection-owner-host'), generation: e.getAttribute('data-projection-generation-host'), inlineStyle: e.getAttribute('style') });
        const describe = (e: Element) => ({ ...attrs(e), text: e.textContent?.slice(0, 300), ancestry: (() => { const a = []; for (let p: Element | null = e; p && a.length < 10; p = p.parentElement) a.push(attrs(p)); return a; })() });
        const sample = (reason: string, changes: unknown[] = []) => {
          if (stopped) return;
          queries++;
          const triggers = Array.from(document.querySelectorAll('[data-homepage-runtime] [data-projection-control="runtime"] [role="combobox"]')).map((e) => ({ ...describe(e), controls: e.getAttribute('aria-controls'), expanded: e.getAttribute('aria-expanded') }));
          const portals = triggers.map((t) => { const p = t.controls ? document.getElementById(t.controls) : null; return { controls: t.controls, portal: p ? describe(p) : null, options: p ? Array.from(p.querySelectorAll('[role="option"]')).map(describe) : [] }; });
          const state = { triggers, portals }; const key = JSON.stringify(state); if (key === last) return; last = key;
          const row = { atMs: performance.now(), epochMs: Date.now(), reason, changes, ...state };
          if (rows.length < 512) rows.push(row); else dropped++;
        };
        const observer = new MutationObserver((records) => sample('mutation', records.slice(0, 12).map((m) => ({ type: m.type, attribute: m.attributeName, oldValue: m.oldValue, target: m.target instanceof Element ? attrs(m.target) : null, added: m.addedNodes.length, removed: m.removedNodes.length }))));
        observer.observe(document, { subtree: true, childList: true, attributes: true, attributeOldValue: true, attributeFilter: ['role','aria-hidden','inert','data-pui-view-pending','data-pui-view-revealing','data-projection-generation-state','aria-expanded','aria-controls','hidden','style'] });
        for (const type of ['pointerdown','pointerup','click','keydown']) document.addEventListener(type, (event) => { if (inputs.length < 128) inputs.push({ atMs: performance.now(),epochMs: Date.now(),type,trusted:event.isTrusted,key:(event as KeyboardEvent).key,target:event.target instanceof Element ? describe(event.target) : null }); }, true);
        (window as any).__homeOptionsObservation = { stop() { sample('stop'); stopped = true; observer.disconnect(); return { rows, inputs, queries, dropped, physicalMutationTimeKnown: false }; } };
      });
''';anchor='      try {\n        await page.goto';assert section.count(anchor)==1;section=section.replace(anchor,prefix+anchor);anchor2='''      } finally {
        await context.close();
      }''';assert section.count(anchor2)==1;capture='''      } finally {
        Object.defineProperty(locatorPrototype, 'allTextContents', originalText);
        try {
          const directory = path.join(process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR!, 'home-options');
          await mkdir(directory, { recursive: true });
          const browserObservation = await page.evaluate(() => ({
            trace: (window as any).__homeOptionsObservation?.stop(),
            atMs: performance.now(), epochMs: Date.now(), width: innerWidth,
            roleOptions: Array.from(document.querySelectorAll<HTMLElement>('[role="option"]')).map((e) => ({ text:e.textContent,html:e.outerHTML,rect:e.getBoundingClientRect().toJSON(),visibility:getComputedStyle(e).visibility,display:getComputedStyle(e).display,ancestry:(() => {const a=[];for(let p:HTMLElement|null=e;p&&a.length<12;p=p.parentElement){const s=getComputedStyle(p);a.push({tag:p.tagName,id:p.id,role:p.getAttribute('role'),ariaHidden:p.getAttribute('aria-hidden'),inert:p.inert,pending:p.hasAttribute('data-pui-view-pending'),revealing:p.hasAttribute('data-pui-view-revealing'),display:s.display,visibility:s.visibility,opacity:s.opacity});}return a;})() })),
          }));
          await writeFile(path.join(directory, `${colorScheme}.json`), JSON.stringify({ colorScheme, nodeQueries, browserObservation, scope: 'Original responsive case plus passive raw DOM/Promise journal; post-assertion capture, not original failure frame' }, null, 2));
          await page.screenshot({path:path.join(directory, `${colorScheme}.png`),fullPage:true});
        } catch (error) { console.error('[home-options-observation]', error); }
        await context.close();
      }''';section=section.replace(anchor2,capture);out=source[:a]+section+source[b:];assert not(W/dest).exists();(W/dest).write_text(out);(D/'diagnostic.browser.test.ts').write_text(out);assert section.replace(prefix,'').replace(capture,anchor2)==source[a:b];assert out.count('expect(')==source.count('expect(');sha=lambda b:hashlib.sha256(b).hexdigest();(D/'diagnostic-source-binding.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'basePath':base,'baseSHA256':sha((W/base).read_bytes()),'actualTemporaryPath':dest,'actualSHA256':sha((W/dest).read_bytes()),'onlyAddedInitJournalAndFinallyCapture':True,'allOriginalAssertionsInputsAndDeadlinesBytePreserved':True,'scope':'Selected1originalcase+10filtered; beforegoto passive rawDOM+originalPromise identity tap; overhead nonzero and may perturb timing; no rootcause/oldred closure.'},indent=2)+'\n');p=json.loads((R/'final-native269.plan.json').read_text());O=R/'home-options-diagnostic';p.update(files=[dest],scope='Boundedoneoriginalresponsivecase with passive rawDOM and originalallTextContentsPromise tap; original180s case and inputs/assertions preserved. 10 other originalcases filtered, no fullsuite rerun.',extraInputPaths=[str(W/dest),str(W/'apps/www/.astro/settings.json')]);p['argv']=['corepack','pnpm@10.32.1','exec','vitest','run',dest,'-t',title,'--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(O/'vitest.json')];p['environmentOverrides'].update(PROTO_UI_RUNTIME_EVIDENCE_DIR=str(O/'evidence'),RUNNER_TEMP=str(O/'runner-temp'));(R/'home-options-diagnostic.plan.json').write_text(json.dumps(p,indent=2)+'\n');print('Prepared original case passive diagnostic clone, no product bytes changed')
