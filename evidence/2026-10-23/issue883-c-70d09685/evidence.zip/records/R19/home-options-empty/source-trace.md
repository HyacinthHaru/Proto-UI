当前候选没有发现具体源码问题；结论为 **partial / ABSTAIN**，不是 GitHub 批准。源绑定：原 9ffa `6aac48c1…`，候选 `b5a421b4…`，只增加 `portalControlledBy` 的五行就绪等待。

原 clean 9ffa 的 269 项保持 268 通过 / 1 失败。另一次私有诊断也保留原失败：Node 原 `allTextContents` 返回 `[]`；浏览器观察回调此前已记录 controlled ID `pui-select-1-content` 下四个物理 option。后置样本中四项均有矩形，但 Surface 和后代 `visibility:hidden`，Surface `opacity:0`，Content 本身 visible。该后置样本不能反填为原查询瞬间的 CSS，也没有直接观察内部 alignment/transition phase。

固定 Playwright 1.58.2 的角色引擎会过滤 hidden 项，而 `allTextContents()` 是一次 `$$eval` 快照。当前 draft `P-BASE-SELECT-CONTENT-PRESENTATION-ADMISSION` 允许 full-pending 保留可测但隐藏的 view；`P-SHADCN-SELECT-CONTENT` 明确 Content Frame、Surface 与 Viewport 的分工。结合真实数据，可证的缺口是测试仅等待外框 visible 就读取角色列表；目前不足以归因或回退新 main 的 WC slot failure-atomicity 修复。

候选保留原外框 visible 10 秒等待，在相同 phase deadline 下用剩余时间等待第一个可见 option。remaining 非正时显式失败，未把 timeout0 传给 Playwright。原四标签 literal、全部 69 个 expect 调用、7 个 it 调用点的完整字节、原 180 秒 case、所有输入和 owner17 控制都保留。新增等待不会让永远 hidden、缺项或错误 labels 通过；首项可见并不代替随后完整列表断言。此预算是逻辑等待预算，不宣称跨进程/调度零开销或硬实时上限。

原诊断 clone 的 setup-cleanup 和 error-stringification 已知限制保持原样记录；它不应被称为全面 nonthrowing 或零干扰。当前报告未读取候选运行结果、没有执行测试/浏览器/网络、没有修改产品。源码、SDK、原始记录及静态保全证据的完整 SHA256 在相邻 JSON。
