# Playwright1.58.2 resolve: exact source trace

Read-only, human-assisted/current-user. Initial checkoutac1990c7 wasclean; Parentthenstagedacceptedmainintegration. Currentobserver/caller hashesremainboundtoac inJSON. No browser/test/network orsourceedit wasperformed.

`FrameSelectors.resolveInjectedForSelector` (frameSelectors.js141–147) hasthree awaitsites:

1. `resolveFrameForSelector` (104–139). The fixedCSS+nth selector hasnoenter-frame oraria-ref. Itsframe-loop awaitsites118/119/120/129 aretherefore notentered. Split/validation/finalparse are synchronous, butasyncreturn/outerawait stillenqueuePromisecontinuation.
2. `resolved.frame._context(world)` (frames.js581–586). Thisawaits theworld’sManualPromise, resolvedbyactualcontextcreation (_setContext1363–1369). It neitherpollsnorqueriesDOM.
3. `context.injectedScript()` (dom.js74–103). Cachedpathreturns existingpromise; coldpath builds SDKInjectedScript andcallsrawEvaluateHandle, then_setPreview. ExecutionContext.rawEvaluateHandle (javascript.js63–65) racesactualdelegateevaluation againstcontextdestruction. Chromiumdelegate57–65 awaits theexisting`Runtime.evaluate` request. Cachedpromise presence doesnotprovealreadysettled.

Current observer resolve.exit (docs-query-timing.mjs408–430) isinsideanaddedfulfilledtapreaction **afterpatchHandle**. patchHandle170–225 is synchronousWeakSet/descriptorinstallation, noawait/RPC. Its evaluatorhash/decoratorwork runs laterwhenhandle.evaluate isinvoked. Thereforetheoldinterval includes await/scheduling andobserverpatch work; itdoesnotidentifyoneSDKawait. Anewfulfilled-before-patch markerpluspatchenter/exit givesanobservedreactionboundary, nottheunobservableinstantPromiseinternallysettled.

The SDKpoll isoutsideoneresolve: frames.js874–897 prepends0 totheprovided[0,20,50,100,100,500], waitsnonzeroNode timers, thenawaitsaction. _callOnElementOnceMatches1338–1361 firstawaitsresolve, theninjected.evaluate, returningcontinuePollingonlyforunresolved/missingelement. LaterJSHandle.evaluate usesargumentPromise.all andUtilityScript/evaluateWithArguments (javascript.js186–219,66–92); thatUtilityScript isdistinctfromDOMInjectedScript acquisitioninside resolve. Client/driverbridgeusesin-processsetImmediate (inProcessFactory.js46–53), notnetwork.

**Smallestfirstinstrumentationarm:** preservecaller andbrowserselector/gettercode; addprepatchfulfilled/patchmarkers; wraponlyactualserverFrame._context andtheactualreturnedcontext’sinjectedScript/rawEvaluateHandlemethods. ReuseexistingALSactualcallId, originalthis/args andexactPromise viaexistingtap. Patchcontextonlyafteritsoriginalacquirefulfills, beforeSDKcontinuation; no eagercontextrequest, newRPC, CDPsession/world orpost-gotoawait. Binddom.js asnewSDKsource; optionalCRdelegatehookonlyifrawawaitneedsfurtherdivision.

Poll splitting isoptional: wraptheexistingretryaction once witha nonasyncforwarder, preservingprogress/timeouts andoriginalactionPromise; recordactionordinal/continuePolling. Between-actiongap isconfiguredtimer+scheduling+observercost, notpuretimerduration. Aresolveordinal mustnotbeconfusedwiththeexistingevaluateattempt counter.

KeeporiginalqueryPromise,1sverdict,2sfailed-onlyobservationtail,context-close-start marker,originalinputs/matchers and17keyboard-ownercontrolsunmodified. Nonthrowdiagnostics, falsyerrorpreservation,CASdescriptorrestoration andmissing/drop/error debt remainrequired. Historicalnatural8failed andisolated10rows areonlyindices; theydo notmeasuretheseinternalphases. Anew samefailure isrequiredforcausalattribution. No productionsemanticpatch orstableguarantee isproposed.

The JSONcontains exactSDK/repository SHA256bindings, line references, hookpriorities andlimits. Partial/ABSTAIN, notformalapproval.
