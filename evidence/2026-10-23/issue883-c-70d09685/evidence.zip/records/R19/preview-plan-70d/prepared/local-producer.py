from pathlib import Path, PurePosixPath
import argparse
import datetime
import hashlib
import json
import os
import platform
import re
import stat
import subprocess
import sys
import zipfile
import zlib

R = Path('<R19>')
W = Path('<WORKTREE>')
OUT = R / 'built-preview-70d/local-producer'
HEAD = '70d096851a1b22e50ac72e147efaa2b46f62f1c4'
TREE = '7d18f8fe42785c14df46db2a29ec8b595cb5ccee'
NODE = '<HOME>/.codex/task-state/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin'
ENV = dict(os.environ, PATH=NODE + os.pathsep + os.environ.get('PATH', ''))


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=W, env=ENV)


def check_source():
    assert git('rev-parse', 'HEAD').decode().strip() == HEAD
    assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
    assert not git('status', '--porcelain'), 'Exact clean 70d required; stop, do not reset.'


def write_json(name, value):
    target = OUT / name
    with target.open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')
    return digest(target.read_bytes())


def census():
    result = {}
    for raw in git('ls-files', '-z').split(b'\0'):
        if not raw:
            continue
        name = os.fsdecode(raw)
        item = W / name
        data = os.readlink(item).encode() if item.is_symlink() else item.read_bytes()
        result[name] = {'sha256': digest(data), 'symlink': item.is_symlink()}
    return result


def inventory(root):
    rows = []
    for item in sorted(root.rglob('*')):
        info = item.lstat()
        assert not stat.S_ISLNK(info.st_mode), str(item)
        if stat.S_ISDIR(info.st_mode):
            continue
        assert stat.S_ISREG(info.st_mode), str(item)
        data = item.read_bytes()
        rows.append({'path': item.relative_to(root).as_posix(), 'type': 'file',
                     'size': len(data), 'sha256': digest(data)})
    return sorted(rows, key=lambda row: row['path'])


def command(argv, label, cwd=W, additions=None):
    start = now()
    environment = dict(ENV, **(additions or {}))
    with (OUT / (label + '.log')).open('xb') as log:
        result = subprocess.run(argv, cwd=cwd, env=environment,
                                stdout=log, stderr=subprocess.STDOUT)
    receipt = {'start': start, 'end': now(), 'argv': argv, 'cwd': str(cwd),
               'environmentOverrides': additions or {}, 'exit': result.returncode,
               'logSHA256': digest((OUT / (label + '.log')).read_bytes())}
    write_json(label + '-receipt.json', receipt)
    assert result.returncode == 0, f'{label} exited {result.returncode}; original output retained.'
    return receipt


def complete_zip_index(archive, producer_files):
    destination = OUT / 'extracted'
    destination.mkdir()
    rows = []
    names = set()
    with zipfile.ZipFile(archive) as zipped:
        for info in zipped.infolist():
            raw = info.filename
            name = PurePosixPath(raw)
            assert raw not in names, raw
            names.add(raw)
            assert not name.is_absolute() and '..' not in name.parts and '\\' not in raw
            assert not any(ord(char) < 32 for char in raw)
            target = destination.joinpath(*name.parts)
            assert target.resolve().is_relative_to(destination.resolve())
            kind = stat.S_IFMT(info.external_attr >> 16)
            assert kind in (0, stat.S_IFREG, stat.S_IFDIR), raw
            data = zipped.read(info)
            crc = zlib.crc32(data) & 0xffffffff
            assert crc == info.CRC, raw
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as handle:
                    handle.write(data)
                assert target.read_bytes() == data, raw
            rows.append({'path': raw, 'type': 'directory' if info.is_dir() else 'file',
                         'size': len(data), 'sha256': digest(data),
                         'compressedBytes': info.compress_size,
                         'declaredCRC32': f'{info.CRC:08x}', 'computedCRC32': f'{crc:08x}',
                         'crcEqual': True, 'extractionByteEqual': True,
                         'zipExternalMode': info.external_attr >> 16})
    regular = sorted((row for row in rows if row['type'] == 'file'), key=lambda row: row['path'])
    simplified = [{key: row[key] for key in ('path', 'type', 'size', 'sha256')} for row in regular]
    assert simplified == producer_files, 'ZIP must preserve every producer file and byte.'
    assert inventory(destination) == producer_files
    archive_index_sha = write_json('archive-members.json', rows)
    member_sha = write_json('members.json', regular)
    result = {'artifactId': None, 'artifactName': None, 'archive': archive.name,
              'archiveBytes': archive.stat().st_size, 'archiveSHA256': digest(archive.read_bytes()),
              'members': len(rows), 'files': len(regular), 'directories': len(rows) - len(regular),
              'html': sum(row['path'].endswith('.html') for row in regular),
              'expandedBytes': sum(row['size'] for row in regular),
              'allCRCChecked': True, 'allExtractedBytesEqual': True,
              'allMemberHashesRecorded': True, 'extractionDirectory': str(destination),
              'memberInventorySHA256': member_sha, 'archiveInventorySHA256': archive_index_sha,
              'pruned': False, 'symlinkOrUnsupportedMembers': 0}
    write_json('inspection-receipt.json', {'at': now(), 'head': HEAD, 'tree': TREE,
               'sourceMode': 'local-producer', 'completeSiteArtifact': result,
               'producerFilesEqualZIPAndExtraction': True, 'browserExecuted': False})
    return result


def main():
    parser = argparse.ArgumentParser(description='One explicitly local complete docs producer; no GitHub or browser calls.')
    parser.add_argument('--mode', required=True, choices=['local-producer'])
    parser.add_argument('--native-receipt', type=Path, default=R / 'final-native269-70d/receipt.json')
    parser.add_argument('--profile-restore-receipt', type=Path)
    args = parser.parse_args()
    native = json.loads(args.native_receipt.read_text())
    assert native['head'] == HEAD and native['exit'] == 0 and native['sourceStable']
    assert native.get('extraInputsStable', True)
    native_result_path = args.native_receipt.parent / 'vitest.json'
    native_result = json.loads(native_result_path.read_text())
    assert native_result['numPassedTests'] == 269 and native_result['numFailedTests'] == 0
    started_profile = list(R.glob('profile-experiment*/before.json'))
    if started_profile:
        assert args.profile_restore_receipt, 'Started profile experiment requires its actual CAS restore receipt.'
    profile = None
    if args.profile_restore_receipt:
        profile = json.loads(args.profile_restore_receipt.read_text())
        assert profile['head'] == HEAD and profile['tree'] == TREE
        assert profile['allManagedFilesCASRestored'] and profile['cliDistExactOriginalBytesRestored']
        assert profile['productWorktreeClean'] and profile['temporaryFamilyNotCommitted']
    check_source()
    assert subprocess.check_output(['node', '--version'], env=ENV, text=True).strip() == 'v24.21.0'
    manager = subprocess.check_output(['corepack', 'pnpm@10.32.1', '--version'], cwd=W, env=ENV, text=True).strip()
    assert manager == '10.32.1'
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(exist_ok=False)
    before = census()
    before_sha = write_json('input-manifest-before.json', before)
    receipt = {'start': now(), 'head': HEAD, 'tree': TREE, 'sourceMode': args.mode,
               'producerRun': None, 'producerJob': None, 'artifactId': None,
               'node': 'v24.21.0', 'pnpm': manager, 'platform': platform.platform(),
               'nativeReceiptSHA256': digest(args.native_receipt.read_bytes()),
               'nativeVitestSHA256': digest(native_result_path.read_bytes()),
               'profileRestoreReceiptSHA256': digest(args.profile_restore_receipt.read_bytes()) if profile else None,
               'inputManifestBeforeSHA256': before_sha, 'success': False,
               'scope': 'Local reused locked dependencies; exact tracked-source census is not a bundler dependency closure or canonical Linux result.'}
    original_failure = None
    binding = None
    try:
        build = command(['corepack', 'pnpm@10.32.1', '--filter', 'apps-www', 'build'], 'producer')
        dist = W / 'apps/www/dist'
        assert (dist / 'index.html').stat().st_size > 0
        producer_files = inventory(dist)
        producer_inventory_sha = write_json('producer-files.json', producer_files)
        archive = OUT / 'site.zip'
        command(['zip', '-q', '-r', str(archive), '.'], 'archive', cwd=dist)
        admission = command(['node', '--test', 'scripts/preview/generated-artifact.test.mjs'],
                            'producer-default-admission', additions={
                                'PREVIEW_GENERATED_ARTIFACT': str(archive),
                                'PREVIEW_GENERATED_SOURCE': str(dist)})
        text = (OUT / 'producer-default-admission.log').read_text()
        counts = {key: int(re.search(r'^# ' + key + r' (\d+)\s*$', text, re.M).group(1))
                  for key in ('tests', 'pass', 'fail', 'skipped')}
        assert counts == {'tests': 1, 'pass': 1, 'fail': 0, 'skipped': 0}, counts
        site = complete_zip_index(archive, producer_files)
        assert inventory(dist) == producer_files, 'Producer source changed during packaging/admission.'
        binding = {'at': now(), 'head': HEAD, 'tree': TREE, 'sourceMode': 'local-producer',
                   'producerRun': None, 'producerJob': None, 'runConclusion': None,
                   'producerActualCheckout': HEAD, 'completeSiteArtifact': site,
                   'sourceBindingArtifact': None, 'producerToolchain': {'node': 'v24.21.0', 'pnpm': manager, 'platform': platform.platform()},
                   'producerLogSHA256': build['logSHA256'], 'producerFileInventorySHA256': producer_inventory_sha,
                   'producerDefaultAdmission': {'counts': counts, 'sourceDirectory': str(dist),
                      'sourceWasRealProducerDirectory': True, 'inputZIPWasProducerOwnArchive': True,
                      'usesExistingDefaultExtractionAndSanitization': True, 'logSHA256': admission['logSHA256']},
                   'localDefaultAdmissionExecuted': True, 'localBuildExecuted': True,
                   'builtArtifactBrowserExecuted': False, 'sitePruned': False,
                   'scope': 'Local complete producer plus original default admission. Not Actions, publisher Ready,47-package build,rendered artifact,or full CI acceptance.'}
    except BaseException as error:
        original_failure = error
        receipt['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        try:
            after = census()
            receipt['inputManifestAfterSHA256'] = write_json('input-manifest-after.json', after)
            receipt['trackedFiles'] = len(before)
            receipt['sourceStable'] = before == after
            receipt['headAfter'] = git('rev-parse', 'HEAD').decode().strip()
            receipt['treeAfter'] = git('rev-parse', 'HEAD^{tree}').decode().strip()
            receipt['statusAfter'] = git('status', '--porcelain').decode()
            assert receipt['sourceStable'] and receipt['headAfter'] == HEAD and receipt['treeAfter'] == TREE
            assert not receipt['statusAfter']
        except BaseException as error:
            receipt['sourceVerificationError'] = {'type': type(error).__name__, 'message': str(error)}
            if original_failure is None:
                original_failure = error
        receipt['end'] = now()
        receipt['success'] = original_failure is None and binding is not None
        if receipt['success']:
            binding['sourceStable'] = True
            binding['trackedInputCount'] = len(before)
            receipt['finalBindingSHA256'] = write_json('final-binding.json', binding)
        write_json('receipt.json', receipt)
    print(json.dumps({'success': receipt['success'], 'output': str(OUT),
                      'sourceStable': receipt.get('sourceStable'), 'error': receipt.get('error')}))
    if original_failure is not None:
        raise original_failure


if __name__ == '__main__':
    main()
