from pathlib import Path
import subprocess,json,os,hashlib,datetime,sys,shutil
R=Path(__file__).parent;W=Path('<WORKTREE>');D=R/'profile-experiment';P=R/'profile-composition-prep';plan=json.loads((R/'profile-composition-execution-plan-70d.json').read_text());closure=json.loads((P/'source-closure-plan.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();env=os.environ.copy();env['PATH']='<HOME>/.codex/task-state/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:'+env['PATH'];test=plan['temporaryTestPath'];base='apps/www/src/content/docs/zh-cn/home-demo-runtime.browser.test.ts'
def git(*a):return subprocess.check_output(['git',*a],cwd=W,text=True).strip()
def files():return sorted(set(plan['snapshotPaths']+[test]+[str(p.relative_to(W))for p in(W/'packages/cli/dist').rglob('*')if p.is_file()]))
def snap(paths):
 return {n:{'exists':(W/n).exists(),'sha256':sha((W/n).read_bytes())if(W/n).exists()else None,'mode':((W/n).stat().st_mode&0o777)if(W/n).exists()else None}for n in paths}
def save(n,v):
 p=D/n;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def run(a,log):
 start=now()
 with(D/log).open('x')as f:p=subprocess.run(a,cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT)
 save(log+'.receipt.json',{'start':start,'end':now(),'argv':a,'exit':p.returncode});return p.returncode
def prepare(stage):
 out=D/stage;v=json.loads((R/'final-native269-70d.plan.json').read_text());v.update(scope='TEMPORARY publishedShadcn67 family subset+localBase+Shadcnwrapinput, originalfirstreveal90s selected1case; othercasefilter disclosed; no GitHub/productwholehead acceptance',files=[test],extraInputPaths=[str(W/n)for n in sorted(set([test]+[a['path']for a in closure['closure']]+plan['snapshotPaths']))if(W/n).exists()]);v['argv']=['corepack','pnpm@10.32.1','exec','vitest','run',test,'-t',plan['selectedOriginalCase'],'--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')];v['environmentOverrides'].update(PROTO_UI_RUNTIME_EVIDENCE_DIR=str(out/'evidence'),RUNNER_TEMP=str(out/'runner-temp'));p=R/('profile-'+stage+'.plan.json');p.write_text(json.dumps(v,indent=2)+'\n');save(stage+'-inputs.json',{'at':now(),'head':git('rev-parse','HEAD'),'indexTree':git('write-tree'),'temporaryInputs':snap(files()),'originalTestSHA256':sha((W/base).read_bytes()),'actualTestSHA256':sha((W/test).read_bytes()),'sourceClosure':'subset+localBase, notwhole926','status':git('status','--porcelain')});return p
mode=sys.argv[1]
if mode=='init':
 rc=json.loads((R/'final-native269-70d/receipt.json').read_text());assert rc['sourceStable'] and rc['exit']==0,'Originalcombinationmustfirstbecomplete';assert git('rev-parse','HEAD')==plan['baseHead']and not git('status','--porcelain');D.mkdir();paths=files();before=snap(paths)
 for n,v in before.items():
  if v['exists']:
   p=D/'before'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((W/n).read_bytes())
 save('before.json',{'at':now(),'head':plan['baseHead'],'tree':plan['baseTree'],'files':before})
 for a in closure['closure']:
  assert before[a['path']]['exists']==a['originalExists'];assert before[a['path']]['sha256']==a['originalSHA256']
 subprocess.run(['git','apply','--check',str(P/'button-and-cli-source.patch')],cwd=W,check=True);assert run(['git','apply',str(P/'button-and-cli-source.patch')],'apply-source.log')==0;assert run(['git','apply',str(P/'settings-shadcn-wrap-input.proposal.patch')],'apply-consumer.log')==0
 (D/'temporary-consumer.ts').write_bytes((W/'apps/www/src/components/Homepage/homepage-showcase.ts').read_bytes())
 assert run(closure['generators']['smallestExistingRequiredStage'],'preset-generate.log')==0;assert run(closure['generators']['correspondingCheck'],'preset-check.log')==0
 source=(W/base).read_text();a=source.index("  it('"+plan['selectedOriginalCase']);b=source.index("  it('",a+7);section=source[a:b];anchor='    } finally {\n      await context.close();\n    }';assert section.count(anchor)==1
 capture='''    } finally {
      // Temporary profile composition capture after the original assertions.
      try {
        const directory = path.join(process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR!, 'profile-settings');
        await mkdir(directory, { recursive: true });
        const facts = [];
        for (const width of [1440, 320]) {
          await page.setViewportSize({ width, height: 900 });
          facts.push(await home.evaluate((root) => ({
            width: innerWidth,
            samples: (window as any).__homeMountSamples ?? [],
            controls: Array.from(root.querySelectorAll<HTMLElement>('[data-projection-generation-state="active"] [data-demo-ref="settings-save"], [data-projection-generation-state="active"] [data-demo-ref="settings-reset"]')).map((node) => {
              const r = node.getBoundingClientRect(); const s = getComputedStyle(node);
              const owner = node.closest<HTMLElement>('[data-projection-generation-state]');
              return { ref: node.dataset.demoRef, prototype: node.getAttribute('data-projection-prototype'), elementTag: node.tagName, style: node.getAttribute('data-pui-style'), role: node.getAttribute('role'), connected: node.isConnected, pending: node.hasAttribute('data-pui-view-pending'), owner: owner?.dataset.projectionOwnerHost, generation: owner?.dataset.projectionGenerationHost, state: owner?.dataset.projectionGenerationState, inert: owner?.inert, rect: { x:r.x,y:r.y,width:r.width,height:r.height }, computed: {height:s.height,minHeight:s.minHeight,visibility:s.visibility,overflowWrap:s.overflowWrap,whiteSpace:s.whiteSpace,transitionDuration:s.transitionDuration} };
            }),
          })));
          await page.screenshot({ path: path.join(directory, `settings-${width}.png`), fullPage: true });
        }
        await writeFile(path.join(directory, 'observed.json'), JSON.stringify(facts, null, 2));
      } catch (error) {
        console.error('[profile-composition-capture]', error);
      }
      await context.close();
    }''';modified=source[:a]+section.replace(anchor,capture)+source[b:];(W/test).write_text(modified);(D/'red-case-source.ts').write_text(modified);p=prepare('red');print(p)
elif mode=='green':
 a=json.loads((D/'red-verdict-inspected.json').read_text());assert a['acceptedOnlyOriginalSizeOracleFailure'] and a['redReceiptSHA256']==sha((D/'red/receipt.json').read_bytes()) and a['redVitestSHA256']==sha((D/'red/vitest.json').read_bytes());assert json.loads((D/'red/receipt.json').read_text())['exit']!=0
 assert (W/test).read_bytes()==(D/'red-case-source.ts').read_bytes();source=(W/test).read_text();old="          expect(tokens.some((token) => ['h-9', 'size-9'].includes(token))).toBe(true);";new="          expect(tokens).toContain('min-h-8');\n          expect(tokens).toContain('h-auto');";assert source.count(old)==1;(W/test).write_text(source.replace(old,new));(D/'green-case-source.ts').write_bytes((W/test).read_bytes());print(prepare('green'))
elif mode=='seal':
 stage=sys.argv[2];assert stage in ['red','green','apply-source.log','apply-consumer.log','preset-generate.log','preset-check.log'];rp=D/(stage+'/receipt.json' if stage in ['red','green'] else stage+'.receipt.json');terminal=json.loads(rp.read_text());assert 'exit' in terminal,'Stage must be terminal';before=json.loads((D/'before.json').read_text())['files'];assert git('rev-parse','HEAD')==plan['baseHead'];assert sha((W/base).read_bytes())==before[base]['sha256']
 if (W/test).exists():assert any((D/n).exists()and(W/test).read_bytes()==(D/n).read_bytes()for n in ['red-case-source.ts','green-case-source.ts'])
 for a in closure['closure']:
  q=W/a['path'];actual=sha(q.read_bytes())if q.exists()else None;assert actual in [a['originalSHA256'],a['publishedSHA256']]
 cp=W/'apps/www/src/components/Homepage/homepage-showcase.ts';allowed=[before[str(cp.relative_to(W))]['sha256']];tp=D/'temporary-consumer.ts';allowed += [sha(tp.read_bytes())]if tp.exists()else[];assert sha(cp.read_bytes())in allowed
 current=snap(sorted(set(files())|set(before)));save('after-experiment.json',{'at':now(),'files':current,'status':git('status','--porcelain'),'terminalStage':stage,'stageReceiptSHA256':sha(rp.read_bytes()),'originalTestUntouched':True,'sourceCASInputsKnown':True,'generatedArtifacts':'Actual outputs of owned finite experiment; originalbytes retained for restoration'})
 print('Frozen terminal-stage manifest; no restoration yet')
elif mode=='restore':
 before=json.loads((D/'before.json').read_text())['files'];current=json.loads((D/'after-experiment.json').read_text())['files'];assert set(current)==set(files())|set(before);assert snap(list(current))==current,'Managedfile changed after freeze: do not overwrite'
 for n,v in current.items():
  p=W/n;assert (not p.exists()and not v['exists'])or(p.is_file()and sha(p.read_bytes())==v['sha256'])
  original=before.get(n,{'exists':False})
  if original['exists']:
   data=(D/'before'/n).read_bytes();assert sha(data)==original['sha256'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(original['mode'])
  elif p.exists():p.unlink()
 assert snap(list(before))==before;assert not git('status','--porcelain');assert git('rev-parse','HEAD')==plan['baseHead']and git('write-tree')==plan['baseTree'];save('restore-receipt.json',{'at':now(),'head':plan['baseHead'],'tree':plan['baseTree'],'allManagedFilesCASRestored':True,'cliDistExactOriginalBytesRestored':True,'productWorktreeClean':True,'temporaryFamilyNotCommitted':True});print('CAS restored')
else:raise ValueError(mode)
