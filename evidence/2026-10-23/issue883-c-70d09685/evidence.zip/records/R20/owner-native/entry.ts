import {createWebProtoEventRouter as current} from "<WORKTREE>/packages/adapters/base/src/events/web-event-router.ts";
import {createWebProtoEventRouter as reported} from "<WORKTREE>/packages/adapters/base/src/events/feedback-978-router.ts";
window.choose=(source,retire)=>{
 const factory=source==='current'?current:reported;const mark=Symbol.for('@proto.ui/adapter-react/__proto_instance');let first=0,next=0;const trace=[];const old=document.getElementById('original'),fresh=document.getElementById('next');old[mark]=fresh[mark]=true;const log=(type,extra={})=>trace.push({type,ms:performance.now(),epoch:Date.now(),first,next,active:document.activeElement?.id,...extra});
 const a=factory({rootEl:old,isEnabled:()=>true}),b=factory({rootEl:fresh,isEnabled:()=>true});
 const paint=()=>{document.getElementById('counts').textContent=JSON.stringify({source,retire,first,next});};
 a.rootTarget.addEventListener('press.commit',()=>{first++;log('original.commit');if(retire){delete old[mark];old.removeAttribute('role');a.dispose();old.remove();}fresh.focus();paint();log('focus.returned');});
 b.rootTarget.addEventListener('press.commit',()=>{next++;paint();log('next.commit');});
 b.rootTarget.addEventListener('key.down',()=>log('next.key.down'));
 b.globalTarget.addEventListener('key.down',()=>log('global.key.down'));
 for(const target of [document,window])for(const type of ['keydown','keyup','click'])target.addEventListener(type,e=>log((target===document?'document.':'window.')+type,{key:e.key,trusted:e.isTrusted,target:e.target?.id,targetRole:e.target?.getAttribute?.('role')}));
 window.take=()=>({source,retire,first,next,trace:[...trace],active:document.activeElement?.id});paint();old.focus();log('setup.ready');
};