# Exact70d live CI checkpoint

Read-only collection **2026-10-23 10:39:33–10:39:53 UTC**. All pagination completed, noHTTP errors. Source70d/tree7d18 and main81339 were stable at start/end. Workflow/job reads are not an atomic snapshot.

- 38workflowruns from complete headlist plus38check/statusURL runIDs; union38, no referencedrun missing. Everyrun's jobs/artifacts was fully paginated.
- Workflow states:27queued,1pending,3inprogress,5success,2failure.
- 92checkruns:77queued,5inprogress,8success,2failure. One separateVercel failure says authorization is required to deploy.
- 91materialized Actions jobs:76queued,5inprogress,8success,2failure. Check/run/job totals are different surfaces and must not be substituted for one another.
- 11artifactmetadata entries retained; **zeroZIP/media downloads**.

## Priority queues

| Run | Actual state and observed job boundary |
|---|---|
| CI39925882543 | Runqueued;8materialized jobs,7queued without runner and1rust-interop running. test-plan/public_package_plan stillqueued. No actualprimary test/package counts or browsermatrix can yet be supplied. |
| Preview39925882470 | Builddocs job120322018162 queued,runner_id0,emptyrunnername,steps[]. Artifacts0: no exact70dsite/bindingZIP available at thisread. |
| Browserrepair39925882428 | focused-browser120322017917 queued,no assignedrunner,steps[],artifacts0. |
| Startup39925882455 | baseline120322017470 andcandidate120322017664 queued,no assignedrunner,steps[],artifacts0. |

Some queuedjobs have an APIstarted_at value; it does not show executedsteps. Some workflowobjects precede a later successful jobread. Preserve these non-atomic rawstates rather than rewriting them into a synchronized verdict. The preparedlocalproducer was not run.

## Two actual completed failures

**Bootstrap39925882194/job120322016243.** Actualcheckoutlog126 is70d; GitAPI tree equals7d18. Fourfiles45tests:44passed/1failed. Its realbrowserfile15tests allpassed. The failure is `packages/prototypes/bootstrap-2-3-2/test/controls.test.ts:219`, `expect(tokens).toEqual([...DRAFT_FAMILY_STYLE_TOKENS[name]])`:414collected versus437expected,23expected-only entries in the firstcomplete diff. This is a current vocabulary equalityfailure, not a native15casefailure. Rootcause/owningcollection drift remains unassigned; it is not proven identical to the fourCheckbox gap or a new C productionbug. RawlogSHA `628e0ac3507486d1b056b550bd26031b17857bba54874d03cc61e2b827cfd28f`.

**V2optical39925882453/job120322016592.** Actualcheckoutlog124 is70d/tree7d18. Earlier36unitchecks pass; selected44/47publicpackages build and47manifests check; source and packed basicfourruntimeevidence pass. Bothcontinuousarms then fail `experiments/material-v2/continuous-browser.test.mjs:639`, requiring a trusted nativewindowblur in `window.__native`:false!==true. Later contact-rest/noactivation assertions are not reached in that failingbranch. No Portal/cleanup/productcause is established by this input-precondition failure, and no media wasdownloaded. RawlogSHA `bc6b9c3d10c970856b26381613f60a317bb60ae4bfa5780f07916f7f3cbdb2ac`.

The two rawlogs were read once at10:40:55–10:40:58UTC, separatelyfrom the earliercomplete metadata snapshot. BothactualcheckoutSHA bindings were checked against exactsource Gitobjects; runnerimage commit text was not mistaken for productcheckout.

All38run/jobstates,11artifact IDs/digests and complete rawpages are in `20261023T103933Z/summary.json` and `artifact-inventory.json`. No pendingjob log wasrequested, no primary counts guessed, no CIaction/APIwrite/localtest/build/browser/sourceedit performed. This is partial/ABSTAIN with accurate queuedevidence debt; no furtherpoll is scheduled by this task.
