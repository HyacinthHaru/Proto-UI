四个新增失败workflow的完整job metadata与5份原日志已只读收齐，全部直接checkout70d/tree7d18，0获取错误。结论partial / ABSTAIN；没有据此成立可直接修的新增C生产缺陷。

| Workflow | 实际终态与首断点 |
|---|---|
| Accordion39925882317 | 输入契约24/24；native24/25。唯一LiquidGlass React在Space关闭secondtrigger并读aria-controls=null后，freshEnter→原277行expanded(true)的1000ms仍false。|
| LibraryCard39925882364 | CJK apt下载61.2MB包的原3分钟步骤超时；9个browser计划全部未执行。|
| TOC39925882493 | candidate契约9/9、真实build完成；continuous-reverse缺目标变化、插值、至少500px文档位移、productupdates四项，capture exit1。随后固定411c参考契约16/16及build/capture步骤success，不能抹掉candidate红。|
| RuntimeSwitch39925882595 | browserjob CJK3分钟超时，原14项未执行；独立productionRetry sibling实际6/6通过。|

Accordion获准只下载一次现成artifact12496297430：6,236,271B，SHA1f90901e…5574，177成员CRC/安全/hash全核，选择7个原文本。其source70d、Chrome155.0.8059.39、Node24.21.0明确。只有initial与第一次overview关闭JSON；最后前置捕获10:54:15.483早于本次secondtrigger的Space/freshEnter失败。因此早期trustedInputs、materialopaque-fallback和后续独立320px阳性都不能填补失败瞬间的focus/owner/gate/原getter时序。Csharedrouter参与链路，但没有证据指认它或Reactgate为原因，不能叫flake或凭未改文件称继承。

最小后续缺口是同原失败分支保存既有input journal及currentsecondtrigger公开身份、focus/connection/generation/pending/aria与公开Root状态，保留原error和1000ms，不增加按键或生产修复。TOC stdout没有nativewheel ingress/取消/边界事实，只保留四个不满足条件，不归C。两个字体setup超时不得记成browserfail或pass。

未重跑Actions、测试或浏览器，未改源码/断言/deadline，未外部写。完整准确source/hash/计数/限制见triage.json。
