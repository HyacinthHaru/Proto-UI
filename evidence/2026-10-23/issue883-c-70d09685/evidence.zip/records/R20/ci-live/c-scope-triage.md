# C-scope triage — exact70d, source and retained logs only

**Bootstrap has a concrete fixture input-domain mismatch; neither failure establishes a new C production defect. V2 native-blur causality remains unknown. Partial / ABSTAIN.**

## Bootstrap: actual inherited-source closure mismatch

The failed `controls.test.ts:217-219` scans only `packages/prototypes/bootstrap-2-3-2/src` with `collectProtoStyleTokens`, then compares it to a generatedtable that uses `collectFamilyStyleClosure(familyRoot, baseRoot)`. The latter intentionally follows actual non-type Base valueimports; the former scans its supplieddirectory and relativeimportedconstants, without executingBase hooks oraddingpackage-subpathfiles. This is a concrete different-input-domain comparison, not a reason todelete23expectedtokens orpatchCompilerIR.

The23expected-only tokens allhave exactBase literal witnesses. JSON lists everytoken/line/hash. Grouped witnesses:

- BaseResizable `resizable.proto.ts:210`: `basis-[calc(var(--pui-size)*1%)]`, `grow-0`, `shrink`.
- BaseDrawer `content.proto.ts:131,137,146`: `content-start`, available-regionheight/top/left/drag-progress width tokens.
- BaseDrawer `handle.proto.ts:187,194,201,208`: `top-1`, `bottom-1`, `left-1`, `right-1`, `h-2`, `h-12`, `w-2`, `w-12`, bothresizecursors.
- BaseAlertDialog `content.proto.ts:265`: available-region max-height/max-width. TheBaseDialogduplicate isnotneeded toprove theactualBootstrap importchain.
- BaseSelect `content.proto.ts:477`: `invisible`; BaseContextMenu `content.proto.ts:341` gives a separate reachable `z-40` witness (also presentinSelect/Dropdown).

There **is** a realdependency on retainedC BaseSelect; it must not be dismissed because thefailingfile belongs toBootstrap. But main81339→70d's Selectdelta ispreparing-close focusordering: theinvisible/z-40 style/rule tail isbyte-identical. Thetest,collector,generator,generatedtable andothermissingtoken sources aremain-equal. The50retainedCfiles arepartofa55-net-path branch; noSource-role collection/expectedtable change isamongthem.

Historicalevidence isactual: ac run39834975567/job120020775813 logged44pass/1fail withbrowser15allpass, controls219 and the **same23expected-only tokens**. RawlogSHA `35c6ae6b6dd120fe22b1652a1bad96869c4e6616d8faef9d69f03c9df3e01dbe`. Itscheckout andmetadata bindac, andall25existingreviewed sourcefilesarebyte-equalac→70d. Thus thissamefailure ishistorically demonstrated, not assumedfromanoldredname. Nofirst-introduction claim follows.

`T-BOOTSTRAP-2-3-2-CONTROLS-0001` is**draft** andcatalogsBaseinheritance/tokenclosure; itsoldpassinglabel doesnot override actualCI. Minimalcandidate for theowningfamily/preset fixture is reuseexisting`collectFamilyStyleClosure`, retainingoriginal`toEqual`andCSSsupportassertions. Noexpectedchange/collector takeover, patch ornewrun wasperformed.

## V2: no observed qualifying native event is not proof of router mishandling

Thefixture's own capture-phasewindowlistener records`type`, `isTrusted`, `windowTarget` into`window.__native` (82–120). At626 it freezesanindex, then performs theoriginalmousedown/newpage/bringToFront/mouseup/return sequencewith40/100/400ms waits. Line639 reads thatslice andrequiresa trustedwindowtargetblur. Bothsource/packedarms returnedfalse. This proves **no matchingentry in thatslice atthatread**. It doesnot prove no blur wasgenerated, any particular enginecause, orrouterreceiptfollowedbymishandling.

TheCrouter isindeedadependency; its503–506globalblurlistener endscontactandemitscancelwhenenabled. Thatblock ismain-equal, while theCdelta touchesVue2markers/keyboardowner. Thefailedassertion doesnotreadrouterstate. Downstream contact-rest/noactivation assertions648–652 were notreached; relabellingthisasPortal/cleanupfailurewouldbeincorrect.

Theexistingcatch retains`failure-state.json` withnative/contacts/frames, but itwasnotdownloadedorreadhere. IfRootlaterchoosesinspection, thoseexistingJSONs aretheminimum next evidence beforea newprobe; rawlogalone cannot distinguish missinggeneration fromdelivery/observationloss. Do notsynthesizeblur, addwaits orrelax639. TheapplicableMaterialContact/optical entities remain**draft**; nooptical/admissionupgrade isclaimed.

All23mappings, three-refSHAcomparisons, exactold/currentlogbindings andunknowns arein`c-scope-triage.json`. NoAPI,test,browser,collector run, sourceedit ornewownershipclaim occurred.
