已核全部实际对照与清理，0个具体来源/计数finding；结论partial / ABSTAIN，不是GitHub批准。

同一a63e23a3私有Nodefixture只切FEEDBACK_SOURCE：旧0c8router为live Enter/Space两过、retired Enter/Space两红（原expected press/key0/0，actual1/1）；当前70d四过。旧unit红在该断言即停止，不能称继续执行freshkey；真实native控制则保留后续输入。

实际8条bareRouter原生journey为旧live2过、旧retired2失败、当前4过。旧retired第一次同键nextpress/rootkey各1，当前均0。全部8条后续freshkey各新增nextpress/rootkey1，global从1到2，焦点在next。64条document/windowkeydown/up观察均isTrusted=true，但这是每journey两组down/up的双阶段观察，不是64个独立键。launcherexit0代表预期对比成立，不是8个当前产品case全绿。

唯一成功启动的native运行使用Playwright1.58.2/Chrome145.0.7632.6，10:47:51.705–10:47:54.848UTC。首次root包MODULE_NOT_FOUND在输出目录/server/browser建立前发生，0case；原script与failureJSON保留，修正为apps-www依赖owner解析后才有实际浏览器执行。没有安装依赖或production改动。

metafile实际5inputs：70d当前router+2shared依赖、准确0c8router副本、私有entry。只用Reactsymbol标记两个普通DOMroot，不是ReactAdapter、Select或四框架组合。8张640×300PNG在首keydown后、keyup/freshkey前拍摄，hash已绑定；本审阅不替代root像素查看。截图有时间扰动，不称hosted原场景复刻。

原3files另有26/26：owner17、nativefocus2、WCrouter7。四次执行tracked census均11362相同且各自前后相同，额外输入亦稳定。browser/server终态closedtrue，八个context的finally close完成；没有单独isClosed逐项采样。两临时W文件按冻结hash删除，当前clean70d，生产源码未变。

结果支持旧source缺口与当前修复的区别，不代替#978/#982组合native验证或声称新70d问题已修。完整receipt、SHA与逐journey计数见JSON。审阅未运行测试/浏览器/API、未改W或外部写入。
