import { afterEach, describe, expect, it, vi } from 'vitest';
import { createWebProtoEventRouter as current } from '../src/events/web-event-router';
import { createWebProtoEventRouter as reported } from '../src/events/feedback-978-router';
const dispose: (() => void)[] = [];
afterEach(() => { dispose.splice(0).reverse().forEach(fn => fn()); });
const router = process.env.FEEDBACK_SOURCE === 'reported' ? reported : current;
describe('reported native activation owner boundary', () => {
  for (const retirement of [false, true]) for (const key of ['Enter', ' ']) {
    it(`${retirement ? 'retired' : 'live'} original owner retains ${JSON.stringify(key)}, later events remain eligible`, () => {
      const mark = Symbol.for('@proto.ui/adapter-react/__proto_instance');
      const original = document.createElement('div'); const next = document.createElement('div');
      original.tabIndex = next.tabIndex = 0;
      (original as any)[mark] = (next as any)[mark] = true;
      document.body.append(original, next);
      const a = router({rootEl: original, isEnabled: () => true});
      const b = router({rootEl: next, isEnabled: () => true});
      dispose.push(() => { a.dispose(); b.dispose(); original.remove(); next.remove(); });
      const moved = vi.fn(); const globalKey = vi.fn(); const nextKey = vi.fn();
      b.rootTarget.addEventListener('press.commit', moved);
      b.rootTarget.addEventListener('key.down', nextKey);
      b.globalTarget.addEventListener('key.down', globalKey);
      const first = vi.fn(() => {
        if (retirement) { delete (original as any)[mark]; a.dispose(); original.remove(); }
        next.focus();
      });
      a.rootTarget.addEventListener('press.commit', first);
      original.focus();
      original.dispatchEvent(new KeyboardEvent('keydown', {key, bubbles: true, composed: true}));
      expect(first).toHaveBeenCalledOnce();
      expect(document.activeElement).toBe(next);
      expect(globalKey).toHaveBeenCalledOnce();
      expect({presses: moved.mock.calls.length, keys: nextKey.mock.calls.length}).toEqual({presses: 0, keys: 0});
      next.dispatchEvent(new KeyboardEvent('keyup', {key, bubbles: true, composed: true}));
      next.dispatchEvent(new KeyboardEvent('keydown', {key, bubbles: true, composed: true}));
      expect(moved).toHaveBeenCalledOnce();
      expect(nextKey).toHaveBeenCalledOnce();
      expect(globalKey).toHaveBeenCalledTimes(2);
    });
  }
});
