from pathlib import Path
import subprocess,json,datetime,hashlib,concurrent.futures,collections
R=Path(__file__).resolve().parent;prior=R.parent/'read-1';repo='repos/Proto-UI/Proto-UI';run=39965405460

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def command(name,argv,paged=False,asJSON=True):
 p=R/name;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():raise RuntimeError('Refuse replacing '+name)
 start=now()
 try:q=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=55);code=q.returncode;out=q.stdout;err=q.stderr
 except subprocess.TimeoutExpired as e:code=124;out=e.stdout or b'';err=e.stderr or b''
 p.write_bytes(out);Path(str(p)+'.stderr').write_bytes(err);rc={'start':start,'end':now(),'argv':argv,'exit':code,'bytes':len(out),'sha256':hashlib.sha256(out).hexdigest(),'readOnly':True,'paged':paged,'attempt':1};Path(str(p)+'.receipt.json').write_text(json.dumps(rc,indent=2)+'\n');x={'name':name,'receipt':rc}
 if code:x['error']=err.decode(errors='replace')
 elif asJSON:
  try:x['data']=json.loads(out)
  except Exception as e:x['error']='JSON: '+str(e)
 return x
def get(t):
 name,url,paged=t;return command(name,['gh','api',url]+(['--paginate','--slurp']if paged else[]),paged)
start=now();tasks=[('pr.json',repo+'/pulls/921',False),('main-ref.json',repo+'/git/ref/heads/main',False),('run.json',repo+f'/actions/runs/{run}',False),('jobs-pages.json',repo+f'/actions/runs/{run}/jobs?per_page=100&filter=latest',True),('artifacts-pages.json',repo+f'/actions/runs/{run}/artifacts?per_page=100',True)]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:results=list(p.map(get,tasks))
errors=[{'name':x['name'],'error':x['error']}for x in results if'error'in x];data={x['name']:x['data']for x in results if'data'in x};s={'readStart':start,'metadataReadEnd':now(),'atomicSnapshot':False,'errors':errors,'newLogs':[]}
if not errors:
 pr=data['pr.json'];oldpr=json.loads((prior/'pr.json').read_text());jp=data['jobs-pages.json'];ap=data['artifacts-pages.json'];jobs=[j for p in jp for j in p['jobs']];arts=[a for p in ap for a in p['artifacts']];old=json.loads((prior/'snapshot.json').read_text());oldjobs={j['id']:j for j in old['runs']['main']['jobRows']}
 s.update({'sourceHead':pr['head']['sha'],'main':data['main-ref.json']['object']['sha'],'pr':{k:pr.get(k)for k in ['state','draft','merged','updated_at','comments','review_comments']},'run':{k:data['run.json'].get(k)for k in ['id','name','status','conclusion','head_sha','run_attempt','updated_at']},'jobs':{'reported':jp[0]['total_count'],'received':len(jobs),'unique':len({j['id']for j in jobs}),'pages':len(jp),'paginationComplete':len(jobs)==jp[0]['total_count']==len({j['id']for j in jobs}),'statusCounts':dict(collections.Counter(j['status']for j in jobs)),'terminalConclusions':dict(collections.Counter(j['conclusion']for j in jobs if j['status']=='completed'))},'jobRows':[{k:j.get(k)for k in ['id','name','status','conclusion','started_at','completed_at','head_sha','html_url']}for j in jobs],'artifacts':{'reported':ap[0]['total_count'],'received':len(arts),'unique':len({a['id']for a in arts}),'pages':len(ap),'paginationComplete':len(arts)==ap[0]['total_count']==len({a['id']for a in arts}),'downloaded':False},'feedback':{'priorCompleteRead':str(prior),'priorUpdatedAt':oldpr['updated_at'],'currentUpdatedAt':pr['updated_at'],'metadataChanged':oldpr['updated_at']!=pr['updated_at']}})
 if pr['updated_at']!=oldpr['updated_at']:
  x=get(('comments-pages.json',repo+'/issues/921/comments?per_page=100',True))
  if'error'in x:errors.append({'name':x['name'],'error':x['error']})
  else:
   comments=[c for p in x['data']for c in p];prev=[c for p in json.loads((prior/'comments-pages.json').read_text())for c in p];ids={c['id']:c for c in prev};changed=[c for c in comments if c['id']not in ids or c['body']!=ids[c['id']]['body']or c['updated_at']!=ids[c['id']]['updated_at']];(R/'changed-comments.json').write_text(json.dumps(changed,indent=2)+'\n');s['feedback'].update({'commentsRead':len(comments),'paginationComplete':len(comments)==pr['comments'],'changed':len(changed),'changedIds':[c['id']for c in changed]})
 else:s['feedback'].update({'commentsReRead':False,'priorComments':75,'priorReviews':0,'priorInline':0,'priorThreads':0,'note':'No update signal; prior complete feedback retained as prior-time evidence.'})
 new=[j for j in jobs if j['status']=='completed' and oldjobs.get(j['id'],{}).get('status')!='completed' and (j['name'].startswith('test')or j['name'].startswith('public_package'))]
 for j in new:
  name=f'logs/{j["id"]}.log';x=command(name,['gh','api',repo+f'/actions/jobs/{j["id"]}/logs'],asJSON=False);s['newLogs'].append({'jobId':j['id'],'name':j['name'],'conclusion':j['conclusion'],'receipt':x['receipt'],'error':x.get('error')})
  if'error'in x:errors.append({'name':name,'error':x['error']})
s['readEnd']=now();(R/'snapshot.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({k:v for k,v in s.items()if k!='jobRows'},indent=2))
