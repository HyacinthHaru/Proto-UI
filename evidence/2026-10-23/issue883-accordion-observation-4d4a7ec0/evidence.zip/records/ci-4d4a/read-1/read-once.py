from pathlib import Path
import subprocess,concurrent.futures,datetime,json,hashlib,re,collections
R=Path(__file__).resolve().parent;BASE=R.parents[1];repo='repos/Proto-UI/Proto-UI';runs={'main':39965405460,'accordion':39965405725};head='4d4a7ec071dd83756444cbebf5a4c8b3bea81bcf'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def command(name,argv,paged=False,jsonOutput=True):
 p=R/name;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():raise RuntimeError('refuse replacing '+name)
 start=now()
 try:q=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=55);code=q.returncode;out=q.stdout;err=q.stderr
 except subprocess.TimeoutExpired as e:code=124;out=e.stdout or b'';err=e.stderr or b''
 p.write_bytes(out);Path(str(p)+'.stderr').write_bytes(err);rc={'start':start,'end':now(),'argv':argv,'exit':code,'bytes':len(out),'sha256':hashlib.sha256(out).hexdigest(),'networkReadOnly':True,'paged':paged,'attempt':1};Path(str(p)+'.receipt.json').write_text(json.dumps(rc,indent=2)+'\n')
 result={'name':name,'receipt':rc}
 if code:result['error']=err.decode(errors='replace')
 elif jsonOutput:
  try:result['data']=json.loads(out)
  except Exception as e:result['error']='JSON: '+str(e)
 else:result['text']=out.decode(errors='replace')
 return result
def get(t):
 name,url,paged=t;return command(name,['gh','api',url]+(['--paginate','--slurp']if paged else[]),paged)
start=now();tasks=[('pr.json',repo+'/pulls/921',False),('main-ref.json',repo+'/git/ref/heads/main',False),('comments-pages.json',repo+'/issues/921/comments?per_page=100',True),('reviews-pages.json',repo+'/pulls/921/reviews?per_page=100',True),('inline-pages.json',repo+'/pulls/921/comments?per_page=100',True),('head-commit.json',repo+'/git/commits/'+head,False)]
for k,n in runs.items():tasks += [(f'{k}/run.json',repo+f'/actions/runs/{n}',False),(f'{k}/jobs-pages.json',repo+f'/actions/runs/{n}/jobs?per_page=100&filter=latest',True),(f'{k}/artifacts-pages.json',repo+f'/actions/runs/{n}/artifacts?per_page=100',True)]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:results=list(p.map(get,tasks))
errors=[{'name':x['name'],'error':x['error']}for x in results if'error'in x];data={x['name']:x['data']for x in results if'data'in x};threads=[];cursor=None;page=0;threadComplete=False
while not errors:
 page+=1;var=',$cursor:String!'if cursor else'';after=',after:$cursor'if cursor else''
 query='query($number:Int!'+var+'){repository(owner:"Proto-UI",name:"Proto-UI"){pullRequest(number:$number){headRefOid baseRefOid state reviewDecision reviewThreads(first:100'+after+'){totalCount pageInfo{hasNextPage endCursor}nodes{id isResolved isOutdated path line comments(first:100){pageInfo{hasNextPage endCursor}nodes{id databaseId body createdAt updatedAt url author{login}}}}}}}}'
 argv=['gh','api','graphql','-F','number=921','-f','query='+query]+(['-f','cursor='+cursor]if cursor else[]);x=command(f'threads/page-{page}.json',argv)
 if 'error'in x or x.get('data',{}).get('errors'):errors.append({'name':x['name'],'error':x.get('error',x.get('data',{}).get('errors'))});break
 conn=x['data']['data']['repository']['pullRequest']['reviewThreads'];threads+=conn['nodes']
 for t in conn['nodes']:
  comments=t['comments'];cp=1
  while comments['pageInfo']['hasNextPage']:
   cp+=1;q='query($id:ID!,$cursor:String!){node(id:$id){...on PullRequestReviewThread{comments(first:100,after:$cursor){pageInfo{hasNextPage endCursor}nodes{id databaseId body createdAt updatedAt url author{login}}}}}}'
   x2=command(f'threads/{t["id"]}-comments-{cp}.json',['gh','api','graphql','-f','query='+q,'-f','id='+t['id'],'-f','cursor='+comments['pageInfo']['endCursor']])
   if 'error'in x2 or x2.get('data',{}).get('errors'):errors.append({'name':x2['name'],'error':x2.get('error',x2.get('data',{}).get('errors'))});break
   comments=x2['data']['data']['node']['comments'];t['comments']['nodes']+=comments['nodes']
 if errors:break
 if not conn['pageInfo']['hasNextPage']:threadComplete=len(threads)==conn['totalCount'];break
 cursor=conn['pageInfo']['endCursor']
(R/'threads-complete.json').write_text(json.dumps(threads,indent=2)+'\n');metaEnd=now();summary={'readStart':start,'metadataReadEnd':metaEnd,'atomicSnapshot':False,'errors':errors,'threads':{'received':len(threads),'pages':page,'paginationComplete':threadComplete},'runs':{},'logs':[],'checkoutObjects':[]}
if not errors:
 pr=data['pr.json'];c=data['head-commit.json'];comments=[x for pg in data['comments-pages.json']for x in pg];reviews=[x for pg in data['reviews-pages.json']for x in pg];inline=[x for pg in data['inline-pages.json']for x in pg]
 previousPath=BASE/'live/comments921.json';previous=[x for pg in json.loads(previousPath.read_text())for x in pg];old={x['id']:x for x in previous};changed=[x for x in comments if x['id']not in old or x['body']!=old[x['id']]['body'] or x['updated_at']!=old[x['id']]['updated_at']]
 (R/'changed-comments.json').write_text(json.dumps(changed,indent=2)+'\n')
 summary.update({'sourceHead':pr['head']['sha'],'main':data['main-ref.json']['object']['sha'],'state':pr['state'],'draft':pr['draft'],'merged':pr['merged'],'baseAPI':pr['base']['sha'],'headCommit':{'sha':c['sha'],'tree':c['tree']['sha'],'parents':[p['sha']for p in c['parents']]},'comments':{'received':len(comments),'reportedByPR':pr['comments'],'paginationComplete':len(comments)==pr['comments'],'previousCount':len(previous),'changed':len(changed),'changedIds':[x['id']for x in changed],'previousSource':str(previousPath)},'reviews':{'received':len(reviews),'pages':len(data['reviews-pages.json']),'paginationComplete':True},'inline':{'received':len(inline),'reportedByPR':pr['review_comments'],'paginationComplete':len(inline)==pr['review_comments']}})
 for k,runId in runs.items():
  run=data[f'{k}/run.json'];jp=data[f'{k}/jobs-pages.json'];ap=data[f'{k}/artifacts-pages.json'];jobs=[j for p in jp for j in p['jobs']];arts=[a for p in ap for a in p['artifacts']]
  summary['runs'][k]={'run':{x:run.get(x)for x in ['id','name','status','conclusion','head_sha','run_attempt','updated_at','html_url']},'jobs':{'reported':jp[0]['total_count'],'received':len(jobs),'pages':len(jp),'paginationComplete':len(jobs)==jp[0]['total_count']==len({j['id']for j in jobs}),'statusCounts':dict(collections.Counter(j['status']for j in jobs)),'terminalConclusions':dict(collections.Counter(j['conclusion']for j in jobs if j['status']=='completed'))},'jobRows':[{a:j.get(a)for a in ['id','name','status','conclusion','started_at','completed_at','head_sha','html_url']}for j in jobs],'artifacts':{'reported':ap[0]['total_count'],'received':len(arts),'pages':len(ap),'paginationComplete':len(arts)==ap[0]['total_count']==len({a['id']for a in arts}),'downloaded':False}}
  targets=[j for j in jobs if j['status']=='completed' and (k=='accordion' or j['name'].startswith('test') or j['name'].startswith('public_package'))]
  for j in targets:
   result=command(f'logs/{j["id"]}.log',['gh','api',repo+f'/actions/jobs/{j["id"]}/logs'],jsonOutput=False);entry={'jobId':j['id'],'runKind':k,'runId':runId,'jobName':j['name'],'conclusion':j['conclusion'],'receipt':result['receipt']}
   if'error'in result:entry['error']=result['error'];errors.append({'name':result['name'],'error':result['error']})
   else:
    text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',result['text']);entry['checkouts']=sorted(set(re.findall(r'git log -1 --format=%H\s*\n[^\n]*?Z ([0-9a-f]{40})',text)+re.findall(r'"checkoutSha":"([0-9a-f]{40})"',text)))
   summary['logs'].append(entry)
 for sha in sorted({sha for x in summary['logs']for sha in x.get('checkouts',[])}):
  if sha==head:obj=data['head-commit.json'];summary['checkoutObjects'].append({'sha':sha,'tree':obj['tree']['sha'],'parents':[p['sha']for p in obj['parents']],'path':'head-commit.json','newFetch':False})
  else:
   x=get((f'checkout-{sha}.json',repo+'/git/commits/'+sha,False))
   if'error'in x:errors.append({'name':x['name'],'error':x['error']})
   else:obj=x['data'];summary['checkoutObjects'].append({'sha':sha,'tree':obj['tree']['sha'],'parents':[p['sha']for p in obj['parents']],'path':x['name'],'newFetch':True})
summary['readEnd']=now();(R/'snapshot.json').write_text(json.dumps(summary,indent=2)+'\n');display={k:v for k,v in summary.items() if k not in ['logs','runs']};display['runs']={k:{a:b for a,b in v.items()if a!='jobRows'}for k,v in summary['runs'].items()};display['logs']=[{a:x.get(a)for a in ['jobId','runKind','jobName','conclusion','checkouts','error']}for x in summary['logs']];print(json.dumps(display,indent=2))
