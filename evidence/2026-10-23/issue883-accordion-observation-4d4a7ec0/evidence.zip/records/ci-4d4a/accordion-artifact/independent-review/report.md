官方Accordion39965405725/job120453846404的原25case全部通过。Artifact12506673984完整ZIP6,565,532B，SHA d6d9b7f1176de30edf981828d6674ecf80d1089c99e00c333ab81dfbc4ecf0ac等metadata；185成员目录/CRC-size元数据齐全。本审查独立重算非PNG成员及提取字节，PNG未打开、没有像素审阅；Root此前完整CRC/extract核验单独标明。source-sha精确4d4a，2个实际Vite transform回执与该Git插件/原Adapter源码机械回放hash一致，7SDKpins一致。

Main79rows/0drop/error，SDK6requests/6batch/6guardpass均complete，0pending/drop/error，contextClosed和disposed=true。transportComplete=false保留，不能把6个匹配请求扩大成全部19个poll或所有transport。

同次阳性序列：Space7243.2→root enabled7244.1→press.commit7244.4–7248.4，expanded true到false；gate7334.1 disable→7383.6 enable；freshEnter7394.5→root enabled7394.9→press.commit7395.2–7398.6，expanded false到true。原poll9约51.537ms，poll10约10.785ms均通过。后者call@2550/attempt1原browser selector7440.7–7441.3，getter在两次相同采样时间7441.4返回true；不能称测得0ms执行或tick长度。窗口在下个原Tab7539.3停止。输入始终main:2/private token18/publicReact generation2；private React viewGeneration1是另一计数。finally finalActive为后续Vue/gen3，不作原输入焦点证据。

这是真实新官方instrumented阳性，未复现旧自然失败，未证明产品根因或race消失。观察成本、异步reaction/patch时点、事件null关联和clock未校准等界限保留。0具体来源/算术finding，partial/ABSTAIN，非正式批准。
