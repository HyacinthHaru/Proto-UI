from pathlib import Path, PurePosixPath
import collections, datetime, hashlib, json, re, subprocess, zipfile, zlib

D=Path(__file__).resolve().parent; A=D.parent; R=A.parent.parent; E=A/'extracted'
W=Path('<WORKTREE>')
H='4d4a7ec071dd83756444cbebf5a4c8b3bea81bcf'; T='8af15e292175a4366691acb3834e8cb4331c3a77'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
receipt=load(A/'download-receipt.json'); members=load(A/'members.json')
metadata=[x for page in load(R/'ci-4d4a/read-1/accordion/artifacts-pages.json') for x in page['artifacts'] if x['id']==receipt['id']]
assert len(metadata)==1; metadata=metadata[0]
archive_sha=sha((A/'original.zip').read_bytes())
assert archive_sha==receipt['sha256']==metadata['digest'].removeprefix('sha256:')
assert (A/'original.zip').stat().st_size==receipt['bytes']==metadata['size_in_bytes']
assert metadata['workflow_run']['head_sha']==H
manifest={row['path']:row for row in members}; verified=[]; image_count=0
with zipfile.ZipFile(A/'original.zip') as archive:
    infos=archive.infolist(); assert len(infos)==len(manifest)==185
    assert len({x.filename for x in infos})==len(infos)
    assert set(x.filename for x in infos)==set(manifest)
    for info in infos:
        p=PurePosixPath(info.filename); assert not p.is_absolute() and '..' not in p.parts and not info.is_dir()
        row=manifest[info.filename]; assert info.file_size==row['bytes'] and info.CRC==row['crc32']
        if info.filename.endswith('.png'):
            image_count+=1
            continue
        raw=archive.read(info); extracted=(E/info.filename).read_bytes()
        assert raw==extracted and sha(raw)==row['sha256'] and zlib.crc32(raw)==row['crc32']
        verified.append({'path':info.filename,'sha256':sha(raw),'bytes':len(raw)})

before=load(E/'activation/activation-before-close.json'); final=load(E/'activation/activation-final.json')
m=before['main']; n=final['node']; v=load(E/'vitest.json')
assert (v['numPassedTests'],v['numFailedTests'],v['numPendingTests'],len(v['testResults']))==(25,0,0,1)
assert (E/'source-sha.txt').read_text().strip()==H
assert final['contextClosed'] and n['disposed'] and n['errors']==[]
assert n['capturedOriginalRequests']==len(n['requests'])==len(n['browserBatches'])==6
assert n['mappingCompleteAtSnapshot'] and n['pendingCapturedRequests']==0
assert m['errors']==m['dropped']==n['dropped']==n['browserDropped']==final['callerDiagnosticErrors']==0
assert len(m['rows'])==79

plugin=subprocess.check_output(['git','show',H+':apps/www/scripts/accordion-activation-probe.mjs'],cwd=W).decode()
transforms=[]
for name, section, marker, relative in [
    ('router','routerSplices','const reactSplices','packages/adapters/base/src/events/web-event-router.ts'),
    ('react','reactSplices','/** Test-only','packages/adapters/react/src/adapt.ts'),
]:
    part=plugin.split('const '+section+' = [',1)[1].split(marker,1)[0]
    splices=re.findall(r"name: '([^']+)',\s+before: `([\s\S]*?)`,\s+after: `([\s\S]*?)`,",part)
    assert len(splices)==(5 if name=='router' else 1)
    original=subprocess.check_output(['git','show',H+':'+relative],cwd=W); transformed=original.decode()
    for label,old,new in splices:
        assert transformed.count(old)==1
        transformed=transformed.replace(old,new,1)
    paths=list((E/'activation/source-transforms').glob(name+'-*.json')); assert len(paths)==1
    recorded=load(paths[0]); assert recorded['relativePath']==relative
    assert recorded['beforeSHA']==sha(original) and recorded['afterSHA']==sha(transformed.encode())
    assert recorded['shapes']==[x[0] for x in splices] and recorded['stage']=='test-onlyViteServe'
    transforms.append({'path':relative,'gitBlob':subprocess.check_output(['git','rev-parse',H+':'+relative],cwd=W,text=True).strip(),
        'originalSHA256':sha(original),'staticTransformedSHA256':sha(transformed.encode()),'recordedReceipt':recorded,
        'receiptSHA256':sha(paths[0].read_bytes()),'mechanicalStringReplayOnly':True})

sdk_root=W/'node_modules/.pnpm/playwright-core@1.58.2/node_modules/playwright-core'
pins=[{'path':x['path'],'recordedSHA256':x['sha256'],'localPinnedSHA256':sha((sdk_root/x['path']).read_bytes())}for x in n['sourceBindings']]
assert len(pins)==7 and all(x['recordedSHA256']==x['localPinnedSHA256']for x in pins)

def slim_node(value):
    if not isinstance(value,dict):return value
    result={key:value.get(key)for key in ['identity','ref','tag','connected','expanded','controls','disabled']}
    own=next((o for o in value.get('owners',[]) if o['identity']==value.get('identity')),None)
    if own:result['publicAttributes']=dict(own['attributes'])
    return result
timeline=[]
for index,row in enumerate(m['rows']):
    keep=row['stage'] in ['document.capture','router.enabled','react.gate.disable','react.gate.enable'] or row['stage'].startswith('router.emit') and row.get('type')=='press.commit'
    if not keep:continue
    entry={'rowIndex':index,**{k:value for k,value in row.items()if isinstance(value,(str,int,float,bool))or value is None}}
    for k in ['root','target']:
        if k in row:entry[k]=slim_node(row[k])
    if isinstance(row.get('active'),dict):entry['activeElement']=slim_node(row['active'])
    elif 'active'in row:entry['routerActive']=row['active'];entry.pop('active',None)
    timeline.append(entry)
polls={};requests=[]
for row in before['polls']:polls.setdefault(row['pollId'],[]).append(row)
for req in n['requests']:
    call=req['callId']; batch=[b for b in n['browserBatches']if b['callId']==call]; assert len(batch)==1
    batch=batch[0];assert batch['attempt']==req['attempts']==1 and req['settled'] and batch['diagnosticErrors']==0
    stages={x['stage']:x for x in batch['rows']}; assert stages['getter.exit']['value']==str(req['query']['expected']).lower()
    pr=polls[req['query']['pollId']]; assert [x['stage']for x in pr]==['poll.begin','poll.pass']
    requests.append({'callId':call,'query':req['query'],'attempt':1,'settled':True,'pollDurationMs':pr[1]['nodeMs']-pr[0]['nodeMs'],
        'browserRows':batch['rows'],'nodeRows':[row for row in n['rows']if row.get('callId')==call],
        'selectorObservedMs':stages['selector.exit']['pageMs']-stages['selector.enter']['pageMs'],
        'getterObservedMs':stages['getter.exit']['pageMs']-stages['getter.enter']['pageMs']})
(D/'phase-sequence.json').write_text(json.dumps({'sourceHead':H,'mainTimeline':timeline,'capturedRequests':requests},indent=2)+'\n')
report={'reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'disposition':'partial/ABSTAIN','formalApproval':False,'findings':[],
    'scope':'Read-only review of the already-downloaded official artifact and immutable source; no API/test/browser or PNG pixel read.',
    'sourceHead':H,'sourceTree':T,'runId':39965405725,'jobId':120453846404,
    'artifact':{'id':receipt['id'],'name':metadata['name'],'sha256':archive_sha,'bytes':receipt['bytes'],'entries':185,'regularUniqueSafeNames':True,
        'allDeclaredCRCSizeMetadataMatchManifest':True,'nonPNGMembersRecomputed':len(verified),'pngMembersNotOpened':image_count,
        'zipAndExtractedNonPNGBytesEqual':True,'rootEarlierFullCRCVerification':'Root reported complete185-member CRC/extraction verification; this review independently recomputed non-PNG bytes and checked all central-directory CRC/size metadata.'},
    'result':{'files':1,'passed':25,'failed':0,'skipped':0,'sourceShaText':H,'browser':(E/'browser-environment.txt').read_text().strip(),'node':(E/'node-environment.txt').read_text().strip(),
        'kind':'Official instrumented dedicated positive run, not natural failure reproduction or wholeCI acceptance'},
    'sourceTransforms':transforms,'sdkPins':pins,
    'mainLedger':{'rows':len(m['rows']),'stages':dict(collections.Counter(x['stage']for x in m['rows'])),'errors':m['errors'],'dropped':m['dropped'],
        'windowStartPageMs':m['windowStart'],'windowStopPageMs':m['windowStop']['at'],'windowStopReason':m['windowStop']['reason'],'windowStopKey':m['windowStop']['key'],
        'targetDuringInput':slim_node(m['windowStop']['target']),'laterFinalActive':slim_node(m['finalActive']),
        'finalActiveLimit':'finalActive is later Vue/gen3 runtime state, not the React/gen2 input-time focus; use contemporaneous document.capture rows.'},
    'sdkHealth':{k:n[k]for k in ['available','capturedOriginalRequests','pendingCapturedRequests','evaluatorGuardPasses','evaluatorGuardFailures','mappingCompleteAtSnapshot','errors','dropped','browserDropped','disposed','extraQueryOrRPC','transportComplete','clockTickLengthMeasured']},
    'cleanup':{'contextClosed':final['contextClosed'],'sdkDisposed':n['disposed'],'sdkErrors':n['errors'],'callerDiagnosticErrors':final['callerDiagnosticErrors'],
        'limit':'Main-world listeners retire with the context; no separate main-world descriptor restoration or OS process hard-deadline proof is inferred.'},
    'spaceEnterFacts':['Space main:1 captured7243.2; root gate enabled7244.1; one press.commit before7244.4/after7248.4, expanded true->false and controls null.',
        'Same trigger main:2/token main:18/router main:20; React gate main:19 disable7334.1 then enable7383.6, privateviewGeneration1 distinct from publicprojectionGeneration2.',
        'Fresh Enter main:28 captured7394.5; same root gate enabled7394.9; one press.commit before7395.2/after7398.6, expanded false->true.',
        'Original Space-close poll9 call@2546 passed in51.536924ms; freshEnter poll10 call@2550 passed in10.784785ms.',
        'call@2550/attempt1 browser selector7440.7->7441.3 and getter7441.4->7441.4 returned true; equal sampled getter timestamps do not measure tick length or zero execution cost.',
        'Window stops at the next original Tab7539.3;19 poll pairs overall but only6 exact single-lifetime-selector SDK requests are captured.'],
    'limits':['Main rows are bounded to the armed window;0drops does not mean all page/React activity was observed.','React gate rows with null event cannot be retroactively assigned to the previous native key.','Observed parse/context/promise callbacks include observer reaction and patch costs; no pure engine/network timing is claimed.','Main/utility timeOrigin values agree in these records, but no clock tick length/calibration was measured; Node and browser durations are kept separate.','The original1s/25case predicates passed here. This does not explain the earlier70d natural24/1 failure or prove race elimination.','transportComplete=false is retained despite complete captured call mapping.','No PNG pixels were viewed or visually accepted.'],
    'rawBindings':[{'path':str(p.relative_to(R)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}for p in [A/'download-receipt.json',A/'members.json',E/'vitest.json',E/'source-sha.txt',E/'browser.log',E/'activation/activation-before-close.json',E/'activation/activation-final.json']],
    'nonPNGMemberBindings':verified,'phaseSequenceSHA256':sha((D/'phase-sequence.json').read_bytes())}
(D/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(D/'report.md').write_text('''官方Accordion39965405725/job120453846404的原25case全部通过。Artifact12506673984完整ZIP6,565,532B，SHA d6d9b7f1176de30edf981828d6674ecf80d1089c99e00c333ab81dfbc4ecf0ac等metadata；185成员目录/CRC-size元数据齐全。本审查独立重算非PNG成员及提取字节，PNG未打开、没有像素审阅；Root此前完整CRC/extract核验单独标明。source-sha精确4d4a，2个实际Vite transform回执与该Git插件/原Adapter源码机械回放hash一致，7SDKpins一致。\n\nMain79rows/0drop/error，SDK6requests/6batch/6guardpass均complete，0pending/drop/error，contextClosed和disposed=true。transportComplete=false保留，不能把6个匹配请求扩大成全部19个poll或所有transport。\n\n同次阳性序列：Space7243.2→root enabled7244.1→press.commit7244.4–7248.4，expanded true到false；gate7334.1 disable→7383.6 enable；freshEnter7394.5→root enabled7394.9→press.commit7395.2–7398.6，expanded false到true。原poll9约51.537ms，poll10约10.785ms均通过。后者call@2550/attempt1原browser selector7440.7–7441.3，getter在两次相同采样时间7441.4返回true；不能称测得0ms执行或tick长度。窗口在下个原Tab7539.3停止。输入始终main:2/private token18/publicReact generation2；private React viewGeneration1是另一计数。finally finalActive为后续Vue/gen3，不作原输入焦点证据。\n\n这是真实新官方instrumented阳性，未复现旧自然失败，未证明产品根因或race消失。观察成本、异步reaction/patch时点、事件null关联和clock未校准等界限保留。0具体来源/算术finding，partial/ABSTAIN，非正式批准。\n''')
print(json.dumps({'reportSHA256':sha((D/'report.json').read_bytes()),'markdownSHA256':sha((D/'report.md').read_bytes()),'entries':185,'nonPNGRecomputed':len(verified),'PNGNotOpened':image_count}))
