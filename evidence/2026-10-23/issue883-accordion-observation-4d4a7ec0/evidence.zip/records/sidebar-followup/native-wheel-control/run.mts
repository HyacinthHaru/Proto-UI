import { launchBrowser } from '<WORKTREE>/apps/www/src/content/docs/zh-cn/browser-harness.ts';
import fs from 'node:fs/promises';
const output = new URL('./result.json', import.meta.url);
const browsers = [process.env.CHROME_PATH!, '<TASK_STATE>/continue-20261022T061410Z/matched-browser/cache/chromium-1208/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'];
const results: any[] = [];
for (const executable of browsers) {
  process.env.CHROME_PATH = executable;
  const browser = await launchBrowser();
  const row: any = { start: new Date().toISOString(), executable, actualVersion: browser.version(), fixture: 'synthetic plain native overflow div, not Proto UI', before: null, after: null, passed: false };
  try {
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.setContent('<div id="viewport" style="height:200px;width:200px;overflow:auto"><div style="height:2000px">Native wheel control</div></div>');
    await page.evaluate(() => {
      const viewport = document.querySelector<HTMLElement>('#viewport')!;
      viewport.scrollTop = 500;
      (window as any).__events = [];
      document.addEventListener('wheel', event => (window as any).__events.push({ type: 'wheel', trusted: event.isTrusted, deltaY: event.deltaY, prevented: event.defaultPrevented }), { capture: true, passive: true });
      viewport.addEventListener('scroll', () => (window as any).__events.push({ type: 'scroll', top: viewport.scrollTop }));
    });
    await page.mouse.move(100, 100);
    row.before = await page.locator('#viewport').evaluate(el => el.scrollTop);
    await page.mouse.wheel(0, -100);
    try { await page.waitForFunction(() => document.querySelector('#viewport')!.scrollTop < 500, null, { timeout: 1000 }); row.passed = true; }
    catch (error) { row.originalControlError = String(error); }
    row.after = await page.locator('#viewport').evaluate(el => el.scrollTop);
    row.events = await page.evaluate(() => (window as any).__events);
    await context.close();
  } finally { await browser.close(); row.end = new Date().toISOString(); results.push(row); await fs.writeFile(output, JSON.stringify({ results, scope: 'diagnostic browser/platform control only; no Proto product/root cause inference' }, null, 2)); }
  if (row.passed) break;
}
console.log(JSON.stringify(results));
