原sidebar单case私有诊断实际0pass/1fail/9filtered，保留原1s scrollTop<9021失败；sourceStable/extraInputsStable，CAS原字节恢复clean4d4a。22条记录中20条原facts都为scrollTop9021/documentY0；另两条为到正确当前文章anchor的trusted wheel（deltaY−400）document capture和window bubble，两个观测点defaultPrevented均false，0scroll rows/0error/drop。该有限记录未证明浏览器最终默认动作、所有listener顺序或未来事件；path仅前8层。

另一次同源扩展仍原case失败。原verdict之后A原CSS/B仅pane inlineoverscroll auto/A恢复，三次额外wheel全9021→9021。原22条trace在这些额外输入前已保存，不能把它当A/B/A事件记录。B没有产生所预测差异，故paneoverscroll原因未获支持，不据此改CSS。

新同Chrome155 plain-DOM native-wheel control实际500→400成功；145arm未运行。不能指责整个平台wheel失效，也不能用plain-DOM阳性解释站点原因。全294原293/1保持不变，两次私有source都CAS恢复，未做产品修复。

只读来源核对，未运行任何新browser/test/API，未看PNG像素。partial/ABSTAIN，根因unknown，无正式批准。
