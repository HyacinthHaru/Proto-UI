const fs=require('node:fs'),crypto=require('node:crypto'),path=require('node:path');
const w='<WORKTREE>',r='<R21>';
const ts=require(w+'/node_modules/typescript'),file=w+'/apps/www/scripts/accordion-activation-probe.mjs';
const text=fs.readFileSync(file,'utf8'),sf=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');const result=[];
for(const st of sf.statements){if(!ts.isVariableStatement(st))continue;for(const d of st.declarationList.declarations){if(!ts.isIdentifier(d.name)||!['routerSplices','reactSplices'].includes(d.name.text))continue;
const p=d.name.text==='routerSplices'?'packages/adapters/base/src/events/web-event-router.ts':'packages/adapters/react/src/adapt.ts';
let src=fs.readFileSync(path.join(w,p),'utf8');const beforeSHA=hash(src),shapes=[];
for(const el of d.initializer.elements){const x={};for(const pr of el.properties){if(ts.isPropertyAssignment(pr)&&ts.isStringLiteralLike(pr.initializer))x[pr.name.getText(sf)]=pr.initializer.text;}
const at=src.indexOf(x.before),again=src.indexOf(x.before,at+x.before.length);if(at<0||again!==-1)throw Error('shape mismatch '+x.name);src=src.slice(0,at)+x.after+src.slice(at+x.before.length);shapes.push(x.name)}
const afterSHA=hash(src);const receipts=fs.readdirSync(r+'/durable-native/activation/source-transforms').map(n=>JSON.parse(fs.readFileSync(r+'/durable-native/activation/source-transforms/'+n,'utf8')));const actual=receipts.find(x=>x.relativePath===p);result.push({path:p,beforeSHA,afterSHA,shapes,receiptMatched:actual?.beforeSHA===beforeSHA&&actual?.afterSHA===afterSHA,parseErrors:ts.createSourceFile(p,src,ts.ScriptTarget.Latest,true).parseDiagnostics.length});}}
fs.writeFileSync(r+'/durable-review/transform-static-replay.json',JSON.stringify({kind:'Static AST string substitution only; plugin transform function was not executed',pluginSHA256:hash(text),sourceBindings:result},null,2)+'\n');console.log(JSON.stringify(result,null,2));
