const fs=require('node:fs');const cp=require('node:child_process');const crypto=require('node:crypto');const path=require('node:path');
const w='<WORKTREE>';
const out='<R21>/durable-review';
const ts=require(path.join(w,'node_modules/typescript'));
const base='70d096851a1b22e50ac72e147efaa2b46f62f1c4';
const file='apps/www/src/content/docs/zh-cn/demo-accordion-family.browser.test.ts';
const original=cp.execFileSync('git',['show',base+':'+file],{cwd:w,encoding:'utf8'});const candidate=fs.readFileSync(path.join(w,file),'utf8');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const printer=ts.createPrinter({removeComments:true,newLine:ts.NewLineKind.LineFeed});
function parse(src,name){return ts.createSourceFile(name,src,ts.ScriptTarget.Latest,true,name.endsWith('.mjs')?ts.ScriptKind.JS:ts.ScriptKind.TS)}
const norm=(node,sf)=>printer.printNode(ts.EmitHint.Unspecified,node,sf);
function extracted(src){const sf=parse(src,file);const result={matchers:[],inputs:[],caseTemplates:[],caseDeadlines:[],pollOptions:[],timeoutProperties:[]};
 function visit(n){if(ts.isCallExpression(n)){const e=n.expression;const expr=norm(e,sf);
 if(ts.isPropertyAccessExpression(e)&&/^to[A-Z]/.test(e.name.text)&&expr.startsWith('expect'))result.matchers.push({matcher:e.name.text,args:n.arguments.map(a=>norm(a,sf))});
 if(ts.isPropertyAccessExpression(e)&&['press','click','focus','down','up','move','wheel'].includes(e.name.text))result.inputs.push(norm(n,sf));
 if(ts.isIdentifier(e)&&['selectAccordionRuntime','selectRuntime','choosePreviewRuntime','applyColorScheme','focused','materialized','expanded'].includes(e.text))result.inputs.push(norm(n,sf));
 if(ts.isIdentifier(e)&&e.text==='it'){result.caseTemplates.push(norm(n.arguments[0],sf));result.caseDeadlines.push(n.arguments.length>2?norm(n.arguments[2],sf):null)}
 if(ts.isPropertyAccessExpression(e)&&ts.isIdentifier(e.expression)&&e.expression.text==='expect'&&e.name.text==='poll')result.pollOptions.push(n.arguments.slice(1).map(a=>norm(a,sf)));
 }
 if(ts.isPropertyAssignment(n)&&n.name.getText(sf)==='timeout')result.timeoutProperties.push(norm(n.initializer,sf));
 ts.forEachChild(n,visit)}visit(sf);return {parseErrors:sf.parseDiagnostics.map(d=>({start:d.start,text:ts.flattenDiagnosticMessageText(d.messageText,' ')})),...result}}
const a=extracted(original),b=extracted(candidate);const eq=(x,y)=>JSON.stringify(x)===JSON.stringify(y);
const paths=cp.execFileSync('git',['diff','--name-only'],{cwd:w,encoding:'utf8'}).trim().split('\n').concat(cp.execFileSync('git',['ls-files','--others','--exclude-standard'],{cwd:w,encoding:'utf8'}).trim().split('\n')).filter(Boolean);
const source=paths.map(p=>{const s=fs.readFileSync(path.join(w,p));return {path:p,sha256:hash(s),bytes:s.length,parseErrors:/\.(?:[cm]?js|ts)$/.test(p)?parse(s.toString(),p).parseDiagnostics.map(d=>ts.flattenDiagnosticMessageText(d.messageText,' ')):null}});
const controls=['packages/adapters/base/test/event-router-work.test.ts','packages/adapters/base/src/events/web-event-router.ts','packages/adapters/react/src/adapt.ts'].map(p=>{const old=cp.execFileSync('git',['show',base+':'+p],{cwd:w});const cur=fs.readFileSync(path.join(w,p));return {path:p,sha256:hash(cur),equalBase:old.equals(cur)}});
const audit={kind:'Read-only AST/hash mechanics, not a test or browser run',at:new Date().toISOString(),base,originalSHA256:hash(original),candidateSHA256:hash(candidate),original:a,candidate:b,preservation:{matchers:eq(a.matchers,b.matchers),inputCallSequence:eq(a.inputs,b.inputs),caseTemplates:eq(a.caseTemplates,b.caseTemplates),caseDeadlineExpressions:eq(a.caseDeadlines,b.caseDeadlines),expectPollOptions:eq(a.pollOptions,b.pollOptions),timeoutProperties:eq(a.timeoutProperties,b.timeoutProperties)},selectedSourceFiles:source,unchangedControls:controls};
fs.writeFileSync(path.join(out,'static-audit.corrected.json'),JSON.stringify(audit,null,2)+'\n');console.log(JSON.stringify({originalSHA256:audit.originalSHA256,candidateSHA256:audit.candidateSHA256,preservation:audit.preservation,matcherCount:a.matchers.length,inputCalls:a.inputs.length,caseTemplates:a.caseTemplates,caseDeadlines:a.caseDeadlines,pollOptions:a.pollOptions,parseErrors:b.parseErrors,files:source,unchangedControls:controls},null,2));
