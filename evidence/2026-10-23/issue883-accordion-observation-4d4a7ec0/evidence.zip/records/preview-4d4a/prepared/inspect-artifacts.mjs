import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const worktree = '<WORKTREE>';
const selected = JSON.parse(await fs.readFile(path.join(root, 'selected-artifacts.json'), 'utf8'));
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const git = (...args) => execFileSync('git', args, { cwd: worktree, encoding: 'utf8' }).trim();
assert.equal(git('rev-parse', 'HEAD'), selected.head);
assert.equal(git('rev-parse', 'HEAD^{tree}'), selected.tree);
assert.equal(git('status', '--porcelain'), '');
const receipt = { start: new Date().toISOString(), success: false, head: selected.head, tree: selected.tree, errors: [] };
const output = path.join(root, 'extracted');
await fs.mkdir(output); // Fresh path only: no overwrite, retry, or asset pruning.
try {
  const { extractBoundedZip } = await import(pathToFileURL(path.join(worktree, 'scripts/preview/extract-artifact.mjs')));
  const { PREVIEW_LIMITS } = await import(pathToFileURL(path.join(worktree, 'scripts/preview/sanitize-tree.mjs')));
  receipt.defaultLimits = PREVIEW_LIMITS;
  const archives = {};
  for (const [label, metadata] of [['site', selected.site], ['binding', selected.binding]]) {
    const filename = path.join(root, 'artifacts', `${label}.zip`), bytes = await fs.readFile(filename);
    assert.equal(bytes.length, metadata.size_in_bytes);
    assert.equal(sha(bytes), metadata.digest.replace(/^sha256:/, ''));
    assert(bytes.length <= PREVIEW_LIMITS.maxCompressedBytes);
    const files = extractBoundedZip(bytes); // Existing defaults; no budget override.
    const central = JSON.parse(execFileSync('python3', ['-c', String.raw`
import zipfile,json,sys,hashlib,pathlib,re
with zipfile.ZipFile(sys.argv[1]) as z:
 assert z.testzip() is None
 entries=[]; seen=set()
 for i in z.infolist():
  name=i.filename; normal=name[:-1] if i.is_dir() else name
  assert normal and not normal.startswith('/') and '\\' not in name and not re.match(r'^[A-Za-z]:',name)
  assert not any(ord(c)<32 or ord(c)==127 for c in name)
  assert all(p not in ('','.','..') for p in normal.split('/')) and name not in seen
  seen.add(name)
  assert ((i.external_attr>>16)&0o170000) in (0,0o040000 if i.is_dir() else 0o100000)
  entries.append({'path':name,'isDirectory':i.is_dir(),'size':i.file_size,'compressedSize':i.compress_size,'crc32':i.CRC,'mode':i.external_attr>>16,'sha256':None if i.is_dir() else hashlib.sha256(z.read(i)).hexdigest()})
 print(json.dumps(entries))
`, filename], { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024 }));
    assert.equal(central.filter(entry => !entry.isDirectory).length, files.size);
    for (const entry of central) if (!entry.isDirectory) {
      assert(files.has(entry.path));
      assert.equal(sha(files.get(entry.path)), entry.sha256);
    }
    archives[label] = { metadata, archiveSHA256: sha(bytes), archiveBytes: bytes.length, entries: central.length, allCRCChecked: true };
    await fs.writeFile(path.join(root, `${label}-archive-members.json`), JSON.stringify(central, null, 2) + '\n', { flag: 'wx' });
    if (label === 'binding') {
      assert.equal(files.size, 1);
      const bindingText = [...files.values()][0].toString('utf8');
      assert.equal(bindingText, `PR=921\nHEAD=${selected.head}\n`);
      archives.binding.bindingText = bindingText;
    } else {
      const members = [];
      for (const [name, data] of files) {
        const destination = path.join(output, name);
        await fs.mkdir(path.dirname(destination), { recursive: true });
        await fs.writeFile(destination, data, { flag: 'wx' });
        assert((await fs.readFile(destination)).equals(data));
        members.push({ path: name, type: 'file', size: data.length, sha256: sha(data) });
      }
      members.sort((a, b) => a.path.localeCompare(b.path, 'en'));
      const memberBytes = JSON.stringify(members, null, 2) + '\n';
      await fs.writeFile(path.join(root, 'members.json'), memberBytes, { flag: 'wx' });
      Object.assign(archives.site, { files: members.length, html: members.filter(x => x.path.endsWith('.html')).length, expandedBytes: members.reduce((n, x) => n + x.size, 0), memberInventorySHA256: sha(memberBytes), allExtractedBytesEqual: true, pruned: false });
      assert.equal(archives.site.files, selected.producerDefaultAdmission.files);
      assert.equal(archives.site.expandedBytes, selected.producerDefaultAdmission.expandedBytes);
      assert(members.some(x => x.path === 'index.html' && x.size > 0));
    }
  }
  const binding = { head: selected.head, tree: selected.tree, sourceMode: 'official-actions-artifact', producerRun: selected.runId, producerJob: selected.jobId, runConclusion: selected.runConclusion, producerActualCheckout: selected.producerActualCheckout, exactSourceBinding: true, completeSiteArtifact: { artifactId: selected.site.id, ...archives.site }, sourceBindingArtifact: { id: selected.binding.id, ...archives.binding }, producerDefaultAdmission: selected.producerDefaultAdmission, localDefaultAdmission: 'pending', scope: 'Verified whole Actions artifact. Local admission and native execution remain separate pending steps.' };
  await fs.writeFile(path.join(root, 'artifact-binding.json'), JSON.stringify(binding, null, 2) + '\n', { flag: 'wx' });
  receipt.archives = archives;
  receipt.success = true;
} catch (error) {
  receipt.errors.push(String(error));
  throw error;
} finally {
  receipt.end = new Date().toISOString();
  await fs.writeFile(path.join(root, 'inspection-receipt.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
}
