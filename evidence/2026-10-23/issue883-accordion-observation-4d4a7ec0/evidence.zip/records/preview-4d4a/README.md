准确 4d4a 预览准备已完成；本目录不是已执行的本地预览结果。

新官方 producer run39965405561 / job120453846440 已真实SUCCESS，actualcheckout `4d4a7ec071dd83756444cbebf5a4c8b3bea81bcf`、tree `8af15e292175a4366691acb3834e8cb4331c3a77`。原日志生产build完成，651生成页面；原defaultadmission1pass/0fail/0skip，3837完整文件、104015898展开字节。651不是最终HTML文件数，须从下载ZIP重新统计。Producer自用ZIP21184577B；Actions上传siteZIP21118985B，SHA9b7ef24d187c5a5db1d62239beba8a18e5adfd9f0937fc4d19e09bc2c6ac77e6，两者是不同容器。

Root已一次下载site和binding到artifacts/；本审查没有重复下载。所有元数据/producer原log及唯一读回执在metadata/，准确tuple在selected-artifacts.json。即使源码变化只是serve-only取证，也没有借用70d的生产产物。

Root在当前294结束且工作树clean exact4d4a后串行执行以下步骤。没有localbuild，不变更默认50MiB压缩/100MiB展开等admission限额，不删任何资源：

1. 使用Node24执行 `prepared/inspect-artifacts.mjs`。它读取现有两ZIP，核metadata size/SHA、现有默认extractBoundedZip、全部中央目录/CRC/成员SHA，并保留所有regularfiles到新extracted/，生成完整members和artifact-binding。输出目录必须新建；失败原件保留。
2. 用已有census launcher运行原defaultadmission：

```sh
python3 <TASK_STATE>/continue-20261023T071326Z/run-plan.py <R21>/preview-4d4a/admission-plan.json <R21>/preview-4d4a/admission
```

这是原 `node --test scripts/preview/generated-artifact.test.mjs`，SOURCE是同一下载ZIP的完整extraction。独立producer-dist比较只来自官方原log，不能把本地比较冒充第二个独立产物。

3. 使用Node24执行 `prepared/prepare-native.mjs`。它先核上述真实receipt/head/tree/source/extras/1pass；同时兼容Node原ℹ或TAP#汇总，不重复旧70d wrapper误读。再由4d4a Git源码提取原waitForRuntimeAt callback和MIME，生成native-qa/plan.json。
4. 只执行一次新native plan：

```sh
python3 <TASK_STATE>/continue-20261023T071326Z/run-plan.py <R21>/preview-4d4a/native-qa/plan.json <R21>/preview-4d4a/native-qa/launcher
```

CHROME_PATH明确R21 browser-source CFT155.0.8059.39；Playwright1.58.2/Node24.21/macOS是本地环境，不声称与hostedLinux一致。沿原脚本两freshcontext1440×1100与320×1000、WC/light、同60s观察预算、相同全部断言/输入和服务cleanup。没有新增style/state注入或缩减资源。原模板对每个实际HTTP200做SHA/size/MIME比较，整个extracted树前后逐文件一致；实际响应和unique成员数动态统计，不预填123/246。

两原PNG须由root真正查看。它们是观测状态后的fullPage capture，不是firstframe、全Tabs可达、全站/全Adapter/AT/光学/motion验收。原locale/timezone没有新固定，按真实记录。所有既有negative与未完成CI仍保留。

本次只运行了metadata/log只读GET、脚本语法检查；没有执行inspection/admission/browser/build。首次准备substring检查被ANSI影响的错误保留在preparation-initial-check-error.json，已仅改派生解析、不改raw。更多来源和脚本SHA在plan.json。partial/ABSTAIN，不作批准。
