from pathlib import Path
import subprocess, json, datetime, hashlib, concurrent.futures, collections

R = Path(__file__).resolve().parent
STATE = R.parent.parent
REPO = 'Proto-UI/Proto-UI'
RUN = 39925882543
errors = []
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data): return hashlib.sha256(data).hexdigest()
def request(name, argv, json_output=True):
    out = R / name
    if out.exists(): raise RuntimeError('Refuse overwrite: ' + str(out))
    started = now()
    try:
        result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=55)
        stdout, stderr, code = result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired as error:
        stdout, stderr, code = error.stdout or b'', error.stderr or b'', 124
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(stdout)
    Path(str(out) + '.stderr').write_bytes(stderr)
    receipt = {'readStart': started, 'readEnd': now(), 'argv': argv, 'exitCode': code,
               'bytes': len(stdout), 'sha256': sha(stdout), 'networkReadOnly': True, 'attempt': 1}
    Path(str(out) + '.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if code:
        error = {'file': name, 'exitCode': code, 'stderr': stderr.decode(errors='replace')}
        errors.append(error)
        return {'receipt': receipt, 'error': error}
    if not json_output: return {'receipt': receipt, 'path': str(out)}
    try: return {'receipt': receipt, 'data': json.loads(stdout)}
    except Exception as error:
        item = {'file': name, 'parseError': str(error)}; errors.append(item)
        return {'receipt': receipt, 'error': item}

def api(name, endpoint, paged=False):
    return request(name, ['gh', 'api', endpoint] + (['--paginate', '--slurp'] if paged else []))

start = now()
tasks = [
    ('pr.json', f'repos/{REPO}/pulls/921', False),
    ('main.json', f'repos/{REPO}/git/ref/heads/main', False),
    ('run.json', f'repos/{REPO}/actions/runs/{RUN}', False),
    ('jobs-pages.json', f'repos/{REPO}/actions/runs/{RUN}/jobs?per_page=100&filter=latest', True),
    ('artifacts-pages.json', f'repos/{REPO}/actions/runs/{RUN}/artifacts?per_page=100', True),
]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    values = list(pool.map(lambda task: api(*task), tasks))
lookup = {task[0]: value.get('data') for task, value in zip(tasks, values)}
query = 'query { repository(owner:"Proto-UI", name:"Proto-UI") { pullRequest(number:921) { updatedAt headRefOid baseRefOid mergeStateStatus reviewDecision comments { totalCount } reviews { totalCount } reviewThreads { totalCount } } } }'
feedback = request('feedback-counts.json', ['gh', 'api', 'graphql', '-f', 'query=' + query])
pr = lookup['pr.json']; pages = lookup['jobs-pages.json']; run = lookup['run.json']
summary = {'readStart': start, 'metadataReadEnd': now(), 'atomicSnapshot': False,
           'runId': RUN, 'errors': errors, 'selectedLogs': [], 'feedback': {}}
if pr:
    prior_pr = json.loads((R.parent/'later-read/pr.json').read_text())
    f = (feedback.get('data') or {}).get('data', {}).get('repository', {}).get('pullRequest')
    previous_comments = json.loads((STATE/'live/comments921.json').read_text())
    if previous_comments and isinstance(previous_comments[0], list): previous_comments = sum(previous_comments, [])
    previous_reviews = json.loads((STATE/'live/reviews921.json').read_text())
    if previous_reviews and isinstance(previous_reviews[0], list): previous_reviews = sum(previous_reviews, [])
    previous_threads = json.loads((STATE/'live/threads921-complete.json').read_text())
    changed = pr['updated_at'] != prior_pr['updated_at'] or pr['comments'] != prior_pr['comments']
    if f:
        changed = changed or f['comments']['totalCount'] != len(previous_comments) or f['reviews']['totalCount'] != len(previous_reviews) or f['reviewThreads']['totalCount'] != len(previous_threads)
    summary['feedback'] = {'changedSignal': changed, 'currentCounts': f, 'priorComplete': str(STATE/'live'), 'expanded': False}
    if changed:
        comments = api('comments-pages.json', f'repos/{REPO}/issues/921/comments?per_page=100', True)
        reviews = api('reviews-pages.json', f'repos/{REPO}/pulls/921/reviews?per_page=100', True)
        q = 'query($endCursor:String) { repository(owner:"Proto-UI",name:"Proto-UI") { pullRequest(number:921) { reviewThreads(first:100,after:$endCursor) { totalCount pageInfo { hasNextPage endCursor } nodes { id isResolved isOutdated comments(first:100) { totalCount pageInfo { hasNextPage endCursor } nodes { id databaseId body createdAt updatedAt url author { login } } } } } } } }'
        threads = request('threads-pages.json', ['gh', 'api', 'graphql', '--paginate', '--slurp', '-f', 'query=' + q])
        summary['feedback']['expanded'] = True
        summary['feedback']['complete'] = all('data' in value for value in [comments, reviews, threads])
        if 'data' in comments:
            rows = sum(comments['data'], [])
            old = {c['id']:c for c in previous_comments}
            summary['feedback']['newOrEdited'] = [{'id':c['id'],'author':c['user']['login'],'created_at':c['created_at'],'updated_at':c['updated_at'],'url':c['html_url'],'body':c['body']} for c in rows if c['id'] not in old or c['updated_at']!=old[c['id']]['updated_at'] or c['body']!=old[c['id']]['body']]
        if 'data' in threads:
            for page in threads['data']:
                for thread in page['data']['repository']['pullRequest']['reviewThreads']['nodes']:
                    if thread['comments']['pageInfo']['hasNextPage']:
                        nested_q = 'query($endCursor:String) { node(id:"' + thread['id'] + '") { ... on PullRequestReviewThread { comments(first:100,after:$endCursor) { totalCount pageInfo { hasNextPage endCursor } nodes { id databaseId body createdAt updatedAt url author { login } } } } } }'
                        nested = request('thread-' + thread['id'] + '-comments-pages.json', ['gh','api','graphql','--paginate','--slurp','-f','query='+nested_q])
                        if 'data' not in nested: summary['feedback']['complete'] = False
    summary.update({'sourceHead': pr['head']['sha'], 'main': (lookup['main.json'] or {}).get('object',{}).get('sha'),
                    'pr': {k:pr.get(k) for k in ['state','draft','merged','updated_at','mergeable','mergeable_state','comments','review_comments']}})
if run: summary['run'] = {k:run.get(k) for k in ['id','head_sha','status','conclusion','run_attempt','updated_at']}
if pages:
    jobs = [job for page in pages for job in page['jobs']]
    summary['jobs'] = {'reported':pages[0]['total_count'],'received':len(jobs),'unique':len({j['id'] for j in jobs}),'pageCount':len(pages),
                       'paginationComplete':len(jobs)==len({j['id'] for j in jobs})==pages[0]['total_count'],
                       'statusCounts':dict(collections.Counter(j['status'] for j in jobs)),
                       'terminalConclusions':dict(collections.Counter(j['conclusion'] for j in jobs if j['status']=='completed'))}
    summary['jobRows'] = [{k:j.get(k) for k in ['id','name','status','conclusion','head_sha','started_at','completed_at','html_url']} for j in jobs]
    selected = [j for j in jobs if j['status']=='completed' and (j['name']=='test-general' or j['name'].startswith('test-browser'))]
    for job in selected:
        existing = [p for p in R.parent.rglob(str(job['id'])+'.log') if R not in p.parents and p.stat().st_size>0]
        if existing:
            p=existing[0];summary['selectedLogs'].append({'jobId':job['id'],'name':job['name'],'cached':True,'path':str(p),'sha256':sha(p.read_bytes())});continue
        value=request(f"logs/{job['id']}.log",['gh','api',f"repos/{REPO}/actions/jobs/{job['id']}/logs"],False)
        summary['selectedLogs'].append({'jobId':job['id'],'name':job['name'],'cached':False,**value})
    print(json.dumps({'metadataReadEnd':summary['metadataReadEnd'],'run':summary.get('run'),'jobs':summary['jobs'],'selectedLogCount':len(summary['selectedLogs'])}),flush=True)
if lookup['artifacts-pages.json'] is not None:
    ap=lookup['artifacts-pages.json']; arts=[a for page in ap for a in page['artifacts']]
    summary['artifacts']={'reported':ap[0]['total_count'],'received':len(arts),'pageCount':len(ap),'paginationComplete':len(arts)==len({a['id'] for a in arts})==ap[0]['total_count'],'downloaded':False}
summary['readEnd']=now()
(R/'snapshot.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'readEnd':summary['readEnd'],'errors':errors,'feedbackExpanded':summary['feedback'].get('expanded')}),flush=True)
