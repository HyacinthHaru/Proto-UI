from pathlib import Path
import json,re,hashlib,collections
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
snapshot=read(R/'snapshot.json')
jobrows={j['id']:j for j in snapshot['jobRows']}
ansi=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
logs={int(p.stem):[ansi.sub('',x) for x in p.read_text(errors='replace').splitlines()] for p in (R/'logs').glob('*.log')}
def rows(jid,marker):
 out=[]
 for i,line in enumerate(logs[jid]):
  if marker in line:
   try: value=json.JSONDecoder().raw_decode(line.split(marker,1)[1])[0]
   except Exception: continue
   out.append({'rawLogLine':i+1,'value':value})
 return out
observations={
 'docsVerdicts':rows(120418432576,'[Docs role readiness] '),
 'docsPostVerdictSettlements':rows(120418432576,'[Docs role settlement] '),
 'scrollOriginalAssertion':rows(120418432600,'[scroll-corner-minimum-thumb-assertion-failure] '),
 'scrollPostFailure':rows(120418432600,'[scroll-corner-minimum-thumb-after-failure] '),
 'matrixReadiness':rows(120418432654,'[demo-matrix-readiness] '),
 'matrixPageErrors':rows(120418432654,'[demo-matrix-pageerror] '),
}
search=[];current_case=None
for i,line in enumerate(logs[120418432576]):
 if '× Search family Button commands > ' in line:current_case=line.split('× ',1)[1]
 if current_case and ' → {' in line:
  value=json.JSONDecoder().raw_decode(line.split(' → ',1)[1])[0]
  search.append({'case':current_case,'rawLogLine':i+1,'value':value});current_case=None
observations['searchInitialReadinessFailures']=search
(R/'log-observations.json').write_text(json.dumps(observations,indent=2)+'\n')
verdicts=observations['docsVerdicts'];settlements={(x['value']['family'],x['value']['width']):x for x in observations['docsPostVerdictSettlements']}
docs=[]
for item in verdicts:
 v=item['value'];s=settlements.get((v['family'],v['width']));sv=s['value'] if s else None
 docs.append({'family':v['family'],'width':v['width'],'passed':v['passed'],'calls':v['calls'],'pendingAtVerdict':v['pending'],'dropped':v['dropped'],'rawVerdictLine':item['rawLogLine'],'postVerdict':None if not sv else {'line':s['rawLogLine'],'budgetMs':sv['budgetMs'],'budgetExpired':sv['budgetExpired'],'completeAtDrainPoint':sv['completeAtDrainPoint'],'outcomes':sv['outcomes'],'droppedSamples':sv['droppedSamples'],'droppedOutcomes':sv['droppedOutcomes'],'observerError':sv['observerError'],'issuedAfterVerdict':sv['issuedAfterVerdict']}})
search_summary=[]
for item in search:
 v=item['value'];samples=v['samples'];deadline=v['deadline']
 search_summary.append({'case':item['case'],'line':item['rawLogLine'],'sampleCount':v['sampleCount'],'droppedSamples':v['droppedSamples'],'browserEntryRelativeDeadlineMs':v['browserEnteredAt']-deadline,'observedReadyRelativeDeadlineMs':None if v['observedReadyAt'] is None else v['observedReadyAt']-deadline,'samplesAtOrBeforeDeadline':sum(s['atEpochMs']<=deadline for s in samples),'samplesAfterDeadline':sum(s['atEpochMs']>deadline for s in samples),'actualGetterSamples':sum(s.get('getterStartedAt') is not None for s in samples),'commandCounts':[s['commandCount'] for s in samples]})
log_reports=[]
for jid,lines in sorted(logs.items()):
 p=R/'logs'/f'{jid}.log'
 file_rows=[]
 for i,line in enumerate(lines):
  m=re.search(r'[✓❯] (\S+\.(?:browser\.)?test\.[cm]?[jt]s) \((\d+) tests?(?: \| (\d+) failed)?(?: \| (\d+) skipped)?\)',line)
  if m:file_rows.append({'path':m[1],'total':int(m[2]),'failed':int(m[3] or 0),'skipped':int(m[4] or 0),'passed':int(m[2])-int(m[3] or 0)-int(m[4] or 0),'logLine':i+1})
 summary_lines=[{'line':i+1,'text':line} for i,line in enumerate(lines) if re.search(r'\s(?:Test Files|Tests)\s',line)]
 exit_codes=[int(m[1]) for line in lines if (m:=re.search(r'Process completed with exit code (\d+)',line))]
 checkout=[]
 for i,line in enumerate(lines):
  if 'git log -1 --format=%H' in line and i+1<len(lines):
   m=re.search(r'\b([a-f0-9]{40})\b',lines[i+1]);
   if m:checkout.append(m[1])
 log_reports.append({'job':jobrows[jid],'path':str(p),'sha256':sha(p),'downloadReceiptSHA256':sha(Path(str(p)+'.receipt.json')),'checkoutSHAs':checkout,'vitestRunMarkerPresent':any(re.search(r'\bRUN\s+v2\.1\.9\b',line) for line in lines),'processExitCodes':exit_codes,'completeVitestSummary':bool(summary_lines),'summaryLines':summary_lines,'completedFileRows':file_rows})
objp=R.parent/'checkout-git-object.json';obj=read(objp)
source_bindings=read(R/'source-bindings.json')
failures=[
 {'jobId':120418432429,'kind':'pre-Vitest governance guard','file':'public-docs guard','predicate':'78 unclassified family/export drift issues; no ordinary Vitest run marker or suite summary','rawLogLines':[1283,1284,1285,1286,1287,1288,1362],'vitestExecuted':False,'firstExamples':[logs[120418432429][i] for i in range(1283,1288)]},
 {'jobId':120418432576,'kind':'original readiness assertions before shard exit124','file':'apps/www/src/content/docs/zh-cn/site-search-commands.browser.test.ts','fileCounts':{'passed':14,'failed':16,'total':30},'failures':[{'count':8,'predicate':'initialReady.onTime must be true within the original 1000ms window','rawLogLines':[627,628,629,630,631,632,633,634,635,636,637,638,639,640,641,642,643]},{'count':8,'predicate':'original locator.getAttribute(role) poll must become combobox in 1000ms','rawLogLines':[652,653,655,656,658,659,660,661,662,663,664,665,666,667,668,669]}],'cause':'unknown; original verdict and later promise settlement are distinct','wholeShardCounts':None},
 {'jobId':120418432654,'kind':'committed-host-readiness timeout then shard exit124','file':'apps/www/src/content/docs/zh-cn/demo-matrix.browser.test.ts','sourceLine':250,'predicate':'page.waitForFunction(matrixHostsReady, undefined, { timeout: 60_000 })','recordedFailedCases':['mounts every demo in every official Web adapter','keeps the matrix readable at 320px'],'rawLogLines':[698,788],'nearbyPageErrors':sorted({x['value']['message'] for x in observations['matrixPageErrors']}),'cause':'unknown; nearby shadow-split token errors are observed, not proven to explain timeout','wholeShardCounts':None},
 {'jobId':120418432548,'kind':'actual assertion','file':'apps/www/src/content/docs/zh-cn/demo-new-projection-families.browser.test.ts','sourceLine':124,'count':2,'predicate':'disabled button computed opacity expected 0.5, received 1 (light and dark source projection cases)','rawLogLines':[564,565,566,571],'cause':'unknown; no production ownership or fix inferred from family name'},
 {'jobId':120418432548,'kind':'case deadline','file':'apps/www/src/content/docs/zh-cn/demo-shadow-split-s4-paint.browser.test.ts','count':1,'predicate':'S4 compositor case exceeded original 150000ms','rawLogLines':[581,582],'cause':'unknown; full timeout does not identify a paint assertion or exact phase'},
 {'jobId':120418432600,'kind':'initial fixture readiness','file':'apps/www/src/content/docs/zh-cn/demo-shadow-split-s4.browser.test.ts','sourceLine':28,'count':2,'predicate':'all previewers data-inited=1 and .host has children within 60000ms; zh-cn and en','rawLogLines':[594,595,596,597],'downstreamJourneyReached':False,'cause':'unknown'},
 {'jobId':120418432600,'kind':'actual geometry assertion','file':'apps/www/src/content/docs/zh-cn/scroll-area-corner.browser.test.ts','sourceLine':531,'count':1,'runtime':'react','family':'shadcn','predicate':'vertical thumb trailing edge must equal vertical track trailing edge minus2 within0.5px; actual absolute error158','rawLogLines':[405,408,607,608,609,616],'originalNumbers':{'thumbBottom':959.5+18,'expectedTrackBottomMinus2':957.5+180-2,'difference':158},'postFailureScope':'separate later reads show viewport scrollTop9810/scrollLeft9682 and thumb offsets0; cannot substitute for original non-atomic rectangles','cause':'unknown; explicit C-neighbour evidence preserved, not dismissed by prior local green'},
]
plan=read(R.parent/'test-plan-from-log.json')
accordion='apps/www/src/content/docs/zh-cn/demo-accordion-family.browser.test.ts'
shard=next(i+1 for i,files in enumerate(plan['browser']) if accordion in files)
report={'scope':'One bounded read of current PR/main and full canonical job/artifact pages; only terminal General/browser logs fetched once. No artifact media, package re-download, test, source edit, Actions mutation or repeated poll.','disposition':'partial/ABSTAIN','readStart':snapshot['readStart'],'metadataReadEnd':snapshot['metadataReadEnd'],'readEnd':snapshot['readEnd'],'atomicSnapshot':False,'sourceHead':snapshot['sourceHead'],'main':snapshot['main'],'pr':snapshot['pr'],'feedback':snapshot['feedback'],'run':snapshot['run'],'jobs':snapshot['jobs'],'jobRows':snapshot['jobRows'],'artifacts':snapshot['artifacts'],'errors':snapshot['errors'],'syntheticCheckout':{'sha':obj['sha'],'tree':obj['tree']['sha'],'parents':[p['sha'] for p in obj['parents']],'equalsHeadTree':obj['tree']['sha']=='7d18f8fe42785c14df46db2a29ec8b595cb5ccee','cachedGitAPIPath':str(objp),'cachedGitAPISHA256':sha(objp),'allSixLogsSameCheckout':all(x['checkoutSHAs']==[obj['sha']] for x in log_reports)},'actualPlan':{'source':str(R.parent/'test-plan-from-log.json'),'sha256':sha(R.parent/'test-plan-from-log.json'),'generalFiles':len(plan['general']),'browserFilesByShard':[len(x) for x in plan['browser']],'productionExcluded':len(plan['productionExcluded'])},'logs':log_reports,'newFailurePredicates':failures,'completeShardSubtotal':{'shards':[3,4,6],'passed':58+121+169,'failed':3+3,'skipped':0,'total':61+124+169,'isWholeRun':False},'incompleteShards':[{'shard':1,'jobId':120418432576,'exit':124,'completeSummary':False},{'shard':2,'jobId':120418432654,'exit':124,'completeSummary':False}],'runningAtSnapshot':[j for j in snapshot['jobRows'] if j['status']!='completed'],'accordion':{'file':accordion,'plannedShard':shard,'jobId':120418432683,'jobStatusAtRead':jobrows[120418432683]['status'],'terminalLogRead':False,'original1sFailureOnThisMainRun':'unknown','private25PassIsNotCanonicalReproduction':True},'docsSameLog':{'rows':docs,'failed':sum(not x['passed'] for x in docs),'passed':sum(x['passed'] for x in docs),'note':'Eight original failed1s verdicts have later complete2s post-verdict settlements to combobox. No new query issued after verdict in those records; this does not turn the original predicate green or isolate SDK/browser cause.'},'searchSameLog':search_summary,'observations':{'path':str(R/'log-observations.json'),'sha256':sha(R/'log-observations.json')},'sourceBindings':source_bindings,'cachedPackage':{'jobId':120417020505,'path':str(R.parent/'later-read/120417020505.log'),'sha256':sha(R.parent/'later-read/120417020505.log'),'downloadedAgain':False,'selectedBuilds':47,'completeBuilds':47,'manifests':47,'budgetDisposition':{'PASS':4,'ADVISORY':5},'note':'Five advisory measurements remain over strict ceilings; not nine strict passes.'},'notClaimed':['All materialized jobs or entire CI terminal','Whole eight-shard total','Accordion same-failure capture in main CI','Production cause or fix for the preserved current failures','Private Vite transform changes executed by this 70d CI','New maintainer acceptance/formal approval']}
(R/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
md=f'''本次只读读取在 {snapshot['readStart']} 至 {snapshot['readEnd']} 完成；metadata 截止 {snapshot['metadataReadEnd']}，不是原子快照。PR #921 仍 OPEN/非 draft/未合并、MERGEABLE/BLOCKED、REVIEW_REQUIRED，head70d/main81339 未变。75 comments、0 reviews、0 threads，updatedAt 未变，因此按要求引用上次完整全文，不重复展开。读取 errors=[]，没有后续轮询。\n\n主 CI39925882543 仍 in_progress。完整分页是21个已物化 job：13success、5failure、3running（5/7/8）；不能当最终22或全终态。Artifacts8项仅元数据，未下载媒体。已一次取得 General、Browser1/2/3/4/6 六份原log；六份真实 checkout 均d8d146c346aeeffc395bd53dbaef6af864e97088，既有Git API对象tree7d18与70d一致、parents81339+70d。\n\nGeneral停在78 public-docs分类缺口，普通Vitest未运行。前三项为Base AlertDialog/Drawer/Popover未分类，具体78条保留原log。Package沿用同run既有原log，不重复下载：47/47build、47manifest，4PASS+5ADVISORY，后五项不是严格预算通过。\n\nBrowser3完整58pass3fail：两source-projection case的disabled opacity原124行实际1而预期0.5；S4 compositor case150s超时，无足够阶段证据。Browser4完整121pass3fail：S4两locale在原28行全previewer初始inited/host-child60s前置超时，未到journey；Shadcn/React Scroll corner原531行vertical-thumb trailing edge误差158>0.5。其原矩形与后置viewport到底但thumb offset0数据均保留，尚不能归因生产或fixture。Browser6完整169pass。三完整片小计348pass/6fail/0skip，只是3/4/6，不能当八片总数。\n\nBrowser1与2均exit124，无完整summary。Browser1的Search文件实际14pass16fail：8 initialReady.onTime原1s失败、8 Docs role原1s失败；后者均原pending1，后置2s观察得到combobox，原失败仍保留。Brutalist320/390两个Docs case通过。初始readiness的Brutalistlight390在deadline后3ms才记录ready；其余窗口/缺target详见JSON，不能把缺元素写成原getter返回null。该片Portal55/Home runtime11实际通过。Browser2的Homepage9通过；DemoMatrix两case明确在原250行committed-host-readiness60s超时，附近shadow-split token错误保留为关联观察，未证因果。\n\n**Accordion family在实际plan的Browser7，当前仍running；没有下载未完成log，原Space关闭→freshEnter的1s失败是否在本主run出现仍unknown。** 已完成的private25/25或新durable25/25不能替代该同失败CI证据。当前明确通过的相关文件还包括Portal direction8、Dialog available-space8。\n\n没有改源、运行测试/browser、重跑/取消Actions、下载大artifact或对外写入。结论partial/ABSTAIN。每个新predicate、原log行/哈希、不可变源码hash、synthetic tree、尚未终态边界见report.json和log-observations.json。\n'''
(R/'report.md').write_text(md)
selection=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(R.rglob('*')) if p.is_file() and p.name not in ['report-hashes.json']]
(R/'report-hashes.json').write_text(json.dumps({'reportSHA256':sha(R/'report.json'),'markdownSHA256':sha(R/'report.md'),'files':selection},indent=2)+'\n')
print(json.dumps({'reportSHA256':sha(R/'report.json'),'markdownSHA256':sha(R/'report.md'),'docsRows':len(docs),'docsPass':sum(x['passed'] for x in docs),'docsFail':sum(not x['passed'] for x in docs),'searchInitialReadyFailures':len(search),'fileCount':len(selection)},indent=2))
