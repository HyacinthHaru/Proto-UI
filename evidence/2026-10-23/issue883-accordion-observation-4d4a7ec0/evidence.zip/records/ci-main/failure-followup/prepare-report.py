from pathlib import Path
import datetime, hashlib, json, re, subprocess

D = Path(__file__).resolve().parent
R = D.parent.parent
P = D.parent / 'final-read-1'
W = Path('<WORKTREE>')
HEAD = '70d096851a1b22e50ac72e147efaa2b46f62f1c4'
MAIN = '81339ddce9b6fc9b488331e10a533884ace96593'
sha = lambda data: hashlib.sha256(data).hexdigest()
paths = [
    'packages/modules/scroll/src/web/create-web-scroll-host.ts',
    'packages/modules/scroll/test/web-scroll-host.test.ts',
    'packages/modules/scroll/test/web-scroll-corner.test.ts',
    'packages/prototypes/base/src/scroll-area/thumb.proto.ts',
    'packages/prototypes/shadcn/src/scroll-area/thumb.proto.ts',
    'apps/www/src/content/docs/zh-cn/scroll-area-corner.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/demo-brutalist-controls.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/site-search-commands.browser.test.ts',
    'apps/www/src/content/docs/zh-cn/family-query-observer.ts',
    'spec/contracts/C-SCROLL-COMPOSED-CHROME-0001.yaml',
    'spec/contracts/C-SCROLL-COMPOSED-CONTROL-0001.yaml',
    'spec/host-caps/HC-SCROLL-SURFACE-0001.yaml',
    'spec/prototypes/P-BASE-SCROLL-AREA-THUMB.yaml',
    'spec/prototypes/P-SHADCN-SCROLL-AREA-THUMB.yaml',
    'spec/tests/T-SHADCN-SCROLL-AREA-0001.yaml',
    'internal/records/2026-10-03-scroll-area-track-corner.md',
]
bindings = []
for path in paths:
    raw = subprocess.check_output(['git', 'show', HEAD + ':' + path], cwd=W)
    blob = subprocess.check_output(['git', 'rev-parse', HEAD + ':' + path], cwd=W, text=True).strip()
    main = subprocess.run(['git', 'rev-parse', '--verify', MAIN + ':' + path], cwd=W, capture_output=True, text=True)
    main_blob = main.stdout.strip() if main.returncode == 0 else None
    row = {'path': path, 'sha256': sha(raw), 'gitBlob': blob,
           'mainBlob': main_blob, 'sameAsMain': blob == main_blob}
    if path.startswith('spec/'):
        row['status'] = re.search(r'^status: (\S+)', raw.decode(), re.M)[1]
    bindings.append(row)

observations = json.loads((P / 'log-observations.json').read_text())
settlements = {(r['value']['family'], r['value']['width']): r for r in observations['docsPostVerdictSettlements']}
docs = []
for row in observations['docsVerdicts']:
    v = row['value']
    item = {k: v[k] for k in ['family', 'width', 'passed', 'calls', 'pending', 'dropped']}
    item['verdictLogLine'] = row['rawLogLine']
    s = settlements.get((v['family'], v['width']))
    if s:
        x = s['value']
        item['postVerdict'] = {k: x[k] for k in ['budgetMs', 'budgetExpired', 'completeAtDrainPoint',
            'issuedAfterVerdict', 'outcomes', 'observerError', 'droppedSamples', 'droppedOutcomes']}
        item['postVerdict'].update({'logLine': s['rawLogLine'], 'waitDurationMs': x['finishedMs'] - x['startedMs']})
    docs.append(item)

plan_path = Path('<TASK_STATE>/continue-20261023T071326Z/final-native269-70d.plan.json')
plan = json.loads(plan_path.read_text())
report = {
    'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Read-only saved logs and immutable 70d source; no new GitHub/API/test/browser/source edit.',
    'disposition': 'partial/ABSTAIN', 'sourceHead': HEAD, 'mainCompared': MAIN,
    'sourceBindings': bindings,
    'scroll': {
        'jobId': 120418432600,
        'logSHA256': sha((P / 'logs/120418432600.log').read_bytes()),
        'case': "'shadcn' reserves a non-control corner through layout, overflow, focus, and drag transitions",
        'runtime': 'react', 'sourceLine': 531, 'helperLine': 51, 'caseBudgetMs': 240000,
        'assertion': {'rawLogLine': 405, 'tolerancePx': 0.5, 'trackY': 957.5, 'trackHeight': 180,
                      'thumbY': 959.5, 'thumbHeight': 18, 'thumbBottom': 977.5, 'expectedBottom': 1135.5, 'absoluteError': 158},
        'originalOrder': [
            'Content10000px, scrollTo0, both minimum size18px and offset0 polls (490–513).',
            'Original scrollTo(scrollWidth,scrollHeight) (518).',
            'Only vertical host remaining range<=1 poll (519–523).',
            'Four separate rect RPCs through Promise.all (524–529).',
            'Vertical then horizontal0.5px assertions (531–532).',
            'Post-failure viewport/offset reads (558–590),1000ms observation bound, original throw retained.',
        ],
        'originalAndLaterObservations': {
            'original': observations['scrollOriginalAssertion'], 'later': observations['scrollPostFailure'],
            'limit': 'Original rects are separate RPCs; later thumb reads6133.9/6134.1ms precede viewport6140ms. No common atomic snapshot or physical node/lease ID.',
        },
        'owningSource': [
            {'path': paths[0], 'lines': [292, 310, 396, 443, 467, 662, 666, 889, 913, 1103],
             'fact': 'Host snapshot->normalized facts->current control geometry->size/offset style writes. publish projects before connection.onFacts; native scroll invokes publish.'},
            {'path': paths[3], 'lines': [9, 15], 'fact': 'Base Thumb is anatomy-only, not offset owner.'},
            {'path': paths[4], 'lines': [8, 9], 'fact': 'Shadcn Thumb adds visual tokens, not alternate offset state.'},
        ],
        'coverage': {
            'local269Plan': str(plan_path), 'planSHA256': sha(plan_path.read_bytes()), 'files': plan['files'],
            'cornerFileIncluded': paths[5] in plan['files'],
            'existingCScrollFix': {'path': paths[6], 'lines': [1519, 1548],
                'scope': 'Brutalist ArrowRight completion fence after original geometry assertions and before blur/theme, using remaining original10s budget.',
                'coversThisShadcnMinimumThumbFailure': False},
            'hostAndCornerEqualMain': all(x['sameAsMain'] for x in bindings if x['path'] in [paths[0], paths[5]]),
            'notClaimed': 'Main equality does not establish inherited cause or exclude C responsibility. Local269 does not cover this file.',
        },
        'nextMinimalObservation': {
            'status': 'proposal only',
            'selection': 'Original whole Shadcn corner case, all runtime loops,240s original budget.',
            'preserve': ['one original scrollTo and input sequence', 'original end poll/default timeout', 'four rect sampling frontier', 'both0.5px assertions'],
            'design': [
                'Arm capped physical-ID ledger within existing end-scroll evaluate; no additional original-path RPC/await.',
                'Record passive native scroll delivery for that physical Viewport, without synthesizing events or advancing animation.',
                'Within original rect evaluations, keep one original BCR/document-coordinate calculation; append ID/timing to ledger without delaying assertions.',
                'Private exact-source hooks at existing onScroll/publish/projectComposedChrome/retirement reuse actual guard result, snapshot, geometry, computed offset and completed style writes. Never repeat policyCurrent, snapshot, BCR or dispatch for diagnostics.',
                'Collect only after original verdict; original error wins. Bound/drop/error counters and exact descriptor/source cleanup are required.',
            ],
            'discriminants': [
                'No owned onScroll/publish before rects: delivery vs attachment retirement still needs separation, not an automatic wait fix.',
                'Facts position1 but offset0: inspect computation/style-write/restore and current control identity.',
                'Different physical target/control IDs: attachment or replacement boundary.',
                'Current-identity final offset written before original BCR yet wrong position: presentation/geometry realization boundary.',
            ],
            'limits': ['Positive-only run cannot explain failed schedule.', 'Nonzero observation cost, caps and errors remain material.', 'No production fix is proven by current logs.'],
        },
    },
    'docs': {
        'jobId': 120418432576, 'logSHA256': sha((P/'logs/120418432576.log').read_bytes()),
        'rows': docs, 'failed': 8, 'passed': 2,
        'confirmed': 'Eight failed1s verdicts each retain one pending original Promise. All eight later fulfill combobox inside separate2s observation, completeAtDrainPoint=true, no added call, drops or observer errors. Brutalist320/390 are the two passes.',
        'limits': [
            'Post2s settlement is not original1s acceptance or proof of role beforedeadline.',
            'completeAtDrainPoint is not future quiescence or absence of later Vitest retry.',
            'The log lacks this failure per-stage SDK artifact; it cannot divide context/selector/browser getter/driver/Node scheduling causally.',
            'Later value does not establish same physical element or earlier role state.',
            'Failure-only tail extends context lifetime; it is not a proposed2s acceptance deadline.',
            'These8Docs failures are separate from8Search initialReady.onTime failures.',
        ],
        'sourceLines': {'frozenVerdict': [1030, 1058], 'failureOnlyDrain': [1059, 1124]},
    },
    'noProductFixClaim': True,
}
(D/'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
md = '''Scroll corner 原误差158为 Shadcn/React 的最小Thumb端点：track957.5+180−2=1135.5，thumb959.5+18=977.5，差158，原531/51行0.5px断言失败。原host末端poll通过后，四个rect通过独立RPC并行读取。后置viewport已到底9810/9682，两个Thumb offset仍0，但Thumb读取6133.9/6134.1ms早于Viewport6140ms，不是原子状态，亦无物理node/host lease ID。\n\n源侧实际owner是Web scroll host：publish先用snapshot投射composed chrome，再通知onFacts；Base Thumb只声明anatomy，Shadcn只加视觉。相关HC/contract/prototype/test实体均draft。Host与corner test同accepted main81339逐blob相等，但不能以此判旧红或排除C问题。\n\n没有已验证C修复覆盖该端点。旧C的Brutalist ArrowRight completion fence发生在原几何断言之后、blur/theme之前，保留原10s剩余窗口；它不覆盖Shadcn/React的10000px最小Thumb端点。实际clean70d269的11文件清单不含corner文件。已有host最小size/request单测不能代替这次原生时序。\n\n下一最小判别：一次完整原Shadcn case，保240s/原输入/末端poll/四rect采样/0.5px。仅在既有evaluate和host onScroll→publish guard/facts→computed offset/style write/retire加有界身份时序ledger，不新增原路径RPC、等待、事件或layout读；失败后收集，原throw优先。区分native delivery、已退役/不同attachment、计算/写入/覆盖以及真实geometry边界。当前不加wait、不改oracle、不声称修复。\n\nDocs10中8个原1s失败（各1call、pending1），Brutalist320/390通过。8失败原Promise在另一个failure-only2s观察内全返回combobox，无新call/drop/error且drain点完整；这既不把原1s变绿，也不证明deadline前角色正确。completeAtDrainPoint不是quiescence，取证尾窗确延长context寿命。当前原log不含细分SDK阶段artifact，不能归因浏览器、driver、selector或生产投射；另8个Search initial-readiness失败必须分开。\n\n只读旧日志和准确Git源码；无新API/browser/test/源码改动。partial / ABSTAIN。\n'''
(D/'report.md').write_text(md)
print(json.dumps({'reportSHA256':sha((D/'report.json').read_bytes()),'markdownSHA256':sha((D/'report.md').read_bytes())}))
