Scroll corner 原误差158为 Shadcn/React 的最小Thumb端点：track957.5+180−2=1135.5，thumb959.5+18=977.5，差158，原531/51行0.5px断言失败。原host末端poll通过后，四个rect通过独立RPC并行读取。后置viewport已到底9810/9682，两个Thumb offset仍0，但Thumb读取6133.9/6134.1ms早于Viewport6140ms，不是原子状态，亦无物理node/host lease ID。

源侧实际owner是Web scroll host：publish先用snapshot投射composed chrome，再通知onFacts；Base Thumb只声明anatomy，Shadcn只加视觉。相关HC/contract/prototype/test实体均draft。Host与corner test同accepted main81339逐blob相等，但不能以此判旧红或排除C问题。

没有已验证C修复覆盖该端点。旧C的Brutalist ArrowRight completion fence发生在原几何断言之后、blur/theme之前，保留原10s剩余窗口；它不覆盖Shadcn/React的10000px最小Thumb端点。实际clean70d269的11文件清单不含corner文件。已有host最小size/request单测不能代替这次原生时序。

下一最小判别：一次完整原Shadcn case，保240s/原输入/末端poll/四rect采样/0.5px。仅在既有evaluate和host onScroll→publish guard/facts→computed offset/style write/retire加有界身份时序ledger，不新增原路径RPC、等待、事件或layout读；失败后收集，原throw优先。区分native delivery、已退役/不同attachment、计算/写入/覆盖以及真实geometry边界。当前不加wait、不改oracle、不声称修复。

Docs10中8个原1s失败（各1call、pending1），Brutalist320/390通过。8失败原Promise在另一个failure-only2s观察内全返回combobox，无新call/drop/error且drain点完整；这既不把原1s变绿，也不证明deadline前角色正确。completeAtDrainPoint不是quiescence，取证尾窗确延长context寿命。当前原log不含细分SDK阶段artifact，不能归因浏览器、driver、selector或生产投射；另8个Search initial-readiness失败必须分开。

只读旧日志和准确Git源码；无新API/browser/test/源码改动。partial / ABSTAIN。
