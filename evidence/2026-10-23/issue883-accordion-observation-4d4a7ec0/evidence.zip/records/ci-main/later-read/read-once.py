from pathlib import Path
import subprocess,json,datetime,hashlib,concurrent.futures,collections
R=Path(__file__).resolve().parent
REPO='Proto-UI/Proto-UI';RUN=39925882543

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def get(name,endpoint,paged=False):
    out=R/name
    if out.exists(): raise RuntimeError('Refuse to replace prior read: '+name)
    args=['gh','api',endpoint]
    if paged:args+=['--paginate','--slurp']
    start=now()
    try:
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=55)
        raw=p.stdout;err=p.stderr;code=p.returncode
    except subprocess.TimeoutExpired as e:
        raw=e.stdout or b'';err=e.stderr or b'';code=124
    out.write_bytes(raw);(R/(name+'.stderr')).write_bytes(err)
    rec={'start':start,'end':now(),'argv':args,'exit':code,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'networkReadOnly':True,'paginated':paged}
    (R/(name+'.receipt.json')).write_text(json.dumps(rec,indent=2)+'\n')
    if code: return {'name':name,'error':err.decode(errors='replace'),'exit':code}
    try:return {'name':name,'data':json.loads(raw),'receipt':rec}
    except Exception as e:return {'name':name,'error':'JSON parse: '+str(e),'exit':code}

readStart=now()
tasks=[('pr.json',f'repos/{REPO}/pulls/921',False),('main.json',f'repos/{REPO}/git/ref/heads/main',False),('run.json',f'repos/{REPO}/actions/runs/{RUN}',False),('jobs-pages.json',f'repos/{REPO}/actions/runs/{RUN}/jobs?per_page=100&filter=latest',True),('artifacts-pages.json',f'repos/{REPO}/actions/runs/{RUN}/artifacts?per_page=100',True)]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    rs=list(pool.map(lambda x:get(*x),tasks))
errors=[x for x in rs if 'error' in x];lookup={x['name']:x['data'] for x in rs if 'data' in x}
summary={'readStart':readStart,'metadataReadEnd':now(),'atomicSnapshot':False,'errors':errors,'reads':[x.get('receipt',{'name':x['name'],'error':x.get('error')}) for x in rs]}
if not errors:
    pr=lookup['pr.json'];main=lookup['main.json'];run=lookup['run.json'];jp=lookup['jobs-pages.json'];ap=lookup['artifacts-pages.json'];jobs=[j for p in jp for j in p['jobs']];arts=[a for p in ap for a in p['artifacts']]
    summary.update({'sourceHead':pr['head']['sha'],'main':main['object']['sha'],'prState':pr['state'],'prDraft':pr['draft'],'prMerged':pr['merged'],'run':{k:run.get(k) for k in ['id','name','head_sha','status','conclusion','run_attempt','updated_at','html_url']},'jobs':{'totalReported':jp[0]['total_count'],'received':len(jobs),'unique':len({j['id'] for j in jobs}),'pageCount':len(jp),'paginationComplete':len(jobs)==jp[0]['total_count']==len({j['id'] for j in jobs}),'statusCounts':dict(collections.Counter(j['status'] for j in jobs)),'terminalConclusions':dict(collections.Counter(j['conclusion'] for j in jobs if j['status']=='completed'))},'artifacts':{'totalReported':ap[0]['total_count'],'received':len(arts),'unique':len({a['id'] for a in arts}),'pageCount':len(ap),'paginationComplete':len(arts)==ap[0]['total_count']==len({a['id'] for a in arts})},'jobRows':[{k:j.get(k) for k in ['id','name','status','conclusion','head_sha','started_at','completed_at','html_url']} for j in jobs]})
    old=json.loads((R.parent/'current-ci-review.json').read_text());oldmap={j['id']:j for j in old['jobs']}
    summary['newTerminalJobs']=[j['id'] for j in jobs if j['status']=='completed' and oldmap.get(j['id'],{}).get('status')!='completed']
    selected=[j for j in jobs if j['status']=='completed' and (j['name']=='test-general' or j['name']=='public_package_build' or j['name'].startswith('test-browser')) and oldmap.get(j['id'],{}).get('status')!='completed']
    summary['selectedNewTerminalLogs']=[]
    for j in selected:
        name=f"{j['id']}.log";args=['gh','api',f"repos/{REPO}/actions/jobs/{j['id']}/logs"];start=now()
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=55)
        (R/name).write_bytes(p.stdout);(R/(name+'.stderr')).write_bytes(p.stderr)
        rec={'jobId':j['id'],'name':j['name'],'start':start,'end':now(),'argv':args,'exit':p.returncode,'bytes':len(p.stdout),'sha256':hashlib.sha256(p.stdout).hexdigest(),'terminalMetadata':{k:j.get(k) for k in ['status','conclusion','started_at','completed_at']},'downloadAttempt':1}
        (R/(name+'.receipt.json')).write_text(json.dumps(rec,indent=2)+'\n');summary['selectedNewTerminalLogs'].append(rec)
summary['end']=now()
(R/'snapshot.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
