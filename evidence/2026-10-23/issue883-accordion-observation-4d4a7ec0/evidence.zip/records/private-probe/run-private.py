from pathlib import Path
import json,hashlib,subprocess,datetime,sys
P=Path(__file__).parent;R=P.parent;W=Path('<WORKTREE>');M=json.loads((P/'prepared-manifest.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();rows={k:v for k,v in M['files'].items()if'preparedPath'in v};assert len(rows)==3
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==M['head'];assert subprocess.check_output(['git','status','--porcelain'],cwd=W)==b''
for n,v in rows.items():assert sha((W/n).read_bytes())==v['originalSHA256']and sha(Path(v['preparedPath']).read_bytes())==v['instrumentedSHA256']
installed=[]
try:
 for n,v in rows.items(): (W/n).write_bytes(Path(v['preparedPath']).read_bytes());installed.append(n)
 (P/'installed.json').write_text(json.dumps({'at':now(),'files':rows,'head':M['head'],'kind':'privateworkingtreeinstrumentation-notcleanhead'},indent=2)+'\n')
 baseline=json.loads((R/'accordion-baseline/plan.json').read_text());run=P/'execution';run.mkdir();plan={**baseline,'files':[str(W/n)for n in rows],'extraInputPaths':list(dict.fromkeys(baseline['extraInputPaths']+[str(W/n)for n in rows]+[str(P/'prepared/call-timing.mjs'),str(P/'prepared-manifest.json')])),'argv':['corepack','pnpm@10.32.1','exec','vitest','run','apps/www/src/content/docs/zh-cn/demo-accordion-family.browser.test.ts','--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(run/'vitest.json')],'environmentOverrides':{**baseline['environmentOverrides'],'PROTO_UI_ACCORDION_SCREENSHOT_DIR':str(run/'evidence'),'PROTO_UI_ACCORDION_DIAGNOSTIC_DIR':str(run/'same-failure')},'scope':'Once original25cases withprivate readonly journal/SDK/gate/router instrumentation; same1s/90s/input/order, MacCFT155; notclean70dacceptance'};(P/'execution-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'start':now(),'scope':plan['scope']}),flush=True)
 z=subprocess.run(['python3',str(R.parent/'continue-20261023T071326Z/run-plan.py'),str(P/'execution-plan.json'),str(run/'launcher')],cwd=W);(P/'run-exit.json').write_text(json.dumps({'at':now(),'exit':z.returncode},indent=2)+'\n')
finally:
 restored=[];conflicts=[]
 for n in installed:
  v=rows[n];f=W/n
  if sha(f.read_bytes())!=v['instrumentedSHA256']:conflicts.append(n);continue
  b=(P/'original'/n).read_bytes();assert sha(b)==v['originalSHA256'];f.write_bytes(b);restored.append(n)
 receipt={'at':now(),'restored':restored,'conflicts':conflicts,'statusAfter':subprocess.check_output(['git','status','--porcelain'],cwd=W,text=True).strip(),'allOriginalBytesRestored':len(restored)==3and not conflicts};(P/'restore.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);assert receipt['allOriginalBytesRestored']
raise SystemExit(z.returncode)
