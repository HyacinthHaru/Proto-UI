import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const directory = path.dirname(fileURLToPath(import.meta.url));
const worktree = '<WORKTREE>';
const require = createRequire(path.join(worktree, 'package.json'));
const ts = require('typescript');
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
const manifestBytes = fs.readFileSync(path.join(directory, 'prepared-manifest.json'));
const manifest = JSON.parse(manifestBytes);
const testPath = 'apps/www/src/content/docs/zh-cn/demo-accordion-family.browser.test.ts';
const sources = {};
const sourceBindings = [];
for (const [relative, row] of Object.entries(manifest.files)) {
  const original = fs.readFileSync(path.join(directory, 'original', relative));
  const candidate = row.preparedPath ? fs.readFileSync(row.preparedPath) : null;
  sourceBindings.push({ path: relative, originalSHA256: sha(original), originalManifestEqual: sha(original) === row.originalSHA256,
    candidateSHA256: candidate ? sha(candidate) : null, candidateManifestEqual: candidate ? sha(candidate) === row.instrumentedSHA256 : null });
  sources[relative] = { original: original.toString(), candidate: candidate?.toString() };
}
const actionNames = new Set(['press', 'click', 'dblclick', 'focus', 'fill', 'check', 'uncheck', 'hover', 'tap', 'move', 'down', 'up', 'wheel', 'insertText']);
const helperActions = new Set(['applyColorScheme', 'selectAccordionRuntime', 'choosePreviewRuntime']);
function analyze(text) {
  const file = ts.createSourceFile(testPath, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  const assertions = [], actions = [], polls = [], budgets = [], declarations = [], originalReads = [], timeouts = [];
  const at = node => file.getLineAndCharacterOfPosition(node.getStart(file)).line + 1;
  function visit(node) {
    if (ts.isCallExpression(node)) {
      const callee = node.expression.getText(file).replace(/\s+/g, '');
      const call = node.getText(file);
      if (['it', 'beforeAll', 'afterAll'].includes(callee)) {
        const timeoutIndex = callee === 'it' ? 2 : 1;
        budgets.push({ callee, timeout: node.arguments[timeoutIndex]?.getText(file) ?? null });
        if (callee === 'it') declarations.push({ title: node.arguments[0].getText(file), timeout: node.arguments[2]?.getText(file) ?? null });
      }
      if (ts.isPropertyAccessExpression(node.expression)) {
        const method = node.expression.name.text;
        if (actionNames.has(method)) actions.push({ call, line: at(node) });
        let receiver = node.expression.expression;
        const modifiers = [];
        while (ts.isPropertyAccessExpression(receiver)) {
          modifiers.unshift(receiver.name.text);
          receiver = receiver.expression;
        }
        if (ts.isCallExpression(receiver)) {
          const root = receiver.expression.getText(file).replace(/\s+/g, '');
          if (root === 'expect' || root === 'expect.poll') {
            assertions.push({ root, matcher: [...modifiers, method].join('.'),
              subject: root === 'expect.poll' ? '<original poll callback separately audited>' : receiver.arguments.map(arg => arg.getText(file)),
              pollOptions: root === 'expect.poll' ? receiver.arguments.slice(1).map(arg => arg.getText(file)) : null,
              expected: node.arguments.map(arg => arg.getText(file)), originalCallText: call, line: at(node) });
          }
        }
      }
      if (helperActions.has(callee)) actions.push({ call, line: at(node) });
      if (callee === 'expect.poll') polls.push({ callback: node.arguments[0].getText(file), options: node.arguments.slice(1).map(arg => arg.getText(file)), line: at(node) });
      if (callee === 'button.getAttribute' && node.arguments[0]?.getText(file) === "'aria-expanded'") originalReads.push({ call, line: at(node) });
      for (const argument of node.arguments) if (ts.isObjectLiteralExpression(argument)) {
        for (const item of argument.properties) if (ts.isPropertyAssignment(item) && item.name.getText(file) === 'timeout') {
          timeouts.push({ callee, value: item.initializer.getText(file), call, line: at(node) });
        }
      }
    }
    ts.forEachChild(node, visit);
  }
  visit(file);
  const normalizeAssertion = ({ originalCallText, line, ...row }) => row;
  return { syntaxErrors: file.parseDiagnostics.map(item => ts.flattenDiagnosticMessageText(item.messageText, '\n')),
    assertions, normalizedAssertions: assertions.map(normalizeAssertion), actions, polls, budgets, declarations, originalReads, timeouts };
}
const original = analyze(sources[testPath].original), candidate = analyze(sources[testPath].candidate);
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
function literalArray(text, name) {
  const file = ts.createSourceFile('array.ts', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
  let found;
  const visit = node => {
    if (ts.isVariableDeclaration(node) && node.name.getText(file) === name) {
      let value = node.initializer;
      while (value && ts.isAsExpression(value)) value = value.expression;
      if (value && ts.isArrayLiteralExpression(value)) found = value.elements.map(item => item.text);
    }
    ts.forEachChild(node, visit);
  };
  visit(file);
  if (!found?.every(item => typeof item === 'string')) throw Error('Exact literal array unavailable: ' + name);
  return found;
}
const families = literalArray(sources[testPath].original, 'families');
const candidateFamilies = literalArray(sources[testPath].candidate, 'families');
const harnessBytes = fs.readFileSync(path.join(worktree, 'apps/www/src/content/docs/zh-cn/browser-harness.ts'));
const runtimes = literalArray(harnessBytes.toString(), 'RUNTIMES');
const expand = rows => rows.flatMap(row => row.title.includes('${runtime}')
  ? families.flatMap(family => runtimes.map(runtime => ({ name: row.title.slice(1, -1).replace('${family}', family).replace('${runtime}', runtime), timeout: row.timeout })))
  : families.map(family => ({ name: row.title.slice(1, -1).replace('${family}', family), timeout: row.timeout })));
const inventoryOriginal = expand(original.declarations), inventoryCandidate = expand(candidate.declarations);
const extraTimeouts = candidate.timeouts.filter(row => !original.timeouts.some(before => before.call === row.call));
const routerOriginal = sources['packages/adapters/base/src/events/web-event-router.ts'].original;
const routerCandidate = sources['packages/adapters/base/src/events/web-event-router.ts'].candidate;
const calls = (text, expression) => {
  const file = ts.createSourceFile('source.ts', text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS), result = [];
  const visit = node => { if (ts.isCallExpression(node) && node.expression.getText(file) === expression) result.push(node.getText(file)); ts.forEachChild(node, visit); };
  visit(file); return result;
};
const checks = {
  manifestBindingsEqual: sourceBindings.every(row => row.originalManifestEqual && row.candidateManifestEqual !== false),
  testParseDiagnosticsEmpty: !original.syntaxErrors.length && !candidate.syntaxErrors.length,
  familyLoopValuesEqual: equal(families, candidateFamilies),
  declaredTestTemplatesAndBudgetsEqual: equal(original.declarations, candidate.declarations),
  expanded25CaseInventoryEqual: inventoryOriginal.length === 25 && equal(inventoryOriginal, inventoryCandidate),
  allMatcherSubjectExpectedAndPollOptionsEqual: equal(original.normalizedAssertions, candidate.normalizedAssertions),
  originalActionCallTextsAndOrderEqual: equal(original.actions.map(row => row.call), candidate.actions.map(row => row.call)),
  allHookAndCaseBudgetsEqual: equal(original.budgets, candidate.budgets),
  samePollCountAndOptions: equal(original.polls.map(row => row.options), candidate.polls.map(row => row.options)),
  onlyExpandedPollCallbackChanges: original.polls.filter((row, i) => row.callback !== candidate.polls[i]?.callback).length === 1 && original.polls[0].callback.includes("button.getAttribute('aria-expanded')"),
  originalButtonGetterCallTextCountEqual: equal(original.originalReads.map(row => row.call), candidate.originalReads.map(row => row.call)),
  originalExplicitTimeoutsRetained: original.timeouts.every(row => candidate.timeouts.some(after => after.call === row.call)),
  onlyAddedExplicitTimeoutIsPostVerdictScreenshot: extraTimeouts.length === 1 && extraTimeouts[0].value === '3000' && extraTimeouts[0].call.includes('original-failure.png'),
  optGateInvocationTextAndCountEqual: equal(calls(routerOriginal, 'opt.isEnabled'), calls(routerCandidate, 'opt.isEnabled')),
  realDispatchInvocationTextAndCountEqual: equal(calls(routerOriginal, 'target.dispatchEvent'), calls(routerCandidate, 'target.dispatchEvent')),
  originalGateShortCircuitRetained: routerCandidate.includes('const enabled = active && opt.isEnabled();'),
  originalFailureObservationBudgetCallRetained: equal(calls(sources[testPath].original, 'withLiquidCardFailureObservation'), calls(sources[testPath].candidate, 'withLiquidCardFailureObservation')),
  originalContextCloseCallCountEqual: equal(calls(sources[testPath].original, 'context.close'), calls(sources[testPath].candidate, 'context.close')),
  failedVerdictGuardPresentInBothCatches: (sources[testPath].candidate.match(/if \(!activation\.failed\) \{ activation\.failed = true; activation\.observer\.freezeVerdict\(false\); \}/g) ?? []).length === 2,
};
const details = { original, candidate, expandedOriginalInventory: inventoryOriginal, expandedCandidateInventory: inventoryCandidate, sourceBindings, checks };
fs.writeFileSync(path.join(directory, 'assertion-action-extracted.json'), JSON.stringify(details, null, 2) + '\n');
const sdkBytes = fs.readFileSync(manifest.sdkPrivateCopy.path);
const report = {
  schemaVersion: 1, kind: 'Prepared-only TypeScript AST assertion/action comparison', preparedOnly: true,
  head: manifest.head, manifestSHA256: sha(manifestBytes), sdkPrivateSHA256: sha(sdkBytes), sdkManifestEqual: sha(sdkBytes) === manifest.sdkPrivateCopy.sha256,
  result: 'partial', disposition: 'ABSTAIN', formalApproval: false, checks,
  counts: { expandedCases: inventoryOriginal.length, declaredItTemplates: original.declarations.length,
    matcherCallSites: original.assertions.length, actionCallSites: original.actions.length, pollCallSites: original.polls.length,
    originalButtonGetterCallSites: original.originalReads.length, originalExplicitTimeouts: original.timeouts.length, addedCaptureTimeouts: extraTimeouts.length },
  countsMeaning: 'Static call sites, not dynamic input/assertion execution counts.25cases=5families×4runtimes plus5narrowtextcases.',
  loopSource: { families, runtimes, runtimeHarnessSHA256: sha(harnessBytes) },
  sourceBindings,
  closedBeforeExecution: [{ id: 'ACCORDION-PROBE-VERDICT-001', severity: 'P3', status: 'corrected in current prepared source',
    initialCandidateSHA256: 'ab4359f837d43301b5c51377f65a00ebfb334789f54978f90f412e6b0fab91ac',
    issue: 'Outer case catch previously overwrote the original poll rejection timestamp.',
    correction: 'Both catches freeze only when activation.failed is false; original-case.fail remains a separate observation. Caller observation is guarded by observe(), and capture errors remain separate.' }],
  openFindings: Object.entries(checks).filter(([, passed]) => !passed).map(([check]) => ({ check, severity: 'review required' })),
  observerBoundary: [
    'One existing testsetup page.evaluate is augmented; original event journal remains. Extra native focus and MO read-only observers have nonzero cost; no new key/click/focus action or hot-path layout read is introduced.',
    'Only LiquidGlassReact installs the private SDK observer. Otherfamily/runtime assertions remain, with Node helper bookkeeping but no activated observer. Existing poll options and default1s are not changed.',
    'Mainworld ledger caps2048; private SDK cap is deliberately1024 instead of original512. These are observer capacities, not extended matcher deadlines.',
    'Gate methods forward once with original this/arguments/result/throw; router opt.isEnabled retains original shortcircuit. emit observes before/after the one original dispatch; no semantic event is synthesized.',
    'Mainworld physical/event/token IDs are localWeakMap identities; utilityrealm IDs remain separate. Gate logs without an in-flight original event have no exact input attribution.',
    'Current journal records React viewGeneration and opaque instance/router/gate identities, but does not capture all public projection-scope/generation attributes. Do not rename those private identities as complete public owner-generation proof.',
    'Final snapshot/evaluate/screenshot are post-verdict; they do not replace failure-frame facts. The new evaluate has no separate per-call deadline; all observation/capture costs remain inside the original90s case. No universal hung-renderer cleanup guarantee is established.',
    'Original context.close is retained once percase. SDK disposal follows confirmed close; mainrealm listeners/MO end with context lifetime, not a separately reported early disconnect.',
  ],
  executedByReviewer: { browser: 0, tests: 0, API: 0, worktreeEdits: 0, activity: 'AST parse/string/hash extraction only; no prototype or test module imported.' },
  baselineBoundary: 'Root reported original25/25baseline. This audit does not re-execute it or claim the private candidate has run.',
  extractedCallsSHA256: sha(fs.readFileSync(path.join(directory, 'assertion-action-extracted.json'))),
};
fs.writeFileSync(path.join(directory, 'assertion-action-audit.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ checks, counts: report.counts, openFindings: report.openFindings, reportSHA256: sha(fs.readFileSync(path.join(directory, 'assertion-action-audit.json'))) }, null, 2));
