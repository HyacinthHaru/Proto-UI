import { createRequire } from 'node:module';
import { performance as nodePerformance } from 'node:perf_hooks';
import { installDocsCallTimingObserver } from '<R21>/private-probe/prepared/call-timing.mjs';
// @vitest-environment node
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { collectLiquidMaterialObservation } from './liquid-material-observation';
import { withLiquidCardFailureObservation } from './library-liquid-card-observation';
import {
  collectAccordionPendingObservation,
  readAccordionSourceBinding,
} from './accordion-pending-observation';
import type { Browser, Locator, Page } from 'playwright-core';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import {
  RUNTIMES,
  applyColorScheme,
  choosePreviewRuntime,
  launchBrowser,
  openRoute,
  selectRuntime,
  startServer,
  stopServer,
  waitForPreviewRuntime,
} from './browser-harness';
import { revealHeaderPreferences } from './site-header-browser';
const families = ['base', 'shadcn', 'brutalist', 'bootstrap-2-3-2', 'liquid-glass'];
const route = (family: string, locale = 'en') => `/${locale}/ui-libraries/${family}/accordion/`;
let browser: Browser,
  baseUrl = '';
const ref = (previewer: Locator, id: string) => previewer.locator(`.host [data-demo-ref="${id}"]`);
let activation: any = null;
let querySequence = 0, pollSequence = 0;
const observedPolls: any[] = [];
const nodeClock = () => ({ nodeMs: nodePerformance.now(), timeOrigin: nodePerformance.timeOrigin, dateNow: Date.now() });
const expanded = async (button: Locator, value: boolean) => {
  const pollId = ++pollSequence;
  if (activation) observedPolls.push({ stage: 'poll.begin', pollId, expected: value, phase: activation.phase, ...nodeClock() });
  try {
    await expect.poll(() => {
      const read = () => button.getAttribute('aria-expanded');
      return activation ? activation.observer.runOriginalQuery({ pollId, expected: value, phase: activation.phase, query: ++querySequence }, read) : read();
    }).toBe(String(value));
    if (activation) observedPolls.push({ stage: 'poll.pass', pollId, ...nodeClock() });
  } catch (error) {
    if (activation) { activation.failed = true; activation.observer.freezeVerdict(false); observedPolls.push({ stage: 'poll.fail', pollId, ...nodeClock() }); }
    throw error;
  }
};
// Canonical expanded can precede React's Content view commit. Wait only for
// materialization readiness, then assert IDREFs immediately (never poll the relation).
const materialized = async (content: Locator) => {
  await expect
    .poll(() =>
      content.evaluateAll(
        (nodes) =>
          nodes.length === 1 &&
          !nodes[0].hasAttribute('data-pui-view-pending') &&
          !nodes[0].hasAttribute('data-pui-view-detached')
      )
    )
    .toBe(true);
};
const focused = async (button: Locator) => {
  await expect.poll(() => button.evaluate((el) => document.activeElement === el)).toBe(true);
};
async function selectAccordionRuntime(
  page: Page,
  previewer: Locator,
  runtime: (typeof RUNTIMES)[number]
): Promise<void> {
  if ((await previewer.getAttribute('data-projection-toolbar')) !== 'false')
    return selectRuntime(page, previewer, runtime, '[aria-expanded]', 11);
  // A page that explicitly omits its family toolbar uses the visible Header
  // preference. When a real family Select is introduced, exercise that toolbar.
  const openedMenu = await revealHeaderPreferences(page);
  const preferences = page.locator('[data-site-header] [data-site-header-preferences]');
  await choosePreviewRuntime(page, preferences, runtime);
  if (openedMenu) {
    const menu = page.locator('[data-docs-site-header] [data-site-menu-button]');
    if ((await menu.getAttribute('aria-expanded')) === 'true') await menu.click();
  }
  await waitForPreviewRuntime(page, runtime, '[aria-expanded]', 11);
}

async function observeLayout(page: Page) {
  return page.evaluate(() => {
    const viewportWidth = document.documentElement.clientWidth;
    return {
      viewportWidth,
      pageOverflow: document.documentElement.scrollWidth - viewportWidth,
      overflowing: Array.from(document.querySelectorAll<HTMLElement>('body *'))
        .map((element) => {
          const rect = element.getBoundingClientRect();
          const style = getComputedStyle(element);
          const clipping = [];
          for (let parent = element.parentElement; parent; parent = parent.parentElement) {
            if (['auto', 'scroll', 'hidden', 'clip'].includes(getComputedStyle(parent).overflowX)) {
              const bounds = parent.getBoundingClientRect();
              clipping.push({
                tag: parent.tagName,
                className: parent.className,
                left: bounds.left,
                right: bounds.right,
                clientWidth: parent.clientWidth,
                scrollWidth: parent.scrollWidth,
              });
            }
          }
          return {
            clipping,
            tag: element.tagName.toLowerCase(),
            ref: element.dataset.demoRef ?? null,
            role: element.getAttribute('role'),
            className: element.getAttribute('class'),
            text: element.textContent?.slice(0, 120),
            left: rect.left,
            right: rect.right,
            width: rect.width,
            clientWidth: element.clientWidth,
            scrollWidth: element.scrollWidth,
            display: style.display,
            visibility: style.visibility,
            position: style.position,
            overflowX: style.overflowX,
            minWidth: style.minWidth,
            whiteSpace: style.whiteSpace,
            overflowWrap: style.overflowWrap,
            gridTemplateColumns: style.gridTemplateColumns,
          };
        })
        .filter(
          (item) =>
            item.width > 0 &&
            (item.right > viewportWidth + 1 ||
              item.left < -1 ||
              item.scrollWidth > item.clientWidth + 1)
        ),
    };
  });
}

async function capture(
  previewer: Locator,
  name: string,
  subject: { family: string; runtime: string; state: string }
) {
  const base =
    process.env.PROTO_UI_ACCORDION_SCREENSHOT_DIR ??
    (process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR
      ? path.join(process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR, 'accordion')
      : null);
  if (!base) return;
  await mkdir(base, { recursive: true });
  const source = execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
  await previewer.screenshot({
    path: path.join(base, `${source.slice(0, 12)}-${name}.png`),
    style: 'astro-dev-toolbar { visibility: hidden; }',
  });
  if (name.includes('320-text200'))
    await previewer
      .page()
      .screenshot({ path: path.join(base, `${source.slice(0, 12)}-${name}-viewport.png`) });
  await writeFile(
    path.join(base, `${source.slice(0, 12)}-${name}.json`),
    JSON.stringify(
      {
        sourceSha: source,
        sourceDirty:
          execFileSync('git', ['status', '--porcelain', '--untracked-files=no'], {
            encoding: 'utf8',
          }).trim().length > 0,
        layout: await observeLayout(previewer.page()),
        material:
          subject.family === 'liquid-glass'
            ? await Promise.all(
                (await previewer.locator('[aria-expanded]').all()).map((node) =>
                  node.evaluate(collectLiquidMaterialObservation)
                )
              )
            : [],
        fixture: 'demo-accordion-family.browser.test.ts',
        name,
        ...subject,
        rect: await previewer.boundingBox(),
        aria: await previewer.locator('[aria-expanded]').evaluateAll((elements) =>
          elements.map((el) => ({
            ref: (el as HTMLElement).dataset.demoRef ?? null,
            expanded: el.getAttribute('aria-expanded'),
            disabled: el.getAttribute('aria-disabled'),
            controls: el.getAttribute('aria-controls'),
          }))
        ),
        trustedInputs: await previewer
          .page()
          .evaluate(() => (window as any).__accordionInputEvidence ?? []),
        checkedAt: new Date().toISOString(),
        viewport: previewer.page().viewportSize(),
        environment: await previewer.page().evaluate(() => ({
          theme: document.documentElement.dataset.theme ?? null,
          colorScheme: matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light',
          devicePixelRatio,
          rootFontSize: getComputedStyle(document.documentElement).fontSize,
        })),
        comparison:
          'Same source, runtime and viewport across family/state captures; no historical before-image exists.',
      },
      null,
      2
    )
  );
}
beforeAll(async () => {
  baseUrl = await startServer(route('base'));
  browser = await launchBrowser();
}, 150_000);
afterAll(async () => {
  await browser?.close();
  await stopServer();
}, 60_000);
describe.sequential('Accordion five families / four native Web consumers', () => {
  for (const family of families)
    for (const runtime of RUNTIMES)
      it(`${family} ${runtime} preserves activation, natural Tab, ownership, relationships and repeatable lifetime`, async () => {
        const { context, page, previewer } = await openRoute(browser, baseUrl, route(family), {
          width: 1280,
          height: 1000,
        });
        try {
          await page.evaluate((observe) => {
            (window as any).__accordionInputEvidence = [];
            for (const type of ['pointerdown', 'click', 'keydown', 'keyup'])
              document.addEventListener(
                type,
                (event) => {
                  const ref = (event.target as Element | null)
                    ?.closest?.('[data-demo-ref]')
                    ?.getAttribute('data-demo-ref');
                  if (ref)
                    (window as any).__accordionInputEvidence.push({
                      type,
                      trusted: event.isTrusted,
                      ref,
                      key: (event as KeyboardEvent).key ?? null,
                    });
                },
                { capture: true }
              );
            if (!observe) return;
            const w = window as any;
            const ids = new WeakMap<object, string>();
            let next = 0, errors = 0, dropped = 0;
            const rows: any[] = [];
            let lastEvent: Event | null = null;
            const id = (x: any) => { if (!x || (typeof x !== 'object' && typeof x !== 'function')) return null; let n = ids.get(x); if (!n) { n = `main:${++next}`; ids.set(x, n); } return n; };
            const node = (x: any) => {
              if (!(x instanceof Element)) return { identity: id(x), tag: x?.nodeName ?? null };
              return { identity: id(x), tag: x.localName, ref: x.getAttribute('data-demo-ref'), id: x.id, connected: x.isConnected, expanded: x.getAttribute('aria-expanded'), controls: x.getAttribute('aria-controls'), viewAncestors: Array.from((function*(){ for(let p: Element | null=x;p;p=p.parentElement) yield p; })()).filter(p => p.hasAttribute('data-demo-ref') || p.hasAttribute('data-pui-view-pending') || p.hasAttribute('data-pui-view-detached')).map(p => ({ identity: id(p), ref: p.getAttribute('data-demo-ref'), pending: p.hasAttribute('data-pui-view-pending'), detached: p.hasAttribute('data-pui-view-detached'), revealing: p.hasAttribute('data-pui-view-revealing') })) };
            };
            const record = (stage: string, facts: any = {}, root?: Element, token?: object, router?: object, native?: Event) => {
              try {
                const event = native ?? (lastEvent?.eventPhase ? lastEvent : null);
                const r = root?.getAttribute('data-demo-ref');
                if ((stage.startsWith('router.') || stage.startsWith('react.')) && r !== 'single-lifetime-trigger' && r !== 'single-overview-trigger') return;
                if (stage.startsWith('router.emit') && !['press.commit', 'key.down', 'key.up'].includes(facts.type)) return;
                if (rows.length >= 2048) { ++dropped; return; }
                rows.push({ stage, pageMs: performance.now(), timeOrigin: performance.timeOrigin, dateNow: Date.now(), event: id(event), eventPhase: event?.eventPhase ?? 0, eventType: event?.type ?? null, key: (event as KeyboardEvent | null)?.key ?? null, trusted: event?.isTrusted ?? null, keyboardOwner: id((event as any)?.[Symbol.for('@proto.ui/router/keyboard-press-owner')]), root: node(root), token: id(token), routerOrGate: id(router), target: node(event?.target), active: node(document.activeElement), ...facts });
              } catch { ++errors; }
            };
            w.__accordionTrace = { record, snapshot: () => ({ namespace: 'main', rows: [...rows], errors, dropped, finalActive: node(document.activeElement) }) };
            for (const type of ['keydown','keyup','click','pointerdown','focusin','focusout']) document.addEventListener(type, event => { lastEvent = event; record('document.capture'); }, true);
            for (const type of ['keydown','keyup','click','focusin','focusout']) window.addEventListener(type, event => record('window.observation', {}, undefined, undefined, undefined, event));
            const mo = new MutationObserver(records => {
              for (const mutation of records) {
                const target = mutation.target instanceof Element ? mutation.target : null;
                if (!target || target.getAttribute('data-demo-ref') !== 'single-lifetime-trigger') continue;
                record('mutation.delivery', { mutationType: mutation.type, attribute: mutation.attributeName, oldValue: mutation.oldValue, subject: node(target) });
              }
            });
            mo.observe(document, { subtree: true, childList: true, attributes: true, attributeOldValue: true, attributeFilter: ['aria-expanded','aria-controls','data-pui-view-pending','data-pui-view-detached','data-pui-view-revealing'] });
          }, family === 'liquid-glass' && runtime === 'react');
          await applyColorScheme(page, 'light');
          await selectAccordionRuntime(page, previewer, runtime);
          const first = ref(previewer, 'single-overview-trigger'),
            second = ref(previewer, 'single-lifetime-trigger'),
            long = ref(previewer, 'single-long-trigger');
          if (family === 'liquid-glass' && runtime === 'react') {
            const req = createRequire(path.join(process.cwd(), 'apps/www/package.json'));
            const sdkRoot = path.dirname(req.resolve('playwright-core/package.json'));
            activation = { phase: 'initial', failed: false, observer: installDocsCallTimingObserver(page, { sdkRoot, selector: (second as any)._selector, attribute: 'aria-expanded' }) };
          }
          await expanded(first, true);
          await expanded(second, false);
          await capture(ref(previewer, 'single'), `${family}-${runtime}-light-initial-open`, {
            family,
            runtime,
            state: 'initial-open',
          });
          await first.focus();
          await page.keyboard.press('Enter');
          await expanded(first, false);
          await capture(
            ref(previewer, 'single'),
            `${family}-${runtime}-light-closed-keyboard-focus`,
            { family, runtime, state: 'closed-keyboard-focus' }
          );
          await page.keyboard.press('Enter');
          await expanded(first, true);
          await first.focus();
          await page.keyboard.press('ArrowDown');
          await focused(second);
          await expanded(first, true);
          await expanded(second, false);
          await page.keyboard.press('Enter');
          await expanded(first, false);
          await expanded(second, true);
          await focused(second);
          await materialized(ref(previewer, 'single-lifetime-content'));
          const id = await second.getAttribute('aria-controls');
          expect(id).toBeTruthy();
          expect(await ref(previewer, 'single-lifetime-content').getAttribute('id')).toBe(id);
          expect(
            await ref(previewer, 'single-lifetime-content').getAttribute('aria-labelledby')
          ).toBe(await second.getAttribute('id'));
          const scrollY = await page.evaluate(() => window.scrollY);
          if (activation) activation.phase = 'second-space-close';
          await page.keyboard.press('Space');
          await expanded(second, false);
          expect(await page.evaluate(() => window.scrollY)).toBe(scrollY);
          expect(await second.getAttribute('aria-controls')).toBeNull();
          if (activation) activation.phase = 'second-fresh-enter';
          await page.keyboard.press('Enter');
          await expanded(second, true);
          await materialized(ref(previewer, 'single-lifetime-content'));
          expect(await second.getAttribute('aria-controls')).toBe(id);
          expect(await ref(previewer, 'single-lifetime-content').getAttribute('id')).toBe(id);
          expect(
            await ref(previewer, 'single-lifetime-content').getAttribute('aria-labelledby')
          ).toBe(await second.getAttribute('id'));
          await page.keyboard.press('Tab');
          await focused(long); // disabled header is skipped; no auto focusable Content
          await page.keyboard.press('Home');
          await focused(first);
          await page.keyboard.press('End');
          await focused(long);
          await expanded(second, true);
          await capture(previewer, `${family}-${runtime}-open-focus`, {
            family,
            runtime,
            state: 'open-keyboard-focus',
          });
          const required = ref(previewer, 'multiple-a-trigger');
          expect(await required.getAttribute('aria-disabled')).toBe('true');
          await required.focus();
          await page.keyboard.press('Enter');
          await expanded(required, true);
          const retainedId = await required.getAttribute('aria-controls');
          await ref(previewer, 'multiple-b-trigger').click();
          await required.click();
          await expanded(required, false);
          expect(await required.getAttribute('aria-controls')).toBe(retainedId);
          expect(await ref(previewer, 'multiple-a-content').isVisible()).toBe(false);
          const rtl = ref(previewer, 'rtl-a-trigger');
          await rtl.focus();
          await page.keyboard.press('ArrowLeft');
          await focused(ref(previewer, 'rtl-b-trigger'));
          await expanded(rtl, false);
          const controlled = ref(previewer, 'controlled-a-trigger');
          await controlled.click();
          await expanded(controlled, false);
          await ref(previewer, 'accept').click();
          await expanded(controlled, true);
          await first.click();
          await expanded(first, true);
          await withLiquidCardFailureObservation(
            () => ref(previewer, 'nested-overview-trigger').click(),
            () =>
              ref(previewer, 'nested-overview-trigger').evaluate(
                collectAccordionPendingObservation
              ),
            async (facts) => {
              const directory =
                process.env.PROTO_UI_ACCORDION_SCREENSHOT_DIR ??
                (process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR
                  ? path.join(process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR, 'accordion')
                  : null);
              if (!directory) return;
              await mkdir(directory, { recursive: true });
              const { sourceSha, sourceTree, sourceDirty } = readAccordionSourceBinding((args) =>
                execFileSync('git', args, { encoding: 'utf8' })
              );
              // At most one retained observation per exact source/family/runtime.
              // EEXIST is secondary and never replaces the original native failure.
              await writeFile(
                path.join(
                  directory,
                  `${sourceSha.slice(0, 12)}-${family}-${runtime}-nested-click-failure.json`
                ),
                JSON.stringify(
                  { sourceSha, sourceTree, sourceDirty, family, runtime, facts },
                  null,
                  2
                ),
                { flag: 'wx' }
              );
            },
            (error) => console.error('[accordion failure observation]', String(error)),
            1000
          );
          await expanded(ref(previewer, 'nested-overview-trigger'), true);
          await expanded(first, true);
          await capture(previewer, `${family}-${runtime}-controlled-nested`, {
            family,
            runtime,
            state: 'controlled-accepted-and-nested-open',
          });
          const old = await first.elementHandle();
          await selectAccordionRuntime(
            page,
            previewer,
            RUNTIMES[(RUNTIMES.indexOf(runtime) + 1) % RUNTIMES.length]!
          );
          expect(await old?.evaluate((el) => el.isConnected)).toBe(false);
        } catch (error) {
          if (activation) { activation.failed = true; activation.observer.freezeVerdict(false); observedPolls.push({ stage: 'original-case.fail', ...nodeClock() }); }
          throw error;
        } finally {
          if (activation) {
            if (!activation.failed) activation.observer.freezeVerdict(true);
            try {
              const main = await page.evaluate(() => (window as any).__accordionTrace?.snapshot());
              const directory = process.env.PROTO_UI_ACCORDION_DIAGNOSTIC_DIR!;
              await mkdir(directory, { recursive: true });
              await writeFile(path.join(directory, 'same-run-before-close.json'), JSON.stringify({ main, node: activation.observer.snapshot(), polls: observedPolls }, null, 2));
              if (activation.failed) await page.screenshot({ path: path.join(directory, 'original-failure.png'), fullPage: true, timeout: 3000 });
            } catch (error) { console.error('Accordion diagnostic capture failed', error); }
            activation.observer.markContextCloseStart();
          }
          await context.close();
          if (activation) {
            activation.observer.disposeAfterContextClosed(true);
            try { await writeFile(path.join(process.env.PROTO_UI_ACCORDION_DIAGNOSTIC_DIR!, 'same-run-final.json'), JSON.stringify({ node: activation.observer.snapshot(), polls: observedPolls }, null, 2)); } catch (error) { console.error('Accordion diagnostic final capture failed', error); }
            activation = null;
          }
        }
      }, 90_000);
  for (const family of families)
    it(`${family} Chinese 320px / 200% text keeps long labels and overflow inside the page`, async () => {
      const { context, page, previewer } = await openRoute(
        browser,
        baseUrl,
        route(family, 'zh-cn'),
        { width: 320, height: 1100 }
      );
      try {
        await applyColorScheme(page, 'light');
        await selectAccordionRuntime(page, previewer, 'react');
        await page.evaluate(() => {
          document.documentElement.style.fontSize = '200%';
        });
        const button = ref(previewer, 'single-long-trigger');
        await button.click();
        await expanded(button, true);
        // Preserve the exact failing paint and read-only geometry before the
        // strict assertion; a red run must still contain its useful evidence.
        await capture(previewer, `${family}-react-zh-320-text200`, {
          family,
          runtime: 'react',
          state: 'long-label-320-text200',
        });
        if (family !== 'base') {
          const chevron = await button.locator('svg').evaluate((el) => {
            const bounds = el.getBoundingClientRect();
            const frame = el.parentElement!;
            return {
              width: bounds.width,
              height: bounds.height,
              shrink: getComputedStyle(frame).flexShrink,
              pointerEvents: getComputedStyle(frame).pointerEvents,
            };
          });
          expect(chevron.width).toBeCloseTo(family === 'brutalist' ? 20 : 16, 1);
          expect(chevron.height).toBeCloseTo(family === 'brutalist' ? 20 : 16, 1);
          expect(chevron.shrink).toBe('0');
          expect(chevron.pointerEvents).toBe('none');
        }
        expect(await button.evaluate((el) => el.scrollHeight <= el.clientHeight + 1)).toBe(true);
        const layout = await observeLayout(page);
        expect(layout.pageOverflow, JSON.stringify(layout.overflowing)).toBeLessThanOrEqual(1);
      } finally {
        await context.close();
      }
    }, 90_000);
});
