from pathlib import Path
import hashlib,json,difflib,subprocess
P=Path(__file__).parent;D=P/'prepared';W=Path('<WORKTREE>');H='70d096851a1b22e50ac72e147efaa2b46f62f1c4';sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','status','--porcelain'],cwd=W)==b''
files={}
def source(name):
 b=subprocess.check_output(['git','show',H+':'+name],cwd=W);assert(W/name).read_bytes()==b;files[name]={'originalSHA256':sha(b),'originalBytes':len(b)};q=P/'original'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);return b.decode()
def output(name,old,new):
 assert new!=old;q=D/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(new);(D/(name.replace('/','__')+'.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=H+'/'+name,tofile='private-readonly-probe/'+name)));files[name].update(instrumentedSHA256=sha(q.read_bytes()),preparedPath=str(q))
name='apps/www/src/content/docs/zh-cn/docs-query-timing.mjs';s=source(name);t=s.replace('export function installDocsCallTimingObserver(page, { sdkRoot, cap = 512 }) {','export function installDocsCallTimingObserver(page, { sdkRoot, cap = 1024, selector = expectedSelector, attribute = "role" }) {\n  const targetSelector = selector;');assert t!=s;t=t.replace('selector === expectedSelector && name === \'role\'','selector === targetSelector && name === attribute').replace("arg?.taskData?.name !== 'role'","arg?.taskData?.name !== attribute").replace('selector: expectedSelector,','selector: targetSelector,').replace("attribute: 'role',",'attribute,');(D/'call-timing.mjs').write_text(t);(D/'call-timing.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile=name,tofile='private-call-timing.mjs')))
name='packages/adapters/base/src/events/web-event-router.ts';s=source(name);old='  const isEnabled = () => activeRouterByRoot.get(rootEl) === routerIdentity && opt.isEnabled();';new='''  const isEnabled = () => {
    const active = activeRouterByRoot.get(rootEl) === routerIdentity;
    const enabled = active && opt.isEnabled();
    try { (globalThis as any).__accordionTrace?.record('router.enabled', { active, optEvaluated: active, enabled }, rootEl, opt.instanceToken, routerIdentity); } catch {}
    return enabled;
  };''';assert s.count(old)==1;t=s.replace(old,new);old='    target.dispatchEvent(ev);';new="    try { (globalThis as any).__accordionTrace?.record('router.emit.before', { type }, rootEl, opt.instanceToken, routerIdentity, native); } catch {}\n"+old+"\n    try { (globalThis as any).__accordionTrace?.record('router.emit.after', { type }, rootEl, opt.instanceToken, routerIdentity, native); } catch {}";assert t.count(old)==1;t=t.replace(old,new);output(name,s,t)
name='packages/adapters/react/src/adapt.ts';s=source(name);old='        eventGateRef.current = eventGate;';new=old+'''
        for (const method of ['enable', 'disable', 'isEnabled', 'dispose'] as const) {
          const original = eventGate[method];
          (eventGate as any)[method] = function (...args: any[]) {
            const value = Reflect.apply(original, this, args);
            try { (globalThis as any).__accordionTrace?.record('react.gate.' + method, { value, viewGeneration: viewGenerationRef.current, viewReady: viewReadyRef.current, hasPendingCommit: !!pendingCommitRef.current }, rootEl, instanceTokenRef.current, eventGate); } catch {}
            return value;
          };
        }''';assert s.count(old)==1;output(name,s,s.replace(old,new))
name='apps/www/src/content/docs/zh-cn/demo-accordion-family.browser.test.ts';s=source(name);t="import { createRequire } from 'node:module';\nimport { performance as nodePerformance } from 'node:perf_hooks';\nimport { installDocsCallTimingObserver } from '"+str(D/'call-timing.mjs')+"';\n"+s
pos=t.index('const expanded = async');t=t[:pos]+'''let activation: any = null;
let querySequence = 0, pollSequence = 0;
const observedPolls: any[] = [];
const nodeClock = () => ({ nodeMs: nodePerformance.now(), timeOrigin: nodePerformance.timeOrigin, dateNow: Date.now() });
'''+t[pos:]
old="  await expect.poll(() => button.getAttribute('aria-expanded')).toBe(String(value));";new='''  const pollId = ++pollSequence;
  if (activation) observedPolls.push({ stage: 'poll.begin', pollId, expected: value, phase: activation.phase, ...nodeClock() });
  try {
    await expect.poll(() => {
      const read = () => button.getAttribute('aria-expanded');
      return activation ? activation.observer.runOriginalQuery({ pollId, expected: value, phase: activation.phase, query: ++querySequence }, read) : read();
    }).toBe(String(value));
    if (activation) observedPolls.push({ stage: 'poll.pass', pollId, ...nodeClock() });
  } catch (error) {
    if (activation) { activation.failed = true; activation.observer.freezeVerdict(false); observedPolls.push({ stage: 'poll.fail', pollId, ...nodeClock() }); }
    throw error;
  }''';assert t.count(old)==1;t=t.replace(old,new)
start=t.index('          await page.evaluate(() => {');end=t.index("          await applyColorScheme(page, 'light');",start);old=t[start:end];assert old.endswith('          });\n');new=old.replace('await page.evaluate(() => {','await page.evaluate((observe) => {',1)[:-len('          });\n')]
new+='''            if (!observe) return;
            const w = window as any;
            const ids = new WeakMap<object, string>();
            let next = 0, errors = 0, dropped = 0;
            const rows: any[] = [];
            let lastEvent: Event | null = null;
            const id = (x: any) => { if (!x || (typeof x !== 'object' && typeof x !== 'function')) return null; let n = ids.get(x); if (!n) { n = `main:${++next}`; ids.set(x, n); } return n; };
            const node = (x: any) => {
              if (!(x instanceof Element)) return { identity: id(x), tag: x?.nodeName ?? null };
              return { identity: id(x), tag: x.localName, ref: x.getAttribute('data-demo-ref'), id: x.id, connected: x.isConnected, expanded: x.getAttribute('aria-expanded'), controls: x.getAttribute('aria-controls'), viewAncestors: Array.from((function*(){ for(let p: Element | null=x;p;p=p.parentElement) yield p; })()).filter(p => p.hasAttribute('data-demo-ref') || p.hasAttribute('data-pui-view-pending') || p.hasAttribute('data-pui-view-detached')).map(p => ({ identity: id(p), ref: p.getAttribute('data-demo-ref'), pending: p.hasAttribute('data-pui-view-pending'), detached: p.hasAttribute('data-pui-view-detached'), revealing: p.hasAttribute('data-pui-view-revealing') })) };
            };
            const record = (stage: string, facts: any = {}, root?: Element, token?: object, router?: object, native?: Event) => {
              try {
                const event = native ?? (lastEvent?.eventPhase ? lastEvent : null);
                const r = root?.getAttribute('data-demo-ref');
                if ((stage.startsWith('router.') || stage.startsWith('react.')) && r !== 'single-lifetime-trigger' && r !== 'single-overview-trigger') return;
                if (stage.startsWith('router.emit') && !['press.commit', 'key.down', 'key.up'].includes(facts.type)) return;
                if (rows.length >= 2048) { ++dropped; return; }
                rows.push({ stage, pageMs: performance.now(), timeOrigin: performance.timeOrigin, dateNow: Date.now(), event: id(event), eventPhase: event?.eventPhase ?? 0, eventType: event?.type ?? null, key: (event as KeyboardEvent | null)?.key ?? null, trusted: event?.isTrusted ?? null, keyboardOwner: id((event as any)?.[Symbol.for('@proto.ui/router/keyboard-press-owner')]), root: node(root), token: id(token), routerOrGate: id(router), target: node(event?.target), active: node(document.activeElement), ...facts });
              } catch { ++errors; }
            };
            w.__accordionTrace = { record, snapshot: () => ({ namespace: 'main', rows: [...rows], errors, dropped, finalActive: node(document.activeElement) }) };
            for (const type of ['keydown','keyup','click','pointerdown','focusin','focusout']) document.addEventListener(type, event => { lastEvent = event; record('document.capture'); }, true);
            for (const type of ['keydown','keyup','click','focusin','focusout']) window.addEventListener(type, event => record('window.observation', {}, undefined, undefined, undefined, event));
            const mo = new MutationObserver(records => {
              for (const mutation of records) {
                const target = mutation.target instanceof Element ? mutation.target : null;
                if (!target || target.getAttribute('data-demo-ref') !== 'single-lifetime-trigger') continue;
                record('mutation.delivery', { mutationType: mutation.type, attribute: mutation.attributeName, oldValue: mutation.oldValue, subject: node(target) });
              }
            });
            mo.observe(document, { subtree: true, childList: true, attributes: true, attributeOldValue: true, attributeFilter: ['aria-expanded','aria-controls','data-pui-view-pending','data-pui-view-detached','data-pui-view-revealing'] });
          }, family === 'liquid-glass' && runtime === 'react');
''';t=t[:start]+new+t[end:]
old="            long = ref(previewer, 'single-long-trigger');";new=old+'''
          if (family === 'liquid-glass' && runtime === 'react') {
            const req = createRequire(path.join(process.cwd(), 'apps/www/package.json'));
            const sdkRoot = path.dirname(req.resolve('playwright-core/package.json'));
            activation = { phase: 'initial', failed: false, observer: installDocsCallTimingObserver(page, { sdkRoot, selector: (second as any)._selector, attribute: 'aria-expanded' }) };
          }''';assert t.count(old)==1;t=t.replace(old,new)
old="          await page.keyboard.press('Space');";assert t.count(old)==1;t=t.replace(old,"          if (activation) activation.phase = 'second-space-close';\n"+old)
old="          expect(await second.getAttribute('aria-controls')).toBeNull();\n          await page.keyboard.press('Enter');";assert t.count(old)==1;t=t.replace(old,"          expect(await second.getAttribute('aria-controls')).toBeNull();\n          if (activation) activation.phase = 'second-fresh-enter';\n          await page.keyboard.press('Enter');")
old='''        } finally {
          await context.close();
        }
      }, 90_000);''';new='''        } finally {
          if (activation) {
            if (!activation.failed) activation.observer.freezeVerdict(true);
            try {
              const main = await page.evaluate(() => (window as any).__accordionTrace?.snapshot());
              const directory = process.env.PROTO_UI_ACCORDION_DIAGNOSTIC_DIR!;
              await mkdir(directory, { recursive: true });
              await writeFile(path.join(directory, 'same-run-before-close.json'), JSON.stringify({ main, node: activation.observer.snapshot(), polls: observedPolls }, null, 2));
              if (activation.failed) await page.screenshot({ path: path.join(directory, 'original-failure.png'), fullPage: true, timeout: 3000 });
            } catch (error) { console.error('Accordion diagnostic capture failed', error); }
            activation.observer.markContextCloseStart();
          }
          await context.close();
          if (activation) {
            activation.observer.disposeAfterContextClosed(true);
            try { await writeFile(path.join(process.env.PROTO_UI_ACCORDION_DIAGNOSTIC_DIR!, 'same-run-final.json'), JSON.stringify({ node: activation.observer.snapshot(), polls: observedPolls }, null, 2)); } catch (error) { console.error('Accordion diagnostic final capture failed', error); }
            activation = null;
          }
        }
      }, 90_000);''';assert t.count(old)==1;t=t.replace(old,new);output(name,s,t)
manifest={'head':H,'preparedOnly':True,'productionFix':False,'files':files,'sdkPrivateCopy':{'path':str(D/'call-timing.mjs'),'sha256':sha((D/'call-timing.mjs').read_bytes())},'scope':'Private temporary exactsource instrumentation, original25inputs/assertions/1spoll/90scase preserved; notcleanheadacceptance. Originalexceptions/results retaincontrol; callbackobservercostnonzero.'};(P/'prepared-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'prepared':len(files)-1,'sourceEditsApplied':False,'manifest':str(P/'prepared-manifest.json')},indent=2))
