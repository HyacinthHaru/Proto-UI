import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import path from 'node:path';
const D=path.dirname(new URL(import.meta.url).pathname);
const require=createRequire('<WORKTREE>/package.json');
const ts=require('typescript');
const js=s=>ts.transpileModule(s,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;
const read=(base,p)=>fs.readFileSync(path.join(D,base,p),'utf8');
const router='packages/adapters/base/src/events/web-event-router.ts';
const original=read('original',router),candidate=read('prepared',router);
const o=original.match(/  const isEnabled = [^\n]+/)[0];
const c=candidate.slice(candidate.indexOf('  const isEnabled ='),candidate.indexOf('  const contactWriter ='));
const results=[];
function route(code,active,value,throws,observerThrows){
 const root={},identity={},map=new Map(active?[[root,identity]]:[]),error={original:'sentinel'};
 let calls=0,records=0;
 const context={rootEl:root,routerIdentity:identity,activeRouterByRoot:map,opt:{instanceToken:{},isEnabled(){++calls;if(throws)throw error;return value;}},__accordionTrace:{record(){++records;if(observerThrows)throw new Error('diagnostic-only');}}};
 let answer,thrown;try{answer=vm.runInNewContext(js(code)+'\nisEnabled();',context);}catch(e){thrown=e;}
 return {answer,calls,records,thrownOriginal:thrown===error,throwOther:!!thrown&&thrown!==error};
}
for(const [name,active,value,throws,obs]of[['active-true',true,true,false,false],['active-false',true,false,false,false],['inactive-short-circuit',false,true,false,false],['inactive-throwing-opt-unreached',false,true,true,true],['original-throw',true,true,true,true],['observer-throw',true,true,false,true]]){
 const a=route(o,active,value,throws,obs),b=route(c,active,value,throws,obs);
 for(const k of ['answer','calls','thrownOriginal','throwOther'])assert.equal(b[k],a[k],name+':'+k);
 results.push({name,original:a,instrumented:b,passed:true});
}
const gateSource=read('original','packages/adapters/base/src/gate/event-gate.ts');
const make=()=>{const context={exports:{}};vm.runInNewContext(js(gateSource),context);return context.exports.createEventGate();};
const react=read('prepared','packages/adapters/react/src/adapt.ts');
const a=react.indexOf("        for (const method of ['enable'");const b=react.indexOf('\n\n        const router =',a);assert(a>0&&b>a);const loop=react.slice(a,b);
for(const observerThrows of [false,true]){
 const plain=make(),observed=make();let records=0;const counters={};
 for(const method of ['enable','disable','isEnabled','dispose']){const original=observed[method];observed[method]=function(...args){counters[method]=(counters[method]??0)+1;return Reflect.apply(original,this,args);};}
 const context={eventGate:observed,rootEl:{},instanceTokenRef:{current:{}},viewGenerationRef:{current:4},viewReadyRef:{current:true},pendingCommitRef:{current:null},__accordionTrace:{record(){++records;if(observerThrows)throw new Error('diagnostic-only');}}};vm.runInNewContext(js(loop),context);
 const operations=['isEnabled','enable','isEnabled','disable','isEnabled','dispose','enable','isEnabled'];
 const expected=operations.map(m=>plain[m]()),actual=operations.map(m=>observed[m]());assert.deepEqual(actual,expected);assert.deepEqual(counters,{isEnabled:4,enable:2,disable:1,dispose:1});assert.equal(records,operations.length);results.push({name:'actual-gate-methods-observer-throws='+observerThrows,passed:true,operations,values:actual,originalCalls:counters});
}
fs.writeFileSync(path.join(D,'noninterference-result.json'),JSON.stringify({scope:'Executed actual extracted original/router/gate and prepared wrappers in VM; artificial local closures, not nativeinput/hostedfailure. Original shortcircuit, return, originalthrow identity and once-onlycalls preserved under observerthrow.',results},null,2)+'\n');console.log(JSON.stringify({passed:results.length,failed:0,scope:'private-source noninterference control'}));
