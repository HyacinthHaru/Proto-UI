# Accordion activation probe — prepared only

`accordion-activation-probe.mjs` is a proposed test-only Vite plugin. Copying it to `apps/www/scripts/accordion-activation-probe.mjs` and applying `astro-config.proposal.patch` would register it in the existing Vite plugin array. Neither action has been performed here.

The two-line integration adds its import and `accordionActivationProbePlugin(repositoryRoot)`. Without a nonempty `PROTO_UI_ACCORDION_ACTIVATION_PROBE_DIR`, the factory returns `undefined`. With the environment variable, `apply: 'serve'` restricts transformation to the development server. The plugin does not create a server, directory, evidence file, observer, timer, or RPC.

The transform matches only the resolved repository paths for `packages/adapters/base/src/events/web-event-router.ts` and `packages/adapters/react/src/adapt.ts`, ignoring a Vite query suffix. It requires each of six source shapes exactly once; mismatch throws `ACCORDION_ACTIVATION_PROBE_SETUP` before returning transformed code. The six shapes cover three existing observation sites and three keyboard handler calls. The source patches and original/candidate copies are review material, not changes to Adapter package sources.

`router.enabled` records the original active-router comparison and short-circuited `opt.isEnabled()` result. Only `global.keydown`, `root.keydown`, and `global.keyup` pass their actual `KeyboardEvent` and handler label. Other calls have no event association; the test sink must preserve this as unknown instead of inferring the last input. `router.emit.before/after` forward the original native event around one unchanged dispatch. React gate wrappers call each original method once with its original `this` and arguments, return its actual result, and preserve an original throw. React gate records themselves do not acquire a direct native-event argument.

All record calls and fact evaluation are inside diagnostic `try/catch` blocks. The test owns installation, bounded storage, drops/error reporting, arming, and descriptor cleanup for `globalThis.__accordionTrace`. A missing sink yields no record, not successful capture. No Adapter public API or Compiler/IR behavior is added. Logging and wrapping have nonzero cost; transformed line numbers differ and the plugin returns no source map.

`prepared-binding.json` binds the current 70d source bytes, each source shape and transformed candidate, the two-line Astro proposal, and the plugin. Node syntax checking has completed; no Vite server, transform execution, browser, test, or CI workflow has run for this plugin. The earlier private 25/25 result remains a separate positive diagnostic arm with a capped journal; it did not reproduce the natural CI failure.

Disposition: preparation only, partial / ABSTAIN, no independent acceptance claim.
