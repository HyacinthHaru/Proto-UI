# Accordion same-failure trace — prepared only

Currentread source is clean70d/tree7d18; allboundfiles equalGit. Theactualhistoricalcase is LiquidGlassReact, line277: secondTriggerSpaceclose has passed expandedfalse, unchangedscroll andcontrolsnull; thefollowingfreshEnter's expandedtrue poll timesout1000ms. Originalcase90s/allinputs remain. Theoldcapture/journal cannotprove thatlastkey's target/focus/gate/getter timing.

Activeauthorities: A-REACT-18-19-0001 andC-LIFECYCLE-0008. AccordionRoot/Trigger/Content, LiquidTrigger, tests andC-EVENT-0003 remain draft. The2026-10-08reopen record fixes a different boundary (expandedtrue butContentIDREFnotcommitted); itdoesnotjustify addingwaitbeforethisexpandedfalsefailure.

One actualsource chain merits observation: LiquidTrigger expanded.watch schedulesdelay(0)→run.update; Reactcommit disableseventGate andreenablesonlyaftermatchingview/stylecommit. However publicpending/revealing markers arenot actualgate state, particularlyexisting-readyupdates. This is a hypothesis, not a proposed productionfix.

Minimumsame-case instrumentedarm afterRoot's unmodifiedbaseline:

1. Extend theexistingjournalpage.evaluate, retainingoriginaljournal andaddinga boundedcompanion ledger withnativeeventID/timestamps,target+activeElement mainworldIDs, focusin/out, realref/id/connected/aria andscope/generation/viewmarkers. IncludeBODY/refnull; noextraRPC/layoutread/input/wait onthekeypath.
2. Privately copycurrentdocs-query-timing helper, retargetonlyexactSecondLocatorselector andaria-expanded. Reuse7SDKpins, ALSrunOriginalQuery, realcallId/attempt andsameevaluate selector/getter timing. OriginalgetAttribute iscalledonceanditsPromise/value/errorpreserved. No cold-targetwarmupawait ornewquery. Freezeoriginal1s verdictbeforeboundedfailed-tailcollection.
3. For anactualgate claim, RootmaytemporarilyVite-transformtheexistingroutergate evaluation torecordits originalretval/currentrouterfactor—nevercallitagain, preserveoriginalshortcircuit andallroot/global/keyboardownerlogic. Publicmarkersalonecannotprovegatedinput. Thisisprivateinstrumentationwithrawsourcehash,notnewproductionAPI/debugbranch.
4. Saveoriginalfailure/frozenverdict/trace first, then boundedpostfailureDOM/PNG andfinallyrealcleanup. Anycaptureerror remainssecondary. Do not mutatefocus/props/owner orreplayaninput.

Keepmain/utilityidentityspaces separate; sameid/ref/ownerattributes alonearenota crossrealmphysicalidentityproof. Node/browserclockorigins/resolutionareseparate. Caps/errors/lateinstall/0capture areexplicitdebt. Root's CFT155 choice, ifmade,stilldiffersfromLinuxOS; no nativeexecutionordownloadoccurredhere.

Exactcaseargv anddecisiontable arein`same-failure-plan.json`; sourcepaths/linechain/status/hash in`source-map.json`. NoexistingCfix isestablishedbeforeactualsamefailure observations. Preserveowner17andoriginal1s/90s.
