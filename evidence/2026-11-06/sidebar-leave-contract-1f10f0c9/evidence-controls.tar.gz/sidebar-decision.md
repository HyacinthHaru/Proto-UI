# Sidebar 归还边界：准确 main 508e2d3 的决策包

范围：既有 Docs Contents Dialog 的同一原生导航树。不是 #1191 的全部 Popover/响应式验收，也不接管 #1161 活跃共享浮层修复或 #1177 terminal teardown。

本轮准确源码：508e2d3b7dc397c06d843d61748aa7962fc67bb8，tree51988a973b0e76dfaeaf16dc86e9848ce6c02577。最新main相对上一轮只有两个workflow与一条事实记录；产品、原test、定义和锁文件未改。原Contents用例仍0/1/8filtered，原L954 count0≠1，原关闭/焦点断言与deadline未改。

## 已有依据

- Draft C-AS-TRANSITION-0001-E：leaving全程保留当前view，closed/afterLeave之后才请求detached。
- Draft C-AS-TRANSITION-0001-B/K：isPresent不是实际mount/DOM/terminal disposed的真相；三个事实必须分离。
- Draft P-SHADCN-DIALOG-CONTENT-TRANSITION / P-BRUTALIST-DIALOG-CONTENT-TRANSITION：logical enter/leave配置200ms。family public边界是open/transitionState/isPresent，不把内部complete/afterLeave能力冒充支持API。
- 当前site-contents-panel.ts按public open=false及isPresent=false归还，避开关闭调用栈。原held-leave单测要求离场期间仍借出、归还先于renderer detach；它是现有实现证据，不自行升级为网站规范。
- #1191明确同节点handback及焦点/retirement是独立consumer欠项，未规定逻辑close后的第一次同步读取必须成功。最新讨论尚未作这个语义选择。

## 同次新取证（不是无扰动时钟）

在当前head另外跑一份两文件只读observer，保留原getter的短路顺序/次数/值及原count断言，原失败重抛；只有失败后追加500ms诊断观察。代码插桩可扰动时间，dirty=true如实记录；两原文件已finally逐字恢复。

同slot/generation1/Shadcn/WC：

| 浏览器performance.now，ms | 真实记录 |
| --- | --- |
| 3203.6 | public open true→false；tree不在home，仍connected |
| 3228.7 | 原finish读取open=false，present=true；tree仍借出 |
| 3237.0 | catch中写入“原count失败后已观察到verdict”marker，不是原count的精确时刻 |
| 3406.4 | public present true→false，同一回调中开始return；保留Content引用仍connected |
| 3481.3 | return完成，treeHome=true，tree/Content仍connected |
| 3739.1 | 失败后观察marker；500ms是诊断请求值，实际两marker间502.1ms |

这次支持“原即时读取发生于逻辑关闭与离场完成之间”，没有证明永久丢树，也没有证明所有family/runtime、fatal retirement或无扰动的真实耗时。74.9ms return区间包含原move lease/scroll工作和同步trace成本，不独立归因。

## 需要选择的最小契约

A（推荐）：正常close在public离场屏障完成后归还，且应在renderer移除借用槽位前完成；逻辑open=false时允许仍借出。保留离场内容，契合现有200ms语义和held-leave控制。原数值、焦点、same-node及归还断言保留；需要明确授权将原浏览器用例的“立即首读”前置阶段改为观察真实public完成边界，且不得扩大原close总deadline或添加固定sleep。不能称当前原用例已经通过。

B：逻辑close调用栈退出、焦点归还后就必须归还，在public isPresent仍true时允许将树搬回home。应据此最小修改consumer和held-leave预期，并用原立即首读断言验收；需要接受原Dialog离场期间导航内容已移走这一可见变化，不能只为测试绿而改动。

推荐A是建议，不是批准或已生效保证。两者都不把public false状态当作terminal teardown/focus release证明，fatal退出仍归共享owner闭包。维护者或当前用户明确选择前，不创建新规范实体、不改production、不放宽原assert/deadline。

## 后续实际决定

当前用户在本线程明确回复“A：离场完成后归还（推荐）”。本轮据此准备网站consumer draft及原fixture的前置阶段修正；数值/焦点/归还断言、1000ms总关闭预算与180s case deadline保留。上文未决定时的记录为历史，不回写为当时已经授权或通过。实现与验证另按实际源码回执记录。
