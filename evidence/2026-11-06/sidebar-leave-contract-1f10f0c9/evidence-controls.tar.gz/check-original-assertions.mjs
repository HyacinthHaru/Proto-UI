import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
const root='<SOURCE_ROOT>';
const require=createRequire(root+'/package.json'); const ts=require('typescript');
const p='apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts';
const before=execFileSync('git',['show','508e2d3b7dc397c06d843d61748aa7962fc67bb8:'+p],{cwd:root,encoding:'utf8'}),after=fs.readFileSync(root+'/'+p,'utf8');
const printer=ts.createPrinter();
function collect(source,select){const f=ts.createSourceFile(p,source,ts.ScriptTarget.Latest,true);const rows=[];function visit(n){if(ts.isCallExpression(n)&&select(n,f))rows.push(printer.printNode(ts.EmitHint.Unspecified,n,f));ts.forEachChild(n,visit)}visit(f);return rows}
const assertions=s=>collect(s,(n,f)=>ts.isPropertyAccessExpression(n.expression)&&/^to[A-Z]/.test(n.expression.name.text)&&n.getText(f).startsWith('expect'));
const native=s=>collect(s,(n,f)=>/^(page\.(keyboard|mouse)\.|command\.(click|focus)\()/ .test(n.getText(f)));
const a=assertions(before),b=assertions(after);let index=0;for(const x of b)if(x===a[index])index++;if(index!==a.length)throw Error('Original assertion changed or removed');
if(JSON.stringify(native(before))!==JSON.stringify(native(after)))throw Error('Original native input changed');
const diff=execFileSync('git',['diff','--unified=0','--',p],{cwd:root,encoding:'utf8'});if(diff.split('\n').some(x=>x.startsWith('-')&&!x.startsWith('---')))throw Error('Original source line removed');
const report={base:'508e2d3b7dc397c06d843d61748aa7962fc67bb8',originalAssertionCalls:a.length,allOriginalAssertionsInOrder:true,originalSelectedNativeInputCalls:native(before).length,nativeInputSequenceUnchanged:true,pureInsertion:true,case180sRetained:after.includes('180_000'),closeBudget:'1000ms after Escape returns, including original logical/focus and lease/return assertions; final hard elapsed assertion'};
fs.writeFileSync('<STATE_ROOT>/assertion-binding.json',JSON.stringify(report,null,2)+'\n');console.log(report);
