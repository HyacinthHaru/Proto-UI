from pathlib import Path
import subprocess,json,hashlib,os,datetime
root=Path('<SOURCE_ROOT>');s=Path(__file__).parent;out=s/'identity-replacement-control';out.mkdir(exist_ok=True);p=root/'apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts';original=p.read_bytes();assert hashlib.sha256(original).hexdigest()=='6456b32d61ebe3e3b96f9c02ff3bd1245e2b3248ab63d319cdc0c7aa48ecfb3d';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='508e2d3b7dc397c06d843d61748aa7962fc67bb8'
t=original.decode();start=t.index("  it('uses real family Contents Buttons");end=t.index("  it('uses the same mobile shell",start);part=t[start:end];anchor="            await page.keyboard.press('Escape');";assert part.count(anchor)==1
injection='''            await page.evaluate(() => {
              const state = window as typeof window & { __contentsOriginalTree?: Element; __contentsReplacementControl?: unknown };
              const original = state.__contentsOriginalTree!;
              const observer = new MutationObserver(() => {
                if (original.hasAttribute('data-site-contents-dialog-tree')) return;
                observer.disconnect();
                const replacement = document.createElement('nav');
                replacement.className = 'docs-sidebar';
                original.replaceWith(replacement);
                state.__contentsReplacementControl = { at: performance.now(), originalConnected: original.isConnected, replaced: true };
              });
              observer.observe(original, { attributes: true, attributeFilter: ['data-site-contents-dialog-tree'] });
            });
''';part=part.replace(anchor,injection+anchor)
anchor='''      } finally {
        await context.close();
      }''';assert part.count(anchor)==1
catch='''      } catch (error) {
        const facts = await page.evaluate(() => {
          const state = window as typeof window & { __contentsOriginalTree?: Element; __contentsReplacementControl?: unknown };
          const current = document.querySelector('nav.docs-sidebar');
          return { mutation: state.__contentsReplacementControl,
            originalConnected: state.__contentsOriginalTree?.isConnected,
            originalIsCurrent: state.__contentsOriginalTree === current,
            oldMarkerPredicate: !!current && !current.hasAttribute('data-site-contents-dialog-tree'),
            oldHomeCount: document.querySelectorAll('.docs-shell nav.docs-sidebar').length,
            oldMarkerNull: current?.getAttribute('data-site-contents-dialog-tree') === null };
        });
        await writeFile(path.join(directory, 'identity-control.json'), JSON.stringify({ source, facts, error: String(error), intentionalDOMReplacement: true, originalBudgetMs: 1000 }, null, 2));
        await page.screenshot({ path: path.join(directory, 'identity-control-after-verdict.png') });
        throw error;
      } finally {
        await context.close();
      }''';part=part.replace(anchor,catch);modified=(t[:start]+part+t[end:]).encode();(out/'executed-test.ts').write_bytes(modified)
env=os.environ.copy();env['PATH']='<TASK_STATE_ROOT>/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:/opt/homebrew/bin:'+env['PATH'];env['CHROME_PATH']='<TASK_STATE_ROOT>/proto-ui-883/continue-20261023T123632Z/browser-source/cache/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing';env.update(PROTO_UI_DIALOG_INTEGRITY_PATH=str(out/'runner-integrity.json'),PROTO_UI_DIALOG_JSON_PATH=str(out/'vitest.json'),CANDIDATE_SHA='508e2d3b7dc397c06d843d61748aa7962fc67bb8',PROTO_UI_RUNTIME_EVIDENCE_DIR=str(out))
args=['corepack','pnpm@10.32.1','exec','vitest','run','--no-file-parallelism','apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts','-t','uses real family Contents Buttons','--reporter=./scripts/test/dialog-run-integrity-reporter.mjs','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')];r={'head':'508e2d3b7dc397c06d843d61748aa7962fc67bb8','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidateTestSha256':hashlib.sha256(original).hexdigest(),'executedTestSha256':hashlib.sha256(modified).hexdigest(),'kind':'Private negative control: real normal-close callback first restores the original tree, then a test-only DOM MutationObserver replaces it with an empty native nav. No synthetic keyboard event or production/private state injection. Retain every assertion/deadline; log and rethrow the original rejection. This is not a product defect or a full old-case false pass.','command':args};(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
try:
 p.write_bytes(modified)
 with (out/'browser.log').open('w') as log:
  try:result=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450);r['exitCode']=result.returncode
  except subprocess.TimeoutExpired:r['outerTimeout']=True
finally:
 assert p.read_bytes()==modified;p.write_bytes(original);r['restoredExactCandidate']=p.read_bytes()==original;r['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
