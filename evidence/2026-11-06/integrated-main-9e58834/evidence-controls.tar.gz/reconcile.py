from pathlib import Path
import json,hashlib,subprocess,math,datetime
s=Path(__file__).parent;root=Path('<SOURCE_ROOT>');h='9e58834d167618216ed9b39278eb8dded2f2f596';sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==h and not git('status','--porcelain')
r={'head':h,'tree':git('rev-parse','HEAD^{tree}'),'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceChangedThisRound':False,'products':{},'native':{},'sourceFiles':[]}
for mode in ['source','packed']:
 p=s/f'products-main-9e58834/{mode}-continuous/result.json';j=json.loads(p.read_text());assert j['source']['revision']==h and j['execution']=='passed' and not j['errors'];assert len(j['results'])==42
 blur=[x for x in j['results'] if x.get('flow')=='focus second page'];assert len(blur)==8 and all(x['error'] is None for x in blur)
 dispose=next(x['state'] for x in j['results'] if x['flow']=='dispose');assert all(dispose['metrics'][k]==0 for k in ['contexts','consumers','pendingImages','decodedImages'])
 geo=next(x for x in j['results'] if x['flow']=='resize invalidates pending old decode and recovers new geometry');assert len(geo['after'])==4
 for row in geo['after']:
  pad=math.ceil(max(row['width'],row['height'])*.08+1);assert row['paintWidth']==row['width']+2*pad and row['paintHeight']==row['height']+2*pad
 o=json.loads((s/f'products-main-9e58834/{mode}-ordinary/result.json').read_text());assert o['revision']==h and not o['failure']
 r['products'][mode]={'resultSha256':sha(p.read_bytes()),'flowRecords':42,'blurArms':8,'resizeRows':geo['after'],'dispose':dispose,'browser':j['browser'],'video':next(x['video'] for x in j['results'] if x['flow']=='actual browser screencast'),'ordinaryThemes':[x['theme'] for x in o['observations']]}
for key,dirname,expected,skips in [('dialog','dialog-main-9e58834',8,0),('sidebar','sidebar-main-9e58834',0,8)]:
 d=s/dirname;j=json.loads((d/'vitest.json').read_text());i=json.loads((d/'runner-integrity.json').read_text());assert i['phase']=='process-exit' and i['closeFinished'] and not i['runnerErrors'] and not i['unhandledErrors'] and not i['processTimedOut'];assert i['reportSha256']==sha((d/'vitest.json').read_bytes());assert j['numPassedTests']==expected
 r['native'][key]={'passed':j['numPassedTests'],'failed':j['numFailedTests'],'pending':j['numPendingTests'],'reportSha256':i['reportSha256'],'runnerClean':True}
 if key=='dialog':
  o=json.loads((d/'dialog-available-space/observations.json').read_text());assert o['sourceSha']==h;r['native'][key].update(observationRows=len(o['observations']),pngFiles=len(list(d.rglob('*.png'))),browser=o['browser'])
 else:
  a=[a for f in j['testResults'] for a in f['assertionResults'] if a['status']=='failed'];assert len(a)==1 and 'expected +0 to be 1' in a[0]['failureMessages'][0];r['native'][key].update(failure='Original immediate sidebar count 0 != 1 at homepage-dogfood.browser.test.ts:954, after logical-close poll and focus check; not an elapsed-1s return failure',pngFiles=len(list(d.rglob('*.png'))))
paths=['experiments/material-v2/build-browser.mjs','experiments/material-v2/browser.test.mjs','experiments/material-v2/continuous-browser.test.mjs','experiments/material-v2/resize-geometry.ts','experiments/material-v2/resize-geometry.test.ts','packages/prototypes/shadcn/src/dialog/content.proto.ts','apps/www/src/content/docs/zh-cn/dialog-available-space.browser.test.ts','apps/www/src/content/docs/zh-cn/browser-harness.ts','scripts/test/server-readiness.mjs','scripts/test/dialog-run-integrity-reporter.mjs','scripts/test/check-dialog-baseline-evidence.mjs','scripts/test/check-dialog-baseline-evidence.test.mjs','apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts','apps/www/src/components/site-contents-panel.ts','pnpm-lock.yaml','package.json']
for p in paths:
 b=(root/p).read_bytes();orig=subprocess.check_output(['git','show',h+':'+p],cwd=root);assert b==orig;r['sourceFiles'].append({'path':p,'blob':git('rev-parse',h+':'+p),'sha256':sha(b)})
r['remaining']=['Independent current closure calibration; historical accepted table unchanged','Sidebar immediate logical-close first read versus public leave/presence barrier semantic decision','Hosted full CI and broader install/optical/performance/GPUI acceptance remain outside this local pass']
r['limitations']=['Local Node24.21/Chrome155/macOS arm64; not hosted CI','Packed uses emitted public packages plus explicit private Liquid source, not installed public Liquid package','Screencast JPEGs retained; encoded:false due odd-height 1300x813, two zero-byte MP4 placeholders, no playable video/performance claim','No new fixed-baseline run today; prior matched local aab pair remains dated Nov5','Five selected main product/Dialog/sidebar PNGs viewed; remaining PNGs retained/hash verified, not all visually reviewed']
(s/'validation-report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k in ['head','native']}))
