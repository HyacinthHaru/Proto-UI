from pathlib import Path
import subprocess,json,hashlib,os,datetime
root=Path('<SOURCE_ROOT>');s=Path(__file__).parent;out=s/'marker-order-control';out.mkdir(exist_ok=True);paths=['apps/www/src/components/site-contents-panel.ts','apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts'];original={p:(root/p).read_bytes() for p in paths};assert hashlib.sha256(original[paths[1]]).hexdigest()=='8a5db042fcaee8550630c755fdc72583c8bc5645cc5418eccc416523b5453e8e';head='e8ae5f4bc6e744196e48ed5bf0b740246578dc93';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
controller=original[paths[0]].decode();a="""      home.insertBefore(tree, nextSibling?.parentNode === home ? nextSibling : null);
      tree.removeAttribute('data-site-contents-dialog-tree');""";b="""      tree.removeAttribute('data-site-contents-dialog-tree');
      home.insertBefore(tree, nextSibling?.parentNode === home ? nextSibling : null);""";assert controller.count(a)==1;controller=controller.replace(a,b)
test=original[paths[1]].decode();start=test.index("  it('uses real family Contents Buttons");end=test.index("  it('uses the same mobile shell",start);part=test[start:end];a="""      } catch (originalError) {
        try {
          await saveCloseEvidence();""";assert part.count(a)==1;b="""      } catch (originalError) {
        try {
          const facts = await page.evaluate(() => {
            const state = window as typeof window & { __contentsOriginalTree?: Element; __contentsOriginalParent?: Node | null; __contentsOriginalNextSibling?: Node | null };
            const current = document.querySelector('nav.docs-sidebar');
            return { originalConnected: state.__contentsOriginalTree?.isConnected,
              originalIsCurrent: state.__contentsOriginalTree === current,
              homeCount: document.querySelectorAll('.docs-shell nav.docs-sidebar').length,
              markerNull: current?.getAttribute('data-site-contents-dialog-tree') === null,
              parentMatches: state.__contentsOriginalTree?.parentNode === state.__contentsOriginalParent,
              siblingMatches: state.__contentsOriginalTree?.nextSibling === state.__contentsOriginalNextSibling };
          });
          await writeFile(path.join(directory, 'order-control-final-facts.json'), JSON.stringify({ source, facts, originalError: String(originalError), sameTurnReversedDOMOperations: true }, null, 2));
          await page.screenshot({ path: path.join(directory, 'order-control-after-verdict.png') });
          await saveCloseEvidence();""";part=part.replace(a,b);test=test[:start]+part+test[end:];modified={paths[0]:controller.encode(),paths[1]:test.encode()}
for p,b in modified.items():(out/(Path(p).name+'.txt')).write_bytes(b)
env=os.environ.copy();env['PATH']='<TASK_STATE_ROOT>/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:/opt/homebrew/bin:'+env['PATH'];env['CHROME_PATH']='<TASK_STATE_ROOT>/proto-ui-883/continue-20261023T123632Z/browser-source/cache/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing';env.update(PROTO_UI_DIALOG_INTEGRITY_PATH=str(out/'runner-integrity.json'),PROTO_UI_DIALOG_JSON_PATH=str(out/'vitest.json'),CANDIDATE_SHA=head,PROTO_UI_RUNTIME_EVIDENCE_DIR=str(out))
args=['corepack','pnpm@10.32.1','exec','vitest','run','--no-file-parallelism',paths[1],'-t','uses real family Contents Buttons','--reporter=./scripts/test/dialog-run-integrity-reporter.mjs','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')];r={'head':head,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'Private negative: only swap marker removal and home insertion inside the existing synchronous withNativeContentLease callback. Final original identity/home/parent/sibling remain correct. Test private catch records actual final facts and rethrows original order failure; no synthetic input or business state injection.','bindings':{p:{'originalSha256':hashlib.sha256(original[p]).hexdigest(),'executedSha256':hashlib.sha256(modified[p]).hexdigest()} for p in paths},'command':args};(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
try:
 for p,b in modified.items():(root/p).write_bytes(b)
 with (out/'browser.log').open('w') as log:
  try:result=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450);r['exitCode']=result.returncode
  except subprocess.TimeoutExpired:r['outerTimeout']=True
finally:
 for p,b in original.items():assert (root/p).read_bytes()==modified[p];(root/p).write_bytes(b)
 r['restoredExactCandidate']=all((root/p).read_bytes()==b for p,b in original.items());r['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
