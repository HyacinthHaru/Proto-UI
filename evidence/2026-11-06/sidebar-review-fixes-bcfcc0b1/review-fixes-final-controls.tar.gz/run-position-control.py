from pathlib import Path
import subprocess,json,hashlib,os,datetime,sys
kind=sys.argv[1];assert kind in ['parent','sibling'];root=Path('<SOURCE_ROOT>');s=Path(__file__).parent;out=s/('position-'+kind+'-control');out.mkdir(exist_ok=True);p=root/'apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts';original=p.read_bytes();assert hashlib.sha256(original).hexdigest()=='67345619b7684536a3b506ba4ab8394b64b3f9b282ec7d24142bfa62d3bcfdba';head='1f10f0c9bc76d6d305c43ccbe04c9065f982bf1d';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
t=original.decode();start=t.index("  it('uses real family Contents Buttons");end=t.index("  it('uses the same mobile shell",start);part=t[start:end];anchor="            await page.keyboard.press('Escape');";assert part.count(anchor)==1
injection='''            await page.evaluate((kind) => {
              const state = window as typeof window & { __contentsOriginalTree?: Element; __contentsOriginalParent?: Node | null; __contentsOriginalNextSibling?: Node | null; __contentsPositionControl?: unknown };
              const original = state.__contentsOriginalTree!;
              const parent = state.__contentsOriginalParent!;
              const sibling = state.__contentsOriginalNextSibling;
              const observer = new MutationObserver(() => {
                if (original.hasAttribute('data-site-contents-dialog-tree')) return;
                observer.disconnect();
                const before = { parentMatches: original.parentNode === parent, siblingMatches: original.nextSibling === sibling };
                if (kind === 'parent') {
                  const wrapper = document.createElement('div');
                  parent.appendChild(wrapper);
                  wrapper.appendChild(original);
                  if (sibling) wrapper.appendChild(sibling);
                } else if (sibling) parent.appendChild(original);
                else parent.appendChild(document.createTextNode('position-control'));
                state.__contentsPositionControl = { kind, at: performance.now(), before,
                  after: { parentMatches: original.parentNode === parent, siblingMatches: original.nextSibling === sibling } };
              });
              observer.observe(original, { attributes: true, attributeFilter: ['data-site-contents-dialog-tree'] });
            }, 'CONTROL_KIND');
'''.replace('CONTROL_KIND',kind);part=part.replace(anchor,injection+anchor);anchor='''      } finally {
        await context.close();
      }''';assert part.count(anchor)==1
catch='''      } catch (error) {
        const facts = await page.evaluate(() => {
          const state = window as typeof window & { __contentsOriginalTree?: Element; __contentsOriginalParent?: Node | null; __contentsOriginalNextSibling?: Node | null; __contentsPositionControl?: unknown };
          const current = document.querySelector('nav.docs-sidebar');
          return { mutation: state.__contentsPositionControl, originalConnected: state.__contentsOriginalTree?.isConnected,
            originalIsCurrent: state.__contentsOriginalTree === current,
            oldMarkerPredicate: !!current && !current.hasAttribute('data-site-contents-dialog-tree'),
            oldHomeCount: document.querySelectorAll('.docs-shell nav.docs-sidebar').length,
            oldMarkerNull: current?.getAttribute('data-site-contents-dialog-tree') === null,
            parentMatches: state.__contentsOriginalTree?.parentNode === state.__contentsOriginalParent,
            siblingMatches: state.__contentsOriginalTree?.nextSibling === state.__contentsOriginalNextSibling };
        });
        await writeFile(path.join(directory, 'position-control.json'), JSON.stringify({ source, facts, error: String(error), intentionalDOMMove: true, originalBudgetMs: 1000 }, null, 2));
        await page.screenshot({ path: path.join(directory, 'position-control-after-verdict.png') });
        throw error;
      } finally {
        await context.close();
      }''';part=part.replace(anchor,catch);modified=(t[:start]+part+t[end:]).encode();(out/'executed-test.ts').write_bytes(modified)
env=os.environ.copy();env['PATH']='<TASK_STATE_ROOT>/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:/opt/homebrew/bin:'+env['PATH'];env['CHROME_PATH']='<TASK_STATE_ROOT>/proto-ui-883/continue-20261023T123632Z/browser-source/cache/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing';env.update(PROTO_UI_DIALOG_INTEGRITY_PATH=str(out/'runner-integrity.json'),PROTO_UI_DIALOG_JSON_PATH=str(out/'vitest.json'),CANDIDATE_SHA=head,PROTO_UI_RUNTIME_EVIDENCE_DIR=str(out))
args=['corepack','pnpm@10.32.1','exec','vitest','run','--no-file-parallelism','apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts','-t','uses real family Contents Buttons','--reporter=./scripts/test/dialog-run-integrity-reporter.mjs','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')];r={'head':head,'kind':kind,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidateTestSha256':hashlib.sha256(original).hexdigest(),'executedTestSha256':hashlib.sha256(modified).hexdigest(),'control':'After real normalrestore, test-only MutationObserver changes only intended positional relation; original identity/current/marker/homecount remain. No production mutation/private state/synthetic input. Original failed assertion is rethrown.','command':args};(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
try:
 p.write_bytes(modified)
 with (out/'browser.log').open('w') as log:
  try:result=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450);r['exitCode']=result.returncode
  except subprocess.TimeoutExpired:r['outerTimeout']=True
finally:
 assert p.read_bytes()==modified;p.write_bytes(original);r['restoredExactCandidate']=p.read_bytes()==original;r['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
