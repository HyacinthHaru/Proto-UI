// @vitest-environment node
import { revealHeaderPreferences } from './site-header-browser';
import {
  prepareUtilityFamilyReadObservation,
  settleFamilyQueryBatch,
} from './family-query-observer';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { installDocsCallTimingObserver } from './docs-query-timing.mjs';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {
  captureHeaderPreferenceLease,
  inspectHeaderPreferenceLease,
  headerPreferenceLeaseIssues,
  measureHeaderPreferenceFocusRing,
} from './site-header-breakpoint-evidence';
import type { Browser, ElementHandle, JSHandle, Page } from 'playwright-core';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { launchBrowser, RUNTIMES, startServer, stopServer } from './browser-harness';
const LABELS = { wc: 'Web Components', react: 'React', vue: 'Vue', vue2: 'Vue 2' } as const;
const familyQueryMode = process.env.PROTO_UI_FAMILY_QUERY_MODE ?? 'hybrid';
if (!['hybrid', 'native-only', 'node-only'].includes(familyQueryMode))
  throw new Error('Unknown family query observation mode');
let browser: Browser;
let baseUrl: string;
beforeAll(async () => {
  baseUrl = await startServer('/zh-cn/');
  browser = await launchBrowser();
}, 150_000);
afterAll(async () => {
  await browser?.close();
  await stopServer();
}, 60_000);
async function ready(page: Page, runtime: string) {
  await page.waitForFunction(
    (target) => {
      const page = document.querySelector<HTMLElement>('[data-homepage-runtime]');
      const demo = document.querySelector<HTMLElement>('[data-home-showcase]');
      return (
        page?.dataset.runtimeState === 'ready' &&
        page.dataset.runtime === target &&
        demo?.dataset.runnerState === 'ready' &&
        demo.dataset.runnerRuntime === target
      );
    },
    runtime,
    { timeout: 30_000 }
  );
}
async function switchRuntime(page: Page, runtime: keyof typeof LABELS) {
  await revealHeaderPreferences(page);
  const trigger = page.locator(
    '[data-homepage-runtime] [data-projection-control="runtime"] [role="combobox"]'
  );
  await trigger.click();
  const id = await trigger.getAttribute('aria-controls');
  expect(id).toBeTruthy();
  await page
    .locator(`[id=${JSON.stringify(id)}]`)
    .getByRole('option', { name: LABELS[runtime], exact: true })
    .click();
  await ready(page, runtime);
}

describe.sequential('Homepage end-to-end dogfood boundary', () => {
  it('switches every registered homepage group through real adapters, preserving native anchors and theme', async () => {
    const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
    const page = await context.newPage();
    const errors: string[] = [];
    page.on('pageerror', (error) => errors.push(error.message));
    try {
      await page.goto(`${baseUrl}/zh-cn/`, { waitUntil: 'networkidle' });
      await ready(page, 'wc');
      const fallbackLinks = await page.locator('[data-homepage-fallback] a').evaluateAll((links) =>
        links.map((link) => ({
          href: link.getAttribute('href'),
          text: link.textContent?.trim(),
          target: link.getAttribute('target'),
        }))
      );
      expect(fallbackLinks.length).toBeGreaterThan(5);
      expect(
        await page.locator('[data-home-showcase] [data-projection-control="runtime"]').count()
      ).toBe(0);
      for (const runtime of [...RUNTIMES, 'react', 'wc'] as const) {
        await switchRuntime(page, runtime);
        const groups = await page.locator('[data-homepage-actions]').evaluateAll((roots) =>
          roots.map((root) => {
            const active = root.querySelectorAll<HTMLElement>(
              '[data-projection-generation-state="active"]'
            );
            const surfaces = [
              ...(active[0]?.querySelectorAll<HTMLElement>('[data-projection-prototype]') ?? []),
            ];
            return {
              activeCount: active.length,
              runtime:
                active[0]?.querySelector<HTMLElement>('[data-projection-scope]')?.dataset
                  .projectionRuntime,
              surfaces: surfaces.length,
              fallbackHidden: root.querySelector<HTMLElement>('[data-homepage-fallback]')?.hidden,
            };
          })
        );
        expect(groups.length).toBeGreaterThanOrEqual(3);
        for (const group of groups) {
          expect(group.activeCount).toBe(1);
          expect(group.runtime).toBe(runtime);

          expect(group.fallbackHidden).toBe(true);
        }
        const anchors = await page
          .locator('[data-homepage-mount] [data-projection-generation-state="active"] a')
          .evaluateAll((links) =>
            links.map((link) => ({
              href: link.getAttribute('href'),
              text: link.textContent?.trim(),
              target: link.getAttribute('target'),
            }))
          );
        expect(anchors).toEqual(fallbackLinks);
        expect(
          await page
            .locator(
              '[data-homepage-runtime] [data-projection-control="runtime"] [role="combobox"]'
            )
            .evaluate((element) => document.activeElement === element)
        ).toBe(true);
        const accessibleTheme = page
          .locator('[data-homepage-runtime]')
          .getByRole('button', { name: '切换主题', exact: true });
        expect(await accessibleTheme.count()).toBe(1);
        expect(await accessibleTheme.getAttribute('title')).toBe('切换主题');
        await accessibleTheme.hover();
        expect(await accessibleTheme.count(), 'name survives hover feedback').toBe(1);
        const themeBefore = await page.locator('html').getAttribute('data-theme');
        await page
          .locator(
            '[data-homepage-runtime] [data-projection-generation-state="active"] [data-demo-ref="home-theme"]'
          )
          .click();
        await expect
          .poll(() => page.locator('html').getAttribute('data-theme'))
          .toBe(themeBefore === 'dark' ? 'light' : 'dark');
        expect(await page.evaluate(() => localStorage.getItem('starlight-theme'))).toBe(
          themeBefore === 'dark' ? 'light' : 'dark'
        );
        const trigger = page.locator(
          '[data-homepage-runtime] [data-projection-control="runtime"] [role="combobox"]'
        );
        await revealHeaderPreferences(page);
        await trigger.focus();
        await page.keyboard.press('Enter');
        const keyboardPortalId = await trigger.getAttribute('aria-controls');
        const keyboardPortal = page.locator(`[id=${JSON.stringify(keyboardPortalId)}]`);
        await keyboardPortal.waitFor({ state: 'visible' });
        // Select enters the selected item after its deferred overlay-ready step.
        // Escape must test an entered popup, not race that entry callback.
        await expect
          .poll(
            () =>
              keyboardPortal
                .getByRole('option')
                .evaluateAll((items) => items.some((item) => item === document.activeElement)),
            { timeout: 10_000 }
          )
          .toBe(true);
        await page.keyboard.press('Escape');
        await keyboardPortal.waitFor({ state: 'hidden' });
        await expect
          .poll(() => trigger.evaluate((element) => document.activeElement === element), {
            timeout: 10_000,
          })
          .toBe(true);
      }
      const chooseDemo = async (control: 'family', label: string) => {
        const trigger = page.locator(
          `[data-homepage-runtime] [data-projection-generation-state="active"] [data-projection-control="${control}"] [role="combobox"]`
        );
        await trigger.click();
        const id = await trigger.getAttribute('aria-controls');
        await page
          .locator(`[id=${JSON.stringify(id)}]`)
          .getByRole('option', { name: label, exact: true })
          .click();
      };
      for (const family of ['brutalist', 'shadcn'] as const) {
        await chooseDemo('family', family === 'brutalist' ? 'Brutalist' : 'Shadcn');
        await page.waitForFunction(
          (target) =>
            document.querySelector<HTMLElement>('[data-homepage-runtime]')?.dataset.family ===
            target,
          family
        );
        for (const runtime of RUNTIMES) {
          await switchRuntime(page, runtime);
          const coordinates = await page.evaluate(() => {
            const root = document.querySelector<HTMLElement>('[data-homepage-runtime]')!;
            const demo = document.querySelector<HTMLElement>('[data-home-showcase]')!;
            const scopes = [
              ...document.querySelectorAll<HTMLElement>(
                '[data-homepage-mount] [data-projection-generation-state="active"] [data-projection-scope], [data-home-demo-host] [data-projection-generation-state="active"] [data-projection-scope]'
              ),
            ];
            return {
              family: root.dataset.family,
              component: demo.dataset.projectionComponent,
              pageGeneration: root.dataset.runtimeGeneration,
              demoGeneration: demo.dataset.projectionGeneration,
              scopes: scopes.map((scope) => ({
                runtime: scope.dataset.projectionRuntime,
                family: scope.dataset.projectionFamily,
                generation: scope.dataset.projectionGeneration,
              })),
            };
          });
          const accessibleTheme = page
            .locator('[data-homepage-runtime]')
            .getByRole('button', { name: '切换主题', exact: true });
          expect(await accessibleTheme.count(), `${family}/${runtime} icon accessible name`).toBe(
            1
          );
          expect(await accessibleTheme.getAttribute('title')).toBe('切换主题');
          expect(coordinates.family).toBe(family);
          expect(coordinates.component).toBe('website-component-gallery');
          expect(coordinates.demoGeneration).toBe(coordinates.pageGeneration);
          expect(
            await page.locator('[data-home-showcase] [data-projection-control="component"]').count()
          ).toBe(0);
          expect(await page.locator('[data-home-settings]').count()).toBe(1);
          for (const scope of coordinates.scopes) {
            expect(scope.runtime).toBe(runtime);
            expect(scope.family).toBe(family);
            expect(scope.generation).toBe(coordinates.pageGeneration);
          }
        }
      }
      expect(errors).toEqual([]);
      const link = page
        .locator(
          '#home-navigation-desktop [data-homepage-mount] [data-projection-generation-state="active"] a'
        )
        .filter({ hasText: '文档' });
      expect(await link.count()).toBe(1);
      expect(await link.isVisible()).toBe(true);
      const destination = await link.getAttribute('href');
      const opened = context.waitForEvent('page');
      await link.click({ modifiers: ['ControlOrMeta'] });
      const newPage = await opened;
      await newPage.waitForURL(`**${destination}`);
      await newPage.close();
      expect(new URL(page.url()).pathname).toBe('/zh-cn/');
    } finally {
      await context.close();
    }
  }, 240_000);

  it('keeps native navigation available without JavaScript and does not overflow mobile', async () => {
    const noJs = await browser.newContext({
      javaScriptEnabled: false,
      viewport: { width: 390, height: 844 },
    });
    try {
      const page = await noJs.newPage();
      await page.goto(`${baseUrl}/zh-cn/`);
      const links = page.locator('[data-homepage-fallback] a');
      expect(await links.count()).toBeGreaterThan(5);
      expect(await links.first().isVisible()).toBe(true);
      const nativeMobileDocs = page
        .locator('#home-navigation-mobile [data-homepage-fallback] a')
        .filter({ hasText: '文档' });
      expect(await nativeMobileDocs.count()).toBe(1);
      expect(await nativeMobileDocs.isVisible()).toBe(false);
      const summary = page.locator('[data-site-header-fallback-summary]');
      expect(await summary.isVisible()).toBe(true);
      await summary.click();
      expect(await nativeMobileDocs.isVisible()).toBe(true);
      expect(
        await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)
      ).toBe(true);
      expect(await nativeMobileDocs.getAttribute('href')).toBe('/zh-cn/start-here/what-you-saw/');
      await nativeMobileDocs.click();
      await page.waitForURL('**/zh-cn/start-here/what-you-saw/');
    } finally {
      await noJs.close();
    }
    const context = await browser.newContext({ viewport: { width: 320, height: 844 } });
    try {
      const page = await context.newPage();
      await page.goto(`${baseUrl}/zh-cn/`);
      await ready(page, 'wc');
      for (const width of [390, 430, 320]) {
        await page.setViewportSize({ width, height: 844 });
        const navigation = page.locator('[data-site-header-navigation]');
        const originalNavigation = await navigation.elementHandle();
        expect(
          await originalNavigation!.evaluate((node) => (node as HTMLElement).hidden),
          `${width}px navigation starts collapsed`
        ).toBe(true);
        await revealHeaderPreferences(page);
        expect(
          await originalNavigation!.evaluate(
            (node) => node === document.querySelector('[data-site-header-navigation]')
          )
        ).toBe(true);
        const geometry = await page.evaluate(() => {
          const header = document
            .querySelector<HTMLElement>('[data-homepage-runtime]')!
            .getBoundingClientRect();
          const navigation = document.querySelector<HTMLElement>('[data-site-header-navigation]')!;
          const controls = [
            ...document.querySelectorAll<HTMLElement>(
              '.site-header-search [data-open-modal], .site-header-theme [data-demo-ref="home-theme"], .site-header-menu [data-demo-ref="home-menu"]'
            ),
          ].filter(
            (element) =>
              element.closest('[data-projection-generation-state="active"]') ||
              element.hasAttribute('data-open-modal')
          );
          const controlBounds = controls.map((element) => element.getBoundingClientRect());
          const status = document
            .querySelector<HTMLElement>('[data-homepage-runtime-status]')!
            .getBoundingClientRect();
          const brand = document.querySelector<HTMLElement>(
            '[data-homepage-mount] [data-home-brand]'
          )!;
          return {
            width: header.width,
            navHidden: navigation.hidden,
            controls: controlBounds.map(({ x, y, width, height }) => ({ x, y, width, height })),
            height: header.height,
            headerBottom: header.bottom,
            panel: document
              .querySelector('[data-site-header-panel]')!
              .getBoundingClientRect()
              .toJSON(),
            menu: document
              .querySelector(
                '[data-projection-generation-state="active"] [data-demo-ref="home-menu"]'
              )!
              .getBoundingClientRect()
              .toJSON(),
            preferences: [
              ...document.querySelectorAll<HTMLElement>(
                '[data-homepage-runtime] [data-projection-generation-state="active"] [data-projection-control] [role="combobox"]'
              ),
            ].map((control) => {
              const bounds = control.getBoundingClientRect();
              const value = control.querySelector<HTMLElement>(
                '[data-projection-prototype$="-select-value"]'
              )!;
              return {
                x: bounds.x,
                y: bounds.y,
                width: bounds.width,
                height: bounds.height,
                bottom: bounds.bottom,
                fullValueVisible: value.scrollWidth <= value.clientWidth + 1,
              };
            }),
            statusArea: status.width * status.height,
            brandSize: getComputedStyle(brand).fontSize,
          };
        });
        expect(geometry.navHidden, `${width}px navigation is deliberately disclosed`).toBe(false);
        await originalNavigation!.dispose();
        expect(geometry.preferences).toHaveLength(3);
        // Author labels name each independent Select; selected text is its value,
        // not a replacement accessible name. Never let a duplicate locale row
        // satisfy the three-control geometry count.
        for (const [name, value] of [
          ['整页 Runtime', 'Web Components'],
          ['整页组件库', 'Shadcn'],
          ['语言', '简体中文'],
        ]) {
          const control = page.locator('[data-homepage-runtime]').getByRole('combobox', {
            name,
            exact: true,
          });
          expect(await control.count()).toBe(1);
          expect(await control.isVisible()).toBe(true);
          expect((await control.ariaSnapshot()).split('\n')[0]).toContain(`combobox "${name}"`);
          expect(
            (
              await control.locator('[data-projection-prototype$="-select-value"]').textContent()
            )?.trim()
          ).toBe(value);
          expect(await control.getAttribute('aria-expanded')).toBe('false');
        }
        for (const preference of geometry.preferences) {
          expect(preference.height).toBeGreaterThanOrEqual(44);
          expect(preference.width).toBeGreaterThanOrEqual(120);
          expect(preference.fullValueVisible).toBe(true);
          expect(preference.bottom).toBeLessThanOrEqual(geometry.panel.bottom + 1);
          expect(preference.y).toBeGreaterThanOrEqual(geometry.panel.top);
          expect(preference.y).toBeGreaterThan(
            geometry.controls[0]!.y + geometry.controls[0]!.height
          );
        }
        for (let index = 1; index < geometry.preferences.length; index++)
          expect(geometry.preferences[index]!.y).toBeGreaterThan(
            geometry.preferences[index - 1]!.bottom
          );
        expect(Math.abs(geometry.panel.top - geometry.headerBottom - 5)).toBeLessThanOrEqual(1);
        expect(Math.abs(geometry.panel.right - (width - 8))).toBeLessThanOrEqual(1);
        expect(geometry.height).toBeLessThanOrEqual(64);
        expect(geometry.controls).toHaveLength(3);
        for (const control of geometry.controls) {
          expect(control.width).toBeGreaterThanOrEqual(44);
          expect(control.height).toBeGreaterThanOrEqual(44);
          expect(control.y).toBe(geometry.controls[0]!.y);
        }
        expect(geometry.statusArea).toBeLessThanOrEqual(1);
        expect(geometry.brandSize).toBe('16px');
        await page.keyboard.press('Escape');
      }
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
        true
      );
      const menu = page.locator(
        '[data-projection-generation-state="active"] [data-demo-ref="home-menu"]'
      );
      await menu.click();
      expect(await menu.getAttribute('aria-expanded')).toBe('true');
      const disclosedDocs = page
        .locator('#home-navigation-mobile [data-homepage-mount] a')
        .filter({ hasText: '文档' });
      expect(await disclosedDocs.isVisible()).toBe(true);
      await switchRuntime(page, 'vue2');
      expect(
        await menu.getAttribute('aria-expanded'),
        'open application state survives runtime commit'
      ).toBe('true');
      expect(await disclosedDocs.isVisible()).toBe(true);
      await page.keyboard.press('Escape');
      expect(await menu.getAttribute('aria-expanded')).toBe('false');
      expect(await menu.evaluate((element) => document.activeElement === element)).toBe(true);
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
        true
      );
      // Runtime selection above commits Vue2. Family selection has its own
      // unchanged 1000ms transaction gate later in this suite. Exercise locale
      // as navigation, not merely another identically shaped combobox.
      await revealHeaderPreferences(page);
      const locale = page.locator('[data-homepage-runtime]').getByRole('combobox', {
        name: '语言',
        exact: true,
      });
      await locale.click();
      const localeList = await locale.getAttribute('aria-controls');
      expect(localeList).toBeTruthy();
      const options = page.locator(`[id=${JSON.stringify(localeList)}]`);
      expect(
        await options
          .getByRole('option', { name: '简体中文', exact: true })
          .getAttribute('aria-selected')
      ).toBe('true');
      await Promise.all([
        page.waitForURL(`${baseUrl}/en/`, { timeout: 10_000 }),
        options.getByRole('option', { name: 'English', exact: true }).click(),
      ]);
      expect(new URL(page.url()).origin).toBe(new URL(baseUrl).origin);
      await ready(page, 'vue2');
      await revealHeaderPreferences(page);
      const english = page.locator('[data-homepage-runtime]').getByRole('combobox', {
        name: 'Language',
        exact: true,
      });
      expect(await english.count()).toBe(1);
      expect(
        (
          await english.locator('[data-projection-prototype$="-select-value"]').textContent()
        )?.trim()
      ).toBe('English');
      expect(await page.evaluate(() => localStorage.getItem('preferred-locale'))).toBe('en');
    } finally {
      await context.close();
    }
  }, 90_000);
  it('retains saved React across cold library routes and exercises actual family chrome', async () => {
    const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
    const page = await context.newPage();
    try {
      await page.goto(`${baseUrl}/zh-cn/`, { waitUntil: 'networkidle' });
      await ready(page, 'wc');
      await switchRuntime(page, 'react');
      expect(await page.evaluate(() => localStorage.getItem('preferred-prototypes-adapter'))).toBe(
        'react'
      );
      for (const route of [
        {
          path: '/zh-cn/ui-libraries/brutalist/components/tooltip/',
          family: 'brutalist',
          component: 'tooltip',
        },
        {
          path: '/zh-cn/ui-libraries/shadcn/radio-group/',
          family: 'shadcn',
          component: 'radio-group',
        },
      ]) {
        await page.goto(`${baseUrl}${route.path}`, { waitUntil: 'networkidle' });
        const preview = page
          .locator('[data-previewer-id][data-projection-mode="fixed-family"]')
          .first();
        await preview.scrollIntoViewIfNeeded();
        const scope = preview.locator(
          '[data-projection-generation-state="active"] [data-projection-scope]'
        );
        await expect.poll(() => scope.getAttribute('data-projection-runtime')).toBe('react');
        expect(await page.locator('html').getAttribute('data-site-library-family')).toBe(
          route.family
        );
        expect(await preview.getAttribute('data-projection-family')).toBe(route.family);
        expect(await preview.getAttribute('data-projection-component')).toBe(route.component);
        const adapter = page.locator('header [data-adapter-select-root]').first();
        const language = page.locator('header [data-language-select-root]').first();
        const theme = page.locator('header [data-theme-toggle]').first();
        for (const control of [adapter, language]) {
          expect(await control.evaluate((element) => element.localName)).toBe(
            `wc-${route.family}-select-root`
          );
          expect(await control.getAttribute('data-pui-root')).not.toBeNull();
        }
        expect(await theme.evaluate((element) => element.localName)).toBe(
          `wc-${route.family}-button`
        );
        const chooseAdapter = async (value: 'vue' | 'react') => {
          await revealHeaderPreferences(page);
          const trigger = adapter.locator('[role="combobox"]');
          await trigger.click();
          const id = await trigger.getAttribute('aria-controls');
          expect(id).toBeTruthy();
          const portal = page.locator(`[id=${JSON.stringify(id)}]`);
          await portal.waitFor({ state: 'visible' });
          expect(await portal.getAttribute('data-site-control-family')).toBe(route.family);
          expect(await portal.getAttribute('data-pui-root')).not.toBeNull();
          await portal
            .getByRole('option', { name: value === 'vue' ? 'Vue' : 'React', exact: true })
            .click();
          await expect.poll(() => scope.getAttribute('data-projection-runtime')).toBe(value);
        };
        await chooseAdapter('vue');
        await chooseAdapter('react');
        const menu = page.locator('header [data-site-menu-button]');
        await menu.click();
        expect(await menu.getAttribute('aria-expanded')).toBe('true');
        const languageTrigger = language.locator('[role="combobox"]');
        await languageTrigger.click();
        const languagePortalId = await languageTrigger.getAttribute('aria-controls');
        const languagePortal = page.locator(`[id=${JSON.stringify(languagePortalId)}]`);
        await languagePortal.waitFor({ state: 'visible' });
        expect(await languagePortal.getAttribute('data-site-control-family')).toBe(route.family);
        await languagePortal.getByRole('option').first().waitFor({ state: 'visible' });
        expect(await languagePortal.getByRole('option').count()).toBeGreaterThan(1);
        await page.keyboard.press('Escape');
        await languagePortal.waitFor({ state: 'hidden' });
        const beforeTheme = await page.locator('html').getAttribute('data-theme');
        await page.evaluate(() => {
          const state = window as typeof window & { __siteThemeChanges?: number };
          state.__siteThemeChanges = 0;
          document.addEventListener('starlight-theme:change', () => {
            state.__siteThemeChanges = (state.__siteThemeChanges ?? 0) + 1;
          });
        });
        await theme.click();
        await expect
          .poll(() => page.locator('html').getAttribute('data-theme'))
          .toBe(beforeTheme === 'dark' ? 'light' : 'dark');
        expect(
          await page.evaluate(
            () => (window as typeof window & { __siteThemeChanges?: number }).__siteThemeChanges
          )
        ).toBe(1);
        expect(
          await page.evaluate(() => localStorage.getItem('preferred-prototypes-adapter'))
        ).toBe('react');
        expect(await preview.getAttribute('data-projection-family')).toBe(route.family);
        expect(await preview.getAttribute('data-projection-component')).toBe(route.component);
      }
    } finally {
      await context.close();
    }
  }, 180_000);
  it('uses real family Contents Buttons through all four Docs runtimes with keyboard and exact-source visual evidence', async () => {
    const directory = path.join(
      process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR ??
        path.join(process.env.RUNNER_TEMP ?? os.tmpdir(), 'homepage-evidence'),
      'contents-command'
    );
    await mkdir(directory, { recursive: true });
    const source = {
      sha: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
      dirty: execFileSync('git', ['status', '--porcelain'], { encoding: 'utf8' }).trim() !== '',
      expectedSha: process.env.CANDIDATE_SHA ?? null,
      files: Object.fromEntries(
        [
          'components/SiteContentsCommand.astro',
          'components/site-contents-command.ts',
          'components/site-contents-panel.ts',
          'components/site-header-surface.ts',
          'components/site-header-disclosure.ts',
          'components/override/Sidebar.astro',
          'components/override/PageFrame.astro',
          'styles/site-contents-command.css',
        ].map((file) => [
          file,
          createHash('sha256')
            .update(readFileSync(`apps/www/src/${file}`))
            .digest('hex'),
        ])
      ),
    };
    for (const family of ['shadcn', 'brutalist'] as const) {
      const context = await browser.newContext({
        viewport: { width: 390, height: 844 },
        colorScheme: 'dark',
      });
      await context.route('**/*', (route) =>
        new URL(route.request().url()).origin === new URL(baseUrl).origin
          ? route.continue()
          : route.abort()
      );
      const page = await context.newPage();
      const pageErrors: string[] = [];
      page.on('pageerror', (error) => pageErrors.push(error.message));
      page.on('console', (message) => {
        if (message.type() === 'error') pageErrors.push(`console: ${message.text()}`);
      });
      await page.addInitScript(() => {
        const evidence = {
          longTasks: [] as Array<{ start: number; duration: number }>,
          changes: [] as Array<{ at: number; adapter: unknown }>,
        };
        Object.assign(window, { __contentsRuntimeEvidence: evidence });
        document.addEventListener('proto-adapter:change', (event) => {
          evidence.changes.push({
            at: performance.timeOrigin + performance.now(),
            adapter: (event as CustomEvent<{ adapter: unknown }>).detail?.adapter,
          });
        });
        if (PerformanceObserver.supportedEntryTypes.includes('longtask'))
          new PerformanceObserver((entries) => {
            evidence.longTasks.push(
              ...entries.getEntries().map((entry) => ({
                start: performance.timeOrigin + entry.startTime,
                duration: entry.duration,
              }))
            );
            evidence.longTasks.splice(0, Math.max(0, evidence.longTasks.length - 100));
          }).observe({ type: 'longtask', buffered: true });
      });
      try {
        const route =
          family === 'shadcn'
            ? '/zh-cn/ui-libraries/shadcn/button/'
            : '/zh-cn/ui-libraries/brutalist/components/button/';
        await page.goto(`${baseUrl}${route}`, { waitUntil: 'networkidle' });
        const root = page.locator('[data-site-contents-command]');
        const command = root.locator(
          '[data-projection-generation-state="active"] [data-site-contents-button]'
        );
        const menu = page.locator('[data-docs-site-header] [data-site-menu-button]');
        await page.evaluate(() =>
          Object.assign(window, {
            __contentsOriginalTree: document.querySelector('nav.docs-sidebar'),
            __contentsOriginalParent: document.querySelector('nav.docs-sidebar')?.parentNode,
            __contentsOriginalNextSibling: document.querySelector('nav.docs-sidebar')?.nextSibling,
            __contentsOriginalDetails: [...document.querySelectorAll('nav.docs-sidebar details')],
            __contentsOriginalCurrent: document.querySelector(
              'nav.docs-sidebar [aria-current="page"]'
            ),
          })
        );
        for (const runtime of RUNTIMES) {
          await revealHeaderPreferences(page);
          const select = page.locator('[data-adapter-select] [role="combobox"]');
          await select.click();
          const popup = await select.getAttribute('aria-controls');
          const transitionStartedAt = Date.now();
          await page
            .locator(`[id=${JSON.stringify(popup)}]`)
            .getByRole('option', { name: LABELS[runtime], exact: true })
            .click();
          const clickedAt = Date.now();
          let originalError: unknown;
          try {
            await expect.poll(() => root.getAttribute('data-contents-runtime')).toBe(runtime);
          } catch (error) {
            originalError = error;
          }
          const originalCheckAt = Date.now();
          const readTransition = () =>
            page.evaluate((since) => {
              const contents = document.querySelector<HTMLElement>('[data-site-contents-command]');
              const panel = document.querySelector<HTMLElement>('[data-site-header-panel]');
              const evidence = (
                window as typeof window & {
                  __contentsRuntimeEvidence?: {
                    longTasks: Array<{ start: number; duration: number }>;
                    changes: Array<{ at: number; adapter: unknown }>;
                  };
                }
              ).__contentsRuntimeEvidence;
              return {
                observedAt: performance.timeOrigin + performance.now(),
                preference: localStorage.getItem('preferred-prototypes-adapter'),
                contents: contents ? { ...contents.dataset } : null,
                panel: panel ? { ...panel.dataset } : null,
                generations: [
                  ...document.querySelectorAll<HTMLElement>(
                    'header [data-projection-generation-host]'
                  ),
                ].map((element) => ({ ...element.dataset, inert: element.inert })),
                longTasks: evidence?.longTasks.filter((entry) => entry.start >= since),
                changes: evidence?.changes.filter((entry) => entry.at >= since),
                resources: performance
                  .getEntriesByType('resource')
                  .filter(
                    (entry) =>
                      performance.timeOrigin + entry.startTime >= since &&
                      new URL(entry.name).origin === location.origin
                  )
                  .slice(-40)
                  .map((entry) => ({
                    path: new URL(entry.name).pathname,
                    start: performance.timeOrigin + entry.startTime,
                    duration: entry.duration,
                  })),
              };
            }, transitionStartedAt);
          try {
            const first = await readTransition();
            let late: Awaited<ReturnType<typeof readTransition>> | null = null;
            if (originalError) {
              // Diagnosis only: retain the original1000ms failure even if this
              // bounded observation later sees the requested generation commit.
              await page
                .waitForFunction(
                  (target) =>
                    document.querySelector<HTMLElement>('[data-site-contents-command]')?.dataset
                      .contentsRuntime === target,
                  runtime,
                  { timeout: 3000 }
                )
                .catch(() => {});
              late = await readTransition();
              await page.screenshot({
                path: path.join(directory, `${family}-${runtime}-failure.png`),
              });
            }
            await writeFile(
              path.join(directory, `${family}-${runtime}-transition.json`),
              JSON.stringify(
                {
                  source,
                  family,
                  runtime,
                  transitionStartedAt,
                  clickedAt,
                  originalCheckAt,
                  originalDeadlineMs: 1000,
                  originalError: originalError ? String(originalError) : null,
                  first,
                  late,
                  pageErrors,
                },
                null,
                2
              )
            );
          } catch (diagnosticError) {
            console.error('[Contents runtime evidence]', diagnosticError);
          }
          if (originalError) throw originalError;
          expect(await root.getAttribute('data-contents-family')).toBe(family);
          expect(
            await page
              .locator('[data-site-contents-panel-mount]')
              .getAttribute('data-contents-panel-runtime')
          ).toBe(runtime);
          expect(await root.getAttribute('data-contents-generation')).toBe(
            await page
              .locator('[data-site-header-panel]')
              .getAttribute('data-header-surface-generation')
          );
          if ((await menu.getAttribute('aria-expanded')) === 'true') await menu.click();
          expect(await root.getByRole('button', { name: '页面目录', exact: true }).count()).toBe(1);
          expect(await command.getAttribute('aria-controls')).toBe('starlight__sidebar');
          for (const action of ['click', 'Enter', 'Space']) {
            expect(await command.getAttribute('aria-expanded')).toBe('false');
            if (action === 'click') await command.click();
            else {
              await command.focus();
              await page.keyboard.press(action);
            }
            await expect.poll(() => command.getAttribute('aria-expanded')).toBe('true');
            await expect
              .poll(() =>
                page.locator('nav.docs-sidebar[data-site-contents-dialog-tree]').isVisible()
              )
              .toBe(true);
            expect(await command.getAttribute('aria-controls')).toBe('starlight__sidebar');
            const dialog = page.getByRole('dialog');
            expect(await dialog.count()).toBe(1);
            expect(await dialog.getAttribute('aria-modal')).toBe('true');
            expect(
              await dialog.evaluate((surface) => {
                let node: Node | null = document.querySelector('nav.docs-sidebar');
                while (node) {
                  if (node === surface) return true;
                  node =
                    (node as Element).assignedSlot ??
                    node.parentNode ??
                    (node.getRootNode() as ShadowRoot).host ??
                    null;
                }
                return false;
              })
            ).toBe(true);
            expect(await page.locator('nav.docs-sidebar').count()).toBe(1);
            expect(
              await page
                .locator('nav.docs-sidebar select, nav.docs-sidebar .mobile-menu-footer')
                .count()
            ).toBe(0);
            expect(
              await page.evaluate(() => {
                const state = window as typeof window & {
                  __contentsOriginalTree?: Element;
                  __contentsOriginalDetails?: Element[];
                  __contentsOriginalCurrent?: Element;
                };
                const tree = document.querySelector('nav.docs-sidebar');
                if (!tree) return false;
                return (
                  tree === state.__contentsOriginalTree &&
                  tree.querySelector('[aria-current="page"]') === state.__contentsOriginalCurrent &&
                  [...tree.querySelectorAll('details')].every(
                    (node, index) => node === state.__contentsOriginalDetails?.[index]
                  )
                );
              })
            ).toBe(true);
            // Native tab traversal must remain within the real public modal,
            // including the original anchors and disclosure summaries.
            await page.keyboard.press('Tab');
            expect(
              await dialog.evaluate((surface) => {
                let active = document.activeElement;
                while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
                let node: Node | null = active;
                while (node) {
                  if (node === surface) return true;
                  node =
                    (node as Element).assignedSlot ??
                    node.parentNode ??
                    (node.getRootNode() as ShadowRoot).host ??
                    null;
                }
                return false;
              })
            ).toBe(true);
            await page.keyboard.press('Shift+Tab');
            expect(
              await dialog.evaluate((surface) => {
                let active = document.activeElement;
                while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
                let node: Node | null = active;
                while (node) {
                  if (node === surface) return true;
                  node =
                    (node as Element).assignedSlot ??
                    node.parentNode ??
                    (node.getRootNode() as ShadowRoot).host ??
                    null;
                }
                return false;
              })
            ).toBe(true);
            const beforeScroll = await page.evaluate(() => scrollY);
            await page.mouse.move(2, 800);
            await page.mouse.wheel(0, 500);
            await page.evaluate(
              () =>
                new Promise<void>((resolve) =>
                  requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
                )
            );
            expect(await page.evaluate(() => scrollY)).toBe(beforeScroll);
            if (action === 'click') {
              const id = `${family}-${runtime}-public-dialog-open`;
              const metrics = await dialog.evaluate((element) => {
                const panel = element.getBoundingClientRect();
                const tree = document.querySelector('nav.docs-sidebar')!;
                const treeRect = tree.getBoundingClientRect();
                return {
                  panel: { x: panel.x, y: panel.y, width: panel.width, height: panel.height },
                  tree: {
                    x: treeRect.x,
                    y: treeRect.y,
                    width: treeRect.width,
                    height: treeRect.height,
                  },
                  treePosition: getComputedStyle(tree).position,
                  overflow: document.documentElement.scrollWidth - innerWidth,
                  rootFont: getComputedStyle(document.documentElement).fontSize,
                  dpr: devicePixelRatio,
                  scale: visualViewport?.scale,
                };
              });
              await writeFile(
                path.join(directory, `${id}.json`),
                JSON.stringify(
                  {
                    source,
                    family,
                    runtime,
                    viewport: page.viewportSize(),
                    metrics,
                    screenshotComplete: false,
                  },
                  null,
                  2
                )
              );
              await page.screenshot({ path: path.join(directory, `${id}.png`) });
              await writeFile(
                path.join(directory, `${id}.json`),
                JSON.stringify(
                  {
                    source,
                    family,
                    runtime,
                    viewport: page.viewportSize(),
                    metrics,
                    screenshotComplete: true,
                  },
                  null,
                  2
                )
              );
              expect(metrics.overflow).toBeLessThanOrEqual(1);
              expect(metrics.treePosition).toBe('static');
              expect(metrics.tree.width).toBeGreaterThan(120);
            }
            await page.evaluate((kind) => {
              const state = window as typeof window & { __contentsOriginalTree?: Element; __contentsOriginalParent?: Node | null; __contentsOriginalNextSibling?: Node | null; __contentsPositionControl?: unknown };
              const original = state.__contentsOriginalTree!;
              const parent = state.__contentsOriginalParent!;
              const sibling = state.__contentsOriginalNextSibling;
              const observer = new MutationObserver(() => {
                if (original.hasAttribute('data-site-contents-dialog-tree')) return;
                observer.disconnect();
                const before = { parentMatches: original.parentNode === parent, siblingMatches: original.nextSibling === sibling };
                if (kind === 'parent') {
                  const wrapper = document.createElement('div');
                  parent.appendChild(wrapper);
                  wrapper.appendChild(original);
                  if (sibling) wrapper.appendChild(sibling);
                } else if (sibling) parent.appendChild(original);
                else parent.appendChild(document.createTextNode('position-control'));
                state.__contentsPositionControl = { kind, at: performance.now(), before,
                  after: { parentMatches: original.parentNode === parent, siblingMatches: original.nextSibling === sibling } };
              });
              observer.observe(original, { attributes: true, attributeFilter: ['data-site-contents-dialog-tree'] });
            }, 'sibling');
            await page.keyboard.press('Escape');
            const closeDeadline = performance.now() + 1000;
            await expect.poll(() => command.getAttribute('aria-expanded')).toBe('false');
            expect(await command.evaluate((element) => document.activeElement === element)).toBe(
              true
            );
            // The website retains its native tree through the public leave barrier.
            // Lease completion shares the original close budget, without a fixed sleep.
            const remainingCloseMs = closeDeadline - performance.now();
            expect(remainingCloseMs).toBeGreaterThan(0);
            await expect
              .poll(
                () =>
                  page.evaluate(() => {
                    const state = window as typeof window & { __contentsOriginalTree?: Element };
                    const tree = state.__contentsOriginalTree;
                    return (
                      !!tree?.isConnected &&
                      tree === document.querySelector('nav.docs-sidebar') &&
                      !tree.hasAttribute('data-site-contents-dialog-tree')
                    );
                  }),
                { timeout: remainingCloseMs }
              )
              .toBe(true);
            expect(await page.locator('.docs-shell nav.docs-sidebar').count()).toBe(1);
            expect(
              await page.locator('nav.docs-sidebar').getAttribute('data-site-contents-dialog-tree')
            ).toBeNull();
            expect(
              await page.evaluate(() => {
                const state = window as typeof window & {
                  __contentsOriginalTree?: Element;
                  __contentsOriginalParent?: Node | null;
                  __contentsOriginalNextSibling?: Node | null;
                };
                const tree = state.__contentsOriginalTree;
                return (
                  !!tree &&
                  tree.parentNode === state.__contentsOriginalParent &&
                  tree.nextSibling === state.__contentsOriginalNextSibling
                );
              })
            ).toBe(true);
            expect(performance.now()).toBeLessThanOrEqual(closeDeadline);
          }
          // Real keyboard navigation selects the focus-visible state for the capture.
          await page.keyboard.press('Tab');
          await page.keyboard.press('Shift+Tab');
          const facts = await command.evaluate((element) => {
            const style = getComputedStyle(element);
            const box = element.getBoundingClientRect();
            const center = document.elementFromPoint(box.x + box.width / 2, box.y + box.height / 2);
            return {
              tokens: element.getAttribute('data-pui-style'),
              width: box.width,
              height: box.height,
              border: [style.borderWidth, style.borderColor],
              radius: style.borderRadius,
              shadow: style.boxShadow,
              font: style.fontFamily,
              focusVisible: element.hasAttribute('data-focus-visible'),
              ownsCenter: !!center && element.contains(center),
            };
          });
          expect(facts.width).toBeGreaterThanOrEqual(44);
          expect(facts.height).toBeGreaterThanOrEqual(44);
          expect(facts.ownsCenter).toBe(true);
          expect(facts.focusVisible).toBe(true);
          expect(facts.tokens).toContain(family === 'shadcn' ? 'border-ring' : 'rounded-base');
          const id = `${family}-${runtime}-keyboard-focus`;
          const record = {
            source,
            family,
            runtime,
            viewport: page.viewportSize(),
            facts,
            screenshot: `${id}.png`,
          };
          await writeFile(
            path.join(directory, `${id}.json`),
            JSON.stringify({ ...record, screenshotComplete: false }, null, 2)
          );
          await page.screenshot({ path: path.join(directory, `${id}.png`) });
          await writeFile(
            path.join(directory, `${id}.json`),
            JSON.stringify({ ...record, screenshotComplete: true }, null, 2)
          );
        }
      } catch (error) {
        const facts = await page.evaluate(() => {
          const state = window as typeof window & { __contentsOriginalTree?: Element; __contentsOriginalParent?: Node | null; __contentsOriginalNextSibling?: Node | null; __contentsPositionControl?: unknown };
          const current = document.querySelector('nav.docs-sidebar');
          return { mutation: state.__contentsPositionControl, originalConnected: state.__contentsOriginalTree?.isConnected,
            originalIsCurrent: state.__contentsOriginalTree === current,
            oldMarkerPredicate: !!current && !current.hasAttribute('data-site-contents-dialog-tree'),
            oldHomeCount: document.querySelectorAll('.docs-shell nav.docs-sidebar').length,
            oldMarkerNull: current?.getAttribute('data-site-contents-dialog-tree') === null,
            parentMatches: state.__contentsOriginalTree?.parentNode === state.__contentsOriginalParent,
            siblingMatches: state.__contentsOriginalTree?.nextSibling === state.__contentsOriginalNextSibling };
        });
        await writeFile(path.join(directory, 'position-control.json'), JSON.stringify({ source, facts, error: String(error), intentionalDOMMove: true, originalBudgetMs: 1000 }, null, 2));
        await page.screenshot({ path: path.join(directory, 'position-control-after-verdict.png') });
        throw error;
      } finally {
        await context.close();
      }
    }
  }, 180_000);
  it('uses the same mobile shell on documentation with independent global navigation and contents', async () => {
    const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
    await context.route('**/*', (route) =>
      new URL(route.request().url()).origin === new URL(baseUrl).origin
        ? route.continue()
        : route.abort()
    );
    const page = await context.newPage();
    const source = {
      sha: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
      dirty: execFileSync('git', ['status', '--porcelain'], { encoding: 'utf8' }).trim() !== '',
    };
    let stage = 'navigate';
    let activeWidth: number | null = null;
    const stages: Array<{ stage: string; width: number; nodeMs: number }> = [];
    try {
      for (const width of [390, 430, 320]) {
        activeWidth = width;
        stage = 'navigate';
        await page.setViewportSize({ width, height: 844 });
        await page.goto(`${baseUrl}/zh-cn/ui-libraries/brutalist/components/tooltip/`, {
          waitUntil: 'networkidle',
        });
        const header = page.locator('[data-docs-site-header]');
        const menu = header.locator('[data-site-menu-button]');
        stage = 'menu-ready';
        stages.push({ stage, width, nodeMs: performance.now() });
        await expect.poll(() => header.getAttribute('data-site-menu-ready')).toBe('');
        stage = 'mobile-interaction';
        stages.push({ stage, width, nodeMs: performance.now() });
        // This loop reuses its native pointer across navigations. Measure the
        // resting row, not a legitimate +4px Brutalist hover under the old point.
        await page.mouse.move(0, 800);
        await expect
          .poll(
            () =>
              header.evaluate((element) =>
                [
                  ...element.querySelectorAll(
                    '.site-header-search [data-open-modal], [data-theme-toggle], [data-site-menu-button]'
                  ),
                ].every((control) => getComputedStyle(control).transform === 'none')
              ),
            { timeout: 1000 }
          )
          .toBe(true);
        const geometry = await header.evaluate((element) => {
          const bounds = element.getBoundingClientRect();
          const controls = [
            ...element.querySelectorAll<HTMLElement>(
              '.site-header-search [data-open-modal], [data-theme-toggle], [data-site-menu-button]'
            ),
          ].map((control) => {
            const { x, y, width, height } = control.getBoundingClientRect();
            return { x, y, width, height };
          });
          return {
            height: bounds.height,
            measuredOffset: parseFloat(
              getComputedStyle(element.closest('.site-page-frame')!).getPropertyValue(
                '--header-height'
              )
            ),
            controls,
            overflow: document.documentElement.scrollWidth > innerWidth,
          };
        });
        expect(Math.abs(geometry.height - geometry.measuredOffset)).toBeLessThanOrEqual(1);
        expect(geometry.overflow).toBe(false);
        expect(geometry.controls).toHaveLength(3);
        for (const control of geometry.controls) {
          expect(control.width).toBeGreaterThanOrEqual(44);
          expect(control.height).toBeGreaterThanOrEqual(44);
          expect(control.y).toBe(geometry.controls[0]!.y);
        }
        await menu.click();
        expect(await menu.getAttribute('aria-controls')).toBe('site-header-panel');
        expect(await header.locator('[data-site-header-navigation]').isVisible()).toBe(true);
        expect(await page.locator('body').getAttribute('data-mobile-menu-expanded')).toBeNull();
        await page.keyboard.press('Escape');
        expect(await menu.getAttribute('aria-expanded')).toBe('false');
        const contents = header.locator(
          '[data-site-contents-command] [data-projection-generation-state="active"] [data-site-contents-button]'
        );
        expect(await contents.getAttribute('aria-controls')).toBe('starlight__sidebar');
        expect(await header.getByRole('button', { name: '页面目录', exact: true }).count()).toBe(1);
        expect(await contents.getAttribute('title')).toBe('页面目录');
        await revealHeaderPreferences(page);
        const hitTargets = await header.evaluate((element) => {
          const trigger = element.querySelector<HTMLElement>(
            '[data-adapter-select] [role="combobox"]'
          )!;
          const contents = element.querySelector<HTMLElement>(
            '[data-site-contents-command] [data-projection-generation-state="active"] [data-site-contents-button]'
          )!;
          const triggerRect = trigger.getBoundingClientRect();
          const contentsRect = contents.getBoundingClientRect();
          const center = document.elementFromPoint(
            contentsRect.x + contentsRect.width / 2,
            contentsRect.y + contentsRect.height / 2
          );
          return {
            trigger: { left: triggerRect.left, right: triggerRect.right, top: triggerRect.top },
            contents: {
              left: contentsRect.left,
              right: contentsRect.right,
              bottom: contentsRect.bottom,
            },
            contentsOwnsCenter: center !== null && contents.contains(center),
            centerTag: center?.tagName,
            chevrons: [...trigger.querySelectorAll('svg')].map((svg) => {
              const rect = svg.getBoundingClientRect();
              return { left: rect.left, right: rect.right, width: rect.width };
            }),
          };
        });
        console.info('Mobile documentation header hit targets', { width, ...hitTargets });
        expect(hitTargets.chevrons).toHaveLength(1);
        for (const chevron of hitTargets.chevrons) {
          expect(chevron.width, `${width}px real runtime chevron`).toBeGreaterThan(0);
          expect(chevron.left, `${width}px chevron inside trigger left`).toBeGreaterThanOrEqual(
            hitTargets.trigger.left
          );
          expect(chevron.right, `${width}px chevron inside trigger right`).toBeLessThanOrEqual(
            hitTargets.trigger.right
          );
        }
        expect(
          hitTargets.trigger.top,
          `${width}px runtime panel is separate from the first-row contents opener`
        ).toBeGreaterThanOrEqual(hitTargets.contents.bottom);
        expect(
          hitTargets.contentsOwnsCenter,
          `${width}px native contents target owns its center`
        ).toBe(true);
        await contents.click();
        expect(await page.locator('body').getAttribute('data-mobile-menu-expanded')).not.toBeNull();
        expect(await menu.getAttribute('aria-expanded')).toBe('false');
        // Public modal blocks background Header interaction; close it normally
        // before entering Navigation and settings, rather than clicking through.
        expect(await contents.getAttribute('aria-controls')).toBe('starlight__sidebar');
        const dialog = page.getByRole('dialog');
        await expect.poll(() => dialog.isVisible()).toBe(true);
        const menuHit = await menu.evaluate((element) => {
          const rect = element.getBoundingClientRect();
          return element.contains(
            document.elementFromPoint(rect.x + rect.width / 2, rect.y + rect.height / 2)
          );
        });
        expect(menuHit).toBe(false);
        await page.keyboard.press('Escape');
        await expect.poll(() => contents.getAttribute('aria-expanded')).toBe('false');
        await expect.poll(() => dialog.count()).toBe(0);
        await menu.click();
        expect(await menu.getAttribute('aria-expanded')).toBe('true');
        expect(await contents.getAttribute('aria-expanded')).toBe('false');
        expect(await page.locator('body').getAttribute('data-mobile-menu-expanded')).toBeNull();
        expect(await header.locator('[data-language-select]').isVisible()).toBe(true);
        expect(await header.locator('[data-theme-toggle]').isVisible()).toBe(true);
        expect(
          await header.locator('[data-site-header-settings] a[href*="github.com"]').count()
        ).toBeGreaterThan(0);
        await page.keyboard.press('Escape');
        expect(await menu.evaluate((element) => document.activeElement === element)).toBe(true);
        // Reverse the order and exercise the complete keydown + keyup Escape.
        await menu.click();
        await contents.click();
        stage = 'navigation-close-from-contents';
        stages.push({ stage, width, nodeMs: performance.now() });
        await expect.poll(() => menu.getAttribute('aria-expanded')).toBe('false');
        stage = 'contents-focus';
        stages.push({ stage, width, nodeMs: performance.now() });
        expect(await contents.getAttribute('aria-expanded')).toBe('true');
        await page.keyboard.press('Escape');
        expect(await contents.evaluate((element) => document.activeElement === element)).toBe(true);
      }
    } catch (error) {
      const rejected = {
        source,
        stage,
        width: activeWidth,
        nodeMs: performance.now(),
        message: String(error),
        stack: error instanceof Error ? error.stack : null,
        cause: error instanceof Error && error.cause !== undefined ? String(error.cause) : null,
        stages: stages.map((entry) => ({ ...entry })),
      };
      // Freeze the original rejection before any post-failure browser request.
      console.info('[mobile-shell-rejection]', JSON.stringify(rejected));
      try {
        const directory = path.join(
          process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR ??
            path.join(process.env.RUNNER_TEMP ?? os.tmpdir(), 'homepage-evidence'),
          'mobile-shell'
        );
        await mkdir(directory, { recursive: true });
        await writeFile(path.join(directory, 'rejection.json'), JSON.stringify(rejected, null, 2));
        const nodeStartedMs = performance.now();
        const facts = await page.evaluate(() => {
          const header = document.querySelector<HTMLElement>('[data-docs-site-header]');
          const menu = header?.querySelector('[data-site-menu-button]');
          const contents = header?.querySelector('[data-site-contents-command]');
          return {
            timeOrigin: performance.timeOrigin,
            pageMs: performance.now(),
            menuReady: header?.getAttribute('data-site-menu-ready'),
            menuExpanded: menu?.getAttribute('aria-expanded'),
            contents: contents?.outerHTML,
            bodyExpanded: document.body.getAttribute('data-mobile-menu-expanded'),
            activeElement: document.activeElement?.outerHTML,
          };
        });
        await writeFile(
          path.join(directory, 'post-rejection.json'),
          JSON.stringify({ nodeStartedMs, nodeReturnedMs: performance.now(), facts }, null, 2)
        );
        await page.screenshot({ path: path.join(directory, 'failure.png'), fullPage: true });
      } catch (captureError) {
        console.info('[mobile-shell-capture-error]', String(captureError));
      }
      throw error;
    } finally {
      console.info('[mobile-shell-stages]', JSON.stringify({ source, stages }));
      await context.close();
    }
  }, 90_000);
});

for (const family of ['shadcn', 'brutalist'] as const) {
  it(`compact ${family} preferences stay usable at 200% text, RTL and breakpoint moves`, async () => {
    const context = await browser.newContext({ viewport: { width: 390, height: 1000 } });
    const page = await context.newPage();
    try {
      await page.goto(`${baseUrl}/zh-cn/`, { waitUntil: 'networkidle' });
      await ready(page, 'wc');
      await revealHeaderPreferences(page);
      if (family === 'brutalist') {
        const control = page.locator(
          '#home-preferences [data-projection-control="family"] [role="combobox"]'
        );
        await control.click();
        const id = await control.getAttribute('aria-controls');
        await page
          .locator(`[id=${JSON.stringify(id)}]`)
          .getByRole('option', { name: 'Brutalist', exact: true })
          .click();
        await page.waitForFunction(
          () =>
            document.querySelector<HTMLElement>('[data-homepage-runtime]')?.dataset.family ===
            'brutalist'
        );
      }
      for (const width of [320, 390])
        for (const rtl of [false, true]) {
          await page.setViewportSize({ width, height: 1000 });
          await page.evaluate((rtl) => {
            document.documentElement.dir = rtl ? 'rtl' : 'ltr';
            document.documentElement.style.fontSize = '200%';
          }, rtl);
          const menu = page.locator(
            '.site-header-menu [data-projection-generation-state="active"] [data-demo-ref="home-menu"]'
          );
          // Reopen through the actual Button after changing host text/direction.
          if ((await menu.getAttribute('aria-expanded')) === 'true') await menu.click();
          await revealHeaderPreferences(page);
          const controls = page.locator('#home-preferences [role="combobox"]');
          expect(await controls.count()).toBe(2);
          for (const control of await controls.all()) {
            await control.scrollIntoViewIfNeeded();
            const facts = await control.evaluate((node) => {
              const value = node.querySelector<HTMLElement>(
                '[data-projection-prototype$="-select-value"]'
              )!;
              return {
                rect: node.getBoundingClientRect().toJSON(),
                overflow: value.scrollWidth - value.clientWidth,
                whiteSpace: getComputedStyle(value).whiteSpace,
                hidden: !!node.closest('[hidden], [inert]'),
              };
            });
            expect(facts.hidden).toBe(false);
            expect(facts.rect.height).toBeGreaterThanOrEqual(44);
            expect(facts.whiteSpace).toBe('normal');
            expect(facts.overflow).toBeLessThanOrEqual(1);
          }
          const placement = await page.locator('[data-site-header-panel]').evaluate((panel) => {
            const surface = panel.querySelector('.site-header-popup-surface')!;
            const trigger = document.querySelector(
              '.site-header-menu [data-projection-generation-state="active"] [data-demo-ref="home-menu"]'
            )!;
            return {
              panel: panel.getBoundingClientRect().toJSON(),
              surface: surface.getBoundingClientRect().toJSON(),
              trigger: trigger.getBoundingClientRect().toJSON(),
              header: trigger.closest('[data-site-header]')!.getBoundingClientRect().toJSON(),
              overflow: document.documentElement.scrollWidth - innerWidth,
            };
          });
          expect(placement.overflow).toBeLessThanOrEqual(1);
          expect(Math.abs(placement.panel.top - placement.header.bottom - 5)).toBeLessThanOrEqual(
            1
          );
          expect(
            Math.abs((rtl ? placement.panel.left : placement.panel.right) - (rtl ? 8 : width - 8))
          ).toBeLessThanOrEqual(1);
          expect(Math.abs(placement.surface.width - placement.panel.width)).toBeLessThanOrEqual(1);
          const runtime = page.locator(
            '#home-preferences [data-projection-control="runtime"] [role="combobox"]'
          );
          await runtime.focus();
          await page.setViewportSize({ width: 1440, height: 1000 });
          await expect
            .poll(() =>
              runtime.evaluate(
                (node) =>
                  node === document.activeElement && !node.closest('[data-site-header-panel]')
              )
            )
            .toBe(true);
          await page.setViewportSize({ width, height: 1000 });
          await expect
            .poll(() =>
              runtime.evaluate(
                (node) =>
                  node === document.activeElement &&
                  !!node.closest('[data-site-header-panel]') &&
                  !node.closest('[hidden], [inert]')
              )
            )
            .toBe(true);
          await page.keyboard.press('Escape');
          expect(await menu.evaluate((node) => node === document.activeElement)).toBe(true);
          expect(await page.locator('[data-site-header-panel]').isVisible()).toBe(false);
        }
    } finally {
      await context.close();
    }
  }, 120_000);
}

// Two bounded family journeys, each exercising all four actual renderers. A
// locator re-query is insufficient here: every comparison retains the original
// physical ElementHandle, plus WC's public exposed-state handle identities.
for (const family of ['shadcn', 'brutalist'] as const) {
  it(`retains ${family} preference owners and portals through real breakpoint reconnects`, async () => {
    const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
    const page = await context.newPage();
    const evidenceDirectory = path.join(
      process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR ??
        path.join(process.env.RUNNER_TEMP ?? os.tmpdir(), 'homepage-evidence'),
      'header-breakpoint'
    );
    await mkdir(evidenceDirectory, { recursive: true });
    const source = {
      sha: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
      dirty: execFileSync('git', ['status', '--porcelain'], { encoding: 'utf8' }).trim() !== '',
      expectedSha: process.env.CANDIDATE_SHA ?? null,
      eventSha: process.env.GITHUB_SHA ?? null,
    };
    const records: unknown[] = [];
    const ringFailures: string[] = [];
    const errors: string[] = [];
    const consoleErrors: string[] = [];
    const familyCommitCalls: Array<{
      call: number;
      startedMs: number;
      returnedMs?: number;
      value?: string | null;
      error?: string;
    }> = [];
    const familyCommitTiming = {
      clock: 'Node performance.now() milliseconds',
      timeOrigin: performance.timeOrigin,
      startedMs: null as number | null,
      finishedMs: null as number | null,
      outcome: 'not-run',
      totalCalls: 0,
      droppedCalls: 0,
      observerError: false,
      calls: familyCommitCalls,
      rejectionSnapshot: null as typeof familyCommitCalls | null,
    };
    let utilityObservation: Awaited<ReturnType<typeof prepareUtilityFamilyReadObservation>> | null =
      null;
    // Keep every original Promise until post-verdict settlement; only displayed rows are capped.
    const familyQueryRequests: Array<{
      request: Promise<string | null>;
      call: (typeof familyCommitCalls)[number];
    }> = [];
    const familyQueryObservation = {
      mode: familyQueryMode,
      enabled: {
        node: true,
        writerMO: familyQueryMode !== 'node-only',
        utility: familyQueryMode === 'hybrid',
      },
      ledgerError: false,
      verdict: null as null | { outcome: string; nodeMs: number | null; frozenAtMs: number },
      pendingAtVerdict: [] as typeof familyCommitCalls,
      pendingAtVerdictCount: 0,
      droppedPendingRows: 0,
      referenceCountAtVerdict: 0,
      referenceCountAfterDrain: 0,
      issuedAfterDrain: 0,
      wait: {
        startedMs: null as number | null,
        finishedMs: null as number | null,
        drainedReferences: 0,
        budgetMs: 1000,
        budgetExpired: false,
        pendingAtDrainEndCount: 0,
        pendingAtDrainEnd: [] as typeof familyCommitCalls,
        droppedPendingAtDrainEndRows: 0,
        displayedOutcomes: [] as Array<Record<string, unknown>>,
        droppedOutcomeRows: 0,
        completeAtDrainPoint: false,
      },
      utility: null as Record<string, any> | null,
      cleanupDeferredUntilContextClose: false,
      errors: [] as string[],
    };
    const noteQueryError = (error: unknown) => {
      try {
        familyQueryObservation.errors.push(String(error));
      } catch {
        familyQueryObservation.ledgerError = true;
      }
    };
    let finishQueries: Promise<void> | null = null;
    const finishFamilyQueryObservation = () =>
      (finishQueries ??= (async () => {
        if (family !== 'brutalist') return;
        try {
          familySDK?.freezeVerdict(familyCommitTiming.outcome === 'fulfilled');
          familyQueryObservation.verdict = {
            outcome: familyCommitTiming.outcome,
            nodeMs: familyCommitTiming.finishedMs,
            frozenAtMs: performance.now(),
          };
          familyQueryObservation.referenceCountAtVerdict = familyQueryRequests.length;
          const pending = familyQueryRequests.filter(({ call }) => call.returnedMs === undefined);
          familyQueryObservation.pendingAtVerdictCount = pending.length;
          familyQueryObservation.pendingAtVerdict = pending
            .slice(0, 64)
            .map(({ call }) => ({ ...call }));
          familyQueryObservation.droppedPendingRows = Math.max(0, pending.length - 64);
          try {
            console.info(
              '[family-query-verdict]',
              JSON.stringify({
                source,
                family,
                mode: familyQueryMode,
                verdict: familyQueryObservation.verdict,
                referenceCount: familyQueryObservation.referenceCountAtVerdict,
                pendingCount: pending.length,
                pending: familyQueryObservation.pendingAtVerdict,
                droppedPendingRows: familyQueryObservation.droppedPendingRows,
              })
            );
          } catch (error) {
            noteQueryError(error);
          }
          familyQueryObservation.wait.startedMs = performance.now();
          const drainDeadline =
            familyQueryObservation.wait.startedMs + familyQueryObservation.wait.budgetMs;
          let drained = 0;
          while (drained < familyQueryRequests.length) {
            const batch = familyQueryRequests.slice(drained);
            const settlement = await settleFamilyQueryBatch(
              batch.map(({ request }) => request),
              Math.max(0, drainDeadline - performance.now())
            );
            if (!settlement.complete) {
              familyQueryObservation.wait.budgetExpired = true;
              break;
            }
            const outcomes = settlement.outcomes;
            const observedAtMs = performance.now();
            outcomes.forEach((outcome, index) => {
              try {
                if (familyQueryObservation.wait.displayedOutcomes.length < 64)
                  familyQueryObservation.wait.displayedOutcomes.push({
                    call: batch[index]!.call.call,
                    status: outcome.status,
                    ...('value' in outcome
                      ? { value: outcome.value }
                      : { error: String(outcome.reason) }),
                    batchObservedAtMs: observedAtMs,
                  });
                else familyQueryObservation.wait.droppedOutcomeRows++;
              } catch (error) {
                noteQueryError(error);
              }
            });
            drained += batch.length;
            familyQueryObservation.wait.drainedReferences = drained;
          }
          familyQueryObservation.referenceCountAfterDrain = familyQueryRequests.length;
          const pendingAtDrainEnd = familyQueryRequests.filter(
            ({ call }) => call.returnedMs === undefined
          );
          familyQueryObservation.wait.pendingAtDrainEndCount = pendingAtDrainEnd.length;
          familyQueryObservation.wait.pendingAtDrainEnd = pendingAtDrainEnd
            .slice(0, 64)
            .map(({ call }) => ({ ...call }));
          familyQueryObservation.wait.droppedPendingAtDrainEndRows = Math.max(
            0,
            pendingAtDrainEnd.length - 64
          );
          familyQueryObservation.wait.completeAtDrainPoint =
            !familyQueryObservation.ledgerError &&
            !familyQueryObservation.wait.budgetExpired &&
            drained === familyQueryRequests.length;
        } catch (error) {
          noteQueryError(error);
        } finally {
          familyQueryObservation.wait.finishedMs = performance.now();
        }
        if (utilityObservation) {
          if (familyQueryObservation.wait.completeAtDrainPoint) {
            try {
              familyQueryObservation.utility = await utilityObservation.collectAndRestore();
            } catch (error) {
              noteQueryError(error);
            }
          } else {
            // Unknown/unretained requests cannot be made safe by restoring their hook early.
            familyQueryObservation.cleanupDeferredUntilContextClose = true;
          }
        }
        try {
          console.info(
            '[family-query-settled]',
            JSON.stringify({ source, family, ...familyQueryObservation })
          );
        } catch (error) {
          noteQueryError(error);
        }
      })());
    const observeFamilyMutation = () => {
      const target = document.querySelector<HTMLElement>('[data-homepage-runtime]')!;
      const nativeDataset = target.dataset;
      const ownDataset = Object.getOwnPropertyDescriptor(target, 'dataset');
      const writes: Array<{
        startedMs: number | null;
        finishedMs: number;
        previous: string | null;
        current: string | null;
        returned?: boolean;
        error?: string;
      }> = [];
      let droppedWrites = 0;
      let writerObserverError = false;
      const recordWrite = (
        startedMs: number | null,
        previous: string | null,
        result: { returned: boolean } | { error: unknown }
      ) => {
        try {
          const finishedMs = performance.now();
          if (writes.length < 64)
            writes.push({
              startedMs,
              finishedMs,
              previous,
              current: target.getAttribute('data-family'),
              ...('error' in result ? { error: String(result.error) } : result),
            });
          else droppedWrites += 1;
        } catch {
          writerObserverError = true;
        }
      };
      // This instance-only interposition changes dataset identity/access cost.
      // It brackets the native attribute write, not the complete publication.
      const dataset = new Proxy(nativeDataset, {
        set(subject, key, value) {
          if (key !== 'family') return Reflect.set(subject, key, value, subject);
          let previous: string | null = null;
          let startedMs: number | null = null;
          try {
            previous = target.getAttribute('data-family');
            startedMs = performance.now();
          } catch {
            writerObserverError = true;
          }
          let returned: boolean;
          try {
            returned = Reflect.set(subject, key, value, subject);
          } catch (error) {
            recordWrite(startedMs, previous, { error });
            throw error;
          }
          recordWrite(startedMs, previous, { returned });
          return returned;
        },
      });
      const datasetGetter = () => dataset;
      const deliveries: Array<{
        deliveredMs: number;
        oldValues: Array<string | null>;
        currentValueAtDelivery: string | null;
        connected: boolean;
      }> = [];
      let retainedRecords = 0;
      let droppedRecords = 0;
      let observerError: string | null = null;
      const observer = new MutationObserver((records) => {
        try {
          const deliveredMs = performance.now();
          const retained = records.slice(0, 64 - retainedRecords);
          retainedRecords += retained.length;
          droppedRecords += records.length - retained.length;
          if (retained.length)
            deliveries.push({
              deliveredMs,
              oldValues: retained.map((record) => record.oldValue),
              currentValueAtDelivery: target.getAttribute('data-family'),
              connected: target.isConnected,
            });
        } catch (error) {
          observerError = String(error);
        }
      });
      observer.observe(target, {
        attributes: true,
        attributeFilter: ['data-family'],
        attributeOldValue: true,
      });
      try {
        Object.defineProperty(target, 'dataset', {
          configurable: true,
          enumerable: ownDataset?.enumerable ?? false,
          get: datasetGetter,
        });
      } catch (error) {
        observer.disconnect();
        throw error;
      }
      return {
        target,
        observer,
        deliveries,
        getDroppedRecords: () => droppedRecords,
        getObserverError: () => observerError,
        initialValue: target.getAttribute('data-family'),
        timeOrigin: performance.timeOrigin,
        setupPageMs: performance.now(),
        writes,
        getDroppedWrites: () => droppedWrites,
        getWriterObserverError: () => writerObserverError,
        restoreDataset: () => {
          if (Object.getOwnPropertyDescriptor(target, 'dataset')?.get !== datasetGetter)
            return false;
          if (ownDataset) Object.defineProperty(target, 'dataset', ownDataset);
          else Reflect.deleteProperty(target, 'dataset');
          return target.dataset === nativeDataset;
        },
      };
    };
    let familyMutationHandle: JSHandle<ReturnType<typeof observeFamilyMutation>> | null = null;
    const familyMutationTiming = {
      clock: 'Browser performance.now() milliseconds; MutationObserver delivery, not mutation time',
      setup: null as { nodeStartedMs: number; nodeReturnedMs: number } | null,
      collect: null as { nodeStartedMs: number; nodeReturnedMs: number } | null,
      calibration: [] as Array<{
        nodeStartedMs: number;
        nodeReturnedMs: number;
        timeOrigin: number;
        pageMs: number;
        currentRootSame: boolean;
      }>,
      facts: null as unknown,
      errors: [] as string[],
    };
    const collectFamilyMutation = async () => {
      const handle = familyMutationHandle;
      if (!handle) return;
      familyMutationHandle = null;
      const nodeStartedMs = performance.now();
      try {
        familyMutationTiming.facts = await handle.evaluate((state) => {
          const pending = state.observer.takeRecords();
          const pendingOldValues = pending.slice(0, 64).map((record) => record.oldValue);
          state.observer.disconnect();
          const datasetRestored = state.restoreDataset();
          return {
            timeOrigin: state.timeOrigin,
            collectedTimeOrigin: performance.timeOrigin,
            setupPageMs: state.setupPageMs,
            collectedPageMs: performance.now(),
            initialValue: state.initialValue,
            deliveries: state.deliveries,
            pendingOldValues,
            pendingDroppedRecords: Math.max(0, pending.length - pendingOldValues.length),
            currentValueAtCollection: state.target.getAttribute('data-family'),
            currentRootSame: document.querySelector('[data-homepage-runtime]') === state.target,
            connected: state.target.isConnected,
            droppedRecords: state.getDroppedRecords(),
            observerError: state.getObserverError(),
            writes: state.writes,
            droppedWrites: state.getDroppedWrites(),
            writerObserverError: state.getWriterObserverError(),
            datasetRestored,
          };
        });
      } catch (error) {
        familyMutationTiming.errors.push(String(error));
      } finally {
        familyMutationTiming.collect = { nodeStartedMs, nodeReturnedMs: performance.now() };
      }
      try {
        // Fixed post-poll samples; retain every interval rather than picking a fast one.
        for (let index = 0; index < 3; index += 1) {
          const nodeStartedMs = performance.now();
          const sample = await handle.evaluate((state) => ({
            timeOrigin: performance.timeOrigin,
            pageMs: performance.now(),
            currentRootSame: document.querySelector('[data-homepage-runtime]') === state.target,
          }));
          familyMutationTiming.calibration.push({
            nodeStartedMs,
            nodeReturnedMs: performance.now(),
            ...sample,
          });
        }
      } catch (error) {
        familyMutationTiming.errors.push(String(error));
      } finally {
        await handle.dispose().catch((error) => familyMutationTiming.errors.push(String(error)));
      }
    };
    page.on('console', (message) => {
      if (message.type() === 'error') consoleErrors.push(message.text());
    });
    page.on('pageerror', (error) => errors.push(error.message));
    const familySDK =
      family === 'brutalist'
        ? installDocsCallTimingObserver(page, {
            sdkRoot: path.dirname(
              createRequire(import.meta.url).resolve('playwright-core/package.json')
            ),
            selector: '[data-homepage-runtime]',
            attribute: 'data-family',
          })
        : null;
    let stage = 'navigate';
    const save = async (name: string, facts: unknown) => {
      const id = `${family}-${name}`;
      const screenshot = `${id}.png`;
      const jsonPath = path.join(evidenceDirectory, `${id}.json`);
      const record = {
        source,
        screenshot,
        family,
        stage,
        viewport: page.viewportSize(),
        capturedAt: new Date().toISOString(),
        facts,
      };
      // Retain the primary geometry/ownership facts even if capture itself fails.
      await writeFile(jsonPath, JSON.stringify({ ...record, screenshotComplete: false }, null, 2));
      await page.screenshot({ path: path.join(evidenceDirectory, screenshot) });
      await writeFile(jsonPath, JSON.stringify({ ...record, screenshotComplete: true }, null, 2));
    };
    try {
      await page.goto(`${baseUrl}/zh-cn/`, { waitUntil: 'networkidle' });
      stage = 'initial-ready';
      await ready(page, 'wc');
      if (family === 'brutalist') {
        if (familyQueryMode !== 'node-only') {
          // Bracket a page-clock sample before input; keep the original click/poll interval intact.
          const nodeStartedMs = performance.now();
          try {
            familyMutationHandle = await page.evaluateHandle(observeFamilyMutation);
          } catch (error) {
            familyMutationTiming.errors.push(String(error));
          } finally {
            familyMutationTiming.setup = { nodeStartedMs, nodeReturnedMs: performance.now() };
          }
        }
        stage = 'family-open';
        await revealHeaderPreferences(page);
        const control = page.locator(
          '#home-preferences [data-projection-control="family"] [role="combobox"]'
        );
        await control.click();
        const id = await control.getAttribute('aria-controls');
        if (familyQueryMode === 'hybrid')
          utilityObservation = await prepareUtilityFamilyReadObservation(page);
        stage = 'family-choice';
        await page
          .locator(`[id=${JSON.stringify(id)}]`)
          .getByRole('option', { name: 'Brutalist', exact: true })
          .click();
        stage = 'family-commit';
        familyCommitTiming.startedMs = performance.now();
        familyCommitTiming.outcome = 'pending';
        await expect
          .poll(() => {
            const call: (typeof familyCommitCalls)[number] = {
              call: ++familyCommitTiming.totalCalls,
              startedMs: performance.now(),
            };
            if (familyCommitCalls.length < 64) familyCommitCalls.push(call);
            else familyCommitTiming.droppedCalls += 1;
            const request: Promise<string | null> = familySDK!.runOriginalQuery(call.call, () =>
              page.locator('[data-homepage-runtime]').getAttribute('data-family')
            );
            try {
              familyQueryRequests.push({ request, call });
              if (familyQueryObservation.wait.finishedMs !== null)
                familyQueryObservation.issuedAfterDrain++;
            } catch {
              familyQueryObservation.ledgerError = true;
            }
            void request
              .then(
                (value) => {
                  call.returnedMs = performance.now();
                  call.value = value;
                },
                (error) => {
                  call.returnedMs = performance.now();
                  call.error = String(error);
                }
              )
              .catch(() => {
                familyCommitTiming.observerError = true;
              });
            return request;
          })
          .toBe(family);
        familyCommitTiming.finishedMs = performance.now();
        familyCommitTiming.outcome = 'fulfilled';
        await finishFamilyQueryObservation();
        await collectFamilyMutation();
        stage = 'family-ready';
        await ready(page, 'wc');
      }
      for (const runtime of RUNTIMES) {
        stage = `${runtime}-setup`;
        await page.setViewportSize({ width: 390, height: 844 });
        await switchRuntime(page, runtime);
        const header = page.locator('[data-homepage-runtime]');
        const generation = await header.getAttribute('data-runtime-generation');
        const handles = new Map<string, ElementHandle<HTMLElement>>();
        for (const control of ['runtime', 'family'] as const) {
          stage = `${runtime}-${control}-lease`;
          const triggerLocator = page.locator(
            `#home-preferences [data-projection-control="${control}"] [role="combobox"]`
          );
          const rootLocator = page.locator(
            `#home-preferences [data-demo-ref="__pui_projection__${control}_root"]`
          );
          await expect.poll(() => triggerLocator.count()).toBe(1);
          await expect.poll(() => rootLocator.count()).toBe(1);
          const trigger = (await triggerLocator.elementHandle()) as ElementHandle<HTMLElement>;
          const root = (await rootLocator.elementHandle()) as ElementHandle<HTMLElement>;
          expect(trigger).not.toBeNull();
          expect(root).not.toBeNull();
          handles.set(control, trigger);
          const lease = await trigger.evaluateHandle(captureHeaderPreferenceLease, {
            root,
            control,
          });
          let portal: ElementHandle<HTMLElement> | null = null;
          let selected: ElementHandle<HTMLElement> | null = null;
          try {
            await trigger.focus();
            await page.keyboard.press('Enter');
            const id = await trigger.getAttribute('aria-controls');
            expect(id).toBeTruthy();
            const portalLocator = page.locator(`[id=${JSON.stringify(id)}]`);
            await portalLocator.waitFor({ state: 'visible' });
            const expectedLabel =
              control === 'runtime'
                ? LABELS[runtime]
                : family === 'shadcn'
                  ? 'Shadcn'
                  : 'Brutalist';
            const selectedLocator = portalLocator.getByRole('option', {
              name: expectedLabel,
              exact: true,
            });
            await expect
              .poll(() =>
                selectedLocator.evaluate(
                  (node) =>
                    node === document.activeElement && node.getAttribute('aria-selected') === 'true'
                )
              )
              .toBe(true);
            portal = (await portalLocator.elementHandle()) as ElementHandle<HTMLElement>;
            selected = (await selectedLocator.elementHandle()) as ElementHandle<HTMLElement>;
            for (const [name, width, insidePanel] of [
              ['mobile-before', 390, true],
              ['desktop', 1440, false],
              ['mobile-return', 320, true],
            ] as const) {
              stage = `${runtime}-${control}-${name}`;
              await page.setViewportSize({ width, height: 844 });
              await expect
                .poll(() =>
                  lease
                    .evaluate(inspectHeaderPreferenceLease, {
                      insidePanel,
                      portal: portal!,
                      selected: selected!,
                      focused: 'portal' as const,
                    })
                    .then(headerPreferenceLeaseIssues)
                )
                .toEqual([]);
              const facts = await lease.evaluate(inspectHeaderPreferenceLease, {
                insidePanel,
                portal,
                selected,
                focused: 'portal' as const,
              });
              records.push({ stage, facts });
              if (control === 'runtime') await save(stage, facts);
              expect(await header.getAttribute('data-runtime-generation')).toBe(generation);
              expect(await trigger.getAttribute('aria-controls')).toBe(id);
            }
            // Re-select the current value using native keys, so a legitimate
            // runtime/family change cannot hide a breakpoint-induced remount.
            stage = `${runtime}-${control}-keyboard-commit-current`;
            await page.keyboard.press('Home');
            const options = control === 'runtime' ? Object.values(LABELS) : ['Shadcn', 'Brutalist'];
            for (let index = 0; index < options.indexOf(expectedLabel); index++)
              await page.keyboard.press('ArrowDown');
            await expect
              .poll(() => selected!.evaluate((node) => node === document.activeElement))
              .toBe(true);
            await page.keyboard.press('Enter');
            await expect.poll(() => portal!.isVisible()).toBe(false);
            await expect
              .poll(() =>
                lease
                  .evaluate(inspectHeaderPreferenceLease, {
                    insidePanel: true,
                    focused: 'trigger' as const,
                  })
                  .then(headerPreferenceLeaseIssues)
              )
              .toEqual([]);
            records.push({
              stage,
              facts: await lease.evaluate(inspectHeaderPreferenceLease, {
                insidePanel: true,
                focused: 'trigger' as const,
              }),
            });
            expect(await header.getAttribute('data-runtime-generation')).toBe(generation);
          } finally {
            await lease.dispose();
            await root.dispose();
            await portal?.dispose();
            await selected?.dispose();
          }
        }
        // The compact closed state must remove the settings row. Do not change
        // app DOM or force a hidden Select to obtain its focus-ring capture.
        stage = `${runtime}-closed`;
        await page.keyboard.press('Escape');
        const menu = page.locator(
          '.site-header-menu [data-projection-generation-state="active"] [data-demo-ref="home-menu"]'
        );
        await expect.poll(() => menu.getAttribute('aria-expanded')).toBe('false');
        expect(await header.locator('[data-site-header-preferences]').isVisible()).toBe(false);
        expect((await header.boundingBox())!.height).toBeLessThanOrEqual(64);
        await page.setViewportSize({ width: 320, height: 300 });
        await menu.focus();
        await page.keyboard.press('Enter');
        const firstLink = page
          .locator('#home-navigation-mobile [data-homepage-mount] a[href]')
          .first();
        await expect
          .poll(() => firstLink.evaluate((node) => node === document.activeElement))
          .toBe(true);
        const unfocused = await handles.get('runtime')!.evaluate(measureHeaderPreferenceFocusRing);
        for (let index = 0; index < 3; index++) await page.keyboard.press('Tab');
        for (const control of ['runtime', 'family'] as const) {
          stage = `${runtime}-${control}-narrow-focus-ring`;
          const trigger = handles.get(control)!;
          await expect
            .poll(() =>
              trigger.evaluate(
                (node) => node === document.activeElement && node.matches(':focus-visible')
              )
            )
            .toBe(true);
          const expectedToken = family === 'shadcn' ? 'ring-3' : 'ring-2';
          await expect.poll(() => trigger.getAttribute('data-pui-style')).toContain(expectedToken);
          const facts = await trigger.evaluate(measureHeaderPreferenceFocusRing);
          records.push({ stage, facts });
          await save(stage, { unfocused, focused: facts });
          if (!facts.unclipped || !facts.inViewport)
            ringFailures.push(
              `${stage}: ${JSON.stringify({ ring: facts.ring, viewport: facts.viewport, clipping: facts.clipping })}`
            );
          expect(facts.prototype).toBe(`${family}-select-trigger`);
          expect(facts.ringWidth).toBe(family === 'shadcn' ? 3 : 2);
          expect(facts.ringOffset).toBe(family === 'shadcn' ? 0 : 2);
          expect(facts.shadow).not.toBe('none');
          if (control === 'runtime') expect(facts.shadow).not.toBe(unfocused.shadow);
          if (control === 'runtime') await page.keyboard.press('Tab');
        }
        await page.keyboard.press('Escape');
        await expect
          .poll(() => menu.evaluate((node) => node === document.activeElement))
          .toBe(true);
        for (const handle of handles.values()) await handle.dispose();
      }
      expect(errors).toEqual([]);
      // Collect every family/runtime sample before reporting clipping debt.
      expect(ringFailures, 'Prototype focus rings must fit all real clipping boundaries').toEqual(
        []
      );
    } catch (error) {
      if (stage === 'family-commit') {
        familyCommitTiming.finishedMs = performance.now();
        familyCommitTiming.outcome = 'rejected';
        familyCommitTiming.rejectionSnapshot = familyCommitCalls.map((call) => ({ ...call }));
      }
      await finishFamilyQueryObservation();
      await collectFamilyMutation();
      const failureState = await page
        .evaluate(() => {
          const header = document.querySelector<HTMLElement>('[data-homepage-runtime]');
          const demo = document.querySelector<HTMLElement>('[data-home-showcase]');
          const trigger = header?.querySelector<HTMLElement>(
            '[data-projection-control="family"] [role="combobox"]'
          );
          const portalId = trigger?.getAttribute('aria-controls');
          const portal = portalId ? document.getElementById(portalId) : null;
          const sample = (element: HTMLElement | null | undefined) =>
            element
              ? {
                  tag: element.tagName,
                  id: element.id,
                  connected: element.isConnected,
                  dataset: { ...element.dataset },
                  busy: element.getAttribute('aria-busy'),
                  hidden: !!element.closest('[hidden], [inert]'),
                }
              : null;
          return {
            header: sample(header),
            showcase: sample(demo),
            status: header?.querySelector('[data-homepage-runtime-status]')?.textContent,
            transaction: (
              header as HTMLElement & { __homepageRuntime__?: { getSnapshot(): unknown } }
            )?.__homepageRuntime__?.getSnapshot(),
            generations: Array.from(
              header?.querySelectorAll<HTMLElement>('[data-projection-generation-state]') ?? []
            ).map(sample),
            familyTrigger: sample(trigger),
            familyValue: trigger?.textContent,
            portal: sample(portal),
          };
        })
        .catch((captureError) => ({ captureError: String(captureError) }));
      await save('failure', {
        stage,
        message: String(error),
        familyCommitTiming,
        familyMutationTiming,
        records,
        ringFailures,
        errors,
        consoleErrors,
        failureState,
      });
      throw error;
    } finally {
      if (family === 'brutalist') await finishFamilyQueryObservation();
      await writeFile(
        path.join(evidenceDirectory, `${family}-lifecycle.json`),
        JSON.stringify(
          {
            source,
            family,
            records,
            ringFailures,
            errors,
            consoleErrors,
            familyCommitTiming,
            familyMutationTiming,
          },
          null,
          2
        )
      );
      if (family === 'brutalist') {
        console.info(
          '[family-commit-poll-timing]',
          JSON.stringify({ source, familyCommitTiming, familyMutationTiming })
        );
      }
      let contextCloseSucceeded = false;
      try {
        await context.close();
        contextCloseSucceeded = true;
      } finally {
        try {
          familySDK?.disposeAfterContextClosed(contextCloseSucceeded);
          if (familySDK)
            await settleFamilyQueryBatch(
              [
                writeFile(
                  path.join(evidenceDirectory, `${family}-sdk-timing.json`),
                  JSON.stringify({ source, family, observation: familySDK.snapshot() }, null, 2)
                ),
              ],
              2000
            );
        } catch (error) {
          noteQueryError(error);
        }
        if (utilityObservation && familyQueryObservation.cleanupDeferredUntilContextClose) {
          try {
            familyQueryObservation.utility =
              await utilityObservation.disposeIncompleteCapture(contextCloseSucceeded);
          } catch (error) {
            noteQueryError(error);
          }
        }
        if (family === 'brutalist') {
          try {
            const report = {
              source,
              family,
              ...familyQueryObservation,
              referenceCountAtReport: familyQueryRequests.length,
              pendingObservedAtReport: familyQueryRequests.filter(
                ({ call }) => call.returnedMs === undefined
              ).length,
              droppedNodeRows: familyCommitTiming.droppedCalls,
              captureCoversAllRecordedQueries:
                !familyQueryObservation.ledgerError &&
                familyQueryObservation.issuedAfterDrain === 0 &&
                familyQueryObservation.wait.completeAtDrainPoint &&
                familyQueryObservation.wait.droppedOutcomeRows === 0 &&
                familyQueryObservation.droppedPendingRows === 0 &&
                familyCommitTiming.droppedCalls === 0,
            };
            console.info('[family-query-observation]', JSON.stringify(report));
            await writeFile(
              path.join(evidenceDirectory, `${family}-query-observation.json`),
              JSON.stringify(report, null, 2)
            );
          } catch (error) {
            noteQueryError(error);
            try {
              console.info('[family-query-capture-error]', String(error));
            } catch {
              /* Retain original outcome. */
            }
          }
        }
      }
    }
  }, 180_000);
}
