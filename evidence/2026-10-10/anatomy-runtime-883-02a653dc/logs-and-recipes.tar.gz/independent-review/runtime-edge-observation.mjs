import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
const root = process.env.SOURCE_ROOT;
if (!root) throw new Error('SOURCE_ROOT is required');
const { createRuntimeSession } = await import(pathToFileURL(path.join(root, 'packages/runtime/dist/index.js')).href);
const { delay } = await import(pathToFileURL(path.join(root, 'packages/core/dist/index.js')).href);
const unhandled = [];
const onUnhandled = (error) => unhandled.push(error);
process.on('unhandledRejection', onUnhandled);
const observations = [];
function host(name) {
  const tasks = [];
  return {
    prototypeName: name, tasks, getRawProps: () => ({}),
    commit: (_children, signal) => signal?.done(), schedule: (task) => task(),
    scheduleDelay(_duration, task) {
      const rec = { task, cancelled: 0 }; tasks.push(rec);
      return { cancel() { rec.cancelled++; task(); } };
    },
  };
}
for (const [name, cleanupValue] of [['undefined', undefined], ['null', null], ['false', false], ['zero', 0], ['empty', '']]) {
  const h = host('review-failed-created-' + name);
  const creationError = new Error('creation:' + name);
  let state; let cleanupCalls = 0; let staleCalls = 0; let thrown;
  try {
    createRuntimeSession({ name: h.prototypeName, setup(def) {
      state = def.state.bool('flag', false);
      def.lifecycle.onCreated(() => { delay(0, () => staleCalls++); throw creationError; });
      def.lifecycle.onBeforeDispose(() => { cleanupCalls++; assert.equal(state.get(), false); throw cleanupValue; });
    } }, h);
  } catch (error) { thrown = error; }
  assert.ok(thrown instanceof AggregateError);
  assert.equal(thrown.errors.length, 2);
  assert.equal(thrown.errors[0], creationError);
  assert.equal(thrown.errors[1], cleanupValue);
  assert.equal(cleanupCalls, 1);
  assert.equal(h.tasks.length, 1);
  assert.equal(h.tasks[0].cancelled, 1);
  h.tasks[0].task(); assert.equal(staleCalls, 0);
  assert.throws(() => state.get(), /disposed/i);
  observations.push({ case: 'failed-created-falsy-cleanup-' + name, aggregateIdentitiesPreserved: true, cleanupCalls, hostCancels: h.tasks[0].cancelled, staleCalls, stateInvalidated: true });
}
{
  const h = host('review-normal-dispose-diagnostic-reentry');
  const points = ['disposing', 'instance.dispose.begin', 'beforeDispose', 'disposed', 'instance.dispose.done'];
  const failures = points.map((point) => new Error(point));
  const reentrant = []; const events = []; let session; let state; let callbackCalls = 0;
  h.onLifecycleEvent = (event) => {
    const point = event.type === 'instance.phase' ? event.phase : event.type;
    const index = points.indexOf(point);
    if (index >= 0) { events.push(point); reentrant.push(session.dispose()); throw failures[index]; }
  };
  session = createRuntimeSession({ name: h.prototypeName, setup(def) {
    state = def.state.bool('flag', false);
    def.lifecycle.onBeforeDispose(() => {
      callbackCalls++; events.push('beforeDispose'); reentrant.push(session.dispose());
      assert.equal(state.get(), false); throw failures[2];
    });
  } }, h);
  const pending = session.dispose();
  for (const value of reentrant) assert.equal(value, pending);
  assert.equal(session.instancePhase, 'disposed');
  assert.throws(() => state.get(), /disposed/i);
  let caught; try { await pending; } catch (error) { caught = error; }
  assert.ok(caught instanceof AggregateError); assert.deepEqual(caught.errors, failures);
  await session.dispose(); assert.equal(callbackCalls, 1); assert.deepEqual(events, points);
  observations.push({ case: 'normal-dispose-diagnostic-reentry', phases: events, sameCompletion: true, errorOrderAndIdentitiesPreserved: true, callbackCalls, stateInvalidatedSynchronously: true, finalPhase: session.instancePhase });
}
await new Promise((resolve) => setImmediate(resolve));
await new Promise((resolve) => setImmediate(resolve));
assert.equal(unhandled.length, 0);
process.off('unhandledRejection', onUnhandled);
const files = ['packages/runtime/src/instance/session.ts','packages/runtime/dist/instance/session.js','packages/runtime/test/contract/delay.v0.contract.test.ts','packages/adapters/web-component/src/adapt.ts'];
const bindings = files.map((file) => { const bytes = fs.readFileSync(path.join(root, file)); return { path: file, bytes: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex') }; });
console.log(JSON.stringify({ kind: 'independent-disposable-runtime-observation', node: process.version, platform: process.platform, sourceRoot: root, observations, unhandledRejections: unhandled.length, bindings, limitation: 'Local compiled-output observation; no browser, no full-suite or canonical-CI claim.' }, null, 2));
