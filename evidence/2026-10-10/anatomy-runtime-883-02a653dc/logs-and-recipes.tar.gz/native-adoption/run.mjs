import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';import {createServer} from 'node:http';import {createRequire} from 'node:module';import assert from 'node:assert/strict';
const root=process.cwd(), out='/evidence/native-adoption',state=path.dirname(out),require=createRequire(path.join(root,'package.json'));
const {build}=require('esbuild');const {chromium}=createRequire(path.join(root,'apps/www/package.json'))('playwright-core');const sha=b=>createHash('sha256').update(b).digest('hex');
const alias={name:'repo-source',setup(b){b.onResolve({filter:/^@proto\.ui\//},args=>{
const [pkg,...rest]=args.path.slice(10).split('/');let sub=pkg.startsWith('module-')?'modules/'+pkg.slice(7):pkg.startsWith('adapter-')?'adapters/'+pkg.slice(8):pkg.startsWith('prototypes-')?'prototypes/'+pkg.slice(11):pkg.startsWith('compositions-')?'compositions/'+pkg.slice(13):pkg;
const base=path.join(root,'packages',sub,'src'),target=path.join(base,...rest);
for(const p of [path.join(target,'index.ts'),target+'.ts',target+'.tsx',target])if(fs.existsSync(p)&&fs.statSync(p).isFile())return {path:p};
const manifest=JSON.parse(fs.readFileSync(path.join(base,'..','package.json'),'utf8'));
const entry=manifest.exports?.['./'+rest.join('/')];const exported=typeof entry==='string'?entry:entry?.import??entry?.default??entry?.types;
if(exported){const source=path.resolve(base,'..',exported.replace('./dist/','./src/').replace(/\.d\.ts$/,'.ts').replace(/\.js$/,'.ts'));if(fs.existsSync(source))return {path:source};}
throw new Error('Unresolved actual source '+args.path);
});}};
const sources=new Map([['packages/runtime/src/instance/session.ts','original-session.ts'],['packages/adapters/web-component/src/adapt.ts','original-adapt.ts']]);
const variants={};
for(const variant of ['baseline','candidate']){
 const overlay={name:'fixed-baseline-inputs',setup(b){if(variant==='baseline')b.onLoad({filter:/\.(?:ts|tsx)$/},args=>{const rel=path.relative(root,args.path);const saved=sources.get(rel);if(saved)return {contents:fs.readFileSync(path.join(state,saved),'utf8'),loader:'ts'};});}};
 const result=await build({absWorkingDir:root,entryPoints:[path.join(out,'entry.ts')],bundle:true,write:false,platform:'browser',format:'iife',target:['es2020'],plugins:[overlay,alias],metafile:true,logLevel:'silent'});
 const js=result.outputFiles[0].contents;fs.writeFileSync(path.join(out,variant+'.js'),js);
 const inputs=Object.keys(result.metafile.inputs).map(p=>{const abs=path.resolve(root,p);const rel=path.relative(root,abs);const saved=variant==='baseline'?sources.get(rel):undefined;const bytes=fs.readFileSync(saved?path.join(state,saved):abs);return {path:rel,sha256:sha(bytes),baselineOverlay:!!saved};});variants[variant]={bundleSha256:sha(js),inputs};
}
fs.writeFileSync(path.join(out,'source-binding.json'),JSON.stringify({baseline:'ea19727838d85c05af5e4bca8d5fc235cb44e288',candidate:'current dirty 3-file candidate; recorded source hashes',variants},null,2)+'\n');
const server=createServer((req,res)=>{if(req.url==='/bundle.js'){res.setHeader('content-type','text/javascript');res.end(fs.readFileSync(path.join(out,server.variant+'.js')));return;}res.setHeader('content-type','text/html');res.end('<!doctype html><meta charset="utf-8"><title>Base Collapsible ownership observation</title><style>body{font:16px system-ui;margin:32px;background:#fff;color:#171717}main{display:grid;grid-template-columns:1fr 1fr;gap:24px}section{border:1px solid #aaa;padding:20px;min-height:180px}h2{font-size:20px;margin:0 0 20px}x-883-trigger{cursor:pointer;padding:10px;border:1px solid #444;margin:8px 0}x-883-content{padding:12px;background:#edf2f7;margin-top:12px}</style><h1>Base Collapsible</h1><main></main><script src="/bundle.js"></script>');});await new Promise(r=>server.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+server.address().port;
const browser=await chromium.launch({executablePath:'/browser/Chrome',headless:true});const results=[];
try{for(const variant of ['baseline','candidate']){server.variant=variant;
 for(const scenario of ['trigger','content','detached-content']){const ctx=await browser.newContext({viewport:{width:1100,height:700},colorScheme:'light'});const page=await ctx.newPage();
 try{await page.goto(url,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.probe?.ready);
 await page.evaluate(({scenario})=>{const p=window.probe;const a=p.create('source',scenario!=='trigger'),b=p.create('destination',false);document.querySelector('main').append(a.panel,b.panel);p.a=a;p.b=b;}, {scenario});
 await page.waitForFunction(()=>window.probe.a.r.getExposes().partCount('trigger')===1&&window.probe.b.r.getExposes().partCount('content')===1);
 await page.evaluate(()=>{const p=window.probe;p.identity={a:p.a.t.getExposes().expanded,content:p.a.c.getExposes().open};});
 if(scenario==='detached-content'){await page.evaluate(()=>window.probe.b.r.getExposes().present(false));await page.waitForFunction(()=>window.probe.b.r.hasAttribute('data-pui-view-detached'));}
 const snapshot=()=>page.evaluate(()=>{const p=window.probe;return {sourceTrigger:p.a.r.getExposes().partCount('trigger'),sourceContent:p.a.r.getExposes().partCount('content'),destinationTrigger:p.b.r.getExposes().partCount('trigger'),destinationContent:p.b.r.getExposes().partCount('content'),sourceOpen:p.a.r.getExposes().open.get(),destinationOpen:p.b.r.getExposes().open.get(),sourceExpanded:p.a.t.getExposes().expanded.get(),sourceContentOpen:p.a.c.getExposes().open.get(),sourceIdentity:p.a.t.getExposes().expanded===p.identity.a,contentIdentity:p.a.c.getExposes().open===p.identity.content,destinationDetached:p.b.r.hasAttribute('data-pui-view-detached'),errors:[...p.observed],inputs:[...p.input],changes:[...p.changes]};});
 const before=await snapshot();await page.screenshot({path:path.join(out,variant+'-'+scenario+'-before.png')});
 await page.evaluate(({scenario})=>{const p=window.probe;p.b.r.append(scenario==='trigger'?p.a.t:p.a.c);}, {scenario});
 // Let native Custom Element reactions and MutationObservers complete; no synthetic event or expected state is injected.
 await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));const rejected=await snapshot();await page.screenshot({path:path.join(out,variant+'-'+scenario+'-rejected.png')});
 let activated=null;if(scenario==='trigger'){await page.locator('#source-trigger').click();await page.evaluate(()=>new Promise(r=>requestAnimationFrame(r)));activated=await snapshot();await page.screenshot({path:path.join(out,variant+'-'+scenario+'-activation.png')});}
 const accepted=variant==='candidate'?rejected.sourceTrigger===1&&rejected.sourceContent===1&&rejected.destinationTrigger===1&&rejected.destinationContent===1&&rejected.sourceIdentity&&rejected.contentIdentity&&rejected.errors.some(e=>e.code==='COLLAPSIBLE_DUPLICATE_PART'):null;
 results.push({variant,scenario,before,rejected,activated,accepted});if(variant==='candidate'){assert.equal(accepted,true,scenario);if(activated){assert.equal(activated.sourceOpen,true);assert.equal(activated.destinationOpen,false);assert.ok(activated.inputs.some(i=>i.trusted));}}
 }finally{await ctx.close();}}
}}finally{fs.writeFileSync(path.join(out,'observations.json'),JSON.stringify({browser:browser.version(),viewport:{width:1100,height:700},theme:'light',input:'Native DOM composition moves plus actual Playwright pointer click; native ErrorEvents captured/preventDefault and retained',results},null,2)+'\n');await browser.close();await new Promise(r=>server.close(r));}
console.log(JSON.stringify({baseline:results.filter(r=>r.variant==='baseline').map(r=>({scenario:r.scenario,source:[r.rejected.sourceTrigger,r.rejected.sourceContent],destination:[r.rejected.destinationTrigger,r.rejected.destinationContent],errors:r.rejected.errors})),candidate:results.filter(r=>r.variant==='candidate').map(r=>({scenario:r.scenario,accepted:r.accepted})),browser:browser.version()}));
