import { definePrototype } from '@proto.ui/core';
import { AdaptToWebComponent, setElementProps } from '@proto.ui/adapter-web-component';
import { asCollapsibleRoot, collapsibleTrigger, collapsibleContent, COLLAPSIBLE_FAMILY } from '@proto.ui/prototypes-base/collapsible';
const root = definePrototype({name:'x-883-root',setup(def){
  asCollapsibleRoot(); let run:any;
  def.lifecycle.onCreated(value=>{run=value;});
  def.expose.method('partCount',(role:string)=>run.anatomy.partsOf(COLLAPSIBLE_FAMILY,role).length);
  def.expose.method('present',(value:boolean)=>run.lifecycle.setPresent(value));
}});
AdaptToWebComponent(root);
AdaptToWebComponent(collapsibleTrigger,{registerAs:'x-883-trigger'});
AdaptToWebComponent(collapsibleContent,{registerAs:'x-883-content'});
const observed:any[]=[];const input:any[]=[];const changes:any[]=[];
addEventListener('error',(event)=>{observed.push({message:event.message,code:event.error?.code??null});event.preventDefault();});
document.addEventListener('click',event=>input.push({trusted:event.isTrusted,target:(event.target as Element)?.id}));
function create(id:string,open:boolean){
  const panel=document.createElement('section');const heading=document.createElement('h2');heading.textContent=id==='source'?'Source disclosure':'Destination disclosure';
  const r=document.createElement('x-883-root') as any;r.id=id;setElementProps(r,{defaultOpen:open});
  const t=document.createElement('x-883-trigger') as any;t.id=id+'-trigger';t.textContent=id==='source'?'Source trigger':'Destination trigger';
  const c=document.createElement('x-883-content') as any;c.textContent=id==='source'?'Source content':'Destination content';
  r.addEventListener('openChange',(event:CustomEvent)=>changes.push({owner:id,detail:event.detail,trusted:event.isTrusted}));
  r.append(t,c);panel.append(heading,r);return {panel,r,t,c};
}
(window as any).probe={observed,input,changes,create,ready:true};
