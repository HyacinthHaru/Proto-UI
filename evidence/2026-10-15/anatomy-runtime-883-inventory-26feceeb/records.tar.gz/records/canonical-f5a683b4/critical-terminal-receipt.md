# f5 canonical 一次终态快照

准确 `f5a683b44b1ad0ffec22cb882cff7b5253dc47e1` / tree `4e886b166b11acbef61377974f610f5a33284479`。读取窗 2026-10-15 06:19:54–06:20:04 UTC，没有后续轮询。human-assisted / partial / ABSTAIN。

| 项目 | 实际结果 | 边界 |
| --- | --- | --- |
| Field38691011574 / job116276675818 | 25pass | 官方async-trace目录开启；没有下载trace，不写成默认无观测器Linux覆盖。 |
| Coll38691011649 / job116276676386 原36 | 32pass /4fail | 四个Liquid narrow 320.4375>320，第584行；本次没有原60s timeout。 |
| Coll后续独立诊断 | 8pass /36原case skipped | 与原36分开；不能由本次通过宣布旧dataLoss原因修复。 |
| Finf Forms38691011313 / job116276696170 | 10pass /2fail | 原597颜色断言；两JSON的pageErrors/captureErrors都[]。Finf其他job仍未全终态。 |
| Main CI38691011417 | completed FAILURE，15jobs：11success/2failure/2skipped | test-plan先失败；general与browser均SKIPPED，没有本次普通测试或八分片计数。 |

新明确阻碍是test-plan job116276675999：`Browser inventory mismatch: unregistered=apps/www/src/content/docs/zh-cn/demo-liquid-glass-hover.browser.test.ts; missing=`，抛于`runtime-test-plan.mjs:280`。准确源码对账：该hover browser file在680不存在、a62与f5逐字相同；inventory模块680/a62/f5也逐字相同。因此为新基础的inventory登记缺口，不是已复现的C产品行为失败。本次未更改任何源码/断言。

Field/Coll/Forms日志实际checkout都是f5；plan为synthetic `6565603d6a7fcaec77598229e66882f5ac1ad1d2`，GitHub Git commit API确认tree严格等于f5。四日志均打印Node24.21.0。Forms artifact11951669978为3,146,279bytes/72members，SHA`efb004e614f8f3844481d6d5ddc10409bdc22082aea627a64bcb1e460353bc11`，已核官方size/digest且仅提两JSON。它记录Chrome155.0.8059.39，先前d591是154.0.8037.97；此版本差异只记录，不归因。

Forms当前provider数组为空不证明旧070的两条base-field error已修。Coll本次8诊断通过也不解释旧3/5或8dataLoss。不得将d591的78docs gate与八分片结果转标为f5；本次在更早test-plan停止。

[完整机器收据](critical-terminal-receipt.json)含每份rawlog hash、准确checkout及源码对账。两个一次性网络脚本均终态exit0，没有新测试/浏览器/构建或任何外部写入。d591原报告和冻结证据保持不变。
