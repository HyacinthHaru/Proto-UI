# a62 → f5 组合与 C 边界只读审查

限定结论：**0 个新增具体 C 源回归/保留丢失 finding**；仍为 human-assisted、unassessed advisory、partial / ABSTAIN。合并保留不等于接受全部上游功能，实际 CLI 与 release BOM 阻断未消失。

准确签名提交 `f5a683b44b1ad0ffec22cb882cff7b5253dc47e1` / tree `4e886b166b11acbef61377974f610f5a33284479`，parents 为 d591 与 a62。已独立逐条比较 **11,179 mode/kind/blob**：原 own18 与 incoming54 零交集，完整 union 精确，所有非 incoming 路径等于 d591，包括旧 C、Overlay、Field、Toggle Group、Calendar 与 Drawer。签名验证 exit0，Author/Committer 均 HyacinthHaru / hyacinth@haru.ac，DCO 存在，无 coauthor。

新基础并非仅画面：Base Accordion/Collapsible/Select/Dropdown/Toggle 增加 press.cancel 清理，Toggle/Dropdown 补 view unmount 瞬态退休；上游 56 个 real Runtime 控制覆盖两种受控模式、7 个 part、3 种 cancel 与未预先 cancel 的 unmount/remount，检查逻辑值/请求数/State handle identity 保留。它已实际进入组合选择，56/56 通过。未将 HappyDOM 的 Web router 合成输入称为真实浏览器。新 Liquid 六命令只借用 Base states；静态 hover、press、focus、disabled、Accordion blocked 与既有 pointer self-contact 的边界保留，draft P/C/T 未升格。旧 d591 原 25/36 native 不重标为当前组合。

真实组合日志是 **76 files：75 pass、1 fail；1311 tests pass、1 fail**。原 C67 合计1116全过，Liquid interactive31/31、fixture11/11亦在日志中。唯一失败为 CLI exhaustive scanner 的 blind-list 断言；它仍是 gate failure。报错路径与 own18 零交集，三个 own prototype source 也不匹配其 rule-word 输入过滤；没有独立运行 a62 对照，故不把“继承失败”冒充执行结论。

准确 f5 的 postcommit local 已有 types908/0 errors/0 warnings/13 hints，47/47 build、47 manifests、4 PASS/5 ADVISORY；preset/Agent projection receipts 均 exit0 且未改变 tracked bytes。**原 pnpm test 则在 release:assets:check 的 BOM stale exit1，尚未进入后续测试**；这不是 d591 官方 general 的 public-docs78 首阻断。

BOM 的具体原因已静态对账：47 个包集合没有改变，但已记录 BOM 少 `adapter-base → module-positioning` 和 `module-feedback → module-state` 两条 manifest workspace 依赖，随后有20个 publishOrder 不同。包括59个扫描层级 manifest、generator/lib、governance、VERSION、formatter/lock 等 70 个输入，在 680/d591/a62/f5 四个固定对象中逐 blob 相同。故这是准确基础已有的 release metadata 欠账，不是本 C 原型修复引入的依赖。该判断来自读取数据/算法，不是重新执行 foundation test。应由 release 所有者通过原生成器更新并评审 BOM；本次没有修改生成文件或放宽任何 gate。

本报告没有运行测试、浏览器、构建或外部写入；没有完整审查新917行 native hover suite 的光学行为，未对当前新 native 句柄或平台审批作结论。
