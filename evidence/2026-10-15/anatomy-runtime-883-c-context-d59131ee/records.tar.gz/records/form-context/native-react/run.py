from pathlib import Path
import subprocess,os,json,datetime,hashlib,signal,re
p=Path(__file__).parent;w=Path('<SOURCE_ROOT>');o=p/'run-1';o.mkdir(exist_ok=False);a=o/'artifacts';a.mkdir();sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
env=os.environ.copy();env['PATH']="<REDACTED_PATH>";assert env.get('GITHUB_ACTIONS')!='true' and not env.get('CANDIDATE_SHA');assert not env.get('PROTO_UI_BROWSER_BASE_URL')
env['PUI_FINF_FEATURE_GROUP']='forms';env['PUI_FINF_FEATURE_EVIDENCE_DIR']=str(a)
def git(*x):return subprocess.check_output(['git',*x],cwd=w,text=True).strip()
def inputs():
 result=[]
 for x in git('ls-files').splitlines():
  f=w/x
  if f.is_file() and (x.startswith('packages/') and '/src/' in x or x.startswith('apps/www/') and any(s in x for s in ['/src/','/scripts/','astro.config','package.json'])):result.append({'path':x,'sha256':sha(f.read_bytes()),'bytes':f.stat().st_size})
 return result
before=inputs();(o/'source-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
command=['corepack','pnpm@10.32.1','exec','vitest','run','--config',str(p/'local.config.ts'),'--maxWorkers=1','--minWorkers=1']
rec={'startedAt':now(),'privateLocalDiagnostic':True,'notOfficialWorkflowRun':True,'sourceExtractedFrom':'1a838284516139595308f166ec55928ebc711f8e','physicalHeadBefore':git('rev-parse','HEAD'),'physicalStatusBefore':git('status','--porcelain=v1'),'command':command,'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'pnpm':subprocess.check_output(['corepack','pnpm@10.32.1','--version'],env=env,text=True).strip(),'envScope':{'GITHUB_ACTIONS':env.get('GITHUB_ACTIONS'),'CANDIDATE_SHA':env.get('CANDIDATE_SHA'),'group':'forms','externalBaseURL':False},'testSHA256':sha((p/'local.browser.test.ts').read_bytes()),'configSHA256':sha((p/'local.config.ts').read_bytes()),'outerBudgetSeconds':300,'sourceTrackedInputsBefore':len(before),'processBefore':subprocess.check_output(['ps','-axo','pid=,pgid=,command='],text=True)}
(o/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({k:v for k,v in rec.items() if k!='processBefore'}),flush=True)
with (o/'run.log').open('w') as log:
 child=subprocess.Popen(command,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);rec['childPid']=child.pid
 try:rec['exit']=child.wait(timeout=300)
 except subprocess.TimeoutExpired:
  rec['outerWatchdogExpired']=True;os.killpg(child.pid,signal.SIGTERM)
  try:rec['exit']=child.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);rec['exit']=child.wait(timeout=10)
rec.update(completedAt=now(),physicalHeadAfter=git('rev-parse','HEAD'),physicalStatusAfter=git('status','--porcelain=v1'),logSHA256=sha((o/'run.log').read_bytes()))
after=inputs();(o/'source-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');bm={x['path']:x for x in before};am={x['path']:x for x in after};rec['trackedSourceByteChanges']=[x for x in sorted(set(bm)|set(am)) if bm.get(x)!=am.get(x)]
runtime=a/'local-runtime.json';ports=[]
if runtime.exists():
 data=json.loads(runtime.read_text());rec['runtime']=data;ports=[int(data['baseUrl'].rsplit(':',1)[1])]
else:ports=list({int(x) for x in re.findall(r'http://127\.0\.0\.1:(\d+)',(o/'run.log').read_text())})
rec['ports']=ports;rec['listeningAfter']=[]
for port in ports:
 q=subprocess.run(['lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN'],capture_output=True,text=True);rec['listeningAfter'].append({'port':port,'exit':q.returncode,'output':q.stdout})
(o/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({k:v for k,v in rec.items() if k!='processBefore'}),flush=True)
