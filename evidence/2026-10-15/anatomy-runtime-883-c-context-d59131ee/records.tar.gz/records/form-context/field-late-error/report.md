# Field deferred request after Context error — private candidate

Current review hypothesis [4274326282](https://github.com/Proto-UI/Proto-UI/pull/888#discussion_r4274326282) is reproduced on fixed070 and then on the newer fixed1a838 source. An early public FIELD_CONTEXT subscriber calls validate(); a later subscriber throws one Error. The real ContextCenter drains the queued pending transition and the early call has already returned a live request ID. Field's outer publish() then leaves completed=false and clears its deferred emitter, so no validationRequest reaches the owner although pending is true and resolving the current request still succeeds.

Authority is draft C-FIELD-0001-ASYNC/OWNERSHIP, draft T-FIELD-VALIDATION-INTERRUPTIONS-0001-CASE-PUBLICATION and draft C-CONTEXT-0010-F/G/H. The owning change is Field Root publication completion. ContextCenter's existing finite-drain/error policy already works and is not edited. No stable admission, global order or API change is claimed.

The minimal Root patch removes the completed-success gate. The outermost finally still takes and clears the deferred closure, then invokes it; its existing captured-run and exact-pending guards suppress retired work. The original later-subscriber Error still propagates with identical identity. The two formal controls reuse the existing RuntimeSession helper and real Field Root/Control with its synthetic TextControl host. All assertions are outside subscriber callbacks, and callback-scope results are assigned to local variables rather than relying on the public void return.

Exact newer-base pair uses one identical formal test SHA `bde43260a1d953f920806af28cc2543d1f516a7560a40bf7267267e13bdb2c8f`: baseline **1 pass /1 fail /96 skipped** → candidate **2 pass /96 skipped**. Both load395 tracked inputs from Git1a838, with only FieldRoot changed between the pair. Physical worktree was1a838 with the parent's three Toggle edits; the fixed-source loader did not use those edits. Node24.21.0 and pnpm10.32.1 were actually recorded. All parts dispose in reverse order; all probe processes are terminal.

The first private070 experiment also included a raw0 throw expectation. Its truthful results remain **1pass/2fail →2pass/1fail**: the top-level TextControl call does not surface0 on either source, so that extra expectation is not established as a Field requirement. The emitter omission itself changes from[] to[currentID], but no global exception policy is modified and the remaining private assertion is not relabeled green. The formal contribution contains only normal and Error controls.

Files ready for the parent to apply sequentially:

- `root.proto.ts` / `root-candidate.patch`: Root SHA `e640e4ec16dbdde979ad39584b8fd77679b65614e704cce6208e4e7f181b68fa`.
- `formal-field-cases.ts`: two-case snippet SHA `17add9ea9bd0ef9a1c111c58bb3a8a8d76c62329d1833801d1bd37f8796a94a9`; append after the parent's concurrent Toggle additions rather than replacing their file.
- `formal-test-two-controls.patch`: exact patch against the saved070/1a838 original test, SHA `c938da96bc6d5a9fada03094d2fd462c6e1dcda780e3fde9ad9ff4dfbe640c4d`.
- `t-mapping-note.txt`: bounded evidence note for existing CASE-PUBLICATION, not a normative change.
- `source-binding.json` and `report.json`: every loaded tracked input, before/after source labels, all original failures/controls and execution receipts.

This work is a private candidate, human-assisted/current-user and partial/ABSTAIN. No product/index modification, commit, push, external comment or independent approval by this agent. Parent owns integration, formal original-path validation and review. It does not explain the separate Form-page missing-provider observations.
