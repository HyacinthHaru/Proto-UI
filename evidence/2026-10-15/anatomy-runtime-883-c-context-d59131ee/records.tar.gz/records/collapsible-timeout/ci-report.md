完整分页/官方原日志/两artifact已取回并绑定：070原36=32pass4timeout；e036原36=31pass5fail（WCtimeout+四Liquid320px/200% geometry.right320.4375>320）。两轮后续8诊断均dataLoss，不complete。partial / ABSTAIN。

070 WC的60s参考点在原previewer.screenshot区间59.386598–65.064746s；React/Vue/Vue2却仍在native-journey，不能归成共同PNG原因。e036 WC在60s时已过capture，位于runtime-switch56.445610–67.236269s；三框架journey分别约54.006/51.638/50.637s结束。late callback及上下文重叠不改变timeout结果或证明共同根因。

实际页面toolbar=true，走本地Runtime Tabs和waitForRuntimeAt；Header只是假定false备用。若需要一次最小细分，应围原toolbar-read、visiblewait、role-read、Tabclick、previewer-id和20s readiness await加Node记录，复用原返回值，不加browserRPC。新e036 material scene/provider/program/portal源码确在相关source链并改变面积/布局/资源工作，但未有隔离因果或cachehit证据。窄屏错误先记录原Root/Content标签及已有geometry，不能放宽断言或直接归C/B。

未运行测试/browser/build/CI，未修改产品、timeout/buffer/guard或外部写入。所有原hash、阶段细表、lossy诊断范围及准确源绑定见ci-report.json与相邻raw文件。
