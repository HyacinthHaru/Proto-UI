import os,pathlib,json,hashlib,subprocess,datetime
root=pathlib.Path('<checkout>'); out=pathlib.Path('<evidence-output>/dialog-exact-e88a630a');out.mkdir(exist_ok=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='e88a630aa3eb3a272851f2b5b8ee5c4b157092f2'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
probe=root/'apps/www/src/content/docs/zh-cn/dialog-available-space.browser.test.ts'
env=os.environ.copy();env['PATH']='<task-state>/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:/opt/homebrew/bin:'+env['PATH'];env['CHROME_PATH']='<task-state>/proto-ui-883/continue-20261023T123632Z/browser-source/cache/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
env.update(PROTO_UI_DIALOG_INTEGRITY_PATH=str(out/'runner-integrity.json'),PROTO_UI_DIALOG_JSON_PATH=str(out/'vitest.json'),PROTO_UI_DIALOG_PROBE_SHA='e88a630aa3eb3a272851f2b5b8ee5c4b157092f2',PROTO_UI_DIALOG_SUBJECT='candidate',PROTO_UI_RUNTIME_EVIDENCE_DIR=str(out))
cmd=['corepack','pnpm@10.32.1','exec','vitest','run','--no-file-parallelism',str(probe.relative_to(root)),'--reporter=./scripts/test/dialog-run-integrity-reporter.mjs','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')]
receipt=dict(startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=cmd,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),probeSha256=hashlib.sha256(probe.read_bytes()).hexdigest(),originalAssertionPreserved=True,outerResourceBoundSeconds=1080,platform=os.uname().machine)
(out/'executed-probe.ts').write_bytes(probe.read_bytes());(out/'receipt.json').write_text(json.dumps(receipt,indent=2))
with (out/'browser.log').open('w') as log:
 try: r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1080);receipt['exitCode']=r.returncode
 except subprocess.TimeoutExpired: receipt['outerTimeout']=True
receipt['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
