import os,pathlib,json,hashlib,subprocess,datetime
root=pathlib.Path('<checkout>');out=pathlib.Path('<evidence-output>/sidebar-exact-e88a630a');out.mkdir(parents=True,exist_ok=True)
probe=root/'apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert head=='e88a630aa3eb3a272851f2b5b8ee5c4b157092f2';assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
env=os.environ.copy();env['PATH']='<task-state>/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:/opt/homebrew/bin:'+env['PATH'];env['CHROME_PATH']='<task-state>/proto-ui-883/continue-20261023T123632Z/browser-source/cache/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
env.update(PROTO_UI_DIALOG_INTEGRITY_PATH=str(out/'runner-integrity.json'),PROTO_UI_DIALOG_JSON_PATH=str(out/'vitest.json'),CANDIDATE_SHA=head,PROTO_UI_RUNTIME_EVIDENCE_DIR=str(out))
cmd=['corepack','pnpm@10.32.1','exec','vitest','run','--no-file-parallelism',str(probe.relative_to(root)),'-t','uses real family Contents Buttons','--reporter=./scripts/test/dialog-run-integrity-reporter.mjs','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')]
r=dict(startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=cmd,head=head,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),sourceSha256=hashlib.sha256(probe.read_bytes()).hexdigest(),originalAssertionsAndDeadlines=True,reporter='Existing shared process-integrity reporter, unchanged. Its historical environment variable names contain DIALOG; the actual tracked test path is Homepage Contents.')
(out/'executed-test.ts').write_bytes(probe.read_bytes());(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
with (out/'browser.log').open('w') as log:
 try:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450);r['exitCode']=p.returncode
 except subprocess.TimeoutExpired:r['outerTimeout']=True
r['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
