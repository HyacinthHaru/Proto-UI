from pathlib import Path
import re, subprocess, hashlib, json
s=Path(__file__).parent
root=Path('<checkout>')
file=root/'apps/www/src/content/docs/zh-cn/ui-libraries/shadcn/button.mdx'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='ebce9feae890d8b9b318e1da82611331ceeb0e19'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
original=file.read_bytes()
diagnostic,count=re.subn(rb'^<CodeExample [^\n]+ />\n', b'', original, flags=re.M)
assert count==7
assert not (s/'sidebar-doc-control-ebce9fea').exists()
source=(s/'run-sidebar-main.py').read_text().replace('sidebar-main-ebce9fea','sidebar-doc-control-ebce9fea')
source=source.replace("assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()", "assert subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()==['apps/www/src/content/docs/zh-cn/ui-libraries/shadcn/button.mdx']")
p=s/'run-sidebar-doc-control-inner.py'
p.write_text(source)
try:
 file.write_bytes(diagnostic)
 subprocess.run(['python3',str(p)],cwd=root,check=True)
finally:
 assert file.read_bytes()==diagnostic
 file.write_bytes(original)
out=s/'sidebar-doc-control-ebce9fea'
(out/'executed-page.mdx').write_bytes(diagnostic)
(out/'intervention.json').write_text(json.dumps(dict(baseHead='ebce9feae890d8b9b318e1da82611331ceeb0e19',onlyChange=str(file.relative_to(root)),originalSha256=hashlib.sha256(original).hexdigest(),diagnosticSha256=hashlib.sha256(diagnostic).hexdigest(),removedCodeExamples=count,restoredOriginal=True,diagnosticOnly=True),indent=2)+'\n')
