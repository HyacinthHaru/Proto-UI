from pathlib import Path
import hashlib, json, os, subprocess, datetime
root = Path('<checkout>')
out = Path(__file__).parent / 'sidebar-profile-ebce9fea'
out.mkdir()
test = root / 'apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts'
probe = test.with_name('contents-nov09-diagnostic.browser.test.ts')
head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=root,text=True).strip()
assert head == 'ebce9feae890d8b9b318e1da82611331ceeb0e19'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
source = test.read_text()
def replace(before, after):
    global source
    assert source.count(before) == 1
    source = source.replace(before, after)
replace('          const transitionStartedAt = Date.now();', '''          const profileSession =
            family === 'shadcn' && runtime === 'react' ? await context.newCDPSession(page) : null;
          if (profileSession) {
            await profileSession.send('Profiler.enable');
            await profileSession.send('Profiler.setSamplingInterval', { interval: 500 });
            await profileSession.send('Profiler.start');
          }
          const transitionStartedAt = Date.now();''')
replace("              path.join(directory, `${family}-${runtime}-transition.json`),", """              path.join(directory, `${family}-${runtime}-transition.json`),""")
replace("          if (originalError) throw originalError;\n          expect(await root.getAttribute('data-contents-family'))", """          if (profileSession) {
            const { profile } = await profileSession.send('Profiler.stop');
            await writeFile(path.join(directory, 'shadcn-react.cpuprofile'), JSON.stringify(profile));
            await profileSession.detach();
          }
          if (originalError) throw originalError;
          expect(await root.getAttribute('data-contents-family'))""")
env = os.environ.copy()
env['PATH'] = '<task-state>/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:/opt/homebrew/bin:' + env['PATH']
env['CHROME_PATH'] = '<task-state>/proto-ui-883/continue-20261023T123632Z/browser-source/cache/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
env.update(PROTO_UI_DIALOG_INTEGRITY_PATH=str(out/'runner-integrity.json'),PROTO_UI_DIALOG_JSON_PATH=str(out/'vitest.json'),CANDIDATE_SHA=head,PROTO_UI_RUNTIME_EVIDENCE_DIR=str(out))
cmd = ['corepack','pnpm@10.32.1','exec','vitest','run','--no-file-parallelism',str(probe.relative_to(root)),'-t','uses real family Contents Buttons','--reporter=./scripts/test/dialog-run-integrity-reporter.mjs','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')]
receipt = dict(baseHead=head, command=cmd, originalSha256=hashlib.sha256(test.read_bytes()).hexdigest(), diagnosticSha256=hashlib.sha256(source.encode()).hexdigest(), originalAssertionsAndDeadlines=True, diagnostic='Profiler before Shadcn React click, stop after original verdict/late observation. Only this disposable test file differs. Profiler can perturb timings.', startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'executed-test.ts').write_text(source)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
with probe.open('x') as f:
    f.write(source)
try:
    with (out/'browser.log').open('w') as f:
        receipt['exitCode'] = subprocess.run(cmd, cwd=root, env=env, stdout=f, stderr=subprocess.STDOUT,timeout=450).returncode
except subprocess.TimeoutExpired:
    receipt['outerTimeout'] = True
finally:
    assert probe.read_text() == source
    probe.unlink()
    receipt['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
