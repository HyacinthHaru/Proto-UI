# #549 browser refresh at 17a2cff9

All six full probes **actually ran on 2026-09-29** at frozen HEAD `17a2cff98080eb57f9070a6f45d89b58d3a72c3f`, tree `a46d21801fc0e32b1a3f807f9c567a44e1b08d63`. The sequential wrapper began at **15:10:41.067 UTC** and finished at **15:11:21.412 UTC**. All **324/324 checks passed**, with no fixture execution failure, page error, console warning/error, source-binding mismatch or nonzero exit. Browser/build processes ended before the heavy slot was returned to root; subsequent work only read captured evidence.

These are new executions of the recovered, unchanged final harness. They are not a redating or input-equivalence reuse of the old fd9 runs. Old baselines and historical failures remain in the formal evidence branch, with their original source/time bindings.

## Results and actual inputs

| Probe | Full scope retained | Checks | PNGs reviewed | AX captures reconciled |
| --- | --- | ---: | ---: | ---: |
| Ownership | All 18 original cases | 218/218 | 0, internal host-contract fixture | 75 |
| Actual WC Tabs | All five original scenarios | 21/21 | 11 | 11 |
| Actual React Tabs | All five original scenarios | 21/21 | 11 | 11 |
| Actual Vue 3 Tabs | All five original scenarios | 21/21 | 11 | 11 |
| Actual Vue 2 Tabs | All five original scenarios | 21/21 | 11 | 11 |
| Generic actual WC family | All original public-prop/host-control steps | 22/22 | 13 | 13 |

The ownership count includes **141 contract observations and 77 fixture execution controls**. Normal page/console controls do not create a general exception/silence policy. The scenarios, assertions, per-probe input order and time parameters were unchanged. No case-selection override, retry, additional recovery update or broad sleep was introduced.

Actual environment in every provenance: **Node 22.23.2, zlib 1.3.1-e00f703, esbuild 0.25.12, Playwright core 1.58.2, Chrome 153.0.8010.53, macOS arm64**. Installed framework manifests bind React/React DOM 19.2.6, Vue 3.5.31 and Vue 2.6.14. Source roots stayed clean at the frozen HEAD/tree throughout all six runs.

The preparation bound **6,807 tracked files**, including actual working bytes versus HEAD Git blobs. Every actual bundle input was then checked against its recorded end bytes; tracked inputs also matched the prepared source and HEAD blob. The six actual metafiles contain **315 distinct tracked inputs** with no cross-run hash differences. Every probe now includes one new tracked input relative to its old run: `packages/adapters/base/src/platform/focus-order.ts`. Seven prior tracked inputs changed for ownership/WC/generic and nine for React/Vue/Vue2. The actual new graph, including these changes, is preserved in each provenance/metafile and in `evidence-audit.json`.

The wrappers record exact executable, args, cwd, environment, output location, start/end head and status in `execution-receipt.json`. They add provenance only. Their source and full adaptation diff are retained under `../browser-refresh-preparation/runner-17a2cff9/`. The seven recovered harness files remain byte-identical to the published final archive; the runner's SHA is `ad74d2abefc904c6d68dc2e6c8002f2007b44a09e834887cf63116bfa71cbbb6`.

## Actual rendered output, AX and input provenance

All **57 new PNGs were individually opened with `view_image`**. Each actual Tabs view has readable selected-trigger styling and panel text, the intentional empty missing-target state, and the two intentionally authored duplicate panels. Generic captures show the two domains, source/target L1 disappearance and return, and physical domain moves. Host ID/key changes can leave the pixels unchanged; they are supported by the captured DOM/AX, not asserted from appearance alone.

All **132 native AX captures** were read and reconciled to their current DOM facts, with **zero mismatches**. Tabs and generic retain DOM fact snapshots; ownership additionally retains complete serialized DOM documents. Every ownership source/target DOM serialization was checked against its checkpoint. Hidden host barriers cause Chrome to omit the operative controls relation until reveal; synchronous before-reveal DOM evidence is distinct from the later AX capture. The ownership controls are intentionally plain internal nodes, so their unnamed native buttons do not stand in for business-UI accessibility acceptance.

After selecting exact key `a b`, all four actual Tabs Adapters show the Space key panel with AX name **Key “a b”**, and the selected trigger controls its unique live target. The old wrong plus-key AX name does not recur. Missing/duplicate matches fail closed without disabling the ordinary selection journey. Every lazy A→B→A journey withdraws the outgoing IDREF and restores the original reserved identity.

Input records contain **36 trusted browser clicks**: six per Tabs Adapter, plus twelve ordinary app-authored generic host-control clicks. WC Tabs also records **six non-trusted semantic CustomEvent deliveries**, which are not counted as extra native clicks. Generic controls invoke public props or explicit host operations. Ownership uses explicit ID/snapshot-epoch/physical-binding host stimuli and real Runtime State replay; it does not claim product-button activation, OS input or a full framework consumer journey.

## D/E timing: new traces, not final-tick inference

The following locations were read from the **new 17a traces**. Indices are zero-based mutation records. Although the deterministic sequences resemble old runs, these references and the timestamps/hashes belong to this execution.

| Actual Tabs Adapter | Outgoing controls withdrawal | Later L1 removal boundary | Return-A ID / labelledBy / controls | Later reveal |
| --- | --- | --- | --- | --- |
| WC | `seq65`, record 34 | Same batch record 37 sets detached | `seq118`, records 60/61/62 | Same batch record 120 removes detached |
| React | `seq70`, record 23 | `seq80`, record 0 removes root child | `seq121`, records 141/142/143 | Same batch record 213 removes pending |
| Vue 3 | `seq66`, record 23 | `seq71`, record 0 starts physical removal | `seq122`, records 2/3/4 | Same batch record 79 removes pending |
| Vue 2 | `seq69`, record 23 | `seq73`, record 1 starts physical removal | `seq118`, records 18/19/20 | `seq120`, record 0 removes pending |

Synchronous Runtime phase observations support the before-reveal interpretation. WC returning Content A epoch 2 has its reciprocal pair at mounting `seq109` and commit start `seq111`, while still detached/`display:none`. React has the pair at mounted `seq120`, still pending/hidden. Vue 3 has it at commit done `seq120`, pending/hidden; Vue 2 at commit done `seq116`, pending/hidden. Framework lifecycle callback names alone are not treated as visibility; the corresponding pending/detached barriers and actual DOM facts determine the claim.

Initial renderer ordering remains explicitly scoped. WC forms the first pair at Content mounting `seq37` before commit start `seq39`. React and Vue 3 may reveal Content before the source gets its semantic binding; once the unique operative pair forms, the Trigger is still pending (`seq40` / `seq44`) and all relationship writes precede its reveal. Vue 2 has both endpoints pending when the pair forms at `seq43`. An earlier absent-source interval is not called an already-valid relationship.

The generic actual WC family adds the source-only L1 and opposite initial endpoint order:

- Target hide: `seq58` records 2/3/4 remove source controls, target labelledBy and target ID, before detached record 5.
- Source hide: `seq75` records 2/3/4 remove target labelledBy, source controls and source ID, before source detached record 5.
- Source-first domain A forms its full pair at target mounting `seq20`, before commit start `seq22`; target-first domain B forms the pair at source mounting `seq44`, before commit start `seq46`.
- Target remount epoch 2 has the pair at mounting `seq66` while detached/none, before commit start `seq68`; `seq71` restores ID/labelledBy/controls at records 20/21/22 before detached removal 47.
- Source remount epoch 2 has the pair at mounting `seq83`, before commit start `seq85`; `seq88` restores source ID/controls and target labelledBy at records 18/19/22 before detached removal 47.

MutationObserver delivery follows mutations. Ordered records and old values, combined with synchronous phase snapshots, support the stated withdrawal/write-before-reveal order. Tabs' saved `newValue` is sampled at batch delivery, not represented as a per-instruction synchronous value. A hidden retained panel is also not equated with L1 detach. Raw queues are retained so those distinctions remain reviewable.

## Ownership and provider K boundaries

All ordinary explicit/generated identity, independent scalar writer, absent-dependent relation and real State-before-observer cases pass. In the State explicit-ID variation, the host write returns at `seq71` with new target ID/old controls; actual State replay has the current pair by `seq74`, before MO `seq76`. Independent takeover returns at `seq73` with controls absent; the normal State replay retains that fail-closed state at `seq76`, before MO `seq78`.

For pending live ID before detach, `seq9` writes the author ID; detach returns at `seq10` with controls absent **before** the fixture hides the target at `seq11`; the new epoch pair exists at `seq16`, before MO/reveal. For pending ID before replacement, the real WC provider setter returns at `seq12` with current `host-later` identity and controls, before MO/reveal. The observer-first alternatives and generated/explicit variants all pass. A genuinely new ID written only after detach is retained while the relation stays fail closed.

The same-epoch K sequence uses the actual WC capability provider and existing `HostSurfaceProjection` setter, not copied projection logic. Target node 4 → 5 has the same reserved identity and complete source relation at provider return `seq11`, while hidden; the old empty ID is restored exactly. Conflicting authored node 6 is preserved and only the lease token is removed at `seq22`. Source node 3 → 7 has its new author token plus lease at `seq65`, with old author contribution preserved. Target epoch 3→4 with unchanged ID invalidates the stale relation at `seq53`; the explicitly refreshed target epoch restores it at `seq59`. Old epochs, null binding, source rebind and retired-target mutation controls also pass.

K is **native-browser internal host-contract evidence** under an explicit host barrier, not an unexecuted production replacement journey in all four frameworks. The actual generic family is separate from this provider fixture.

## Scope retained and limits

The complete original five Tabs scenarios per Adapter, generic steps and eighteen ownership cases were retained. No historical failure output was overwritten. No product or test source was edited. This fresh browser evidence supplements rather than replaces **all seven T cases and six required paths** in `T-A11Y-PART-RELATIONSHIP-0001`.

The six required Runtime/WC/Base/React/Vue/Vue2 test paths and the owning `part-relationships.test.ts` / `web-reference.test.ts` remain root's final validation responsibility. In particular, the maintainer's projector-failure/retry/reentrant notification and AggregateError cases are not forced by ordinary browser journeys; these 324 passing checks do not falsely claim their execution. Complete terminal internal resource counts, portable no-host-data guarantees and all token overlap obligations likewise retain their owning-layer evidence. Closing the browser is not a resource-cleanup proof.

No stable lifecycle admission, independent approval, all-browser/all-platform accessibility claim, full repository test result, budget/CI pass or merge is implied by this report. Old fd9 images/results remain historical, even where unchanged visuals happen to produce the same pixels. No Dialog/#707 or old Matrix diagnostic was rerun.

## Evidence index

- `execution-receipt.json`: six exact commands/environments, actual execution dates, exits, source before/after and input checks.
- `source-binding.json`, `preparation.json`: frozen source binding and prepare-only provenance.
- `runs/<probe>/provenance.json`, `esbuild-metafile.json`: actual toolchain, input graph and hashes.
- `runs/<probe>/results.json`, traces and per-case result files: unchanged original assertions and raw observations.
- `runs/<probe>/visual-review.json`: all 57 individually viewed PNGs and hashes, where screenshots apply.
- `runs/<probe>/ax-review.json`: all 132 AX reconciliations and corresponding DOM facts/checks.
- `evidence-audit.json`: combined results, actual input changes, AX/DOM comparisons and retained timing records.
- `audit-evidence.py`: read-only post-processing source used for the evidence index, separate from the executed browser harness.
- `summary.json`: compact handoff and artifact hashes.
