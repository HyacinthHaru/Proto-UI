import json, hashlib, struct
from pathlib import Path
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
props = lambda n: {p['name']: p['value'] for p in n.get('properties', [])}
receipt = json.loads((root / 'execution-receipt.json').read_text())
old = json.loads((root.parent / 'browser-refresh-preparation/input-comparison.json').read_text())
old_ids = {'wc': 'final-fd9-wc', 'react': 'final-fd9-react', 'vue': 'final-fd9-vue', 'vue2': 'final-fd9-vue2', 'generic-wc': 'final-fd9-generic-wc', 'ownership': 'ownership-native-fd9fc6b4-1'}
old_inputs = {r['run']: {i['path']: i['oldExecutedBlob'] for i in r['inputChecks']} for r in old['runs']}
audit = {'reviewedAt': datetime.now(timezone.utc).isoformat(), 'actualHead': receipt['expectedHead'], 'actualTree': receipt['expectedTree'], 'actualStartedAt': receipt['actualStartedAt'], 'actualFinishedAt': receipt['actualFinishedAt'], 'browserProcessesComplete': receipt['browserProcessesComplete'], 'runs': [], 'ax': [], 'visual': [], 'timing': []}
all_package_inputs = {}
notes = {
 'retained_control-initial': 'Account selected and its panel rendered; all text readable and unclipped.',
 'retained_control-after-B': 'Security selected and its panel rendered; all text readable and unclipped.',
 'retained_control-after-A': 'Account selection and panel restored; readable and unclipped.',
 'lazy-initial': 'Initial lazy Account panel and selected trigger render normally.',
 'lazy-after-B': 'Lazy journey shows the Security panel and selected trigger.',
 'lazy-after-A': 'Lazy return restores the Account panel and selected trigger.',
 'collision-initial': 'Distinct exact-key labels are visible; plus-key trigger/panel selected.',
 'collision-after-B': 'Space-key trigger selected and Space key panel visible; distinct labels remain readable.',
 'missing-initial': 'Existing Account counterpart renders as the positive control.',
 'missing-after-B': 'Missing Security counterpart produces the intentional empty panel area; selected tab remains visible.',
 'duplicate-initial': 'Both intentionally authored Account Content sections render; readable without clipping. Relation ambiguity is checked in DOM/AX, not inferred from appearance.',
 'initial': 'Two generic domain cards render, with opposite endpoint order; all twelve host controls visible.',
 'hide-target': 'Primary details removed; primary source and secondary pair remain.',
 'show-target': 'Primary details restored; both pairs visible.',
 'hide-source': 'Primary source removed while its details and the secondary pair remain.',
 'show-source': 'Primary source restored; both pairs visible.',
 'rekey-target': 'Relationship-only re-key leaves the visible cards unchanged; DOM/AX carry the fail-closed evidence.',
 'rekey-source': 'Matching key restores the relation without a layout change.',
 'move-target': 'Primary target visibly moves into the right domain; primary source stays left.',
 'move-source': 'Primary source joins its target in the right domain; left domain is empty.',
 'host-id': 'Host identity update leaves the visible layout unchanged; DOM/AX carry identity evidence.',
 'add-collision': 'Collision stimulus does not create a visible business failure; relation withdrawal is evidenced by DOM/AX.',
 'remove-collision': 'Collision removal preserves layout; relation recovery is evidenced by DOM/AX.',
 'dispose-target': 'Primary target removed; primary/secondary sources and secondary target remain, with readable controls.',
}

for execution in receipt['runs']:
    ident = execution['id']
    directory = root / 'runs' / ident
    provenance = json.loads((directory / 'provenance.json').read_text())
    result = json.loads((directory / 'results.json').read_text())
    entries = result if isinstance(result, list) else [result]
    checks = [c for entry in entries for c in entry['assertions']]
    tracked = {i['path']: i for i in provenance['sourceInputs'] if i.get('gitBlob')}
    previous = old_inputs[old_ids[ident]]
    for p, item in tracked.items():
        all_package_inputs.setdefault(p, set()).add(item['sha256'])
    run = {'id': ident, 'head': provenance.get('head', provenance.get('gitHead')), 'checks': len(checks), 'passed': sum(c['pass'] for c in checks), 'failures': [c for c in checks if not c['pass']], 'fixtureExecutionFailures': [e.get('executionError') for e in entries if e.get('executionError')], 'pageErrors': sum(len(e.get('errors', [])) for e in entries), 'consoleWarningsAndErrors': sum(len(e.get('consoleMessages', e.get('warnings', []))) for e in entries), 'environment': {k: provenance.get(k) for k in ['node', 'zlib', 'platform', 'arch', 'esbuild', 'playwright', 'chrome']}, 'inputCount': len(provenance['sourceInputs']), 'trackedInputs': len(tracked), 'newTrackedInputs': sorted(tracked.keys() - previous.keys()), 'removedTrackedInputs': sorted(previous.keys() - tracked.keys()), 'changedPriorInputs': [{'path': p, 'oldGitBlob': previous[p], 'newGitBlob': tracked[p]['gitBlob']} for p in sorted(tracked.keys() & previous.keys()) if tracked[p]['gitBlob'] != previous[p]], 'harness': provenance['harness'], 'sourceBindingMismatches': execution['inputMismatches'], 'exitCode': execution['exitCode']}
    audit['runs'].append(run)
    if ident in ['wc', 'react', 'vue', 'vue2']:
        clicks = [click for entry in entries for click in entry['nativeClicks']]
        run.update(trustedClicks=sum(c['isTrusted'] is True for c in clicks), nonTrustedSemanticClicks=sum(c['isTrusted'] is False for c in clicks), traceLimitReached=any(e['traceLimitReached'] for e in entries))
        for entry in entries:
            scenario = entry['scenario']
            for label, state in entry['states'].items():
                stem = scenario + '-' + {'initial': 'initial', 'afterB': 'after-B', 'afterA': 'after-A'}[label]
                ax_path = directory / (stem + '-ax.json')
                ax = json.loads(ax_path.read_text())
                nodes = [n for n in ax['nodes'] if not n.get('ignored')]
                tabs = [n for n in nodes if n.get('role', {}).get('value') == 'tab']
                panels = [n for n in nodes if n.get('role', {}).get('value') == 'tabpanel']
                selected = [n for n in tabs if props(n).get('selected', {}).get('value') is True]
                expected_name = ('Key “a b”' if label == 'afterB' else 'Key “a+b”') if scenario == 'collision' else ('Security' if label == 'afterB' else 'Account')
                expected_panels = [] if scenario == 'missing' and label == 'afterB' else ['Account', 'Account'] if scenario == 'duplicate' else [expected_name]
                names = [n.get('name', {}).get('value') for n in selected]
                panel_names = [n.get('name', {}).get('value') for n in panels]
                controls = [props(n).get('controls') for n in selected]
                expected_controls = not ((scenario == 'missing' and label == 'afterB') or scenario == 'duplicate')
                ok = names == [expected_name] and panel_names == expected_panels and len(selected) == 1 and bool(controls[0] if controls else None) == expected_controls
                audit['ax'].append({'run': ident, 'file': ax_path.name, 'sha256': sha(ax_path), 'selectedNames': names, 'panelNames': panel_names, 'expectedPanelNames': expected_panels, 'selectedControls': controls, 'domFacts': state, 'matches': ok})
        trace = json.loads((directory / 'lazy-trace.json').read_text())['entries']
        evidence = []
        for e in trace:
            if e['source'] == 'mutation-observer':
                records = [{'index': i, **m} for i, m in enumerate(e['detail']) if (m.get('target') in ['trigger-0', 'content-0'] and m.get('attribute') in ['id', 'aria-controls', 'aria-labelledby', 'data-pui-view-pending', 'data-pui-view-detached']) or (m.get('target') == 'root' and m.get('removed', 0))]
                if records:
                    evidence.append({'seq': e['seq'], 'source': e['source'], 'records': records})
            elif e['source'] in ['runtime:content-0', 'runtime:trigger-0'] and e.get('detail', {}).get('type') in ['mount.phase', 'mount.commit.start', 'mount.commit.done', 'unmount.begin']:
                evidence.append({'seq': e['seq'], 'source': e['source'], 'detail': e['detail'], 'sourcePart': e['facts']['parts']['trigger-0'], 'targetPart': e['facts']['parts']['content-0']})
        audit['timing'].append({'run': ident, 'trace': 'lazy-trace.json', 'observations': evidence})
    elif ident == 'generic-wc':
        trace = json.loads((directory / 'trace.json').read_text())
        events = [e for e in trace if e['source'].startswith('native:')]
        run.update(trustedClicks=sum(e['detail']['isTrusted'] is True for e in events), nonTrustedSemanticClicks=sum(e['detail']['isTrusted'] is False for e in events))
        for observation in result['observations']:
            stem = observation['name']
            ax_path = directory / (stem + '-ax.json')
            nodes = [n for n in json.loads(ax_path.read_text())['nodes'] if not n.get('ignored')]
            state = observation['state']
            pairs = []
            for suffix, label in [('A', 'Record one · primary'), ('B', 'Record one · secondary')]:
                source, target = state['source' + suffix], state['target' + suffix]
                sv = source['connected'] and source['display'] != 'none' and source['visibility'] != 'hidden'
                tv = target['connected'] and target['display'] != 'none' and target['visibility'] != 'hidden'
                buttons = [n for n in nodes if n.get('role', {}).get('value') == 'button' and n.get('name', {}).get('value') == label]
                regions = [n for n in nodes if n.get('role', {}).get('value') == 'region' and n.get('name', {}).get('value') == label]
                actual = props(buttons[0]).get('controls', {}).get('value') if buttons else None
                expected = source['controls'] if sv and tv else None
                pairs.append({'pair': suffix, 'buttons': len(buttons), 'regions': len(regions), 'actualControls': actual, 'expectedControls': expected, 'matches': len(buttons) == int(sv) and len(regions) == int(tv and bool(target['labelledBy'])) and actual == expected})
            audit['ax'].append({'run': ident, 'file': ax_path.name, 'sha256': sha(ax_path), 'pairs': pairs, 'domFacts': state, 'matches': all(p['matches'] for p in pairs)})
        audit['timing'].append({'run': ident, 'trace': 'trace.json', 'observations': trace})
    else:
        run['contractObservations'] = sum(c['authority']['kind'] == 'contract-criteria' for c in checks)
        run['fixtureControls'] = sum(c['authority']['kind'] == 'fixture-execution-control' for c in checks)
        for case in entries:
            case_dir = directory / case['caseId']
            for checkpoint in case['checkpoints']:
                label, state = checkpoint['label'], checkpoint['state']
                ax_path = case_dir / (label + '-ax.json')
                dom_path = case_dir / (label + '-dom.html')
                nodes = [n for n in json.loads(ax_path.read_text())['nodes'] if not n.get('ignored')]
                buttons = [n for n in nodes if n.get('role', {}).get('value') == 'button']
                source = next(v for v in state['nodes'].values() if v['nodeId'] == state['currentSource']['nodeId'])
                target = next(v for v in state['nodes'].values() if v['nodeId'] == state['currentTarget']['nodeId'])
                sv = source['connected'] and source['renderedRects'] > 0
                tv = target['connected'] and target['renderedRects'] > 0
                valid = tv and bool(state['targetId']) and state['targetId'] in (state['controls'] or '').split()
                expected = state['controls'] if sv and valid else None
                controls = [props(n)['controls'] for n in buttons if 'controls' in props(n)]
                actual = controls[0].get('value') if len(controls) == 1 else None
                ok = len(buttons) == int(sv) and actual == expected
                if expected is not None:
                    ok = ok and state['targetId'] in [n.get('idref') for n in controls[0].get('relatedNodes', [])]
                dom = dom_path.read_text()
                source_match = not source['connected'] or source['outerHTML'] in dom
                target_match = not target['connected'] or target['outerHTML'] in dom
                audit['ax'].append({'run': ident, 'case': case['caseId'], 'file': str(ax_path.relative_to(directory)), 'sha256': sha(ax_path), 'domSha256': sha(dom_path), 'sourceVisible': sv, 'targetVisible': tv, 'expectedControlsFromDOM': expected, 'actualControls': controls, 'matches': ok and source_match and target_match, 'connectedSourceDOMMatches': source_match, 'connectedTargetDOMMatches': target_match, 'axTiming': checkpoint['axTiming']})
            trace = json.loads((case_dir / 'trace.json').read_text())
            audit['timing'].append({'run': ident, 'case': case['caseId'], 'trace': str((case_dir / 'trace.json').relative_to(directory)), 'observations': trace['trace']})
    visuals = []
    for png in sorted(directory.glob('*.png')):
        width, height = struct.unpack('>II', png.read_bytes()[16:24])
        image = {'run': ident, 'file': png.name, 'sha256': sha(png), 'width': width, 'height': height, 'method': 'Individually opened with view_image during this actual 17a2cff9 run review', 'observation': notes[png.stem], 'visualIssueFound': False}
        audit['visual'].append(image)
        visuals.append(image)
    if visuals:
        (directory / 'visual-review.json').write_text(json.dumps({'actualHead': audit['actualHead'], 'reviewedAt': audit['reviewedAt'], 'images': visuals}, indent=2) + '\n')
    (directory / 'ax-review.json').write_text(json.dumps({'actualHead': audit['actualHead'], 'reviewedAt': audit['reviewedAt'], 'captures': [a for a in audit['ax'] if a['run'] == ident]}, indent=2) + '\n')

audit['axMismatches'] = [a for a in audit['ax'] if not a['matches']]
audit['distinctTrackedInputs'] = len(all_package_inputs)
audit['crossRunInputMismatches'] = [p for p, values in all_package_inputs.items() if len(values) != 1]
audit['summary'] = {'checks': sum(r['checks'] for r in audit['runs']), 'passed': sum(r['passed'] for r in audit['runs']), 'pageErrors': sum(r['pageErrors'] for r in audit['runs']), 'consoleWarningsAndErrors': sum(r['consoleWarningsAndErrors'] for r in audit['runs']), 'trustedClicks': sum(r.get('trustedClicks', 0) for r in audit['runs']), 'wcSemanticClicks': sum(r.get('nonTrustedSemanticClicks', 0) for r in audit['runs']), 'individuallyViewedPNG': len(audit['visual']), 'AXCapturesReconciled': len(audit['ax']), 'AXMismatches': len(audit['axMismatches'])}
(root / 'evidence-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({'summary': audit['summary'], 'distinctTrackedInputs': audit['distinctTrackedInputs'], 'crossRunInputMismatches': audit['crossRunInputMismatches'], 'newInputs': {r['id']: r['newTrackedInputs'] for r in audit['runs']}, 'changedPriorInputCounts': {r['id']: len(r['changedPriorInputs']) for r in audit['runs']}}, indent=2))
