import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { execFileSync, spawnSync } from 'node:child_process';

const here = path.dirname(fileURLToPath(import.meta.url));
const configPath = path.join(here, 'runner-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const sourceRoot = process.env.SOURCE_ROOT && path.resolve(process.env.SOURCE_ROOT);
const outputRoot = process.env.OUTPUT_ROOT && path.resolve(process.env.OUTPUT_ROOT);
const mode = process.argv[2];
if (!sourceRoot || !outputRoot || !['--prepare', '--run'].includes(mode)) {
  throw new Error('Use SOURCE_ROOT, OUTPUT_ROOT, and exactly one mode: --prepare or --run.');
}
if (outputRoot === sourceRoot || outputRoot.startsWith(`${sourceRoot}${path.sep}`)) {
  throw new Error('OUTPUT_ROOT must be outside the product source checkout.');
}
if (Number(process.versions.node.split('.')[0]) !== 22) {
  throw new Error('The repository baseline requires Node 22.');
}
const harnessRoot = path.resolve(here, config.harnessDirectory);
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const git = (...args) =>
  execFileSync('git', ['-C', sourceRoot, ...args], {
    encoding: 'utf8',
    env: { ...process.env, GIT_OPTIONAL_LOCKS: '0' },
  }).trim();
const writeJson = (name, value) =>
  fs.writeFileSync(path.join(outputRoot, name), `${JSON.stringify(value, null, 2)}\n`);
const readJson = (name) => JSON.parse(fs.readFileSync(path.join(outputRoot, name), 'utf8'));

function inspectSource() {
  const head = git('rev-parse', 'HEAD');
  const tree = git('rev-parse', 'HEAD^{tree}');
  const status = git('status', '--short', '--untracked-files=all');
  if (head !== config.expectedHead || tree !== config.expectedTree || status) {
    throw new Error(`Frozen source mismatch: ${JSON.stringify({ head, tree, status })}`);
  }
  const objectFormat = git('rev-parse', '--show-object-format');
  const entries = git('ls-tree', '-r', '-z', head).split('\0').filter(Boolean);
  const files = entries.flatMap((entry) => {
    const tab = entry.indexOf('\t');
    const [fileMode, kind, gitBlob] = entry.slice(0, tab).split(' ');
    const relative = entry.slice(tab + 1);
    if (kind !== 'blob') return [];
    const absolute = path.join(sourceRoot, relative);
    const bytes =
      fileMode === '120000' ? Buffer.from(fs.readlinkSync(absolute)) : fs.readFileSync(absolute);
    const actualBlob = createHash(objectFormat)
      .update(Buffer.from(`blob ${bytes.length}\0`))
      .update(bytes)
      .digest('hex');
    return [
      { path: relative, fileMode, gitBlob, actualBlob, sha256: sha256(bytes), bytes: bytes.length },
    ];
  });
  const mismatches = files.filter((file) => file.gitBlob !== file.actualBlob);
  if (mismatches.length)
    throw new Error(`Tracked source differs from HEAD: ${JSON.stringify(mismatches)}`);
  const harness = config.harnessFiles.map((file) => {
    const actual = sha256(fs.readFileSync(path.join(harnessRoot, file.name)));
    if (actual !== file.sha256) throw new Error(`Restored harness changed: ${file.name}`);
    return { name: file.name, sha256: actual };
  });
  return { at: new Date().toISOString(), sourceRoot, head, tree, status, files, harness };
}

function packageVersion(manifest, dependency) {
  const require = createRequire(path.join(sourceRoot, manifest));
  const entry = require.resolve(`${dependency}/package.json`);
  return {
    name: dependency,
    version: JSON.parse(fs.readFileSync(entry, 'utf8')).version,
    manifestSha256: sha256(fs.readFileSync(entry)),
  };
}

fs.mkdirSync(outputRoot, { recursive: true });
const wrapper = {
  file: path.basename(fileURLToPath(import.meta.url)),
  sha256: sha256(fs.readFileSync(fileURLToPath(import.meta.url))),
  configSha256: sha256(fs.readFileSync(configPath)),
};

if (mode === '--prepare') {
  if (fs.existsSync(path.join(outputRoot, 'source-binding.json'))) {
    throw new Error('Use a fresh preparation output directory.');
  }
  const binding = inspectSource();
  writeJson('source-binding.json', binding);
  const preparation = {
    preparedAt: new Date().toISOString(),
    status: 'prepared only; no esbuild call, browser launch, or probe execution',
    wrapper,
    sourceHead: binding.head,
    sourceTree: binding.tree,
    sourceFiles: binding.files.length,
    harness: binding.harness,
    runtime: {
      node: process.version,
      zlib: process.versions.zlib,
      platform: process.platform,
      arch: process.arch,
    },
    dependencies: [
      packageVersion('package.json', 'esbuild'),
      packageVersion('apps/www/package.json', 'playwright-core'),
      packageVersion('packages/adapters/react/package.json', 'react'),
      packageVersion('packages/adapters/react/package.json', 'react-dom'),
      packageVersion('apps/www/package.json', 'vue'),
      packageVersion('packages/adapters/vue2/package.json', 'vue'),
    ],
    plannedRuns: config.runs,
    originalScenariosAssertionsAndInputOrderChanged: false,
    executionGate: 'Root must separately release the heavy slot before --run is invoked.',
  };
  writeJson('preparation.json', preparation);
  console.log(
    JSON.stringify({
      preparedOnly: true,
      sourceHead: binding.head,
      sourceFiles: binding.files.length,
      probesExecuted: 0,
    })
  );
} else {
  const prepared = readJson('preparation.json');
  const binding = readJson('source-binding.json');
  if (
    prepared.wrapper.sha256 !== wrapper.sha256 ||
    prepared.wrapper.configSha256 !== wrapper.configSha256
  ) {
    throw new Error('Runner bytes changed after preparation.');
  }
  const bindingByPath = new Map(binding.files.map((file) => [file.path, file]));
  const receipt = {
    actualStartedAt: new Date().toISOString(),
    expectedHead: config.expectedHead,
    expectedTree: config.expectedTree,
    wrapper,
    sourceRoot,
    outputRoot,
    runs: [],
    scope:
      'New executions of the unchanged full probes. Historical native results are not rebound or redated.',
  };
  for (const run of config.runs) {
    const before = inspectSource();
    if (before.files.some((file) => bindingByPath.get(file.path)?.sha256 !== file.sha256)) {
      throw new Error('Source bytes changed since preparation.');
    }
    const outputDir = path.join(outputRoot, 'runs', run.id);
    if (fs.existsSync(outputDir))
      throw new Error(`Refusing to overwrite a prior run: ${outputDir}`);
    fs.mkdirSync(path.dirname(outputDir), { recursive: true });
    const childEnv = {
      ...process.env,
      SOURCE_ROOT: sourceRoot,
      OUTPUT_DIR: outputDir,
      EXPECTED_HEAD: config.expectedHead,
    };
    delete childEnv.CASES;
    delete childEnv.ADAPTER;
    if (run.adapter) childEnv.ADAPTER = run.adapter;
    const args = [path.join(harnessRoot, run.script)];
    const logName = `${run.id}.log`;
    const log = fs.openSync(path.join(outputRoot, logName), 'wx');
    const record = {
      id: run.id,
      startedAt: new Date().toISOString(),
      command: { executable: process.execPath, args, cwd: sourceRoot },
      environment: {
        SOURCE_ROOT: sourceRoot,
        OUTPUT_DIR: outputDir,
        EXPECTED_HEAD: config.expectedHead,
        ADAPTER: childEnv.ADAPTER ?? null,
        CASES: null,
        PATH: childEnv.PATH,
        CHROME_PATH: childEnv.CHROME_PATH ?? null,
      },
      before: { head: before.head, tree: before.tree, status: before.status },
      log: logName,
    };
    receipt.runs.push(record);
    writeJson('execution-receipt.json', receipt);
    console.log(JSON.stringify({ start: run.id, head: before.head }));
    let result;
    try {
      result = spawnSync(process.execPath, args, {
        cwd: sourceRoot,
        env: childEnv,
        stdio: ['ignore', log, log],
      });
    } finally {
      fs.closeSync(log);
    }
    record.finishedAt = new Date().toISOString();
    record.exitCode = result.status;
    record.signal = result.signal;
    if (result.error) record.processError = String(result.error);
    const after = inspectSource();
    record.after = { head: after.head, tree: after.tree, status: after.status };
    const provenancePath = path.join(outputDir, 'provenance.json');
    if (fs.existsSync(provenancePath)) {
      const provenance = JSON.parse(fs.readFileSync(provenancePath, 'utf8'));
      record.actualProvenanceHead = provenance.gitHead ?? provenance.head;
      record.actualSourceInputs = provenance.sourceInputs;
      record.actualHarness = provenance.harness;
      record.inputChecks = provenance.sourceInputs.map((input) => {
        const absolute = path.resolve(sourceRoot, input.path);
        const previous = bindingByPath.get(input.path);
        return {
          path: input.path,
          sha256: input.sha256,
          gitBlob: input.gitBlob,
          matchesEndBytes: sha256(fs.readFileSync(absolute)) === input.sha256,
          matchesPreparedSource: previous ? previous.sha256 === input.sha256 : null,
          matchesHeadBlob: input.gitBlob ? previous?.gitBlob === input.gitBlob : null,
        };
      });
      record.inputMismatches = record.inputChecks.filter(
        (input) =>
          !input.matchesEndBytes ||
          input.matchesPreparedSource === false ||
          input.matchesHeadBlob === false
      );
    }
    writeJson('execution-receipt.json', receipt);
    console.log(
      JSON.stringify({
        end: run.id,
        exitCode: record.exitCode,
        inputMismatches: record.inputMismatches?.length ?? null,
      })
    );
    if (
      record.exitCode !== 0 ||
      record.processError ||
      record.actualProvenanceHead !== config.expectedHead ||
      record.inputMismatches?.length
    ) {
      throw new Error(
        `Stopped after ${run.id}; preserve and inspect its log/results before continuing.`
      );
    }
  }
  receipt.actualFinishedAt = new Date().toISOString();
  receipt.browserProcessesComplete = true;
  writeJson('execution-receipt.json', receipt);
  console.log('ALL_SIX_PROBES_AND_SOURCE_BINDINGS_COMPLETE');
}
