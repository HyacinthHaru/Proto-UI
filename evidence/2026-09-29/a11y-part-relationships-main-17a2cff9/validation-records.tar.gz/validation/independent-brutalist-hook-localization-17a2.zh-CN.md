# 17a2 本地 Brutalist controls hook 超时：只读定位

**可以确定是 `afterAll`；原日志不足以证明 `browser.close()` 内部哪一步阻塞或为什么阻塞。** 本轮不将它命名为 flake、环境问题或产品缺陷。结论保持 partial / ABSTAIN，未重跑、改源码或写 GitHub。

准确 head：`17a2cff98080eb57f9070a6f45d89b58d3a72c3f`。该 suite、共享 harness、runtime runner/plan 与 Vitest config 的 blob 均与 accepted main `0e455a38` 相同；这说明本 PR 没有改这些测试字节，不足以排除所有产品间接影响。

## 已能证明的定位

`demo-brutalist-controls.browser.test.ts:530–537` 的 beforeAll 显式为 150,000ms，顺序等待 startServer、chromeExecutable 和 chromium.launch；:539–542 的 afterAll 显式为 60,000ms，依次等待 :540 `browser?.close()`、:541 `stopServer()`。该文件没有 beforeEach/afterEach；导入的共享 harness 也不注册 hook。

本地日志 :1915–1925 将该 suite 十个测试全部标为通过，:2094–2096 只有 suite 级 `Hook timed out in 60000ms`。因此不是 beforeAll 或某个测试体的 timeout。各测试最终 await context.close 也在已通过的测试 promise 内；那些关闭没有作为本次失败的未完成测试出现。Suite 总耗时 118,569ms，十项测试耗时之和 57,859ms，余量 60,710ms 与该 afterAll deadline 一致；这只是辅助一致性，不是额外时间戳定位。

完整运行的 :1911 显示共享 docs server。`scripts/test/run-runtime-tests.mjs:176` 将 `PROTO_UI_BROWSER_BASE_URL` 注入 browser Vitest 子进程。该 suite 的 startServer(:124–129) 随即走 external 分支，suite-local devServer 保持初始 null(:54)；stopServer 的首个 guard(:163) 因此立即 return。共享 harness 自己的 server 变量是另一份模块局部状态，且此 suite 只导入 runtime 常量与选择器 helper。真正的共享 server 由外层 driver 在 Vitest 完成之后清理，不在此 suite 的 afterAll 内。

所以在已证明的执行分支中，**browser.close 是该 hook 唯一具有实际异步关闭工作的 await**。原始日志没有 API entered/succeeded、browser pid exit 或 cleanup 完成时间，仍不能宣称已观察到具体 Playwright channel/process/tmp-cleanup 挂点；也不能从“末尾清理阶段”跳到“必然与产品无关”。

## 两份验证事实应分别保留

- 本地默认 pnpm test（仅 max2/min1 worker 环境覆盖，无筛选、无 timeout 修改）退出 **1**。主阶段 498 files / 2712 tests 通过，既有 3 skipped / 34 TODO；browser 137 tests 全通过，但 suite 为 **26 passed / 1 failed**。browser plan 本来就用 `--no-file-parallelism`，不能仅凭 worker 环境变量断言是多个 browser suites 并行相撞。
- 已下载的可信 CI run `36588210917` metadata 为准确 head 17a2、**11/11 jobs success**。test 原始日志记载 checkout `b60690ff006e4628fab611504188666f6eab1455`，主阶段 498/2712、browser 27/137 全通过；同一 Brutalist suite 10 tests / 39,682ms 通过。CI 的成功不能抹掉本地非零，本地 hook 失败也不能改写已完成 CI 的结论。

## 最小后续动作

完成 root 已授权且正在进行的原 suite 单次 `DEBUG=pw:api,pw:browser` 诊断，保留原 assertions/timeouts。重点保留：最后一个 context.close 完成 → browser.close started → browser graceful-close / process exit / temporary-directory cleanup → browser.close succeeded → suite 完成的时间链。若再次卡住，只对该次任务拥有的 browser/worker PID 做被动观察；从最后完成阶段区分具体下一步，再判断是否存在可修的测试资源问题。

若这次通过，只能记为“该有限诊断未复现原失败”。独立 focused run 若不用同一 shared-server/prior-phase 条件，不是对原 full-run 条件的完整否定。当前没有依据扩大 timeout、重跑到绿、吞掉 close 错误、修改产品，或新开无关 PR。

伴随 JSON 记录原始日志 SHA、准确 source blob、行号、CI job 摘要与本次未执行事项。

## 追加：隔离原 suite 的实际关闭时间链

已只读核对 `brutalist-cleanup-isolated-17a2cff9.log` 与 receipt：原十项测试加 `DEBUG=pw:api,pw:browser` 于同一 17a2 head 退出 0，1 file / 10 tests 通过，无 assertion/timeout 修改。末次 context.close 在 15:32:57.445Z 返回；browser.close 于 .446Z 开始，Chrome pid46997 于 .596Z 以 exitCode0/signalnull 退出并开始临时目录清理，.603Z 清理结束且 browser.close 成功返回，关闭区间约 157ms（log:3279–3288）。

该次使用独立 docs server，原完整运行使用共享 server；此观察仅说明这一次有限诊断没有复现原 hook 超时，不给原失败补造底层挂点/原因，也不替代原完整运行。原本地 exit1 与可信 CI success 仍分别成立；随后 root 启动的完整 retry 未在本次报告中核验或标为完成。
