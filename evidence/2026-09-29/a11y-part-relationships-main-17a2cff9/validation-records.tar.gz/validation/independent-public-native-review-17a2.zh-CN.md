# 17a2 native prepared packet / CI 独立对账

结论为 **partial / ABSTAIN**。未发现证据字节、来源/时间、执行范围或 CI receipt 的具体不一致；有 **一处 P3 发布引用澄清**，详见下文。本轮只读核对，没有修改 packet、产品或 GitHub，也没有重跑测试/浏览器/构建。

准确 head `17a2cff98080eb57f9070a6f45d89b58d3a72c3f`，tree `a46d21801fc0e32b1a3f807f9c567a44e1b08d63`。审核快照 manifest SHA256 为 `3b3c53f3359357dac22448eef6b868dae252f7cae12a1e5a6df1badc3fb3d2a8`，README SHA256 为 `22350c821e0ed242d9a57080f0d68b245d811977dc8b61b419bb90dc439902fd`。

## 已核对的证据

- 65 文件 / 64 manifest entries 全部吻合；archive 为 332 + 9 个普通文件成员，无重复、链接或越界路径。398 个原始/公开映射全部重算哈希。57 PNG 与 9 个实际执行代码文件逐字节一致，公开 Markdown 本地链接均存在。
- 14 个文本成员的差异仅为已声明路径替换，共 87 次；我用私有 preparation receipt 中的原始 literal 独立重做替换，结果与公开副本完全相等。未发现已知 `/Users/`、私有临时路径或原 PATH 残留。12 个 excluded bundles/maps 的原始哈希吻合，archive 未包含这些文件、node_modules 目录或第三方依赖缓存；metadata 引用不等同于分发依赖文件。
- 六个 metafile 的实际输入集合与 provenance 一致；315 个 distinct tracked inputs 都独立与准确 commit blob/实际字节 SHA 核对。6,807 个 prepared source bindings 与 tree 路径/mode/blob 对应；六次运行前后均记为准确 head/tree/clean。各 run 与 provenance 时刻均位于外层 15:10:41.067–15:11:21.412 UTC 区间。六份输入图都新增 focus-order.ts；旧输入 7/9 个差异的旧 blob 与 fd9 对应，没有伪称沿用旧输入等价。
- 逐个结果统计得 324/324 checks；ownership 明确为 141 contract observations + 77 fixture controls，18 cases；四 Adapter 各五场景。36 trusted clicks 与 WC 额外 6 untrusted semantic deliveries 分开计数，错误/console 项为空。57 条视觉记录和 132 条 AX 对应文件哈希匹配；“逐图查看”仍归属于原记录者，本轮未重新独立看图。
- README 的四 Adapter D/E 表格全部 seq/record 对上新 trace；generic 初始两顺序、source/target L1 与 remount phase facts 对应。K provider 的 seq11/22/53/59/65 对得上 physical identity、collision 和 epoch 状态，README 正确保留 internal WC host-contract / explicit host barrier 范围，没有扩称所有生产 framework routes。
- Immutable 历史 README 链接实时可读取，确实保留 b0ed0f55 Tabs baseline、820/83/349 ownership failures 与 fd9 实际执行；当前包没有重标这些历史图片/运行。顶层三个 root receipt slots 保持 null，含义是未纳入本 native-only 包，不是底层门禁结论。

## CI receipt 对账

实时 GitHub GET 确认官方 `Proto-UI/Proto-UI` 的 `.github/workflows/ci.yml`、pull_request event、准确 head17a2，run36588210917 **completed/success，11/11 jobs success**。live Git commit metadata 确认实际 checkout b60690ff 的 tree 就是 a46d2180。

原始 package job109474177313 log 确認 **44/44 build、44 manifest checks、九项 budget PASS**。九项 gzip/minified/SHA 与 receipt 和本地 JSON 全部一致；Runtime66024/66500、React85641/86500、Vue85384/86500。环境仍分别注明本地 macOS arm64 与 CI Linux x64，没有把本次一致扩成所有平台保证。原始 test job109474103663 log 对上 main498files/2712tests、browser27files/137tests、registry14项和实际ChromiumScroll6项；既有3skipped/34TODO保留。

CI成功与原本地完整运行 exit1 分开记录。隔离原十项 suite 的 DEBUG log 已补入先前 hook 定位报告：15:32:57.446Z browser.close 开始，.596Z Chrome exit0，.603Z temp cleanup 完成/close succeeded，约157ms。该次独立server诊断通过，原完整shared-server超时的根因仍未知。root 随后启动的全量 retry 未在本报告中核验或宣布完成。

## 唯一具体发布澄清

**PUB-17A-RAW-REPORT-LOCAL-REFERENCE（P3，高置信度）**：`native-records.tar.gz::report.md:24` 说 wrapper source 和 full adaptation diff 留在 `../browser-refresh-preparation/runner-17a2cff9/`。该目录及 adaptation receipt 没有分发在 65 文件或两份 archive 中；实际执行 wrapper/config 则在 `execution-code/runner-17a2cff9/`。公开读者按原报告相对路径无法找到那份 full diff。

建议保留 raw report，只在顶层 README 明说该条为原本地审计引用、full adaptation diff 不在本包，并指向已分发的 execution-code archive/layout；若确需公开完整 diff，另行准确提供。此项不否定现有执行代码的可复现性，不是产品 finding，也不产生新验证/批准结论。

伴随 JSON 记录准确快照、全部局部审计文件哈希、live CI 来源及限制。独立维护者正式批准与实际 merge 仍是单独门禁；本报告不构成 GitHub disposition。
