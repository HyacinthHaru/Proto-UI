# 17a2 发布说明与便携观察脚本增量收尾

**P3 `PUB-17A-RAW-REPORT-LOCAL-REFERENCE` 可关闭；此增量没有新 finding，仍为 partial / ABSTAIN。**

`public-final-17a2cff9/README.md:66` 明确指出 archived raw report 的 adaptation 目录/receipt locator 是原本地审计引用，不在分发包内，并准确指向 `execution-code.tar.gz` 及其中两个目录。该说明为原 README 的追加。原 native README/manifest 及两份 archive 均未改，未改写历史 raw report。当前最终 README SHA256 为 `bb381eae91190b1298be7c1aa24fde5b469399cfc485f280bf92dec27caa11c0`。

便携脚本也核对通过。使用仓库现有 Prettier 3.8.1 做纯文本格式化比较：把原脚本唯一固定 repo 路径改为 `process.env.SOURCE_ROOT` 并加 required assert，再按 Babel parser 格式化，输出与便携脚本逐字节相同。不存在其他 assertion、输入顺序、队列、错误或报告语义变化。本轮没有执行观察脚本。

- 原 harness SHA256：`c29772f83f9937a8e12c8bef1ccbd11e230fc69374fcabbe6039dde4d9a1a373`。
- 便携版实际 harness SHA256：`9a02d552d526fe119e2df55b46f787f790aa7f2302bf02e9745c61fa952f2872`，同时吻合 adaptation receipt 与结果内自哈希。
- 原观察时间为 `15:01:44.832Z`，root 的便携版新执行记录为 `15:43:58.806Z`，均为 2026-09-29；没有把旧运行改日期。
- 15 条 events、两个 results、三份 source bindings 逐字段相同。其余结果字段除 observedAt / harnessSha256 外也相同；stdout 精确对应这些事件与 2/2 pass 末行，stderr 为空。Node22.23.2 / `--experimental-strip-types` / receipt exit0 对应准确17a2 head/tree。

这是 root 已执行记录的独立只读核对，不是本 reviewer 的新执行。最终包尚需待 root 完整本地 retry 结束及最终 receipts/manifest 冻结后再检查；本报告不宣布该 retry、全体发布审查、独立正式批准或 merge 已完成。原始 P3 报告保留为历史，本增量记录将该稳定 ID 标为 resolved。
