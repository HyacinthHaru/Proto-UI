# #688 集成候选独立增量复核

结论：**未发现本轮增量范围内的新具体 finding；partial / ABSTAIN**。本报告只覆盖准确候选的父提交/文件合并、原 authority 保留与两个授权的纯 registry 故障组合；不扩展为全局源码验收或 GitHub disposition。

候选 `17a2cff98080eb57f9070a6f45d89b58d3a72c3f`，tree `a46d21801fc0e32b1a3f807f9c567a44e1b08d63`；parents 顺序准确为 feature `51cf494a2c4201c0fc9c208a6e94ff0d6fcb2bb4`、accepted main `0e455a38ea1397c225e6a72d2d43b5f76da02cdc`。实际读取 git object，并独立运行 `git verify-commit` 成功；Author/Committer 均为 HyacinthHaru <hyacinth@haru.ac>，有 DCO trailer。检查时专用工作树干净。

对 base/feature/main/candidate 全部 **6,807** 个 tree 路径逐一比较 mode/type/blob：**45 个 feature-only 全部保留 feature 字节；18 个 main-only 全部保留 main 字节；6,742 个双方未变路径无额外修改；仅 2 个预期交集**。相对 accepted main 的 47 个路径集合与 feature 相对共同基线的 47 个路径集合完全相同，没有因同步丢失原功能路径或夹带第三组改动。

- Table 候选恰等于 feature 加 accepted main 的 mount-phase caller guard，原 callee guard 同时保留，无其他 Table 产品改动。
- Base Tabs 测试恰等于 feature 加 main 的 32 行 A→B→A labelledBy 回归，原 exact-key、ambiguity、domain、lazy identity 等断言字节保留。
- 九个相关 spec entity 均与 feature blob 完全相同且仍为 draft。C-A11Y-PART-RELATIONSHIP-0001 A–K 共 11 条、T 的 7 cases / 6 required implementation paths 完整保留；没有 stable admission。
- GPUI generator 同 feature/main；fixture 同 feature，仍是维护者 generator 提交产生的 epoch0 snapshot 增量。此轮没有执行 generator/GPUI checks，未把静态来源验证写成生成一致性 PASS。
- 预算脚本、public package planner 和全部 workflow 文件与 accepted main 字节相同；无 #688 内追加上限、测量算法或 CI 路由调整。

两个一次性观察于 2026-09-29T15:01:44Z 使用 Node v22.23.2 直接 type-strip/import 该准确候选的 registry、core semantic ref factory、Anatomy factory。执行前后均校验源码 SHA 与 commit 内容，进程退出 0，未超时，stderr 为空。它们不是 DOM/Adapter 或真实浏览器投射验证。

1. **重入变更 tuple 后抛错**：source 第一次接收 target=null 后，将 target/source/peer 改成 latest key 与 epoch2，再抛出指定 Error。Peer 仅被通知一次，并读取 latest/key+epoch2 的有效 target；外层收到同一个 Error 对象。之后相等 target.update 仅重试失败 source（累计 2 次），peer 仍为 1 次；再相等更新无新通知。未观察到 pending 丢失或同轮自旋。
2. **notify 自 dispose 后抛错**：source 首次通知中 dispose 自身并抛出指定 Error。Peer 正常收到 target=null；source resolution 为空。相等 target update 和 disposed source update 均没有重试该 source；target epoch2 恢复只通知 peer，source 仍为空。累计 source 1 次、peer 2 次，外层保留原 Error identity。

可复现代码为 `independent-17a2-registry/registry-combinations.mjs`，完整 15 条事件/异常、执行命令、环境及源码/harness SHA 位于同目录 results JSON、execution receipt 与 stdout/stderr logs。静态对账代码为 `independent-17a2-blob-audit.py`，准确路径绑定为 `independent-17a2-final-binding.json`。首次报告解析器因 YAML list 的 `- id` 正则遗漏中止，修正的是任务目录中的审计解析器，未修改产品；最终完整静态对账通过，此记录保留该校正历史。

未启动 package build、类型检查、普通测试 runner、GPUI runner、browser 或 CI。Root 正在执行的其他验证不在本报告中冒认已通过。此前的三个已解决 P2 源码字节保留，但本轮没有重跑其 adapter/宿主复现；旧视觉与 CI 证据仍按原版本归属。独立维护者正式批准、准确集成 head 的完整可信 CI 与实际 merge 仍分别待完成。
