import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { execFileSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const repo = process.env.SOURCE_ROOT;
assert.ok(repo, "SOURCE_ROOT must name the frozen source checkout.");
const head = "17a2cff98080eb57f9070a6f45d89b58d3a72c3f";
const tree = "a46d21801fc0e32b1a3f807f9c567a44e1b08d63";
const out = path.dirname(fileURLToPath(import.meta.url));
const git = (...args) =>
  execFileSync("git", args, { cwd: repo, encoding: "utf8" }).trim();
const sha256 = (bytes) => createHash("sha256").update(bytes).digest("hex");
assert.equal(git("rev-parse", "HEAD"), head);
assert.equal(git("rev-parse", `${head}^{tree}`), tree);
const sources = [
  "packages/modules/a11y/src/part-relationships.ts",
  "packages/core/src/a11y.ts",
  "packages/core/src/anatomy.ts",
].map((sourcePath) => {
  const bytes = readFileSync(path.join(repo, sourcePath));
  const committed = execFileSync("git", ["show", `${head}:${sourcePath}`], {
    cwd: repo,
  });
  assert.equal(
    sha256(bytes),
    sha256(committed),
    `live source drift: ${sourcePath}`,
  );
  return {
    path: sourcePath,
    blob: git("rev-parse", `${head}:${sourcePath}`),
    sha256: sha256(bytes),
  };
});
const { createA11yPartRelationshipRegistry } = await import(
  pathToFileURL(path.join(repo, sources[0].path)).href
);
const { createA11ySemanticObjectRef } = await import(
  pathToFileURL(path.join(repo, sources[1].path)).href
);
const { createAnatomyFamily } = await import(
  pathToFileURL(path.join(repo, sources[2].path)).href
);
const events = [];
let activeCase = null;
const event = (type, data = {}) => {
  const row = { seq: events.length + 1, case: activeCase, type, ...data };
  events.push(row);
  console.log(JSON.stringify(row));
};
const makeFixture = () => {
  const registry = createA11yPartRelationshipRegistry();
  const family = createAnatomyFamily("independent-notify-combination", {
    roles: {
      root: { cardinality: { min: 1, max: 1 } },
      source: { cardinality: { min: 0, max: "*" } },
      target: { cardinality: { min: 0, max: "*" } },
    },
  });
  const scope = {};
  const refs = {
    source: createA11ySemanticObjectRef(),
    peer: createA11ySemanticObjectRef(),
    target: createA11ySemanticObjectRef(),
  };
  const callbacks = { source: () => {}, peer: () => {} };
  const source = registry.createOwner(refs.source, () => callbacks.source());
  const peer = registry.createOwner(refs.peer, () => callbacks.peer());
  const target = registry.createOwner(refs.target, () => {});
  const targetInput = {
    epoch: 1,
    available: true,
    parts: [{ family, scope, role: "target", key: "initial" }],
    relationships: [],
  };
  const sourceInput = {
    epoch: 1,
    available: true,
    parts: [],
    relationships: [
      {
        family,
        scope,
        role: "source",
        key: "initial",
        relation: "controls",
        targetRole: "target",
      },
    ],
  };
  source.update(sourceInput);
  peer.update(sourceInput);
  target.update(targetInput);
  const observation = (owner) =>
    owner
      .getRelationships()
      .map((r) => ({
        key: r.key,
        sourceEpoch: r.sourceEpoch,
        targetEpoch: r.targetEpoch,
        target:
          r.target === refs.target
            ? "target-ref"
            : r.target === null
              ? null
              : "unexpected-ref",
      }));
  return {
    source,
    peer,
    target,
    callbacks,
    targetInput,
    sourceInput,
    observation,
  };
};
const results = [];

activeCase = "reentrant-tuple-change-then-throw";
{
  const f = makeFixture();
  let sourceCalls = 0;
  let peerCalls = 0;
  let peerProjected = f.observation(f.peer);
  let sourceProjected = f.observation(f.source);
  const failure = new Error("reentrant source fails once");
  const latestTarget = {
    ...f.targetInput,
    epoch: 2,
    parts: [{ ...f.targetInput.parts[0], key: "latest" }],
  };
  const latestSource = {
    ...f.sourceInput,
    epoch: 2,
    relationships: [{ ...f.sourceInput.relationships[0], key: "latest" }],
  };
  f.callbacks.source = () => {
    sourceCalls++;
    assert.ok(sourceCalls < 6, "unexpected source recursion");
    event("source-notify", {
      call: sourceCalls,
      resolution: f.observation(f.source),
    });
    if (sourceCalls === 1) {
      f.target.update(latestTarget);
      f.source.update(latestSource);
      f.peer.update(latestSource);
      event("reentrant-updates-returned", { inputKey: "latest", epoch: 2 });
      event("source-throw");
      throw failure;
    }
    sourceProjected = f.observation(f.source);
  };
  f.callbacks.peer = () => {
    peerCalls++;
    assert.ok(peerCalls < 6, "unexpected peer recursion");
    peerProjected = f.observation(f.peer);
    event("peer-notify", { call: peerCalls, resolution: peerProjected });
  };
  let caught;
  try {
    f.target.update({ ...f.targetInput, available: false });
  } catch (error) {
    caught = error;
  }
  assert.equal(caught, failure, "single thrown value must be preserved");
  event("outer-error", {
    name: caught.name,
    message: caught.message,
    originalIdentity: caught === failure,
  });
  const latestResolution = [
    { key: "latest", sourceEpoch: 2, targetEpoch: 2, target: "target-ref" },
  ];
  assert.equal(sourceCalls, 1);
  assert.equal(peerCalls, 1);
  assert.deepEqual(f.observation(f.source), latestResolution);
  assert.deepEqual(f.observation(f.peer), latestResolution);
  assert.deepEqual(peerProjected, latestResolution);
  assert.deepEqual(sourceProjected, [
    { key: "initial", sourceEpoch: 1, targetEpoch: 1, target: "target-ref" },
  ]);
  event("before-retry", {
    sourceCalls,
    peerCalls,
    sourceProjected,
    peerProjected,
  });
  assert.doesNotThrow(() => f.target.update(latestTarget));
  assert.equal(sourceCalls, 2);
  assert.equal(peerCalls, 1);
  assert.deepEqual(sourceProjected, latestResolution);
  f.target.update(latestTarget);
  assert.equal(sourceCalls, 2);
  assert.equal(peerCalls, 1);
  results.push({
    case: activeCase,
    pass: true,
    sourceCalls,
    peerCalls,
    exception: {
      name: caught.name,
      message: caught.message,
      originalIdentity: true,
    },
    peerFirstNotification: latestResolution,
    equalUpdateRetriedFailedOnly: true,
    subsequentEqualUpdateWasNoop: true,
  });
  event("case-pass", results.at(-1));
}

activeCase = "self-dispose-then-throw";
{
  const f = makeFixture();
  let sourceCalls = 0;
  let peerCalls = 0;
  const failure = new Error("source disposes then fails");
  f.callbacks.source = () => {
    sourceCalls++;
    assert.ok(sourceCalls < 3, "disposed source was retried");
    event("source-notify", {
      call: sourceCalls,
      resolution: f.observation(f.source),
    });
    f.source.dispose();
    event("source-disposed", { resolution: f.observation(f.source) });
    event("source-throw");
    throw failure;
  };
  f.callbacks.peer = () => {
    peerCalls++;
    assert.ok(peerCalls < 6, "unexpected peer recursion");
    event("peer-notify", {
      call: peerCalls,
      resolution: f.observation(f.peer),
    });
  };
  const detached = { ...f.targetInput, available: false };
  let caught;
  try {
    f.target.update(detached);
  } catch (error) {
    caught = error;
  }
  assert.equal(caught, failure);
  event("outer-error", {
    name: caught.name,
    message: caught.message,
    originalIdentity: caught === failure,
  });
  assert.equal(sourceCalls, 1);
  assert.equal(peerCalls, 1);
  assert.deepEqual(f.observation(f.source), []);
  assert.deepEqual(f.observation(f.peer), [
    { key: "initial", sourceEpoch: 1, targetEpoch: 1, target: null },
  ]);
  assert.doesNotThrow(() => f.target.update(detached));
  assert.doesNotThrow(() => f.source.update(f.sourceInput));
  assert.equal(sourceCalls, 1);
  assert.equal(peerCalls, 1);
  f.target.update({ ...f.targetInput, epoch: 2 });
  assert.equal(sourceCalls, 1);
  assert.equal(peerCalls, 2);
  assert.deepEqual(f.observation(f.source), []);
  assert.deepEqual(f.observation(f.peer), [
    { key: "initial", sourceEpoch: 1, targetEpoch: 2, target: "target-ref" },
  ]);
  results.push({
    case: activeCase,
    pass: true,
    sourceCalls,
    peerCalls,
    exception: {
      name: caught.name,
      message: caught.message,
      originalIdentity: true,
    },
    disposedOwnerRemainedEmpty: true,
    equalUpdateAndDisposedUpdateDidNotRetry: true,
    peerRestoredAtTargetEpoch: 2,
  });
  event("case-pass", results.at(-1));
}
for (const source of sources)
  assert.equal(
    sha256(readFileSync(path.join(repo, source.path))),
    source.sha256,
    `source changed during observation: ${source.path}`,
  );
assert.equal(git("rev-parse", "HEAD"), head);
const report = {
  kind: "disposable-source-bound-registry-observation",
  observedAt: new Date().toISOString(),
  head,
  tree,
  node: process.version,
  nodeExecutable: process.execPath,
  platform: process.platform,
  arch: process.arch,
  commandArgs: process.execArgv,
  sources,
  harnessSha256: sha256(readFileSync(fileURLToPath(import.meta.url))),
  result: "2/2 observations passed",
  results,
  events,
  scope:
    "Actual registry and core factories imported directly from exact committed TypeScript via Node type stripping. Callback resolution delivery only; no DOM, adapter projection, browser or package build.",
  recommendation:
    "partial/ABSTAIN; no GitHub disposition; not complete A11y conformance or an integrated CI result",
};
writeFileSync(
  path.join(out, "registry-combinations-results.json"),
  JSON.stringify(report, null, 2) + "\n",
);
console.log(
  JSON.stringify({
    result: report.result,
    head,
    output: path.join(out, "registry-combinations-results.json"),
  }),
);
