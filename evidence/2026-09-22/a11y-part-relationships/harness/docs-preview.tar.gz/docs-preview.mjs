import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const root = process.env.SOURCE_ROOT;
const out = process.env.OUTPUT_DIR;
if (!root || !out) throw new Error('SOURCE_ROOT and OUTPUT_DIR are required');
const dist = path.join(root, 'apps/www/dist');
const require = createRequire(path.join(root, 'apps/www/package.json'));
const { chromium } = require('playwright-core');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.woff2': 'font/woff2', '.wasm': 'application/wasm' };
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://127.0.0.1');
    let file = path.join(dist, decodeURIComponent(url.pathname));
    if (!file.startsWith(dist + path.sep)) throw new Error('outside dist');
    if ((await fs.stat(file)).isDirectory()) file = path.join(file, 'index.html');
    res.setHeader('Content-Type', mime[path.extname(file)] ?? 'application/octet-stream');
    res.end(await fs.readFile(file));
  } catch {
    res.writeHead(404).end('Not found');
  }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
await fs.mkdir(out, { recursive: true });
const browser = await chromium.launch({ executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless: true });
const head = execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
const report = { head, browser: browser.version(), scope: 'Built Base Tabs documentation in both locales, desktop/mobile; WC preview only. No full keyboard, focus or accessibility claim.', captures: [] };
try {
  for (const locale of ['en', 'zh-cn']) for (const width of [1440, 390]) {
    const page = await browser.newPage({ viewport: { width, height: 1000 } });
    const errors = [], requests = [], events = [];
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
    page.on('requestfailed', r => requests.push({ url: r.url(), reason: r.failure()?.errorText }));
    await page.exposeFunction('recordDocClick', e => events.push(e));
    await page.addInitScript(() => document.addEventListener('click', e => window.recordDocClick({ trusted: e.isTrusted, target: e.target?.tagName }), true));
    const route = `/${locale}/ui-libraries/base/tabs/`;
    await page.goto(`http://127.0.0.1:${server.address().port}${route}`, { waitUntil: 'networkidle' });
    const preview = page.locator('[data-demo-id="demo-base-tabs"]');
    await preview.locator('[role="tab"]').first().waitFor({ state: 'visible' });
    const before = await preview.locator('[role="tab"]').evaluateAll(tabs => tabs.map(t => ({ text: t.textContent, selected: t.getAttribute('aria-selected'), controls: t.getAttribute('aria-controls') })));
    await preview.screenshot({ path: path.join(out, `${locale}-${width}-initial.png`) });
    await preview.locator('[role="tab"]').nth(1).click();
    const after = await preview.locator('[role="tab"]').evaluateAll(tabs => tabs.map(t => ({ text: t.textContent, selected: t.getAttribute('aria-selected'), controls: t.getAttribute('aria-controls') })));
    if (after[1]?.selected !== 'true') throw new Error(`${locale}/${width}: second tab not selected`);
    await preview.screenshot({ path: path.join(out, `${locale}-${width}-selected.png`) });
    const heading = page.getByRole('heading', { name: locale === 'en' ? 'Accessibility and presence' : '可访问性与存在性', exact: true });
    if (await heading.count()) await heading.scrollIntoViewIfNeeded();
    const prose = await page.locator('main').innerText();
    if (!prose.includes('a+b') || !prose.includes('a b')) throw new Error('updated relationship paragraph absent');
    await page.screenshot({ path: path.join(out, `${locale}-${width}-prose.png`) });
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - innerWidth);
    if (errors.length || overflow > 0) throw new Error(JSON.stringify({ errors, overflow }));
    const html = await fs.readFile(path.join(dist, route, 'index.html'));
    report.captures.push({ locale, width, route, before, after, errors, requests, events, overflow, htmlSha256: createHash('sha256').update(html).digest('hex') });
    await page.close();
  }
} finally {
  report.finishedAt = new Date().toISOString();
  await fs.writeFile(path.join(out, 'results.json'), JSON.stringify(report, null, 2) + '\n');
  await browser.close();
  await new Promise(resolve => server.close(resolve));
}
