import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createServer } from 'node:http';
import { createHash } from 'node:crypto';

const sourceRoot = process.env.SOURCE_ROOT && path.resolve(process.env.SOURCE_ROOT);
const outputDir = process.env.OUTPUT_DIR && path.resolve(process.env.OUTPUT_DIR);
const expectedHead = process.env.EXPECTED_HEAD;
const prepareOnly = process.argv.includes('--prepare-only');
if (!sourceRoot || !outputDir || !expectedHead)
  throw new Error('SOURCE_ROOT, OUTPUT_DIR and EXPECTED_HEAD are required.');
if (outputDir === sourceRoot || outputDir.startsWith(`${sourceRoot}${path.sep}`))
  throw new Error('OUTPUT_DIR must be outside SOURCE_ROOT.');
const here = path.dirname(fileURLToPath(import.meta.url));
const requireSource = createRequire(path.join(sourceRoot, 'package.json'));
const requireWWW = createRequire(path.join(sourceRoot, 'apps/www/package.json'));
const esbuild = requireSource('esbuild');
const { chromium } = requireWWW('playwright-core');
const sha256 = (data) => createHash('sha256').update(data).digest('hex');
const git = (...args) =>
  execFileSync('git', ['-C', sourceRoot, ...args], { encoding: 'utf8' }).trim();
const head = git('rev-parse', 'HEAD');
if (head !== expectedHead) throw new Error(`Expected source HEAD ${expectedHead}, found ${head}.`);
const cases = (
  process.env.CASES ??
  'explicit-id,generated-id,independent-writer,independent-writer-absent,explicit-id-replay,generated-id-replay,independent-writer-replay,wc-provider-binding'
).split(',');
const allowed = new Set([
  'explicit-id',
  'generated-id',
  'independent-writer',
  'independent-writer-absent',
  'explicit-id-replay',
  'generated-id-replay',
  'independent-writer-replay',
  'wc-provider-binding',
]);
if (cases.some((name) => !allowed.has(name))) throw new Error('Unknown ownership fixture case.');
await fsp.mkdir(outputDir, { recursive: true });

function resolveWorkspace(id) {
  const [pkg, ...rest] = id.slice('@proto.ui/'.length).split('/');
  const scope = pkg.startsWith('module-')
    ? `modules/${pkg.slice(7)}`
    : pkg.startsWith('adapter-')
      ? `adapters/${pkg.slice(8)}`
      : pkg.startsWith('prototypes-')
        ? `prototypes/${pkg.slice(11)}`
        : pkg;
  const directory = path.join(sourceRoot, 'packages', scope);
  const manifest = JSON.parse(fs.readFileSync(path.join(directory, 'package.json'), 'utf8'));
  const key = rest.length ? `./${rest.join('/')}` : '.';
  const entry = manifest.exports?.[key];
  if (!entry) throw new Error(`Undeclared public import: ${id}`);
  const exported =
    typeof entry === 'string' ? entry : (entry.import ?? entry.default ?? entry.types);
  const source = exported
    .replace('./dist/', './src/')
    .replace(/\.d\.ts$/, '.ts')
    .replace(/\.js$/, '.ts');
  const resolved = path.resolve(directory, source);
  if (!fs.existsSync(resolved)) throw new Error(`Missing source export ${id}: ${resolved}`);
  return resolved;
}
const internalInputs = {
  'ownership:wc-provider': 'packages/adapters/web-component/src/runtime/modules.ts',
  'ownership:wc-instance-tree': 'packages/adapters/web-component/src/platform/instance-tree.ts',
};
const build = await esbuild.build({
  entryPoints: [path.join(here, 'ownership-fixture.ts')],
  outfile: path.join(outputDir, 'fixture.js'),
  absWorkingDir: sourceRoot,
  bundle: true,
  format: 'esm',
  platform: 'browser',
  target: 'es2020',
  sourcemap: true,
  metafile: true,
  nodePaths: [
    path.join(sourceRoot, 'node_modules'),
    path.join(sourceRoot, 'apps/www/node_modules'),
  ],
  plugins: [
    {
      name: 'actual-source-host-contract',
      setup(builder) {
        builder.onResolve({ filter: /^@proto\.ui\// }, (args) => ({
          path: resolveWorkspace(args.path),
        }));
        builder.onResolve({ filter: /^ownership:/ }, (args) => {
          const relative = internalInputs[args.path];
          if (!relative) throw new Error(`Unknown internal host fixture input ${args.path}`);
          return { path: path.join(sourceRoot, relative) };
        });
      },
    },
  ],
});
await fsp.writeFile(
  path.join(outputDir, 'esbuild-metafile.json'),
  JSON.stringify(build.metafile, null, 2)
);
const inputs = Object.keys(build.metafile.inputs).map((input) => {
  const absolute = path.resolve(sourceRoot, input);
  const relative = path.relative(sourceRoot, absolute);
  return {
    path: relative,
    sha256: sha256(fs.readFileSync(absolute)),
    gitBlob:
      !relative.startsWith('..') && !relative.includes('node_modules/')
        ? git('hash-object', absolute)
        : null,
  };
});
const chromePath =
  process.env.CHROME_PATH ?? '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const provenance = {
  startedAt: new Date().toISOString(),
  sourceRoot,
  outputDir,
  head,
  expectedHead,
  gitStatus: git('status', '--short'),
  trackedStatus: git('status', '--short', '--untracked-files=no'),
  node: process.version,
  zlib: process.versions.zlib,
  platform: process.platform,
  arch: process.arch,
  esbuild: esbuild.version,
  playwright: requireWWW('playwright-core/package.json').version,
  chromeExecutable: chromePath,
  internalInputs,
  sourceInputs: inputs,
  harness: ['ownership-probe.mjs', 'ownership-fixture.ts'].map((name) => ({
    name,
    sha256: sha256(fs.readFileSync(path.join(here, name))),
  })),
  scope:
    'Internal ownership/DOM host-contract fixture using actual Web projector, actual WC capability provider and existing HostSurfaceProjection setter. Runtime replay cases use real State watches. Not a public demo, complete Adapter consumer journey, native product event or OS input claim.',
  timing:
    'Host operations are explicit page-evaluate stimuli. Immediate snapshots are captured synchronously; requestAnimationFrame records the following observer/rendering boundary. Provider replacement holds a host-owned hidden barrier until a separate reveal command.',
  importBoundary:
    'Public Core/Runtime/A11y/Adapter Base export names resolve to selected TypeScript source; the two explicit WC provider paths above are internal. No projection or ownership algorithm is copied into the fixture.',
  status: prepareOnly
    ? 'prepared source bundle only; browser and assertions not executed'
    : 'browser run in progress',
};
await fsp.writeFile(
  path.join(outputDir, prepareOnly ? 'preparation.json' : 'provenance.json'),
  JSON.stringify(provenance, null, 2)
);
if (prepareOnly) {
  console.log(JSON.stringify({ prepared: true, head, cases, browserRun: false, outputDir }));
  process.exit(0);
}
const html =
  '<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Internal A11y ownership host fixture</title></head><body><script type="module" src="/fixture.js"></script></body></html>';
await fsp.writeFile(path.join(outputDir, 'index.html'), html);
const server = createServer((req, res) => {
  const file = req.url?.split('?')[0] === '/fixture.js' ? 'fixture.js' : 'index.html';
  res.setHeader('Content-Type', file.endsWith('.js') ? 'text/javascript' : 'text/html');
  fs.createReadStream(path.join(outputDir, file)).pipe(res);
});
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({ executablePath: chromePath, headless: true });
provenance.chrome = browser.version();
const results = [];
const C = 'C-A11Y-PART-RELATIONSHIP-0001';

try {
  for (const caseId of cases) {
    const directory = path.join(outputDir, caseId);
    await fsp.mkdir(directory, { recursive: true });
    const context = await browser.newContext({ viewport: { width: 1100, height: 700 } });
    const page = await context.newPage();
    const cdp = await context.newCDPSession(page);
    const errors = [],
      consoleMessages = [],
      checkpoints = [],
      assertions = [];
    page.on('pageerror', (error) => errors.push(String(error)));
    page.on('console', (message) => {
      if (['warning', 'error'].includes(message.type()))
        consoleMessages.push({ type: message.type(), text: message.text() });
    });
    const check = (id, expected, actual, pass, anchors) =>
      assertions.push({
        id,
        expected,
        actual,
        pass: Boolean(pass),
        authority: anchors.length
          ? { kind: 'contract-criteria', anchors }
          : {
              kind: 'fixture-execution-control',
              anchors: [],
              statement:
                'Execution control for this fixture only; no generic exception, silence, or OS-input policy is asserted.',
            },
      });
    const capture = async (label, immediate = null) => {
      const state = await page.evaluate((name) => window.ownershipProbe.nextFrame(name), label);
      const ax = await cdp.send('Accessibility.getFullAXTree');
      const dom = await page.content();
      await fsp.writeFile(path.join(directory, `${label}-ax.json`), JSON.stringify(ax, null, 2));
      await fsp.writeFile(path.join(directory, `${label}-dom.html`), dom);
      checkpoints.push({
        label,
        immediate,
        state,
        axTiming:
          'AX captured after observer/frame boundary, not at a synchronous setter-return point.',
      });
      return state;
    };
    const step = (name) => page.evaluate((action) => window.ownershipProbe.step(action), name);
    try {
      await page.goto(`http://127.0.0.1:${server.address().port}/?case=${caseId}`, {
        waitUntil: 'load',
      });
      await page.waitForFunction(
        () => window.ownershipProbe?.ready || window.ownershipProbe?.initializationError
      );
      const initializationError = await page.evaluate(
        () => window.ownershipProbe.initializationError
      );
      if (initializationError) throw new Error(initializationError);
      const initial = await capture('settled-initial');
      const initialId = initial.targetId;
      if (caseId !== 'wc-provider-binding') {
        const isExplicit = caseId.startsWith('explicit');
        const isWriter = caseId.startsWith('independent');
        const isReplay = caseId.endsWith('-replay');
        check(
          'initial-target-identity',
          isExplicit ? 'proto-id' : 'non-empty generated ID',
          initialId,
          isExplicit ? initialId === 'proto-id' : Boolean(initialId),
          [`${C}-J`]
        );
        check(
          'initial-controls',
          initialId,
          initial.controls,
          Boolean(initialId) && initial.controls === initialId,
          [`${C}-C`]
        );
        if (isReplay)
          check('normal-State-initial-value', false, initial.busy, initial.busy === false, []);
        const immediate = await step('stimulate');
        const after = await capture('after-mutation-observer-delivery', immediate);
        if (isReplay)
          check(
            'normal-State-committed-before-delivery',
            true,
            immediate.state.busy,
            immediate.state.busy === true,
            []
          );
        if (isReplay)
          check(
            'normal-State-reaches-A11y-before-observer-delivery',
            'target projector receives busy=true in the same stimulus call',
            immediate.observation.stateReplaySubmissions,
            immediate.observation.stateReplaySubmissions.some(
              (submission) => submission.actor === 'target' && submission.input.states.busy === true
            ),
            []
          );
        if (isWriter) {
          check(
            'independent-write-return-fails-closed',
            null,
            immediate.observation.writeReturn.controls,
            immediate.observation.writeReturn.controls === null,
            ['C-A11Y-0001-O', 'C-A11Y-0001-P', `${C}-J`]
          );
          check(
            'independent-owned-id-after-delivery',
            'independent-id',
            after.targetId,
            after.targetId === 'independent-id',
            [`${C}-J`]
          );
          check(
            'independent-owner-is-not-host-authorship',
            null,
            after.controls,
            after.controls === null,
            ['C-A11Y-0001-P', `${C}-J`]
          );
          if (caseId === 'independent-writer-absent') {
            const removed = await step('remove-dependent-relation');
            check(
              'dependent-relation-absent',
              null,
              removed.state.controls,
              removed.state.controls === null,
              ['C-A11Y-0001-O']
            );
            await capture('dependent-relation-absent', removed);
          }
          const released = await step('release-writer');
          let restored = await capture('after-writer-disposal-observation', released);
          if (caseId === 'independent-writer-absent')
            restored = await capture(
              'after-dependent-relation-return',
              await step('restore-dependent-relation')
            );
          check(
            'writer-release-restores-original-generated-id',
            initialId,
            restored.targetId,
            restored.targetId === initialId,
            ['C-A11Y-0001-P', `${C}-J`]
          );
          check(
            'writer-release-restores-original-controls',
            initialId,
            restored.controls,
            restored.controls === initialId,
            ['C-A11Y-0001-P', `${C}-J`]
          );
        } else {
          check(
            'host-authored-id-survives-delivery',
            'host-later',
            after.targetId,
            after.targetId === 'host-later',
            [`${C}-J`]
          );
          check(
            'controls-rebind-to-host-authored-id',
            'host-later',
            after.controls,
            after.controls === 'host-later',
            [`${C}-J`]
          );
        }
        const disposed = await capture('target-disposal', await step('dispose-target'));
        check(
          'target-disposal-withdraws-dependent',
          null,
          disposed.controls,
          disposed.controls === null,
          [`${C}-F`]
        );
        if (!isWriter)
          check(
            'target-disposal-preserves-later-author-id',
            'host-later',
            disposed.targetId,
            disposed.targetId === 'host-later',
            [`${C}-J`]
          );
      } else {
        const sourceToken = `source-caption ${initialId}`;
        check(
          'provider-normal-control',
          sourceToken,
          initial.controls,
          Boolean(initialId) && initial.controls === sourceToken,
          [`${C}-D`, `${C}-K`]
        );
        const replaceTarget = await step('replace-target');
        const bound = replaceTarget.observation.beforeReveal;
        check(
          'target-replacement-before-reveal',
          sourceToken,
          bound.controls,
          bound.controls === sourceToken &&
            bound.targetId === initialId &&
            bound.nodes['target-boundary'].attributes.hidden === '',
          [`${C}-K`]
        );
        check(
          'physical-target-identity-changed',
          initial.currentTarget.nodeId,
          bound.currentTarget.nodeId,
          bound.currentTarget.nodeId !== initial.currentTarget.nodeId,
          []
        );
        check(
          'exact-empty-id-restored-on-old-target',
          '',
          bound.nodes['target-first'].attributes.id,
          bound.nodes['target-first'].attributes.id === '',
          [`${C}-J`, `${C}-K`]
        );
        const targetBeforeReveal = await capture('target-replacement-before-reveal', replaceTarget);
        check(
          'target-replacement-survives-observer-before-reveal',
          sourceToken,
          targetBeforeReveal.controls,
          targetBeforeReveal.controls === sourceToken &&
            targetBeforeReveal.targetId === initialId &&
            targetBeforeReveal.nodes['target-boundary'].attributes.hidden === '',
          [`${C}-K`]
        );
        await step('reveal');
        await capture('target-replacement-revealed');
        const conflict = await step('conflict-target');
        const closed = conflict.observation.beforeReveal;
        check(
          'different-authored-id-fails-closed',
          { id: 'host-different', controls: 'source-caption' },
          { id: closed.targetId, controls: closed.controls },
          closed.targetId === 'host-different' && closed.controls === 'source-caption',
          [`${C}-J`, `${C}-K`]
        );
        check(
          'old-target-owned-id-released',
          null,
          closed.nodes['target-second'].attributes.id ?? null,
          !('id' in closed.nodes['target-second'].attributes),
          [`${C}-J`, `${C}-K`]
        );
        const conflictBeforeReveal = await capture('conflicting-target-before-reveal', conflict);
        check(
          'authored-conflict-remains-closed-before-reveal',
          { id: 'host-different', controls: 'source-caption' },
          { id: conflictBeforeReveal.targetId, controls: conflictBeforeReveal.controls },
          conflictBeforeReveal.targetId === 'host-different' &&
            conflictBeforeReveal.controls === 'source-caption',
          [`${C}-J`, `${C}-K`]
        );
        await step('reveal');
        await capture('conflicting-target-revealed');
        const recovered = await step('restore-target');
        check(
          'target-binding-recovery',
          sourceToken,
          recovered.observation.beforeReveal.controls,
          recovered.observation.beforeReveal.controls === sourceToken &&
            recovered.observation.beforeReveal.targetId === initialId,
          [`${C}-K`]
        );
        await capture('target-binding-recovered-before-reveal', recovered);
        await step('reveal');
        let attempted = await step('old-target-epoch');
        check(
          'old-target-epoch-rejected',
          sourceToken,
          attempted.state.controls,
          attempted.state.controls === sourceToken && attempted.state.targetId === initialId,
          [`${C}-A`, `${C}-E`]
        );
        await capture('old-target-epoch-rejected', attempted);
        attempted = await step('old-source-epoch');
        check(
          'old-source-epoch-rejected',
          sourceToken,
          attempted.state.controls,
          attempted.state.controls === sourceToken,
          [`${C}-A`, `${C}-E`]
        );
        await capture('old-source-epoch-rejected', attempted);
        attempted = await step('advance-target-epoch');
        check(
          'same-id-new-epoch-invalidates-stale-dependent',
          'source-caption',
          attempted.state.controls,
          attempted.state.controls === 'source-caption' && attempted.state.targetId === initialId,
          [`${C}-A`, `${C}-E`]
        );
        await capture('new-target-epoch-stale-dependent', attempted);
        attempted = await step('refresh-source-target-epoch');
        check(
          'current-target-epoch-recovers',
          sourceToken,
          attempted.state.controls,
          attempted.state.controls === sourceToken,
          [`${C}-A`, `${C}-E`]
        );
        await capture('current-target-epoch-restored', attempted);
        const replacedSource = await step('replace-source');
        const nextSource = replacedSource.observation.beforeReveal;
        check(
          'source-replacement-before-reveal',
          `replacement-caption ${initialId}`,
          nextSource.controls,
          nextSource.controls === `replacement-caption ${initialId}` &&
            nextSource.nodes['source-boundary'].attributes.hidden === '',
          [`${C}-K`]
        );
        check(
          'physical-source-identity-changed',
          initial.currentSource.nodeId,
          nextSource.currentSource.nodeId,
          nextSource.currentSource.nodeId !== initial.currentSource.nodeId,
          []
        );
        check(
          'old-source-author-token-survives',
          'source-caption',
          nextSource.nodes.source.attributes['aria-controls'],
          nextSource.nodes.source.attributes['aria-controls'] === 'source-caption',
          [`${C}-D`, `${C}-K`]
        );
        const sourceBeforeReveal = await capture(
          'source-replacement-before-reveal',
          replacedSource
        );
        check(
          'source-replacement-survives-observer-before-reveal',
          `replacement-caption ${initialId}`,
          sourceBeforeReveal.controls,
          sourceBeforeReveal.controls === `replacement-caption ${initialId}` &&
            sourceBeforeReveal.nodes['source-boundary'].attributes.hidden === '',
          [`${C}-K`]
        );
        await step('reveal');
        await capture('source-replacement-revealed');
        const unbound = await step('unbind-source');
        check(
          'source-unbind-releases-owned-token',
          'replacement-caption',
          unbound.observation.beforeReveal.controls,
          unbound.observation.beforeReveal.controls === 'replacement-caption' &&
            unbound.state.providerBindings.source === null,
          [`${C}-D`, `${C}-K`]
        );
        await capture('source-unbound', unbound);
        const rebound = await step('restore-source');
        check(
          'original-source-rebind',
          sourceToken,
          rebound.observation.beforeReveal.controls,
          rebound.observation.beforeReveal.controls === sourceToken,
          [`${C}-K`]
        );
        await capture('source-rebound-before-reveal', rebound);
        await step('reveal');
        const oldNode = await capture('old-target-host-rewrite', await step('mutate-old-target'));
        check(
          'old-target-cannot-affect-current-binding',
          sourceToken,
          oldNode.controls,
          oldNode.controls === sourceToken && oldNode.targetId === initialId,
          [`${C}-J`, `${C}-K`]
        );
      }
      await page.evaluate(() => window.ownershipProbe.cleanup());
      const evidence = await page.evaluate(() => window.ownershipProbe.evidence());
      await fsp.writeFile(path.join(directory, 'trace.json'), JSON.stringify(evidence, null, 2));
      check('page-errors', [], errors, errors.length === 0, []);
      check('console-warning-errors', [], consoleMessages, consoleMessages.length === 0, []);
      const result = {
        caseId,
        assertions,
        checkpoints,
        errors,
        consoleMessages,
        scope: provenance.scope,
      };
      await fsp.writeFile(path.join(directory, 'results.json'), JSON.stringify(result, null, 2));
      results.push(result);
      console.log(
        JSON.stringify({
          caseId,
          passed: assertions.filter((x) => x.pass).length,
          failed: assertions.filter((x) => !x.pass).map((x) => x.id),
          errors,
        })
      );
    } catch (error) {
      const executionError = String(error?.stack ?? error);
      const evidence = await page
        .evaluate(() => window.ownershipProbe?.evidence?.() ?? null)
        .catch(() => null);
      const result = {
        caseId,
        classification: 'fixture-execution-failure, not a demonstrated ownership assertion failure',
        executionError,
        assertions,
        checkpoints,
        errors,
        consoleMessages,
      };
      await fsp.writeFile(
        path.join(directory, 'execution-failure.json'),
        JSON.stringify({ ...result, evidence }, null, 2)
      );
      results.push(result);
      console.log(JSON.stringify({ caseId, executionError }));
    } finally {
      await context.close();
    }
  }
} finally {
  provenance.finishedAt = new Date().toISOString();
  provenance.status = 'browser run completed; inspect per-case results and execution failures';
  await fsp.writeFile(path.join(outputDir, 'provenance.json'), JSON.stringify(provenance, null, 2));
  await fsp.writeFile(path.join(outputDir, 'results.json'), JSON.stringify(results, null, 2));
  await browser.close();
  await new Promise((resolve) => server.close(resolve));
}
process.exitCode = results.some(
  (result) => result.executionError || result.assertions.some((check) => !check.pass)
)
  ? 1
  : 0;
