import {
  createAnatomyFamily,
  createA11ySemanticObjectRef,
  definePrototype,
  type A11ySemanticObjectSnapshot,
  type OwnedStateHandle,
} from '@proto.ui/core';
import { asAccessible } from '@proto.ui/hooks';
import { createRuntimeSession } from '@proto.ui/runtime';
import { createHostSurfaceProjection, createHostWiring } from '@proto.ui/adapter-base';
import {
  A11Y_PROJECT_CAP,
  createWebA11yProjectionRegistry,
  createWebA11yProjector,
  type A11yPort,
  type A11yProjector,
} from '@proto.ui/module-a11y';
import { createWebComponentModules } from 'ownership:wc-provider';
import {
  createLogicalInstance,
  markProtoInstance,
  unbindProtoInstance,
} from 'ownership:wc-instance-tree';

const caseId = new URL(location.href).searchParams.get('case') ?? 'explicit-id';
const providerCase = caseId === 'wc-provider-binding';
const revocationCase = caseId.startsWith('pending-') || caseId.startsWith('detached-');
const detachedAuthor = caseId.startsWith('detached-');
const replacementBoundary = caseId.includes('-replace-');
const observerFirst = caseId.endsWith('-observer-first');
const stateReplay = caseId.endsWith('-replay');
const explicit = caseId.startsWith('explicit') || (revocationCase && caseId.includes('-explicit-'));
const independent = caseId.startsWith('independent');
const absentDependent = caseId === 'independent-writer-absent';
const family = createAnatomyFamily(
  revocationCase ? 'review-id-detach' : 'explicit-part-id-review',
  {
    roles: {
      root: { cardinality: { min: 1, max: 1 } },
      source: { cardinality: { min: 0, max: '*' } },
      target: { cardinality: { min: 0, max: '*' } },
    },
  }
);
const scope = {};
const nodes = new Map<string, HTMLElement>();
const nodeIds = new WeakMap<Node, number>();
const refIds = new WeakMap<object, number>();
const trace: unknown[] = [];
const submissions: unknown[] = [];
let nodeSequence = 0;
let refSequence = 0;
let sequence = 0;
let currentSource: HTMLElement;
let currentTarget: HTMLElement;
let readBusy: (() => boolean) | null = null;
let setBusy: (() => void) | null = null;
let targetDisposed = false;
let ready = false;
let initializationError: string | null = null;
let epochInputs = { source: 1, target: 1, relationTarget: 1 };
let sourceSnapshot: A11ySemanticObjectSnapshot;
let targetSnapshot: A11ySemanticObjectSnapshot;
let dependent: A11yProjector;
let projector: A11yProjector;
let writer: A11yProjector | null = null;
let createWriter: (() => A11yProjector) | null = null;
let targetRuntime: ReturnType<typeof createRuntimeSession> | null = null;
const sessions: Array<ReturnType<typeof createRuntimeSession>> = [];
const providers: Array<ReturnType<typeof makeProvider>> = [];
let sourceProvider: ReturnType<typeof makeProvider> | null = null;
let targetProvider: ReturnType<typeof makeProvider> | null = null;

function nodeId(node: Node) {
  if (!nodeIds.has(node)) nodeIds.set(node, ++nodeSequence);
  return nodeIds.get(node)!;
}
function refId(ref: object) {
  if (!refIds.has(ref)) refIds.set(ref, ++refSequence);
  return refIds.get(ref)!;
}
function identify(node: Node) {
  return {
    nodeId: nodeId(node),
    name: [...nodes].find(([, value]) => value === node)?.[0] ?? null,
    nodeName: node.nodeName,
  };
}
function node(name: string, tag: string) {
  const element = document.createElement(tag);
  nodes.set(name, element);
  nodeId(element);
  return element;
}
function snapshot() {
  return {
    caseId,
    fixtureKind:
      providerCase || revocationCase
        ? 'actual WC host-capability provider'
        : stateReplay
          ? 'actual Runtime State and WC provider'
          : 'actual Web projector',
    targetId: currentTarget?.getAttribute('id') ?? null,
    controls: currentSource?.getAttribute('aria-controls') ?? null,
    busy: readBusy ? readBusy() : null,
    targetDisposed,
    currentSource: currentSource ? identify(currentSource) : null,
    currentTarget: currentTarget ? identify(currentTarget) : null,
    sourceBound: dependent?.isBound?.() ?? null,
    targetBound: projector?.isBound?.() ?? null,
    providerBindings:
      providerCase || revocationCase
        ? {
            source: sourceProvider?.surface.getSurfaceTarget()
              ? identify(sourceProvider.surface.getSurfaceTarget()!)
              : null,
            target: targetProvider?.surface.getSurfaceTarget()
              ? identify(targetProvider.surface.getSurfaceTarget()!)
              : null,
          }
        : null,
    suppliedEpochs: { ...epochInputs },
    nodes: Object.fromEntries(
      [...nodes].map(([name, element]) => [
        name,
        {
          ...identify(element),
          connected: element.isConnected,
          parent: element.parentNode ? identify(element.parentNode) : null,
          attributes: Object.fromEntries(
            element.getAttributeNames().map((key) => [key, element.getAttribute(key)])
          ),
          outerHTML: element.outerHTML,
          hostBarrier: element.closest('[hidden]') ? identify(element.closest('[hidden]')!) : null,
          renderedRects: element.getClientRects().length,
        },
      ])
    ),
  };
}
function record(phase: string, detail?: unknown) {
  trace.push({ seq: ++sequence, time: performance.now(), phase, detail, snapshot: snapshot() });
}
function inputSummary(input: A11ySemanticObjectSnapshot) {
  return {
    objectRef: refId(input.objectRef),
    viewEpoch: input.viewEpoch ?? null,
    id: input.id ?? null,
    states: { ...input.states },
    relations: Object.fromEntries(
      Object.entries(input.relations).map(([key, value]) => [
        key,
        Array.isArray(value) ? value.map(refId) : value,
      ])
    ),
    partRelationships:
      input.partRelationships?.map((part) => ({
        sourceRef: refId(part.source),
        targetRef: part.target ? refId(part.target) : null,
        sourceRole: part.sourceRole,
        targetRole: part.targetRole,
        key: part.key,
        sourceEpoch: part.sourceEpoch,
        targetEpoch: part.targetEpoch,
      })) ?? [],
  };
}
function observedProjector(name: string, original: A11yProjector): A11yProjector {
  const observed: A11yProjector = (input) => {
    const summary = { actor: name, input: inputSummary(input) };
    submissions.push(summary);
    record('projector-input', summary);
    original(input);
    record('projector-return', { actor: name });
  };
  // Forward the real projector lifecycle/readiness methods; no projection logic is copied.
  return Object.assign(observed, original);
}
const observer = new MutationObserver((batch) => {
  record(
    'mutation-delivery',
    batch.map((mutation, index) => {
      const later = batch
        .slice(index + 1)
        .find(
          (next) =>
            next.type === 'attributes' &&
            next.target === mutation.target &&
            next.attributeName === mutation.attributeName
        );
      return {
        ...identify(mutation.target),
        type: mutation.type,
        attribute: mutation.attributeName,
        oldValue: mutation.oldValue,
        newValue:
          mutation.type === 'attributes'
            ? later
              ? later.oldValue
              : (mutation.target as Element).getAttribute(mutation.attributeName!)
            : undefined,
        added: [...mutation.addedNodes].map(identify),
        removed: [...mutation.removedNodes].map(identify),
      };
    })
  );
});
observer.observe(document.body, {
  subtree: true,
  attributes: true,
  attributeOldValue: true,
  childList: true,
});

function emptySnapshot(
  objectRef: ReturnType<typeof createA11ySemanticObjectRef>
): A11ySemanticObjectSnapshot {
  return { objectRef, states: {}, actions: {}, relations: {} };
}
function structuredSource(
  sourceRef: ReturnType<typeof createA11ySemanticObjectRef>,
  targetRef: ReturnType<typeof createA11ySemanticObjectRef>,
  sourceEpoch: number,
  targetEpoch: number
): A11ySemanticObjectSnapshot {
  return {
    ...emptySnapshot(sourceRef),
    viewEpoch: sourceEpoch,
    relations: { controls: [targetRef] },
    relationModes: { controls: 'append' },
    partRelationships: [
      {
        family,
        scope,
        source: sourceRef,
        sourceRole: 'source',
        targetRole: 'target',
        relation: 'controls',
        key: revocationCase ? 'x' : 'exact-key',
        sourceEpoch,
        targetEpoch,
        target: targetRef,
      },
    ],
  };
}

function makeProvider(
  name: string,
  boundary: HTMLElement,
  physical: HTMLElement,
  proto = definePrototype({ name: `ownership-${name}`, setup() {} })
) {
  const token = createLogicalInstance(proto);
  markProtoInstance(boundary, proto, token);
  const surface = createHostSurfaceProjection<HTMLElement>(boundary, physical);
  const modules = createWebComponentModules({
    el: boundary,
    surfaceProjection: surface,
    instanceToken: token,
    router: { rootTarget: boundary, globalTarget: window },
    rawPropsSource: { get: () => ({}), subscribe: () => () => {} },
    effectsPort: { queueStyle() {}, requestFlush() {} },
    textControlTarget: null,
    imageViewTarget: null,
    getMeta: () => undefined,
    setExposes() {},
    runInCallbackScope: (fn: () => void) => fn(),
    isViewReady: () => true,
    subscribeTargetReady: () => () => {},
    retryTargetReady() {},
  });
  const original = modules.a11y!({ prototypeName: proto.name }).find(
    ([cap]) => cap === A11Y_PROJECT_CAP
  )![1] as A11yProjector;
  const observed = observedProjector(name, original);
  const a11y = modules.a11y!;
  modules.a11y = (context) =>
    a11y(context).map(([cap, value]) => [cap, cap === A11Y_PROJECT_CAP ? observed : value]);
  return {
    surface,
    modules,
    projector: observed,
    proto,
    dispose() {
      observed.dispose?.();
      unbindProtoInstance(token);
    },
  };
}

function initializeDirect() {
  currentSource = node('source', 'button');
  currentTarget = node('target', 'section');
  document.body.append(currentSource, currentTarget);
  const registry = createWebA11yProjectionRegistry();
  const sourceRef = createA11ySemanticObjectRef();
  const targetRef = createA11ySemanticObjectRef();
  dependent = observedProjector(
    'source',
    createWebA11yProjector(currentSource, undefined, registry)
  );
  projector = observedProjector(
    'target',
    createWebA11yProjector(currentTarget, undefined, registry)
  );
  targetSnapshot = {
    ...emptySnapshot(targetRef),
    viewEpoch: 1,
    ...(explicit ? { id: 'proto-id' } : {}),
  };
  sourceSnapshot = structuredSource(sourceRef, targetRef, 1, 1);
  projector(targetSnapshot);
  dependent(sourceSnapshot);
  if (independent)
    createWriter = () =>
      observedProjector(
        'independent-writer',
        createWebA11yProjector(currentTarget, undefined, registry)
      );
}

async function initializeStateReplay() {
  const root = node('root-boundary', 'x-ownership-root');
  const sourceBoundary = node('source-boundary', 'x-ownership-source');
  const targetBoundary = node('target-boundary', 'x-ownership-target');
  currentSource = node('source', 'button');
  currentTarget = node('target', 'section');
  sourceBoundary.append(currentSource);
  targetBoundary.append(currentTarget);
  root.append(sourceBoundary, targetBoundary);
  document.body.append(root);
  let busy!: OwnedStateHandle<boolean>;
  const makeSession = (
    role: 'root' | 'source' | 'target',
    boundary: HTMLElement,
    physical: HTMLElement
  ) => {
    const proto = definePrototype({
      name: `ownership-state-${role}`,
      setup(def) {
        def.anatomy.claim(family, { role });
        if (role === 'root') return;
        const accessible = asAccessible();
        accessible.part(family, { key: 'exact-key' });
        if (role === 'source') {
          accessible.relation('controls', {
            target: { kind: 'part', family, role: 'target', key: 'exact-key' },
            mode: 'append',
          });
        } else {
          if (explicit) accessible.id('proto-id');
          busy = def.state.bool('busy', false);
          accessible.state('busy', busy);
        }
      },
    });
    const provider = makeProvider(role, boundary, physical, proto);
    providers.push(provider);
    const wiring = createHostWiring({ prototypeName: proto.name, modules: provider.modules });
    const session = createRuntimeSession(proto, {
      prototypeName: proto.name,
      getRawProps: () => ({}),
      schedule: (task) => queueMicrotask(task),
      commit(_children, signal) {
        record(`runtime:${role}:host-commit`);
        signal?.done();
      },
      onRuntimeReady: (api) => wiring.onRuntimeReady(api),
      onLifecycleEvent: (event) => record(`runtime:${role}:lifecycle`, event),
    });
    sessions.push(session);
    return { provider, session };
  };
  const rootPart = makeSession('root', root, root);
  await rootPart.session.mount();
  const targetPart = makeSession('target', targetBoundary, currentTarget);
  targetRuntime = targetPart.session;
  projector = targetPart.provider.projector;
  readBusy = () => busy.get();
  setBusy = () =>
    targetPart.session.invokeInCallbackScope(() =>
      busy.set(true, 'host-contract ordinary State update')
    );
  await targetPart.session.mount();
  const sourcePart = makeSession('source', sourceBoundary, currentSource);
  dependent = sourcePart.provider.projector;
  await sourcePart.session.mount();
  targetSnapshot = targetPart.session.caps.getPort<A11yPort>('a11y')!.getSnapshot();
  sourceSnapshot = sourcePart.session.caps.getPort<A11yPort>('a11y')!.getSnapshot();
  if (independent)
    createWriter = () =>
      observedProjector('independent-writer', createWebA11yProjector(currentTarget));
}

function initializeProvider() {
  const targetBoundary = node('target-boundary', 'x-wc-binding-provider');
  const sourceBoundary = node('source-boundary', 'x-wc-source-provider');
  currentSource = node('source', 'button');
  currentSource.setAttribute('aria-controls', 'source-caption');
  currentTarget = node('target-first', 'input');
  currentTarget.setAttribute('id', '');
  node('target-second', 'textarea');
  node('target-conflict', 'input').id = 'host-different';
  node('source-replacement', 'button').setAttribute('aria-controls', 'replacement-caption');
  sourceBoundary.append(currentSource);
  targetBoundary.append(currentTarget);
  document.body.append(targetBoundary, sourceBoundary);
  targetProvider = makeProvider('target-provider', targetBoundary, currentTarget);
  sourceProvider = makeProvider('source-provider', sourceBoundary, currentSource);
  providers.push(targetProvider, sourceProvider);
  projector = targetProvider.projector;
  dependent = sourceProvider.projector;
  const targetRef = createA11ySemanticObjectRef(),
    sourceRef = createA11ySemanticObjectRef();
  epochInputs = { source: 4, target: 3, relationTarget: 3 };
  targetSnapshot = { ...emptySnapshot(targetRef), viewEpoch: 3 };
  sourceSnapshot = structuredSource(sourceRef, targetRef, 4, 3);
  projector(targetSnapshot);
  dependent(sourceSnapshot);
}

function initializeRevocation() {
  const targetBoundary = node('target-boundary', 'x-wc-revocation-target');
  const sourceBoundary = node('source-boundary', 'x-wc-revocation-source');
  currentSource = node('source', 'button');
  currentTarget = node('target-original', 'section');
  node('target-successor', 'section');
  sourceBoundary.append(currentSource);
  targetBoundary.append(currentTarget);
  document.body.append(sourceBoundary, targetBoundary);
  // Match the review's target-before-dependent construction and submission order.
  // Replacement notifications use the actual WC provider, not a copied target slot.
  targetProvider = makeProvider('target-provider', targetBoundary, currentTarget);
  sourceProvider = makeProvider('source-provider', sourceBoundary, currentSource);
  providers.push(targetProvider, sourceProvider);
  projector = targetProvider.projector;
  dependent = sourceProvider.projector;
  const targetRef = createA11ySemanticObjectRef();
  const sourceRef = createA11ySemanticObjectRef();
  targetSnapshot = {
    ...emptySnapshot(targetRef),
    viewEpoch: 1,
    ...(explicit ? { id: 'proto-id' } : {}),
  };
  sourceSnapshot = structuredSource(sourceRef, targetRef, 1, 1);
  projector(targetSnapshot);
  dependent(sourceSnapshot);
}

function writeLiveIdentity() {
  currentTarget.id = 'host-later';
  record('revocation:live-host-write-return');
  return snapshot();
}

function revokeView(writeBeforeBoundary: boolean) {
  let writeReturn: ReturnType<typeof snapshot> | null = null;
  let detached: ReturnType<typeof snapshot> | null = null;
  const targetBoundary = nodes.get('target-boundary')!;
  if (writeBeforeBoundary && !detachedAuthor) writeReturn = writeLiveIdentity();
  if (replacementBoundary) {
    targetBoundary.hidden = true;
    record('revocation:replacement-barrier');
    const successor = nodes.get('target-successor')!;
    currentTarget.replaceWith(successor);
    currentTarget = successor;
    record('revocation:replacement-DOM-before-provider');
    targetProvider!.surface.setSurfaceTarget(successor);
    record('revocation:replacement-provider-return-before-reveal');
  } else {
    projector.detach?.();
    record('revocation:detach-return-before-hide');
    detached = snapshot();
    targetBoundary.hidden = true;
    record('revocation:detached-host-barrier');
    if (detachedAuthor) {
      currentTarget.id = 'host-later';
      record('revocation:host-write-while-detached');
      writeReturn = snapshot();
    }
    projector.reactivate?.();
    epochInputs.target = 2;
    epochInputs.relationTarget = 2;
    targetSnapshot = { ...targetSnapshot, viewEpoch: 2 };
    sourceSnapshot = {
      ...sourceSnapshot,
      partRelationships: sourceSnapshot.partRelationships!.map((part) => ({
        ...part,
        targetEpoch: 2,
      })),
    };
    projector(targetSnapshot);
    dependent(sourceSnapshot);
    record('revocation:rematerialized-before-reveal');
  }
  return { writeReturn, detached, beforeReveal: snapshot() };
}

function replaceBinding(which: 'source' | 'target', name: string | null) {
  const boundary = nodes.get(`${which}-boundary`)!;
  const provider = which === 'source' ? sourceProvider! : targetProvider!;
  boundary.hidden = true;
  record(`host:${which}-replacement:barrier`, { binding: name });
  if (name) {
    const next = nodes.get(name)!;
    boundary.replaceChildren(next);
    if (which === 'source') currentSource = next;
    else currentTarget = next;
    record(`host:${which}-replacement:DOM-before-provider`, { binding: name });
    provider.surface.setSurfaceTarget(next);
  } else {
    provider.surface.setSurfaceTarget(null);
  }
  record(`host:${which}-replacement:provider-return-before-reveal`, { binding: name });
  const beforeReveal = snapshot();
  if (!name) boundary.replaceChildren();
  return { beforeReveal, hiddenBoundary: identify(boundary) };
}

async function step(name: string) {
  record(`stimulus:${name}:before`);
  let observation: unknown = null;
  if (name === 'revocation-live-write') observation = { writeReturn: writeLiveIdentity() };
  else if (name === 'revocation-boundary') observation = revokeView(!observerFirst);
  else if (name === 'stimulate') {
    if (independent) {
      writer ??= createWriter!();
      writer({ ...emptySnapshot(createA11ySemanticObjectRef()), id: 'independent-id' });
      record('independent-write-return');
    } else {
      currentTarget.id = 'host-later';
      record('host-write-return');
    }
    const writeReturn = snapshot();
    const replayStart = submissions.length;
    if (stateReplay) {
      setBusy!();
      record('unrelated-state-replay-before-observer-delivery');
    }
    observation = { writeReturn, stateReplaySubmissions: submissions.slice(replayStart) };
  } else if (name === 'remove-dependent-relation') {
    dependent({ ...emptySnapshot(sourceSnapshot.objectRef), viewEpoch: 1 });
  } else if (name === 'release-writer') {
    writer!.dispose?.();
    record('independent-writer-disposal-return');
  } else if (name === 'restore-dependent-relation') {
    dependent(sourceSnapshot);
  } else if (name === 'dispose-target') {
    readBusy = null;
    targetDisposed = true;
    if (targetRuntime) await targetRuntime.dispose();
    else projector.dispose?.();
    record('target-disposal');
  } else if (name === 'replace-target') observation = replaceBinding('target', 'target-second');
  else if (name === 'conflict-target') observation = replaceBinding('target', 'target-conflict');
  else if (name === 'restore-target') observation = replaceBinding('target', 'target-second');
  else if (name === 'replace-source') observation = replaceBinding('source', 'source-replacement');
  else if (name === 'unbind-source') observation = replaceBinding('source', null);
  else if (name === 'restore-source') observation = replaceBinding('source', 'source');
  else if (name === 'reveal') {
    nodes.get('source-boundary')!.hidden = false;
    nodes.get('target-boundary')!.hidden = false;
  } else if (name === 'old-target-epoch') projector({ ...targetSnapshot, viewEpoch: 2 });
  else if (name === 'old-source-epoch') dependent({ ...sourceSnapshot, viewEpoch: 3 });
  else if (name === 'advance-target-epoch') {
    epochInputs.target = 4;
    targetSnapshot = { ...targetSnapshot, viewEpoch: 4 };
    projector(targetSnapshot);
  } else if (name === 'refresh-source-target-epoch') {
    epochInputs.relationTarget = 4;
    sourceSnapshot = {
      ...sourceSnapshot,
      partRelationships: sourceSnapshot.partRelationships!.map((part) => ({
        ...part,
        targetEpoch: 4,
      })),
    };
    dependent(sourceSnapshot);
  } else if (name === 'mutate-old-target') {
    const old = nodes.get('target-first')!;
    old.id = 'old-node-later';
    document.body.append(old);
  } else throw new Error(`Unknown host stimulus: ${name}`);
  record(`stimulus:${name}:return`);
  return { observation, state: snapshot() };
}

async function cleanup() {
  readBusy = null;
  for (const session of [...sessions].reverse()) await session.dispose();
  writer?.dispose?.();
  if (!sessions.length) {
    projector?.dispose?.();
    dependent?.dispose?.();
  }
  for (const provider of providers) provider.dispose();
  record('fixture:cleanup');
  observer.disconnect();
}

(window as any).ownershipProbe = {
  get ready() {
    return ready;
  },
  get initializationError() {
    return initializationError;
  },
  snapshot,
  step,
  nextFrame: (label: string) =>
    new Promise((resolve) =>
      requestAnimationFrame(() => {
        record(label);
        resolve(snapshot());
      })
    ),
  evidence: () => ({
    caseId,
    stateReplay,
    explicit,
    independent,
    absentDependent,
    revocationCase,
    detachedAuthor,
    replacementBoundary,
    observerFirst,
    trace,
    submissions,
  }),
  cleanup,
};
void (async () => {
  if (revocationCase) initializeRevocation();
  else if (providerCase) initializeProvider();
  else if (stateReplay) await initializeStateReplay();
  else initializeDirect();
  ready = true;
  record('fixture:ready');
})().catch((error) => {
  initializationError = String(error?.stack ?? error);
  record('fixture:initialization-error', initializationError);
});
