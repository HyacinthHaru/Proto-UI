import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createServer } from 'node:http';
import { createHash } from 'node:crypto';

const sourceRoot = process.env.SOURCE_ROOT && path.resolve(process.env.SOURCE_ROOT);
const outputDir = process.env.OUTPUT_DIR && path.resolve(process.env.OUTPUT_DIR);
if (!sourceRoot || !outputDir) throw new Error('SOURCE_ROOT and OUTPUT_DIR are required.');
if (sourceRoot === outputDir || outputDir.startsWith(`${sourceRoot}${path.sep}`)) {
  throw new Error('OUTPUT_DIR must be outside SOURCE_ROOT.');
}
const here = path.dirname(fileURLToPath(import.meta.url));
const requireSource = createRequire(path.join(sourceRoot, 'package.json'));
const requireWWW = createRequire(path.join(sourceRoot, 'apps/www/package.json'));
const esbuild = requireSource('esbuild');
const { chromium } = requireWWW('playwright-core');
const adapter = 'wc';
if (!['wc', 'react', 'vue', 'vue2'].includes(adapter))
  throw new Error(`Unknown ADAPTER: ${adapter}`);

const sha256 = (data) => createHash('sha256').update(data).digest('hex');
await fsp.mkdir(outputDir, { recursive: true });
const git = (...args) =>
  execFileSync('git', ['-C', sourceRoot, ...args], { encoding: 'utf8' }).trim();

function resolveWorkspace(id) {
  if (!id.startsWith('@proto.ui/')) return null;
  const [pkg, ...rest] = id.slice('@proto.ui/'.length).split('/');
  const scope = pkg.startsWith('module-')
    ? `modules/${pkg.slice(7)}`
    : pkg.startsWith('adapter-')
      ? `adapters/${pkg.slice(8)}`
      : pkg.startsWith('prototypes-')
        ? `prototypes/${pkg.slice(11)}`
        : pkg.startsWith('spec-')
          ? `spec/${pkg.slice(5)}`
          : pkg;
  const packageDir = path.join(sourceRoot, 'packages', scope);
  const manifest = JSON.parse(fs.readFileSync(path.join(packageDir, 'package.json'), 'utf8'));
  const exportKey = rest.length ? `./${rest.join('/')}` : '.';
  let entry = manifest.exports?.[exportKey];
  let wildcard = '';
  if (!entry) {
    for (const [key, value] of Object.entries(manifest.exports ?? {})) {
      if (!key.includes('*')) continue;
      const [prefix, suffix] = key.split('*');
      if (exportKey.startsWith(prefix) && exportKey.endsWith(suffix)) {
        entry = value;
        wildcard = exportKey.slice(prefix.length, suffix ? -suffix.length : undefined);
        break;
      }
    }
  }
  if (!entry) throw new Error(`Undeclared workspace import: ${id}`);
  const target = typeof entry === 'string' ? entry : (entry.import ?? entry.default ?? entry.types);
  const source = target
    .replace('*', wildcard)
    .replace('./dist/', './src/')
    .replace(/\.d\.ts$/, '.ts')
    .replace(/\.js$/, '.ts');
  const resolved = path.resolve(packageDir, source);
  if (!fs.existsSync(resolved))
    throw new Error(`Source export does not exist: ${id} -> ${resolved}`);
  return resolved;
}

const built = await esbuild.build({
  entryPoints: [path.join(here, 'part-fixture.ts')],
  outfile: path.join(outputDir, 'fixture.js'),
  absWorkingDir: sourceRoot,
  bundle: true,
  format: 'esm',
  platform: 'browser',
  target: 'es2020',
  sourcemap: true,
  metafile: true,
  define: {
    __PROBE_ADAPTER__: JSON.stringify(adapter),
    'process.env.NODE_ENV': '"development"',
    __VUE_OPTIONS_API__: 'true',
    __VUE_PROD_DEVTOOLS__: 'false',
    __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: 'false',
  },
  nodePaths: [
    path.join(sourceRoot, 'node_modules'),
    path.join(sourceRoot, 'apps/www/node_modules'),
  ],
  plugins: [
    {
      name: 'public-workspace-exports-to-current-source',
      setup(build) {
        build.onResolve({ filter: /^@proto\.ui\// }, (args) => ({
          path: resolveWorkspace(args.path),
        }));
        build.onResolve({ filter: /^probe:/ }, (args) => {
          const dependencies = {
            'probe:react': ['packages/adapters/react/package.json', 'react'],
            'probe:react-dom-client': ['packages/adapters/react/package.json', 'react-dom/client'],
            'probe:react-dom': ['packages/adapters/react/package.json', 'react-dom'],
            'probe:vue': ['apps/www/package.json', 'vue'],
            'probe:vue2': ['packages/adapters/vue2/package.json', 'vue/dist/vue.runtime.esm.js'],
          };
          const [manifest, name] = dependencies[args.path] ?? [];
          if (!manifest) throw new Error(`Unknown fixture dependency: ${args.path}`);
          return { path: createRequire(path.join(sourceRoot, manifest)).resolve(name) };
        });
      },
    },
  ],
});
await fsp.writeFile(
  path.join(outputDir, 'esbuild-metafile.json'),
  JSON.stringify(built.metafile, null, 2)
);
const inputs = Object.keys(built.metafile.inputs).map((input) => {
  const absolute = path.resolve(sourceRoot, input);
  const rel = path.relative(sourceRoot, absolute);
  return {
    path: rel,
    sha256: sha256(fs.readFileSync(absolute)),
    gitBlob:
      !rel.startsWith('..') && !rel.includes('node_modules/') ? git('hash-object', absolute) : null,
  };
});
const chromePath =
  process.env.CHROME_PATH ?? '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const provenance = {
  startedAt: new Date().toISOString(),
  sourceRoot,
  outputDir,
  adapter,
  gitHead: git('rev-parse', 'HEAD'),
  gitStatus: git('status', '--short'),
  node: process.version,
  zlib: process.versions.zlib,
  platform: process.platform,
  arch: process.arch,
  esbuild: esbuild.version,
  playwright: requireWWW('playwright-core/package.json').version,
  chromeExecutable: chromePath,
  importBoundary:
    'Declared public package export names resolved to SOURCE_ROOT TypeScript source; bundled actual implementations, not built-dist or installed-tarball evidence.',
  sourceInputs: inputs,
  harness: ['part-probe.mjs', 'part-fixture.ts'].map((name) => ({
    name,
    sha256: sha256(fs.readFileSync(path.join(here, name))),
  })),
};
await fsp.writeFile(path.join(outputDir, 'provenance.json'), JSON.stringify(provenance, null, 2));

const html = `<!doctype html><html lang="en"><meta charset="utf-8"><title>Same-domain record detail relationship</title><style>
body{font:16px/1.5 system-ui;margin:0;background:#f1f5f9;color:#172536;padding:42px}main{max-width:1000px;margin:auto}h1{font-size:27px}#domains{display:grid;grid-template-columns:1fr 1fr;gap:22px}probe-record-root{background:#fff;border:1px solid #cbd5e1;border-radius:12px;padding:24px;min-height:155px}probe-record-action{display:block;background:#143b56;color:white;border-radius:7px;padding:12px;margin-bottom:16px}probe-record-detail{padding:14px;background:#eef4f8;border-left:3px solid #50809e;margin-bottom:16px}#actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:28px}button{font:inherit;font-size:13px;border:1px solid #9eafbf;border-radius:5px;padding:8px 12px;background:white}p{color:#526374}</style>
<main><h1>Record detail · independent Anatomy domains</h1><p>Generic authored WC prototypes using the same A11y part service as Tabs. Both endpoint orders are mounted.</p><div id="domains"></div><div id="actions"></div></main><script type="module" src="/fixture.js"></script></html>`;
await fsp.writeFile(path.join(outputDir, 'index.html'), html);
const server = createServer((req, res) => {
  const file = req.url?.split('?')[0] === '/fixture.js' ? 'fixture.js' : 'index.html';
  res.setHeader('Content-Type', file.endsWith('.js') ? 'text/javascript' : 'text/html');
  fs.createReadStream(path.join(outputDir, file)).pipe(res);
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const browser = await chromium.launch({ executablePath: chromePath, headless: true });
provenance.chrome = browser.version();
const page = await browser.newPage({ viewport: { width: 1180, height: 800 } });
const cdp = await page.context().newCDPSession(page);
const errors = [],
  warnings = [],
  observations = [],
  assertions = [];
page.on('pageerror', (e) => errors.push(String(e)));
page.on('console', (m) => {
  if (['warning', 'error'].includes(m.type())) warnings.push({ type: m.type(), text: m.text() });
});
const assertionAuthorities = {
  'first-domain-pair': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-C', 'C-A11Y-PART-RELATIONSHIP-0001-E'],
  },
  'opposite-order-second-domain-pair': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-C', 'C-A11Y-PART-RELATIONSHIP-0001-E'],
  },
  'distinct-domains-distinct-identities': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-C', 'C-A11Y-PART-RELATIONSHIP-0001-J'],
  },
  'sourceA-portable-key': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-B'],
  },
  'targetA-portable-key': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-B'],
  },
  'sourceB-portable-key': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-B'],
  },
  'targetB-portable-key': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-B'],
  },
  'target-L1-withdraws': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-D'],
  },
  'target-L1-retains-identity': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-D', 'C-A11Y-PART-RELATIONSHIP-0001-E'],
  },
  'source-L1-withdraws': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-D'],
  },
  'source-L1-retains-identity': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-D', 'C-A11Y-PART-RELATIONSHIP-0001-E'],
  },
  'one-sided-rekey-closes-both': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-C', 'C-A11Y-PART-RELATIONSHIP-0001-G'],
  },
  'matching-rekey-recovers': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-C', 'C-A11Y-PART-RELATIONSHIP-0001-G'],
  },
  'domain-move-invalidates-old-domain': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-C', 'C-A11Y-PART-RELATIONSHIP-0001-G'],
  },
  'matching-domain-move-recovers': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-C', 'C-A11Y-PART-RELATIONSHIP-0001-G'],
  },
  'other-pair-unchanged': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-C'],
  },
  'live-authored-ID-rebind': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-J'],
  },
  'live-ID-collision-closes': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-J'],
  },
  'removed-collision-recovers': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-J'],
  },
  'terminal-withdraws-preserves-author-ID': {
    kind: 'contract-criteria',
    anchors: ['C-A11Y-PART-RELATIONSHIP-0001-F', 'C-A11Y-PART-RELATIONSHIP-0001-J'],
  },
  'page-errors': {
    kind: 'fixture-execution-control',
    anchors: [],
    statement:
      'This fixture recorded no uncaught page errors for its listed authored inputs; it asserts no general Proto UI exception policy.',
  },
  'console-warning-errors': {
    kind: 'fixture-execution-control',
    anchors: [],
    statement:
      'This fixture recorded no console warnings or errors for its listed authored inputs; it does not require every Proto UI operation to remain silent or succeed.',
  },
};
const check = (id, pass, actual) =>
  assertions.push({ id, pass: Boolean(pass), actual, authority: assertionAuthorities[id] });
const capture = async (name) => {
  const state = await page.evaluate(() => window.partProbe.nextFrame());
  observations.push({ name, state });
  await page.screenshot({ path: path.join(outputDir, `${name}.png`) });
  await fsp.writeFile(
    path.join(outputDir, `${name}-ax.json`),
    JSON.stringify(await cdp.send('Accessibility.getFullAXTree'), null, 2)
  );
  return state;
};
const click = async (name) => {
  await page.locator(`#${name}`).click();
  return capture(name);
};
try {
  await page.goto(`http://127.0.0.1:${server.address().port}`, { waitUntil: 'load' });
  await page.waitForFunction(() => window.partProbe?.snapshot().targetA.id);
  const initial = await capture('initial');
  check(
    'first-domain-pair',
    initial.sourceA.controls === initial.targetA.id &&
      initial.targetA.labelledBy === initial.sourceA.id,
    initial
  );
  check(
    'opposite-order-second-domain-pair',
    initial.sourceB.controls === initial.targetB.id &&
      initial.targetB.labelledBy === initial.sourceB.id,
    initial
  );
  check(
    'distinct-domains-distinct-identities',
    initial.targetA.id !== initial.targetB.id && initial.sourceA.id !== initial.sourceB.id,
    initial
  );
  for (const n of ['sourceA', 'targetA', 'sourceB', 'targetB'])
    check(`${n}-portable-key`, initial[n].protocolKey === 'record+one', initial[n]);
  let state = await click('hide-target');
  check('target-L1-withdraws', state.sourceA.controls === null && state.targetA.detached, state);
  state = await click('show-target');
  check(
    'target-L1-retains-identity',
    state.targetA.id === initial.targetA.id && state.sourceA.controls === state.targetA.id,
    state
  );
  state = await click('hide-source');
  check('source-L1-withdraws', state.targetA.labelledBy === null && state.sourceA.detached, state);
  state = await click('show-source');
  check(
    'source-L1-retains-identity',
    state.sourceA.id === initial.sourceA.id && state.targetA.labelledBy === state.sourceA.id,
    state
  );
  state = await click('rekey-target');
  check(
    'one-sided-rekey-closes-both',
    state.sourceA.controls === null && state.targetA.labelledBy === null,
    state
  );
  state = await click('rekey-source');
  check(
    'matching-rekey-recovers',
    state.sourceA.controls === state.targetA.id && state.targetA.labelledBy === state.sourceA.id,
    state
  );
  state = await click('move-target');
  check(
    'domain-move-invalidates-old-domain',
    state.sourceA.controls === null && state.targetA.labelledBy === null,
    state
  );
  state = await click('move-source');
  check(
    'matching-domain-move-recovers',
    state.sourceA.controls === state.targetA.id && state.targetA.labelledBy === state.sourceA.id,
    state
  );
  check(
    'other-pair-unchanged',
    state.sourceB.controls === initial.targetB.id &&
      state.targetB.labelledBy === initial.sourceB.id,
    state
  );
  state = await click('host-id');
  check(
    'live-authored-ID-rebind',
    state.targetA.id === 'author-detail' && state.sourceA.controls === 'author-detail',
    state
  );
  state = await click('add-collision');
  check(
    'live-ID-collision-closes',
    state.targetA.id === 'author-detail' && state.sourceA.controls === null,
    state
  );
  state = await click('remove-collision');
  check('removed-collision-recovers', state.sourceA.controls === 'author-detail', state);
  state = await click('dispose-target');
  check(
    'terminal-withdraws-preserves-author-ID',
    !state.targetA.connected &&
      state.targetA.id === 'author-detail' &&
      state.sourceA.controls === null,
    state
  );
  const trace = await page.evaluate(() => window.partProbe.trace());
  await fsp.writeFile(path.join(outputDir, 'trace.json'), JSON.stringify(trace, null, 2));
  await page.evaluate(() => window.partProbe.stop());
  check('page-errors', errors.length === 0, errors);
  check('console-warning-errors', warnings.length === 0, warnings);
  await fsp.writeFile(
    path.join(outputDir, 'results.json'),
    JSON.stringify(
      {
        observations,
        assertions,
        errors,
        warnings,
        nativeClicks: trace.filter((x) => x.source.startsWith('native:')),
        scope: 'Actual generic WC consumer; no other shipped family or other browser is claimed.',
      },
      null,
      2
    )
  );
  console.log(
    JSON.stringify({
      passed: assertions.filter((x) => x.pass).length,
      failed: assertions.filter((x) => !x.pass),
    })
  );
  if (assertions.some((x) => !x.pass)) process.exitCode = 1;
} finally {
  provenance.finishedAt = new Date().toISOString();
  await fsp.writeFile(path.join(outputDir, 'provenance.json'), JSON.stringify(provenance, null, 2));
  await browser.close();
  await new Promise((r) => server.close(r));
}
