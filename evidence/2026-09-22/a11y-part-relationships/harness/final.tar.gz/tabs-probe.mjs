import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createServer } from 'node:http';
import { createHash } from 'node:crypto';

const sourceRoot = process.env.SOURCE_ROOT && path.resolve(process.env.SOURCE_ROOT);
const outputDir = process.env.OUTPUT_DIR && path.resolve(process.env.OUTPUT_DIR);
if (!sourceRoot || !outputDir) throw new Error('SOURCE_ROOT and OUTPUT_DIR are required.');
if (sourceRoot === outputDir || outputDir.startsWith(`${sourceRoot}${path.sep}`)) {
  throw new Error('OUTPUT_DIR must be outside SOURCE_ROOT.');
}
const here = path.dirname(fileURLToPath(import.meta.url));
const requireSource = createRequire(path.join(sourceRoot, 'package.json'));
const requireWWW = createRequire(path.join(sourceRoot, 'apps/www/package.json'));
const esbuild = requireSource('esbuild');
const { chromium } = requireWWW('playwright-core');
const adapter = process.env.ADAPTER ?? 'wc';
if (!['wc', 'react', 'vue', 'vue2'].includes(adapter))
  throw new Error(`Unknown ADAPTER: ${adapter}`);
const scenarios = (process.env.CASES ?? 'retained_control,lazy,collision,missing,duplicate').split(
  ','
);
const sha256 = (data) => createHash('sha256').update(data).digest('hex');
await fsp.mkdir(outputDir, { recursive: true });
const git = (...args) =>
  execFileSync('git', ['-C', sourceRoot, ...args], { encoding: 'utf8' }).trim();

function resolveWorkspace(id) {
  if (!id.startsWith('@proto.ui/')) return null;
  const [pkg, ...rest] = id.slice('@proto.ui/'.length).split('/');
  const scope = pkg.startsWith('module-')
    ? `modules/${pkg.slice(7)}`
    : pkg.startsWith('adapter-')
      ? `adapters/${pkg.slice(8)}`
      : pkg.startsWith('prototypes-')
        ? `prototypes/${pkg.slice(11)}`
        : pkg.startsWith('spec-')
          ? `spec/${pkg.slice(5)}`
          : pkg;
  const packageDir = path.join(sourceRoot, 'packages', scope);
  const manifest = JSON.parse(fs.readFileSync(path.join(packageDir, 'package.json'), 'utf8'));
  const exportKey = rest.length ? `./${rest.join('/')}` : '.';
  let entry = manifest.exports?.[exportKey];
  let wildcard = '';
  if (!entry) {
    for (const [key, value] of Object.entries(manifest.exports ?? {})) {
      if (!key.includes('*')) continue;
      const [prefix, suffix] = key.split('*');
      if (exportKey.startsWith(prefix) && exportKey.endsWith(suffix)) {
        entry = value;
        wildcard = exportKey.slice(prefix.length, suffix ? -suffix.length : undefined);
        break;
      }
    }
  }
  if (!entry) throw new Error(`Undeclared workspace import: ${id}`);
  const target = typeof entry === 'string' ? entry : (entry.import ?? entry.default ?? entry.types);
  const source = target
    .replace('*', wildcard)
    .replace('./dist/', './src/')
    .replace(/\.d\.ts$/, '.ts')
    .replace(/\.js$/, '.ts');
  const resolved = path.resolve(packageDir, source);
  if (!fs.existsSync(resolved))
    throw new Error(`Source export does not exist: ${id} -> ${resolved}`);
  return resolved;
}

const built = await esbuild.build({
  entryPoints: [
    path.join(here, adapter === 'wc' ? 'tabs-fixture.ts' : 'framework-tabs-fixture.ts'),
  ],
  outfile: path.join(outputDir, 'fixture.js'),
  absWorkingDir: sourceRoot,
  bundle: true,
  format: 'esm',
  platform: 'browser',
  target: 'es2020',
  sourcemap: true,
  metafile: true,
  define: {
    __PROBE_ADAPTER__: JSON.stringify(adapter),
    'process.env.NODE_ENV': '"development"',
    __VUE_OPTIONS_API__: 'true',
    __VUE_PROD_DEVTOOLS__: 'false',
    __VUE_PROD_HYDRATION_MISMATCH_DETAILS__: 'false',
  },
  nodePaths: [
    path.join(sourceRoot, 'node_modules'),
    path.join(sourceRoot, 'apps/www/node_modules'),
  ],
  plugins: [
    {
      name: 'public-workspace-exports-to-current-source',
      setup(build) {
        build.onResolve({ filter: /^@proto\.ui\// }, (args) => ({
          path: resolveWorkspace(args.path),
        }));
        build.onResolve({ filter: /^probe:/ }, (args) => {
          const dependencies = {
            'probe:react': ['packages/adapters/react/package.json', 'react'],
            'probe:react-dom-client': ['packages/adapters/react/package.json', 'react-dom/client'],
            'probe:react-dom': ['packages/adapters/react/package.json', 'react-dom'],
            'probe:vue': ['apps/www/package.json', 'vue'],
            'probe:vue2': ['packages/adapters/vue2/package.json', 'vue/dist/vue.runtime.esm.js'],
          };
          const [manifest, name] = dependencies[args.path] ?? [];
          if (!manifest) throw new Error(`Unknown fixture dependency: ${args.path}`);
          return { path: createRequire(path.join(sourceRoot, manifest)).resolve(name) };
        });
      },
    },
  ],
});
await fsp.writeFile(
  path.join(outputDir, 'esbuild-metafile.json'),
  JSON.stringify(built.metafile, null, 2)
);
const inputs = Object.keys(built.metafile.inputs).map((input) => {
  const absolute = path.resolve(sourceRoot, input);
  const rel = path.relative(sourceRoot, absolute);
  return {
    path: rel,
    sha256: sha256(fs.readFileSync(absolute)),
    gitBlob:
      !rel.startsWith('..') && !rel.includes('node_modules/') ? git('hash-object', absolute) : null,
  };
});
const chromePath =
  process.env.CHROME_PATH ?? '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const provenance = {
  startedAt: new Date().toISOString(),
  sourceRoot,
  outputDir,
  adapter,
  gitHead: git('rev-parse', 'HEAD'),
  gitStatus: git('status', '--short'),
  node: process.version,
  zlib: process.versions.zlib,
  platform: process.platform,
  arch: process.arch,
  esbuild: esbuild.version,
  playwright: requireWWW('playwright-core/package.json').version,
  chromeExecutable: chromePath,
  importBoundary:
    'Declared public package export names resolved to SOURCE_ROOT TypeScript source; bundled actual implementations, not built-dist or installed-tarball evidence.',
  sourceInputs: inputs,
  harness: [
    'tabs-probe.mjs',
    adapter === 'wc' ? 'tabs-fixture.ts' : 'framework-tabs-fixture.ts',
  ].map((name) => ({ name, sha256: sha256(fs.readFileSync(path.join(here, name))) })),
};
await fsp.writeFile(path.join(outputDir, 'provenance.json'), JSON.stringify(provenance, null, 2));

const html = `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Actual Base Tabs probe</title>
<style>html{color:#172026;background:#f4f6f8;font:16px/1.5 system-ui,sans-serif}body{margin:0;padding:56px}main{max-width:790px;margin:auto}.eyebrow{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#53606a}h1{font-size:26px;font-weight:650;margin:8px 0 28px}.tabs-root{border:1px solid #ccd4dc;background:white;border-radius:12px;padding:24px}.tabs-list{display:flex;gap:8px;border-bottom:1px solid #dde2e7;padding-bottom:12px}.tabs-trigger{display:inline-block;padding:10px 18px;border:1px solid #bdc8d1;border-radius:7px;cursor:pointer;user-select:none}.tabs-trigger[aria-selected="true"]{background:#142b43;color:white;border-color:#142b43}.tabs-trigger:focus-visible{outline:3px solid #2b78cc;outline-offset:3px}.tabs-content{padding:22px 4px}.tabs-content h2{font-size:21px;margin:0 0 10px}.tabs-content p{margin:0;color:#52606d}.caption{font-size:13px;color:#63717e;margin-top:24px}</style>
<main><div class="eyebrow">Proto UI · Base Tabs · ${adapter === 'wc' ? 'Web Component' : adapter}</div><h1 id="case-title"></h1><div id="fixture"></div><p class="caption">Actual Root, List, Trigger and Content implementations. App-owned layout only.</p></main><script type="module" src="/fixture.js"></script></html>`;
await fsp.writeFile(path.join(outputDir, 'index.html'), html);
const server = createServer((req, res) => {
  const file =
    req.url?.split('?')[0] === '/fixture.js'
      ? 'fixture.js'
      : req.url?.split('?')[0] === '/fixture.js.map'
        ? 'fixture.js.map'
        : 'index.html';
  res.setHeader(
    'Content-Type',
    file.endsWith('.js')
      ? 'text/javascript'
      : file.endsWith('.map')
        ? 'application/json'
        : 'text/html'
  );
  fs.createReadStream(path.join(outputDir, file)).pipe(res);
});
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
const address = server.address();
const baseUrl = `http://127.0.0.1:${address.port}`;
const browser = await chromium.launch({ executablePath: chromePath, headless: true });
provenance.chrome = browser.version();
const results = [];

function evaluate(scenario, states) {
  const assertions = [];
  const add = (id, expected, actual, pass, authority) =>
    assertions.push({ id, expected, actual, pass, authority });
  const C = 'C-A11Y-PART-RELATIONSHIP-0001';
  const initial = states.initial;
  const a = initial.parts['trigger-0'];
  const content = initial.parts['content-0'];
  add(
    'normal-interaction-starts-at-first-key',
    a.key,
    initial.root.value,
    initial.root.value === a.key,
    'P-BASE-TABS-PROP-DEFAULT-VALUE'
  );
  if (scenario === 'retained_control' || scenario === 'lazy') {
    add(
      'normal-reciprocal-pair',
      { controls: content.id, labelledBy: a.id },
      { controls: a.controls, labelledBy: content.labelledBy },
      Boolean(content.id && a.id && a.controls === content.id && content.labelledBy === a.id),
      'P-BASE-TABS-A11Y-RELATIONSHIP-TARGET'
    );
  }
  if (states.afterB) {
    add(
      'native-click-selects-second-key',
      initial.parts['trigger-1'].key,
      states.afterB.root.value,
      states.afterB.root.value === initial.parts['trigger-1'].key,
      'P-BASE-TABS-TRIGGER-ACTIVATION-REQUESTS-SELECTION'
    );
  }
  if (states.afterA)
    add(
      'native-click-returns-first-key',
      a.key,
      states.afterA.root.value,
      states.afterA.root.value === a.key,
      'P-BASE-TABS-UNCONTROLLED-UPDATES-VALUE'
    );
  if (scenario === 'lazy') {
    const detached = states.afterB.parts['content-0'];
    add(
      'lazy-A-view-is-detached',
      true,
      detached.detached,
      detached.detached && (!detached.connected || detached.display === 'none'),
      'P-BASE-TABS-DEFAULT-L1-DETACH'
    );
    add(
      'detached-source-controls-withdrawn',
      null,
      states.afterB.parts['trigger-0'].controls,
      !states.afterB.parts['trigger-0'].controls,
      `${C}-D`
    );
    const restored = states.afterA.parts['content-0'];
    add(
      'rematerialized-target-same-identity',
      content.id,
      restored.id,
      Boolean(content.id && restored.id === content.id),
      `${C}-E`
    );
    add(
      'rematerialized-reciprocal-pair',
      { controls: restored.id, labelledBy: states.afterA.parts['trigger-0'].id },
      { controls: states.afterA.parts['trigger-0'].controls, labelledBy: restored.labelledBy },
      Boolean(
        restored.id &&
        states.afterA.parts['trigger-0'].controls === restored.id &&
        restored.labelledBy === states.afterA.parts['trigger-0'].id
      ),
      `${C}-E`
    );
  }
  if (scenario === 'collision') {
    const first = initial.parts['content-0'],
      second = initial.parts['content-1'];
    add(
      'distinct-exact-keys-have-unique-target-identity',
      'different non-empty IDs',
      [first.id, second.id],
      Boolean(first.id && second.id && first.id !== second.id),
      `${C}-B,${C}-C`
    );
    add(
      'exact-first-key-controls-one-correct-target',
      ['content-0'],
      a.matchedControls.flatMap((x) => x.matches.map((y) => y.part)),
      a.matchedControls.length === 1 &&
        a.matchedControls[0].matches.length === 1 &&
        a.matchedControls[0].matches[0].part === 'content-0',
      `${C}-C`
    );
  }
  if (scenario === 'missing') {
    const missing = states.afterB.parts['trigger-1'];
    add('missing-counterpart-fails-closed', null, missing.controls, !missing.controls, `${C}-C`);
  }
  if (scenario === 'duplicate')
    add('duplicate-counterpart-fails-closed', null, a.controls, !a.controls, `${C}-C`);
  return assertions;
}

try {
  for (const scenario of scenarios) {
    const context = await browser.newContext({
      viewport: { width: 1050, height: 660 },
      deviceScaleFactor: 1,
    });
    const page = await context.newPage();
    const cdp = await context.newCDPSession(page);
    const errors = [],
      consoleMessages = [];
    page.on('pageerror', (e) => errors.push(String(e)));
    page.on('console', (m) => {
      if (m.type() === 'warning' || m.type() === 'error')
        consoleMessages.push({ type: m.type(), text: m.text() });
    });
    const states = {};
    const files = [];
    await page.goto(`${baseUrl}/?case=${scenario}`, { waitUntil: 'load' });
    await page.waitForFunction(
      () =>
        window.tabsProbe?.snapshot().parts['trigger-0']?.role === 'tab' &&
        window.tabsProbe.snapshot().root.value !== undefined
    );
    states.initial = await page.evaluate(() => window.tabsProbe.nextFrame());
    await fsp.writeFile(
      path.join(outputDir, `${scenario}-initial-ax.json`),
      JSON.stringify(await cdp.send('Accessibility.getFullAXTree'), null, 2)
    );
    await page.screenshot({ path: path.join(outputDir, `${scenario}-initial.png`) });
    files.push(`${scenario}-initial.png`);
    if (scenario !== 'duplicate') {
      await page.evaluate(() => window.tabsProbe.mark('before-native-click-B'));
      await page.locator('[data-fixture-part="trigger-1"], [data-demo-ref="trigger-1"]').click();
      await page.waitForFunction(() => {
        const s = window.tabsProbe.snapshot();
        return s.root.value === s.parts['trigger-1'].key;
      });
      states.afterB = await page.evaluate(() => window.tabsProbe.nextFrame());
      await fsp.writeFile(
        path.join(outputDir, `${scenario}-after-B-ax.json`),
        JSON.stringify(await cdp.send('Accessibility.getFullAXTree'), null, 2)
      );
      await page.screenshot({ path: path.join(outputDir, `${scenario}-after-B.png`) });
      files.push(`${scenario}-after-B.png`);
    }
    if (scenario === 'lazy' || scenario === 'retained_control') {
      await page.evaluate(() => window.tabsProbe.mark('before-native-click-A'));
      await page.locator('[data-fixture-part="trigger-0"], [data-demo-ref="trigger-0"]').click();
      await page.waitForFunction(() => {
        const s = window.tabsProbe.snapshot();
        return s.root.value === s.parts['trigger-0'].key;
      });
      states.afterA = await page.evaluate(() => window.tabsProbe.nextFrame());
      await fsp.writeFile(
        path.join(outputDir, `${scenario}-after-A-ax.json`),
        JSON.stringify(await cdp.send('Accessibility.getFullAXTree'), null, 2)
      );
      await page.screenshot({ path: path.join(outputDir, `${scenario}-after-A.png`) });
      files.push(`${scenario}-after-A.png`);
    }
    await page.evaluate(() => window.tabsProbe.stop());
    const trace = await page.evaluate(() => window.tabsProbe.trace());
    const configuration = await page.evaluate(() => window.tabsProbe.configuration);
    const assertions = evaluate(scenario, states);
    const nativeClicks = trace.entries.filter((x) => x.source === 'native-event:click:capture');
    const result = {
      scenario,
      configuration,
      states,
      assertions,
      errors,
      consoleMessages,
      screenshots: files,
      traceCount: trace.entries.length,
      traceLimitReached: trace.limitReached,
      nativeClicks: nativeClicks.map((x) => ({ seq: x.seq, ...x.detail })),
    };
    await fsp.writeFile(
      path.join(outputDir, `${scenario}-trace.json`),
      JSON.stringify(trace, null, 2)
    );
    await fsp.writeFile(
      path.join(outputDir, `${scenario}-result.json`),
      JSON.stringify(result, null, 2)
    );
    results.push(result);
    console.log(
      JSON.stringify({
        scenario,
        pass: assertions.filter((x) => x.pass).length,
        fail: assertions.filter((x) => !x.pass).map((x) => x.id),
        errors,
        nativeClicks: result.nativeClicks,
        traceCount: result.traceCount,
      })
    );
    await context.close();
  }
} finally {
  provenance.completedAt = new Date().toISOString();
  await fsp.writeFile(path.join(outputDir, 'provenance.json'), JSON.stringify(provenance, null, 2));
  await fsp.writeFile(path.join(outputDir, 'results.json'), JSON.stringify(results, null, 2));
  await browser.close();
  await new Promise((resolve) => server.close(resolve));
}
process.exitCode = results.some((r) => r.errors.length || r.assertions.some((a) => !a.pass))
  ? 1
  : 0;
