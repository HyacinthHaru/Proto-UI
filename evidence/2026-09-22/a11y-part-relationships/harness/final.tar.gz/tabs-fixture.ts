import { AdaptToWebComponent, setElementProps } from '@proto.ui/adapter-web-component';
import { tabsRoot, tabsList, tabsTrigger, tabsContent } from '@proto.ui/prototypes-base/tabs';

type FixtureCase = {
  title: string;
  keys: string[];
  contents: Array<{ key: string; label: string }>;
  retained: boolean;
};

const cases: Record<string, FixtureCase> = {
  retained_control: {
    title: 'Retained panels · normal control',
    keys: ['a', 'b'],
    contents: [
      { key: 'a', label: 'Account' },
      { key: 'b', label: 'Security' },
    ],
    retained: true,
  },
  lazy: {
    title: 'Default lazy panels · A → B → A',
    keys: ['a', 'b'],
    contents: [
      { key: 'a', label: 'Account' },
      { key: 'b', label: 'Security' },
    ],
    retained: false,
  },
  collision: {
    title: 'Distinct exact keys · a+b and a b',
    keys: ['a+b', 'a b'],
    contents: [
      { key: 'a+b', label: 'Plus key' },
      { key: 'a b', label: 'Space key' },
    ],
    retained: true,
  },
  missing: {
    title: 'Missing Content counterpart',
    keys: ['a', 'b'],
    contents: [{ key: 'a', label: 'Account' }],
    retained: true,
  },
  duplicate: {
    title: 'Two Content parts with the same key',
    keys: ['a', 'b'],
    contents: [
      { key: 'a', label: 'Account · first authored Content' },
      { key: 'a', label: 'Account · second authored Content' },
      { key: 'b', label: 'Security' },
    ],
    retained: true,
  },
};

const scenario = new URL(location.href).searchParams.get('case') ?? 'lazy';
const config = cases[scenario];
if (!config) throw new Error(`Unknown fixture case: ${scenario}`);

const mountPoint = document.querySelector<HTMLElement>('#fixture')!;
const title = document.querySelector<HTMLElement>('#case-title')!;
title.textContent = config.title;

const parts = new Map<string, HTMLElement & { getExposes?: () => any }>();
const trace: any[] = [];
let active = true;
let limitReached = false;
let seq = 0;

function readExposes(el: HTMLElement & { getExposes?: () => any }) {
  if (!el.getExposes) return {};
  try {
    const e = el.getExposes();
    return Object.fromEntries(
      ['value', 'selected', 'current', 'hidden'].flatMap((name) =>
        e?.[name] && typeof e[name].get === 'function' ? [[name, e[name].get()]] : []
      )
    );
  } catch (error) {
    return { unavailable: String(error) };
  }
}

function snapshot() {
  const ids = [...document.querySelectorAll<HTMLElement>('[id]')];
  return {
    scenario,
    root: parts.has('root') ? readExposes(parts.get('root')!) : {},
    parts: Object.fromEntries(
      [...parts].map(([name, el]) => {
        const controls = el.getAttribute('aria-controls');
        const labelledBy = el.getAttribute('aria-labelledby');
        const style = getComputedStyle(el);
        const matchedControls = controls
          ? controls
              .split(/\s+/)
              .filter(Boolean)
              .map((token) => ({
                token,
                matches: ids
                  .filter((target) => target.id === token)
                  .map((target) => ({
                    part: target.dataset.fixturePart ?? null,
                    tag: target.localName,
                    detached: target.hasAttribute('data-pui-view-detached'),
                    display: getComputedStyle(target).display,
                    visibility: getComputedStyle(target).visibility,
                  })),
              }))
          : [];
        return [
          name,
          {
            key: el.dataset.fixtureKey ?? null,
            tag: el.localName,
            connected: el.isConnected,
            id: el.getAttribute('id'),
            role: el.getAttribute('role'),
            controls,
            labelledBy,
            ariaSelected: el.getAttribute('aria-selected'),
            ariaHidden: el.getAttribute('aria-hidden'),
            detached: el.hasAttribute('data-pui-view-detached'),
            pending: el.hasAttribute('data-pui-view-pending'),
            hiddenAttribute: el.hasAttribute('hidden'),
            display: style.display,
            visibility: style.visibility,
            rectCount: el.getClientRects().length,
            tabIndex: el.tabIndex,
            exposes: readExposes(el),
            matchedControls,
          },
        ];
      })
    ),
  };
}

function record(source: string, detail: unknown = null) {
  if (!active) return;
  if (trace.length >= 20_000) {
    limitReached = true;
    return;
  }
  trace.push({ seq: ++seq, time: performance.now(), source, detail, facts: snapshot() });
}

const observer = new MutationObserver((records) => {
  record(
    'mutation-observer',
    records.map((mutation) => ({
      type: mutation.type,
      target:
        mutation.target instanceof HTMLElement
          ? (mutation.target.dataset.fixturePart ?? mutation.target.localName)
          : mutation.target.nodeName,
      attribute: mutation.attributeName,
      oldValue: mutation.oldValue,
      newValue:
        mutation.type === 'attributes'
          ? (mutation.target as HTMLElement).getAttribute(mutation.attributeName!)
          : undefined,
      added: mutation.addedNodes.length,
      removed: mutation.removedNodes.length,
    }))
  );
});
observer.observe(mountPoint, {
  subtree: true,
  attributes: true,
  attributeOldValue: true,
  childList: true,
});

for (const type of ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'focusin', 'click']) {
  mountPoint.addEventListener(
    type,
    (event) =>
      record(`native-event:${type}:capture`, {
        isTrusted: event.isTrusted,
        target:
          (event.target as HTMLElement).dataset.fixturePart ??
          (event.target as HTMLElement).localName,
      }),
    true
  );
  mountPoint.addEventListener(type, (event) => {
    record(`native-event:${type}:bubble`, { isTrusted: event.isTrusted });
    queueMicrotask(() => record(`native-event:${type}:microtask`));
  });
}

function part(name: string, proto: any, props: Record<string, unknown> = {}) {
  const tagName = `probe-${scenario.replaceAll('_', '-')}-${name}`;
  AdaptToWebComponent(proto, {
    registerAs: tagName,
    diagnostics: {
      onLifecycleEvent: (event) => record(`runtime:${name}`, event),
    },
  });
  const el = document.createElement(tagName);
  el.dataset.fixturePart = name;
  if (typeof props.value === 'string') el.dataset.fixtureKey = props.value;
  setElementProps(el, props);
  parts.set(name, el);
  return el;
}

const root = part('root', tabsRoot, { defaultValue: config.keys[0] });
const list = part('list', tabsList, { a11yLabel: 'Account sections' });
root.className = 'tabs-root';
list.className = 'tabs-list';
for (const [index, key] of config.keys.entries()) {
  const trigger = part(`trigger-${index}`, tabsTrigger, { value: key });
  trigger.className = 'tabs-trigger';
  trigger.textContent =
    scenario === 'collision' ? `Key “${key}”` : index === 0 ? 'Account' : 'Security';
  list.appendChild(trigger);
}
root.appendChild(list);
for (const [index, content] of config.contents.entries()) {
  const panel = part(`content-${index}`, tabsContent, {
    value: content.key,
    ...(config.retained ? { keepMounted: true } : {}),
  });
  panel.className = 'tabs-content';
  const heading = document.createElement('h2');
  heading.textContent = content.label;
  const paragraph = document.createElement('p');
  paragraph.textContent =
    content.key === config.keys[0]
      ? 'Your account details are shown in this panel.'
      : 'Your security settings are shown in this panel.';
  panel.append(heading, paragraph);
  root.appendChild(panel);
}
root.addEventListener('valueChange', (event) =>
  record('public:valueChange', (event as CustomEvent).detail)
);

(window as any).tabsProbe = {
  snapshot,
  trace: () => ({ entries: trace, limitReached }),
  mark: (label: string) => record(`harness:${label}`),
  nextFrame: () =>
    new Promise((resolve) =>
      requestAnimationFrame(() => {
        record('animation-frame');
        resolve(snapshot());
      })
    ),
  stop: () => {
    record('harness:stop');
    observer.disconnect();
    active = false;
  },
  configuration: { adapter: 'wc', scenario, ...config },
};
record('harness:before-mount');
mountPoint.appendChild(root);
record('harness:after-mount');
