import { createAnatomyFamily, definePrototype } from '@proto.ui/core';
import { asAccessible } from '@proto.ui/hooks';
import { AdaptToWebComponent, setElementProps } from '@proto.ui/adapter-web-component';

const family = createAnatomyFamily('evidence-record-detail', {
  roles: {
    root: { cardinality: { min: 1, max: 1 } },
    action: { cardinality: { min: 0, max: '*' } },
    detail: { cardinality: { min: 0, max: '*' } },
  },
});
const records: any[] = [];
let sequence = 0;
const nodes = new Map<string, HTMLElement>();
const nodeIds = new WeakMap<Node, number>();
let nextNode = 0;
const nodeId = (node: Node) => { if (!nodeIds.has(node)) nodeIds.set(node, ++nextNode); return nodeIds.get(node); };
const snapshot = () => Object.fromEntries([...nodes].map(([name, el]) => [name, {
  id: el.getAttribute('id'), controls: el.getAttribute('aria-controls'), labelledBy: el.getAttribute('aria-labelledby'),
  connected: el.isConnected, detached: el.hasAttribute('data-pui-view-detached'),
  display: getComputedStyle(el).display, visibility: getComputedStyle(el).visibility,
  protocolKey: (el as any).getExposes?.().protocolKey?.get(),
}]));
const record = (source: string, detail?: unknown) => records.push({ seq: ++sequence, source, detail, snapshot: snapshot() });
const observer = new MutationObserver((batch) => {
  const mutations = batch.map((m, index) => {
    const later = batch.slice(index + 1).find(n => n.type === 'attributes' && n.target === m.target && n.attributeName === m.attributeName);
    return {
      node: nodeId(m.target), part: (m.target as HTMLElement).dataset?.part, type: m.type,
      attr: m.attributeName, oldValue: m.oldValue,
      newValue: m.type === 'attributes' ? later ? later.oldValue : (m.target as Element).getAttribute(m.attributeName!) : undefined,
      removed: [...m.removedNodes].map(nodeId), added: [...m.addedNodes].map(nodeId),
    };
  });
  record('mutation-delivery', mutations);
});
observer.observe(document.body, { subtree: true, childList: true, attributes: true, attributeOldValue: true });

for (const role of ['root', 'action', 'detail'] as const) {
  const proto = definePrototype<{ match?: string; present?: boolean }>({
    name: `record-${role}`,
    setup(def) {
      def.anatomy.claim(family, { role });
      if (role === 'root') return;
      def.props.define({ match: { type: 'string', empty: 'fallback' }, present: { type: 'boolean', empty: 'fallback' } });
      def.props.setDefaults({ match: 'record+one', present: true });
      const key = def.state.string('protocolKey', 'record+one');
      def.expose.state('protocolKey', key);
      const accessible = asAccessible();
      accessible.part(family, { key });
      accessible.role(role === 'action' ? 'button' : 'region');
      if (role === 'action') accessible.nameFromContent();
      accessible.relation(role === 'action' ? 'controls' : 'labelledBy', {
        target: { kind: 'part', family, role: role === 'action' ? 'detail' : 'action', key },
      });
      def.props.watch(['match', 'present'], (run, next) => {
        key.set(next.match ?? '');
        run.lifecycle.setPresent(next.present !== false);
      });
    },
  });
  AdaptToWebComponent(proto, { registerAs: `probe-record-${role}`, diagnostics: {
    onLifecycleEvent: (event) => record(`runtime:${role}`, event),
  } });
}
function part(name: string, role: string, text: string) {
  const el = document.createElement(`probe-record-${role}`);
  el.dataset.part = name; el.textContent = text; nodes.set(name, el); return el;
}
const rootA = part('rootA', 'root', ''), rootB = part('rootB', 'root', '');
const sourceA = part('sourceA', 'action', 'Record one · primary');
const targetA = part('targetA', 'detail', 'Primary record details');
const sourceB = part('sourceB', 'action', 'Record one · secondary');
const targetB = part('targetB', 'detail', 'Secondary record details');
rootA.append(sourceA, targetA);
// Reverse endpoint order in the second domain.
rootB.append(targetB, sourceB);
document.querySelector('#domains')!.append(rootA, rootB);
const matches = { sourceA: 'record+one', targetA: 'record+one' };
const props = (which: keyof typeof matches, present = true) => setElementProps(nodes.get(which)!, { match: matches[which], present });
const actions: Record<string, () => void> = {
  'hide-target': () => props('targetA', false), 'show-target': () => props('targetA'),
  'hide-source': () => props('sourceA', false), 'show-source': () => props('sourceA'),
  'rekey-target': () => { matches.targetA = 'record one'; props('targetA'); },
  'rekey-source': () => { matches.sourceA = 'record one'; props('sourceA'); },
  'move-target': () => rootB.append(targetA), 'move-source': () => rootB.append(sourceA),
  'host-id': () => { targetA.id = 'author-detail'; },
  'add-collision': () => { const dup = document.createElement('span'); dup.id = 'author-detail'; dup.dataset.collision = ''; rootB.append(dup); },
  'remove-collision': () => document.querySelector('[data-collision]')?.remove(),
  'dispose-target': () => targetA.remove(),
};
for (const [name, action] of Object.entries(actions)) {
  const button = document.createElement('button'); button.id = name; button.textContent = name.replaceAll('-', ' ');
  button.onclick = (event) => { record(`native:${name}`, { isTrusted: event.isTrusted }); action(); record(`after:${name}`); };
  document.querySelector('#actions')!.append(button);
}
(window as any).partProbe = { snapshot, trace: () => records, nextFrame: () => new Promise(resolve => requestAnimationFrame(() => resolve(snapshot()))), stop: () => observer.disconnect() };
