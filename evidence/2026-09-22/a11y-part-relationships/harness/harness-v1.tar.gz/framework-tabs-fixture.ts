import * as React from 'probe:react';
import { createRoot } from 'probe:react-dom-client';
import { createPortal } from 'probe:react-dom';
import * as Vue from 'probe:vue';
import Vue2 from 'probe:vue2';
import { createReactAdapter } from '@proto.ui/adapter-react';
import { createVueAdapter } from '@proto.ui/adapter-vue';
import { createVue2Adapter } from '@proto.ui/adapter-vue2';
import { tabsRoot, tabsList, tabsTrigger, tabsContent } from '@proto.ui/prototypes-base/tabs';

declare const __PROBE_ADAPTER__: 'react' | 'vue' | 'vue2';
const adapter = __PROBE_ADAPTER__;
const cases = {
  retained_control: { title: 'Retained panels · normal control', keys: ['a', 'b'], contents: [{ key: 'a', label: 'Account' }, { key: 'b', label: 'Security' }], retained: true },
  lazy: { title: 'Default lazy panels · A → B → A', keys: ['a', 'b'], contents: [{ key: 'a', label: 'Account' }, { key: 'b', label: 'Security' }], retained: false },
  collision: { title: 'Distinct exact keys · a+b and a b', keys: ['a+b', 'a b'], contents: [{ key: 'a+b', label: 'Plus key' }, { key: 'a b', label: 'Space key' }], retained: true },
  missing: { title: 'Missing Content counterpart', keys: ['a', 'b'], contents: [{ key: 'a', label: 'Account' }], retained: true },
  duplicate: { title: 'Two Content parts with the same key', keys: ['a', 'b'], contents: [{ key: 'a', label: 'Account · first authored Content' }, { key: 'a', label: 'Account · second authored Content' }, { key: 'b', label: 'Security' }], retained: true },
};
const scenario = new URL(location.href).searchParams.get('case') ?? 'lazy';
const config = cases[scenario];
if (!config) throw new Error(`Unknown fixture case: ${scenario}`);
const mountPoint = document.querySelector<HTMLElement>('#fixture')!;
document.querySelector<HTMLElement>('#case-title')!.textContent = config.title;
const handles = new Map<string, any>();
const metadata = new Map<string, { key?: string }>();
const phases = new Map<string, { phase: string; epoch?: number }>();
const trace: any[] = [];
let active = true, limitReached = false, seq = 0;

function readExposes(name: string) {
  try {
    const handle = handles.get(name);
    const e = handle?.getExposes?.();
    return Object.fromEntries(['value', 'selected', 'current', 'hidden'].flatMap((key) =>
      e?.[key] && typeof e[key].get === 'function' ? [[key, e[key].get()]] : []));
  } catch (error) { return { unavailable: String(error) }; }
}

function partName(el: Element) { return el.getAttribute('data-demo-ref'); }
function snapshot() {
  const ids = [...document.querySelectorAll<HTMLElement>('[id]')];
  return {
    adapter, scenario, root: readExposes('root'),
    parts: Object.fromEntries([...metadata].map(([name, data]) => {
      const el = mountPoint.querySelector<HTMLElement>(`[data-demo-ref="${name}"]`);
      const controls = el?.getAttribute('aria-controls') ?? null;
      const style = el ? getComputedStyle(el) : null;
      const phase = phases.get(name);
      return [name, {
        key: data.key ?? null, tag: el?.localName ?? null, connected: el?.isConnected ?? false,
        id: el?.getAttribute('id') ?? null, role: el?.getAttribute('role') ?? null,
        controls, labelledBy: el?.getAttribute('aria-labelledby') ?? null,
        ariaSelected: el?.getAttribute('aria-selected') ?? null,
        ariaHidden: el?.getAttribute('aria-hidden') ?? null,
        detached: phase?.phase === 'detached' || el?.hasAttribute('data-pui-view-detached') === true,
        runtimePhase: phase ?? null,
        pending: el?.hasAttribute('data-pui-view-pending') ?? false,
        hiddenAttribute: el?.hasAttribute('hidden') ?? false,
        display: style?.display ?? null, visibility: style?.visibility ?? null,
        rectCount: el?.getClientRects().length ?? 0, tabIndex: el?.tabIndex ?? null,
        exposes: readExposes(name),
        matchedControls: controls ? controls.split(/\s+/).filter(Boolean).map(token => ({
          token, matches: ids.filter(target => target.id === token).map(target => ({
            part: partName(target), tag: target.localName,
            detached: target.hasAttribute('data-pui-view-detached'),
            display: getComputedStyle(target).display, visibility: getComputedStyle(target).visibility,
          })),
        })) : [],
      }];
    })),
  };
}

function record(source: string, detail: unknown = null) {
  if (!active) return;
  if (trace.length >= 20_000) { limitReached = true; return; }
  trace.push({ seq: ++seq, time: performance.now(), source, detail, facts: snapshot() });
}
function diagnostics(name: string) {
  return { onLifecycleEvent(event: any) {
    if (event.type === 'mount.phase') phases.set(name, { phase: event.phase, epoch: event.epoch });
    record(`runtime:${name}`, event);
  } };
}

const observer = new MutationObserver(records => record('mutation-observer', records.map(mutation => ({
  type: mutation.type,
  target: mutation.target instanceof HTMLElement ? partName(mutation.target) ?? mutation.target.localName : mutation.target.nodeName,
  attribute: mutation.attributeName, oldValue: mutation.oldValue,
  newValue: mutation.type === 'attributes' ? (mutation.target as HTMLElement).getAttribute(mutation.attributeName!) : undefined,
  added: mutation.addedNodes.length, removed: mutation.removedNodes.length,
}))));
observer.observe(mountPoint, { subtree: true, attributes: true, attributeOldValue: true, childList: true });
for (const type of ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'focusin', 'click']) {
  mountPoint.addEventListener(type, (event) => record(`native-event:${type}:capture`, {
    isTrusted: event.isTrusted, target: partName(event.target as Element) ?? (event.target as HTMLElement).localName,
  }), true);
  mountPoint.addEventListener(type, (event) => {
    record(`native-event:${type}:bubble`, { isTrusted: event.isTrusted });
    queueMicrotask(() => record(`native-event:${type}:microtask`));
  });
}

type Node = { name: string; proto: any; props: Record<string, unknown>; className: string; children: Array<Node | { tag: string; text: string } | string> };
const node = (name: string, proto: any, props: Record<string, unknown>, className: string, children: Node['children']): Node => {
  metadata.set(name, { key: typeof props.value === 'string' ? props.value : undefined });
  return { name, proto, props, className, children };
};
const structure = node('root', tabsRoot, { defaultValue: config.keys[0] }, 'tabs-root', [
  node('list', tabsList, { a11yLabel: 'Account sections' }, 'tabs-list', config.keys.map((key, index) =>
    node(`trigger-${index}`, tabsTrigger, { value: key }, 'tabs-trigger', [scenario === 'collision' ? `Key “${key}”` : index === 0 ? 'Account' : 'Security']))),
  ...config.contents.map((content, index) => node(`content-${index}`, tabsContent, { value: content.key, ...(config.retained ? { keepMounted: true } : {}) }, 'tabs-content', [
    { tag: 'h2', text: content.label },
    { tag: 'p', text: content.key === config.keys[0] ? 'Your account details are shown in this panel.' : 'Your security settings are shown in this panel.' },
  ])),
]);

(window as any).tabsProbe = {
  snapshot,
  trace: () => ({ entries: trace, limitReached }),
  mark: (label: string) => record(`harness:${label}`),
  nextFrame: () => new Promise(resolve => requestAnimationFrame(() => { record('animation-frame'); resolve(snapshot()); })),
  stop: () => { record('harness:stop'); observer.disconnect(); active = false; },
  configuration: { adapter, scenario, ...config, frameworks: { react: React.version, vue: Vue.version, vue2: Vue2.version } },
};

record('harness:before-mount');
if (adapter === 'react') {
  const adapt = createReactAdapter({ ...React, createPortal } as any);
  const components = new Map();
  function render(n: Node | { tag: string; text: string } | string): any {
    if (typeof n === 'string') return n;
    if ('tag' in n) return React.createElement(n.tag, {}, n.text);
    let Component = components.get(n.name);
    if (!Component) { Component = adapt(n.proto, { diagnostics: diagnostics(n.name) }); components.set(n.name, Component); }
    return React.createElement(Component, { ...n.props, 'data-demo-ref': n.name, surfaceClassName: n.className,
      ref: (value: any) => { if (value) handles.set(n.name, value); else handles.delete(n.name); },
      ...(n.name === 'root' ? { onValueChange: (value: unknown) => record('public:valueChange', value) } : {}),
    }, ...n.children.map(render));
  }
  createRoot(mountPoint).render(render(structure));
} else if (adapter === 'vue') {
  const adapt = createVueAdapter(Vue as any);
  const components = new Map();
  function render(n: Node | { tag: string; text: string } | string): any {
    if (typeof n === 'string') return n;
    if ('tag' in n) return Vue.h(n.tag, {}, n.text);
    let Component = components.get(n.name);
    if (!Component) { Component = adapt(n.proto, { diagnostics: diagnostics(n.name) }); components.set(n.name, Component); }
    return Vue.h(Component, { ...n.props, 'data-demo-ref': n.name, surfaceClass: n.className,
      ref: (value: any) => { if (value) handles.set(n.name, value); else handles.delete(n.name); },
      ...(n.name === 'root' ? { onValueChange: (value: unknown) => record('public:valueChange', value) } : {}),
    }, () => n.children.map(render));
  }
  Vue.createApp({ setup: () => () => render(structure) }).mount(mountPoint);
} else {
  const adapt = createVue2Adapter({ extend: Vue2.extend.bind(Vue2), nextTick: Vue2.nextTick.bind(Vue2), set: Vue2.set.bind(Vue2), delete: Vue2.delete.bind(Vue2) });
  const components = new Map();
  const App = Vue2.extend({
    mounted() { for (const [name, handle] of Object.entries(this.$refs)) handles.set(name, handle); },
    updated() { for (const [name, handle] of Object.entries(this.$refs)) handles.set(name, handle); },
    render(h: any) {
      function render(n: Node | { tag: string; text: string } | string): any {
        if (typeof n === 'string') return n;
        if ('tag' in n) return h(n.tag, {}, n.text);
        let Component = components.get(n.name);
        if (!Component) { Component = adapt(n.proto, { diagnostics: diagnostics(n.name) }); components.set(n.name, Component); }
        return h(Component, { attrs: { ...n.props, 'data-demo-ref': n.name }, props: { surfaceClass: n.className }, ref: n.name,
          ...(n.name === 'root' ? { on: { valueChange: (value: unknown) => record('public:valueChange', value) } } : {}),
        }, n.children.map(render));
      }
      return render(structure);
    },
  });
  const vm = new App().$mount();
  mountPoint.appendChild(vm.$el);
}
record('harness:after-mount');
