import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { Window } from '<candidate-root>/node_modules/happy-dom/lib/index.js';
import { createAnatomyFamily, createA11ySemanticObjectRef } from '<candidate-root>/packages/core/dist/index.js';
import { createWebA11yProjectionRegistry, createWebA11yProjector } from '<candidate-root>/packages/modules/a11y/dist/index.js';

const results = [];
for (const explicit of [false, true]) for (const flushBeforeDetach of [false]) {
  const window = new Window();
  const document = window.document;
  globalThis.MutationObserver = window.MutationObserver;
  const source = document.createElement('button'), target = document.createElement('section');
  document.body.append(source, target);
  const sourceRef = createA11ySemanticObjectRef(), targetRef = createA11ySemanticObjectRef();
  const family = createAnatomyFamily('review-id-detach', { roles: { root: { cardinality: {min:1,max:1} }, source: {cardinality:{min:0,max:'*'}}, target: {cardinality:{min:0,max:'*'}} } });
  const registry = createWebA11yProjectionRegistry();
  const projector = createWebA11yProjector(target, undefined, registry);
  const dependent = createWebA11yProjector(source, undefined, registry);
  const targetSnapshot = { objectRef:targetRef, viewEpoch:1, ...(explicit ? {id:'proto-id'} : {}), states:{}, actions:{}, relations:{} };
  const sourceSnapshot = { objectRef:sourceRef, viewEpoch:1, states:{}, actions:{}, relations:{controls:[targetRef]}, relationModes:{controls:'append'}, partRelationships:[{family,scope:{},source:sourceRef,sourceRole:'source',targetRole:'target',relation:'controls',key:'x',sourceEpoch:1,targetEpoch:1,target:targetRef}] };
  const snapshots=[];
  const capture = phase => snapshots.push({phase,id:target.getAttribute('id'),controls:source.getAttribute('aria-controls')});
  projector(targetSnapshot); dependent(sourceSnapshot);
  await window.happyDOM.whenAsyncComplete(); capture('initial');
  projector.detach(); capture('detached');
  target.id='host-later'; capture('host-write-after-detach');
  projector.reactivate(); projector({...targetSnapshot,viewEpoch:2});
  dependent({...sourceSnapshot,partRelationships:sourceSnapshot.partRelationships.map(part=>({...part,targetEpoch:2}))});
  capture('rematerialized');
  await window.happyDOM.whenAsyncComplete(); capture('after-observer');
  projector.dispose(); dependent.dispose(); await window.happyDOM.close();
  results.push({explicit,flushBeforeDetach,snapshots});
}
const root='<candidate-root>';
const inputs=['packages/modules/a11y/src/web.ts','packages/modules/a11y/dist/web.js'].map(path=>({path,sha256:createHash('sha256').update(fs.readFileSync(root+'/'+path)).digest('hex')}));
const report={head:'fd9fc6b4aa46b2ad18b4ffd685448d36d2ba9ea2',observedAt:new Date().toISOString(),environment:'Node 22, built dist, Happy DOM MutationObserver; no browser claim',inputs,results};
fs.writeFileSync('<evidence-root>/review/repro-id-after-detach-fd9fc6b4.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
