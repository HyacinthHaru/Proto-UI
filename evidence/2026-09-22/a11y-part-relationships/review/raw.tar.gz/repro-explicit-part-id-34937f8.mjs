import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { Window } from '<candidate-root>/node_modules/happy-dom/lib/index.js';
import { createAnatomyFamily, createA11ySemanticObjectRef } from '<candidate-root>/packages/core/dist/index.js';
import { createWebA11yProjectionRegistry, createWebA11yProjector } from '<candidate-root>/packages/modules/a11y/dist/index.js';

const root = '<candidate-root>';
const independentWriter = process.argv.includes('--independent-writer');
const replayBeforeDelivery = process.argv.includes('--replay-before-delivery');
const explicit = !independentWriter && !process.argv.includes('--without-explicit-id');
const output = '<evidence-root>/review/' +
  (independentWriter ? 'repro-independent-id-writer-34937f8' : explicit ? 'repro-explicit-part-id-34937f8' : 'repro-generated-part-id-control-34937f8') +
  (replayBeforeDelivery ? '-replay-before-delivery' : '') + '.json';
const window = new Window();
const document = window.document;
globalThis.MutationObserver = window.MutationObserver;
const source = document.createElement('button');
const target = document.createElement('section');
document.body.append(source, target);
const registry = createWebA11yProjectionRegistry();
const sourceRef = createA11ySemanticObjectRef();
const targetRef = createA11ySemanticObjectRef();
const family = createAnatomyFamily('explicit-part-id-review', {
  roles: {
    root: { cardinality: { min: 1, max: 1 } },
    source: { cardinality: { min: 0, max: '*' } },
    target: { cardinality: { min: 0, max: '*' } },
  },
});
const scope = {};
const snapshots = [];
const mutations = [];
const observe = (phase) => snapshots.push({
  phase,
  targetId: target.getAttribute('id'),
  controls: source.getAttribute('aria-controls'),
});
const recorder = new window.MutationObserver((records) => {
  mutations.push(records.map((record) => ({
    node: record.target === target ? 'target' : 'source',
    attr: record.attributeName,
    old: record.oldValue,
    currentAtDelivery: record.target.getAttribute(record.attributeName),
  })));
});
recorder.observe(document.body, { subtree: true, attributes: true, attributeOldValue: true });
const dependent = createWebA11yProjector(source, undefined, registry);
const projector = createWebA11yProjector(target, undefined, registry);
const targetSnapshot = { objectRef: targetRef, viewEpoch: 1, ...(explicit ? { id: 'proto-id' } : {}), states: {}, actions: {}, relations: {} };
projector(targetSnapshot);
dependent({
  objectRef: sourceRef, viewEpoch: 1, states: {}, actions: {},
  relations: { controls: [targetRef] }, relationModes: { controls: 'append' },
  partRelationships: [{
    family, scope, source: sourceRef, sourceRole: 'source', targetRole: 'target',
    relation: 'controls', key: 'exact-key', sourceEpoch: 1, targetEpoch: 1, target: targetRef,
  }],
});
await window.happyDOM.whenAsyncComplete();
observe('settled-initial');
const writer = independentWriter ? createWebA11yProjector(target, undefined, registry) : null;
if (writer) writer({ objectRef: createA11ySemanticObjectRef(), id: 'independent-id', states: {}, actions: {}, relations: {} });
else target.id = 'host-later';
observe(independentWriter ? 'independent-write-return' : 'host-write-return');
if (replayBeforeDelivery) {
  projector({ ...targetSnapshot, states: { busy: true } });
  observe('unrelated-state-replay-before-observer-delivery');
}
await window.happyDOM.whenAsyncComplete();
observe('after-mutation-observer-delivery');
if (writer) {
  writer.dispose();
  observe('independent-writer-disposal-return');
  await window.happyDOM.whenAsyncComplete();
  observe('after-writer-disposal-observation');
}
projector.dispose();
observe('target-disposal');
dependent.dispose();
recorder.disconnect();
const paths = ['packages/modules/a11y/src/web.ts','packages/modules/a11y/dist/index.js','packages/modules/a11y/dist/web.js','packages/core/dist/index.js'];
const inputs = paths.map((path) => ({
  path,
  sha256: createHash('sha256').update(fs.readFileSync(root+'/'+path)).digest('hex'),
}));
const result = {
  observedAt: new Date().toISOString(), node: process.version,
  environment: 'happy-dom MutationObserver delivery, built public dist; host simulation, not native browser evidence',
  head: execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),
  productCommit: '34937f8e0cc0cd4feed67a69bea30ffa4355f79c',
  explicit, independentWriter, replayBeforeDelivery, inputs, snapshots, mutations,
};
fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({output,...result},null,2));
await window.happyDOM.close();
