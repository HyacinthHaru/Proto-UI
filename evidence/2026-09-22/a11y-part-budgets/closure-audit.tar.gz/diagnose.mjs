import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { gzipSync } from 'node:zlib';
const { MAIN_ROOT, FEATURE_ROOT, OUTPUT_DIR } = process.env;
if (!MAIN_ROOT || !FEATURE_ROOT || !OUTPUT_DIR) {
  throw new Error('MAIN_ROOT, FEATURE_ROOT and OUTPUT_DIR are required.');
}
const output = path.resolve(OUTPUT_DIR);
const roots = [
  {
    name: 'main9d',
    root: path.resolve(MAIN_ROOT),
    head: '9d9552bbe0bc747e9b7f2f1ff6f6db3414086424',
  },
  {
    name: 'candidate868',
    root: path.resolve(FEATURE_ROOT),
    head: '868d3adbd22fae98b8e33ea58a9f3353158c506d',
  },
];
const entries = {
  core: 'packages/core/src/index.ts',
  runtime: 'packages/runtime/src/index.ts',
  react: 'packages/adapters/react/src/index.ts',
  vue: 'packages/adapters/vue/src/index.ts',
  wc: 'packages/adapters/web-component/src/index.ts',
  a11y: 'packages/modules/a11y/src/index.ts',
};
const sha = (b) => createHash('sha256').update(b).digest('hex');
const result = {
  startedAt: new Date().toISOString(),
  scope:
    'Bounded in-memory esbuild diagnostics: six roots per fixed head. Budget script bundling options unchanged; metafile collection added. No product build, test, browser, source/budget edit, or published package claim.',
  runs: [],
};
for (const selected of roots) {
  const git = (...args) =>
    execFileSync('git', ['-C', selected.root, ...args], { encoding: 'utf8' }).trim();
  if (git('rev-parse', 'HEAD') !== selected.head)
    throw new Error('Unexpected HEAD ' + selected.name);
  const req = createRequire(path.join(selected.root, 'package.json'));
  const { build, version } = req('esbuild');
  const manifestPaths = [];
  for (const scope of ['core', 'hooks', 'runtime', 'types', 'cli'])
    manifestPaths.push(`packages/${scope}/package.json`);
  for (const scope of ['adapters', 'modules', 'prototypes'])
    for (const e of fs.readdirSync(path.join(selected.root, 'packages', scope), {
      withFileTypes: true,
    })) {
      const rel = `packages/${scope}/${e.name}/package.json`;
      if (e.isDirectory() && fs.existsSync(path.join(selected.root, rel))) manifestPaths.push(rel);
    }
  const manifests = manifestPaths.map((p) =>
    JSON.parse(fs.readFileSync(path.join(selected.root, p), 'utf8'))
  );
  const workspaceNames = new Set(manifests.map((m) => m.name));
  const externalNames = new Set();
  for (const m of manifests)
    for (const field of ['dependencies', 'peerDependencies', 'optionalDependencies'])
      for (const n of Object.keys(m[field] ?? {})) if (!workspaceNames.has(n)) externalNames.add(n);
  const external = [...externalNames].flatMap((n) => [n, n + '/*']);
  external.push('node:*');
  const treeMap = new Map(
    git('ls-tree', '-r', selected.head)
      .split('\n')
      .map((r) => {
        const [meta, p] = r.split('\t');
        return [p, meta.split(' ')[2]];
      })
  );
  const repo = {
    ...selected,
    tree: git('rev-parse', 'HEAD^{tree}'),
    statusBefore: git('status', '--short'),
    environment: {
      node: process.version,
      zlib: process.versions.zlib,
      esbuild: version,
      platform: process.platform,
      arch: process.arch,
    },
    external,
    manifestInputs: manifestPaths.map((p) => ({
      path: p,
      sha256: sha(fs.readFileSync(path.join(selected.root, p))),
      gitBlob: treeMap.get(p),
    })),
    configInputs: ['tsconfig.json', 'scripts/analysis/package-budgets.mjs', 'pnpm-lock.yaml'].map(
      (p) => ({
        path: p,
        sha256: sha(fs.readFileSync(path.join(selected.root, p))),
        gitBlob: treeMap.get(p),
      })
    ),
    bundles: [],
  };
  for (const [name, entry] of Object.entries(entries)) {
    const options = {
      absWorkingDir: selected.root,
      entryPoints: [entry],
      bundle: true,
      write: false,
      minify: true,
      treeShaking: true,
      format: 'esm',
      platform: 'browser',
      target: ['es2020'],
      external,
      logLevel: 'silent',
      metafile: true,
    };
    const built = await build(options);
    const content = Buffer.concat(built.outputFiles.map((f) => Buffer.from(f.contents)));
    const metafile = path.join(output, `${selected.name}-${name}-metafile.json`);
    fs.writeFileSync(metafile, JSON.stringify(built.metafile, null, 2) + '\n');
    const bytes = new Map();
    for (const out of Object.values(built.metafile.outputs))
      for (const [p, info] of Object.entries(out.inputs))
        bytes.set(p, (bytes.get(p) ?? 0) + info.bytesInOutput);
    const inputs = Object.entries(built.metafile.inputs).map(([p, meta]) => {
      const absolute = path.resolve(selected.root, p);
      const physical = fs.realpathSync(absolute);
      const rel = path.relative(selected.root, physical);
      const b = fs.readFileSync(absolute);
      return {
        path: p,
        physicalPath: physical,
        physicalRelative: rel,
        sha256: sha(b),
        gitBlob: treeMap.get(rel) ?? null,
        sourceBytes: b.length,
        bytesInOutput: bytes.get(p) ?? 0,
        imports: meta.imports,
      };
    });
    const physicalGroups = Object.groupBy(inputs, (i) => i.physicalPath);
    const aliases = Object.entries(physicalGroups)
      .filter(([, arr]) => arr.length > 1)
      .map(([physicalPath, arr]) => ({ physicalPath, inputIds: arr.map((i) => i.path) }));
    const bundle = {
      name,
      entry,
      minifiedBytes: content.length,
      minifiedSha256: sha(content),
      gzipBytes: gzipSync(content, { level: 9 }).length,
      inputCount: inputs.length,
      metafile: path.basename(metafile),
      metafileSha256: sha(fs.readFileSync(metafile)),
      outputAttributionBytes: [...bytes.values()].reduce((a, b) => a + b, 0),
      inputs,
      duplicatePhysicalInputIds: aliases,
      externalImports: [
        ...new Set(
          Object.values(built.metafile.outputs).flatMap((o) =>
            o.imports.filter((i) => i.external).map((i) => i.path)
          )
        ),
      ].sort(),
    };
    repo.bundles.push(bundle);
    console.log(
      JSON.stringify({
        head: selected.name,
        name,
        minifiedBytes: bundle.minifiedBytes,
        gzipBytes: bundle.gzipBytes,
        sha256: bundle.minifiedSha256,
        inputs: bundle.inputCount,
        duplicatePhysicalIds: aliases.length,
      })
    );
  }
  repo.headAfter = git('rev-parse', 'HEAD');
  repo.statusAfter = git('status', '--short');
  repo.inputHashMismatches = repo.bundles.flatMap((b) =>
    b.inputs
      .filter((i) => sha(fs.readFileSync(path.resolve(selected.root, i.path))) !== i.sha256)
      .map((i) => ({ bundle: b.name, path: i.path }))
  );
  result.runs.push(repo);
  fs.writeFileSync(path.join(output, 'diagnostics.json'), JSON.stringify(result, null, 2) + '\n');
}
result.finishedAt = new Date().toISOString();
result.harnessSha256 = sha(fs.readFileSync(new URL(import.meta.url)));
fs.writeFileSync(path.join(output, 'diagnostics.json'), JSON.stringify(result, null, 2) + '\n');
