# Reproduce the #549 closure audit

This runner repeats six bounded, in-memory esbuild measurements at each of two fixed repository heads. It writes diagnostics and metafiles to a caller-selected output directory. It does not change repository source or budgets, install dependencies, run public package builds/tests/browsers, or measure the large Lucide entry.

Required environment:

- Node `22.23.2` with zlib `1.3.1-e00f703`; the recorded local run used macOS arm64, and overlapping artifacts match canonical Linux x64 CI.
- Existing repository dependencies, including the repository-pinned esbuild `0.25.12`, available in both checkouts. Corepack/pnpm is `10.32.1` when preparing those dependencies.
- `MAIN_ROOT`: checkout at `9d9552bbe0bc747e9b7f2f1ff6f6db3414086424`.
- `FEATURE_ROOT`: checkout at `868d3adbd22fae98b8e33ea58a9f3353158c506d`.
- `OUTPUT_DIR`: a fresh, existing directory outside both checkouts.

The runner rejects a different HEAD, records Git status before/after, and records/re-hashes every bundle input. Use clean source checkouts for comparison with the included results. No machine-specific path is embedded in the script.

From this directory:

```sh
export MAIN_ROOT=/absolute/path/to/main-checkout
export FEATURE_ROOT=/absolute/path/to/feature-checkout
export OUTPUT_DIR=/absolute/path/to/new-audit-output
mkdir -p "$OUTPUT_DIR"
node ./diagnose.mjs > "$OUTPUT_DIR/diagnose.log" 2>&1
```

`diagnostics.json` and twelve `*-metafile.json` files are written into `OUTPUT_DIR`. Bundle bytes remain in memory; their minified length, SHA-256 and level-9 gzip size are recorded. Runtime, React, Vue, WC and Core reproduce the existing budget entry settings; standalone A11y is an additional diagnostic entry with no new ceiling.

The algorithm, six entries, pinned heads, assertions, external dependency boundary and esbuild options are identical to the original local diagnostic. Changes are limited to these three environment variables, a missing-input error, and repository Prettier formatting. In the verification rerun, all twelve output sizes/hashes, all twelve raw metafile hashes, and all source input hashes/Git blobs were identical to the originals.

This prepared publication directory contains:

- [REPORT.md](REPORT.md): concise findings and interpretation.
- [diagnose.mjs](diagnose.mjs): parameterized executable source.
- [evidence/measurements.json](evidence/measurements.json): recorded measurements and source-relative provenance, with machine absolute paths omitted.
- Twelve verbatim metafiles under `evidence/`; their hashes remain those of the executed runner.
- [evidence/parameterized-runner-equivalence.json](evidence/parameterized-runner-equivalence.json): original/new harness hashes and exact rerun equality.
- [evidence/attribution.json](evidence/attribution.json): per-input minified-output deltas, graph paths and duplication checks.
- [evidence/canonical-ci-comparison.json](evidence/canonical-ci-comparison.json): existing canonical CI comparisons and raw local receipt hashes.
- [evidence/original-preservation-manifest.json](evidence/original-preservation-manifest.json): hashes for the nineteen preserved original local files.

The original absolute-path runner, raw local diagnostics, original analysis notes and raw CI logs remain in the separate local evidence archive. They are not linked as if they were public files in this directory. The public measurement copy explicitly removes only machine root/physical paths; source IDs, Git blobs, source SHA-256, imports, measurements and output attribution are retained.

`bytesInOutput` describes attribution within a minified bundle. It is not a separately gzip-compressed file contribution. Gzip deltas are measured on whole bundles and must not be added across files or entry points. This audit does not establish a global size optimum or grant budget approval.
