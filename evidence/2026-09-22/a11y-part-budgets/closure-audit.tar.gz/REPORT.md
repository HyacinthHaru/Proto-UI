# #549 closure growth: reproducible audit

The audited change adds one new bundled input, `packages/modules/a11y/src/part-relationships.ts`, to each affected root. No accidental duplicate Core/Runtime/A11y copy, duplicate physical input ID, src/dist double inclusion, new external dependency, or unrelated eager module was found. This is a bounded finding about the observed closures, not proof of a global size optimum or budget approval.

The comparison is main `9d9552bbe0bc747e9b7f2f1ff6f6db3414086424` versus feature `868d3adbd22fae98b8e33ea58a9f3353158c506d`. The parameterized [runner](diagnose.mjs) uses the repository budget script's bundle/minify/tree-shaking, browser ESM/ES2020 and external-boundary settings, adding metafile collection. Six entries were measured at each head, with output bytes kept in memory.

| Root | Main → feature minified bytes | Minified delta | Main → feature gzip bytes | Whole-bundle gzip delta |
| --- | --: | --: | --: | --: |
| Core | 15,514 → 15,514 | 0 | 4,894 → 4,896 | +2 |
| Runtime | 252,198 → 260,957 | +8,759 | 63,228 → 65,865 | +2,637 |
| React | 313,491 → 322,409 | +8,918 | 82,758 → 85,351 | +2,593 |
| Vue | 312,200 → 321,108 | +8,908 | 82,480 → 85,093 | +2,613 |
| WC | 325,310 → 334,292 | +8,982 | 85,908 → 88,554 | +2,646 |
| Standalone A11y, diagnostic only | 21,918 → 30,508 | +8,590 | 6,871 → 9,450 | +2,579 |

The five overlapping gated entries exactly match minified bytes, SHA-256 and gzip in both canonical jobs: [main run 35683310407 / job 106604782868](https://github.com/Proto-UI/Proto-UI/actions/runs/35683310407/job/106604782868) and [feature run 35691550964 / job 106629473832](https://github.com/Proto-UI/Proto-UI/actions/runs/35691550964/job/106629473832). Existing full budget receipts also match all nine policy entries at each head. This bounded rerun did not remeasure the other four policy entries. The feature job's merge checkout tree equals the feature commit's tree. Canonical jobs used Node 22.23.2, zlib 1.3.1-e00f703 and esbuild 0.25.12 on Linux x64; the local diagnostic used the same versions on macOS arm64. Details are in [canonical-ci-comparison.json](evidence/canonical-ci-comparison.json).

A11y `create.ts`, `web.ts`, and the new registry account for **95.5%–98.1% of the affected roots' minified-output growth**. Respectively, their attributed deltas are approximately +3,717–3,738, +2,883–2,947, and +1,959 minified bytes. They implement part declarations, exact tuple resolution, epoch/lifecycle integration, live identity and collision reconciliation, ownership preservation, disposal and physical rebinding. Small residual changes include Adapter notifications/reveal sequencing, Runtime view-presence preparation, Anatomy guards, the Table undeclared-role guard, and minifier attribution variations in unchanged sources. [attribution.json](evidence/attribution.json) distinguishes changed-source and unchanged-source rows.

These are minified-output attributions, **not additive per-file gzip contributions**. Gzip uses the complete artifact's shared dictionary; output naming/layout can change as the bundle changes. The table's gzip differences are whole-bundle measurements. Standalone A11y's gzip delta must not be added to Runtime or Adapter gzip results.

The new A11y → Anatomy package edge does not pull in a second or newly eager Anatomy implementation. `AnatomyPort` is imported as a type and resolved through the existing optional port interface. Standalone A11y has zero Anatomy source inputs at both heads. Runtime and Adapter closures already contain the same seven Anatomy files on main; the observed Anatomy increment is only **46 minified bytes** from two capability guards. The new registry enters through the pre-existing A11y ModuleDef/barrel paths. No accepted A–K behavior was removed, and no unrelated architecture change or numeric ceiling is proposed by this audit.

Original and portable versions are explicitly preserved:

- Original runner SHA-256: `2927043c07cd83d58749d6a8b6533b3164dcbff7739fa4475dfb44ea45bb2b56`.
- Parameterized, repository-formatted runner SHA-256: `7eac4ab8ffbe38e7b46b2326890e67dc78415c1b975a72f03083acf92959aca6`.
- Nineteen original local files were archived byte-for-byte before revision; originals remain unchanged.
- The new runner changed only path configuration, the missing-input error, and formatting. All **twelve** rerun output sizes/minified hashes/gzip sizes, all **twelve** raw metafile hashes, and all source input metadata/SHA/Git blobs match the original diagnostics. See [equivalence evidence](evidence/parameterized-runner-equivalence.json).

[README.md](README.md) gives the exact portable invocation and identifies what is distributed here versus retained only in the local archive. [measurements.json](evidence/measurements.json) and the twelve relative-path metafiles contain the reproducible closure evidence. No feature or budget source was changed, and no full build/test/browser matrix or GitHub write was performed. The existing Runtime/React/Vue budget failures still require the separately reviewed resolution chosen by the maintainer.
