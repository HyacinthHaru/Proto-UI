import ts from '<WORKTREE>/node_modules/typescript/lib/typescript.js';
import { execFileSync } from 'node:child_process';
import { readFileSync,writeFileSync } from 'node:fs';
import {createHash} from 'node:crypto';
const w='<WORKTREE>';
const files=['site-search-commands.browser.test.ts','homepage-dogfood.browser.test.ts','demo-shadow-split-s4.browser.test.ts'].map(x=>'apps/www/src/content/docs/zh-cn/'+x);
const hash=s=>createHash('sha256').update(s).digest('hex');
function collect(text,file){let result={matchers:[],caseBudgets:[],hookBudgets:[],inputs:[]};const sf=ts.createSourceFile(file,text,ts.ScriptTarget.Latest,true);const norm=n=>n.getText(sf).replace(/\s+/g,' ');function visit(n){if(ts.isCallExpression(n)){const expr=norm(n.expression);if(/\.to(?:Be|Equal|Have|Match|Contain|Throw|StrictEqual|BeTruthy|BeFalsy|BeNull|BeDefined|BeUndefined|BeGreater|BeLess)/.test(expr))result.matchers.push(norm(n));if(/^(it|test|it\.skip|test\.skip)$/.test(expr))result.caseBudgets.push(n.arguments[2]?norm(n.arguments[2]):'default');if(/^(beforeAll|afterAll|beforeEach|afterEach)$/.test(expr))result.hookBudgets.push(n.arguments[1]?norm(n.arguments[1]):'default');if(/\.(click|press|type|fill|wheel|check|uncheck|selectOption|tap|dispatchEvent)$/.test(expr))result.inputs.push(norm(n));}ts.forEachChild(n,visit)}visit(sf);return result}
const rows=files.map(file=>{const before=execFileSync('git',['show','d92141c57ebab192f3741e7336c1ec0f24b61c5c:'+file],{cwd:w,encoding:'utf8'}),after=readFileSync(w+'/'+file,'utf8');const a=collect(before,file),b=collect(after,file);return {file,beforeSHA256:hash(before),afterSHA256:hash(after),before:a,after:b,equal:Object.fromEntries(Object.keys(a).map(k=>[k,JSON.stringify(a[k])===JSON.stringify(b[k])]))}});
// Wrapping the original poll callback changes its enclosing matcher text. The
// receiver callbacks are recorded for review; matcher terminal and args remain.
for(const r of rows){r.matcherEndsEqual=JSON.stringify(r.before.matchers.map(x=>x.match(/\.to\w+\([^]*$/)?.[0]))===JSON.stringify(r.after.matchers.map(x=>x.match(/\.to\w+\([^]*$/)?.[0]));}
writeFileSync(new URL('./preservation.json',import.meta.url),JSON.stringify({createdAt:new Date().toISOString(),rows,limits:['Static source comparison, not browser execution.','S4 extracted predicate short-circuit equivalence has direct DOM controls.']},null,2)+'\n');
console.log(JSON.stringify(rows.map(r=>({file:r.file,counts:Object.fromEntries(Object.entries(r.after).map(([k,v])=>[k,v.length])),equal:r.equal,matcherEndsEqual:r.matcherEndsEqual})),null,2));
