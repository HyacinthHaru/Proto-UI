from pathlib import Path
import subprocess,os,json,sys,datetime,hashlib
r=Path(__file__).parent;p=json.loads(Path(sys.argv[1]).read_text());w=Path(p['workdir']);out=r/sys.argv[2];out.mkdir(exist_ok=False)
env=os.environ.copy();env['PATH']=p['nodeToolchainBin']+':'+env['PATH'];env.update(p.get('environmentOverrides',{}))
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def g(*args):return subprocess.check_output(['git',*args],cwd=w).decode().strip()
def census():
 rows={}
 for b in subprocess.check_output(['git','ls-files','-z'],cwd=w).split(b'\0'):
  if not b:continue
  q=os.fsdecode(b);f=w/q
  rows[q]={'sha256':hashlib.sha256(os.readlink(f).encode() if f.is_symlink() else f.read_bytes()).hexdigest(),'symlink':f.is_symlink()}
 return rows
def extras():
 return {str(Path(q).resolve()):hashlib.sha256(Path(q).read_bytes()).hexdigest() for q in p.get('extraInputPaths',[])}
extraBefore=extras();before=census();(out/'input-manifest-before.json').write_text(json.dumps(before,indent=2)+'\n');args=p['argv'];row={'start':now(),'argv':args,'plan':str(Path(sys.argv[1]).resolve()),'environmentOverrides':p.get('environmentOverrides',{}),'head':g('rev-parse','HEAD'),'indexTree':g('write-tree'),'statusBefore':g('status','--porcelain'),'node':subprocess.check_output(['node','-v'],env=env,text=True).strip(),'selectedFiles':p.get('files',[]),'extraInputsBefore':extraBefore,'scope':'Tracked worktree bytes census; dependency/browser/toolchain inputs separately identified, not a complete closure'}
(out/'running.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({'start':row['start'],'out':str(out),'selectedFiles':len(row['selectedFiles'])}),flush=True)
with (out/'run.log').open('x') as f:result=subprocess.run(args,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
extraAfter=extras();after=census();(out/'input-manifest-after.json').write_text(json.dumps(after,indent=2)+'\n');row.update(end=now(),exit=result.returncode,indexTreeAfter=g('write-tree'),statusAfter=g('status','--porcelain'),sourceStable=before==after,trackedFiles=len(before),extraInputsAfter=extraAfter,extraInputsStable=extraBefore==extraAfter);(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({k:row[k] for k in ['head','indexTree','exit','sourceStable','start','end']}),flush=True);raise SystemExit(result.returncode)
