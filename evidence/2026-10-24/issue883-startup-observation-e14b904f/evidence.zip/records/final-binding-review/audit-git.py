from pathlib import Path
import subprocess,json,hashlib,threading,datetime
D=Path(__file__).resolve().parent;R=D.parent;W=Path('<WORKTREE>');H='e14b904f3a9201de412b28f85db9b29b64c36bd0';T='8b36edbd79f11afb83ed04b839ee63d33e53f128';BASE='d92141c57ebab192f3741e7336c1ec0f24b61c5c';sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==H
assert subprocess.check_output(['git','rev-parse',H+'^{tree}'],cwd=W,text=True).strip()==T
assert subprocess.check_output(['git','status','--porcelain'],cwd=W)==b''
data=subprocess.check_output(['git','ls-tree','-rz','--full-tree',H],cwd=W);entries=[]
for raw in data.split(b'\0'):
 if not raw:continue
 meta,name=raw.split(b'\t',1);mode,typ,oid=meta.decode().split();assert typ=='blob';entries.append((name.decode('utf8'),mode,oid))
unique=list(dict.fromkeys(oid for _,_,oid in entries));proc=subprocess.Popen(['git','cat-file','--batch'],cwd=W,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def feed():
 try:
  for oid in unique:proc.stdin.write((oid+'\n').encode())
  proc.stdin.close()
 except BrokenPipeError:pass
thread=threading.Thread(target=feed);thread.start();hashes={};sizes={}
for wanted in unique:
 header=proc.stdout.readline().decode().strip().split();assert len(header)==3 and header[0]==wanted and header[1]=='blob',header
 size=int(header[2]);remaining=size;h=hashlib.sha256()
 while remaining:
  block=proc.stdout.read(min(remaining,1024*1024));assert block;h.update(block);remaining-=len(block)
 assert proc.stdout.read(1)==b'\n';hashes[wanted]=h.hexdigest();sizes[wanted]=size
thread.join();assert proc.wait()==0
index={name:{'gitBlob':oid,'sha256':hashes[oid],'symlink':mode=='120000','mode':mode,'bytes':sizes[oid]}for name,mode,oid in entries};(D/'signed-git-index.json').write_text(json.dumps(index,indent=2)+'\n')
comparisons=[]
for name in ['native-close-final','unit-close-final','types-close-final','combination297-final']:
 b=R/name/'launcher';before=json.loads((b/'input-manifest-before.json').read_text());after=json.loads((b/'input-manifest-after.json').read_text());rec=json.loads((b/'receipt.json').read_text());assert len(before)==len(after)==11367;assert before==after and rec['sourceStable']
 mismatches=[{'path':p,'executionSHA256':r['sha256'],'signedSHA256':index.get(p,{}).get('sha256'),'symlinkExecution':r['symlink'],'symlinkGit':index.get(p,{}).get('symlink')}for p,r in before.items() if p not in index or r['sha256']!=index[p]['sha256'] or r['symlink']!=index[p]['symlink']]
 comparisons.append({'run':name,'trackedEntries':len(before),'beforeAfterExact':True,'receiptSourceStable':rec['sourceStable'],'signedGitEqualEntries':len(before)-len(mismatches),'mismatches':mismatches,'signedOnlyPaths':sorted(set(index)-set(before)),'inputBeforeSHA256':sha((b/'input-manifest-before.json').read_bytes()),'inputAfterSHA256':sha((b/'input-manifest-after.json').read_bytes())})
change=json.loads((R/'candidate-change-close-final.json').read_text());candidate=[]
for r in change['files']:
 p=r['path'];current=index[p];candidate.append({'path':p,'frozenSHA256':r['sha256'],'signedSHA256':current['sha256'],'equal':r['sha256']==current['sha256'],'gitBlob':current['gitBlob'],'bytes':current['bytes']})
assert all(r['equal']for r in candidate)
record='internal/records/2026-10-24-docs-startup-query-timing.md';assert set(index)-set(json.loads((R/'native-close-final/launcher/input-manifest-before.json').read_text()))=={record}
assert all(not x['mismatches']for x in comparisons if x['run']!='combination297-final')
oldplan=json.loads((R/'publication-prep/selected-inputs-plan.v1.json').read_text());private=[]
for r in oldplan['sourceSnapshot']:
 p=R/'publication-prep/source-snapshot-close-candidate'/r['path'];private.append({'path':r['path'],'privateSHA256':sha(p.read_bytes()),'signedSHA256':index[r['path']]['sha256'],'equal':sha(p.read_bytes())==index[r['path']]['sha256']})
print(json.dumps({'head':H,'tree':T,'gitEntries':len(index),'uniqueBlobs':len(unique),'compared':comparisons,'candidateFrozenAllEqual':all(x['equal']for x in candidate),'privatePrepAllEqual':all(x['equal']for x in private)},indent=2))
(D/'git-comparison.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':H,'tree':T,'gitEntries':len(index),'uniqueBlobs':len(unique),'indexSHA256':sha((D/'signed-git-index.json').read_bytes()),'comparisons':comparisons,'candidateBinding':candidate,'privatePrepBinding':private},indent=2)+'\n')
