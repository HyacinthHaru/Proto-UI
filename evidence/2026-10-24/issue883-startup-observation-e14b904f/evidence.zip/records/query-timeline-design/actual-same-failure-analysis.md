当前原始同次CI记录：Docs10=2pass/8fail；Search原6个readiness红。以下均为观测区间，非根因或纯transport耗时。

| family/width | verdict | rawEvaluateHandle ms | selector resolve ms | handle evaluate ms | browser selector/getter ms | Node return − verdict ms |
|---|---|---:|---:|---:|---:|---:|
| brutalist/1280 | fail | 1089.954 | 1090.219 | 15.515 | 4.600/0.000 | 106.519 |
| brutalist/1440 | fail | 1135.424 | 1135.691 | 15.904 | 3.900/0.100 | 153.032 |
| brutalist/2048 | fail | 1098.867 | 1099.143 | 16.353 | 3.900/0.000 | 116.942 |
| brutalist/320 | pass | 868.844 | 869.221 | 51.510 | 2.900/0.000 | -0.082 |
| brutalist/390 | pass | 848.350 | 848.661 | 14.756 | 3.800/0.000 | -0.043 |
| shadcn/1280 | fail | 1736.144 | 1736.348 | 51.587 | 4.700/0.000 | 788.389 |
| shadcn/1440 | fail | 1734.711 | 1734.890 | 67.278 | 4.300/0.000 | 802.921 |
| shadcn/2048 | fail | 1729.807 | 1730.048 | 57.849 | 4.600/0.000 | 789.350 |
| shadcn/320 | fail | 1416.207 | 1417.269 | 56.002 | 4.700/0.000 | 482.366 |
| shadcn/390 | fail | 1353.072 | 1353.323 | 49.713 | 4.600/0.000 | 404.582 |

| Search case | browser entry − deadline ms | first target observation − deadline ms | first fully-ready observation − deadline ms |
|---|---:|---:|---:|
| brutalist-dark-1440 | 161 | 218 | 218 |
| brutalist-light-1440 | 71 | 127 | 127 |
| shadcn-dark-1440 | 635 | 804 | 804 |
| shadcn-dark-390 | 428 | 598 | 598 |
| shadcn-light-1440 | 693 | 857 | 857 |
| shadcn-light-390 | 436 | 572 | 572 |

所有10个Docs同call/query1/attempt1映射完整、7个SDK源码hash匹配、0drops/errors、原context已close/disposed；transportComplete仍false。全部injectedScript entry为未缓存，主要区间落在原rawEvaluateHandle的Promise观察；parse/context本身短，不能再称整段为一个未拆resolve await。
Search两类first均是已有MO/defined/root-found交付后的query记录，不是物理mutation或首帧。记录DateNow差未标定跨进程误差；不把phase重叠相加、也不把Node与page performance.now直接相减。
partial / ABSTAIN；未修改原件、源码、运行测试/浏览器或网络。
