# e14b CI progress at 2026-10-24T02:40:37.181370+00:00

Head `e14b904f3a9201de412b28f85db9b29b64c36bd0` / tree `8b36edbd79f11afb83ed04b839ee63d33e53f128`; synthetic checkout `3d287e473f52391fcd6126a7ff5aa384e90ecfd7` verified by Git API. Main ref remained81339. This is a non-atomic fully paginated metadata read, partial/ABSTAIN, not approval.

Primary run 40053906237 is **in_progress / None**, with 21 actual jobs. Terminal conclusions: {'success': 13, 'failure': 3}; states: {'completed': 16, 'in_progress': 5}. Queued/running jobs remain unassessed.

Actual plan selects1272 general files,82 browserfiles in8 shards and26 exclusions. Only completed shards [5, 4, 6] subtotal {'passed': 379, 'failed': 4, 'skipped': 15}; not an eight-shard total.

Package actual47build/47manifest/9policy pass;4PASS5ADVISORY withstrictoversretained. Types actual{'jobId': 120752484841, 'files': 943, 'errors': 0, 'warnings': 0, 'hints': 14, 'rawLog': {'path': '<R23>/ci-e14b904f/job-logs/120752484841.log', 'bytes': 26811, 'sha256': '5c1faf939e0952910ebb0c3f95d9bdf4c56acbfb323b1f9200f01348d3b1596a'}}. General actual{'jobId': 120752530924, 'publicDocDrift': 78, 'generalVitest': None, 'boundary': 'No repositoryVitestclaimifpublicdocsprefailed; readactualraw', 'rawLog': {'path': '<R23>/ci-e14b904f/job-logs/120752530924.log', 'bytes': 152946, 'sha256': 'ca6931018ee31c82d3ab1a41def16ba20552243d4b8220ca1ca03b7ab4a3d889'}}.

Allworkflow metadata and downloadedlog index areinREPORT.json. Eachcompletedjoblog wasdownloadedonce; nonterminaljobs notdownloaded. No artifacts/media ornewtests/browser were run. Historicalnegative andpartialoutputs remain. DCO actualstate islisted; absentPoppyrecord isnotapproval.
