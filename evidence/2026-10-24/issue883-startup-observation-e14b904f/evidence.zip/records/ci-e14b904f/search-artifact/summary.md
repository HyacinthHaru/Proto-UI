# e14 isolated Search artifact observation

Actual dedicated Search30:29pass/1fail. Originalhead e14/tree8b36; artifact12545365473, complete8803904B ZIP/296membersCRC/SHA retained. Only13JSON selected; noPNGview.

The sole readinessred distinguishes browserentry−98ms, staging/inertopencommand−63ms, and exactactive-target/fullyreadyobservation+5ms. The first28originalsamples have0targets; onlythelastsampleat+5mscallstheactualgetter. OriginalonTime=false remains.

| Docs case | original query ms | injected Runtime.evaluate Node interval ms | utility Runtime.evaluate ms | original Runtime.callFunctionOn ms | browser selector/getter ms | firstRole delivered before query ms |
|---|---:|---:|---:|---:|---:|---:|
| brutalist/1280 | 536.754 | 502.080 | 6.891 | 25.992 | 1.900/0.000 | 398.069 |
| brutalist/1440 | 551.957 | 514.007 | 8.569 | 27.495 | 1.900/0.000 | 400.961 |
| brutalist/2048 | 541.388 | 506.063 | 6.635 | 26.799 | 1.800/0.000 | 403.574 |
| brutalist/320 | 395.439 | 361.716 | 6.688 | 24.920 | 1.800/0.000 | 404.873 |
| brutalist/390 | 414.206 | 378.880 | 4.610 | 28.928 | 1.900/0.000 | 399.007 |
| shadcn/1280 | 893.618 | 857.720 | 11.289 | 22.755 | 2.700/0.000 | 331.679 |
| shadcn/1440 | 873.731 | 838.296 | 10.576 | 23.111 | 2.800/0.000 | 334.923 |
| shadcn/2048 | 878.931 | 843.330 | 11.178 | 22.553 | 2.800/0.000 | 343.254 |
| shadcn/320 | 694.826 | 673.548 | 9.411 | 7.460 | 2.800/0.000 | 336.165 |
| shadcn/390 | 667.991 | 652.930 | 6.758 | 6.457 | 2.700/0.000 | 348.113 |

All10Docsoriginalpollspassed; eachhas1query/1attempt,3actualCDPcommandsmappedby(sessionId,id),10SDKsourcepinsmatched,0drops/errors,contextclosed/disposed. TheobservedfirstcomboboxrolebatcharrivesatNodebeforetheoriginalqueryinall10. Thisdoesnotretrospectivelyexplainoldfailedcalls.
NodeCDPintervalsarecausalbrackets,notpuretransport/engineCPUtime; Node send return isnotbrowserreceipt. Browsergetter0isquantizedsampleequality. Differentclockdomainsarenotdirectlysubtracted; optionaloffsetenvelopesretainexplicitassumptions.
partial/ABSTAIN; authorofinstrumentation, notformalindependentapproval.
