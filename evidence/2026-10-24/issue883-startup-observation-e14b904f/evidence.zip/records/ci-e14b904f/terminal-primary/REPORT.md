# Exact e14 primary terminal evidence

Primary run **40053906237** was actually read completed/failure at 2026-10-24T02:58:50.703413+00:00: **22 jobs, 13 success and 9 failure**. Synthetic checkout `3d287e473f52391fcd6126a7ff5aa384e90ecfd7` has tree `8b36edbd79f11afb83ed04b839ee63d33e53f128`, equal to head `e14b904f3a9201de412b28f85db9b29b64c36bd0`. All 22 cached original logs print this checkout. Partial / ABSTAIN; no formal approval.

Only shards **3/4/5/6/7** print complete summaries: **550 passed, 8 failed, 15 skipped**. Shards **1/2/8** exit 124 without whole-shard summaries. This subtotal is not an eight-shard total.

Main Search is **16/14**: six initial readiness failures and eight Docs original 1s role failures, with two Docs passes. All eight failed requests later return combobox in the post-verdict drain; this does not change their failure. Dedicated Search **29/1** is a different execution. Main shard2 Homepage **9/9** passes, so no shard2 failure artifact is requested.

S4 locale failures remain the actual 60s startup predicate. The cached stream identifies index0/init1/hostChildren0, with capped observations and no component identity inference. S4 paint now has a concrete **30s locator.click** timeout at `shadow-s4-paint-browser.mjs:90`, after actionability/scrolling but without proof of actual click dispatch. Shard3 also retains two original opacity 1-versus-0.5 failures. Shard7 retains the wc/light Checkbox pressed-shadow none-versus-none failure.

General stops at **78 public-document classification drifts** before repository Vitest; aggregate reports Required job test-general did not succeed. Package is actual **47 builds / 47 manifests / 9 policy tests**, budgets **4 PASS and 5 ADVISORY**, not nine strict passes. Types **943 / 0 errors / 0 warnings / 14 hints**.

Within incomplete shard8, NativeLinks10, Controls10 and Header16 each actually pass; this does not pass the whole shard. Six new terminal logs were downloaded once and all other cached logs reused. No tests, browser, source changes, Actions writes or external publication were performed.
