# Exact e14 main shard1 Search timing

Original main Search **16 pass / 14 fail**: readiness **2/6**, Docs **2/8**. Shard exit124 has no whole-shard total. Source checkout`3d287e473f52391fcd6126a7ff5aa384e90ecfd7` equals e14/tree8b36. Artifact12544694458:8,038,130B,325safeCRC/SHAmembers;31JSON/text selected,0PNG. Partial / ABSTAIN.

| Docs | original verdict | query ms | return − verdict ms | injected Runtime.evaluate Node ms | utility Runtime.evaluate ms | original Runtime.callFunctionOn ms | browser selector / getter ms | role delivered before query ms |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| brutalist/1280 | FAIL | 1119.754 | 119.320 | 1101.389 | 6.764 | 9.286 | 3.500 / 0.000 | 343.137 |
| brutalist/1440 | FAIL | 1143.682 | 142.717 | 1125.170 | 7.934 | 8.188 | 4.300 / 0.000 | 329.869 |
| brutalist/2048 | FAIL | 1140.410 | 139.666 | 1120.407 | 8.077 | 9.635 | 3.400 / 0.000 | 337.088 |
| brutalist/320 | pass | 866.383 | -0.058 | 807.045 | 7.853 | 49.065 | 3.100 / 0.000 | 352.292 |
| brutalist/390 | pass | 885.894 | -0.047 | 828.644 | 8.362 | 46.615 | 3.800 / 0.000 | 342.205 |
| shadcn/1280 | FAIL | 1644.536 | 644.805 | 1595.334 | 10.419 | 36.251 | 4.300 / 0.100 | 242.582 |
| shadcn/1440 | FAIL | 1693.676 | 693.394 | 1640.173 | 12.445 | 38.899 | 4.900 / 0.000 | 243.442 |
| shadcn/2048 | FAIL | 1788.660 | 788.681 | 1735.430 | 12.595 | 37.566 | 5.500 / 0.000 | 233.666 |
| shadcn/320 | FAIL | 1422.243 | 421.186 | 1367.785 | 12.949 | 34.952 | 4.400 / 0.000 | 234.946 |
| shadcn/390 | FAIL | 1371.600 | 371.394 | 1317.057 | 15.888 | 35.938 | 4.600 / 0.000 | 256.352 |

All ten records have ten matching SDK source pins, one original query/attempt and three actual CDP send/response pairs each. All eight failed original verdicts occur within the first injected-script Runtime.evaluate Node send→response interval. Their original Runtime.callFunctionOn commands are actually sent after the verdict, then return combobox before the context-close call marker. This causal command order does not need a page/Node clock subtraction. All ten firstRole console batches were already received before the original query. It remains an earlier observation, not proof of target permanence.

| Readiness red | browser entry − deadline epoch ms | exact target / fullyReady − deadline epoch ms | original samples / actual getter samples |
|---|---:|---:|---:|
| brutalist-dark-1440 | 122 | 201 / 201 | 1 / 0 |
| brutalist-light-1440 | 158 | 207 / 207 | 1 / 0 |
| shadcn-dark-1440 | 746 | 904 / 904 | 1 / 0 |
| shadcn-dark-390 | 357 | 516 / 516 | 1 / 0 |
| shadcn-light-1440 | 1002 | 1118 / 1118 | 1 / 0 |
| shadcn-light-390 | 801 | 925 / 925 | 1 / 0 |

Every readiness red originally evaluated after its deadline and found zero active-selector targets; no actual getter ran in those samples. The journal subsequently observes a matching current owner/generation, noninert ready target. These are delivery/read timestamps, not physical mutation/paint times. Epoch comparisons have unmeasured browser/Node clock offset and quantization.

Node transport return is not browser receipt. The long Runtime.evaluate interval is not pure compile/transport/engine CPU evidence. Browser zero getter spans are equal clock ticks. No production root cause or acceptance is claimed. The dedicated Search29/1 execution stays separate.
