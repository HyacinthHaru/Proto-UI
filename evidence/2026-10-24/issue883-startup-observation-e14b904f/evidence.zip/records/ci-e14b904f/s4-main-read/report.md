# Exact e14 primary shard4 S4 observation

Only cached original job120752530905.log was parsed; no download or new execution. Synthetic checkout3d287e473f52391fcd6126a7ff5aa384e90ecfd7 binds to e14/tree8b36. Both original locale cases failed `page.waitForFunction: Timeout60000ms` at source line125; case durations82.576s and95.845s are below the unchanged150s outer deadline. The complete shard summary is122pass/2fail/0skip.

Both navigations returned before startup-wait. The observed wait begin→error spans are65382.920ms (zh) and70549.301ms (en), including scheduling/SDK/observation effects. In both locales the same-callback first-miss stream has1056 roots/index0: zh`pp-v8eu9rodzp`, en`pp-kseuwk6dwrh`. Each changes from inited=null/hostChildren=null to inited=1/hostChildren=0. There is no recorded index1 progression in this CI run. These opaque IDs/index0 alone do not identify a component or Adapter.

Each bounded init stream emitted128 rows and reached its cap; it is not a whole-matrix history. Both postverdict collections report `budget-expired`, with observation/initObservation null. The separately delivered stream therefore remains the evidence; null does not erase it or mean fulfilled-null. Both locales retain18 identical shadcn-tabs-trigger/transition-all/used-value-rounding errors, with no causal mapping to the first missing host. The recorded actual function text/SHA was checked, and browser startup-change emissions prove this callback executed for those samples.

Context-close events and originalfinally returns are present. The zh closeevent andfinally return precede en's first init marker by135.413248ms and135.230937ms. This does not separately observe the later onTestFinished invocation of the already-settled shared Promise and is not an all-process leak-free proof.

Peer/partial ABSTAIN. Original predicates/deadlines remain red; no production cause or fix is claimed, and earlier local150s/overlap results were not used as this CI explanation.
