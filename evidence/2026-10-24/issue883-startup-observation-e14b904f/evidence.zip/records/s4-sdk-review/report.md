S4 SDK只读审查完成，partial / ABSTAIN。准确当前候选297实际294pass/3fail，三个S4均Vitest150s外层超时；zh/en各18条transition-all/used-value-rounding pageerror保持。

PW1.58.2的公共waitForFunction默认main，后置page.evaluate也默认main；不能把null归为utility/main取错。相同world不保证导航前后是同一document/context。

60s SDK timer仅拒绝progress force-abort，controller仍await task。获取poll handle以后，原result progress.race拒绝会进入未再race的await h.abort()；源码确有延长API结算的可能，但当前没有同调用阶段证据，不能说实际触发。Vitest150s Promise.race也不取消原async body，迟到finally可跨入后续test日志组。

静态TypeScript擦除后 observeS4Startup 仅引用Date、JSON、document、globalThis、window，没有import/helper闭包或__name引用。该模型不是实际Vite运行时String(function)，因此目前可排除明确的源码外部闭包依赖，不能彻底排除未保存的序列化差异。

一个明确采集边界：en collectionComplete=true/observation=null并不证明fulfilled-null；Promise.allSettled的rejected也被caller投影为null。下一私有采集应记录真实status及安全错误摘要，保留2s与原verdict。zh completefalse可证预算内未完成。

建议最小phase为goto、wait、finally、snapshot真实settlement及close；原call前只在内存记录实际function字符串/SHA，原判定后写盘。已有predicate row或独立被动MO可限量console送出，带locale/token/timeOrigin；不能将送达当物理mutation或首帧。无需新warmup、selector预解析、手动abort或延deadline。

未修改W/E或原件，未运行测试、浏览器或网络。报告附已执行候选source-census与pinnedSDK hash。
