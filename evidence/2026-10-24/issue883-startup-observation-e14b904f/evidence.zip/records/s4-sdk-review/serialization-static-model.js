export function observeS4Startup() {
    const previews = [...document.querySelectorAll('[data-previewer-id]')];
    const failure = {};
    const ready = previews.length > 0 &&
        previews.every((previewer, index) => {
            const inited = previewer.getAttribute('data-inited');
            // Preserve the original short circuit: an uninitialized previewer does
            // not query its host merely to produce diagnostics.
            const children = inited === '1' ? (previewer.querySelector('.host')?.childElementCount ?? 0) : null;
            const result = inited === '1' && children !== null && children > 0;
            if (!result)
                failure.first = { previewer, index, inited, children };
            return result;
        });
    try {
        const row = {
            timeOrigin: globalThis.performance.timeOrigin,
            pageMs: globalThis.performance.now(),
            dateNow: Date.now(),
            count: previews.length,
            ready,
            firstMissing: failure.first
                ? {
                    previewerId: failure.first.previewer.getAttribute('data-previewer-id'),
                    index: failure.first.index,
                    inited: failure.first.inited,
                    hostChildren: failure.first.children,
                }
                : null,
        };
        const key = JSON.stringify([row.count, row.ready, row.firstMissing]);
        const target = window;
        const journal = (target.__puiS4Startup ??= {
            samples: 0,
            changes: [],
            dropped: 0,
            lastKey: '',
            last: null,
        });
        journal.samples++;
        journal.last = row;
        if (key !== journal.lastKey) {
            journal.lastKey = key;
            if (journal.changes.length < 32)
                journal.changes.push(row);
            else
                journal.dropped++;
        }
    }
    catch {
        // Diagnostics cannot change the original readiness result.
    }
    return ready;
}
