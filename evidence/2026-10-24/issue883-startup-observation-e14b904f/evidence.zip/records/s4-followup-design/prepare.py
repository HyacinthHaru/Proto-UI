from pathlib import Path
import hashlib,json,difflib,datetime
D=Path(__file__).resolve().parent;P=D/'prepared';W=Path('<WORKTREE>');H='apps/www/src/content/docs/zh-cn/demo-matrix-observation.ts';C='apps/www/src/content/docs/zh-cn/demo-shadow-split-s4.browser.test.ts';helper=(W/H).read_text();caller=(W/C).read_text()
(P/'demo-matrix-observation.original.ts').write_text(helper);(P/'demo-shadow-split-s4.original.ts').write_text(caller)
old="""      if (journal.changes.length < 32) journal.changes.push(row);
      else journal.dropped++;"""
new="""      if (journal.changes.length < 32) {
        journal.changes.push(row);
        // Stream only the same bounded changes; the original last sample remains.
        console.info('[S4 startup change]', JSON.stringify(row));
      } else journal.dropped++;"""
assert helper.count(old)==1;h=helper.replace(old,new)
h+='''
/** Passive pre-navigation observation only; no whole-matrix scan or layout read. */
export function installS4InitJournal(): void {
  if (window.top !== window) return;
  const state = {
    deliveryCount: 0,
    observedRecords: 0,
    examinedRecords: 0,
    skippedBatchRecords: 0,
    ignoredTargets: 0,
    emitted: 0,
    droppedEmits: 0,
    observerErrors: 0,
    stoppedAtCap: false,
    last: null as Record<string, unknown> | null,
  };
  let observer: MutationObserver | null = null;
  const emit = (stage: string, facts: Record<string, unknown> = {}) => {
    try {
      if (state.emitted >= 128) {
        state.droppedEmits++;
        return;
      }
      state.emitted++;
      const row = {
        stage,
        ordinal: state.emitted,
        timeOrigin: globalThis.performance.timeOrigin,
        pageMs: globalThis.performance.now(),
        dateNow: Date.now(),
        readyState: document.readyState,
        ...facts,
      };
      state.last = row;
      console.info('[S4 init observation]', JSON.stringify(row));
      if (state.emitted === 128) {
        state.stoppedAtCap = true;
        observer?.disconnect();
      }
    } catch {
      state.observerErrors++;
    }
  };
  try {
    Object.defineProperty(window, '__puiS4InitJournal', {
      configurable: true,
      value: state,
    });
    observer = new MutationObserver((records) => {
      state.deliveryCount++;
      state.observedRecords += records.length;
      const count = Math.min(records.length, 8);
      state.skippedBatchRecords += records.length - count;
      for (let index = 0; index < count; index++) {
        try {
          state.examinedRecords++;
          const record = records[index]!;
          const target = record.target;
          if (!(target instanceof Element)) continue;
          const previewer = target.hasAttribute('data-previewer-id');
          const host = target.classList.contains('host');
          if (!previewer && !host) {
            state.ignoredTargets++;
            continue;
          }
          emit('mutation-delivery', {
            delivery: state.deliveryCount,
            batchIndex: index,
            batchSize: records.length,
            type: record.type,
            attribute: record.attributeName,
            targetTag: target.tagName,
            targetClass: target.getAttribute('class'),
            parentClass: target.parentElement?.getAttribute('class') ?? null,
            previewerId: target.getAttribute('data-previewer-id'),
            parentPreviewerId: target.parentElement?.getAttribute('data-previewer-id') ?? null,
            demoId: target.getAttribute('data-demo-id'),
            inited: target.getAttribute('data-inited'),
            mounting: target.getAttribute('data-mounting'),
            lazy: target.getAttribute('data-lazy'),
            lazyObserved: target.getAttribute('data-lazy-observed'),
            projectionState: target.getAttribute('data-projection-state'),
            hostChildren: host ? target.childElementCount : null,
          });
        } catch {
          state.observerErrors++;
        }
        if (state.stoppedAtCap) break;
      }
    });
    observer.observe(document, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['data-inited', 'data-mounting', 'data-lazy-observed', 'data-projection-state'],
    });
    document.addEventListener('DOMContentLoaded', () => emit('domcontentloaded'), { once: true });
    window.addEventListener('load', () => emit('load'), { once: true });
    emit('installed');
  } catch {
    state.observerErrors++;
    observer?.disconnect();
    emit('setup-unavailable');
  }
}
'''
# Only the test copy is changed. Original awaited calls remain syntactically intact.
c=caller.replace("import { observeS4Startup } from './demo-matrix-observation';","import { observeS4Startup, installS4InitJournal } from './demo-matrix-observation';")
needle="""      page.on('pageerror', (e) => errors.push(e.message));
      try {
        await page.goto(`${baseUrl}/${locale}/internal/demo-matrix/#shadow-split-s4`);"""
replacement="""      page.on('pageerror', (e) => errors.push(e.message));
      let phase = 'created';
      const note = (next: string, outcome: string) => {
        phase = next;
        try {
          console.info('[S4 node phase]', JSON.stringify({
            locale, phase, outcome,
            nodeMs: globalThis.performance.now(),
            nodeTimeOrigin: globalThis.performance.timeOrigin,
            dateNow: Date.now(),
          }));
        } catch { /* Diagnostic output cannot replace the original result. */ }
      };
      const browserObservation = (message: { text(): string }) => {
        try {
          const text = message.text();
          if (!text.startsWith('[S4 startup change]') && !text.startsWith('[S4 init observation]')) return;
          console.info('[S4 browser stream]', JSON.stringify({
            locale, phase, receivedNodeMs: globalThis.performance.now(), dateNow: Date.now(), text,
          }));
        } catch { /* Console delivery is optional diagnostic evidence. */ }
      };
      page.on('console', browserObservation);
      try {
        note('init-script', 'begin');
        try {
          const setup = await settleFamilyQueryBatch([page.addInitScript(installS4InitJournal)], 2000);
          note('init-script', setup.complete && setup.outcomes[0]?.status === 'fulfilled' ? 'return' : 'unavailable');
        } catch { note('init-script', 'error'); }
        note('goto', 'begin');
        try {
          await page.goto(`${baseUrl}/${locale}/internal/demo-matrix/#shadow-split-s4`);
          note('goto', 'return');
        } catch (error) {
          note('goto', 'error');
          throw error;
        }"""
assert c.count(needle)==1;c=c.replace(needle,replacement)
c=c.replace("""        let startupPassed = false;
        try {""","""        let startupPassed = false;
        note('startup-wait', 'begin');
        try {""")
c=c.replace("""        } finally {
          // Read the same predicate's journal only after its original verdict.""","""        } finally {
          note('startup-wait', startupPassed ? 'return' : 'error');
          // Read the same predicate's journal only after its original verdict.""")
c=c.replace("""[page.evaluate(() => (window as any).__puiS4Startup ?? null)],""","""[page.evaluate(() => ({
                startup: (window as any).__puiS4Startup ?? null,
                init: (window as any).__puiS4InitJournal ?? null,
              }))],""")
c=c.replace("""? result.outcomes[0].value
                : null;""","""? result.outcomes[0].value.startup
                : null;
            const initObservation = result.complete && result.outcomes[0]?.status === 'fulfilled'
              ? result.outcomes[0].value.init : null;""")
c=c.replace("""              observation,
            };""","""              observation,
              initObservation,
            };""")
c=c.replace("""        await runS4Journey(page);
        expect(errors).toEqual([]);
      } finally {
        await context.close();
      }""","""        note('journey', 'begin');
        try {
          await runS4Journey(page);
          note('journey', 'return');
        } catch (error) {
          note('journey', 'error');
          throw error;
        }
        expect(errors).toEqual([]);
      } finally {
        note('context-close', 'begin');
        try {
          await context.close();
          note('context-close', 'return');
        } catch (error) {
          note('context-close', 'error');
          throw error;
        } finally {
          try { page.off('console', browserObservation); } catch { /* diagnostic subscription only */ }
        }
      }""")
(P/'demo-matrix-observation.ts').write_text(h);(P/'demo-shadow-split-s4.browser.test.ts').write_text(c)
patch=''.join(difflib.unified_diff(helper.splitlines(True),h.splitlines(True),fromfile='a/'+H,tofile='b/'+H))+''.join(difflib.unified_diff(caller.splitlines(True),c.splitlines(True),fromfile='a/'+C,tofile='b/'+C));(P/'candidate.patch').write_text(patch)
rows=[]
for path,old,new in [(H,helper,h),(C,caller,c)]:rows.append({'path':path,'originalSHA256':hashlib.sha256(old.encode()).hexdigest(),'candidateSHA256':hashlib.sha256(new.encode()).hexdigest(),'originalBytes':len(old.encode()),'candidateBytes':len(new.encode()),'worktreeUnchanged':(W/path).read_text()==old})
(P/'binding.json').write_text(json.dumps({'preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'executed':False,'appliedToWorktree':False,'sources':rows,'candidatePatchSHA256':hashlib.sha256(patch.encode()).hexdigest(),'limits':['Node phases are caller observations, not actualdriver/browserreceipttimes.','addInitScript adds one bounded2s pre-goto setupwait andprotocol command; no earlySDKcontext/selector acquisition.','MO observes platform-delivered records, handlesfirst8perdelivery andatmost128emits; skipped/cappedfutureevents areunknown, notzerochanges.','MO reads only record.target anddirectparentattributes/childElementCount; noquerySelector/closest/layout.','Samecallbackstartupstream emitsfirst32changes; global last remainsretrievableonlyifpostverdictRPCresponds.','Console transportarrival isnotbrowsermutationtime; logging/MO/setup addnonzeroCPU/IPC costs.','NoCPUProfiler existingcollector autoenabled.','No test/browser run orsourceapplication performed.']},indent=2)+'\n')
print(json.dumps(rows))
