// @vitest-environment node
import { execFileSync } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import type { Browser } from 'playwright-core';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { launchBrowser, startServer, stopServer } from './browser-harness';
import { observeS4Startup, installS4InitJournal } from './demo-matrix-observation';
import { settleFamilyQueryBatch } from './family-query-observer';
import { runS4Journey } from '../../../../../../scripts/analysis/shadow-s4-journey.mjs';
let browser: Browser;
let baseUrl: string;
beforeAll(async () => {
  baseUrl = await startServer('/zh-cn/internal/demo-matrix/');
  browser = await launchBrowser();
}, 150_000);
afterAll(async () => {
  await browser?.close();
  await stopServer();
}, 60_000);
describe.sequential('S4 complete public Dialog settings', () => {
  for (const locale of ['zh-cn', 'en'])
    it(`${locale}: native Light/split/mixed acceptance`, async () => {
      const context = await browser.newContext({
        viewport: { width: 1440, height: 1000 },
        colorScheme: 'light',
      });
      const page = await context.newPage();
      const errors: string[] = [];
      page.on('pageerror', (e) => errors.push(e.message));
      let phase = 'created';
      const note = (next: string, outcome: string) => {
        phase = next;
        try {
          console.info('[S4 node phase]', JSON.stringify({
            locale, phase, outcome,
            nodeMs: globalThis.performance.now(),
            nodeTimeOrigin: globalThis.performance.timeOrigin,
            dateNow: Date.now(),
          }));
        } catch { /* Diagnostic output cannot replace the original result. */ }
      };
      const browserObservation = (message: { text(): string }) => {
        try {
          const text = message.text();
          if (!text.startsWith('[S4 startup change]') && !text.startsWith('[S4 init observation]')) return;
          console.info('[S4 browser stream]', JSON.stringify({
            locale, phase, receivedNodeMs: globalThis.performance.now(), dateNow: Date.now(), text,
          }));
        } catch { /* Console delivery is optional diagnostic evidence. */ }
      };
      page.on('console', browserObservation);
      try {
        note('init-script', 'begin');
        try {
          const setup = await settleFamilyQueryBatch([page.addInitScript(installS4InitJournal)], 2000);
          note('init-script', setup.complete && setup.outcomes[0]?.status === 'fulfilled' ? 'return' : 'unavailable');
        } catch { note('init-script', 'error'); }
        note('goto', 'begin');
        try {
          await page.goto(`${baseUrl}/${locale}/internal/demo-matrix/#shadow-split-s4`);
          note('goto', 'return');
        } catch (error) {
          note('goto', 'error');
          throw error;
        }
        let startupPassed = false;
        note('startup-wait', 'begin');
        try {
          await page.waitForFunction(observeS4Startup, undefined, { timeout: 60_000 });
          startupPassed = true;
        } finally {
          note('startup-wait', startupPassed ? 'return' : 'error');
          // Read the same predicate's journal only after its original verdict.
          // A late or unavailable snapshot never replaces that verdict.
          try {
            const result = await settleFamilyQueryBatch(
              [page.evaluate(() => ({
                startup: (window as any).__puiS4Startup ?? null,
                init: (window as any).__puiS4InitJournal ?? null,
              }))],
              2000
            );
            const observation =
              result.complete && result.outcomes[0]?.status === 'fulfilled'
                ? result.outcomes[0].value.startup
                : null;
            const initObservation = result.complete && result.outcomes[0]?.status === 'fulfilled'
              ? result.outcomes[0].value.init : null;
            const evidence = {
              source: {
                sha: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
                dirty: !!execFileSync('git', ['status', '--porcelain'], {
                  encoding: 'utf8',
                }).trim(),
              },
              locale,
              startupPassed,
              errors: [...errors],
              capturedAt: new Date().toISOString(),
              collectionComplete: result.complete,
              observation,
              initObservation,
            };
            console.log('[S4 startup predicate]', JSON.stringify(evidence));
            const directory = path.join(
              process.env.PROTO_UI_RUNTIME_EVIDENCE_DIR ??
                path.join(process.env.RUNNER_TEMP ?? os.tmpdir(), 'homepage-evidence'),
              's4-startup'
            );
            await settleFamilyQueryBatch(
              [
                mkdir(directory, { recursive: true }).then(() =>
                  writeFile(
                    path.join(directory, `${locale}.json`),
                    JSON.stringify(evidence, null, 2)
                  )
                ),
              ],
              2000
            );
          } catch {
            // Missing diagnostics are evidence debt, not a replacement failure.
          }
        }
        page.on('framenavigated', (f) => {
          if (f === page.mainFrame()) errors.push(`Unexpected navigation: ${f.url()}`);
        });
        note('journey', 'begin');
        try {
          await runS4Journey(page);
          note('journey', 'return');
        } catch (error) {
          note('journey', 'error');
          throw error;
        }
        expect(errors).toEqual([]);
      } finally {
        note('context-close', 'begin');
        try {
          await context.close();
          note('context-close', 'return');
        } catch (error) {
          note('context-close', 'error');
          throw error;
        } finally {
          try { page.off('console', browserObservation); } catch { /* diagnostic subscription only */ }
        }
      }
    }, 150_000);
});
