import { it, expect, onTestFinished } from 'vitest';
let open = false, closes = 0;
it('original case still times out', async () => {
  open = true;
  let closing: Promise<void> | undefined;
  const close = () => closing ??= Promise.resolve().then(() => { open = false; closes++; });
  
  try { await new Promise<void>(() => {}); }
  finally { await close(); }
}, 10);
it('next case has no previous owned context', () => {
  expect(open).toBe(false);
  expect(closes).toBe(1);
});
