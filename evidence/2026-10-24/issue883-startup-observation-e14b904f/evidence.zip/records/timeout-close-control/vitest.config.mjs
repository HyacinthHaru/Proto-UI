export default { test: { environment: 'node', include: ['*.test.ts'], maxWorkers: 1, minWorkers: 1 } };
