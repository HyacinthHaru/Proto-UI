# Exact 8afe official Field failure: bounded timing analysis

**这轮失败不是“deadline 前业务 callback 尚未结束”。** 在准确 `8afe6628df8639418b12c4207c4c6dd1bf48a2d3` / tree `5720ba41fc4c88d536620cedee7f8fce2dd4f629` 的官方 Field run [38591514564](https://github.com/Proto-UI/Proto-UI/actions/runs/38591514564)、job 115947316858 中，25 cases 实际为 **24 pass / 1 fail**。唯一失败是 Liquid Glass / Vue 的原 `Checking → Available` 1000 ms poll。后续 Node 观测明确看到 getter 返回 `Available`，但已晚于原失败记录；原断言仍然失败。

本报告为 human-assisted/current-user、partial / ABSTAIN，只读分析已有数据；未跑测试、浏览器或 build，未改产品、timeout、assertion、依赖或 workflow，未写 GitHub。源码只用固定 Git object 读取；没有把新 P2/FIFO 等其他问题混入这次 Field 因果。

原始 artifact **11908975084** 已含 91 个 ZIP members，28,903,563 bytes，实核 SHA256 `169c60204df0deb0d4e59e6ac534d76854144a14280dc6265dfc127485524c09`。before/after source 均为 clean 8afe；当时真实环境为 Linux x64、Node 24.21.0、Chrome 154.0.8037.97。三 Liquid 框架的 opt-in trace 同轮实际开启，诊断错误数组均空。原始 trace 已在官方 Actions artifact 中；本报告不复制、上传或重新发布 trace/ZIP。

原始 Node / trace / sidecar / log 的 SHA256、大小和相对路径、相关 Git blob/SHA256 及全部计算值保存在 [timing-summary.json](timing-summary.json)。只包含有界派生内容的 [vue-completed-events.json](vue-completed-events.json) 列出 Vue timer install→fire 窗口中同一 renderer thread 的全部 742 个完成型 `ph=X` 事件；保留原 trace event index、时间、duration、裁剪重叠和规范化 source/stack。它不是完整 trace，也不包含机器 URL 前缀。

## 原断言、callback 和 getter 的不同时间点

原测试在 [demo-field-family.browser.test.ts:244](https://github.com/Proto-UI/Proto-UI/blob/8afe6628df8639418b12c4207c4c6dd1bf48a2d3/apps/www/src/content/docs/zh-cn/demo-field-family.browser.test.ts#L244) 启动 trace，按原顺序填 `taken`、等待 busy、填 `newer`，再 poll 原 `asyncStatus.textContent()`，没有扩大 1000 ms 或改变 predicate。观测器 [field-async-observation.ts:59](https://github.com/Proto-UI/Proto-UI/blob/8afe6628df8639418b12c4207c4c6dd1bf48a2d3/apps/www/src/content/docs/zh-cn/field-async-observation.ts#L59) 直接返回原 promise，仅旁支记录 settlement；原 catch 首先同步 `markFailure`，再执行失败图片/sidecar。

Vue Node monotonic timestamps（ms）：

| 观察 | 时间 / 相对首 getter |
| --- | --- |
| Getter 1 开始 | 206447.282778 / 0 |
| Getter 1–3 结果 | 全部 `Checking`；耗时 238.334、184.382、174.770 ms |
| Getter 4 开始 | 207196.445382 / +749.162604 ms |
| 原失败记录 | 207447.838568 / **+1000.555790 ms**；getter 4 仍 pending |
| Getter 4 settlement | 207496.374510 / **+1049.091732 ms**；值 `Available` |
| settlement 晚于失败记录 | **48.535942 ms** |

没有独立记录 Vitest 内部 poll timer 的起点，因此“首 getter + 1000 ms”只能作参考，不能伪称精确内部 deadline。上表失败时点来自原 catch 的同步记录。

`check` 栈中的第二个真实 500 ms timer，按 **pid=4732 / tid=4732 / frame=93B3F0397D22FF1921E96DCC484568B8 / timerId=12** 唯一联配。其 install→fire 为 **1004.226 ms**，比名义 500 ms 晚 **504.226 ms**。它的 `TimerFire` 整段 13.602 ms 跨越失败记录，但内部唯一 `field-demo.shared.ts` callback 的 `FunctionCall` 只有 **1.924 ms**：

- `TimerFire` 开始在失败记录前 **8.820–9.547 ms**，结束在失败记录后 **4.055–4.782 ms**。
- **业务 callback 自身在失败记录前 6.878–7.605 ms 已结束。** 不能把外层 `TimerFire` 仍未结束描述成业务 callback 尚未完成。
- Node getter 仍要到 callback 结束后 **55.414–56.141 ms** 才记录 `Available`。这是 getter promise 响应/settlement 的实际晚到；没有独立 protocol-wire timestamp，不能把这整段直接归为传输耗时或服务器等待。

上述跨进程换算使用两次真实 `clock_sync` 的 Node before/after 区间。Vue 两端可兼容的 constant-offset 交集宽 **0.727314 ms**；React 为 0.611479 ms，Vue2 为 0.566433 ms。这个模型假定采样期间两种 monotonic clock 的 offset 固定；没有独立 drift bound。timer 的 install→fire 差、同线程事件占时无需跨时钟假定。完整 markers、交集和较宽 endpoint envelope 都保留在 JSON。

业务源码 [field-demo.shared.ts:126](https://github.com/Proto-UI/Proto-UI/blob/8afe6628df8639418b12c4207c4c6dd1bf48a2d3/apps/www/src/content/docs/field-demo.shared.ts#L126) 的 callback 同步调用 `resolveValidation`，并在 currentRequest 相等且 accepted 时把状态写成 `Available`。最终结果与此 current/accepted 分支一致；trace 没有请求 ID、resolve 返回值或精确 DOM text-write timestamp，所以这里不扩张为每条 lease 都已逐项实测。trace 的 emitted line106 也没有冒充原 TypeScript line130；未保留 emitted-source/map 的逐字绑定。

## 延期区间里实际可见的工作

三个 trace 都没有 `RunTask` 事件。四个配置项是 `-*`、`devtools.timeline`、`disabled-by-default-devtools.timeline.stack` 和 `blink.user_timing`；缺 `RunTask` 是采集边界，不能证明 renderer 空闲。

不过已有完成型事件足够指出具体关联。Vue 第二个 timer 的 nominal due→fire 区间长 **504.226 ms**，同一 `CrRendererMain` 的完成型 X 事件时间并集覆盖 **489.360 ms**；`FunctionCall` 并集为 **483.609 ms**。其中两段 `tick` 明确属于 [preview-material-scene.ts:121](https://github.com/Proto-UI/Proto-UI/blob/8afe6628df8639418b12c4207c4c6dd1bf48a2d3/apps/www/src/components/PrototypePreviewer/preview-material-scene.ts#L121)：

| 事件 | 完整 duration | 与 due→fire 区间重叠 |
| --- | ---: | ---: |
| tick，ts=324104506 μs | 206.488 ms | 202.850 ms |
| tick，ts=324329049 μs | 279.281 ms | 279.281 ms |
| 两段 tick 时间并集 | — | **482.131 ms** |

两段分别嵌在 207.799 / 280.675 ms 的 `FireAnimationFrame` 中。**父/子、GC、layout 等重叠 duration 没有相加**；每类和全部事件都按区间裁剪后求并集。due→fire 内可见 UpdateLayoutTree 并集 3.898 ms、Paint 1.218 ms、Layerize 0.254 ms；Layout 0 ms，EvaluateScript 没有该窗口内完成型记录。GC 事件嵌在上述区间内，不得再当独立可加“成本”。这些是包含式 wall intervals，不是 CPU self time。

同轮阳性控制也有相同 scene tick 和延期，但其 getter 尚能在原 poll deadline 前返回：

| 同一官方 run | 第二个 500 ms timer install→fire | due→fire 中 scene tick 并集 | 第 4 getter 耗时 | 首 getter→Available settlement |
| --- | ---: | ---: | ---: | ---: |
| React，journey pass | 918.951 ms | 397.073 ms | 174.169 ms | 911.561 ms |
| Vue，journey fail | 1004.226 ms | 482.131 ms | 299.929 ms | 1049.092 ms |
| Vue2，journey pass | 927.603 ms | 405.245 ms | 177.426 ms | 922.935 ms |

Vue 的第四段 scene tick 为 279.281 ms，其他两个对应为 203.754 / 207.728 ms。这是这轮 trace 的实际时序和 source 关联，不证明 Vue 框架缺陷、某个 material 算法根因、CPU 单点成本或前几轮红项的原因。

## 失败图片和后续边界

已通过 `view_image` 查看原 [失败 PNG](../ci/field-artifact/extracted/screenshots/8afe6628df86-liquid-glass-vue-failure.png)，672×1444，原字节 SHA 和 sidecar SHA 见 [visual-review.json](visual-review.json)。Vue tab 被选中，async input 是 `newer`，`Available · 可用` 可见；白色固定网站 header 遮住部分 async editor/label，canvas 背景文字与 labels/help 竞争。

sidecar 的 `checkedAt=2026-10-14T15:51:33.298Z` 比 Node 失败记录换算时点约晚 **5615.835 ms**，而且该时间在 screenshot 已完成后才赋值，不是精确快门时点。它证明晚时点可见结果，不能用来宣称 1000 ms 内通过。原 capture helper 自带隐藏 astro-dev-toolbar 的 screenshot style；本分析没有编辑图像、补拍或增加截图样式。不构成完整视觉、对比度或 AT 接受。

最小下一步是把已有的 **preview scene / material 同步工作与协议 getter deadline** 关联送到其 owning path：`tick → draw → CanvasBackdropLease.draw`，包括 draw 内 canvas/readback 与 synchronous source listeners。源码 [source.ts:49](https://github.com/Proto-UI/Proto-UI/blob/8afe6628df8639418b12c4207c4c6dd1bf48a2d3/packages/adapters/base/src/material/source.ts#L49) 的 `draw` 在 finally 通知 listeners，因此不能把 tick 的全部 wall time直接归给 canvas fill。当前 trace 未把这些成本与 tracing、GC、主机调度、Node/CDP 响应处理分开；后续若获准采样，应保留原 25 cases、输入、predicate 和 500/1000 ms，仅有界补足 scheduler/CPU 或具体 callback 内耗时来源。

本次不提出 C source 修复，不扩大 1000 ms / 500 ms，不放松 assertion，不增加诊断 commit，不重跑。此次已证明“原 deadline 真实失败、业务 callback 已执行结束、Node getter 晚到、同 renderer 的 scene tick 有大段重叠”；更细的原因与适用 owner 仍需按该证据继续判断，旧红不因此被解释或消除。
