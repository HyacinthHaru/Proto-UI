a404→9cafed4a 的只读有界审查完成，0 个具体新增 C finding；partial / ABSTAIN，不是上游或全 Finf 接受。

准确范围只有一个提交、16路径。与be6自身17路径、21dd含capture诊断18路径、旧C35路径都没有交集；Runtime/Modules/Adapters/Base整子树逐字不变。pendingmerge由root执行，审查只读固定Git对象。21dd仍是已签名本地提交，remote在任务分派时为be6；前置检查因新foundation停止不是push失败或unknown。

实质影响是Shadcn Item/Label视觉配方、共享生成preset、公开inset Demo以及原16-case native oracle。新配方使用完整且互斥的pl-2/pr-2或pl-8/pr-2，避免水平shorthand与left重叠；没有改Base所有权或generic CSS算法。已读取固定NewYork上游文件，Item/Label确有物理left pl-8，未用logical-start或RTL反转。来源：[固定New York源码](https://github.com/shadcn-ui/ui/blob/02cad61166c4c20edbc8a3f71bd720eed4c1f49b/apps/v4/registry/new-york-v4/ui/dropdown-menu.tsx)。这只是源对齐，不是pixel/native接受。

建议保留root计划的C67/fulltypes，并加真实相关5套：dropdown、dropdown-label、dropdown-destructive、dropdown-style-closure、finf-dropdown-recipe-evidence；同时核preset生成、changed-spec authoring和原public-docs71范围。未改的destructive测试仍有必要，因为同一个Item视觉源变化；document/Shadow closure覆盖生成CSS。P/T维持draft，native implementation仍planned。

新的LiquidWC单journey只能证明capture和该次基础组合，不能替代Actions-only Dropdown16矩阵、新LTR/RTL物理left/right与true-false-true动态观测，也不能宣称原8个inset红已关闭。未运行任何新验证。CLI旧bg-muted两期待与GPUI tracked stylefixture未在本增量修正；不要因生成preset变化把它们写成已修。上游记录中的20/71、本地catalog/graph对照与未来新组合结果应按各自实际来源保留。
