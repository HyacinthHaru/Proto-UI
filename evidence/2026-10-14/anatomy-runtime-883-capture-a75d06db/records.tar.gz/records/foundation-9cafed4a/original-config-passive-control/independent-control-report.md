唯一一次授权的原配置被动fixture控制已结束并恢复，结果20/20pass，未取得红现场；partial / ABSTAIN。

执行为准确a75，2026-10-14T17:20:37.896025–17:20:40.040870UTC，原五files/worker2/1/原vitest.config。只临时修改dropdown-destructive.test.ts中原t78 predicate：每次唯一一次调用原styleContains，记录最多32项同步内存字段后原样返回；1000ms/defaultpoll/toBe(true)与原错误重抛保留。没有新await、DOM写、focus、update、observer或重试。实际worker为Nodev24.21.0、pid81274、worker/pool1。

只有两个样本：首次html.class空、data-theme null、MQLfalse，subject connected/同doc/focused/active均true，原predicate false且还为bg-destructive/20。52.250792ms后第二次原predicate true，主题和焦点事实相同，token已变bg-destructive/10。此处观察到一次正常异步投射，不解释原两次超过1000ms的19/1。没有采产品sourcecallback/RuleMeta内部事件，不将其称直接因果轨迹。

finally恢复原testSHA02c85329aec43b065eedbf74ee8dc8e61515a9d614a8007af1a93e013a291906；HEAD仍a75，status空；index前后SHA45112457ebdc130c3dde32b05761ca4f5001c4c5d98da6bdc8b211c20933f4ca完全相同，原config也相同。执行诊断bytes、最小patch、两样本、完整rawlog及receipt均保存。

新字段读取/MQL对象/内存记录仍有观测开销。未证明Overlay根因、上游继承问题或测试flake，也没有修产品、重标旧失败或再次运行。root可在保留全部红/绿来源的前提下决定后续最小观察。
