有界私有 Overlay 对照终态：candidate20/20，准确9cf Overlay替换臂20/20，均同原五套/两worker/1秒断言，只各跑一次。未复现原红，不认定Overlay是原因，也不抹掉原candidate两轮19/1和原单套5/5。

实际404个Vite pre-transform仓库输入全部绑定准确a75 Git；两臂仅Overlayimpl一项不同，另外403项和路径集合相同。FieldRoot、ToggleRoot、Calendarcaption源没有加载，因此本轮不能归因于其setup。所有产品source与原测试/断言/timeout不变，前后a75 clean。原测试引用的styleContains只看data-pui-style，不是像素。

私有config继承原配置并保持原测试路径/alias/root，只加精确Overlay替换与输入记录。两臂额外出现同一ViteCJS deprecation提示，记录插件有同步写盘开销，文件完成顺序也不同于原红；所以不能称这是完全无扰动的原配置复现。launcher指定Node24.21.0/pnpm10.32.1、log明确Vitest2.1.9；没有在worker中采process.version/pid/execPath，不能虚构actualworker身份实测。

静态owner链是DropdownContent.asOverlay(portal)及Item meta(colorScheme)→default/rebindable document source→MutationObserver/microtask→RuleMeta mounted lease→Rule/Feedback reevaluation。这些主题源、RuleMeta、Rule源码在9cf/a75完全相同；Overlay是唯一加载的C差异，确有间接影响portal/view生命周期的可能，但实际配对未证明。C-RULE-COLOR-SCHEME-0001 draft的A/C/D/E/F/H/L要求同文档域中的源、租约与当前surface一致；现有false token不证明具体哪一环违反，也不能直接归为继承/外组。

若再获准，最小下一步是原五套同path/config、原poll失败后只读采并原error重抛：root class/data-theme/MQL；subject/content/root连接与ownerDocument/portal位置；activeElement及公开focused/active等状态；原data-pui-style、rootopen；workeridentity/time。不主动focus/remount/update，不增加timeout。有效主题仍dark、对象/focus变化、或同对象light但darktokens残留，是三条不同分流，先捕获再决定是否继续观察source通知/RuleMeta租约。此后没有自行加跑，也没有产品或外部写入。

结论为human-assisted/current-user、unassessed、partial / ABSTAIN。无已证实的新sourcefinding；原同组合五套失败仍是未消除的验证欠账。
