import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import original from '<SOURCE_ROOT>/vitest.config.ts';
const productRoot = '<SOURCE_ROOT>';
const controlRoot = '<TASK_STATE>/foundation-9cafed4a/independent-overlay-isolation';
const variant = process.env.PUI_REVIEW_OVERLAY_VARIANT;
if (variant !== 'candidate' && variant !== 'upstream') throw new Error('An exact private variant is required');
const replacement = fs.readFileSync(path.join(controlRoot, `${variant}-overlay.impl.ts`), 'utf8');
const rows = new Map<string, unknown>();
const save = () => fs.writeFileSync(path.join(controlRoot, `${variant}-loaded-inputs.json`), JSON.stringify([...rows.values()], null, 2) + '\n');
const hash = (value: string) => crypto.createHash('sha256').update(value).digest('hex');
export default {
  ...original,
  root: productRoot,
  plugins: [...original.plugins, {
    name: 'private-exact-overlay-source-control',
    enforce: 'pre',
    load(id: string) {
      if (id.split('?')[0] === path.join(productRoot, 'packages/modules/overlay/src/impl.ts')) return replacement;
      return null;
    },
    transform(code: string, id: string) {
      const file = id.split('?')[0];
      if (file.startsWith(productRoot + '/') && !file.includes('/node_modules/') && fs.existsSync(file) && fs.statSync(file).isFile()) {
        const relative = path.relative(productRoot, file);
        rows.set(relative, { path: relative, sha256: hash(code), bytes: Buffer.byteLength(code), representation: 'Vite pre-transform input', overlayOverride: relative === 'packages/modules/overlay/src/impl.ts', onDiskSha256: hash(fs.readFileSync(file, 'utf8')) });
        save();
      }
      return null;
    }
  }]
};
