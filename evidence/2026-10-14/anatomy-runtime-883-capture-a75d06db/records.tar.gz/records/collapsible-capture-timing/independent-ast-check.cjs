const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ts = require('<SOURCE_ROOT>/node_modules/typescript');
const root = '<TASK_STATE>/collapsible-capture-timing';
const sourcePath = '<SOURCE_ROOT>/apps/www/src/content/docs/zh-cn/demo-collapsible-projections.browser.test.ts';
const original = fs.readFileSync(path.join(root, 'original.browser.test.ts'), 'utf8');
const candidate = fs.readFileSync(sourcePath, 'utf8');
const parse = (x) => ts.createSourceFile('source.ts', x, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
const old = parse(original), current = parse(candidate);
const removed = [];
const ranges = [];
const transform = ts.transform(current, [(context) => {
 const visit = (node) => {
  if (ts.isFunctionDeclaration(node) && node.name?.text === 'capture') {
   const keep = node.body.statements.filter((statement) => {
    let kind, detail;
    if (ts.isVariableStatement(statement) && statement.declarationList.declarations.length === 1) {
     const declaration = statement.declarationList.declarations[0];
     if (ts.isIdentifier(declaration.name) && ['captureStartedAt','captureStage'].includes(declaration.name.text)) {kind='diagnostic-variable';detail=declaration.name.text;}
    }
    if (ts.isExpressionStatement(statement) && ts.isCallExpression(statement.expression) && ts.isIdentifier(statement.expression.expression) && statement.expression.expression.text === 'captureStage') {
     kind='diagnostic-call';detail=statement.expression.arguments.map((x)=>x.getText(current));
    }
    if (!kind) return true;
    removed.push({kind,detail,line:current.getLineAndCharacterOfPosition(statement.getStart(current)).line+1});
    ranges.push([statement.getFullStart(),statement.getEnd()]); return false;
   });
   return ts.factory.updateFunctionDeclaration(node,node.modifiers,node.asteriskToken,node.name,node.typeParameters,node.parameters,node.type,ts.factory.updateBlock(node.body,keep));
  }
  return ts.visitEachChild(node,visit,context);
 };
 return (node)=>ts.visitNode(node,visit);
}]);
const stripped = transform.transformed[0];
const printer=ts.createPrinter({removeComments:true,newLine:ts.NewLineKind.LineFeed});
const oldPrinted=printer.printFile(old),newPrinted=printer.printFile(stripped);
let strippedText=candidate;
for(const [start,end] of ranges.sort((a,b)=>b[0]-a[0]))strippedText=strippedText.slice(0,start)+strippedText.slice(end);
const inventory=(ast)=>{
 const out={awaitCount:0,calls:{},numericLiterals:[]};
 function walk(n){if(ts.isAwaitExpression(n))out.awaitCount++;if(ts.isCallExpression(n)){const k=n.expression.getText(ast);out.calls[k]=(out.calls[k]??0)+1;}if(ts.isNumericLiteral(n))out.numericLiterals.push(n.text);ts.forEachChild(n,walk);}walk(ast);return out;
};
const sha=(x)=>crypto.createHash('sha256').update(x).digest('hex');
const result={kind:'read-only-typescript-ast-comparison',node:process.version,typescript:ts.version,originalSHA256:sha(original),candidateSHA256:sha(candidate),parseDiagnostics:{original:old.parseDiagnostics.length,candidate:current.parseDiagnostics.length},removed,removedCount:removed.length,originalPrintedASTSHA256:sha(oldPrinted),strippedCandidatePrintedASTSHA256:sha(newPrinted),printedASTEqual:oldPrinted===newPrinted,diagnosticStrippedTextByteEqual:original===strippedText,originalInventory:inventory(old),candidateInventory:inventory(current),sourceFile:sourcePath};
fs.writeFileSync(path.join(root,'independent-ast-comparison.json'),JSON.stringify(result,null,2)+'\n');
fs.writeFileSync(path.join(root,'independent-reviewed.browser.test.ts'),candidate);
console.log(JSON.stringify({node:result.node,typescript:result.typescript,parseDiagnostics:result.parseDiagnostics,removed:result.removed,printedASTEqual:result.printedASTEqual,diagnosticStrippedTextByteEqual:result.diagnosticStrippedTextByteEqual,awaitOriginal:result.originalInventory.awaitCount,awaitCandidate:result.candidateInventory.awaitCount,sourceSHA256:result.candidateSHA256,normalizedSHA256:result.originalPrintedASTSHA256},null,2));
transform.dispose();
