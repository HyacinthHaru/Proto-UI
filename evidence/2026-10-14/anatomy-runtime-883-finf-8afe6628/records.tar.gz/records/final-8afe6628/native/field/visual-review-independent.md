准确8afe新field视觉/来源审阅完成，local **partial / ABSTAIN**。本次实际逐张查看40张新PNG，不复用c82/6d/58d图片或时间。

真实run：2026-10-14T15:37:29.138196+00:00 至 2026-10-14T15:39:24.799141+00:00，25 tests passed、exit0，clean `8afe6628df8639418b12c4207c4c6dd1bf48a2d3` / tree `5720ba41fc4c88d536620cedee7f8fce2dd4f629`，Node24.21.0 / pnpm10.32.1 / macOSarm64 / Chrome155.0.8059.40，max1/min1，无私有override/asyncTRACE。源中已提交的诊断仍保留，不能称从未instrumented的历史原文件。

All20light captures include a fixed-site-header band obscuring part of the Field editing surface.
BaseVue2dark has middle occlusion; BaseReact/Vue/WCdark have top occlusion in these new images. Other narrow families show strong right clipping and some cancel text overflow.
Liquid background words compete with text; WC and framework input paint visibly differ. Cause/contrast/material conformance unassessed.
390px viewport + rootfont32px is authored font enlargement, not OS/browser200%zoom or AT.
Images are element captures, not entire pages. Long image display is rescaled; no full-resolution pixel measurement claim.

每张名称、SHA、sidecar、head、真实时间限界和观测见JSON。Field有checkedAt；Collapsible无逐图UTC，明确使用runwindow与文件mtime（非伪造capture时间）。没有AT/全视觉/全CI批准。

| 图名 | 新图实际观察 |
| --- | --- |
| `8afe6628df86-base-react-dark-narrow-200.png` | 深色窄卡片，固定页头遮住顶部Runtime/账户标签；Ada/taken、Canceled、owner错误提示及底部长帮助文本可见，长输入值截短。 |
| `8afe6628df86-base-react-light.png` | 当前Runtime下划线可见；Ada/Canceled/owner错误、readonly与disabled以及长文可读。宽白色页头横带遮住Validate/Reset下部和Availability编辑区，不能评估被遮盖处。 |
| `8afe6628df86-base-vue-dark-narrow-200.png` | 深色窄卡片，固定页头遮住顶部Runtime/账户标签；Ada/taken、Canceled、owner错误提示及底部长帮助文本可见，长输入值截短。 |
| `8afe6628df86-base-vue-light.png` | 当前Runtime下划线可见；Ada/Canceled/owner错误、readonly与disabled以及长文可读。宽白色页头横带遮住Validate/Reset下部和Availability编辑区，不能评估被遮盖处。 |
| `8afe6628df86-base-vue2-dark-narrow-200.png` | 深色窄卡片中Ada/taken及长帮助文本多行可见；固定页头横带实际位于中部，遮住Canceled/owner部分；长输入值截短。 |
| `8afe6628df86-base-vue2-light.png` | 当前Runtime下划线可见；Ada/Canceled/owner错误、readonly与disabled以及长文可读。宽白色页头横带遮住Validate/Reset下部和Availability编辑区，不能评估被遮盖处。 |
| `8afe6628df86-base-wc-dark-narrow-200.png` | 深色窄卡片，固定页头遮住顶部Runtime/账户标签；Ada/taken、Canceled、owner错误提示及底部长帮助文本可见，长输入值截短。 |
| `8afe6628df86-base-wc-light.png` | 当前Runtime下划线可见；Ada/Canceled/owner错误、readonly与disabled以及长文可读。宽白色页头横带遮住Validate/Reset下部和Availability编辑区，不能评估被遮盖处。 |
| `8afe6628df86-bootstrap-2-3-2-react-dark-narrow-200.png` | 暗色外层下的白色Bootstrap卡片，右侧裁切贯穿标签、输入、按钮和长文；Canceled及部分红色错误可见。窄图不能证明完整内容可读。 |
| `8afe6628df86-bootstrap-2-3-2-react-light.png` | 当前Runtime选中，灰按钮、Ada/taken/Canceled、红色owner错误及灰化disabled可见；固定白色页头遮住上部帮助和操作区，下部长标签/帮助在宽图换行。 |
| `8afe6628df86-bootstrap-2-3-2-vue-dark-narrow-200.png` | 暗色外层下的白色Bootstrap卡片，右侧裁切贯穿标签、输入、按钮和长文；Canceled及部分红色错误可见。窄图不能证明完整内容可读。 |
| `8afe6628df86-bootstrap-2-3-2-vue-light.png` | 当前Runtime选中，灰按钮、Ada/taken/Canceled、红色owner错误及灰化disabled可见；固定白色页头遮住上部帮助和操作区，下部长标签/帮助在宽图换行。 |
| `8afe6628df86-bootstrap-2-3-2-vue2-dark-narrow-200.png` | 暗色外层下的白色Bootstrap卡片，右侧裁切贯穿标签、输入、按钮和长文；Canceled及部分红色错误可见。窄图不能证明完整内容可读。 |
| `8afe6628df86-bootstrap-2-3-2-vue2-light.png` | 当前Runtime选中，灰按钮、Ada/taken/Canceled、红色owner错误及灰化disabled可见；固定白色页头遮住上部帮助和操作区，下部长标签/帮助在宽图换行。 |
| `8afe6628df86-bootstrap-2-3-2-wc-dark-narrow-200.png` | 暗色外层下的白色Bootstrap卡片，右侧裁切贯穿标签、输入、按钮和长文；Canceled及部分红色错误可见。窄图不能证明完整内容可读。 |
| `8afe6628df86-bootstrap-2-3-2-wc-light.png` | 当前Runtime选中，灰按钮、Ada/taken/Canceled、红色owner错误及灰化disabled可见；固定白色页头遮住上部帮助和操作区，下部长标签/帮助在宽图换行。 |
| `8afe6628df86-brutalist-react-dark-narrow-200.png` | 深色硬边框、蓝按钮；右边界截断多数标签/控件/长文，Cancel文字向按钮左侧溢出。Ada/taken与部分错误状态可见，完整窄屏布局不成立于这张图。 |
| `8afe6628df86-brutalist-react-light.png` | 蓝底黑边框、蓝按钮，Ada/taken/Canceled和红色owner错误可读；Whitepaper/搜索页头横带遮住Validate/Reset/Availability区。readonly/disabled与底部长文可见。 |
| `8afe6628df86-brutalist-vue-dark-narrow-200.png` | 深色硬边框、蓝按钮；右边界截断多数标签/控件/长文，Cancel文字向按钮左侧溢出。Ada/taken与部分错误状态可见，完整窄屏布局不成立于这张图。 |
| `8afe6628df86-brutalist-vue-light.png` | 蓝底黑边框、蓝按钮，Ada/taken/Canceled和红色owner错误可读；Whitepaper/搜索页头横带遮住Validate/Reset/Availability区。readonly/disabled与底部长文可见。 |
| `8afe6628df86-brutalist-vue2-dark-narrow-200.png` | 深色硬边框、蓝按钮；右边界截断多数标签/控件/长文，Cancel文字向按钮左侧溢出。Ada/taken与部分错误状态可见，完整窄屏布局不成立于这张图。 |
| `8afe6628df86-brutalist-vue2-light.png` | 蓝底黑边框、蓝按钮，Ada/taken/Canceled和红色owner错误可读；Whitepaper/搜索页头横带遮住Validate/Reset/Availability区。readonly/disabled与底部长文可见。 |
| `8afe6628df86-brutalist-wc-dark-narrow-200.png` | 深色硬边框、蓝按钮；右边界截断多数标签/控件/长文，Cancel文字向按钮左侧溢出。Ada/taken与部分错误状态可见，完整窄屏布局不成立于这张图。 |
| `8afe6628df86-brutalist-wc-light.png` | 蓝底黑边框、蓝按钮，Ada/taken/Canceled和红色owner错误可读；Whitepaper/搜索页头横带遮住Validate/Reset/Availability区。readonly/disabled与底部长文可见。 |
| `8afe6628df86-liquid-glass-react-dark-narrow-200.png` | 深色条纹与重复背景字样、深色圆角控件可见；右侧裁切贯穿标签/按钮/长文，背景字样与内容竞争。仅能确认可见部分状态，不能声明窄屏/光学验收。 |
| `8afe6628df86-liquid-glass-react-light.png` | 粉蓝条纹透入圆角输入且呈模糊/折射外观；Canceled与owner错误可见。背景重复文字与正文叠加，白色页头遮住上部操作/Availability。未量化对比度或光学正确性。 |
| `8afe6628df86-liquid-glass-vue-dark-narrow-200.png` | 深色条纹与重复背景字样、深色圆角控件可见；右侧裁切贯穿标签/按钮/长文，背景字样与内容竞争。仅能确认可见部分状态，不能声明窄屏/光学验收。 |
| `8afe6628df86-liquid-glass-vue-light.png` | 粉蓝条纹透入圆角输入且呈模糊/折射外观；Canceled与owner错误可见。背景重复文字与正文叠加，白色页头遮住上部操作/Availability。未量化对比度或光学正确性。 |
| `8afe6628df86-liquid-glass-vue2-dark-narrow-200.png` | 深色条纹与重复背景字样、深色圆角控件可见；右侧裁切贯穿标签/按钮/长文，背景字样与内容竞争。仅能确认可见部分状态，不能声明窄屏/光学验收。 |
| `8afe6628df86-liquid-glass-vue2-light.png` | 粉蓝条纹透入圆角输入且呈模糊/折射外观；Canceled与owner错误可见。背景重复文字与正文叠加，白色页头遮住上部操作/Availability。未量化对比度或光学正确性。 |
| `8afe6628df86-liquid-glass-wc-dark-narrow-200.png` | 深色条纹与重复背景字样、深色圆角控件可见；右侧裁切贯穿标签/按钮/长文，背景字样与内容竞争。仅能确认可见部分状态，不能声明窄屏/光学验收。 |
| `8afe6628df86-liquid-glass-wc-light.png` | 粉蓝条纹背景与重复字样；WC输入呈平整较不透明浅色，区别于本次框架图可见的模糊条纹。Canceled与owner错误可见，白页头遮挡上部操作/Availability，背景字样与正文重叠。只记录像素差异，未归因。 |
| `8afe6628df86-shadcn-react-dark-narrow-200.png` | 深色圆角卡片、浅色按钮、红色owner错误；右侧明显裁切，Cancel文字超出按钮左侧。深色页头横带挡住Canceled/owner区域，保留这一观测限界。 |
| `8afe6628df86-shadcn-react-light.png` | 当前Runtime选中；Ada/taken/Canceled、红色owner错误、readonly和灰化disabled可见。白色页头横带遮住Validate/Reset及Availability标签，底部长文换行。 |
| `8afe6628df86-shadcn-vue-dark-narrow-200.png` | 深色圆角卡片、浅色按钮、红色owner错误；右侧明显裁切，Cancel文字超出按钮左侧。深色页头横带挡住Canceled/owner区域，保留这一观测限界。 |
| `8afe6628df86-shadcn-vue-light.png` | 当前Runtime选中；Ada/taken/Canceled、红色owner错误、readonly和灰化disabled可见。白色页头横带遮住Validate/Reset及Availability标签，底部长文换行。 |
| `8afe6628df86-shadcn-vue2-dark-narrow-200.png` | 深色圆角卡片、浅色按钮、红色owner错误；右侧明显裁切，Cancel文字超出按钮左侧。深色页头横带挡住Canceled/owner区域，保留这一观测限界。 |
| `8afe6628df86-shadcn-vue2-light.png` | 当前Runtime选中；Ada/taken/Canceled、红色owner错误、readonly和灰化disabled可见。白色页头横带遮住Validate/Reset及Availability标签，底部长文换行。 |
| `8afe6628df86-shadcn-wc-dark-narrow-200.png` | 深色圆角卡片、浅色按钮、红色owner错误；右侧明显裁切，Cancel文字超出按钮左侧。深色页头横带挡住Canceled/owner区域，保留这一观测限界。 |
| `8afe6628df86-shadcn-wc-light.png` | 当前Runtime选中；Ada/taken/Canceled、红色owner错误、readonly和灰化disabled可见。白色页头横带遮住Validate/Reset及Availability标签，底部长文换行。 |
