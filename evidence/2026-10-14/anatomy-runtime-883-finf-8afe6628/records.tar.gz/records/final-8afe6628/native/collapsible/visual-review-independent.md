准确8afe新collapsible视觉/来源审阅完成，local **partial / ABSTAIN**。本次实际逐张查看24张新PNG，不复用c82/6d/58d图片或时间。

真实run：2026-10-14T15:39:24.858252+00:00 至 2026-10-14T15:41:19.398096+00:00，36 tests passed、exit0，clean `8afe6628df8639418b12c4207c4c6dd1bf48a2d3` / tree `5720ba41fc4c88d536620cedee7f8fce2dd4f629`，Node24.21.0 / pnpm10.32.1 / macOSarm64 / Chrome155.0.8059.40，max1/min1，无私有override/asyncTRACE。源中已提交的诊断仍保留，不能称从未instrumented的历史原文件。

Some selectedBrutalist/Liquid captures include top header/nav intrusion.
Liquid background labels compete with surface/status text; no contrast measurement or optical acceptance.
Chinese-route screenshots displayEnglish demo strings; not complete localization proof.
This24selection excludes320px/font200 captures; root20separate includes narrower cases. Authoredfont enlargement is not native zoom or AT.
Only sampled static states and fourWCkeyboardpairs visually reviewed; no continuousfocus/fullAdapter optical guarantee.
156images not viewed by this reviewer; after root20 distinctrecord,136 remain unassessed.

每张名称、SHA、sidecar、head、真实时间限界和观测见JSON。Field有checkedAt；Collapsible无逐图UTC，明确使用runwindow与文件mtime（非伪造capture时间）。没有AT/全视觉/全CI批准。

| 图名 | 新图实际观察 |
| --- | --- |
| `bootstrap-2-3-2-wc-initial.png` | Uncontrolled与controlled闭合，defaultOpen/keepMounted和disabled内容展开。 蓝色链接/灰按钮外观；这组被选主体没有明显右侧文字损失。 |
| `bootstrap-2-3-2-wc-open.png` | Uncontrolled内容展开；retained/disabled仍开、controlled仍闭合。 蓝色链接/灰按钮外观；这组被选主体没有明显右侧文字损失。 |
| `bootstrap-2-3-2-wc-keyboard-focus-closed.png` | Uncontrolled内容闭合且trigger周围focusoutline清晰可见；retained/disabled内容仍在。 蓝色链接/灰按钮外观；这组被选主体没有明显右侧文字损失。 |
| `bootstrap-2-3-2-wc-keyboard-focus-open.png` | Uncontrolled内容展开且triggerfocusoutline完整可见，未被Content遮住。 蓝色链接/灰按钮外观；这组被选主体没有明显右侧文字损失。 |
| `bootstrap-2-3-2-wc-controlled-accepted.png` | Uncontrolled与retained闭合、disabled仍开；controlled内容已展开，Owner accepted: open与Acceptfocusoutline可见。 蓝色链接/灰按钮外观；这组被选主体没有明显右侧文字损失。 |
| `brutalist-wc-initial.png` | Uncontrolled与controlled闭合，defaultOpen/keepMounted和disabled内容展开。 蓝底黑边框/蓝按钮，正文换行；初始Runtime标签可见。 |
| `brutalist-wc-open.png` | Uncontrolled内容展开；retained/disabled仍开、controlled仍闭合。 蓝底黑边框/蓝按钮，正文换行；顶部站点header遮住Runtime导航区，但主要披露卡片可见。 |
| `brutalist-wc-keyboard-focus-closed.png` | Uncontrolled内容闭合且trigger周围focusoutline清晰可见；retained/disabled内容仍在。 蓝底黑边框/蓝按钮，正文换行；顶部站点header遮住Runtime导航区，但主要披露卡片可见。 |
| `brutalist-wc-keyboard-focus-open.png` | Uncontrolled内容展开且triggerfocusoutline完整可见，未被Content遮住。 蓝底黑边框/蓝按钮，正文换行；顶部站点header遮住Runtime导航区，但主要披露卡片可见。 |
| `brutalist-wc-controlled-accepted.png` | Uncontrolled与retained闭合、disabled仍开；controlled内容已展开，Owner accepted: open与Acceptfocusoutline可见。 蓝底黑边框/蓝按钮，正文换行；顶部站点header遮住Runtime导航区，但主要披露卡片可见。 |
| `liquid-glass-wc-initial.png` | Uncontrolled与controlled闭合，defaultOpen/keepMounted和disabled内容展开。 粉蓝条纹/重复背景字样与trigger及状态文字竞争，白色Content正文可读；初始Runtime导航与背景字样相叠。 不作光学/对比度验收。 |
| `liquid-glass-wc-open.png` | Uncontrolled内容展开；retained/disabled仍开、controlled仍闭合。 粉蓝条纹/重复背景字样与trigger及状态文字竞争，白色Content正文可读；顶部白色条遮住部分Runtime导航。 不作光学/对比度验收。 |
| `liquid-glass-wc-keyboard-focus-closed.png` | Uncontrolled内容闭合且trigger周围focusoutline清晰可见；retained/disabled内容仍在。 粉蓝条纹/重复背景字样与trigger及状态文字竞争，白色Content正文可读；顶部白色条遮住部分Runtime导航。 不作光学/对比度验收。 |
| `liquid-glass-wc-keyboard-focus-open.png` | Uncontrolled内容展开且triggerfocusoutline完整可见，未被Content遮住。 粉蓝条纹/重复背景字样与trigger及状态文字竞争，白色Content正文可读；顶部白色条遮住部分Runtime导航。 不作光学/对比度验收。 |
| `liquid-glass-wc-controlled-accepted.png` | Uncontrolled与retained闭合、disabled仍开；controlled内容已展开，Owner accepted: open与Acceptfocusoutline可见。 粉蓝条纹/重复背景字样与trigger及状态文字竞争，白色Content正文可读；顶部白色条遮住部分Runtime导航。 不作光学/对比度验收。 |
| `shadcn-wc-initial.png` | Uncontrolled与controlled闭合，defaultOpen/keepMounted和disabled内容展开。 白卡片/黑Accept；键盘阶段灰色focusoutline可辨，这组主体未见明显横向裁切。 |
| `shadcn-wc-open.png` | Uncontrolled内容展开；retained/disabled仍开、controlled仍闭合。 白卡片/黑Accept；键盘阶段灰色focusoutline可辨，这组主体未见明显横向裁切。 |
| `shadcn-wc-keyboard-focus-closed.png` | Uncontrolled内容闭合且trigger周围focusoutline清晰可见；retained/disabled内容仍在。 白卡片/黑Accept；键盘阶段灰色focusoutline可辨，这组主体未见明显横向裁切。 |
| `shadcn-wc-keyboard-focus-open.png` | Uncontrolled内容展开且triggerfocusoutline完整可见，未被Content遮住。 白卡片/黑Accept；键盘阶段灰色focusoutline可辨，这组主体未见明显横向裁切。 |
| `shadcn-wc-controlled-accepted.png` | Uncontrolled与retained闭合、disabled仍开；controlled内容已展开，Owner accepted: open与Acceptfocusoutline可见。 白卡片/黑Accept；键盘阶段灰色focusoutline可辨，这组主体未见明显横向裁切。 |
| `bootstrap-2-3-2-vue2-zh-cn-390-open.png` | Vue2中文路由390px图，demo文案仍是英文。正文长词在各卡片内多行换行，展开内容与Accept完整可见；站点header占据顶部。 蓝色链接/灰按钮外观；这组被选主体没有明显右侧文字损失。 |
| `brutalist-vue2-zh-cn-390-open.png` | Vue2中文路由390px图，demo文案仍是英文。正文长词在各卡片内多行换行，展开内容与Accept完整可见；站点header占据顶部。 蓝底黑边框/蓝按钮，正文换行；顶部站点header遮住Runtime导航区，但主要披露卡片可见。 |
| `liquid-glass-vue2-zh-cn-390-open.png` | Vue2中文路由390px图，demo文案仍是英文。正文长词在各卡片内多行换行，展开内容与Accept完整可见；站点header占据顶部。 粉蓝条纹/重复背景字样与trigger及状态文字竞争，白色Content正文可读；顶部白色条遮住部分Runtime导航。 不作光学/对比度验收。 |
| `shadcn-vue2-zh-cn-390-open.png` | Vue2中文路由390px图，demo文案仍是英文。正文长词在各卡片内多行换行，展开内容与Accept完整可见；站点header占据顶部。 白卡片/黑Accept；键盘阶段灰色focusoutline可辨，这组主体未见明显横向裁切。 |
