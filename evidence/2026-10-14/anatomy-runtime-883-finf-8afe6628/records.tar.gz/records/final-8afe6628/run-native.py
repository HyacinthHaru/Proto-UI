from pathlib import Path
import subprocess,json,datetime,hashlib,os
r=Path(__file__).resolve().parent
expected='8afe6628df8639418b12c4207c4c6dd1bf48a2d3'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==expected
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
env=os.environ.copy()
for key in ['PROTO_UI_FIELD_ASYNC_TRACE_DIR','PROTO_UI_COLLAPSIBLE_FOCUS_PATH_DIAGNOSTIC','DEBUG']:
 env.pop(key,None)
for group,test,var in [('field','demo-field-family.browser.test.ts','PROTO_UI_FIELD_SCREENSHOT_DIR'),('collapsible','demo-collapsible-projections.browser.test.ts','PROTO_UI_COLLAPSIBLE_SCREENSHOT_DIR')]:
 d=r/'native'/group;d.mkdir(parents=True,exist_ok=True);captures=d/'captures';captures.mkdir();e=dict(env);e[var]=str(captures)
 cmd=['corepack','pnpm@10.32.1','exec','vitest','run','apps/www/src/content/docs/zh-cn/'+test,'--maxWorkers=1','--minWorkers=1']
 a={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':expected,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'command':cmd,'node':subprocess.check_output(['node','--version'],text=True).strip(),'pnpm':'10.32.1','chrome':subprocess.check_output(['<CHROME_APP>/Contents/MacOS/Google Chrome','--version'],text=True).strip(),'platform':'darwin-arm64','initialStatus':subprocess.check_output(['git','status','--porcelain'],text=True),'sourceOverrides':False,'optInAsyncTracing':False,'addedInstrumentation':'committed new Node stage diagnostics in incoming Collapsible only; no overlay patches'}
 with (d/'run.log').open('w') as f:p=subprocess.run(cmd,env=e,stdout=f,stderr=subprocess.STDOUT)
 a.update(completedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=p.returncode,finalHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),finalStatus=subprocess.check_output(['git','status','--porcelain'],text=True),pngCount=len(list(captures.glob('*.png'))),logSHA256=hashlib.sha256((d/'run.log').read_bytes()).hexdigest())
 (d/'run-receipt.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a),flush=True)
 if p.returncode:print((d/'run.log').read_text()[-6000:],flush=True);raise SystemExit(p.returncode)
 assert a['finalHead']==expected and not a['finalStatus']
