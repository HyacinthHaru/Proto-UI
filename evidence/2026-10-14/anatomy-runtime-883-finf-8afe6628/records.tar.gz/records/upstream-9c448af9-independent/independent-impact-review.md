已只读检查 `99a332e9` → `9c448af9e3f3e0bb1b8a5aa61ed732e2a9026516` 的全部四路径增量，未发现具体新增源码问题；仅 local partial / ABSTAIN，不接受整个上游或提交 GitHub 审批。

四路径与当前 `6b62` 相对 `99a` 的 13 个自有路径、加当前 Field async 诊断共 15 路径没有直接交集。无 package/lock、Runtime/Core、技能或 CI 配置增量。保留审查仍需对实际 merge tree 再做 union 绑定。

Material 的真实 CPU prefilter 改为每个 tap 共用 RGB index/weight，保留每通道累积顺序、边界 clamp、两轮 /64 round、alpha=255；新增测试按实际纹理上传内容与冻结旧算法比较。但这不是无生产源变化：官网 preview-material-scene/library-liquid-scene 经 sink/program-pool 调用它，不能把旧 native 的完整输入闭包当作没变，也不能借用上游 benchmark/test 数字当我们的验证。

Collapsible 新增四 Liquid runtime 的 Node 阶段日志；原 native 输入、focus/expanded 判定、60s timeout、oldViews 原对象的全量 disconnection 断言保持。新增 done 日志只表示 callback 到达，不表示 Vitest 接受。Scroll 则仅在原 trailing-edge 断言失败后输出旧 rect 与限 1 秒的额外读取，再抛原 assertion；没放宽容差或把晚到状态改成验收结果。

父代理计划的最终 Field25/Collapsible36 应绑定新组合实际源，instrumented 与 default 分开记录。旧 6d/6b 的执行仍为历史；本报告未运行任何测试、浏览器或构建，未产生 merge/commit 或外部写入，也未采纳上游 reported310/35-of36 为自己的结果。
