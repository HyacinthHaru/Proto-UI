两次 Mac 控制均为所选 Liquid Glass React journey 1 pass、24 skipped，但 afterAll 10000 ms 超时，suite exit 1。不能称完整绿色，也不能用它们解释或覆盖 Linux 的 Checking→Available 失败。实际 HEAD 为 `6b62e0e6d3c5d415ccf983b572a2e37cd5121e9a`，执行时有明确记录的测试/helper/workflow 3 文件诊断差异；Node 24.21.0、Chrome 155.0.8059.40、darwin arm64。

| 记录 | 原 trace SHA256 | 4 个 check timer 的 install→fire（ms） | 首次 getter 开始→Available 返回（ms） |
| --- | --- | --- | --- |
| native-control-1 | `8852b4da3b3f82bff5e9070428687727ae08e2c8e042dd58d21c9806db75af89` | 803.997, 665.810, 809.129, 680.742 | 662.229 |
| native-control-2-debug | `d3787091bf5d37ebced07045ac381c7c2b95c3d0beb8baac1eaad4a4e34936d0` | 810.504, 667.349, 664.542, 690.894 | 663.541 |

每份 trace 均精确找到 4 个 `TimerInstall`：`timeout=500`、`singleShot=true`、实际 initiating stack 的 `check` 来自 `field-demo.shared.ts`。每项都以 PID/TID/frame/timerId 四元组找到唯一 `TimerFire`，没有拿其它 500 ms timer 代替。运行 1 renderer 是 PID 8759/TID 4157619，运行 2 是 PID 9429/TID 4165258；timerId 均为 43、46、50、53。JSON 保留完整的这个有界调用栈，并将机器 URL 转成仓库相对路径。trace 的 emitted 106:23 不能无 sourcemap 地当作原 TypeScript 行号。

两端 `clock_sync` 都实际存在。Node 的发送前后区间与 Chrome trace 时间给出常量偏移模型；两个端点的偏移区间相交，交集宽度分别为 0.298417 ms 与 0.351209 ms。该模型假设约 12 秒内偏移固定，不声称测得独立漂移上限；各 timer install→fire 间隔本身在同一 trace 时钟上，不依赖这个模型。

第 2 个 timer（46）的触发落在第 4 次原 `textContent()` RPC 的等待区间内，TimerFire 完成早于该 RPC 返回 `Available`。前三次 getter 均返回 Checking。运行 1 的 getter 耗时依次 177.987、114.349、107.072、109.734 ms；运行 2 为 177.382、111.871、109.941、111.132 ms。没有增加 getter，也没有从晚截图倒推出 deadline 内成功；这里的成功由原 journey 断言和实际 Node promise 结果共同证明。

第 2 个 timer 从安装到触发分别为 665.810 ms、667.349 ms，超过名义 500 ms。两份 trace 的 `CrRendererMain` 上都存在跨过名义 due 时刻的约 153–155 ms RunTask，后面还有约 151–153 ms 的 RunTask，覆盖了 due→fire 区间的大部分。JSON 只合并同线程 `RunTask` 区间，未把重复的 ThreadController 事件相加。这是主线程占用的测量，不是特定任务的原因证明、W3C LongTask API 结果或 Linux 根因。

原 trace 没有 requestId 的值或 resolveValidation 的返回值；“第 2 个”仅为该 timer 家族的时序编号，不能伪造语义请求编号。框架 property callback 的 stack 已真实可见，缺少 DOM validationRequest 事件不能解释成 callback 不曾执行。

DEBUG 运行在 13:52:53.518Z 记录 browser graceful close start，13:53:03.530Z 才出现 force close/kill，13:53:03.531Z 记录 ESRCH。原因仍未知；ESRCH 不能证明 Browser.close 的实际卡点或 Chrome 的退出时刻。父代理随后按准确 PID/PGID/62760、63609 端口绑定清理了遗留 Astro，收据为两端口不再监听。本次分析未向任何进程发送信号。

两份 raw trace 分别约 49 MB，含机器路径，未复制或加入公开包。这里仅生成可审查的派生摘要、相对路径、选中原始计时字段和 raw SHA。诊断启用了 7 个 trace categories 且跳过其它 24 项，可能改变时序；没有检查或干预正在进行的第三次全 25 项 opt-in 运行。所选静态 Git blobs 绑定在 JSON，但它们不是完整的 native loaded-input ledger。
