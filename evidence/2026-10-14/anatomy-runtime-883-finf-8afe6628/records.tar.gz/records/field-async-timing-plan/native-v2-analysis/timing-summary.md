V2 的原完整 25 项在 6b62 + 明示 3 文件诊断候选上实际 exit0（2026-10-14 13:58:38–14:01:35 UTC）。这是一份 precommit/instrumented Mac positive control，不是最终 c82 head 的原生验证，也不解释 Linux 红项。

| Runtime | check 500ms timers | Available receipt elapsed from first getter |
| --- | --- | --- |
| react | 4 | 781.951 ms |
| vue | 4 | 659.328 ms |
| vue2 | 4 | 781.207 ms |

三份原 trace 各约20MB，未复制到公开材料。派生 JSON 按 pid/tid/frame/timerId 联配真实 check stack 的 TimerInstall/TimerFire，保留两端 clock_sync、Node 原 getter 时序与 raw SHA。这里既无 requestId，也未读取 resolveValidation 返回值。缩减后的四个 categories 不应冒称保留第一版的完整 RunTask 观察。

第一版两个控制的 afterAll10000ms失败原样保留。v2除了 categories，还取消了单case选择、只在3个Liquid框架journey启用trace，并并行启动独立cleanup，因此不能将成功单独归因某一个改变；Browser.close/ESRCH 的原因仍未知。最终 native/CI 和新的 Field slot 源修复需要独立绑定。