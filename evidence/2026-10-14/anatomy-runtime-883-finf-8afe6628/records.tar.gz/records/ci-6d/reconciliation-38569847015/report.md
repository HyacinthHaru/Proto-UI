精确 6d canonical CI `38569847015` / attempt 1 已完整终态：22 jobs，12 success / 10 failure。全部 22 份原日志已核对，均 checkout `5dc93fceefbd1457a412e3c383448045c73e2ee7`；GitHub git-commit API 的 tree `586c16efc86b1f2fd1f25315a889498e383ddf88` 与 6d 完全相等，parents 为 99a332e9 + 6d。general/browser/package/Rust 四组均绑定这个实际 checkout，不把 synthetic commit 当作额外 source delta。

| Browser shard | 实际终态 | 有最终 summary 的 tests |
| --- | --- | --- |
| 1/8 | exit 1，完整 reporter | 2 failed / 45 passed |
| 2/8 | exit 124，无最终 reporter | 未知；仅保存已完成文件的原 reporter 行 |
| 3/8 | exit 1，完整 reporter | 22 failed / 38 passed |
| 4/8 | exit 124，无最终 reporter | 未知；仅保存已完成文件的原 reporter 行 |
| 5/8 | exit 1，完整 reporter | 1 failed / 71 passed / 15 skipped |
| 6/8 | exit 124，无最终 reporter | 未知；仅保存已完成文件的原 reporter 行 |
| 7/8 | exit 124，无最终 reporter | 未知；仅保存已完成文件的原 reporter 行 |
| 8/8 | exit 124，无最终 reporter | 未知；仅保存已完成文件的原 reporter 行 |

仅 shard 1/3/5 的完整 reports 合计 **154 pass / 25 fail / 15 skip**，不是全 8 总计。其余 2/4/6/7/8 达到进程 deadline 后 exit124，不推算剩余文件/用例。Collapsible 的 36 项在 shard4 有实际文件级通过行，但 shard4 最后仍超时失败。

general 在 public-docs 的 **78 drift issues** 处 exit1；没有进入 general Vitest，也没有 general test 总数。不能把依赖安装输出或脚本中稍后的命令文本当成执行。

Package job 实际 changed-from 构建 **16/47** packages，随后检查 **47 manifests**；budget-policy 9 tests 全过。九个 entry 的结果是 **4 PASS / 5 ADVISORY**，显式 Finf development policy 仍记录超限，不能写作 strict budget 全绿或 Finf 接受。Node24.21.0、zlib1.3.2.1-motley-8002e91、esbuild0.25.12、linux/x64 与各项 gzip/minified/SHA 在 `package-measurements.json`。

Rust、Rust macOS、Rust interop 三 job 实际 success，保留各自原命令及结果，不混成跨平台唯一用例数。14:23:33.445888 UTC 的完整 snapshot 中，精确 6d 的 DCO success；未找到 Poppy 命名 check/status/comment，保持未知，不推断隐藏权限或批准。

58d 的旧完整 browser reports 是155 pass/24 fail/15 skip，属于另一历史 checkpoint；本报告不套用该旧数字，也不因计数相近宣称同一根因。本次只读22原日志/metadata及一份缺失的 synthetic commit 元数据，没有重跑 Actions、测试、build 或修改源码/公开包。
