# PR888 exact58d CI failure triage

本地只读结论为 **partial / ABSTAIN**。本快照以collector 2026-10-14T12:56:23.136972+00:00 为界：main CI38563529622所有8个browser job已终态，但汇总test job仍queued；Field专用38563530001已failure。没有自行重跑或操作collector。

来源已核：Field专用直接checkout58d；main CI为synthetic612991dd99cd69d07e589a22247ba75c073db5e9。通过一次只读GitHub git commit API核定其tree21dc，与58d精确一致，不能把两个commit写成同一个SHA。

最优先C可执行问题是Field异步completion：25项22pass3fail，LiquidReact/Vue/Vue2均在line247等待Available而保持Checking。三条focus getter早已resolved true，不是旧focus1000ms失败。源码demo为validationRequest设置Checking，500ms timer调用resolveValidation，然后仅currentRequest匹配才更新文字。日志尚不能区分newer请求未发/重复覆盖、timer未执行、resolve返回/抛错、owner重建或状态节点陈旧。应先读现有失败artifact中的request/value/owner/input/pageerror；缺时再做一次有界最小观察，不能先加timeout或把新queuedField反例直接当此次CI根因。

General停在public-docs78个unclassified exports，Base/Shadcn/Brutalist各26，未到general Vitest。它是catalog/文档前置问题，同时留下canonical C general未执行的实际欠账；不能用local57/944将该job改绿。

| Job / shard | 实际结果 | 首个边界 / 分类 |
| --- | --- | --- |
| Field115850338269 | 22pass3fail/25 | asyncStatus Checking→Available未达；C优先调查，机制未定 |
| general115851830405 | exit1，78preflightdiagnostics | general测试未执行；catalog owner处理 |
| 1/8 | 46pass1fail/47 | S4 Dialog light trigger click30s超时，paint后段未到 |
| 3/8 | 38pass22fail/60 | color/theme8、Radio theme4、S5初始ready2、Selectgeometry8 |
| 5/8 | 71pass1fail15skip/87 | Vue2Tooltip pressed-scale仍none |
| 2/8 | exit124，整份不完整 | 多file实际通过，Direction8fail；不能算总断言数 |
| 4/8 | exit124，整份不完整 | Projection5fail、Dialogavailable4fail；Collapsible36已实际全过、Scrollend6过 |
| 6/8 | exit124，整份不完整 | nativelinks2fail；Contrast46及quickstart20实际过 |
| 7/8 | exit124，整份不完整 | Shadowparent/query1fail、HomeRuntime5fail、Searchready失败观察 |
| 8/8 | exit124，整份不完整 | Brutalist2fail、Homepage7fail，含anchor38vs44及click/capturetimeouts |

只有1/3/5三份完整browser报告可合计：155pass24fail15skip=194tests。另五份不能据exit124计算完整数量，也不能把已经完成的文件都叫未执行。尤其4/8中Collapsible原36case在12:46:35已通过，可作为该精确tree的官方文件级证据，不能称整个job绿色。

逐job rawSHA、checkout、所有完整FAIL标题、各已打印file报告、deadline前内联失败及78diagnostics原文保存在JSON。Shadow deepEqual只打印collapsed对象，不能仅凭title定位mounted/cleanup首分歧；Select hidden/preparing及Projection旧portal/focus尾部是跨owner候选，C是否参与未定，不能按文件名排除。Color/Radio/Tooltip首先落在family/theme/Feedback/Rule投影；有些后续lifetime断言未执行，仍保留欠账。

本次无paired accepted-main对照，因此未将任何失败笼统归为继承或flake。Mac本地通过不替代Linux失败。精确Chrome版本在专用workflow中重定向到artifact，日志未展示时不猜；Node日志为24.21.0。新workingField/Toggle候选不属于58d执行。
