# Field canonical artifact addendum

官方Field artifact11894636375已一次只读下载到私有目录，81members、5,931,456bytes。source-before/after均clean58d/tree21dc，最终failure。Node24.21.0，**Chrome155.0.8059.39/Linux**；本地Mac的155.0.8059.40是不同环境，不能混称。

原25项22pass3fail不变，三个Liquid React/Vue/Vue2失败仍为line247的Checking→Available 1000ms poll。实际label focus此前已true。新读回三份failure sidecar和原PNG均显示：较晚capture时已Available、value=newer、busy=false、invalid=false。该capture距catch内atFailure约8.56–8.76秒；late success不能抹掉原deadline失败，也不等于知道Available最初出现时间。

两次原生input均有记录，taken→newer相隔约1.9–2.0秒，第二次input的document capture已经读到旧taken为Unavailable。因此不是到截图时仍永久pending；但该DOM recorder没有捕获三运行时的validationRequest/validityChange，无法由此获得requestID或timer fire时间，也不能把缺DOM事件当callback未执行。

三张图已本轮逐张查看：Available文字可见，但白色固定header遮住async editor部分，背景重复文字叠加标签/帮助。不是精确失败瞬间的无侵入截图，也不是完整视觉/AT验收。

当前证据不能区分timer、callback bridge、主线程、DOM更新或Locator读取延迟，不能证明重复请求或Root guard是CI根因；亦不能把新Field-owned重入反例/外部State观察直接套进此CI。若继续，只需一个有界边界记录requestId/value/currentRequest、timer schedule/fire、resolve返回/异常、owner/generation及status节点身份，保留原1000ms断言，不加timeout、不宣称flake/继承。此前triage保持历史原样，本addendum仍partial/ABSTAIN。
