真实同步remount证明原单行候选不足。新8casefixture同字节运行三次：**58d原Root5pass/3fail；原单行候选7pass/1fail；epoch候选8pass/0fail**。原7case、单行源、旧4case正式patch及所有原红未覆盖。

同一个publicContextsubscriber中：
1. 起点alive/mounted、mountEpoch1。
2. 调用session.unmount()返回alive/detached、epoch1。
3. 不await，立即session.mount()返回alive/mounted、epoch2。
4. 原Root和单行候选随后仍发旧valueChange[a]，事件采样epoch2。
5. callback外await两Promise后，独立freshb请求=true、value[b]、单[b]事件；正向fresh/epoch断言先于旧事件红断言执行。

没有访问private runNow或手调生命周期；publicmountEpoch/phase已足够证明跨view，单行guard仍通过而emit旧事件也确认仅owneridentity不足。epoch候选只在prototype内部新增retirementgeneration：已有onUnmounted递增、request捕获、publish后同时核对owner+generation。Runtime未改、返回仍true、合法nested与WC物理remove对照不变。

冻结Root候选[epoch-root.proto.ts](epoch-root.proto.ts)，SHA `3c1a39e5a623eaef920b0ec397f29ff96bf3ade9dfca845c73530f07d8d546a9`；完整补丁[epoch-candidate.patch](epoch-candidate.patch)。新正式[formal-v2/formal-test-candidate.patch](formal-v2/formal-test-candidate.patch)预计5项normal/unmount/dispose/nested/remount，复用既有harness、真实Root/Item、publicContext订阅，voidscope内局部捕获返回，所有expect在callback外，fresh控制不被旧event失败遮住。正式patch尚未运行，父代理先红后绿。

三轮固定Git58d，382loadedpaths相同，候选各381项相同+唯一Rootoverride；新fixture SHA `9d7acc2edfb3f649367ab9c411915093967200cc2ba77b2697c2e6a03479e69d`，config也同字节。实际checkout58d期间父代理Field/test/spec有dirty修改，receipts完整记录；loader未混入它们。三次实际时间分别12:53:09–12:53:16、12:53:42–12:53:49、12:55:13–12:55:20 UTC。进程全终态，无Chrome/其它collector操作。

正式V2基于父代理当前working test快照并保留其Field改动，不把它标成纯58d文件；只生成privatepatch，两个patch的git apply --check已过。created-onlyterminal等未测边界仍不宣称已覆盖。原native/AT/安装包或全Adapter准入不在本小矩阵范围。具体SHA、事件tape和逐次源绑定见report.json；没有产品编辑或外写。
