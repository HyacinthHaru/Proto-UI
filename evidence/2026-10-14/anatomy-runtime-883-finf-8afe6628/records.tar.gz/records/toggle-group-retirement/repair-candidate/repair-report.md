Toggle Group私有最小候选已完成：**同7fixture，baseline5pass/2fail → after7pass/0fail**。实际after为2026-10-14 12:39:33–12:39:38 UTC，固定/physical均准确58d clean，Node24.21.0/pnpm10.32.1，未跑Chrome。382loadedpaths中381项与baselineGit字节相同，唯一Rootoverride；fixture SHA ac8eab0bb742e4a4d15b36354de8968eabd093e84d788a9642313f45b1e5d341、输入/断言/timeout原样。

[candidate.patch](candidate.patch)只在Root的publish之后增加`if (runNow !== run) return true;`。已接受requestToggle仍返回true，旧view退休后不emit；normal和合法nested保持原语义，没有锁、吞错、API、数值或selection顺序变化。WC remove仍是异步物理移除时序对照，事件仍可在Root断连、逻辑cleanup之前出现，未把它误称同步退休或修复。

生命周期核对：现有onUnmounted清runNow，当前实际unmount及mounteddispose都经过它；没有独立onBeforeDispose清理，也没有现成epochcounter。本候选不为未测created-onlydispose或同步unmount/remount加新hook/epoch，因此**不声称覆盖它们**。若父代理扩大到这些边界，应先取得相应实证。现有draft notification-completion应在集成时最小显式列出ToggleGroup caller，不改变完整selection定义或activation状态。

正式测试私有补丁在[formal-test-candidate.patch](formal-test-candidate.patch)，只改notification-retirement-lifecycle.test.ts：复用原runtimeHarness，实际Root+两个实际Item，公开ContextAPI订阅现有source-ownedkey；normal/unmount/dispose/nested共预计新增4例。所有expect在Contextcallback外，void scope内赋局部accepted，finally释放session。无runner/私有provenance工具复制。**正式测试尚未运行**，父代理先原Root红再冻结Root绿。两个patch均已只读git apply --check通过，产品文件未编辑或stage。

Root候选SHA `727a6619a5a830677ba4a56b9bba9bcb66b69353e908189adb8a6bcd5f213222`。完整源绑定、before/after事件/返回对账、正式patch SHA及边界见[repair-report.json](repair-report.json)。原baseline report与所有原失败记录保持原样；无外写、commit或父代理collector操作。
