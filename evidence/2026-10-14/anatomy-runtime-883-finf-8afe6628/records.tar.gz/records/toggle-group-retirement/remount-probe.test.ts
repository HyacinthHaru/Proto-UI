import { afterAll, afterEach, expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import path from 'node:path';
import { definePrototype } from '@proto.ui/core';
import { createRuntimeSession } from '@proto.ui/runtime';
import { AdaptToWebComponent, setElementProps } from '@proto.ui/adapter-web-component';
import { toggleGroupRoot, toggleGroupItem } from '@proto.ui/prototypes-base/toggle-group';
import { TOGGLE_GROUP_CONTEXT } from '@proto.ui/prototypes-base/toggle-group/shared';
import { fieldControl } from '@proto.ui/prototypes-base/field';
import {
  ANATOMY_INSTANCE_TOKEN_CAP,
  ANATOMY_PARENT_CAP,
  ANATOMY_GET_PROTO_CAP,
  ANATOMY_ROOT_TARGET_CAP,
} from '@proto.ui/module-anatomy';
import { CONTEXT_INSTANCE_TOKEN_CAP, CONTEXT_PARENT_CAP } from '@proto.ui/module-context';
import { EVENT_ROOT_TARGET_CAP, EVENT_GLOBAL_TARGET_CAP } from '@proto.ui/module-event';
import { EXPOSE_EVENT_SINK_CAP } from '@proto.ui/module-expose-event';
import {
  AS_TRIGGER_INSTANCE_CAP,
  AS_TRIGGER_PARENT_CAP,
  AS_TRIGGER_GET_PROTO_CAP,
} from '@proto.ui/module-as-trigger';
import { EXPOSES_RECORD_SINK_CAP } from '@proto.ui/module-expose-state';
import {
  TEXT_CONTROL_HOST_CAP,
  TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
} from '@proto.ui/module-text-control';
const output = process.env.TOGGLE_RETIRE_OUTPUT!;
const sessions = new Set<ReturnType<typeof createRuntimeSession>>();
const observations: any[] = [];
const owned: HTMLElement[] = [];
const flush = async () => {
  for (let i = 0; i < 16; i++) await Promise.resolve();
};
const errorFact = (error: unknown) =>
  error instanceof Error
    ? { name: error.name, message: error.message, stack: error.stack }
    : { type: typeof error, value: error };
afterEach(async () => {
  for (const session of [...sessions].reverse()) await session.dispose();
  sessions.clear();
  for (const el of owned.splice(0)) el.remove();
  await flush();
});
afterAll(() => {
  writeFileSync(
    path.join(output, 'observations.json'),
    JSON.stringify(observations, null, 2) + '\n'
  );
  writeFileSync(
    path.join(output, 'worker-environment.json'),
    JSON.stringify(
      {
        node: process.version,
        execPath: process.execPath,
        platform: process.platform,
        arch: process.arch,
        versions: process.versions,
        PATH: process.env.PATH,
      },
      null,
      2
    ) + '\n'
  );
});
AdaptToWebComponent(toggleGroupRoot);
AdaptToWebComponent(toggleGroupItem);
let observerSequence = 0;
function observerProto(onValue: (value: readonly string[]) => void, tape: any[]) {
  return definePrototype({
    name: 'toggle-retirement-observer-' + ++observerSequence,
    setup(def) {
      def.context.subscribe(TOGGLE_GROUP_CONTEXT, (_run, next) => onValue([...next.value]));
      def.lifecycle.onUnmounted(() => tape.push({ kind: 'observer.unmounted' }));
      def.lifecycle.onBeforeDispose(() => tape.push({ kind: 'observer.beforeDispose' }));
    },
  });
}
function runtimeHarness() {
  const parents = new Map<any, any>(),
    protos = new Map<any, any>();
  let actionCallback = (_name: string) => {};
  const actions: string[] = [];
  const events: any[] = [];
  const tape: any[] = [];
  function make(proto: any, parent: any = null, props: any = {}) {
    const listeners = new Map<string, Set<any>>();
    const target = {
      addEventListener(type: string, fn: any) {
        if (!listeners.has(type)) listeners.set(type, new Set());
        listeners.get(type)!.add(fn);
      },
      removeEventListener(type: string, fn: any) {
        listeners.get(type)?.delete(fn);
      },
      dispatchEvent(event: Event) {
        for (const fn of [...(listeners.get(event.type) ?? [])]) fn(event);
        return true;
      },
    } as unknown as EventTarget;
    parents.set(target, parent);
    protos.set(target, proto);
    let exposes: any,
      connection: any,
      textValue = '';
    const session = createRuntimeSession(proto, {
      prototypeName: proto.name,
      getRawProps: () => props,
      schedule: (fn) => fn(),
      scheduleDelay: (ms, fn) => {
        const id = setTimeout(fn, ms);
        return { cancel: () => clearTimeout(id) };
      },
      commit: (_c, s) => s?.done(),
      onRuntimeReady(w) {
        if (proto === fieldControl)
          w.attach('text-control', [
            [
              TEXT_CONTROL_HOST_CAP,
              {
                attach(c: any) {
                  connection = c;
                  textValue = c.patch.value ?? c.patch.defaultValue ?? '';
                  return {
                    update(patch: any) {
                      if (typeof patch.value === 'string') textValue = patch.value;
                    },
                    snapshot: () => ({ value: textValue, composing: false }),
                    dispose() {},
                  };
                },
              },
            ],
            [
              TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
              (fn: () => void) => session.invokeInCallbackScope(fn),
            ],
          ]);
        w.attach('anatomy', [
          [ANATOMY_INSTANCE_TOKEN_CAP, target],
          [ANATOMY_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [ANATOMY_GET_PROTO_CAP, (t: any) => protos.get(t)],
          [ANATOMY_ROOT_TARGET_CAP, (t: any) => t],
        ]);
        w.attach('context', [
          [CONTEXT_INSTANCE_TOKEN_CAP, target],
          [CONTEXT_PARENT_CAP, (t: any) => parents.get(t) ?? null],
        ]);
        w.attach('event', [
          [EVENT_ROOT_TARGET_CAP, () => target],
          [EVENT_GLOBAL_TARGET_CAP, () => target],
        ]);
        w.attach('as-trigger', [
          [AS_TRIGGER_INSTANCE_CAP, target],
          [AS_TRIGGER_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [AS_TRIGGER_GET_PROTO_CAP, (t: any) => protos.get(t)],
        ]);
        w.attach('expose-state', [
          [
            EXPOSES_RECORD_SINK_CAP,
            (x: any) => {
              exposes = x;
            },
          ],
        ]);
        w.attach('expose-event', [
          [
            EXPOSE_EVENT_SINK_CAP,
            (name: string, payload: unknown) => {
              events.push({ name, payload });
              tape.push({ kind: 'event', name, payload });
              actions.push(name);
              actionCallback(name);
            },
          ],
        ]);
      },
    });
    sessions.add(session);
    return {
      session,
      target,
      input(value: string) {
        textValue = value;
        connection.onEvent({
          type: 'input',
          value,
          composing: true,
          data: 'x',
          inputType: 'insertText',
        });
      },
      get exposes() {
        return exposes;
      },
    };
  }

  return {
    make,
    actions,
    events,
    tape,
    setActionCallback(fn: (name: string) => void) {
      actionCallback = fn;
    },
  };
}

it.each(['normal', 'unmount', 'dispose', 'nested', 'remount'] as const)(
  'Runtime Toggle Context publication: %s',
  async (operation) => {
    const h = runtimeHarness();
    const root = h.make(toggleGroupRoot);
    const items = ['a', 'b'].map((value) => h.make(toggleGroupItem, root.target, { value }));
    let armed = false,
      observed = 0,
      nested: unknown,
      returned: unknown,
      threw = false,
      error: unknown;
    const transitions: Promise<unknown>[] = [],
      transitionErrors: unknown[] = [];
    const invoke = (value: string) => {
      let result: unknown;
      root.session.invokeInCallbackScope(() => {
        result = root.exposes.requestToggle(value);
      });
      return result;
    };
    const observer = h.make(
      observerProto((value) => {
        h.tape.push({
          kind: 'context',
          value,
          phase: root.session.instancePhase,
          mount: root.session.mountPhase,
          epoch: root.session.mountEpoch,
        });
        if (!armed || observed || value.length !== 1 || value[0] !== 'a') return;
        observed++;
        h.tape.push({
          kind: 'operation.begin',
          operation,
          phase: root.session.instancePhase,
          mount: root.session.mountPhase,
          epoch: root.session.mountEpoch,
        });
        if (operation === 'nested') nested = invoke('b');
        if (operation === 'unmount' || operation === 'dispose') {
          transitions.push(
            root.session[operation]().catch((e) => transitionErrors.push(errorFact(e)))
          );
          h.tape.push({
            kind: 'retirement.returned',
            phase: root.session.instancePhase,
            mount: root.session.mountPhase,
            epoch: root.session.mountEpoch,
          });
        }
        if (operation === 'remount') {
          const unmount = root.session.unmount();
          transitions.push(unmount.catch((e) => transitionErrors.push(errorFact(e))));
          h.tape.push({
            kind: 'remount.after-unmount-call',
            phase: root.session.instancePhase,
            mount: root.session.mountPhase,
            epoch: root.session.mountEpoch,
          });
          const mount = root.session.mount();
          transitions.push(mount.catch((e) => transitionErrors.push(errorFact(e))));
          h.tape.push({
            kind: 'remount.after-mount-call',
            phase: root.session.instancePhase,
            mount: root.session.mountPhase,
            epoch: root.session.mountEpoch,
          });
        }
        h.tape.push({ kind: 'operation.end', operation, nested });
      }, h.tape),
      root.target
    );
    for (const part of [root, ...items, observer]) await part.session.mount();
    expect(root.exposes.getValue()).toEqual([]);
    expect(root.exposes.count.get()).toBe(2);
    h.events.length = 0;
    h.tape.length = 0;
    const initialEpoch = root.session.mountEpoch;
    h.setActionCallback((name) => {
      if (name === 'valueChange')
        h.tape.push({
          kind: 'valueChange.phase',
          phase: root.session.instancePhase,
          mount: root.session.mountPhase,
          epoch: root.session.mountEpoch,
        });
    });
    armed = true;
    try {
      returned = invoke('a');
    } catch (e) {
      threw = true;
      error = e;
    }
    await Promise.all(transitions);
    const events = h.events.filter((e) => e.name === 'valueChange').map((e) => e.payload);
    const valueAfterOriginal = operation === 'dispose' ? null : root.exposes.getValue();
    let fresh: unknown;
    if (operation === 'remount') {
      h.tape.push({ kind: 'fresh.begin', epoch: root.session.mountEpoch });
      const count = h.events.length;
      const accepted = invoke('b');
      fresh = {
        accepted,
        value: root.exposes.getValue(),
        events: h.events
          .slice(count)
          .filter((e) => e.name === 'valueChange')
          .map((e) => e.payload),
        epoch: root.session.mountEpoch,
      };
      h.tape.push({ kind: 'fresh.end', fresh });
    }
    const row = {
      host: 'runtime',
      operation,
      observed,
      returned,
      nested,
      threw,
      error: threw ? errorFact(error) : null,
      events,
      tape: [...h.tape],
      transitionErrors,
      instancePhase: root.session.instancePhase,
      mountPhase: root.session.mountPhase,
      mountEpoch: root.session.mountEpoch,
      initialEpoch,
      value: valueAfterOriginal,
      fresh,
    };
    observations.push(row);
    expect(observed).toBe(1);
    expect(transitionErrors).toEqual([]);
    expect(threw, JSON.stringify(row.error)).toBe(false);
    expect(returned).toBe(true);
    if (operation === 'normal') {
      expect(events).toEqual([{ value: ['a'] }]);
      expect(row.value).toEqual(['a']);
    } else if (operation === 'nested') {
      expect(nested).toBe(true);
      expect(events).toHaveLength(2);
      expect(events).toContainEqual({ value: ['a'] });
      expect(events).toContainEqual({ value: ['b'] });
      expect(row.value).toEqual(['b']);
    } else {
      if (operation === 'remount') {
        expect(row.mountEpoch).toBe(initialEpoch + 1);
        expect(fresh).toEqual({
          accepted: true,
          value: ['b'],
          events: [{ value: ['b'] }],
          epoch: initialEpoch + 1,
        });
      }
      expect(events).toEqual([]);
      expect(row.mountPhase).toBe(operation === 'remount' ? 'mounted' : 'detached');
      if (operation === 'dispose') expect(row.instancePhase).toBe('disposed');
    }
  }
);
it.each(['normal', 'nested', 'remove'] as const)(
  'WC Toggle Context publication: %s',
  async (operation) => {
    const root = document.createElement(toggleGroupRoot.name) as any;
    owned.push(root);
    const items = ['a', 'b'].map((value) => {
      const item = document.createElement(toggleGroupItem.name);
      setElementProps(item, { value });
      return item;
    });
    const events: any[] = [],
      tape: any[] = [];
    let api: any,
      armed = false,
      observed = 0,
      nested: unknown,
      returned: unknown,
      threw = false,
      error: unknown;
    const proto = observerProto((value) => {
      tape.push({ kind: 'context', value, rootConnected: root.isConnected });
      if (!armed || observed || value.length !== 1 || value[0] !== 'a') return;
      observed++;
      tape.push({ kind: 'operation.begin', operation });
      if (operation === 'nested') nested = api.requestToggle('b');
      if (operation === 'remove') root.remove();
      tape.push({ kind: 'operation.end', operation, nested, rootConnected: root.isConnected });
    }, tape);
    AdaptToWebComponent(proto);
    const observer = document.createElement(proto.name);
    root.addEventListener('valueChange', (event: CustomEvent) => {
      events.push(event.detail);
      tape.push({ kind: 'event', payload: event.detail, rootConnected: root.isConnected });
    });
    root.append(...items, observer);
    document.body.append(root);
    await flush();
    api = root.getExposes();
    expect(api.getValue()).toEqual([]);
    expect(api.count.get()).toBe(2);
    events.length = 0;
    tape.length = 0;
    armed = true;
    try {
      returned = api.requestToggle('a');
    } catch (e) {
      threw = true;
      error = e;
    }
    const atReturn = { events: [...events], rootConnected: root.isConnected, tape: [...tape] };
    await flush();
    const row = {
      host: 'wc',
      operation,
      observed,
      returned,
      nested,
      threw,
      error: threw ? errorFact(error) : null,
      atReturn,
      afterFlush: {
        events: [...events],
        rootConnected: root.isConnected,
        exposeKeys: Object.keys(root.getExposes()),
        tape: [...tape],
      },
      value: operation === 'remove' ? null : api.getValue(),
    };
    observations.push(row);
    expect(observed).toBe(1);
    expect(threw, JSON.stringify(row.error)).toBe(false);
    expect(returned).toBe(true);
    if (operation === 'normal') {
      expect(events).toEqual([{ value: ['a'] }]);
      expect(row.value).toEqual(['a']);
    } else if (operation === 'nested') {
      expect(nested).toBe(true);
      expect(events).toHaveLength(2);
      expect(events).toContainEqual({ value: ['a'] });
      expect(events).toContainEqual({ value: ['b'] });
      expect(row.value).toEqual(['b']);
    } else {
      expect(root.isConnected).toBe(false);
      expect(row.afterFlush.exposeKeys).toEqual([]);
    }
  }
);
