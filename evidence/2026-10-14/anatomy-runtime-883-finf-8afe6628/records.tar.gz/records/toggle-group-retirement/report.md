准确58d39e1f的Toggle Group Context小控制已完成：**7tests，5pass/2fail，exit1**，2026-10-14 12:34:28–12:34:34UTC。4个normal/合法nested控制均通过，另WC DOMremoval时序控制通过；两项实际红均为Runtime同步退休之后的旧continuation。没有import/setup失败或新浏览器运行。

实际公共入口为`requestToggle(value)`，不存在`requestValue`。原source Root72–86仍在publish后直接使用capturedrun emit。实际eventtape：

| 控制 | 观察与首分歧 |
| --- | --- |
| Runtime normal | Context[a]→valueChange[a]，返回true，owner仍alive/mounted。 |
| Runtime unmount | Context[a]→session.unmount返回alive/detached→旧valueChange[a]，返回true，无异常。 |
| Runtime dispose | Context[a]→session.dispose返回disposed/detached→Root85尝试rt.expose.emit，被Runtime终态guard拒绝；没有事件发出。 |
| Runtime / WC nested | callback中requestToggle(b)合法接受；inner/outer均true，最终值[b]，两事件实际为[b]再[a]。只记录顺序，不创建新selection规则。 |
| WC remove | root.remove使isConnectedfalse→随后valueChange[a]→observer.unmounted/beforeDispose稍后发生。此为物理移除与延后退休控制，不是同步Rootunmount/dispose或C失效证明。 |

Fixture使用真实Root和两个真实Item，没有伪造Anatomyitem/state；Runtime复用notification-retirement的宿主能力harness，WC为真实Adapter/renderer在HappyDOM。publicdef.context.subscribe使用existing`TOGGLE_GROUP_CONTEXT`，但该Key只在shared.ts导出、不在packageindex，故这是source-level作者协议控制而非packed消费者声明。Runtime返回值均在invokeInCallbackScope callback内局部捕获，未依赖void返回；所有expect在Contextcallback外。无私有controller或flags、新API、原生输入或Focus操作。

源/环境：fixed与physical前后都为`58d39e1fb06fdd437ae75ad6be26836cfd4e00ac` / tree`21dc0b86c9493e5d75c9e109087ea7c242653cb9`且clean。382个实际loadedGitinputs逐blob/SHA等于58d，零生产override。实际workerNode24.21.0、darwinarm64，launcherpnpm10.32.1。runner/child均已终态且不存在；没碰root9261或其它进程。

归属：terminal样本明确是ToggleGroup旧调用在retiredRun上继续emit，Runtime严格guard本身正常。unmount样本证明旧调用事件继续发出，不能泛化成所有alive/detached实例工作都禁止。C-LIFECYCLE0008 active、0002/Context0004 draft及既有notification-completion方向支持检查caller边界；但现有notification-completion明确caller清单尚无ToggleGroup，P-BASE-TOGGLE-GROUP又只有orientation draft，因此生产修复前应最小补明确caller范围，保留已接受返回和合法nested，不新增selection顺序或吞错策略。

没有修复、外写或额外运行。controlled/rejectednested/remount等尚未扩大验证，WC同步逻辑退休不可用物理remove替代。原日志、事件tape、完整源码hash及局限见report.json/source-binding.json。
