# Initial Overlay c61 review — retained finding

结论partial/ABSTAIN，**1个已实际复现P2：ISSUE883-OVERLAY-RELEASE-REFRESH-OWNER-001**。原layer detach/terminal/secondary控件和53项positive结果保持真实，但不能接受完整c61候选。

外部caps.attach(B)进入refreshCurrentHostCaps，旧A.portal的release先实际释放，再同步onMountPhase(mounted,2)，最后抛原E。refresh在291处中断，297–299的B缓存提交未执行。新deferResourceReentry515处仍flush queued sync，它使用旧A字段，tape证实新增acquire.a.portal。publiccaps已B/epoch3，但A重新1/1/1、B全0。

成对baseline同样失败于剩余A.layer/modal未清理（A0/1/1），所以没有把baseline称绿；c61新增的是旧portal重新获取（A1/1/1）。两边原E身份均保留，之后测试hygiene清理不是主结果恢复。59实际加载输入逐SHA对账，固定58d+唯一c61Overlayoverride；不是native或完整Runtime永久泄漏论断。

建议在refresh所属层完成old-owner release及同代cache提交，步骤之间继续保留caps epoch guards，再协调已验证的currentprovider。不要先赋新cache后释放旧资源，也不要无界retry或改全局错误政策。trace已准备私有v2；本报告保留初版及真实反例，等待最终delta另审。
