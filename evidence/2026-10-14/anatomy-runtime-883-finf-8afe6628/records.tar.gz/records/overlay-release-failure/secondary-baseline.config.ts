import base from '<SOURCE_ROOT>/vitest.config.ts';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
const repo = '<SOURCE_ROOT>',
  revision = '58d39e1fb06fdd437ae75ad6be26836cfd4e00ac',
  output = process.env.OVERLAY_RELEASE_OUTPUT!;
const tracked = new Set(
  execFileSync('git', ['ls-tree', '-r', '--name-only', revision], {
    cwd: repo,
    encoding: 'utf8',
  })
    .trim()
    .split('\n')
);
const loaded = new Map();
const save = () =>
  fs.writeFileSync(
    path.join(output, 'loaded-inputs.json'),
    JSON.stringify([...loaded.values()], null, 2) + '\n'
  );
process.on('exit', save);
export default {
  ...base,
  root: repo,
  cacheDir: path.join(output, 'vite-cache'),
  plugins: [
    {
      name: 'fixed-overlay-release-source',
      enforce: 'pre',
      load(id) {
        const relative = path.relative(repo, id.split('?')[0].replace(/^\/@fs/, ''));
        if (!tracked.has(relative)) return null;
        const bytes = execFileSync('git', ['show', revision + ':' + relative], {
          cwd: repo,
        });
        loaded.set(relative, {
          path: relative,
          source: revision,
          sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
        });
        save();
        return bytes.toString();
      },
    },
    ...(base.plugins ?? []),
  ],
  test: {
    ...base.test,
    include: [
      '<TASK_STATE>/overlay-release-failure/secondary-error.test.ts',
    ],
    maxWorkers: 1,
    minWorkers: 1,
    fileParallelism: false,
    reporters: ['verbose', 'json'],
    outputFile: { json: path.join(output, 'vitest.json') },
  },
};
