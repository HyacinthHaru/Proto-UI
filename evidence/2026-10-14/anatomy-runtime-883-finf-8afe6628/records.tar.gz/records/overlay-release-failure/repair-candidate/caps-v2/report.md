Overlay v2 私有候选完成，保留了 reviewer 找到的新增红项。

同一 `caps-replacement.test.ts`（SHA `409b287f8816c31835f8d0d62daeee8cf9800d5d51cd61b2acbe506f7aca7782`）依次运行：原 58d 为 1 fail，c61 候选为 1 fail，v2 为 1 pass。CapsVault 已是 B、epoch 3 时，baseline 的 A 是 portal=0/layer=1/modal=1；c61 新 drain 会额外 `acquire.a.portal`，恢复成 A 全 1、B 全 0。因此不能拿原实现也红来忽略 c61 的新增回归。

v2 把 refresh 原有 release 步骤和最后的 provider cache 提交放进同一 Overlay-local first-error sequence，仍逐步检查 caps epoch，仍先释放 acquiring owner 再提交当前 cache。结果依次释放 A.portal、A.modal、A.layer，再取得 B.portal、B.layer、B.modal；A 全 0、B 全 1，抛出值仍是同一个原始 Error。

v2 的原 6 项、secondary 2 项与新 replacement 1 项分别保持原 fixture 字节和断言运行，全部通过（合计 9/9；不是一次全仓或浏览器 suite）。每次仍加载固定 58d 的 59 个 tracked inputs，候选仅替换 Overlay impl；实际 checkout 为 6d 加父代理 3 个 staged paths，两种来源在 receipt 明确分开。

父代理当前 staged c61 可应用 `refresh-delta.patch`，测试 staged e075 可应用 `formal-delta.patch`；两个只读 apply-check 都成功。完整补丁另有 `full-candidate.patch` / `full-formal.patch`。最终 impl SHA 为 `a35b8480875550a5b31790c8e57affab06a7b4541e52ae1cee1ffc08bfa0d2fa`。正式测试现在共 6 项新增，本代理未运行正式文件；剩余正式 red/green、相关集成与独立复核由父代理处理。

本次是 Module/host-contract 的实际资源调用计数，不是完整 Runtime/原生/AT 证据。phase 是 public onMountPhase 的实际调用参数与返回，未读取 protected phase。test hygiene 在 primary 观测之后，不能作为原失败自动恢复的证据。旧 6/2 与 c61 新红项均保留；本代理未改产品、index 或 GitHub。
