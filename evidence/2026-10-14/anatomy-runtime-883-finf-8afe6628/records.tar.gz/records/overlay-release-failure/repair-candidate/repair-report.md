Overlay 私有修复候选已冻结，产品工作树未改。

固定源为 `58d39e1fb06fdd437ae75ad6be26836cfd4e00ac`，实际四次运行的工作树均为 `6d150e127461c99d26122dd68642539c841f4190` 且前后 clean。每次加载 59 个 tracked inputs；candidate 只覆盖 Overlay `impl.ts`，其余 58 个输入逐一等于固定 Git blob。Node 启动器与 worker 均实际记录 24.21.0，pnpm 10.32.1。

| 原场景 | 原实现 | 私有候选 |
| --- | --- | --- |
| 原 6 项，fixture 字节不变 | 3 pass / 3 fail | 6 pass |
| 新增 secondary-error 配对，同一 fixture | 1 pass / 1 fail | 2 pass |

原始 layer release 在自身释放后抛出，原实现会跳过其后的 target alignment、position、available-space、portal、modal 以及 terminal logical cleanup。候选按现有顺序尽力完成这些 owned steps，然后抛出第一个原值。重入场景先完成旧贡献清理，再执行排队的新 provider reconcile；这不吞掉原异常。新增对照实际命中了新 provider attach 的第二个 Error：前面有 `0` 时仍抛 `0`，没有第一个错误时抛第二个 Error。失败的 replacement attach 在分配 layer 前抛出；已成功取得的 replacement portal 仍存在，随后由单独 hygiene 清理，不能宣称失败 acquisition 被事务回滚。

`candidate.patch` 只改 Overlay。`formal-test-candidate.patch` 为现有 `host-callback-reentrancy.test.ts` 增加 5 项，复用原 fixture 和原正常 reentry controls；正式补丁没有由本代理执行。两补丁在 6d clean 状态下 `git apply --check` 通过。正式回归覆盖释放失败、terminal logical cleanup、异常后重入、raw zero 优先级；实际 Anatomy target-alignment 清理证据来自保留的私有 6 项，不能冒充正式 fixture 有这项 binding。

这是 Module/host-contract 证据，不是完整 RuntimeSession 或原生浏览器旅程。正常 detach 保留逻辑订阅；terminal 才清除。独立 Module hook 的异常不证明全 Runtime 永久泄漏。本次没有扩展 deactivation、逐个 Boundary disposer 或 Escape cleanup 异常策略。所有 primary 观测在 test hygiene 之前，原 red 和实际工具链、命令、源码哈希均保留在 `repair-report.json`、`source-binding.json` 与各 run 目录。
