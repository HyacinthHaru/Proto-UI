// @vitest-environment node
import { afterAll, expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import path from 'node:path';
import { CapsVault, SYS_CAP } from '@proto.ui/module-base';
import { createAnatomyFamily, type OverlayTargetAlignmentBinding } from '@proto.ui/core';
import { AnatomyModuleImpl } from '@proto.ui/module-anatomy/impl';
import { OverlayModuleImpl } from '@proto.ui/module-overlay/impl';
import {
  OVERLAY_TARGET_HOST_CAP,
  OVERLAY_GLOBAL_MOUNT_CAP,
  OVERLAY_LAYER_SCHEDULER_CAP,
  OVERLAY_MODAL_CAP,
} from '@proto.ui/module-overlay/caps';
import {
  createSysCaps,
  makeCaps,
} from '<SOURCE_ROOT>/packages/modules/anatomy/test/utils/fake-caps';
const output = process.env.OVERLAY_RELEASE_OUTPUT!;
const observations: any[] = [];
const errorFact = (e: unknown) =>
  e instanceof Error
    ? { name: e.name, message: e.message, stack: e.stack }
    : { type: typeof e, value: e };
afterAll(() => {
  writeFileSync(
    path.join(output, 'observations.json'),
    JSON.stringify(observations, null, 2) + '\n'
  );
  writeFileSync(
    path.join(output, 'worker-environment.json'),
    JSON.stringify(
      {
        node: process.version,
        execPath: process.execPath,
        platform: process.platform,
        arch: process.arch,
        versions: process.versions,
        PATH: process.env.PATH,
      },
      null,
      2
    ) + '\n'
  );
});
function fixture() {
  const tape: any[] = [];
  const caps = new CapsVault();
  caps.attachBase([
    [
      SYS_CAP,
      {
        ensureSetup() {},
        ensureRuntime() {},
        deferAfterCallback(fn: () => void) {
          fn();
        },
      } as any,
    ],
  ]);
  const roles = ['root', 'content', 'surface', 'viewport', 'trigger', 'value', 'item', 'item-text'];
  const family = createAnatomyFamily('overlay-release-probe', {
    roles: Object.fromEntries(
      roles.map((role) => [
        role,
        { cardinality: { min: role === 'root' ? 1 : 0, max: role === 'root' ? 1 : '*' } },
      ])
    ),
  });
  const parents = new Map<object, object | null>(),
    all: AnatomyModuleImpl[] = [];
  function add(role: string, parent: object | null = null) {
    const token = {},
      target = {},
      sys = createSysCaps();
    parents.set(token, parent);
    const impl = new AnatomyModuleImpl(
      makeCaps({
        sys,
        instance: token,
        getParent: (t) => parents.get(t as object) ?? null,
        getPrototype: () => ({ name: role, setup() {} }),
        getRootTarget: () => target,
      }),
      role,
      { get: () => null, getAll: () => ({}), has: () => false, keys: () => [] } as any
    );
    impl.claim(family, { role });
    sys.__setExecPhase('callback');
    all.push(impl);
    return { token, target, impl };
  }
  const root = add('root'),
    owner = add('content', root.token),
    surface = add('surface', owner.token),
    viewport = add('viewport', surface.token),
    item = add('item', viewport.token),
    text = add('item-text', item.token),
    trigger = add('trigger', root.token),
    value = add('value', trigger.token);
  const part = (role: string) => {
    const p = owner.impl.partsOf(family, role)[0];
    if (!p) throw new Error('Missingpart ' + role);
    return p;
  };
  const physical = { alignment: 0, position: 0, available: 0 };
  const logical = { outside: 0, regions: 0, targets: 0 };
  const log = (kind: string, detail: any = {}) =>
    tape.push({ kind, capsEpoch: caps.epoch, ...detail });
  const lease = (obj: any, key: string, label: string) => {
    obj[key]++;
    log('acquire.' + label);
    let active = true;
    return () => {
      if (!active) return;
      active = false;
      obj[key]--;
      log('release.' + label);
    };
  };
  const boundary = {
    subscribeOutside: () => lease(logical, 'outside', 'outside'),
    setStackActive() {},
    registerRegion: (_target: unknown, options: any) =>
      lease(logical, 'regions', 'region.' + options.role),
  };
  const boundaryPort = {
    replaceImplicitRoot: () => lease(physical, 'alignment', 'alignment.region'),
  };
  const anatomyPort = {
    ...owner.impl.port,
    subscribeTargets: (...args: any[]) => {
      const off = (owner.impl.port.subscribeTargets as any)(...args);
      const account = lease(logical, 'targets', 'alignment.targets');
      return () => {
        account();
        off();
      };
    },
  };
  const positioning = {
    connect() {
      if (!physical.position) {
        physical.position = 1;
        log('acquire.position');
      }
    },
    disconnect() {
      log('call.position.disconnect');
      if (physical.position) {
        physical.position = 0;
        log('release.position');
      }
    },
    getSnapshot: () => null,
  };
  const available = {
    connect() {
      if (!physical.available) {
        physical.available = 1;
        log('acquire.available');
      }
    },
    disconnect() {
      log('call.available.disconnect');
      if (physical.available) {
        physical.available = 0;
        log('release.available');
      }
    },
    requestUpdate() {},
  };
  let layerCallback: (() => void) | null = null;
  function provider(name: string) {
    const active = { portal: 0, layer: 0, modal: 0 };
    let portalOff: (() => void) | null = null,
      modalOff: (() => void) | null = null;
    return {
      name,
      active,
      mount() {
        portalOff = lease(active, 'portal', name + '.portal');
      },
      unmount() {
        const off = portalOff;
        portalOff = null;
        off?.();
      },
      lock() {
        modalOff = lease(active, 'modal', name + '.modal');
      },
      unlock() {
        const off = modalOff;
        modalOff = null;
        off?.();
      },
      attach() {
        const off = lease(active, 'layer', name + '.layer');
        let done = false;
        return () => {
          if (done) return;
          done = true;
          off();
          layerCallback?.();
        };
      },
    };
  }
  const a = provider('a'),
    b = provider('b');
  const module = new OverlayModuleImpl(
    caps,
    'overlay-release-failure',
    boundary as any,
    boundaryPort as any,
    {} as any,
    anatomyPort as any,
    positioning as any,
    available as any
  );
  const install = (p = a) => {
    log('install', { provider: p.name });
    caps.attach([
      [
        OVERLAY_TARGET_HOST_CAP,
        {
          root: () => surface.target,
          resolve: (x: unknown) => (x === surface.target ? surface.target : null),
        },
      ],
      [OVERLAY_GLOBAL_MOUNT_CAP, p],
      [OVERLAY_LAYER_SCHEDULER_CAP, p],
      [OVERLAY_MODAL_CAP, p],
    ]);
  };
  install();
  const binding: OverlayTargetAlignmentBinding = {
    family,
    surface: part('surface'),
    scrollport: part('viewport'),
    blockReference: part('trigger'),
    inlineReference: part('value'),
    blockTarget: part('item'),
    inlineTarget: part('item-text'),
    atStart: true,
    atEnd: true,
    constraints: {
      boundary: 'layout-viewport',
      margin: 10,
      minimumTargetSpanCount: 5,
      inlineOverflow: 'preserve-start',
      expandOnScroll: true,
    },
    onAlignment(status) {
      log('alignment.callback', { status });
    },
  };
  const snapshot = () => ({
    a: { ...a.active },
    b: { ...b.active },
    physical: { ...physical },
    logical: { ...logical },
    capsEpoch: caps.epoch,
  });
  const activate = () => {
    module.configure({
      defaultOpen: true,
      portal: true,
      modal: true,
      availableSpace: true,
      anchored: true,
    });
    module.registerTrigger(trigger.target);
    module.registerAnchor(trigger.target);
    module.registerContent(surface.target);
    module.registerTargetAlignment(binding);
    module.setViewActive(true);
    module.onMountPhase('mounted', 1);
  };
  const cleanup = () => {
    layerCallback = null;
    const errors: unknown[] = [];
    for (const fn of [
      () => module.onMountPhase('detached', 2),
      () => module.onProtoPhase('unmounted'),
      ...all.reverse().map((impl) => () => impl.dispose()),
    ]) {
      try {
        fn();
      } catch (e) {
        errors.push(errorFact(e));
      }
    }
    return errors;
  };
  return {
    module,
    a,
    b,
    install,
    activate,
    snapshot,
    tape,
    log,
    cleanup,
    setLayerCallback(fn: () => void) {
      layerCallback = fn;
    },
  };
}
const cases = [
  { name: 'detach normal', boundary: 'detach', fault: 'none', reenter: false },
  { name: 'detach layer Error', boundary: 'detach', fault: 'error', reenter: false },
  { name: 'terminal hook normal', boundary: 'terminal', fault: 'none', reenter: false },
  { name: 'terminal hook layer zero', boundary: 'terminal', fault: 'zero', reenter: false },
  { name: 'detach replacement reentry normal', boundary: 'detach', fault: 'none', reenter: true },
  {
    name: 'detach replacement reentry layer Error',
    boundary: 'detach',
    fault: 'error',
    reenter: true,
  },
] as const;
for (const test of cases)
  it(test.name, () => {
    const f = fixture();
    const initiating = test.fault === 'zero' ? 0 : new Error('owned layer release failure');
    let threw = false,
      caught: unknown;
    let row: any;
    try {
      f.activate();
      const acquired = f.snapshot();
      expect(acquired.a).toEqual({ portal: 1, layer: 1, modal: 1 });
      expect(acquired.physical).toEqual({ alignment: 1, position: 1, available: 1 });
      expect(acquired.logical).toEqual({ outside: 1, regions: 2, targets: 1 });
      f.setLayerCallback(() => {
        f.log('layer.callback');
        if (test.reenter) {
          f.install(f.b);
          f.module.onMountPhase('mounted', 2);
          f.log('reentry.mounted-returned', { epoch: 2 });
        }
        if (test.fault !== 'none') throw initiating;
      });
      const begin = f.tape.length;
      try {
        if (test.boundary === 'terminal') f.module.onProtoPhase('unmounted');
        else f.module.onMountPhase('detached', 1);
      } catch (error) {
        threw = true;
        caught = error;
      }
      const after = f.snapshot();
      row = {
        ...test,
        acquired,
        after,
        threw,
        firstIdentityPreserved: threw && Object.is(caught, initiating),
        caught: threw ? errorFact(caught) : null,
        tape: f.tape.slice(begin),
      };
      observations.push(row);
      expect(threw).toBe(test.fault !== 'none');
      if (test.fault !== 'none') expect(Object.is(caught, initiating)).toBe(true);
      expect(after.a).toEqual({ portal: 0, layer: 0, modal: 0 });
      expect(after.b).toEqual(
        test.reenter ? { portal: 1, layer: 1, modal: 1 } : { portal: 0, layer: 0, modal: 0 }
      );
      expect(after.physical).toEqual(
        test.reenter
          ? { alignment: 1, position: 1, available: 1 }
          : { alignment: 0, position: 0, available: 0 }
      );
      expect(after.logical).toEqual(
        test.boundary === 'terminal'
          ? { outside: 0, regions: 0, targets: 0 }
          : { outside: 1, regions: 2, targets: 1 }
      );
    } finally {
      const errors = f.cleanup();
      if (row) {
        row.testHygieneErrors = errors;
        row.afterTestHygiene = f.snapshot();
      } else
        observations.push({
          name: test.name,
          setupIncomplete: true,
          tape: f.tape,
          cleanupErrors: errors,
        });
    }
  });
