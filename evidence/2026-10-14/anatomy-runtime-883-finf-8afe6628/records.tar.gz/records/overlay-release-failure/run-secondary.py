from pathlib import Path
import os,subprocess,json,datetime,hashlib,signal,sys
P=Path(__file__).parent;R=P/'secondary-pair';R.mkdir(exist_ok=True); W=Path('<SOURCE_ROOT>');H='58d39e1fb06fdd437ae75ad6be26836cfd4e00ac';variant=sys.argv[1];assert variant in ['baseline','after']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*a):return subprocess.check_output(['git',*a],cwd=W,text=True).strip()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();env['PATH']="<REDACTED_PATH>";env['OVERLAY_RELEASE_OUTPUT']=str(R/variant);O=Path(env['OVERLAY_RELEASE_OUTPUT']);O.mkdir(exist_ok=False)
bootstrap=[]
for file in ['vitest.config.ts','apps/www/scripts/runtime-retry-urls.mjs']:
 data=subprocess.check_output(['git','show',H+':'+file],cwd=W);assert (W/file).read_bytes()==data;bootstrap.append({'path':file,'sha256':hashlib.sha256(data).hexdigest(),'equalsFixedGit':True})
command=['corepack','pnpm@10.32.1','exec','vitest','run','--config',str(P/('secondary-'+variant+'.config.ts')),'--maxWorkers=1','--minWorkers=1']
r={'startedAt':now(),'fixedSourceHead':H,'fixedSourceTree':git('rev-parse',H+'^{tree}'),'physicalHeadBefore':git('rev-parse','HEAD'),'physicalStatusBefore':git('status','--porcelain=v1'),'command':command,'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'pnpm':subprocess.check_output(['corepack','pnpm@10.32.1','--version'],env=env,text=True).strip(),'runnerPid':os.getpid(),'fixtureSha256':digest(P/'secondary-error.test.ts'),'configSha256':digest(P/('secondary-'+variant+'.config.ts')),'bootstrapFiles':bootstrap,'timeoutSeconds':120,'overlayOverrideSha256':digest(P/'repair-candidate/impl.ts') if variant=='after' else None}
(O/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'event':'started',**r}),flush=True)
with (O/'run.log').open('w') as log:
 proc=subprocess.Popen(command,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 r['childPid']=proc.pid;(O/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 try:r['exit']=proc.wait(timeout=120)
 except subprocess.TimeoutExpired:
  r['deadlineExceeded']=True;os.killpg(proc.pid,signal.SIGTERM)
  try:r['exit']=proc.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);r['exit']=proc.wait(timeout=10)
r.update(completedAt=now(),physicalHeadAfter=git('rev-parse','HEAD'),physicalStatusAfter=git('status','--porcelain=v1'),logSha256=digest(O/'run.log'))
(O/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'event':'completed',**r}),flush=True)
