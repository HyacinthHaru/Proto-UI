# Overlay resource cleanup — independent final working review

**0 remaining concrete finding；partial / ABSTAIN。** 审查对象是工作区a35实现、98fa测试及Six notes；不是任务派发时index中的旧c61；本次最终回读index也已更新到这些字节。三文件Git blob/SHA详见JSON，最终提交需另外精确绑定。

原始c61的P2 `ISSUE883-OVERLAY-RELEASE-REFRESH-OWNER-001` 保留在initial报告；现a35已闭合。真实对照中base释放portal后留下A.layer/modal，c61反而又acquire A.portal；新版本完成A.portal→A.modal→A.layer释放，再用已提交的B缓存取得B三资源，原E身份不变。每个后续release/缓存提交前保留caps epoch检查，不先切provider后清旧owner，不无界重试。

通用局部helper只负责这些Overlay资源步骤：独立failed标记使throw0不丢失；物理cleanup错误不跳过其它已取得步骤，terminal再尝试逻辑Boundary/outside/Anatomy订阅清理。detach仍保留instance逻辑订阅。reconciling标记在finally解除后才flush，首个原错优先；只有secondary错误时继续抛该错误。原lease在callback前清除/撤销，保留旧owner清理和重入隔离。

现有23case主体逐字保留，新增6项均通过实际CapsVault/Module公开hook注入，断言在throwing callback外，正常及secondary-only对照仍在。故障provider先实际释放自身贡献再throw，测试证明后续清理不被跳过，不承诺任意先throw却不释放的provider被强制回收；afterTestHygiene不算主结果成功。

实际历史：原6d+首版28test为4fail24pass；c61+最终29test为1fail28pass；a35实际Overlay5files54pass。原私有6、secondary2、caps1三次固定fixture运行在a35共9pass，59加载源逐SHA对账并与当前实现组合一致，不把三run说成单个完整suite。完整Runtime/Native/AT/CI接受并未建立。

T仍draft，implementation仍needs-review；仅说明从5项变6项及caps replacement覆盖，不新建一般Runtime异常策略。root的67/types/spec/projection检查是单独执行，这份报告未提前计绿。没有改产品、重跑测试或GitHub写入。
