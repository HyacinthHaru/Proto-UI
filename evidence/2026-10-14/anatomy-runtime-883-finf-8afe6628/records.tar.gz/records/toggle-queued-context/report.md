Toggle Group 的 queued Context 退休缺口已实证，私有候选通过原5case。

固定 Git c82，原Root3c1a39e5；15:00:43–15:00:49UTC baseline为2pass/3fail，15:03:14–15:03:20UTC candidate73954948为5pass。另90项原测试仅过滤，不是通过。两次使用相同203e5ffa观察fixture、9a683ea0配置；395个实际trackedinput逐一绑定，before/after唯一变化为ToggleRoot。

原序列Contexta→emit[b]→requestb返回→Contextb→unmount/dispose/remount，三项退休都留下已发出的[b]。原外层a已被现有guard挡住，缺口是nestedb在queuedsubscriber执行前过早完成。候选在Toggle自己的context.update周围持有publicationDepth，保存多个带owner/epochguard的completion，外层链正常完成后依序检查/交付。Normal仍[a]；两层nested仍[b],[c],[a]且acceptedtrue，但事件现在位于Contexta/b/c之后、外层requesta返回之前。这是所需的有意时序修复，不声称所有观察顺序不变。

三种退休的emittedAtReturn都为空；remount实际epoch1→2，随后freshc仍acceptedtrue/只发[c]/canonical[c]。没有globalContextAPI、timer、lock、numeric或selectionpolicy修改。通知抛错矩阵、任意外部同实例State/Context组合及跨host异步交付未覆盖。

`root-candidate.patch`与`formal-test-candidate.patch`均只读apply-check通过。正式patch在现有Runtime helper上追加5case，callbackscope返回通过内部局部赋值捕获、断言在callback外，并保存同步返回时的事件快照。本代理没有运行正式文件；父代理负责原路径red/green及集成。

物理工作树前后均为c82+父代理Overlay3dirty，未冒称clean。load hook实际返回固定Gitc82bytes；若Overlayimpl被加载，也未使用磁盘上的4c71候选。完整对账在source-binding.json，物理dirty的字节另标为运行后观察。所有本代理runner/child已结束。