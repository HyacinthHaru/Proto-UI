import base from '<SOURCE_ROOT>/vitest.config.ts';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
const repo = '<SOURCE_ROOT>',
  revision = 'c82b9919294b78277a0778ed26185348663114db',
  output = process.env.TOGGLE_ERROR_OUTPUT!;
const tracked = new Set(
  execFileSync('git', ['ls-tree', '-r', '--name-only', revision], {
    cwd: repo,
    encoding: 'utf8',
  })
    .trim()
    .split('\n')
);
const loaded = new Map();
const save = () =>
  fs.writeFileSync(
    path.join(output, 'loaded-inputs.json'),
    JSON.stringify([...loaded.values()], null, 2) + '\n'
  );
process.on('exit', save);
export default {
  ...base,
  root: repo,
  cacheDir: path.join(output, 'vite-cache'),
  plugins: [
    {
      name: 'fixed-field-pending-source',
      enforce: 'pre',
      load(id) {
        const relative = path.relative(repo, id.split('?')[0].replace(/^\/@fs/, ''));
        if (!tracked.has(relative)) return null;
        const original = execFileSync('git', ['show', revision + ':' + relative], {
          cwd: repo,
        });
        const isTest =
          relative === 'packages/prototypes/base/test/notification-retirement-lifecycle.test.ts';
        const isRoot =
          relative === 'packages/prototypes/base/src/toggle-group/root.proto.ts' &&
          process.env.TOGGLE_ERROR_VARIANT === 'after';
        const overridden = isTest || isRoot;
        const bytes = overridden
          ? fs.readFileSync(
              '<TASK_STATE>/toggle-queued-context/error-pair/' +
                (isTest ? 'probe.test.ts' : 'candidate-root.proto.ts')
            )
          : original;
        loaded.set(relative, {
          path: relative,
          source: isTest
            ? 'private-observed-formal-case'
            : isRoot
              ? 'private-toggle-root-candidate'
              : revision,
          gitOriginalSha256: crypto.createHash('sha256').update(original).digest('hex'),
          sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
        });
        save();
        return bytes.toString();
      },
    },
    ...(base.plugins ?? []),
  ],
  test: {
    ...base.test,
    include: ['packages/prototypes/base/test/notification-retirement-lifecycle.test.ts'],
    testNamePattern: '^Toggle Group completes eligible queued notifications after sink ',
    maxWorkers: 1,
    minWorkers: 1,
    fileParallelism: false,
    reporters: ['verbose', 'json'],
    outputFile: { json: path.join(output, 'vitest.json') },
  },
};
