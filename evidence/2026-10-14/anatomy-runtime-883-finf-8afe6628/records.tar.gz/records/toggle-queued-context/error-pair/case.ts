
it.each(['normal', 'error', 'zero'] as const)(
  'Toggle Group completes eligible queued notifications after sink %s',
  async (fault) => {
    const { make, setActionCallback } = runtimeHarness();
    const root = make(toggleGroupRoot);
    const items = ['a', 'b', 'c'].map((value) => make(toggleGroupItem, root.target, { value }));
    const failure = fault === 'zero' ? 0 : new Error('nested valueChange sink failure');
    let armed = false;
    const contexts: string[] = [];
    const emitted: string[][] = [];
    const returns: Array<{ value: string; accepted?: boolean; threw: boolean }> = [];
    const request = (value: string) => {
      let accepted: boolean | undefined;
      try {
        root.session.invokeInCallbackScope(() => {
          accepted = root.exposes.requestToggle(value);
        });
      } catch (error) {
        returns.push({ value, threw: true });
        throw error;
      }
      returns.push({ value, accepted, threw: false });
      return accepted;
    };
    setActionCallback((name, payload) => {
      if (name !== 'valueChange') return;
      emitted.push([...payload.value]);
      if (fault !== 'normal' && payload.value[0] === 'b') throw failure;
    });
    const observer = make(
      definePrototype({
        name: 'toggle-group-queued-error-observer',
        setup(def) {
          def.context.subscribe(TOGGLE_GROUP_CONTEXT, (_run, next) => {
            if (!armed || next.value.length !== 1 || contexts.includes(next.value[0])) return;
            const value = next.value[0];
            contexts.push(value);
            if (value === 'a') request('b');
            else if (value === 'b') request('c');
          });
        },
      }),
      root.target
    );
    const parts = [root, ...items, observer];
    try {
      for (const part of parts) await part.session.mount();
      armed = true;
      let threw = false;
      let caught: unknown;
      try {
        request('a');
      } catch (error) {
        threw = true;
        caught = error;
      }
      const emittedAtReturn = emitted.map((value) => [...value]);
      expect(contexts).toEqual(['a', 'b', 'c']);
      expect(root.exposes.getValue()).toEqual(['c']);
      expect(threw).toBe(fault !== 'normal');
      if (fault !== 'normal') expect(caught).toBe(failure);
      expect(emittedAtReturn).toEqual(fault === 'normal' ? [['b'], ['c'], ['a']] : [['b'], ['c']]);
    } finally {
      armed = false;
      for (const part of [...parts].reverse()) await part.session.dispose();
    }
  }
);
