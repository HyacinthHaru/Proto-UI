真实 throw-B host sink pair 未复现候选 drain 停在 B 的假设；不据此新增修复。

固定c82 Git loader，before Root3c1a39e5、after Root73954948，私有fixture12fc0652完全相同，共395个tracked inputs逐一绑定，唯一before/after变化为Root。物理产品5dirty原样保留，未冒称clean。

两次实际运行各为1pass/2fail/90skip。错误/0两项的红来自初始探索断言错误地要求外抛且只发B/C；这些不是产品红，原日志没有改为绿。三项真实事实在两个版本均一致：Context[A,B,C]；sink进入[B,C,A]；B/C/A各request都返回true；最终canonical[C]；Error和0确实在B的sink抛出一次，但外层未抛，因而不存在需要比较的outward原异常身份。

固定源码 `packages/modules/expose-event/src/impl.ts` 的sink调用位于50行，紧接catch隔离host sink失败，注释明确它不会重入prototype执行。这些异常因此没有到达Toggle的通知for-loop，也没有进入ContextCenter H的错误收集。739仅保留此前有意的Context链末通知时序变化，没有新增中断C/A。

`notification-retirement-lifecycle.test.ts` 是保留的错误期望草案，**不要apply或提交**。没有制作drain增量patch，没有改ContextCenter/Field/Runtime，亦未重跑一遍求绿。直接Context subscriber抛错、非法emit/lifecycle路径不是本组实证范围。所有runner/child已终态退出。