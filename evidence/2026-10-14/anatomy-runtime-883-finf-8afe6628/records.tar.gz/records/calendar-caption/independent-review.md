# Calendar caption cleanup — independent working review

**0 specific source finding；partial / ABSTAIN。** 本次为 human-assisted/current-user、unassessed/advisory 的只读两文件审查，基线 bd47d1ee。当前 source SHA 为 `658f9046e493cbd6b71336ba0c5b9fce7aafc641157fd8fb026ded39b499e40c`，test SHA 为 `99717b25f45f432662fe3358d86319546a378ac636b96dc83f3cf2bda91170dd`，Git blob 及 raw evidence 哈希见 JSON。

这是公开的应用层 Calendar/controlled-control 组合 helper。`calendar-month-extent.v0.md` 明确此片段尚未 catalog；现有文档说明 dispose 用于 teardown。本增量治理 helper 持有的两个订阅，不用 draft C-LIFECYCLE-0002-J 扩张一般 Runtime callback 异常政策，也不修改 Calendar 月份/选择语义或 Select 实现。

候选先置原 disposed 标记并一次性 splice 已取得订阅，再分别尝试 unsubscribe；用独立 boolean 保存第一个错误，所以 undefined/null/false/0/空串不会丢失。全部尝试后重抛同一值。原重入/重复 dispose 惰性、同步/请求 terminal guard、顺序与正常路径均保留。它保证尝试所有回调，不保证一个在实际释放前抛错的任意用户 disposer 必然释放成功。

新增六例通过公开 subscribe 返回故障 disposer：先删真实 Set listener，再抛选定值，第二个也抛另一个错误。断言全部在可捕获回调之外，检查两次 release、两个 Set 为空、原值身份、重复 dispose、历史回调及 sync/requestMonth 的 inertness。该注入合法且有判别力，但不是 native/Runtime disposer 自然抛错的证据。原 28 例保留，包括真实 Calendar/Select expose 的 test-DOM 组合。

实际同测试 baseline 为 6 fail / 28 pass，失败是第二 release 未执行；候选为 caption34 + Calendar19，共2文件53pass / exit0。原计划 calendar-month-extent.test.ts 不存在、未收集，无额外12项 claim。已有六项私有 probe 从全部 [0,1] 残留变为 [0,0]，原值和 terminal inertness 保留；这里只读取 root 既有执行，没有 reviewer 新跑。types 日志末尾为 Astro878/0/0/11；未操作其进程。

构造失败原 catch 的 cleanup 与 initiating error 优先级未重新定义。完整 Calendar、其它生命周期 callback、全平台 CI/native/AT 与 Finf 全面验收都不能由本局部报告建立。未修改产品/原日志或执行额外验证；后续源变化需重新绑定。
