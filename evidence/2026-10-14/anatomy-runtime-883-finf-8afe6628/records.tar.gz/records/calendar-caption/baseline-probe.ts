import assert from 'node:assert/strict';
import { bindCalendarCaption } from '<SOURCE_ROOT>/packages/prototypes/base/src/calendar/caption-composition.ts';
const rows: unknown[] = [];
for (const failure of [new Error('first release'), undefined, null, false, 0, '']) {
  const events: string[] = [];
  const listeners = [new Set<() => void>(), new Set<() => void>()];
  const historical: Array<() => void> = [];
  const source = {
    month: { get: () => '2024-02', subscribe(fn: () => void) { listeners[0].add(fn); historical.push(fn); return () => { events.push('month.unsubscribe'); listeners[0].delete(fn); throw failure; }; } },
    disabled: { get: () => false, subscribe(fn: () => void) { listeners[1].add(fn); historical.push(fn); return () => { events.push('disabled.unsubscribe'); listeners[1].delete(fn); throw new Error('second release'); }; } },
    requestMonth() { events.push('request'); return true; },
  };
  const control = { setValue() { events.push('setValue'); }, setDisabled() { events.push('setDisabled'); } };
  const binding = bindCalendarCaption(source, { month: control, year: control });
  events.length = 0;
  let thrown = false, observed: unknown;
  try { binding.dispose(); } catch (error) { thrown = true; observed = error; }
  const cleanupEvents = [...events];
  binding.dispose(); for (const fn of historical) fn(); binding.sync();
  const request = binding.requestMonth('3');
  rows.push({ failure: failure instanceof Error ? 'Error' : String(failure), thrown, originalIdentity: observed === failure, cleanupEvents, listeners: listeners.map(x => x.size), retiredInert: events.length === cleanupEvents.length && request === false });
}
console.log(JSON.stringify(rows, null, 2));
for (const row of rows as any[]) {
 assert.equal(row.thrown, true);
 assert.equal(row.originalIdentity, true);
 assert.deepEqual(row.cleanupEvents, ['month.unsubscribe', 'disabled.unsubscribe']);
 assert.deepEqual(row.listeners, [0, 0]);
 assert.equal(row.retiredInert, true);
}
