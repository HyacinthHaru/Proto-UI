import { afterAll, afterEach, expect, it } from "vitest";
import { writeFileSync } from "node:fs";
import path from "node:path";
import { definePrototype } from "@proto.ui/core";
import { createRuntimeSession } from "@proto.ui/runtime";
import {
  AdaptToWebComponent,
  setElementProps,
} from "@proto.ui/adapter-web-component";
import { asFieldRoot, fieldRoot, fieldControl } from "@proto.ui/prototypes-base/field";
import {
  ANATOMY_INSTANCE_TOKEN_CAP,
  ANATOMY_PARENT_CAP,
  ANATOMY_GET_PROTO_CAP,
  ANATOMY_ROOT_TARGET_CAP,
} from "@proto.ui/module-anatomy";
import {
  CONTEXT_INSTANCE_TOKEN_CAP,
  CONTEXT_PARENT_CAP,
} from "@proto.ui/module-context";
import {
  EVENT_ROOT_TARGET_CAP,
  EVENT_GLOBAL_TARGET_CAP,
} from "@proto.ui/module-event";
import { EXPOSE_EVENT_SINK_CAP } from "@proto.ui/module-expose-event";
import {
  AS_TRIGGER_INSTANCE_CAP,
  AS_TRIGGER_PARENT_CAP,
  AS_TRIGGER_GET_PROTO_CAP,
} from "@proto.ui/module-as-trigger";
import { EXPOSES_RECORD_SINK_CAP } from "@proto.ui/module-expose-state";
import {
  TEXT_CONTROL_HOST_CAP,
  TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
} from "@proto.ui/module-text-control";

const output = process.env.FIELD_PENDING_OUTPUT!;
const sessions = new Set<ReturnType<typeof createRuntimeSession>>();
const observations: any[] = [];
const stops: Array<() => void> = [];
const flush = async () => {
  for (let i = 0; i < 20; i++) await Promise.resolve();
};
const errorFact = (error: unknown) =>
  error instanceof Error
    ? { name: error.name, message: error.message, stack: error.stack }
    : { thrownType: typeof error, value: error };
afterEach(async () => {
  for (const stop of stops.splice(0)) stop();
  for (const session of [...sessions].reverse()) await session.dispose();
  sessions.clear();
  document.body.replaceChildren();
  await flush();
});
afterAll(() => {
  writeFileSync(
    path.join(output, "observations.json"),
    JSON.stringify(observations, null, 2) + "\n",
  );
  writeFileSync(
    path.join(output, "worker-environment.json"),
    JSON.stringify(
      {
        node: process.version,
        execPath: process.execPath,
        platform: process.platform,
        arch: process.arch,
        versions: process.versions,
        PATH: process.env.PATH,
      },
      null,
      2,
    ) + "\n",
  );
});
AdaptToWebComponent(fieldRoot);
AdaptToWebComponent(fieldControl);
function runtimeHarness() {
  const parents = new Map<any, any>(),
    protos = new Map<any, any>();
  let actionCallback = (_name: string) => {};
  const actions: string[] = [];
  const requests: any[] = [];
  const eventTape: any[] = [];
  function make(proto: any, parent: any = null, props: any = {}) {
    const listeners = new Map<string, Set<any>>();
    const target = {
      addEventListener(type: string, fn: any) {
        if (!listeners.has(type)) listeners.set(type, new Set());
        listeners.get(type)!.add(fn);
      },
      removeEventListener(type: string, fn: any) {
        listeners.get(type)?.delete(fn);
      },
      dispatchEvent(event: Event) {
        for (const fn of [...(listeners.get(event.type) ?? [])]) fn(event);
        return true;
      },
    } as unknown as EventTarget;
    parents.set(target, parent);
    protos.set(target, proto);
    let exposes: any,
      connection: any,
      textValue = "";
    const session = createRuntimeSession(proto, {
      prototypeName: proto.name,
      getRawProps: () => props,
      schedule: (fn) => fn(),
      scheduleDelay: (ms, fn) => {
        const id = setTimeout(fn, ms);
        return { cancel: () => clearTimeout(id) };
      },
      commit: (_c, s) => s?.done(),
      onRuntimeReady(w) {
        if (proto === fieldControl)
          w.attach("text-control", [
            [
              TEXT_CONTROL_HOST_CAP,
              {
                attach(c: any) {
                  connection = c;
                  textValue = c.patch.value ?? c.patch.defaultValue ?? "";
                  return {
                    update(patch: any) {
                      if (typeof patch.value === "string")
                        textValue = patch.value;
                    },
                    snapshot: () => ({ value: textValue, composing: false }),
                    dispose() {},
                  };
                },
              },
            ],
            [
              TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
              (fn: () => void) => session.invokeInCallbackScope(fn),
            ],
          ]);
        w.attach("anatomy", [
          [ANATOMY_INSTANCE_TOKEN_CAP, target],
          [ANATOMY_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [ANATOMY_GET_PROTO_CAP, (t: any) => protos.get(t)],
          [ANATOMY_ROOT_TARGET_CAP, (t: any) => t],
        ]);
        w.attach("context", [
          [CONTEXT_INSTANCE_TOKEN_CAP, target],
          [CONTEXT_PARENT_CAP, (t: any) => parents.get(t) ?? null],
        ]);
        w.attach("event", [
          [EVENT_ROOT_TARGET_CAP, () => target],
          [EVENT_GLOBAL_TARGET_CAP, () => target],
        ]);
        w.attach("as-trigger", [
          [AS_TRIGGER_INSTANCE_CAP, target],
          [AS_TRIGGER_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [AS_TRIGGER_GET_PROTO_CAP, (t: any) => protos.get(t)],
        ]);
        w.attach("expose-state", [
          [
            EXPOSES_RECORD_SINK_CAP,
            (x: any) => {
              exposes = x;
            },
          ],
        ]);
        w.attach("expose-event", [
          [
            EXPOSE_EVENT_SINK_CAP,
            (name: string, payload: unknown) => {
              eventTape.push({ kind: "event", name, payload });
              if (name === "validationRequest") requests.push(payload);
              actions.push(name);
              actionCallback(name);
            },
          ],
        ]);
      },
    });
    sessions.add(session);
    return {
      session,
      target,
      input(value: string) {
        textValue = value;
        connection.onEvent({
          type: "input",
          value,
          composing: true,
          data: "x",
          inputType: "insertText",
        });
      },
      get exposes() {
        return exposes;
      },
    };
  }

  return {
    make,
    actions,
    requests,
    eventTape,
    setActionCallback(fn: (name: string) => void) {
      actionCallback = fn;
    },
  };
}


const composedRoot = definePrototype({
  name: 'field-extra-signal-owner',
  setup(def) {
    const inherited = asFieldRoot();
    const signal = def.state.bool('externalSignal', false);
    def.expose.state('externalSignal', signal);
    def.expose.method('startExternalSignal', () => signal.set(true, 'private public control'));
    return inherited.render;
  },
});
for (const operation of ['normal', 'cancel'] as const) {
  it(`public same-instance external State: ${operation}`, async () => {
    const h = runtimeHarness();
    const root = h.make(composedRoot, null, {
      externalValidation: true,
      validationMode: 'manual',
    });
    const control = h.make(fieldControl, root.target, { defaultValue: 'same' });
    await root.session.mount();
    await control.session.mount();
    const api = root.exposes;
    const tape = h.eventTape;
    let request: string | null = null;
    let signalObserved = 0, pendingObserved = 0;
    stops.push(api.externalSignal.subscribe((event: any) => {
      if (event.type !== 'next' || event.next !== true) return;
      signalObserved++;
      tape.push({ kind: 'signal.callback.begin' });
      root.session.invokeInCallbackScope(() => { request = api.validate(); });
      tape.push({ kind: 'validate.returned', request });
    }));
    stops.push(api.pending.subscribe((event: any) => {
      if (event.type !== 'next') return;
      tape.push({ kind: 'pending.callback', next: event.next });
      if (event.next !== true || pendingObserved) return;
      pendingObserved++;
      if (operation === 'cancel') {
        tape.push({ kind: 'cancel.begin' });
        root.session.invokeInCallbackScope(() => api.cancelValidation());
        tape.push({ kind: 'cancel.returned' });
      }
    }));
    h.requests.length = 0; tape.length = 0;
    root.session.invokeInCallbackScope(() => api.startExternalSignal());
    tape.push({ kind: 'externalSignal.returned' });
    const pending = api.pending.get();
    const beforeResolution = [...tape];
    let accepted: boolean | undefined;
    root.session.invokeInCallbackScope(() => {
      accepted = api.resolveValidation(request, { invalid: false });
    });
    observations.push({ operation, request, signalObserved, pendingObserved,
      pendingBeforeResolve: pending, accepted, requests: [...h.requests],
      tape: beforeResolution,
      scope: 'Observation of existing public API ordering; no new batch-notification policy asserted.' });
    expect(signalObserved).toBe(1);
    expect(pendingObserved).toBe(1);
    expect(typeof request).toBe('string');
    if (operation === 'normal') {
      expect(pending).toBe(true);
      expect(accepted).toBe(true);
      expect(h.requests).toEqual([{ requestId: request, value: 'same', reason: 'manual' }]);
    } else {
      expect(pending).toBe(false);
      expect(accepted).toBe(false);
    }
  });
}
