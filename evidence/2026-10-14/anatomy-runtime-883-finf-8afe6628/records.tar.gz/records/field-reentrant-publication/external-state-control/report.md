# Public external State boundary observation

真实执行终态：2026-10-14 13:05:35–13:05:43 UTC，2/2控制通过、exit0。固定58d所有Git输入+Field f01c候选单override；实际物理checkout已是81cea467并有root正在编辑的Toggle文件，此事实保留，没有误记为干净58d工作树。378条加载输入逐SHA核验，亦全部与81提交字节相同，不重标为另一份执行。

真实asFieldRoot wrapper另建owned externalSignal，公开expose state让App订阅，并用公开expose method在callback scope内set。没有Owned.watch、没有更改借用dirty、没有私有kernel或手工调用lifecycle。

normal顺序：signal callback → validationRequest → validate返回 → queued pending callback → signal方法返回，结果可接受。cancel顺序相同，随后pending callback调用cancel、pending=false，旧resolve=false。事件确实先于尚未执行的取消通知；此时“取消使旧结果失效”仍成立。两个测试是合法API/实际顺序控制，不是假定新全batch事件策略的红绿测试。

局部publicationDepth无法观察外部同instance State队列，故已提交Field-owned publication链修复不能扩称全State链保证。已查公开State/RunHandle/AsHook接口没有通用after-drain callback；不能偷用私有队列或加microtask而仍声称正常同步约定未变。若要更强通知排序，需要独立界定治理边界；本观察不自行扩大draftC-FIELD或全局State语义。

结果partial/ABSTAIN，线程额外范围应保持开放。原Field五项actualred/green和81提交局部有效性不被抹掉；该probe不解释LinuxChecking超时，也不是native/AT或平台批准。
