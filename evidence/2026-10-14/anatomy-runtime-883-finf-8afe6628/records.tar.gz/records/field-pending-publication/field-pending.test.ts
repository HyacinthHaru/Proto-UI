import { afterAll, afterEach, expect, it } from "vitest";
import { writeFileSync } from "node:fs";
import path from "node:path";
import { createRuntimeSession } from "@proto.ui/runtime";
import {
  AdaptToWebComponent,
  setElementProps,
} from "@proto.ui/adapter-web-component";
import { fieldRoot, fieldControl } from "@proto.ui/prototypes-base/field";
import {
  ANATOMY_INSTANCE_TOKEN_CAP,
  ANATOMY_PARENT_CAP,
  ANATOMY_GET_PROTO_CAP,
  ANATOMY_ROOT_TARGET_CAP,
} from "@proto.ui/module-anatomy";
import {
  CONTEXT_INSTANCE_TOKEN_CAP,
  CONTEXT_PARENT_CAP,
} from "@proto.ui/module-context";
import {
  EVENT_ROOT_TARGET_CAP,
  EVENT_GLOBAL_TARGET_CAP,
} from "@proto.ui/module-event";
import { EXPOSE_EVENT_SINK_CAP } from "@proto.ui/module-expose-event";
import {
  AS_TRIGGER_INSTANCE_CAP,
  AS_TRIGGER_PARENT_CAP,
  AS_TRIGGER_GET_PROTO_CAP,
} from "@proto.ui/module-as-trigger";
import { EXPOSES_RECORD_SINK_CAP } from "@proto.ui/module-expose-state";
import {
  TEXT_CONTROL_HOST_CAP,
  TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
} from "@proto.ui/module-text-control";

const output = process.env.FIELD_PENDING_OUTPUT!;
const sessions = new Set<ReturnType<typeof createRuntimeSession>>();
const observations: any[] = [];
const stops: Array<() => void> = [];
const flush = async () => {
  for (let i = 0; i < 20; i++) await Promise.resolve();
};
const errorFact = (error: unknown) =>
  error instanceof Error
    ? { name: error.name, message: error.message, stack: error.stack }
    : { thrownType: typeof error, value: error };
afterEach(async () => {
  for (const stop of stops.splice(0)) stop();
  for (const session of [...sessions].reverse()) await session.dispose();
  sessions.clear();
  document.body.replaceChildren();
  await flush();
});
afterAll(() => {
  writeFileSync(
    path.join(output, "observations.json"),
    JSON.stringify(observations, null, 2) + "\n",
  );
  writeFileSync(
    path.join(output, "worker-environment.json"),
    JSON.stringify(
      {
        node: process.version,
        execPath: process.execPath,
        platform: process.platform,
        arch: process.arch,
        versions: process.versions,
        PATH: process.env.PATH,
      },
      null,
      2,
    ) + "\n",
  );
});
AdaptToWebComponent(fieldRoot);
AdaptToWebComponent(fieldControl);
function runtimeHarness() {
  const parents = new Map<any, any>(),
    protos = new Map<any, any>();
  let actionCallback = (_name: string) => {};
  const actions: string[] = [];
  const requests: any[] = [];
  const eventTape: any[] = [];
  function make(proto: any, parent: any = null, props: any = {}) {
    const listeners = new Map<string, Set<any>>();
    const target = {
      addEventListener(type: string, fn: any) {
        if (!listeners.has(type)) listeners.set(type, new Set());
        listeners.get(type)!.add(fn);
      },
      removeEventListener(type: string, fn: any) {
        listeners.get(type)?.delete(fn);
      },
      dispatchEvent(event: Event) {
        for (const fn of [...(listeners.get(event.type) ?? [])]) fn(event);
        return true;
      },
    } as unknown as EventTarget;
    parents.set(target, parent);
    protos.set(target, proto);
    let exposes: any,
      connection: any,
      textValue = "";
    const session = createRuntimeSession(proto, {
      prototypeName: proto.name,
      getRawProps: () => props,
      schedule: (fn) => fn(),
      scheduleDelay: (ms, fn) => {
        const id = setTimeout(fn, ms);
        return { cancel: () => clearTimeout(id) };
      },
      commit: (_c, s) => s?.done(),
      onRuntimeReady(w) {
        if (proto === fieldControl)
          w.attach("text-control", [
            [
              TEXT_CONTROL_HOST_CAP,
              {
                attach(c: any) {
                  connection = c;
                  textValue = c.patch.value ?? c.patch.defaultValue ?? "";
                  return {
                    update(patch: any) {
                      if (typeof patch.value === "string")
                        textValue = patch.value;
                    },
                    snapshot: () => ({ value: textValue, composing: false }),
                    dispose() {},
                  };
                },
              },
            ],
            [
              TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
              (fn: () => void) => session.invokeInCallbackScope(fn),
            ],
          ]);
        w.attach("anatomy", [
          [ANATOMY_INSTANCE_TOKEN_CAP, target],
          [ANATOMY_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [ANATOMY_GET_PROTO_CAP, (t: any) => protos.get(t)],
          [ANATOMY_ROOT_TARGET_CAP, (t: any) => t],
        ]);
        w.attach("context", [
          [CONTEXT_INSTANCE_TOKEN_CAP, target],
          [CONTEXT_PARENT_CAP, (t: any) => parents.get(t) ?? null],
        ]);
        w.attach("event", [
          [EVENT_ROOT_TARGET_CAP, () => target],
          [EVENT_GLOBAL_TARGET_CAP, () => target],
        ]);
        w.attach("as-trigger", [
          [AS_TRIGGER_INSTANCE_CAP, target],
          [AS_TRIGGER_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [AS_TRIGGER_GET_PROTO_CAP, (t: any) => protos.get(t)],
        ]);
        w.attach("expose-state", [
          [
            EXPOSES_RECORD_SINK_CAP,
            (x: any) => {
              exposes = x;
            },
          ],
        ]);
        w.attach("expose-event", [
          [
            EXPOSE_EVENT_SINK_CAP,
            (name: string, payload: unknown) => {
              eventTape.push({ kind: "event", name, payload });
              if (name === "validationRequest") requests.push(payload);
              actions.push(name);
              actionCallback(name);
            },
          ],
        ]);
      },
    });
    sessions.add(session);
    return {
      session,
      target,
      input(value: string) {
        textValue = value;
        connection.onEvent({
          type: "input",
          value,
          composing: true,
          data: "x",
          inputType: "insertText",
        });
      },
      get exposes() {
        return exposes;
      },
    };
  }

  return {
    make,
    actions,
    requests,
    eventTape,
    setActionCallback(fn: (name: string) => void) {
      actionCallback = fn;
    },
  };
}

async function wcFixture() {
  const root = document.createElement(fieldRoot.name) as any;
  const control = document.createElement(fieldControl.name) as any;
  setElementProps(root, { externalValidation: true, validationMode: "manual" });
  setElementProps(control, { defaultValue: "same" });
  root.append(control);
  const requests: any[] = [],
    eventTape: any[] = [];
  root.addEventListener("validationRequest", (event: CustomEvent) => {
    requests.push(event.detail);
    eventTape.push({
      kind: "event",
      name: "validationRequest",
      payload: event.detail,
    });
  });
  document.body.append(root);
  await flush();
  const editor =
    control.shadowRoot?.querySelector("input") ??
    control.querySelector("input");
  expect(editor).not.toBeNull();
  expect((editor as HTMLInputElement).value).toBe("same");
  const api = root.getExposes();
  return {
    api,
    requests,
    eventTape,
    invoke: (method: string, ...args: any[]) => api[method](...args),
  };
}
async function runtimeFixture() {
  const h = runtimeHarness();
  const root = h.make(fieldRoot, null, {
    externalValidation: true,
    validationMode: "manual",
  });
  const control = h.make(fieldControl, root.target, { defaultValue: "same" });
  for (const part of [root, control]) await part.session.mount();
  const api = root.exposes;
  expect(control.exposes.value.get()).toBe("same");
  return {
    api,
    requests: h.requests,
    eventTape: h.eventTape,
    session: root.session,
    invoke: (method: string, ...args: any[]) =>
      root.session.invokeInCallbackScope(() => api[method](...args)),
  };
}
for (const host of ["wc", "runtime"] as const) {
  const operations =
    host === "wc"
      ? (["normal", "cancel", "reset", "newer"] as const)
      : (["normal", "cancel", "reset", "newer", "dispose"] as const);
  for (const operation of operations)
    it(`${host} pending publication: ${operation}`, async () => {
      const f: any = host === "wc" ? await wcFixture() : await runtimeFixture();
      expect(f.api.pending.get()).toBe(false);
      expect(f.api.getValidity().filled).toBe(true);
      const tape = f.eventTape;
      let reacted = false,
        nested: any,
        returned: any,
        thrown: unknown,
        threw = false;
      const transitions: Promise<unknown>[] = [],
        transitionErrors: unknown[] = [];
      const stop = f.api.pending.subscribe((event: any) => {
        if (event.type !== "next") return;
        tape.push({ kind: "pending", next: event.next });
        if (event.next !== true || reacted) return;
        reacted = true;
        tape.push({ kind: "operation.begin", operation });
        if (operation === "cancel") f.invoke("cancelValidation");
        if (operation === "reset") f.invoke("resetValidation");
        if (operation === "newer") nested = f.invoke("validate");
        if (operation === "dispose") {
          transitions.push(
            f.session
              .dispose()
              .catch((error: any) => transitionErrors.push(errorFact(error))),
          );
          tape.push({
            kind: "dispose.returned",
            instancePhase: f.session.instancePhase,
            mountPhase: f.session.mountPhase,
          });
        }
        tape.push({ kind: "operation.end", operation, nested });
      });
      stops.push(stop);
      tape.push({ kind: "validate.begin" });
      try {
        returned = f.invoke("validate");
      } catch (error) {
        threw = true;
        thrown = error;
      }
      tape.push({
        kind: "validate.returned",
        returned,
        threw,
        error: threw ? errorFact(thrown) : null,
      });
      await Promise.all(transitions);
      const row: any = {
        host,
        operation,
        reacted,
        returned,
        nested,
        threw,
        error: threw ? errorFact(thrown) : null,
        requests: [...f.requests],
        tape: [...tape],
        transitionErrors,
        instancePhase: f.session?.instancePhase,
        mountPhase: f.session?.mountPhase,
      };
      if (operation !== "dispose") {
        row.validity = f.api.getValidity();
        row.pending = f.api.pending.get();
        row.oldResultAccepted =
          typeof returned === "string"
            ? f.invoke("resolveValidation", returned, { invalid: false })
            : null;
        if (operation === "newer")
          row.newResultAccepted = f.invoke("resolveValidation", nested, {
            invalid: false,
          });
      }
      observations.push(row);
      expect(reacted).toBe(true);
      expect(transitionErrors).toEqual([]);
      expect(threw, JSON.stringify(row.error)).toBe(false);
      if (operation === "normal") {
        expect(row.requests).toEqual([
          { requestId: returned, value: "same", reason: "manual" },
        ]);
        expect(row.pending).toBe(true);
        expect(row.oldResultAccepted).toBe(true);
      } else if (operation === "newer") {
        expect(row.requests).toEqual([
          { requestId: nested, value: "same", reason: "manual" },
        ]);
        expect(row.oldResultAccepted).toBe(false);
        expect(row.newResultAccepted).toBe(true);
      } else {
        expect(row.requests).toEqual([]);
        if (operation === "dispose") expect(row.instancePhase).toBe("disposed");
        else {
          expect(row.pending).toBe(false);
          expect(row.oldResultAccepted).toBe(false);
        }
      }
    });
}
