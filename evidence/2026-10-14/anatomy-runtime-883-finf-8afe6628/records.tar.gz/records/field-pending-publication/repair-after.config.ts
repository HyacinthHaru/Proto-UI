import base from '<SOURCE_ROOT>/vitest.config.ts';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
const repo = '<SOURCE_ROOT>',
  revision = 'eec135b299b1fbed23bbd02cf6a3c7df7ed9cbe1',
  output = process.env.FIELD_PENDING_OUTPUT!;
const tracked = new Set(
  execFileSync('git', ['ls-tree', '-r', '--name-only', revision], {
    cwd: repo,
    encoding: 'utf8',
  })
    .trim()
    .split('\n')
);
const loaded = new Map();
const save = () =>
  fs.writeFileSync(
    path.join(output, 'loaded-inputs.json'),
    JSON.stringify([...loaded.values()], null, 2) + '\n'
  );
process.on('exit', save);
export default {
  ...base,
  root: repo,
  cacheDir: path.join(output, 'vite-cache'),
  plugins: [
    {
      name: 'fixed-field-pending-source',
      enforce: 'pre',
      load(id) {
        const relative = path.relative(repo, id.split('?')[0].replace(/^\/@fs/, ''));
        if (!tracked.has(relative)) return null;
        const original = execFileSync('git', ['show', revision + ':' + relative], {
          cwd: repo,
        });
        const overridden = relative === 'packages/prototypes/base/src/field/root.proto.ts';
        const bytes = overridden
          ? fs.readFileSync(
              '<TASK_STATE>/field-pending-publication/repair-candidate/root.proto.ts'
            )
          : original;
        loaded.set(relative, {
          path: relative,
          source: overridden ? 'private-field-root-candidate' : revision,
          gitOriginalSha256: crypto.createHash('sha256').update(original).digest('hex'),
          sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
        });
        save();
        return bytes.toString();
      },
    },
    ...(base.plugins ?? []),
  ],
  test: {
    ...base.test,
    include: [
      '<TASK_STATE>/field-pending-publication/field-pending.test.ts',
    ],
    maxWorkers: 1,
    minWorkers: 1,
    fileParallelism: false,
    reporters: ['verbose', 'json'],
    outputFile: { json: path.join(output, 'vitest.json') },
  },
};
