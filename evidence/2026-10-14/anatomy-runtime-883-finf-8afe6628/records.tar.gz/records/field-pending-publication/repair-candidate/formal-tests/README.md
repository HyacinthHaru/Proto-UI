正式回归候选只生成私有副本和[formal-test-candidate.patch](../formal-test-candidate.patch)，未编辑或stage产品文件，未执行测试。补丁已对当前两目标文件通过只读git apply --check。

预计新增8例，实际计数由父代理收集结果确认：
- `field-validation-interruptions.test.ts`：复用现有mount/flush/afterEach，4项normal/cancel/reset/newer。pending nexttrue订阅只调用公共方法；所有expect在callback外，finally退订。对正常lease、取消/重置后无旧event、nested仅新id以及old/newresolve分别断言。
- `notification-retirement-lifecycle.test.ts`：既有runtimeHarness零改动，只加公共FIELD_CONTEXT import。State与Context两个入口各normal/dispose，共4项。Context控制用真实authoring的observer prototype和def.context.subscribe(FIELD_CONTEXT)，不引入privateflag／产品专用接口；它直接瞄准context.update后的firstpublication边界。真正断言留在callback外，finally释放全部session与state订阅。

独审指出的void边界已修正：正式测试在`invokeInCallbackScope` callback内赋局部request/accepted，然后callback外断言，绝不使用scope方法的返回值。旧私有9case、原时点和raw收据均不改；旧工具依赖过实现当前转发值，这仅是执行观察，不建立公开API保证。

这里只建议并准备实际仓库测试，未复制private runner、文件保存、Gitload hook或整套Runtime工具。没有扩大timeout、控制取消或正常合法nested规则。父代理将先在未修复Root跑同补丁红，再apply已冻结Root候选跑绿；在此之前不能称这8项已通过，尤其Context控制尚未实跑。Spec/T映射和实际新增计数仍由父代理核对。
