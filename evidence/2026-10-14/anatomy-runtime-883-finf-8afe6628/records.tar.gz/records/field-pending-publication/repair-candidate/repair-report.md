私有FieldRoot最小候选已完成；有效单Root override对照为**原9项：baseline2pass/7fail → after9pass/0fail**，fixture SHA `5224cbb9db8a89ce0641690727d05bdf3f38a33b0dbe744d871655d68349c7b1`逐字不变，断言与默认timeout未改。未改、stage或提交产品文件。

候选`root.proto.ts`只改两个调用边界：
- publish先捕获owner，在自身normalization/invalidation完成之后捕获既有revision；Context更新后以及每次State通知后复验。取消/新请求/退休导致旧帧停止后续写入，dispose原dirty.set错误在同一测试中消失。不改initialized生命周期，不加全局锁或吞错。
- 创建外部请求时保存owner和exact pending object，publish之后确认仍当前才emit；中途取消/reset/更新请求/终止仍返回原requestId，不擅改返回约定。合法nestedvalidate仍完成并可resolve。

WC与Runtime的cancel/reset均不再发旧id；newer仅发新id，旧resolve=false、新resolve=true。Runtimedispose的instance最终disposed、mountdetached，原dirty写错误消失且没有request事件。两个normal保持当前请求发出/resolve成功。

有效after执行为2026-10-14 11:58:24–11:58:30 UTC，physicalcheckout4648dbde前后clean；固定来源仍eec，378loadedpaths中**377Git字节与baseline完全相同+1私有FieldRoot override**。Nodeworker实测24.21.0、darwinarm64，pnpm10.32.1由launcher实测。after-1的0tests外部fixture加载失败另存；只有overrideconfig恢复与fixture同目录，配置字节相同，才得到after-2有效结果，不把setup错误计入行为红绿。

候选SHA `115c29c6a5b1a7eaf74161ba36cc85f2bc4f11c8b09da343cb38989cfd019d83`；可应用diff在[candidate.patch](candidate.patch)，只含`packages/prototypes/base/src/field/root.proto.ts`，已对当前未改的Root执行只读git apply --check。所有原始结果不覆盖。

建议最小仓库回归：在`packages/prototypes/base/test/field-validation-interruptions.test.ts`复用现有mount/flush/afterEach增加normal/cancel/reset/newer的pending订阅表，不提交私有runner、文件系统保存或来源工具；terminaldispose优先复用`notification-retirement-lifecycle.test.ts`既有真实RuntimeSession+fieldRoot/fieldControl及TextControlcap，增加一个pending退休断言，不复制整套privateharness。实际加入后的计数、映射及当前组合验证由父代理完成。

这是HappyDOM/WC和有声明syntheticTextControlcap的Runtime证据；两个版本Runtime均记录ControlLabel unsupported-host，不宣称原生Label/Focus。尚未新增验证controlledinvalid、Context订阅侧、unmount/remount、全Field suites/types、四Adapter浏览器或包消费者。无源码修复发布或独立批准。完整SHA/事件比较/来源/进程退出收据在[repair-report.json](repair-report.json)。
