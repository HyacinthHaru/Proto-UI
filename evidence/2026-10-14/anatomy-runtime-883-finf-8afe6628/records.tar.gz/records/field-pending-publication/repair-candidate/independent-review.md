# Field Root pending publication — private candidate review

**当前最小产品源码未发现具体错误；有 1 个 P3 私有测试 API 边界问题，结论 partial / ABSTAIN。** 已核候选 SHA `115c29c6a5b1a7eaf74161ba36cc85f2bc4f11c8b09da343cb38989cfd019d83` / blob `eaac7c732d3955c92919f583b36b3292dbb4db1f`，没有预设9项通过等于整体接受。

publish 在准备前捕获 current owner，revision 则在本帧 source/value/required/policy normalization 与合法 invalidate 之后、Context.update 之前捕获。该位置避免把本次正常初始化当成过期。Context.update 和每个 State.set 后都复核 owner/revision；unmount 的 invalidate、terminal dispose 的 invalidate+run=null 能中止旧帧。external validate 还在 publish 后复核 exact pending 对象，不只比较 pending 布尔或字符串ID，因此取消/reset/新请求不会让旧请求继续发出。没有 busy 锁，合法 nested validate 仍实际发出并接受；被中途替代的旧调用保留已分配 requestId 返回约定。

实际九项为 WC 与 custom Runtime host 的 normal/cancel/reset/newer，加 Runtime dispose。相同 fixture 从2pass7fail到9pass，after-2有效；after-1为0测试的Vite加载错误，保留且不计行为红绿。已逐条核378条加载输入：377条为固定eec Git字节，唯一私有 override为Field Root。物理checkout的bd47/4648前进没有被冒充成执行来源。它不是 native Chrome、全Adapter、AT或canonical CI证据。

`ISSUE883-FIELD-PENDING-TEST-RETURN-001`（P3）：私有 runtimeFixture.invoke 直接返回 `session.invokeInCallbackScope(...)`，但公开 `RuntimeSession` 和 execute/types 均声明返回void。当前实现恰好转发callback结果，所以日志观察是真实的；正式测试应在callback内部赋局部 result，scope调用后由helper返回，不能把该偶然转发当公开返回保证。不需更改Runtime API，也不抹原red/green。

另一个必要覆盖边界：9项均从 exposed pending State 通知触发，没有直接覆盖新增Context.update后的guard。正式回归建议补一项实际 FIELD_CONTEXT subscriber 内cancel或dispose，确认无旧事件/退休后的State写入；保留normal与nested控制。这里不据纯静态猜测扩修其它Field caller，也不要求无界全量重测。

权威为draft C-FIELD-0001的当前lease/owner语义、draft State/lifecycle退休规则及active ViewIntent边界，不承诺所有host同步通知，也不定义一般callback异常恢复。报告只读，不改产品、不运行测试、不提交或写GitHub。
