固定eec生产源的Field公共API控制已真实完成：**9项，2个normal控制通过，7项行为失败，exit1**。执行时间2026-10-14 11:49:08–11:49:13 UTC；无import/setup红、无超时。实际worker打印Node24.21.0、darwin/arm64；launcher实测pnpm10.32.1。未启动Chrome或操作父代理native句柄。

| Host | pending订阅动作 | 实际首次分歧 |
| --- | --- | --- |
| WC + Runtime | normal | 各发一个当前requestId，pending=true，resolve被接受；两项通过。 |
| WC + Runtime | cancelValidation | pending=false已公布、旧resolve拒绝，但随后仍发旧validationRequest；两项失败。 |
| WC + Runtime | resetValidation | 同上，已reset的旧lease仍通知消费者；两项失败。 |
| WC + Runtime | 再validate一次 | 新request先发，旧outer request后发；旧resolve拒绝、新resolve接受；两项失败。 |
| Runtime | session.dispose | instance已disposed/mountdetached，无validationRequest发出；旧publish继续state(dirty).set并抛错。一项失败，不能写成dispose仍发旧事件。 |

WC使用实际fieldRoot/fieldControl和WC Adapter，HappyDOM执行真实模块、公开pending.subscribe及validate/cancel/reset/resolve；Runtime使用实际同两Prototype和RuntimeSession，宿主部分复用现有notification-retirement测试的synthetic TextControl cap。没有注入私有flag；pending来自真正validate。WC的20次microtask flush来自已有Field interruption fixture，未增加断言或默认test timeout。新fixture不规定中断后的validate返回null或其他新API语义，只记录原返回值。

源边界：fixture预定gitshow固定`eec135b299b1fbed23bbd02cf6a3c7df7ed9cbe1`，执行时physical checkout已由父代理合法推进到`bd47d1ee60ebb2bad5ad6c2bba8fd4592039e72d`且前后clean。不是“checkout始终eec”。378个实际loadedGitinputs逐一以blob/SHA校验为eec原字节，无生产源码override；这378项另与bd47全部blob相同。私有fixture/config字节单独保存，不冒称仓库原测试。实际初始config和bootstrap脚本也在执行前逐字等于eec。

`field/root.proto.ts220–227`给出pending→publish→旧request emit路径，与cancel/reset/newer实际事件顺序一致。terminal原始stack则定位到publish189的dirty.set，经__fieldNotify297，说明需要考虑publication内部退休；不能只在最终emit前吞异常。Runtime终态State guard正在如实拒绝旧调用，不应放松它或加全局busy锁压制合法新请求。

这里只提供已复现的Field caller问题，尚无修复；C-FIELD0001仍draft，返回约定、controlled validity、Context订阅侧、重复mount、四Adapter/native/AT都不被本9项补成已验收。原始红、normal控制、event tape、错误stack、worker环境及378input绑定见report.json/source-binding.json/run-1。原triage快照保持原样，本报告是之后的新实证。
