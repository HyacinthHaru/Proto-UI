import base from '<SOURCE_ROOT>/vitest.config.ts';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
const repo = '<SOURCE_ROOT>',
  revision = '6b62e0e6d3c5d415ccf983b572a2e37cd5121e9a',
  output = process.env.FIELD_SLOT_OUTPUT!;
const tracked = new Set(
  execFileSync('git', ['ls-tree', '-r', '--name-only', revision], {
    cwd: repo,
    encoding: 'utf8',
  })
    .trim()
    .split('\n')
);
const loaded = new Map();
const save = () =>
  fs.writeFileSync(
    path.join(output, 'loaded-inputs.json'),
    JSON.stringify([...loaded.values()], null, 2) + '\n'
  );
process.on('exit', save);
export default {
  ...base,
  root: repo,
  cacheDir: path.join(output, 'vite-cache'),
  plugins: [
    {
      name: 'fixed-field-pending-source',
      enforce: 'pre',
      load(id) {
        const relative = path.relative(repo, id.split('?')[0].replace(/^\/@fs/, ''));
        if (!tracked.has(relative)) return null;
        const original = execFileSync('git', ['show', revision + ':' + relative], {
          cwd: repo,
        });
        const isTest =
          relative === 'packages/prototypes/base/test/notification-retirement-lifecycle.test.ts';
        const isRoot =
          relative === 'packages/prototypes/base/src/field/root.proto.ts' &&
          process.env.FIELD_SLOT_VARIANT === 'after';
        const overridden = isTest || isRoot;
        const bytes = overridden
          ? fs.readFileSync(
              '<TASK_STATE>/field-after-publication-slot/' +
                (isTest ? 'probe.test.ts' : 'root.proto.ts')
            )
          : original;
        loaded.set(relative, {
          path: relative,
          source: isTest
            ? 'private-observed-formal-case'
            : isRoot
              ? 'private-field-root-candidate'
              : revision,
          gitOriginalSha256: crypto.createHash('sha256').update(original).digest('hex'),
          sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
        });
        save();
        return bytes.toString();
      },
    },
    ...(base.plugins ?? []),
  ],
  test: {
    ...base.test,
    include: ['packages/prototypes/base/test/notification-retirement-lifecycle.test.ts'],
    testNamePattern:
      '^Field Root retains newer validation entered during Context and pending publication$',
    maxWorkers: 1,
    minWorkers: 1,
    fileParallelism: false,
    reporters: ['verbose', 'json'],
    outputFile: { json: path.join(output, 'vitest.json') },
  },
};
