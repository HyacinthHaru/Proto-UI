Field deferred emitter 的旧帧覆盖已实际复现并修复于私有候选。

固定源为 `6b62e0e6d3c5d415ccf983b572a2e37cd5121e9a`；原 Field Root SHA `f01c0398…`，候选 `88e984ed…`。两次同一实际私有 fixture SHA `53a3bcd2…`、同 config，唯一 before/after 输入变化是 Root。共加载 395 个 tracked inputs，逐一保存 Git blob、固定 SHA 与实际执行 SHA。实际工作树的 Diag3 staged paths 不属于这些私有覆盖，receipts 保留该状态。

14:17:50–14:17:56 UTC 的 baseline 为 1 fail / 89 skip。实际顺序为 Context-enter→pending-enter→newer-return `field-1-4-2`→older-return `field-1-3-1`，事件列表为空；当前 pending 为 true，旧 ID resolve=false，新 ID resolve=true。唯一行为红项是应发新 ID 但实际 `[]`。

14:18:51–14:18:57 UTC 的候选为 1 pass / 89 skip。同顺序后唯一 emit 为 `field-1-4-2`，旧 ID 仍拒绝，新 ID 仍可接受。修复只有 `publish()` 后、构造/保存 emitter 前的 current-owner/exact-pending guard；延后闭包原 guard 保留，未改变 API 返回、State/Context 队列、timer 或合法 nested validate。

最终正式补丁在 `formal-v2/formal-test-candidate.patch`，只新增一个 case；根据独审建议先复制 `emittedAtReturn`，再做 old/current resolve，最后在 callback 外断言这个同步返回点已包含新 ID。该正式 v2 未由本代理运行；原已执行 fixture/records 保留，不把强化后的形式测试冒称既有执行。父代理可先 apply 这一个正式 patch 做红，再 apply `root-candidate.patch` 做绿。

这是既有 Runtime helper 的真实 Root/Control、公开 Context/State 订阅和 TextControl host 控制。没有 private kernel flag、Runtime 修改、浏览器/AT 声明。89 skipped 不代表通过；两个工具 runner/child 已结束。公开 payload-v1 未改。