# Group C continuation: executed internal boundaries

This packet records bounded observations and repairs for Issue #883 / PR #888 on the #887 continuation. Local advisory reviews remain partial/ABSTAIN; they are not GitHub approval or whole Finf acceptance. Native, optical, assistive-technology and installed-package claims are separate.

## Field request publication

The formal Runtime controls use real Field Root and Control and the existing synthetic TextControl host. An accepted non-composing input publishes `dirty`; its external subscriber calls the public `validate()`. The same State kernel is still delivering `dirty`, so the `pending` notification queues. Baseline `58d39e1f` emits `validationRequest` before that queued pending callback cancels, resets, disposes or supersedes it: normal passes and four retirement controls fail.

The Field-owned publication repair tracks nested `publish()` calls and retains one latest request continuation. When the outer Field publication returns after its State notifications, the continuation checks the exact current owner and pending record before emission. No microtask, timer, global State queue rule or return-value convention changes. The same final five formal controls pass within the actual seven-file/178-test run. Current request IDs and result acceptance are asserted.

An additional legal composition creates its own owned State in the same instance through `asFieldRoot()`. Both normal and cancel observations show: external signal callback -> event -> validate returns -> queued pending callback. Cancel then retires the result and resolve returns false. This is an observed capability boundary, not proof of a general batch-before-event guarantee in the current Field contract. The local Field depth repair is not described as covering this external State chain.

The first attempt to add exact request-ID assertions omitted a test destructuring binding and failed with ReferenceError. Those controls were corrected before the formal paired run; all original logs remain. No timeout or assertion was weakened.

## Toggle Group owner retirement

A real Runtime Context subscriber synchronously calls public unmount and then mount. Without a Presence wait, the callbacks finish in the same stack: mounted epoch1 -> detached epoch1 -> mounted epoch2. Baseline emits the old `[a]` proposal in epoch2; a single RunHandle identity check still does, because remount reuses that handle. The eight-control private matrix is 5pass/3fail -> identity-only7pass/1fail -> local view-epoch8pass.

The four-line Root repair captures its local epoch and increments it at onUnmounted. After Context publication, either owner retirement or epoch change suppresses only the old continuation and preserves the accepted `true` result. Normal and legal nested requests retain existing behavior; a fresh `[b]` request after remount succeeds. Formal five-case baseline is 2pass/3fail and all five pass in the actual 89-case notification file; three verified related files add 73 actual passes.

WC physical removal is asynchronous and remains a negative control, not evidence of synchronous logical retirement. Created-only disposal and every Adapter remount are not claimed.

## Calendar caption disposal

A caption owns subscriptions to month and disabled source state. Baseline invokes only the first release when it throws and leaves the second subscription acquired. The repair marks the caption terminal, attempts both saved releases, and then rethrows the first identical value, including undefined/null/false/zero/empty string. Six direct before failures change to six passes within the original 34-case caption file; the related Calendar file yields 53 total actual passes. No Runtime-wide exception policy changes.

## Canonical hosted evidence at 58d39e1f

CI38563529622 completed failure:22 jobs,12success10failure. The synthetic checkout612991dd99cd69d07e589a22247ba75c073db5e9 has exactly the same21dc0b86 tree as58d. General stopped at78 public-docs classification diagnostics before Vitest. Three complete browser reports sum155pass24fail15skip; five other shards exited124 without complete reports. Collapsible's36-case file passed within a shard that later timed out; this is file-level evidence, not a green shard.

Field dedicated38563530001 directly checked out58d and completed22pass3fail. Liquid Glass React/Vue/Vue2 failed the later Checking-to-Available completion poll; focus had already passed. The failure mechanism is not established by the local Mac25pass or by the separately reproduced queued-publication case. Final continuation CI and source binding must remain distinct from this historical run.
