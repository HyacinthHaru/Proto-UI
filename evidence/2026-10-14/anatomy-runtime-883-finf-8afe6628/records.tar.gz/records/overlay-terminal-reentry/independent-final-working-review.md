Overlay 新 P2 `ISSUE888-OVERLAY-TERMINAL-REENTRY-001` 在准确双 guard 工作候选中已解决，**0 个新增具体 finding**。结论保持 local **partial / ABSTAIN**。

`onProtoPhase(unmounted)` 已设置终态，而 mountPhase 仍可独立保持mounted。release回调替换caps会分别触发 deferred view reconciliation 与 Escape eligibility 更新。只改flush调用点不足；currentViewGuard与syncEscapeCandidate各自加终态检查，是覆盖这两条实际入口的最小修复。原logical open/viewActive不被改写，旧owner release/cache commit、首原始error传播和清理顺序不变。

同最终test9aa0：原c82 **3fail/29skip**；仅view guard **2pass/1fail/29skip**（Escape仍红）；双guard **5files/57pass**。最初V1因closeOnEscape默认false而出现的Escape假pass，以及view-only元数据wrapper在测试前失败，都保存并排除出有效证明。

旧29case执行体逐字节保留；fixture新增eventPort默认{}只让新Escapecase可注入现有公开scope接口。前置survivor=false证实已加入Overlay候选，终止后的新sample=true证明它没重新夺权。所有关键断言在release回调外、finally测试清理前。本证据是Module/HostCapability/opaque coordinator控制，不是native Escape、完整Runtime恢复或通用异常策略。

T仅追加一条三控制说明，draft/needs-review、CASE与criteria不变。

| 文件 | SHA-256 | Git blob |
| --- | --- | --- |
| `packages/modules/overlay/src/impl.ts` | `4c71c9534479782f7a15f05e77d30f63a1bd8b8a498adbc56e02c733ebdf9087` | `520c48974c1be4b3a8a50388f543490c77978f27` |
| `packages/modules/overlay/test/host-callback-reentrancy.test.ts` | `9aa0a85c25bdb45d92b17a681dc1ee422fbf9ca303755ae4bf95cf80a5d9cd1f` | `b9ac6380f47bda81b6c7cab8c50265c05a27ce02` |
| `spec/tests/T-OVERLAY-CATALOG-0001.yaml` | `078b4a03a70340b72c078f67329723f3142774be6c43ce05ad1eb945af7b99a0` | `a8ae95cfa4a0066aeb463361f2e55bd436e5f852` |

未改产品、运行测试或外部写入。最终commit/新上游组合/native/CI和另一Toggle反馈各自保留独立边界。
