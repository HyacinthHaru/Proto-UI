# be8a0175 官方终态 CI 独立对账

准确 `be8a0175cf573058eb61aa1a43ae4fa8fae9b686` / tree `742400b0a255ac89a62240bd55dab0dca5db4d55`。五目标全部自然终态，唯一collector34685已exit0，未rerun/cancel/dispatch。**human-assisted/current-user，unassessed advisory，partial / ABSTAIN。** 一次02:38只读GET EOF在下一原定读取恢复，错误原记录保留，不计产品失败。

主CI38839992376：22jobs为12success/10failure。全部8普通分片、general、package和type共11份原日志实际checkout `699293026130b1b9c56eefbbc349b0fb8a969d63`；API tree精确等于be8，父2b+be8。另12份专属log直接checkoutbe8。本轮23份选定日志，不能把22jobs与23logs混为同一计数；其它CIjob只核metadatahead/status。

| 分片 | Job | 实际结论 |
| --- | --- | --- |
| 1/8 | 116777736675 | exit124，原900s，无完整报告 |
| 2/8 | 116777736706 | exit124，原900s，无完整报告 |
| 3/8 | 116777736709 | 58 pass / 3 fail / 0 skip |
| 4/8 | 116777736645 | 116 pass / 8 fail / 0 skip |
| 5/8 | 116777736825 | 63 pass / 26 fail / 15 skip |
| 6/8 | 116777736718 | 109 pass / 14 fail / 46 skip |
| 7/8 | 116777736653 | 112 pass / 2 fail / 0 skip |
| 8/8 | 116777736670 | exit124，原900s，无完整报告 |

五份完整报告合计 **458过 /53失败 /61跳过（572）**，另有 **1个suite setup-hook失败**；1/2/8三份原900s deadline exit124，无全8断言总数。shard6为109过/14失败/46skip：contrast的30s beforeAll hook超时，46个case未执行；日志bundle19ms、browser-ready25046ms，尚无first-page-ready，具体卡在其余phase写入/newContext/newPage哪个await未知。它不计作第15个failedtest。另首页`restores semantic control focus...`用例在chooseControl303的Brutalist option count0失败（caller819），还没到后续focus/旧portal断言。这两个testblob同fb71，但未做成对执行，不能据此称继承或认定新Field根因。

**普通与专属路径的四个恢复用例本头均明确通过。** 普通shard1的portal55为54过/1css-zoom失败，WC3451ms、React3618、Vue3606、Vue23425；分片随后仍deadline124。专属Liquid的portal55也54/1，WC3594ms，其主browser780过/3失败（另两项material light/dark质量等待）。旧84/421/fb71每次红/绿与未知官方栈保持历史，没有回填或重标。

Type-check116777637947实际完整check:types成功，Astro **923文件、0errors、0warnings、14hints**。Package116778758007实际47/47build、47manifest和9policytests成功；九项 **4PASS/5ADVISORY**，gzip/minified尺寸及minifiedSHA逐项同fb71canonical。Node24.21.0、pnpm10.32.1、zlib1.3.2.1-motley-8002e91、esbuild0.25.12、Linuxx64。未称strict全过、新本地build或gzip文件字节比较。General116777736629在与fb71逐条相同的ordered78docs诊断停止，未进入Vitest。

Field原25/25通过（现有三Liquid异步观测范围）。Coll原32/4，四Liquid窄几何320.4375>320，无原60s超时；独立诊断8过/原36skip另列。Finf18jobs11success/7failure。Forms原10/2仍597颜色；Finf终态后一次当前artifact12020667495，3,176,843bytes，official/actualSHA6d5f85578a04e007157bc1581c723047bb89d7ef71e953ab24325758550ebb4a一致。72目录只提两JSON，精确be8/tree7424、React/Chrome155.0.8059.39、pageErrors/captureErrors均[]，0PNG；不能据此称颜色gate后的完整流程通过。Liquid9jobs4success/5failure，hover16/16，prominentbrowser32/48，另103unit/job不混计。

最终全head30runs19success/11failure，94checks55success/39failure，DCOsuccess，Vercelgit/authorize独立失败。02:50:52实时回读887仍2b、888仍be8，本次开始后没有新增/更新inline，也没有准确be8review；这不是批准或旧thread解除。父代理和peer的Field修复验证属于独立来源，本CI子任务没有重作源码功能review。

无本地测试/构建/浏览器、产品编辑、GitHub写入、官方PNG提取或视审；仅源对象/API读取与私有报告。
