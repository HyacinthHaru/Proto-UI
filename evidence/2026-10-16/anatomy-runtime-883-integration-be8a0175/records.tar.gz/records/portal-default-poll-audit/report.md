# 421 ordinary WC 恢复失败：默认 poll 清单

**当前失败 predicate 仍未知。** ordinary shard1只留下3154ms case时长与Matcher1000ms；随后900s结束exit124，无完整Vitest结果。specialty421同case通过是另一执行，不能替代或定位该红。

Vitest2.1.9实际实现默认timeout1000ms/interval50ms。准确421的这个case有12个直接默认poll位置，加optical helper75共13个源码位置；完整路径中preferences执行两次、helper执行8次，最多21次1s等待。下表是可能位置，不宣称失败run全部到达。

| 421行 | 阶段 | 期望 | 完整路径次数 |
| --- | --- | --- | --- |
| 75 | optical helper：firstFocus | contentConnected/scopeContains/destinationOwns/physicalDestinationIsOverlay 全 true | 8 |
| 839 | 一像素不足 | source-bounds-unavailable | 1 |
| 847 | 插入遮挡 | source-overlapping-content | 1 |
| 852 | source撤销 | opaque-fallback | 1 |
| 860 | 外部foreground覆盖 | external-foreground-mismatch | 1 |
| 868 | 材质恢复后的菜单焦点 | 至少一个menuitem为activeElement | 1 |
| 887 | destination登记撤销后的图像撤销 | 不包含data:image | 1 |
| 924 | 第一次Escape逻辑关闭 | false | 1 |
| 925 | 第一次Escape焦点返回 | true | 1 |
| 928 | 第一次重新打开使用body | body | 1 |
| 958 | 第二次Escape逻辑关闭 | false | 1 |
| 961 | 新增旧body投射退出 | disconnected 或 parent不同 | 1 |
| 981 | 系统preferences fallback | opaque-fallback | 2 |

optical72是显式20s，不属于上述1s位置；helper75的调用点为836/844/850/855/866/972各一次、1004两次。新961只是其中一项，3154ms总时长不能定位它。

普通CI只配置RUNTIME/TYPOGRAPHY evidence，portal文件只在MATERIAL evidence配置时写截图/metadata；specialty配置了MATERIAL，会在成功路径await截图。实际320-member shard包没有portal或Vitest result，producer payload=null。因此文件缺失不能反推未到哪个checkpoint，也不应为了取metadata打开截图分支并把它当普通路径。

现有checkpoint若在另一次已明确开启evidence的run存在：one-pixel图位于第一组source-bounds断言后；registration-pending图在第一Escape前；preference记录在finally中，即使该preference断言失败也会保存；最终disposed记录才表示整个case结束。当前ordinary包不具备这些阶段证据。

两次close的契约前置条件对称：第一次scene→body只等ariafalse及triggerfocus；第二次body→scene在421新增历史节点离开父节点的等待。Base在Escape分支会恢复trigger焦点，而WC物理detach仍经过两rAF conceal；909的两rAF是在第一Escape之前，不能证明后来的detach。这是待证边界，尚不能说就是本次1s失败。

最小后续判别：Root先执行其已安排的原421、无MATERIAL local WC控制。若仍需ordinary定位，只在原case失败catch即时输出原error完整stack及cause后rethrow；无需成功路径新await或只加message。Vitest外层消息固定，具体assertion在cause，最终汇总会被900s截断；deadline也可在异步getter未返回时先触发，故cause缺失不能解释为DOM条件false。

不改deadline/predicate、不归因C、不启动浏览器或测试。源码blob、engineSHA、原日志/320-member收据与最小方案见同目录report.json；本报告保持human-assisted partial/ABSTAIN。
