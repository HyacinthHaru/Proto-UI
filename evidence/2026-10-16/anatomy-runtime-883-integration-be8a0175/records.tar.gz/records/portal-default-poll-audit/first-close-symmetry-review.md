# 第一次关闭的物理退役前置条件

**case-local closeProjection()复用方案没有阻止实施的具体finding，保持partial/ABSTAIN。** 这是方案与现有源码核对，不是尚未读取的最终helper字节审核或GitHub批准。

新的真实local控制在clean421、原test SHA06c311、清MATERIAL/外部server/DEBUG条件下，01:28:52–01:29:04 UTC exit1：1fail/54filtered，case2758ms，完整stack定位原937，body-parent谓词expectedtrue/receivedfalse。它在新增第二retirement poll之前。它没有采实际替代parent或epoch；不能把“旧scene epoch被保留”升级成过程实测。

官方ordinary421仍只保留3154ms/Matcher1000ms且后来shard900s超时，没有可恢复的stack；不能把local937回填到官方原红。specialty通过也仍独立。

两轮目标转换都需要旧物理view退出：第一scene→body，第二body→restoredscene。旧第一轮只等ariafalse和triggerfocus；focus可在WC两rAF conceal/detach之前返回。T-WEB-PORTAL-DESTINATION-0001-CASE-ADAPTER明示close/detach thenreopen，HC BINDING/MATERIAL与C-AS-OVERLAY F/K区分logical与physical边界。

最小helper条件：每次调用内部新捕获当前Content+parent；依次原Escape、原ariafalse、旧节点断开或换父；finally只dispose本次handle。第一调用后保留原focuspoll、原body-parent断言；第二调用后才restore登记并保留原optical、preferences、source和dispose断言。不要跨两轮复用旧handle，不要加sleep、恢复点击、DOM/state写或扩大数值期限。

它只证明本fixture旧投射离开原位置，不是全资源清理oracle。新增第一轮等待明确改变时序；后续四Runtime OFF/ON、原55OFF及串行types由Root执行，当前报告不预判结果，也不把测试前置条件纠正称为Runtime实现修复。
