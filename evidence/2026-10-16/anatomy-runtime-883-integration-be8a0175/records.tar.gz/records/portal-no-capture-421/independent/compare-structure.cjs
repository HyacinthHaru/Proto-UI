const fs = require('node:fs');
const path = require('node:path');
const cp = require('node:child_process');
const crypto = require('node:crypto');
const W = '<SOURCE_ROOT>';
const R = __dirname;
const ts = require(path.join(W, 'node_modules/typescript'));
const file = 'apps/www/src/content/docs/zh-cn/demo-liquid-glass-portal.browser.test.ts';
const head = '421208cae540c481ab297aa6d09203c49654f5e5';
const before = cp.execFileSync('git', ['show', `${head}:${file}`], {cwd: W, encoding:'utf8'});
const after = fs.readFileSync(path.join(W,file),'utf8');
fs.writeFileSync(path.join(R,'baseline-421.browser.test.ts'), before);
fs.writeFileSync(path.join(R,'candidate.browser.test.ts'), after);
const sf = ts.createSourceFile(file, after, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
let helper; const calls=[];
function visit(n) {
 if (ts.isVariableDeclaration(n) && n.name.getText(sf)==='closeProjection') helper=n;
 if (ts.isExpressionStatement(n) && ts.isAwaitExpression(n.expression) && ts.isCallExpression(n.expression.expression) && n.expression.expression.expression.getText(sf)==='closeProjection') calls.push(n);
 ts.forEachChild(n,visit);
}
visit(sf);
if (!helper || calls.length!==2) throw Error('Unexpected helper or call count');
const firstStart=before.indexOf("        await page.keyboard.press('Escape');",before.indexOf('// Only the next attached view'));
const firstEnd=before.indexOf('        await expect.poll(() => trigger.evaluate',firstStart);
const secondStart=before.indexOf('        const bodyProjection =',firstEnd);
const secondEnd=before.indexOf('        await page.evaluate(() => (window as any).liquidPortalFixture.destination(true));',secondStart);
if ([firstStart,firstEnd,secondStart,secondEnd].some(x=>x<0)) throw Error('Missing original blocks');
const firstBlock=before.slice(firstStart,firstEnd),secondBlock=before.slice(secondStart,secondEnd);
const helperBody=helper.initializer.body.statements.map(n=>n.getText(sf)).join('\n');
function tokens(src) {
 const tree=ts.createSourceFile('comparison.ts',src,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
 if(tree.parseDiagnostics.length) throw Error('Comparison input did not parse');
 const out=[];
 function leaves(n){const children=n.getChildren(tree);if(children.length)children.forEach(leaves);else if(n.kind>=ts.SyntaxKind.FirstToken && n.kind<=ts.SyntaxKind.LastToken && n.kind!==ts.SyntaxKind.EndOfFileToken)out.push([n.kind,n.getText(tree)]);}
 leaves(tree);return out;
}
const replacements=[{start:helper.parent.parent.getStart(sf),end:helper.parent.parent.end,text:''},{start:calls[0].getStart(sf),end:calls[0].end,text:firstBlock},{start:calls[1].getStart(sf),end:calls[1].end,text:secondBlock}];
let restored=after;
for (const change of replacements.sort((a,b)=>b.start-a.start)) restored=restored.slice(0,change.start)+change.text+restored.slice(change.end);
const tokenEqual=JSON.stringify(tokens(restored))===JSON.stringify(tokens(before));
const helperEqual=JSON.stringify(tokens(helperBody))===JSON.stringify(tokens(secondBlock.replaceAll('bodyProjection','projection')));
if (!tokenEqual || !helperEqual) throw Error('Unexpected parsed-token delta');
const digest=s=>crypto.createHash('sha256').update(s).digest('hex');
const report={at:new Date().toISOString(),baseHead:head,path:file,baselineSha256:digest(before),candidateSha256:digest(after),baselineGitBlob:cp.execFileSync('git',['rev-parse',`${head}:${file}`],{cwd:W,encoding:'utf8'}).trim(),candidateGitBlob:cp.execFileSync('git',['hash-object','--stdin'],{cwd:W,input:after,encoding:'utf8'}).trim(),helperCalls:calls.length,helperEquivalentToOldSecondCloseAfterOnlyLocalIdentifierRename:helperEqual,expandedCandidateWithAddedFirstBoundaryRemovedMatchesBaselineAllTokens:tokenEqual,baselineTokenCount:tokens(before).length,normalizedCandidateTokenCount:tokens(restored).length,scope:'Read-only TypeScript parsed-AST token structure analysis. An earlier standalone scanner attempt mishandled template continuation and was rejected as an analysis-tool premise error, not a product failure; attempt scripts are retained. This does not run the browser or establish host timing. All original test statements are preserved after expanding the two helper calls; the first call intentionally adds the physical-boundary prerequisite.'};
fs.writeFileSync(path.join(R,'structural-comparison.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));
