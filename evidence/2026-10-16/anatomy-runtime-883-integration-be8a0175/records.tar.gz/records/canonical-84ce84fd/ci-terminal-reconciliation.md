# 84ce 官方终态 CI 独立对账

准确 `84ce84fdce5a15f58f12978d5cea1c24d554f0d8` / tree `ac120a185a1b2d48e4a8961fad526b3399ef7944`；五个目标run全部终态，collector90378已exit0。head全量快照30runs=18success/12failure，94checks=54success/40failure；DCOsuccess，Vercelgit/authorize为独立preview授权债。**partial / ABSTAIN，不是批准或完整验收。**

主CI38828883989为22jobs12success/10failure。General在78条public-docs family/export登记错误停止，未进Vitest。普通浏览器8分片均已读原日志：

| 分片 | Job | 实际结论 |
| --- | --- | --- |
| 1/8 | 116743629980 | exit124，原900s，无完整报告 |
| 2/8 | 116743629995 | exit124，原900s，无完整报告 |
| 3/8 | 116743630040 | 58 pass / 3 fail / 0 skip |
| 4/8 | 116743629908 | 116 pass / 8 fail / 0 skip |
| 5/8 | 116743629957 | 63 pass / 26 fail / 15 skip |
| 6/8 | 116743630013 | 156 pass / 13 fail / 0 skip |
| 7/8 | 116743629976 | 112 pass / 2 fail / 0 skip |
| 8/8 | 116743630064 | exit124，原900s，无完整报告 |

仅5份完整报告合计 **505pass /52fail /15skip（572）**。1/2/8三份原900s deadline exit124，不能计算全8断言总数。全部8日志没有明确的Context/provider-missing/disposed-state/disposed-module/nullproperty/unhandled异常字样；启动期间ECONNREFUSED和Search owner诊断不是这些异常。但这不能排除C相关断言根因，52项失败及3不完整仍在；具体失败标题和源位置见JSON。

Package job116743622884实际47/47build、47manifest、9policytests通过；9数值为 **4PASS/5ADVISORY**，不是strict全绿。Linuxx64、Node24.21.0、pnpm10.32.1、zlib1.3.2.1-motley-8002e91、esbuild0.25.12；九项gzip/minified尺寸与minifiedSHA均同准确84本地postcommit测量。Darwinarm64与Linux不同，不称同环境或gzip文件byte比较。

General/package/8shards共10log实际checkout `48cbddb264f7581175471e46a421340c4dc3553f`；其API tree精确等于84/ac，两父2b+84。其它12份专属log直接checkout84。

专属Field原25/25成功（既有3Liquidasyncobserver开启）；Coll原32/4四Liquid窄几何320.4375>320，无原60s timeout，独立8pass/36skip另列。Finf18jobs11success/7failure，Forms原10/2仍597颜色红；一次小包的两ReactJSON精确84/ac、Chrome155.0.8059.39、pageErrors/captureErrors均[]，不证明旧provider根因或后半流程已修。

Liquid9jobs4success/5failure：hover四runtime各4case共16pass；prominent四runtime各12browsercases合32pass16fail，未混每job另103unit。主browser779pass/4fail，比所读2b main多一个WCdestination恢复后opticalundefined20s失败。按新增授权一次读取main11MB包，993目录仅提两metadata；失败WC恢复后owner/provider状态未保存，不能借其它WC成功case解释。root后续fixture修复属于后到工作，84CI保持修复前来源。

只做GitHub读取和私有报告；无测试/浏览器/产品编辑/rerun/cancel/dispatch/外部写入。
