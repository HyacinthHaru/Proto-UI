# 84 WC destination 恢复红：最小现有证据

Job116742738980（run38828883938）真实checkout84/treeac。完整case名与log位置存JSON：首次summary687，FAIL1038，helper optical:73、caller957。destination(true)+reopen之后quality仍undefined，20s原poll失败；尚未归因C或Material。

按新增明确授权只下载main artifact12016483745一次，官方/实取11,074,515bytes及SHA f31b0f4079a62c74904ef98fe2d02b7244ec86ceeb0f52ad5d44d1f5fe52d3c2完全相同。完整central directory993成员已记录，只提取root metadata与portal metadata两JSON，无PNG或另外8个大包。

portal metadata精确84/treeac/clean，Node24.21.0/Chrome155.0.8059.39，共60观察。只有React/Vue/Vue2具最终恢复/retirement成功摘要；WC没有该case的beforeRevocation/afterRevocation或失败后状态。源码仅在preferences与dispose都完成后才push这些local快照，WC更早957已失败。其它WC正常矩阵/公开route成功属于不同case，不能拿来解释失败现场。

因此现有包未补齐失效后的content/provider/owner/epoch事实；这些仍unknown，需要root已开展的有界首分歧诊断，而非放宽guard或直接命名C/B根因。partial / ABSTAIN。
