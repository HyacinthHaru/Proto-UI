# 当前 native 窄图：测量对象与来源增补

实际原整文件Field25/25、Collapsible36/36均通过，来源是**raw HEAD26fe + dirty=true + staged merge tree ac120a18**，收据start/end index tree相同。没有重标成未来commit或clean26，也没有由本地pass推断Linux红因。

独立只查看一张`liquid-glass-react-320-text200-dark-before-text-assertion.png`原像素（176×5964）。右边缘截断、极长窄列换行、上部fixedheader遮挡和背景文字竞争确实可见；不扩称全部220图已审或视觉通过。Root另报Field6+Coll2，当前独立一张与其选择重叠。

该样本外层`__pui_projection__runtime_root`是preview Runtime Tabs wrapper：x132,width48,right180,scrollWidth188。它来自projection-composition构造的tabsParts.root，不是原几何测试定位的`data-demo-ref=uncontrolled` Collapsible Root。内层Root/Trigger/Content三者均x149,width170.609375,right319.609375；原断言针对Root/Content，因而其通过与外层窄容器/截图裁切并不矛盾。截图目标是previewer而不是全320px viewport；不能把PNG右缘截断量直接当成真实viewport内容裁切量。

material scene的2rem padding、width100%和32rem上限是需观测的consumer布局输入，尚未用当前computed祖先盒证明具体根因。当前数据只支持把外层wrapper/material布局和截图可读性单列，不能据此归因C owner/Context/teardown或放宽320阈值。

无浏览器重跑、测试、产品或像素修改、外部写；partial / ABSTAIN。
