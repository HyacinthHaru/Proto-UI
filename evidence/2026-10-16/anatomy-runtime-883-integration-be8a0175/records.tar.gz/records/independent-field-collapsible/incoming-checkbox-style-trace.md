# 四项 CheckboxGroup incoming 失败归属

准确候选tree `ac120a185a1b2d48e4a8961fad526b3399ef7944` 的原19文件选择实际529pass/4fail。四项均为`form-actions-quality.test.ts:192`的静态token断言，**没有证据表明是本轮C Context/owner/teardown回归**；它们仍是真实未闭合的style-translation gate。

每个case先通过glyph/passivity、controlled proposal/owner接受及disabled检查，随后调用CLI `collectProtoStyleTokens`与CSS renderer。日志token列表只有裸token；按原循环顺序首个`data-[checked]:`检查即失败。错误文本末尾的`whitespace-normal`/`w-full`是tokens.join的最后一项，不是正在断言缺失的状态。

collector每次新建Set/Map，只读源AST及relative named imports，不执行prototype代码、不读取DOM/RuntimeState。四体系均借用asCheckboxGroupRoot/Item/All；当前known-asHook解析没有这些映射（有binary asCheckboxRoot/Indicator）。实际数组缺失data variants与该源码路径一致。全CLI/src、四族20个CheckboxGroup源文件、测试、config/lock等56个输入均逐blob等于2b；本轮own Field/Toggle/Overlay/Calendar没有进入这个失败结果的数据依赖。

维护者[6189426551](https://github.com/Proto-UI/Proto-UI/pull/887#issuecomment-6189426551)与[6190389235](https://github.com/Proto-UI/Proto-UI/pull/887#issuecomment-6190389235)也保留四项欠账，但它们只作作者陈述佐证，不能冒充本次新2b-only基线运行。独立结论来自实际组合红日志与相同源/纯collector路径。

适用`C-PROTOTYPE-STYLE-CLOSURE-0001`（draft）A/B/C：状态selector/style artifact必须由合法prototype输入和translator闭合，不能由demo补齐。建议保留原红及四断言，交CLI/style owner处理合法borrowed-state lowering；不改Glyph/Control/Context、删断言、以binary Checkbox替代Group或接管Compiler。

本次无任何重测、浏览器、产品编辑或外部写；partial / ABSTAIN。
