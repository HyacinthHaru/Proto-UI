# Field / Collapsible 只读边界与合并保留审查

**合并保留 0 个具体 finding；目前没有从两条基础CI失败确认新的 C 生命周期根因。** human-assisted、unassessed advisory，partial / ABSTAIN。固定own26、upstream2b、候选tree `ac120a185a1b2d48e4a8961fad526b3399ef7944`；本报告不计入root正在运行的测试结果。

整树11206项mode/kind/blob独立比对完成：commonbase a62，own19/incoming65仅planner交集。候选planner精确2b，其余18 own路径精确26；候选相对2b净18。全部65 incoming逐项保留。Runtime、Core、所有Modules、Base prototype source前缀及WC adapt/Delay portablefixture/T-LIFECYCLE/Drawer均保留26字节。hover与prominent各一条dedicated suite、各一个exact Liquid workflow owner，均未进入普通BROWSER_SUITES。原Field/Collapsible断言、timeout、输入次序及4个own P/T字节保持。

**Field219**：基础在Label.click后读focus，尚未执行后续Tab、invalid与async Checking流程。Label→ControlLabel anatomy配对/current physical lease→目标Runtime callback→Field Control enabled/isCurrent→Focus owner链有明确draft C-FIELD-PARTS、ControlLabel/Host Focus约束。2b仍为单元素`evaluate`；候选保留已审`evaluateAll`严格len1+同一`document.activeElement`谓词及0/N拒绝、错误焦点/Shadow负控。基础1000ms失败既可能涉及实际焦点，也可能涉及query/response边界；本次没有新实验证明任一因果，不能据此改Context或把它叫Checking失败。若候选再失败，优先读现有attempt时间/当前唯一目标/activeElement与当时generation；只在失败后做最小快照，不focus、不改poll期限。

**Collapsible557**：原循环先root再Content检查width、left、right<=320、scrollWidth差；Trigger textRange/glyph与后续截图尚未发生。当前log没有失败target/theme，故0.4375不能直接归为空白glyph或paint，也不能被宽免。源码Root/Content的min-w0/max-w-full、demo网格padding与真实material scene的2rem padding/32rem上界共同决定实际宿主几何，应记录失败目标身份和已有geometry返回值，再观察祖先computed box；不要先删padding/material、隐藏overflow或放宽320。draft VISUAL-SAFETY的真实失败仍需组合验证闭合，但无owner/teardown矛盾的现成证据；该基础四Liquid生命周期主journey已过不等于普遍验收。

必须成套保留：Field pending/current-emitter/error-drain；Toggle owner/epoch/FIFO/ContextError；Overlay terminal/release/replacement与firsterror；Calendar全部unsubscribe与firsterror；严格focus oracle及opt-in诊断/清理；Collapsible原非空旧view断连oracle与capture时钟；原C Runtime/Anatomy/Delay/WC；两专属suite的完整登记。

本次无测试、浏览器、构建、产品/index修改、GitHub写入；没有接受全部65项上游行为或宣称新组合已绿。
