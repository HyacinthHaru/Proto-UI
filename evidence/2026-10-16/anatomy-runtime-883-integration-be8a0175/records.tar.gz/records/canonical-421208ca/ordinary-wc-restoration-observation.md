# 421 普通分片中的 WC 恢复失败

准确 421/tree4feed 的主 CI38832461182、shard1 job116754763238 在原日志528–529记录 WC恢复case3154ms、`Matcher did not succeed in1000ms`。同文件55项观察到2失败（另一项css-zoom），React/Vue/Vue2恢复通过。整个分片后来900s deadline exit124，未生成完整Vitest报告或失败栈。

同一tree的专属Liquid job116754074801中，这一WC恢复case4293ms通过，portal55为54过/1css-zoom失败。两次执行都是真实证据；专属阳性不能覆盖普通分片红，也不是控制变量成对实验。

按root明确授权只下载artifact12018214474一次：8,231,219bytes，官方及实际SHA一致，完整320目录成员安全。只提receipt、selection、source-sha及browser.log，0PNG；包没有portal metadata/PNG/checkpoint文件，也没有Vitest/result完整JSON。receipt为准确合成checkoutc2216591、failure、payload:null。rawbrowserlog仍只有同一1000ms消息，不能定位源行。

恢复case有多个默认1000ms poll，包括旧firstFocus/helper、注册/撤销/焦点检查以及新physical-retirement。不能凭3154ms或缺失optional capture文件认定是新增poll，也不能认定已到或未到registration/preference。保留具体predicate未知，原84红与本421两种结果均不改写。

Human-assisted/current-user；partial/ABSTAIN，无产品修改、测试、浏览器或GitHub写入。
