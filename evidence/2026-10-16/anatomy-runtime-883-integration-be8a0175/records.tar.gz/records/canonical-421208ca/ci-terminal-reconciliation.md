# 421208ca 官方终态 CI 独立对账

准确 `421208cae540c481ab297aa6d09203c49654f5e5` / tree `4feed4f52477a26085b152a9c662465c4766e682`。五目标已自然终态，collector91686已exit0，未rerun/cancel/dispatch。**human-assisted/current-user，unassessed advisory，partial / ABSTAIN。**

主CI38832461182为22jobs12success/10failure。General116754763462在78条public-docs登记诊断停止，尚未进入Vitest；ordered78逐条与84相同。普通8分片原日志已逐份读取：

| 分片 | Job | 实际结论 |
| --- | --- | --- |
| 1/8 | 116754763238 | exit124，原900s，无完整报告 |
| 2/8 | 116754763328 | exit124，原900s，无完整报告 |
| 3/8 | 116754763353 | 58 pass / 3 fail / 0 skip |
| 4/8 | 116754763269 | exit124，原900s，无完整报告 |
| 5/8 | 116754763235 | 63 pass / 26 fail / 15 skip |
| 6/8 | 116754763524 | 156 pass / 13 fail / 0 skip |
| 7/8 | 116754763405 | exit124，原900s，无完整报告 |
| 8/8 | 116754763228 | exit124，原900s，无完整报告 |

只有3/5/6三份完整报告，共 **277过 /42失败 /15跳过（334）**。其它1/2/4/7/8五份原900s deadline exit124，不能计算全8断言总数。三份完整报告的失败标题集合与84同分片相同；这只是观测比较，不能把其余未完成项或因果视为已解决。没有明确Context/provider-missing/disposed-state/disposed-module/nullproperty/unhandled异常字样，不等于排除C缺陷。

**WC恢复仍有未闭合的普通分片失败。** 新专属Liquid116754074801的原portal55为54过/1css-zoom失败，四runtime恢复均明确通过；但普通shard1的同WC恢复case在528–529行记录3154ms和1000msmatcher失败。该分片被deadline终止，没有精确失败源行。新增授权只下载一个8.23MB包，320目录成员只提4文本，无portalmetadata、Vitest结果或任何portalPNG/checkpoint名称，不能定位原/新增哪一个poll。专属阳性不能覆盖此红。

四次记录分别是：84专属WC22453ms/20s失败；84普通WC3887ms通过；421专属WC4293ms通过；421普通WC3154ms/1s失败。它们来自不同workflow配置与执行，不是控制变量pair，不据此断言新poll或产品根因。

Package116755496447实际47/47build、47manifest、9policytests通过；数值仍 **4PASS /5ADVISORY**，不是strict预算全过。Node24.21.0、pnpm10.32.1、zlib1.3.2.1-motley-8002e91、esbuild0.25.12、Linuxx64；九项gzip尺寸/minified尺寸/minifiedSHA与84canonical逐项相同。没有声称新421本地build、gzip文件字节比较或跨平台同环境。

主CI的general/package/8分片共10log实际checkout `c2216591b01c9ef3d8d7dd9354ad6e8bd266638c`，API tree精确等于421，父2b+421；另12专属log直接checkout421。

Field38832461265原25/25通过（已有三个Liquid异步trace范围开启）。Coll38832461337原32/4，为四Liquid窄几何320.4375>320，没有原60s超时；独立诊断8过/原36skip另列。Forms38832461173/job116754074532原10/2，仍597颜色；一次小包两ReactJSON绑定421/tree4feed、Chrome155.0.8059.39、pageErrors/captureErrors均[]，不能补足颜色gate后的行为。Finf aggregate18jobs11success/7failure。Liquid9jobs4success/5failure：hover16/16；prominent browser32/48，另103unit/job不混计；主browser780过/3失败（material light/dark两项与css-zoom）。

最终收集快照01:23:11：全head30runs为19success/10failure/1仍in_progress（范围外Homepagevisual）；94checks为55success/38failure/1in_progress，DCOsuccess，Vercelgit/authorize独立failure。五目标终态不等于全head全部完成。

只做只读API、Git源绑定和私有报告；无本地测试/构建/浏览器、产品编辑或GitHub写入。官方PNG未提取或视审，没有AT或正式审批声明。
