import base from '<SOURCE_ROOT>/vitest.config.ts';
import fs from 'node:fs';
const target='<SOURCE_ROOT>/apps/www/src/content/docs/zh-cn/demo-liquid-glass-portal.browser.test.ts';
export default {...base, plugins:[{name:'private-failure-only-portal-observation',enforce:'pre',load(id){if(id.split('?')[0].replace(/^\/@fs/,'')===target)return fs.readFileSync('<TASK_STATE>/portal-failure-observation/observed-v2.browser.test.ts','utf8');return null;}},...(base.plugins??[])],test:{...base.test,include:['apps/www/src/content/docs/zh-cn/demo-liquid-glass-portal.browser.test.ts'],maxWorkers:1,minWorkers:1,fileParallelism:false}};
