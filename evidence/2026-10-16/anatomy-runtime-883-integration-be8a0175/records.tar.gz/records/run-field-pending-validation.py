from pathlib import Path
import subprocess,os,json,datetime,hashlib,sys
R=Path(__file__).parent;W=Path('<SOURCE_ROOT>');O=R/'field-pending-publication-fix';env=dict(os.environ);env['PATH']="<REDACTED_PATH>";now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda b:hashlib.sha256(b).hexdigest()
files=['packages/prototypes/base/src/field/root.proto.ts','packages/prototypes/base/test/notification-retirement-lifecycle.test.ts','spec/tests/T-FIELD-VALIDATION-INTERRUPTIONS-0001.yaml'];before={p:sha((W/p).read_bytes()) for p in files};old=json.loads((R/'combined-validation/focused/receipt.json').read_text())['command'];cmd=old[:-2] if False else old[:];insert=cmd.index('--maxWorkers=2');extra=[]
for pattern in ['field*.test.ts','form*.test.ts']:
 for p in sorted((W/'packages/prototypes/base/test').glob(pattern)):
  rel=str(p.relative_to(W))
  if rel not in cmd:extra.append(rel)
cmd[insert:insert]=extra
commands=[('focused-expanded',cmd),('spec-authoring',['corepack','pnpm@10.32.1','check:spec-authoring','--','--base','2b8757f4516da60d3a3b31e9ec4df7401b3d3195']),('spec-tests',['corepack','pnpm@10.32.1','exec','vitest','run','packages/spec','--maxWorkers=2','--minWorkers=1']),('types',['corepack','pnpm@10.32.1','check:types'])];results=[]
for name,command in commands:
 x={'start':now(),'command':command,'physicalHead':'fb71c01c6e8854028b903aedec781cddad2c8444','sourceClass':'fb71+threefileFieldcandidate; precommit','sourceSHA256':before,'node':subprocess.check_output(['node','--version'],env=env,text=True).strip()}
 with (O/(name+'.log')).open('w') as f:p=subprocess.run(command,cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT)
 x.update(end=now(),exitCode=p.returncode,sourceAfterSHA256={p:sha((W/p).read_bytes()) for p in files},logSHA256=sha((O/(name+'.log')).read_bytes()));assert x['sourceAfterSHA256']==before;(O/(name+'-receipt.json')).write_text(json.dumps(x,indent=2)+'\n');results.append(x);print(json.dumps({'name':name,'exitCode':p.returncode,'end':x['end']}),flush=True)
 if p.returncode!=0 and name not in ['spec-authoring']:break
(O/'validation-runs.json').write_text(json.dumps(results,indent=2)+'\n')
