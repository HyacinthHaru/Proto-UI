# be8 Homepage family option：只读边界报告

**当前CI失败未关闭，未建立新的C实现缺陷，也未归为继承或C范围外。** 精确be8原测试SHA`cc14f857…`；本报告partial/ABSTAIN，没有编辑、测试或浏览器执行。

CI job116777736718的case在chooseControl303/caller819失败：`family option brutalist`的即时count为0。此前activecontrol/combobox各1、triggerclick、非空aria-controls、该IDportal可见及唯一已通过；optionclick304、新generation等待820、semanticfocus821、旧portal退役822均尚未执行。因此不能把该红称为语义focus或cleanup断言失败。

`getByRole(option,name=Brutalist,exact=true)`默认排除ARIA-hidden元素；count0不等于没有ItemDOM。声明源码确实提供Shadcn/Brutalist两项，fullShadcn实际包装Surface/Viewport/ItemText，Content只是定位frame。hostgenerationready/父portalvisible都不能单独证明后续coldSelect的所有optionrole、accessibleName和隐藏状态已就绪。缺失败时DOM/AX与owner/generation，暂不能区分无节点、role/name未满足、隐藏或指向错误target。

适用draft边界是D-HOST-PROTOTYPE-PROJECTION-SCOPE的generation/focus、BaseSelectContent的collection/presentationadmission、Item的optionname，以及C-HOST-VIEW-ATTACHMENT的children/ancestorreadiness。真实违反可能涉及C/Adapter/Select或Websitefixture；source未改不构成归属豁免，也没有证据将其连到新的Fieldpending修复。

Root的一次原始隔离控制实际于**02:52:30–02:52:43UTC**在cleanbe8通过：**1pass/4filtered**，case3939ms，原source/assertion/timeout不变。它不是Linux共享server的10suite环境，也不是原全5case；只能记录此次未复现，不能叫flake或修复。

同一CI分片完整结果109pass/14fail/46skip；contrast-probe是独立beforeAll30s失败，46未执行，不是46断言失败。与本option红没有已证共同原因。

保留CI红、localpositive和未知分类；没有first-divergence证明，不修改产品或弱化等待/断言。详细sourceblob/criterion、原log与控制receipt SHA见source-trace.json。可进入最终冻结包QA，但该报告不宣称Homepage已修或全局失败均不属C。
