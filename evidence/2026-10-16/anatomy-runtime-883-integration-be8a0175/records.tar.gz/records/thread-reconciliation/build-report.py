import json, hashlib, subprocess, re
from pathlib import Path
from datetime import datetime, timezone
W=Path('<SOURCE_ROOT>')
R=Path('<TASK_STATE>')
O=R/'thread-reconciliation'
HEAD='84ce84fdce5a15f58f12978d5cea1c24d554f0d8'
PRE='26feceeb769ed9688ad652262631bc953cc43b9a'
TREE='ac120a185a1b2d48e4a8961fad526b3399ef7944'
N='packages/prototypes/base/test/notification-retirement-lifecycle.test.ts'
OT='packages/modules/overlay/test/host-callback-reentrancy.test.ts'
F='packages/prototypes/base/src/field/root.proto.ts'
TG='packages/prototypes/base/src/toggle-group/root.proto.ts'
OV='packages/modules/overlay/src/impl.ts'
def git(*args): return subprocess.check_output(['git',*args],cwd=W)
def sha(b):return hashlib.sha256(b).hexdigest()
def evidence(p):
 b=(R/p).read_bytes();return {'path':p,'sha256':sha(b),'bytes':len(b)}
def ref(path,a,b=None):
 return {'path':path,'lineStart':a,'lineEnd':b or a,'url':f'https://github.com/Proto-UI/Proto-UI/blob/{HEAD}/{path}#L{a}'+(f'-L{b}' if b and b!=a else '')}
def test(path,a,title,variants,expectation):
 return {**ref(path,a),'title':title,'variants':variants,'expectation':expectation,'executionEvidence':'same-tree-focused'}
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse','HEAD^{tree}').decode().strip()==TREE
assert not git('status','--porcelain')
live=json.loads((R/'live.json').read_text());threads=live['prs']['888']['threads']['items'];assert len(threads)==9
focused=json.loads((R/'combined-validation/focused/receipt.json').read_text())
authoring=json.loads((R/'combined-validation/authoring/receipt.json').read_text())
assert focused['indexTree']==TREE and focused['exit']==0
cases=[
 {'id':'4270798986','short':'Field：排队 pending 观察者先于旧请求通知', 'commit':'81cea4675483e382ba4e7c72be5093b615fcad80',
 'source':[ref(F,188,211),ref(F,241,259)],
 'authority':['T-FIELD-VALIDATION-INTERRUPTIONS-0001-CASE-PUBLICATION','C-FIELD-0001-ASYNC'],
 'tests':[test(N,592,'Field Root retires queued pending publication entered from dirty after %s',['normal','cancel','reset','dispose','newer'],'从 dirty State callback 进入 validate；排队 pending subscriber 退休/替换后不发旧 ID，normal/newer 的当前 ID 和结果仍可用。')],
 'reason':'Field-owned publication depth 将合法 nested emitter 留到外层 publish unwind；emit 前后均检查 current owner 与 exact pending request。五个原回归直接覆盖 queued State 路径。'},
 {'id':'4271328764','short':'Field：旧 validate 不覆盖较新 deferred emitter','commit':'91af833e53dc57326d069cf834697d3271c29f0f',
 'source':[ref(F,248,259)],'authority':['T-FIELD-VALIDATION-INTERRUPTIONS-0001-CASE-PUBLICATION'],
 'tests':[test(N,746,'Field Root retains newer validation entered during Context and pending publication',['single'],'Context 进入旧 validate，pending subscriber 进入新 validate；外层 input 返回点只发 newer，old resolve 被拒，newer resolve 可用。')],
 'reason':'249 行在构造/存入 afterPublication 前检查 owner 与 exact pending object，258 行虽仍是单 slot，stale frame 已不能覆盖它；延后 emit 的 guard 保留。'},
 {'id':'4272267609','short':'Overlay：terminal cleanup 后不能重获资源或 Escape','commit':'fb14c6a9085039b630f0a6a7d9c557e16e1174af',
 'source':[ref(OV,182,189),ref(OV,250,261),ref(OV,458,468),ref(OV,515,536)],
 'authority':['M-OVERLAY-0001-C','T-OVERLAY-CATALOG-0001-CASE-HOST-REENTRY'],
 'tests':[test(OT,378,'terminal replacement during ${stage} release cannot reacquire resources',['detach','unmount'],'still-mounted terminal release 安装 B 并抛 Error；保留原 Error，A/B portal/layer/modal 全零，B 不 acquire，逻辑 outside/regions 清理。'),test(OT,408,'terminal replacement cannot rejoin Escape scope after cleanup',['single'],'terminal replacement 不重新加入 Escape ownership；原 Error identity 保持。')],
 'reason':'currentViewGuard 与 syncEscapeCandidate 都要求 protoPhase 非 unmounted，queued reconciliation 即使仍被调用也不能在 terminal 后 acquire。测试是直接 Module/provider fixture，不是 native Escape journey。'},
 {'id':'4272267620','short':'Toggle Group：等待同 channel 排队 Context 退休','commit':'ca2f6881eb7b7d6a287ee41ef4c2974e62546bef',
 'source':[ref(TG,53,80),ref(TG,89,110),ref(TG,130,137)],
 'authority':['P-BASE-TOGGLE-GROUP-REQUEST-RETIREMENT','P-BASE-TOGGLE-GROUP-NOTIFICATION-ORDER','T-TOGGLE-GROUP-REQUEST-RETIREMENT-0001-CASE-QUEUED'],
 'tests':[test(N,814,'Toggle Group waits for queued Context retirement after %s',['normal','nested','unmount','dispose','remount'],'正常 A 通知一次；nested A→B→C 为 B,C,A；queued unmount/dispose/remount 不发旧 tail，remount 后 fresh 请求仍可用。')],
 'reason':'Root-owned depth/queue 延后 nested notifications，逐项检查 owner/viewEpoch；原排队 subscriber 的退休先于 emit。没有修改 Context API 或全局调度。'},
 {'id':'4273098747','short':'Toggle Group：补齐定义与必需测试映射','commit':'e3d5234123ebdc1be47eaeaec5c74efeac40d73f',
 'source':[ref('spec/prototypes/P-BASE-TOGGLE-GROUP.yaml',21,26),ref('spec/tests/T-TOGGLE-GROUP-REQUEST-RETIREMENT-0001.yaml',9,43)],
 'authority':['P-BASE-TOGGLE-GROUP-REQUEST-RETIREMENT','P-BASE-TOGGLE-GROUP-NOTIFICATION-ORDER','T-TOGGLE-GROUP-REQUEST-RETIREMENT-0001'],
 'tests':[test(N,661,'Toggle Group stops old notification during Context %s',['normal','unmount','dispose','nested','remount'],'直接 Context owner/view 退休与合法 nested/remount 控制；正式标题按下方源码核对。'),test(N,814,'Toggle Group waits for queued Context retirement after %s',['normal','nested','unmount','dispose','remount'],'CASE-QUEUED'),test(N,901,'Toggle Group retains queued notification order when a valueChange callback reenters',['single'],'CASE-REENTRY'),test(N,951,'Toggle Group retires a detached owner during Context %s',['normal','dispose'],'CASE-LIFETIME never-mounted'),test(N,1000,'Toggle Group drains an accepted nested notification before a Context callback error escapes',['single'],'CASE-CALLBACK-ERROR')],
 'reason':'当前 P 明确定义 request retirement 与有限 notification FIFO，T 有四 cases、required Runtime implementation、exercises/consumesCases 与同一路径。定义缺口已补，但 P/T 均 draft，implementation needs-review，不代表稳定准入或审批。'},
 {'id':'4273098759','short':'Toggle Group：valueChange 重入保持既有 FIFO','commit':'e3d5234123ebdc1be47eaeaec5c74efeac40d73f',
 'source':[ref(TG,66,80),ref(TG,103,109)],
 'authority':['P-BASE-TOGGLE-GROUP-NOTIFICATION-ORDER','T-TOGGLE-GROUP-REQUEST-RETIREMENT-0001-CASE-REENTRY'],
 'tests':[test(N,901,'Toggle Group retains queued notification order when a valueChange callback reenters',['single'],'B,C 已排队，B callback 接受 D；实际断言 B,C,D,A，所有 accepted true，完成顺序断言后 current value D。')],
 'reason':'drain 期间 publicationDepth 保持非零，while shift 消费同一队列；D 追加在 C 后。这里只引用当前 green 的 value D 断言，不回填早期 red 在顺序失败后未执行的 D 断言。'},
 {'id':'4274326282','short':'Field：Context 后续 Error 不丢当前 deferred validation','commit':'29b44b92ec8c893c3d26dde37414e5cd4e8409fc',
 'source':[ref(F,199,211),ref(F,241,259)],
 'authority':['C-CONTEXT-0010-H','T-FIELD-VALIDATION-INTERRUPTIONS-0001-CASE-PUBLICATION'],
 'tests':[test(N,1057,'Field Root retains current validation after later Context subscriber %s',['normal','error'],'早 subscriber validate，晚 subscriber Error；Context pending 队列完整、input 返回点有当前 ID、pending/result 可用、同一 Error 仍逸出。')],
 'reason':'publish finally 不再以 completed=false 丢弃 emitter；仍须通过 exact owner/request 检查。该回归限一个 later Error 与正常 emitter，不定义任意双重异常/raw falsy 的全局策略，也不识别浏览器 missing-provider 错误。'},
 {'id':'4274326296','short':'Toggle Group：未 mounted 的 Root dispose 也退休','commit':'f5169aafbebf64647b44c6ef8d81a1a8fec5e23e',
 'source':[ref(TG,89,110),ref(TG,128,137)],
 'authority':['P-BASE-TOGGLE-GROUP-REQUEST-RETIREMENT','T-TOGGLE-GROUP-REQUEST-RETIREMENT-0001-CASE-LIFETIME','C-LIFECYCLE-0007-C'],
 'tests':[test(N,951,'Toggle Group retires a detached owner during Context %s',['normal','dispose'],'created-but-never-mounted Root，public collection 能见 Item；dispose 时 accepted true/no old event/instance disposed；normal 仍 emit。')],
 'reason':'onBeforeDispose 与 onUnmounted 同样推进 epoch 并清 runNow，已 detached 不走 onUnmounted 也不会留下旧 owner。'},
 {'id':'4274326311','short':'Toggle Group：Context Error 前保留已接受 nested 通知','commit':'f5169aafbebf64647b44c6ef8d81a1a8fec5e23e',
 'source':[ref(TG,66,80),ref(TG,103,110)],
 'authority':['C-CONTEXT-0010-H','P-BASE-TOGGLE-GROUP-NOTIFICATION-ORDER','T-TOGGLE-GROUP-REQUEST-RETIREMENT-0001-CASE-CALLBACK-ERROR'],
 'tests':[test(N,1000,'Toggle Group drains an accepted nested notification before a Context callback error escapes',['single'],'早 subscriber 接受 B，晚 subscriber 抛 Error；Context A/B 已交付、nested 返回 true、current B、emit B，原 Error identity 保持；outer A 不新增通知。')],
 'reason':'finally 在 Context 报错后仍 drain 当前有限队列，原 completed gate 已移除。证据不扩展为所有 emitter 异常继续策略。'}
]
# Resolve direct-case label against the actual file rather than retaining a reconstructed name.
ns=git('show',f'{HEAD}:{N}').decode().splitlines()
for i,line in enumerate(ns,1):
 if 'Toggle Group stops' in line and 'Context' in line:
  cases[4]['tests'][0]['title']=line.strip().strip("',")
  cases[4]['tests'][0].update(ref(N,i))
  cases[4]['tests'][0]['expectation']='直接 Context owner/view 退休与合法 nested/remount 控制。'
  break
else:
 raise RuntimeError('direct Toggle case title not found')
byid={t['comments']['nodes'][0]['url'].split('_r')[-1]:t for t in threads}
for row in cases:
 t=byid[row['id']];c=t['comments']['nodes'][0]
 row.update({'threadNodeId':t['id'],'commentNodeId':c['id'],'url':c['url'],'originalTitle':c['body'].split('</sub>  ',1)[1].split('**',1)[0],'commentCreatedAt':c['createdAt'],'commentUpdatedAt':c['updatedAt'],'commentBodySHA256':sha(c['body'].encode()),'snapshotIsOutdated':t['isOutdated'],'snapshotLine':t['line'],'snapshotIsResolved':t['isResolved'],'sourceDisposition':'source-addressed','platformDisposition':'open at recorded snapshot','formalApproval':'ABSTAIN','viewerCanResolve':'unknown: field not present in this snapshot'})
 assert subprocess.run(['git','merge-base','--is-ancestor',row['commit'],HEAD],cwd=W).returncode==0
 row['fixCommitIsAncestorOfReviewedHead']=True
 row['fixCommitTitle']=git('show','-s','--format=%s',row['commit']).decode().strip()
 row['fixCommitURL']='https://github.com/Proto-UI/Proto-UI/commit/'+row['commit']
paths={F,TG,OV,N,OT,'spec/contracts/C-CONTEXT-0010.yaml','spec/contracts/C-LIFECYCLE-0007.yaml','spec/contracts/C-LIFECYCLE-0008.yaml','spec/contracts/C-FIELD-0001.yaml','spec/modules/M-OVERLAY-0001.yaml','spec/tests/T-FIELD-VALIDATION-INTERRUPTIONS-0001.yaml','spec/tests/T-OVERLAY-CATALOG-0001.yaml','spec/prototypes/P-BASE-TOGGLE-GROUP.yaml','spec/tests/T-TOGGLE-GROUP-REQUEST-RETIREMENT-0001.yaml'}
sources=[]
for p in sorted(paths):
 b=git('show',f'{HEAD}:{p}');old=git('show',f'{PRE}:{p}');s=b.decode();st=re.search(r'^status: (.+)$',s,re.M)
 x={'path':p,'blob':git('rev-parse',f'{HEAD}:{p}').decode().strip(),'sha256':sha(b),'bytes':len(b),'sameBytesAsSnapshotHead26fe':b==old,'sameBytesAsWorkingTree':b==(W/p).read_bytes(),'url':f'https://github.com/Proto-UI/Proto-UI/blob/{HEAD}/{p}'}
 if st:x['catalogStatus']=st.group(1)
 if p in focused['sourceSHA256']:
  x['matchesFocusedTestSourceSHA256']=focused['sourceSHA256'][p]==sha(b);assert x['matchesFocusedTestSourceSHA256']
 assert x['sameBytesAsWorkingTree'] and x['sameBytesAsSnapshotHead26fe']
 sources.append(x)
for row in cases:
 for t in row['tests']:
  s=git('show',f'{HEAD}:{t['path']}').decode().splitlines();line=s[t['lineStart']-1]
  assert t['title'] in line,(t,line)
report={'schema':'pui-private-source-thread-reconciliation/v1','createdAt':datetime.now(timezone.utc).isoformat(),'mode':'human-assisted/current-user','assessment':'advisory; unassessed; partial/ABSTAIN','scope':'Read-only reconciliation of nine existing PR #888 bot threads against exact 84ce source and already completed evidence. No tests, product edits, platform mutations or independent approval performed.','reviewerIndependence':'Contributor reconciliation; this agent contributed private candidates earlier. Not an independent review or formal APPROVED disposition.','source':{'head':HEAD,'tree':TREE,'workingTreeCleanAtRead':True,'snapshotHead':PRE,'checkedPaths':len(sources),'allCheckedPathsByteIdenticalTo26fe':True,'files':sources},'githubSnapshot':{**evidence('live.json'),'at':live['at'],'head':live['prs']['888']['headRefOid'],'threadCount':9,'pages':len(live['prs']['888']['threads']['pages']),'complete':all(t.get('allCommentsComplete') and not t['comments']['pageInfo']['hasNextPage'] for t in threads),'allThreadsOpen':all(not t['isResolved'] for t in threads),'viewerCanResolve':'not returned; unknown','limits':'Platform state is the recorded 00:03:59 snapshot at 26fe, not a new post-84ce API read. Current source is separately bound to 84ce.'},'executionEvidence':{'same-tree-focused':{'receipt':evidence('combined-validation/focused/receipt.json'),'log':evidence('combined-validation/focused/run.log'),'start':focused['start'],'end':focused['end'],'node':focused['node'],'command':focused['command'],'actualSourceBasis':focused['sourceBasis'],'executedIndexTree':focused['indexTree'],'commitWithSameTree':HEAD,'commandExit':focused['exit'],'filesPassed':67,'testsPassed':1116,'relevantFiles':[{'path':N,'testsPassed':101,'logLine':54},{'path':OT,'testsPassed':32,'logLine':219}],'notRerunInThisTask':True,'provenanceLimit':'Executed before merge commit at physical 26fe plus staged 2b. Exact tree equals 84ce; not a post-commit execution. Wrapper exited 1 on raw index serialization/stat refresh after successful commands; content and source were unchanged.','wrapperCorrection':evidence('validation-wrapper-binding-correction.json')},'authoring':{'receipt':evidence('combined-validation/authoring/receipt.json'),'log':evidence('combined-validation/authoring/run.log'),'command':authoring['command'],'start':authoring['start'],'end':authoring['end'],'exit':authoring['exit'],'sourceBasis':authoring['sourceBasis'],'tree':authoring['indexTree'],'changedCatalogInputsChecked':4,'limit':'Bounded authoring check, not full catalog acceptance or promotion of draft entities.'}},'rows':cases,'newConcreteFindings':[],'result':{'sourceAddressed':9,'sourceUnresolved':0,'sourceUnknownWithinTheseSpecificThreads':0,'platformOpenAtSnapshot':9,'formalApprovalsSubmitted':0,'threadsResolved':0},'limits':['The current-line/outdated flag is navigation metadata, not a correctness or source-addressed decision.','P-BASE-TOGGLE-GROUP, its T entity, C-FIELD and the named publication mappings retain their recorded draft/needs-review boundaries.','RuntimeSession tests use synthetic host fixtures; Overlay tests use actual Module/provider methods. They do not prove native focus, layout, assistive-technology, complete Adapter/Compiler conformance or Linux timing behavior.','Error tests establish the named later Context Error and normal notification sink boundaries, not a global arbitrary-throw/dual-error policy.','No old failing test assertion is marked as executed if an earlier assertion terminated that run; current green regression reaches the final value assertion.','No inference of absent GitHub permissions from hidden state. Root reports upstream READ and the collaboration resolver requires WRITE/MAINTAIN/ADMIN; this task makes no resolve attempt and requests no permission.','All nine conclusions address their exact original complaints only; no claim that all C work, the PR or canonical CI is complete.']}
(O/'source-reconciliation-84ce.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=['# PR #888：9 条旧 thread 的 exact-source 对账','',f'源码 **{HEAD}**，tree **{TREE}**。只读结论：九项均 `source-addressed`，未发现这九条范围内的新具体问题；这不是独立 APPROVE 或平台 resolve。','',f'平台状态取自 `live.json`（{live["at"]}、head `{PRE}`）：9 条全部 open，comments 完整；未返回 `viewerCanResolve`。本轮未重新读取平台状态，也未修改任何 thread。原 non-outdated/current-line 状态不会自行否定已移动到前置位置的 guard。','', '当前回归证据为 **同 tree 的提交前执行**：00:07:12–00:07:33 UTC、Node 24.21.0，physical 26fe + staged 2b，67 文件 / 1116 tests 通过；其中 notification-retirement 101、Overlay host-callback 32。准确 test SHA 与 84ce 相等。外层 wrapper 因 Git stat refresh 改变 index 序列化字节而 exit 1，两个命令实际 exit 0，tree/源码未变；原记录及 correction 均保留，没有补跑。','', '4 个 changed catalog inputs 的 authoring check exit 0；这不把 draft 或 `needs-review` 提升为稳定或已准入状态。','', '| 反馈 | exact 84ce 源码 | 直接回归 | 结论 / 平台状态 |','| --- | --- | --- | --- |']
for row in cases:
 sr='；'.join(f'[{Path(x["path"]).name}:{x["lineStart"]}]({x["url"]})' for x in row['source'])
 tr='；'.join(f'[{x["title"]}]({x["url"]}) ×{len(x["variants"])}' for x in row['tests'])
 lines.append(f'| [{row["id"]}]({row["url"]}) {row["short"]} | {sr} | {tr} | source-addressed / snapshot open |')
lines+=['','逐项判断依据：','']
for row in cases:
 lines.append(f'- **{row["id"]}**：{row["reason"]} 修复提交 [{row["commit"][:8]}]({row["fixCommitURL"]}) 是 84ce 的祖先。Authority：`'+ '`, `'.join(row['authority'])+'`。')
lines+=['','`source-reconciliation-84ce.json` 保存了 14 个源码/测试/authority 文件的 Git blob 与 SHA256、9 条原评论 body SHA、fix ancestry，以及原 focused/authoring/correction 文件 SHA。14 路径逐字等于快照 head 26fe 和当前 clean 工作树；没有把旧 CI 当本轮执行。','', '这些 RuntimeSession / Module fixture 证明对应 owner/publication/FIFO/terminal 边界；不扩张为原生焦点、视觉、AT、完整 Adapter/Compiler 或 Linux 性能验收。涉及 Context Error 的回归只覆盖所列 Error/sink 情况，不定义任意双重异常或 raw-falsy 的全局政策。','', '本报告是参与实现者的源码与证据对账，保持 **human-assisted / advisory / partial / ABSTAIN**。Root 已确认当前 resolver 要求 WRITE/MAINTAIN/ADMIN 而上游是 READ，本轮不尝试或绕过 resolve，也不申请权限；此表只供维护者审阅。']
(O/'source-reconciliation-84ce.md').write_text('\n'.join(lines)+'\n')
assert not git('status','--porcelain')
for p in [O/'source-reconciliation-84ce.json',O/'source-reconciliation-84ce.md']:
 print(p,sha(p.read_bytes()),p.stat().st_size)
