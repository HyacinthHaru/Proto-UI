from pathlib import Path
import subprocess,datetime,json,hashlib,os
w=Path('<SOURCE_ROOT>');r=Path(__file__).parent/'portal-close-symmetry-fix';f='apps/www/src/content/docs/zh-cn/demo-liquid-glass-portal.browser.test.ts';expected=hashlib.sha256((r/'candidate.browser.test.ts').read_bytes()).hexdigest();baseenv=dict(os.environ);baseenv['PATH']="<REDACTED_PATH>"
for key in ['PROTO_UI_MATERIAL_EVIDENCE_DIR','PROTO_UI_BROWSER_BASE_URL','DEBUG']:baseenv.pop(key,None)
filter='one-pixel source loss, intervening paint, withdrawal, registration revocation/restoration and preferences'
tasks=[('four-runtime-capture-off',['exec','vitest','run',f,'-t',filter,'--maxWorkers=1','--minWorkers=1'],False),('four-runtime-capture-on',['exec','vitest','run',f,'-t',filter,'--maxWorkers=1','--minWorkers=1'],True),('full55-capture-off',['exec','vitest','run',f,'--maxWorkers=1','--minWorkers=1'],False),('types-serial',['check:types'],False)]
rows=[]
for name,tail,capture in tasks:
 assert hashlib.sha256((w/f).read_bytes()).hexdigest()==expected
 env=dict(baseenv)
 if capture:env['PROTO_UI_MATERIAL_EVIDENCE_DIR']=str(r/'captured-artifacts')
 args=['corepack','pnpm@10.32.1',*tail];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/(name+'.log')).open('w') as log:z=subprocess.run(args,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 rec={'name':name,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':args,'exit':z.returncode,'physicalHead':'421208cae540c481ab297aa6d09203c49654f5e5','sourceClass':'421+savedonlyportaltestcandidate;notpostcommitexecution','executedTestSHA256':expected,'materialCapture':capture,'ordinaryNoScreenshotWaits':notcapture,'sourceAfterSHA256':hashlib.sha256((w/f).read_bytes()).hexdigest(),'statusAfter':subprocess.check_output(['git','status','--porcelain=v1'],cwd=w,text=True)};rows.append(rec);(r/(name+'-receipt.json')).write_text(json.dumps(rec,indent=2)+'\n');(r/'receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,z.returncode,(r/(name+'.log')).read_text()[-2200:],flush=True)
 if name.startswith('four-runtime') and z.returncode:break
