# Portal 退役前置条件：最终候选增量核对

**0 个具体源码 finding；partial / ABSTAIN。** 只读核对范围为 physical HEAD `84ce84fdce5a15f58f12978d5cea1c24d554f0d8` 加单文件候选，staged tree `4feed4f52477a26085b152a9c662465c4766e682`。不是 GitHub APPROVE 或整个 PR 验收。

候选只有 `demo-liquid-glass-portal.browser.test.ts` 的 **17+/2-**，SHA256 `06c311a7df13201e33ca9cbce495d3cf71b8c0c354ade63a0ec22e28baf4601c`。删除新增捕获/try-finally/poll 块并放回原 Escape 与 aria wait 后，与原文件逐字相同；其余 11205 tree entries 的 mode/kind/blob 均等于84。生产源码、原 case 列表、既有输入、optical predicate 和20000ms期限均未改变；新增等待确实改变了该位置的动作间时序。

修复把 `HC-OVERLAY-PORTAL-0001-BINDING/MATERIAL`、`C-AS-OVERLAY-0001-F/K` 已有的 physical-view 边界落实为测试前置条件。历史 Content 的 disconnected 或换父表明它退出旧 body/carrier 投射，容许 WC 仍 connected 的 owner shell；它不能单独证明全资源释放或新epoch成立，后续原 optical/firstFocus/contentCount/source/preferences 检查继续承担新view结果验收。

| 证据 | 实际结果与边界 |
| --- | --- |
| 原84 isolated WC | 1 fail /54 filtered，原957 quality undefined，20s |
| 84+单Overlay2b blob控制 | 同点1 fail，原84字节已恢复；不是完整2b checkout |
| failure-only v2 | 失败后1个 connected Content仍BODY、source-scope-unavailable、firstFocus在body、quality属性缺失；不是精确早期epoch轨迹 |
| 候选四Runtime | 4 pass /51 filtered；00:49:18–00:49:34 UTC |
| 候选完整55 | 54 pass /1 fail，exit1；四恢复case与16 public Dropdown均pass，唯一681 css-zoom baselineStability仍红；00:51:45–00:53:44 UTC |
| 首次types | generation阶段CLI dist/index.js缺失，exit1；原失败保留 |
| browser结束后串行types | 00:54:56–00:55:35 UTC，exit0；923 files/0 errors/0 warnings/14 hints |

完整55没有CLI过滤或删除断言。全文件原log也保留服务器初始CLI缺dist错误，之后harness实际到达并完成55cases；不能把那段前置错误抹掉或算作额外Vitest case。准确2b官方原log与84原log均已出现681同title/assertion；只能证明同失败位置存在，不能据此认定同根因或宣称本次文件全绿。

现有 `T-WEB-PORTAL-DESTINATION-0001` 为draft；`web-portal-native-content` 是required、needs-review，实际 consumesCases 是 NATIVE/INLINE-SIZE。ADAPTER/MATERIAL case提供所用生命周期边界，但这次没有伪称改了YAML映射或提升准入状态。

Root另已纠正新私有authority-map中的旧 `latest887Integrated=a62` 为准确2b；历史premerge记录未改。本review记录校正后的hash，不公开其中的私有授权引用。

全部原log/receipt/事实/authority/source blob与SHA见 `incremental-source-review.json`。本核对没有新增测试、浏览器、截图审阅、产品修改或外部写入。等待准确commit绑定与冻结公开包QA。
