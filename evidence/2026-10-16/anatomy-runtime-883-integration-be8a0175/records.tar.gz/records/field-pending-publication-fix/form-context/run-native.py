from pathlib import Path
import subprocess,os,json,datetime,hashlib,signal,re
p=Path(__file__).parent;w=Path('<SOURCE_ROOT>');head='be8a0175cf573058eb61aa1a43ae4fa8fae9b686';tree='742400b0a255ac89a62240bd55dab0dca5db4d55';o=p/'run-1';o.mkdir(exist_ok=False);a=o/'artifacts';a.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
env=os.environ.copy();env['PATH']="<REDACTED_PATH>";assert env.get('GITHUB_ACTIONS')!='true' and not env.get('CANDIDATE_SHA') and not env.get('PROTO_UI_BROWSER_BASE_URL')
env['PUI_FINF_FEATURE_GROUP']='forms';env['PUI_FINF_FEATURE_EVIDENCE_DIR']=str(a)
def git(*args):return subprocess.check_output(['git',*args],cwd=w,text=True).strip()
assert git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain=v1')
expected={}
for item in subprocess.check_output(['git','ls-tree','-r','-z',tree],cwd=w).split(b'\0'):
 if not item:continue
 meta,name=item.split(b'\t');mode,kind,blob=meta.decode().split();name=name.decode()
 if (name.startswith('packages/') and '/src/'in name) or name.startswith('apps/www/src/') or name in ['vitest.config.ts','apps/www/astro.config.mjs','pnpm-lock.yaml','package.json','apps/www/package.json']:
  expected[name]=(mode,blob)
def inputs():
 rows=[]
 for name,(mode,blob)in expected.items():
  f=w/name;b=os.readlink(f).encode() if mode=='120000' else f.read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
  rows.append({'path':name,'mode':mode,'expectedGitBlob':blob,'actualGitBlob':actual,'sha256':sha(b),'bytes':len(b),'matchesCandidate':actual==blob})
 return rows
before=inputs();assert all(x['matchesCandidate']for x in before);(o/'tracked-source-before.json').write_text(json.dumps(before,indent=2)+'\n')
command=['corepack','pnpm@10.32.1','exec','vitest','run','--config',str(p/'local.config.ts'),'--maxWorkers=1','--minWorkers=1']
record={'startedAt':now(),'candidateCommit':head,'candidateTree':tree,'physicalHeadBefore':git('rev-parse','HEAD'),'physicalTreeBefore':git('rev-parse','HEAD^{tree}'),'physicalStatusBefore':git('status','--porcelain=v1'),'preparedAgainstCleanCommit':head,'actualExecutionIsAfterSourceCommit':True,'privateBehaviorDriver':True,'appAuthoredCallbackObservationOverride':True,'notOfficialVisualSuite':True,'command':command,'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'pnpm':subprocess.check_output(['corepack','pnpm@10.32.1','--version'],env=env,text=True).strip(),'toolchainPATHPrefix':'<NODE24_TOOLCHAIN>/bin','environment':{'GITHUB_ACTIONS':env.get('GITHUB_ACTIONS'),'CANDIDATE_SHA':env.get('CANDIDATE_SHA'),'externalServer':env.get('PROTO_UI_BROWSER_BASE_URL')},'testSHA256':sha((p/'local.browser.test.ts').read_bytes()),'configSHA256':sha((p/'local.config.ts').read_bytes()),'sourceInputCount':len(before),'allBeforeInputsMatchCandidate':True,'outerBudgetSeconds':300}
(o/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
with (o/'run.log').open('w')as log:
 child=subprocess.Popen(command,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);record['childPid']=child.pid;record['processGroup']=child.pid;(o/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
 try:record['exit']=child.wait(timeout=300)
 except subprocess.TimeoutExpired:
  record['outerWatchdogExpired']=True;os.killpg(child.pid,signal.SIGTERM)
  try:record['exit']=child.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);record['exit']=child.wait(timeout=10)
after=inputs();(o/'tracked-source-after.json').write_text(json.dumps(after,indent=2)+'\n');bm={x['path']:x for x in before};am={x['path']:x for x in after};record['sourceByteChanges']=[k for k in bm if bm[k]!=am[k]];record['allAfterInputsMatchCandidate']=all(x['matchesCandidate']for x in after)
record.update(completedAt=now(),physicalHeadAfter=git('rev-parse','HEAD'),physicalTreeAfter=git('rev-parse','HEAD^{tree}'),physicalStatusAfter=git('status','--porcelain=v1'),logSHA256=sha((o/'run.log').read_bytes()))
rt=a/'local-runtime.json';ports=[]
if rt.exists():
 record['runtime']=json.loads(rt.read_text());ports=[int(record['runtime']['baseUrl'].rsplit(':',1)[1])]
else:ports=sorted({int(x)for x in re.findall(r'http://127\.0\.0\.1:(\d+)',(o/'run.log').read_text())})
record['listeningAfter']=[]
for port in ports:
 check=subprocess.run(['lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN'],capture_output=True,text=True);record['listeningAfter'].append({'port':port,'exit':check.returncode,'output':check.stdout})
(o/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
