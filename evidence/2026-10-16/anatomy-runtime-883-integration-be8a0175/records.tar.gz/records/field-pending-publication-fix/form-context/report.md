# be8 Form 行为复核

准确clean `be8a0175cf573058eb61aa1a43ae4fa8fae9b686` / tree `742400b0a255ac89a62240bd55dab0dca5db4d55`，**2026-10-16 02:23:33–02:23:52 UTC，2case/2pass/exit0**。Node24.21.0、pnpm10.32.1、Chrome155.0.8059.80当场记录。前后6775tracked输入均匹配该Git tree、0变化，port60140结束后无listener；已释放browser槽给Root。

原driver字节仍为85b21d7e…，行为、app-authored onSubmit旁观和timeout全部保持；仅私有config输入路径改变。Shadcn/Brutalist真实React页面均完成默认值→非法submit/首focus/ARIA→修正五字段submit→quantity/code/SMS编辑并再次submit→reset→再次非法submit→fresh有效submit。各3个callback，ID2/3/5、共6份payload逐项匹配：首份Formbehaviorone/2/12/25/[email]；第二份Formbehaviortwo/3/1234/25/[email,sms]；第三份Afterreset/2/12/25/[email]。非法submit与reset没有额外submit。

页面、console、接线、capture错误均0。70个trusted pointer/click/input/change事件及2个RuntimeTab untrustedclick分别保留；不将Playwright称作OS输入。原fixedHostClock2026-10-10保留，不把浏览器timeOrigin转换为真实UTC性能结论。

**14张新PNG全部逐张view_image**，新文件像素与旧84图恰相同，但仍归本次be8运行。两份终态DOM完整读取/解析、Form IDREF唯一目标与两份AX Form子树核对，能见Afterreset、Quantity2、Code12、Level25、Emailchecked/SMSunchecked。最终viewport下方文档和devtoolbar被裁剪，非完整页面。两个family的Label仍深色、Error红色，原Label/Error颜色判据仍不满足；本次正常行为通过不替代原官方视觉gate。

保留一项旧metadata标签：逐字复用的driver在49行硬编码candidateWorkingTree=ac120a，该值仍出现在4个新raw记录里。它只写metadata，不选择源；同记录physicalHead/tree、runreceipt及6775实际before/after均准确be8/7424。原raw不改、不重跑；[metadata-label-correction.json](metadata-label-correction.json)明确区分该旧标签与真实来源。

实际831请求中744tracked源映射，全部属于新be8；与旧84消费清单相比仅FieldRoot字节变化。87未绑定请求、依赖/生成CSS/Vite转换和appcallback的servedJS观察副本保持限制。原/观察模块分别35b77e06…与97410c3b…，两case一致，严格只有report前旁观及失效source-map删除。

没有配置Contextthrow、asyncvalidator、callback重入、退役、controlledreset或其它Adapter；新pending-Context异常修复由另外的正式Runtime红绿覆盖。此次未再现provider错误不证明旧错误根因已修。human-assisted、partial/ABSTAIN，无平台批准。
