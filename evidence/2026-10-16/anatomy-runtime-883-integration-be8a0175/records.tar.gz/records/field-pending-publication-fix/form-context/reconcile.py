from pathlib import Path
from urllib.parse import unquote
from html.parser import HTMLParser
from collections import Counter
from datetime import datetime,timezone
import json,hashlib,re,subprocess
p=Path(__file__).parent;o=p/'run-1';a=o/'artifacts';R=p.parents[1];old=R/'form-context';W=Path('<SOURCE_ROOT>');H='be8a0175cf573058eb61aa1a43ae4fa8fae9b686';T='742400b0a255ac89a62240bd55dab0dca5db4d55';sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
def ev(q):
 b=q.read_bytes();return {'path':str(q.relative_to(p)),'sha256':sha(b),'bytes':len(b)}
rec=json.loads((o/'receipt.json').read_text());ledger=json.loads((a/'observer-ledger.json').read_text());before=json.loads((o/'tracked-source-before.json').read_text());after=json.loads((o/'tracked-source-after.json').read_text());bm={x['path']:x for x in before}
assert before==after and len(before)==6775 and all(x['matchesCandidate'] for x in before)
assert rec['exit']==0 and rec['physicalHeadBefore']==rec['physicalHeadAfter']==H and rec['physicalTreeBefore']==rec['physicalTreeAfter']==T and rec['physicalStatusBefore']==rec['physicalStatusAfter']==''
assert not ledger['errors'] and all(x['output']=='' and x['exit']==1 for x in rec['listeningAfter'])
vitest=json.loads((a/'vitest.json').read_text());assert vitest['numPassedTests']==2 and vitest['numFailedTests']==0 and vitest['numPendingTests']==0
requested=[];unbound=[]
for url in ledger['requestedPaths']:
 decoded=unquote(url);rel=None
 if decoded.startswith('/@fs/'):
  try:rel=str(Path(decoded[4:]).relative_to(W))
  except ValueError:pass
 elif decoded.startswith('/src/'):rel='apps/www'+decoded
 if rel in bm:requested.append({'url':url,**bm[rel],'executionOverride':'App-authored submit observation in served JS; original/observed module bytes retained' if rel=='apps/www/src/content/docs/form-primitives-demo.shared.ts' else None})
 else:unbound.append(url)
prior=json.loads((old/'observed-source-binding.json').read_text());priorMap={x['path']:x for x in prior['requestedTracked']};requestChanges=[{'path':x['path'],'previousSHA256':priorMap.get(x['path'],{}).get('sha256'),'actualNewSHA256':x['sha256']} for x in requested if x['sha256']!=priorMap.get(x['path'],{}).get('sha256')]
assert len(requested)==744 and len(unbound)==87 and [x['path'] for x in requestChanges]==['packages/prototypes/base/src/field/root.proto.ts']
source={'actualHead':H,'actualTree':T,'sourceReceipt':ev(o/'receipt.json'),'trackedBefore':ev(o/'tracked-source-before.json'),'trackedAfter':ev(o/'tracked-source-after.json'),'trackedCandidateSnapshotCount':6775,'allBeforeAfterTrackedBytesMatchCandidate':True,'requestedPaths':len(ledger['requestedPaths']),'requestedTrackedCount':len(requested),'requestedTracked':requested,'unboundRequests':unbound,'changedRequestedInputsAgainstPrior84Run':requestChanges,'limit':'Request URL plus pre/post tracked Git byte binding, not emitted bundle metafile. Installed dependencies, generated CSS, Vite transforms and explicit served-JS observation are separately bounded.'}
(p/'observed-source-binding.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
original=subprocess.check_output(['git','show',H+':apps/www/src/content/docs/zh-cn/finf-representative-features.browser.test.ts'],cwd=W).decode();derived=(p/'local.browser.test.ts').read_text();assert derived.encode()==(old/'local.browser.test.ts').read_bytes()
def fn(s,n):
 st=s.index('async function '+n+'(');en=s.index('\nasync function ',st+5);return s[st:en]
assert fn(original,'formJourney')==fn(derived,'formJourney')
modules=[];observer='globalThis.__formBehaviorCallbacks.push({ at: performance.now(), timeOrigin: performance.timeOrigin, detail: structuredClone(detail) }); ';marker='refs.status.textContent = JSON.stringify(detail.values);'
for i,m in enumerate(ledger['callbackModules']):
 raw=(a/f'callback-module-{i}-original.js').read_text();observed=(a/f'callback-module-{i}-observed.js').read_text();assert raw.count(marker)==1
 assert observed==re.sub(r'// Public derivative: original source-map comment omitted
 assert sha(raw.encode())==m['originalSHA256'] and sha(observed.encode())==m['observedSHA256'];modules.append(m)
legacy='ac120a185a1b2d48e4a8961fad526b3399ef7944';stale=[]
for name in ['source.json','observer-ledger.json','shadcn-form.json','brutalist-form.json']:
 d=json.loads((a/name).read_text());assert d['candidateWorkingTree']==legacy;stale.append({'path':str((a/name).relative_to(p)),'sha256':sha((a/name).read_bytes()),'field':'candidateWorkingTree','value':legacy})
metadataCorrection={'at':now(),'rawFilesUnchanged':True,'legacyDriverLabel':legacy,'driverSourceLine':49,'reason':'The byte-identical reused85b driver embeds a historical candidateWorkingTree metadata constant. It is output-only, not the live source selection or expected-input binding. No raw field is rewritten and no rerun performed.','actualHead':H,'actualTree':T,'authoritativeBinding':ev(o/'receipt.json'),'files':stale,'otherRawSourceFields':'physicalHead/physicalHeadTree/revision/tree report be8/7424 where present; tracked before/after6775 also exactly match7424.'}
(p/'metadata-label-correction.json').write_text(json.dumps(metadataCorrection,indent=2)+'\n')
expected=[{'displayName':'Form behavior one','quantity':2,'code':'12','level':25,'channels':['email']},{'displayName':'Form behavior two','quantity':3,'code':'1234','level':25,'channels':['email','sms']},{'displayName':'After reset','quantity':2,'code':'12','level':25,'channels':['email']}]
stageFacts={'behavior-rest':'React selected; displayName empty; quantity2, code12, level25, Email checked and SMS unchecked.','behavior-invalid':'Empty displayName has a visible focus outline and a red required message; Label remains dark. Original Label/Error color gate is not satisfied.','behavior-corrected-submit':'Form behavior one and default composite values shown; original status renders the first five-field payload.','behavior-composite-submit':'Form behavior two, quantity3, code1234 and Email+SMS shown; original status matches the edited payload.','behavior-reset':'Controls reset to default values and the error clears; status retains the previous submit because the original demo writes it only onSubmit. No extra callback is claimed.','behavior-after-reset-submit':'After reset is submitted with default composite values; the new five-field status is visible.','final':'Actual public-page viewport with React selected and final Form state. Lower documentation and development toolbar are partly clipped by the viewport; not a full-page or optical/AT acceptance.'}
class DOM(HTMLParser):
 def __init__(self):super().__init__();self.stack=[];self.nodes=[];self.ids=Counter()
 def handle_starttag(self,tag,attrs):
  at=dict(attrs)
  if at.get('id'):self.ids[at['id']]+=1
  if at.get('role')=='form' or any(a.get('role')=='form' for _,a in self.stack):self.nodes.append({'tag':tag,'attrs':at})
  if tag not in ['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr']:self.stack.append((tag,at))
 def handle_endtag(self,tag):
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i][0]==tag:self.stack=self.stack[:i];break
visual=[];cases=[];terminal=[]
for family in ['shadcn','brutalist']:
 d=json.loads((a/f'{family}-form.json').read_text());assert d['result']=='passed' and not d['pageErrors'] and not d['captureErrors'] and not d['error'];assert d['physicalHead']==d['revision']==H and d['physicalHeadTree']==d['tree']==T
 callbacks=d['privateObservation']['callbacks'];assert [x['detail']['submissionId'] for x in callbacks]==[2,3,5] and [x['detail']['values'] for x in callbacks]==expected
 inputs=d['privateObservation']['nativeInputs'];counts=Counter((x['type'],x['trusted']) for x in inputs);untrusted=[x for x in inputs if not x['trusted']];assert len(untrusted)==1 and untrusted[0]['type']=='click' and untrusted[0]['target']['role']=='tab'
 color=next(x for x in d['screenshots'] if x['state']=='behavior-invalid')['observation']['originalColorPredicates'];assert color=={'labelEqualsField':True,'labelEqualsError':False,'labelChanged':False,'editorUnchanged':True}
 html=(a/f'{family}-form-terminal-dom.html').read_text();aria=(a/f'{family}-form-terminal-aria.txt').read_text();assert html.rstrip().endswith('</html>')
 dom=DOM();dom.feed(html);forms=[n for n in dom.nodes if n['attrs'].get('role')=='form'];assert len(forms)==1 and forms[0]['attrs']['aria-label']=='Profile form · 资料表单'
 idrefs=[]
 for n in dom.nodes:
  for key in ['aria-labelledby','aria-describedby','aria-errormessage']:
   for value in n['attrs'].get(key,'').split():idrefs.append({'attribute':key,'target':value,'targetCount':dom.ids[value]})
 assert all(x['targetCount']==1 for x in idrefs)
 lines=aria.splitlines();i=next(i for i,l in enumerate(lines) if 'form "Profile form · 资料表单"' in l);indent=len(lines[i])-len(lines[i].lstrip());j=i+1
 while j<len(lines) and (not lines[j].strip() or len(lines[j])-len(lines[j].lstrip())>indent):j+=1
 excerpt='\n'.join(lines[i:j]);assert 'After reset'in excerpt and 'spinbutton "Quantity · 数量": "2"' in excerpt and 'checkbox "Email · 邮件" [checked]' in excerpt and 'checkbox "SMS · 短信"' in excerpt
 terminal.append({'family':family,'DOM':ev(a/f'{family}-form-terminal-dom.html'),'AX':ev(a/f'{family}-form-terminal-aria.txt'),'formElementsRead':len(dom.nodes),'formCount':1,'IDREFs':idrefs,'AXFormSubtree':excerpt,'scope':'Full files read/hashed; actual Form DOM attributes and AX subtree reconciled. This is an accessibility snapshot, not OS AT execution; HTML value attributes are not substituted for live input properties.'})
 for shot in d['screenshots']:
  f=a/shot['file'];b=f.read_bytes();assert sha(b)==shot['sha256']
  previous=old/'run-1/artifacts'/shot['file'];visual.append({'family':family,'state':shot['state'],'path':str(f.relative_to(p)),'bytes':len(b),'sha256':sha(b),'dimensions':[int.from_bytes(b[16:20],'big'),int.from_bytes(b[20:24],'big')],'actuallyViewed':True,'method':'Each of these14 new files separately displayed with view_image; no editing/montage/reencoding.','visibleFacts':stageFacts[shot['state']],'actualHead':H,'actualTree':T,'actualRunStart':rec['startedAt'],'actualRunEnd':rec['completedAt'],'sourceDirty':False,'privateBehaviorAndCallbackObserver':True,'samePNGBytesAsPrior84':previous.read_bytes()==b,'limit':'Matching image bytes do not relabel the prior execution; this file belongs to the new be8 run.'})
 cases.append({'family':family,'runtime':'react','result':'passed','submitCallbacks':callbacks,'callbackIds':[2,3,5],'nativeInputCounts':[{'type':k[0],'isTrusted':k[1],'count':v} for k,v in sorted(counts.items())],'untrustedRuntimeTabClick':untrusted,'pageErrors':d['pageErrors'],'captureErrors':d['captureErrors'],'blockedRequests':d['blockedRequests'],'colorFacts':color,'images':7})
assert len(visual)==14
(p/'visual-review.json').write_text(json.dumps({'at':now(),'images':visual,'imageCount':14,'scope':'All14 new be8 images actually viewed; light desktop React only. Original color failures retained. No dark/narrow/fulloptical/OSAT claim.'},ensure_ascii=False,indent=2)+'\n')
(p/'terminal-dom-ax-review.json').write_text(json.dumps({'at':now(),'cases':terminal},ensure_ascii=False,indent=2)+'\n')
report={'schemaVersion':1,'kind':'fresh postcommit Form normal-flow native integration diagnosis','at':now(),'mode':'human-assisted/current-user;advisory/unassessed;partial/ABSTAIN','actualSource':{'head':H,'tree':T,'cleanBeforeAfter':True,'afterActualSourceCommit':True,'trackedSourceInputs':6775,'allBeforeAfterMatchGit':True,'changesDuringExecution':[],'legacyRawLabelCorrection':ev(p/'metadata-label-correction.json')},'run':{'receipt':ev(o/'receipt.json'),'log':ev(o/'run.log'),'start':rec['startedAt'],'end':rec['completedAt'],'exit':0,'tests':2,'passed':2,'failed':0,'skipped':0,'command':rec['command'],'node':rec['node'],'pnpm':rec['pnpm'],'chrome':rec['runtime']['chrome'],'macOSLocalNotCI':True,'fakeOfficialEnvUsed':False,'portCleanup':rec['listeningAfter']},'executable':{'driver':ev(p/'local.browser.test.ts'),'sameDriverBytesAsPrior84':True,'config':ev(p/'local.config.ts'),'configChange':'Only path to the identical private driver changed and was formatted beforeexecution','originalOfficialTestSHA256':sha(original.encode()),'originalFormJourneyFunctionUnchangedButNotExecuted':True,'servedCallbackModules':modules,'observerTransformationCheckedExact':True},'executionClass':'Independentbehavior cases on real public Form pages/currentrenderer, with oneapp-authored submitcallback observation insertion inservedJSbeforeoriginalstatuswrite. No productedits; not untouchedofficialdemo ororiginalcolor-gate execution.','cases':cases,'payloadSnapshots':[{'perFamilySubmissionId':k,'values':v} for k,v in zip([2,3,5],expected)],'callbacksTotal':6,'completedFlow':['Initialnamedfields/defaultcomposites','Invalidsubmit: error/ARIA/firstfocus andnoSubmit','Correctedfive-fieldsubmit','Quantityincrement/codefill/SMSnativeedit andsecondpayload','Resetdefaults/validation without extraSubmit','Invalidafterreset without extraSubmit','Freshvalidsubmit afterreset'], 'errors':{'pageerror':0,'consoleerror':0,'callbackWiring':0,'capture':0,'ledger':ledger['errors']},'nativeInputBoundary':{'trustedClicks':18,'trustedPointerDown':18,'trustedPointerUp':18,'trustedInputs':8,'trustedChanges':8,'untrustedRuntimeTabClicks':2,'meaning':'Actual Playwright browser events, not an OS/human input guarantee. Runtime semantic tabclick remains explicitly untrusted.'},'clockBoundary':'Original fixed2026-10-10 hostClock retained. Browserperformance/timeOrigin are fixture-clockaffected; NodeUTC runwindow isreal. No cross-clock latencyclaim.','sourceBinding':ev(p/'observed-source-binding.json'),'requestedTracked':744,'unboundRequests':87,'changedConsumedSourceAgainstOld84':requestChanges,'visualReview':ev(p/'visual-review.json'),'terminalReview':ev(p/'terminal-dom-ax-review.json'),'visualBoundary':'All14newPNGactuallyviewed; bothfamilies retainLabel/Error colorinequality andunchangedLabelink. Originalofficialcolorgate notexecuted orclaimedpassing.','resultBoundary':'Normaltwo-family ReactForm flow completed without Context providererror. This doesnotproveoldprovidererror causefixed or exercise the new throwingContextsubscriber regression; that is separateRuntimeformal evidence.','uncovered':['asyncvalidator/cancel/resolve lease','callback reentry/error/retirement/unmount/remount','controlledreset handshake/duplicate names','otherAdapters/keyboardimplicitEnter/IME/OSAT/dark/narrow/fullFinf','timing equivalence to unobserved originalCI'],'rawHistoryUnchanged':True,'sideEffects':'No trackedproduct/index/GitHub changes by thisagent. Nativeprocess ended and heavy slot released before visual/source reconciliation; subsequentroot jobs are outside this capturedwindow.'}
(p/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
md=f'''# be8 Form 行为复核

准确clean `{H}` / tree `{T}`，**2026-10-16 02:23:33–02:23:52 UTC，2case/2pass/exit0**。Node24.21.0、pnpm10.32.1、Chrome155.0.8059.80当场记录。前后6775tracked输入均匹配该Git tree、0变化，port60140结束后无listener；已释放browser槽给Root。

原driver字节仍为85b21d7e…，行为、app-authored onSubmit旁观和timeout全部保持；仅私有config输入路径改变。Shadcn/Brutalist真实React页面均完成默认值→非法submit/首focus/ARIA→修正五字段submit→quantity/code/SMS编辑并再次submit→reset→再次非法submit→fresh有效submit。各3个callback，ID2/3/5、共6份payload逐项匹配：首份Formbehaviorone/2/12/25/[email]；第二份Formbehaviortwo/3/1234/25/[email,sms]；第三份Afterreset/2/12/25/[email]。非法submit与reset没有额外submit。

页面、console、接线、capture错误均0。70个trusted pointer/click/input/change事件及2个RuntimeTab untrustedclick分别保留；不将Playwright称作OS输入。原fixedHostClock2026-10-10保留，不把浏览器timeOrigin转换为真实UTC性能结论。

**14张新PNG全部逐张view_image**，新文件像素与旧84图恰相同，但仍归本次be8运行。两份终态DOM完整读取/解析、Form IDREF唯一目标与两份AX Form子树核对，能见Afterreset、Quantity2、Code12、Level25、Emailchecked/SMSunchecked。最终viewport下方文档和devtoolbar被裁剪，非完整页面。两个family的Label仍深色、Error红色，原Label/Error颜色判据仍不满足；本次正常行为通过不替代原官方视觉gate。

保留一项旧metadata标签：逐字复用的driver在49行硬编码candidateWorkingTree=ac120a，该值仍出现在4个新raw记录里。它只写metadata，不选择源；同记录physicalHead/tree、runreceipt及6775实际before/after均准确be8/7424。原raw不改、不重跑；[metadata-label-correction.json](metadata-label-correction.json)明确区分该旧标签与真实来源。

实际831请求中744tracked源映射，全部属于新be8；与旧84消费清单相比仅FieldRoot字节变化。87未绑定请求、依赖/生成CSS/Vite转换和appcallback的servedJS观察副本保持限制。原/观察模块分别35b77e06…与97410c3b…，两case一致，严格只有report前旁观及失效source-map删除。

没有配置Contextthrow、asyncvalidator、callback重入、退役、controlledreset或其它Adapter；新pending-Context异常修复由另外的正式Runtime红绿覆盖。此次未再现provider错误不证明旧错误根因已修。human-assisted、partial/ABSTAIN，无平台批准。
'''
(p/'report.md').write_text(md)
print(json.dumps({'head':H,'testsPassed':2,'callbacks':6,'imagesViewed':14,'requested':len(ledger['requestedPaths']),'trackedRequested':len(requested),'unbound':len(unbound),'changedConsumedSource':requestChanges,'reportSHA256':sha((p/'report.json').read_bytes()),'visualSHA256':sha((p/'visual-review.json').read_bytes()),'sourceBindingSHA256':sha((p/'observed-source-binding.json').read_bytes()),'metadataCorrectionSHA256':sha((p/'metadata-label-correction.json').read_bytes())},indent=2))
