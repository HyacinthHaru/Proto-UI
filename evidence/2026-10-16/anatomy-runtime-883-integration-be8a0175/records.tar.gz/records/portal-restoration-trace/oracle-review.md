# Portal 恢复前置条件核对

结论：当前 Root 提出的 `!content.isConnected || content.parentElement !== capturedParent` 适合作为这个真实 Web fixture 的“旧 body/carrier 物理投射已退出”前置条件，未见阻止有界 candidate 验证的具体反例。保持 partial/ABSTAIN；这不是正式 APPROVE，也不是所有资源释放的通用证明。

failure-only v2 已实际观察：Content 唯一且 connected、parent BODY、scope/destination 均 false、source-scope-unavailable、firstFocus 实际在 body，quality 属性缺失。它证明最终恢复仍在 body，尚未直接记录此前每个 mountEpoch/conceal 瞬间。84+单文件2b Overlay 控制也同点失败，限定为这个单文件 pair，不冒称整版2b。

WC 的真实 restore 顺序是先 release material epoch，再将 Content 放回 author origin；shell 可以保持 connected。因此只等 disconnected 不够，而 parent 变化能越过尚可被新 open 取消的两-rAF conceal。新 true intent 仍在现有 reconciliation Promise 后排队，不会抢在旧 detach 完成前直接 attach。React 的父节点是 renderer carrier，卸载 carrier/旧 child 或返回 origin 均被这个条件接纳；Vue Teleport 与 Vue2 anchor restore 也覆盖断开或换父两种实现。没有新增 DOM 操作、产品状态写入或虚构 API。

它符合 draft HC-OVERLAY-PORTAL-0001-BINDING/MATERIAL 与 C-AS-OVERLAY-0001-F/K 的区分：logical close 不是 physical detach；登记恢复本身不授予 optical admission；下一真实投射仍须保留 logical owner/re-entry 并通过原 optical 检查。

边界必须保留：

- 外部作者任意搬节点/替换 Content，可让这个条件成立却不证明 lease 正常清理；本 fixture 在 Escape 与 poll 之间没有这种动作。
- 移走 DOM 但泄漏非 DOM 资源也可能满足它，所以只能称旧物理投射退出，不能称全资源清理完毕。
- 捕获的必须是 Escape 前那个严格单节点和父节点，不能在 poll 中重新选择一个新 Content。JSHandle 在 finally dispose。
- 新 poll 确实增加生命周期等待、改变动作间时序；只应说原输入、原 optical 断言和已有 deadline 保留，不能说时序完全未变。
- 原 optical 的 self-optical、firstFocus、contentCount、scope/source 等仍是恢复后的结果判据；candidate green 不回填旧 red，也不证明所有平台旧失败同因。

确切 source/blob/行、candidate SHA、原失败事实与单文件控制 receipt SHA 见 `oracle-review.json`。本次没有编辑、浏览器或测试执行。
