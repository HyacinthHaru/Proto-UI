# WC portal registration 恢复：首分歧只读链

准确源码 `84ce84fdce5a15f58f12978d5cea1c24d554f0d8` / tree `ac120a185a1b2d48e4a8961fad526b3399ef7944`。本报告只读，**partial / ABSTAIN**；尚未建立新增 C 缺陷，也没有把失败归给 B。

官方 `38828883938 / 116742738980` 是 779 pass / 4 fail，目标 WC case 在 `demo-liquid-glass-portal.browser.test.ts:957` 调 `optical()`，20 秒后 `quality` 最后值为 undefined。Root 的原 case 隔离执行于 00:39:06–00:40:00 UTC 在 clean 84 上同点失败（1 fail / 54 filtered），Node 24.21.0 / Chrome 155.0.8059.80。原有两张 capture 位于更早的 one-pixel / registration-pending 阶段，不能标成最终失败图。

已通过的动作只包括 `open()` 的真实 trigger click 和 menu visible；失败是 optical 的第一个 quality poll，后面的 firstFocus、scope、source admission 断言尚未执行。`geometry()` 先对选中的 Content 执行 bounds，再读 dataset，所以 undefined 不表示该次查询没有 Content；它表示所选 Content 没有 quality attribute。仍须核对它是否与 visible menu 相同、是否有多个实例。

最小有区分力的失败后快照是：原 `geometry()`、原 `activity()`、全部 content/menu 的交叉 identity 和 physical parent、连接/可见标记、data-material*、现有 `publicPortalSnapshot` 的实际 scene/canvas/祖先 CSS、DOM/PNG。注意 `publicPortalSnapshot.firstFocus` 读另一个 `window.publicPortalFirstFocus`，本独立 fixture 正确的观测入口是 `liquidPortalFixture.activity().firstFocus`。

源码给出一个待证边界：953 Escape 后只等 954 的 aria-expanded=false，立即恢复注册并重新 open。WC 的 false intent 先 conceal，再等待两次 rAF 进行物理 detach；若 present=true 取消尚待决的 conceal，`adapt.ts:1196` 会 reveal 同一 `owner.hasView`。旧 body view 此时遇到注册变化会被永久暂停材质，只有下一物理 view 的真实投射 commit 才 reset。`preview-material-provider.ts:65` 在 suspended/无 provider 时只保留普通 style，可能没有 quality；`sink.ts:370` 的 no-slot 路径或 sink release 同样可清掉该属性，所以不能只据 undefined 判定这一假设。

Authority 是 draft `C-AS-OVERLAY-0001-F/K`、`HC-OVERLAY-PORTAL-0001-BINDING/MATERIAL` 和 `M-OVERLAY-0001-C`：logical close 与 view detach 不等价；每个物理 epoch 固定 destination，下一真实投射才解除 suspension；实际 detach 后必须保留 logical ancestry/re-entry。没有规范依据把 aria-expanded=false 自行提升为新 epoch 已完成。

判别顺序：

1. 若 Content 仍在 body、suspended，先定位真实 detach/reopen 是否发生；这是 physical admission 分歧，尚非 GPU 采样错误。
2. 若真实 detach/new epoch 已观察，却没有通过当前 provider 重新投射，才把首分歧推进到 C Overlay owner/resource 与 WC acquisition。
3. 若 scene、unsuspended、新投射和 source admission 均正确但 quality 缺失，继续核对 Rule material slot / Feedback frame/view / preview provider sink 生命周期。
4. 若 sink 已给具体 unavailable/fallback reason，按该实际 guard 调查，不笼统归因材质。

21 个已检查文件对准确 2b 比较，仅 Overlay impl 有 diff；这是检查范围内的事实，不是全 bundle 输入清单或因果证明。Root 正在做的单 Overlay blob 配对保留原 test/fixture/所有其它 84 输入，不能称整版 2b 对照。若后续确实观测到 retained-epoch 路径，可另做一次等待真实 portal release 的生命周期条件控制，必须单独标记，不得把它算原测试通过或削弱原断言。

完整路径/行、Git blob/SHA256、原 CI 与 isolated receipt/log SHA、观察点和限制见同目录 `report.json`。本子任务没有执行测试/浏览器、修改产品或干预 Root 作业。
