from pathlib import Path
import json,hashlib,subprocess,re
from datetime import datetime,timezone
W=Path('<SOURCE_ROOT>');R=Path('<TASK_STATE>');O=R/'portal-retirement-fix'
H='84ce84fdce5a15f58f12978d5cea1c24d554f0d8';T='4feed4f52477a26085b152a9c662465c4766e682';B='2b8757f4516da60d3a3b31e9ec4df7401b3d3195';P='apps/www/src/content/docs/zh-cn/demo-liquid-glass-portal.browser.test.ts'
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
def sha(b):return hashlib.sha256(b).hexdigest()
def ev(p,base=R):
 b=(base/p).read_bytes();return {'path':str(base/p),'sha256':sha(b),'bytes':len(b)}
def ref(p,a,b):
 raw=git('show',f'{H}:{p}');return {'path':p,'lines':[a,b],'blob':git('rev-parse',f'{H}:{p}').decode().strip(),'sha256':sha(raw),'url':f'https://github.com/Proto-UI/Proto-UI/blob/{H}/{p}#L{a}-L{b}'}
base=git('show',f'{H}:{P}');candidate=git('show',f'{T}:{P}');assert sha(candidate)=='06c311a7df13201e33ca9cbce495d3cf71b8c0c354ade63a0ec22e28baf4601c'
s=candidate.decode();a=s.index('        const bodyProjection = await page\n');b=s.index('        await page.evaluate(() => (window as any).liquidPortalFixture.destination(true));',a)
old='        await page.keyboard.press(\'Escape\');\n        await expect.poll(() => trigger.getAttribute(\'aria-expanded\')).toBe(\'false\');\n'
assert (s[:a]+old+s[b:]).encode()==base
assert git('diff','--name-only',H,T).decode().splitlines()==[P]
assert git('diff','--numstat',H,T).decode().strip().split('\t')[:2]==['17','2']
ledger=git('ls-tree','-r',T).decode().splitlines();basemap={l.split('\t',1)[1]:l.split('\t',1)[0] for l in git('ls-tree','-r',H).decode().splitlines()};same=0
for line in ledger:
 metadata,p=line.split('\t',1)
 if p!=P:assert basemap[p]==metadata;same+=1
scope=json.loads((O/'receipt.json').read_text());full=json.loads((O/'full-file-receipt.json').read_text());types=json.loads((O/'types-serial-retry-receipt.json').read_text());am=json.loads((O/'authority-map.json').read_text());assert am['latest887Integrated']==B
fm=json.loads((O/'full-file-artifacts/portal/metadata.json').read_text())
restore=[x for x in fm['observations'] if x.get('destinationRegistrationDeferredUntilReopen')]
public=[x for x in fm['observations'] if x.get('publicContentOptical')]
assert len(restore)==4 and len(public)==16
for x in restore:assert all(x[y] for y in ['onePixelRejected','overlapRejected','foregroundMismatchRejected','sourceRecovered','pendingPreservedContentParentFocusAndOpen','preferencesFallback','disposed'])
assert types['exit']==0
historical=Path('<HISTORICAL_TASK_STATE>/sync-20261015T230423Z/independent-ci-887-2b')
x={'createdAt':datetime.now(timezone.utc).isoformat(),'mode':'human-assisted/current-user','disposition':'partial/ABSTAIN; read-only bounded candidate review; no GitHub approval','candidate':{'baseHead':H,'baseTree':git('rev-parse',f'{H}^{{tree}}').decode().strip(),'stagedTree':T,'path':P,'blob':git('rev-parse',f'{T}:{P}').decode().strip(),'sha256':sha(candidate),'originalBlob':git('rev-parse',f'{H}:{P}').decode().strip(),'originalSHA256':sha(base),'addedLines':17,'removedLines':2,'changedFiles':1,'otherTreeEntriesModeKindBlobIdentical':same,'allOutsideReplacementBlockByteIdentical':True,'productionChanges':False,'executedClass':'Precommit exact84 plus one changed test. Raw metadata correctly records physical84/treeac120 plus trackedDiff; not committed-after execution.','reviewedDiffSHA256':sha(git('diff',H,T,'--',P))},'findings':[],'resolvedMetadataObservation':{'kind':'private derived provenance field','description':'authority-map.json latest887Integrated was stale a62 while baseCurrent was2b; Root corrected this new map to2b. Initial premerge history remains unchanged. No product defect.', 'currentValue':am['latest887Integrated'],'currentEvidence':ev('portal-retirement-fix/authority-map.json'),'privateBoundary':'The raw map contains private authorization references and is not proposed for publication by this review.'},'reviewChecks':[
 'Exact 17+/2- single-file delta; removing the new captured-handle/try-finally/poll block and restoring the original Escape+aria wait produces byte-identical original test.',
 'The original optical helper, 20000ms quality deadline, all case bodies, existing actions and assertion predicates are unchanged outside the replacement block. The additional wait deliberately makes the physical-retirement precondition explicit.',
 'The strict locator captures the old Content and parent before Escape; poll evaluates that retained handle rather than selecting a new node. finally disposes only the JSHandle.',
 'The predicate permits a WC connected shell restored to origin and actual renderer child/carrier disconnection. It does not move DOM, set product state, force recovery, add retries, or extend an existing timeout.',
 'Original post-restoration optical, firstFocus, destination/scope/contentCount, source pixels/bounds, preferences and final disposal checks remain. No failure is skipped or relabeled in the complete55 execution.',
 'No requirement to alter Runtime/Overlay behavior or mint a new normative guarantee; the existing physical-view boundary is used by this concrete test.'
],'authority':[
 {**ref('spec/host-caps/HC-OVERLAY-PORTAL-0001.yaml',24,35),'status':'draft','criteria':['HC-OVERLAY-PORTAL-0001-BINDING','HC-OVERLAY-PORTAL-0001-MATERIAL']},
 {**ref('spec/contracts/C-AS-OVERLAY-0001.yaml',24,59),'status':'draft','criteria':['C-AS-OVERLAY-0001-F','C-AS-OVERLAY-0001-K']},
 {**ref('spec/tests/T-WEB-PORTAL-DESTINATION-0001.yaml',21,32),'status':'draft','criteria':['T-WEB-PORTAL-DESTINATION-0001-CASE-ADAPTER','T-WEB-PORTAL-DESTINATION-0001-CASE-MATERIAL','T-WEB-PORTAL-DESTINATION-0001-CASE-NATIVE'],'explanation':'The first two describe the physical-view and missing-provider/rebind boundary; the same existing native test remains the material acceptance implementation.'},
 {**ref('spec/tests/T-WEB-PORTAL-DESTINATION-0001.yaml',66,72),'implementationId':'web-portal-native-content','implementationStatus':'needs-review','required':True,'mappedConsumesCases':['T-WEB-PORTAL-DESTINATION-0001-CASE-NATIVE','T-WEB-PORTAL-DESTINATION-0001-CASE-INLINE-SIZE'],'mappingLimit':'The existing native implementation consumes NATIVE/INLINE-SIZE; do not falsely claim the YAML was changed or directly consumes all CASE-ADAPTER/CASE-MATERIAL entries.'}
],'evidence':{
 'original84Failure':{'receipt':ev('combined-validation/portal-wc-original-isolated/receipt.json'),'log':ev('combined-validation/portal-wc-original-isolated/run.log'),'counts':{'failed':1,'filteredSkipped':54},'failure':'Original caller957 optical quality undefined at20000ms'},
 'singleOverlayControl':{'receipt':ev('portal-overlay-control/receipt.json'),'counts':{'failed':1,'filteredSkipped':54},'class':'84 with only Overlay impl replaced by exact2b bytes, not a complete2b checkout','failure':'Same original caller957','restoredOriginalSHA256':'4c71c9534479782f7a15f05e77d30f63a1bd8b8a498adbc56e02c733ebdf9087'},
 'failureOnlyV2':{'receipt':ev('portal-failure-observation/receipt-v2.json'),'facts':ev('portal-failure-observation/artifacts-v2/restore-failure-facts.json'),'class':'Private failure-only observer after original rejection; distinct diagnostic test bytes','factsSummary':'One connected Content at BODY; scene/destination false; source-scope-unavailable; actual firstFocus body; quality attribute absent. Post-deadline facts do not record the exact earlier conceal-cancellation instant.'},
 'targetedCandidate':{'receipt':ev('portal-retirement-fix/receipt.json'),'log':ev('portal-retirement-fix/run.log'),'metadata':ev('portal-retirement-fix/artifacts/portal/metadata.json'),'start':scope['start'],'end':scope['end'],'exit':0,'passed':4,'filteredSkipped':51,'executedTestSHA256':scope['executedTestSHA256'],'runtimeOrder':['wc','react','vue','vue2']},
 'fullFileCandidate':{'receipt':ev('portal-retirement-fix/full-file-receipt.json'),'log':ev('portal-retirement-fix/full-file.log'),'metadata':ev('portal-retirement-fix/full-file-artifacts/portal/metadata.json'),'start':full['start'],'end':full['end'],'exit':1,'passed':54,'failed':1,'skipped':0,'originalCasesTotal':55,'executedTestSHA256':full['testSHA256'],'restorationCasesPassed':4,'publicDropdownCasesPassed':16,'remainingFailure':{'title':'measures the actual docs-shell fixed point with a disposable containment handover','assertion':'css-zoom: expected false to be true','line':681},'serverSetupLimit':'Raw full-file log also preserves an initial CLI dist/index.js missing startup error before the harness reached its completed55 execution; not erased or counted as an additional Vitest case failure.'},
 'knownOriginalCssZoomBoundary':{'foundation2bLog':ev('job-116644569689.log',historical),'foundation2bCounts':{'passed':780,'failed':3},'foundation2bFailureLocation':'samefile681 css-zoom baselineStability','original84Log':ev('canonical-84ce84fd/job-116742738980.log'),'original84Counts':{'passed':779,'failed':4},'scope':'Only matching failing title/assertion/line is established. Same location/count does not prove an identical cause. These are historical full Liquid suites, not reruns of the candidate.'},
 'typesFirstAttempt':{'receipt':ev('portal-retirement-fix/types-receipt.json'),'log':ev('portal-retirement-fix/types.log'),'exit':1,'failure':'CLI dist/index.js missing during generation before actual type diagnostics','notErased':True},
 'typesSerialRetry':{'receipt':ev('portal-retirement-fix/types-serial-retry-receipt.json'),'log':ev('portal-retirement-fix/types-serial-retry.log'),'start':types['start'],'end':types['end'],'exit':0,'files':923,'errors':0,'warnings':0,'hints':14,'hypothesisBoundary':'CLI shared-output contention is recorded as the cause hypothesis, not a new source bug or a reason to discard the first failure.'}
},'visualScope':'This review reads completed facts and metadata. It performs no new screenshot viewing and makes no all-image/AT/optical parity claim.','limits':['This is a test sequencing/precondition repair, not a Runtime or Overlay implementation fix.','No complete2b source control was executed locally in this subtask.','Old-projection departure is not universal proof of all resources released or new epoch complete; original optical checks remain required.','All full55 cases ran, but the file remains red at its pre-existing-location css-zoom diagnostic; no all-green claim.','Targeted run51 skips are explicit CLI filtering, not assertions that passed.','No exact-final-commit execution or canonical success is claimed; candidate source/tree binding is precommit.','No new tests/browser/build, source edits or external writes by this reviewer.']}
(O/'incremental-source-review.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
md=f'''# Portal 退役前置条件：最终候选增量核对

**0 个具体源码 finding；partial / ABSTAIN。** 只读核对范围为 physical HEAD `{H}` 加单文件候选，staged tree `{T}`。不是 GitHub APPROVE 或整个 PR 验收。

候选只有 `demo-liquid-glass-portal.browser.test.ts` 的 **17+/2-**，SHA256 `{sha(candidate)}`。删除新增捕获/try-finally/poll 块并放回原 Escape 与 aria wait 后，与原文件逐字相同；其余 {same} tree entries 的 mode/kind/blob 均等于84。生产源码、原 case 列表、既有输入、optical predicate 和20000ms期限均未改变；新增等待确实改变了该位置的动作间时序。

修复把 `HC-OVERLAY-PORTAL-0001-BINDING/MATERIAL`、`C-AS-OVERLAY-0001-F/K` 已有的 physical-view 边界落实为测试前置条件。历史 Content 的 disconnected 或换父表明它退出旧 body/carrier 投射，容许 WC 仍 connected 的 owner shell；它不能单独证明全资源释放或新epoch成立，后续原 optical/firstFocus/contentCount/source/preferences 检查继续承担新view结果验收。

| 证据 | 实际结果与边界 |
| --- | --- |
| 原84 isolated WC | 1 fail /54 filtered，原957 quality undefined，20s |
| 84+单Overlay2b blob控制 | 同点1 fail，原84字节已恢复；不是完整2b checkout |
| failure-only v2 | 失败后1个 connected Content仍BODY、source-scope-unavailable、firstFocus在body、quality属性缺失；不是精确早期epoch轨迹 |
| 候选四Runtime | 4 pass /51 filtered；00:49:18–00:49:34 UTC |
| 候选完整55 | 54 pass /1 fail，exit1；四恢复case与16 public Dropdown均pass，唯一681 css-zoom baselineStability仍红；00:51:45–00:53:44 UTC |
| 首次types | generation阶段CLI dist/index.js缺失，exit1；原失败保留 |
| browser结束后串行types | 00:54:56–00:55:35 UTC，exit0；923 files/0 errors/0 warnings/14 hints |

完整55没有CLI过滤或删除断言。全文件原log也保留服务器初始CLI缺dist错误，之后harness实际到达并完成55cases；不能把那段前置错误抹掉或算作额外Vitest case。准确2b官方原log与84原log均已出现681同title/assertion；只能证明同失败位置存在，不能据此认定同根因或宣称本次文件全绿。

现有 `T-WEB-PORTAL-DESTINATION-0001` 为draft；`web-portal-native-content` 是required、needs-review，实际 consumesCases 是 NATIVE/INLINE-SIZE。ADAPTER/MATERIAL case提供所用生命周期边界，但这次没有伪称改了YAML映射或提升准入状态。

Root另已纠正新私有authority-map中的旧 `latest887Integrated=a62` 为准确2b；历史premerge记录未改。本review记录校正后的hash，不公开其中的私有授权引用。

全部原log/receipt/事实/authority/source blob与SHA见 `incremental-source-review.json`。本核对没有新增测试、浏览器、截图审阅、产品修改或外部写入。等待准确commit绑定与冻结公开包QA。
'''
(O/'incremental-source-review.md').write_text(md)
for p in [O/'incremental-source-review.json',O/'incremental-source-review.md']:print(p,sha(p.read_bytes()))
