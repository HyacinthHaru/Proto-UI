from pathlib import Path
import hashlib,json,subprocess,re
from datetime import datetime,timezone
W=Path('<SOURCE_ROOT>')
R=Path('<TASK_STATE>');O=R/'portal-restoration-trace'
H='84ce84fdce5a15f58f12978d5cea1c24d554f0d8';B='2b8757f4516da60d3a3b31e9ec4df7401b3d3195'
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
def sha(b):return hashlib.sha256(b).hexdigest()
def ev(p):
 b=(R/p).read_bytes();return {'path':p,'sha256':sha(b),'bytes':len(b)}
def ref(p,a,b):return {'path':p,'lines':[a,b],'url':f'https://github.com/Proto-UI/Proto-UI/blob/{H}/{p}#L{a}-L{b}'}
paths=['apps/www/src/content/docs/zh-cn/demo-liquid-glass-portal.browser.test.ts','apps/www/src/pages/en/test/liquid-glass-portal.astro','apps/www/src/content/docs/zh-cn/public-portal-diagnostic.ts','apps/www/src/components/PrototypePreviewer/preview-material-scene.ts','apps/www/src/components/PrototypePreviewer/preview-material-provider.ts','apps/www/src/components/PrototypePreviewer/wc-registry.ts','packages/adapters/base/src/platform/portal-destination.ts','packages/adapters/base/src/material/sink.ts','packages/adapters/web-component/src/adapt.ts','packages/adapters/web-component/src/portal-conceal.ts','packages/adapters/web-component/src/portal-mount.ts','packages/adapters/web-component/src/runtime/modules.ts','packages/modules/feedback/src/create.ts','packages/modules/feedback/src/material/deferred-view-sink.ts','packages/modules/overlay/src/impl.ts','packages/prototypes/base/src/dropdown/content.proto.ts','packages/prototypes/base/src/transition/types.ts','packages/prototypes/liquid-glass/src/dropdown/content.proto.ts','spec/contracts/C-AS-OVERLAY-0001.yaml','spec/host-caps/HC-OVERLAY-PORTAL-0001.yaml','spec/modules/M-OVERLAY-0001.yaml']
files=[]
for p in paths:
 b=git('show',f'{H}:{p}');base=git('show',f'{B}:{p}')
 files.append({'path':p,'blob':git('rev-parse',f'{H}:{p}').decode().strip(),'sha256':sha(b),'base2bBlob':git('rev-parse',f'{B}:{p}').decode().strip(),'sameBytesAs2b':b==base,'bytes':len(b)})
changed=[x['path'] for x in files if not x['sameBytesAs2b']]
assert changed==['packages/modules/overlay/src/impl.ts'],changed
ci='canonical-84ce84fd/job-116742738980.log';isol='combined-validation/portal-wc-original-isolated'
raw=(R/ci).read_text();clean=re.sub(r'\x1b\[[0-9;]*m','',raw);lines=clean.splitlines()
extract=[]
for a,b in [(1038,1060),(1089,1100)]:
 extract.extend({'line':i,'text':lines[i-1]} for i in range(a,b+1))
receipt=json.loads((R/isol/'receipt.json').read_text());meta=json.loads((R/isol/'artifacts/portal/metadata.json').read_text())
assert receipt['exit']==1 and receipt['sourceSHA256'][paths[0]]==files[0]['sha256']
report={'createdAt':datetime.now(timezone.utc).isoformat(),'mode':'human-assisted/current-user','disposition':'partial/ABSTAIN; read-only source analysis, no new execution','target':{'head':H,'tree':git('rev-parse',f'{H}^{{tree}}').decode().strip(),'baseForStaticComparison':B,'testTitle':'wc: one-pixel source loss, intervening paint, withdrawal, registration revocation/restoration and preferences','sourceReadPolicy':'All final hashes computed from exact Git blobs. Root currently owns a temporary one-file Overlay control; mutable working bytes are not used as the reviewed source.'},'sources':files,'staticDiffScope':{'checkedFiles':len(files),'changedFrom2b':changed,'limits':'This is the explicitly inspected closure slice, not all loaded Vite inputs or proof that a source difference caused the failure.'},'actualEvidence':{'canonical':{'log':ev(ci),'jobId':116742738980,'runId':38828883938,'checkout':'actual 84ce checkout and git log -1 are recorded in raw log','files':{'passed':26,'failed':2},'tests':{'passed':779,'failed':4},'specificFailure':{'caller':ref(paths[0],953,957),'helper':ref(paths[0],70,73),'deadlineMs':20000,'expected':'self-optical','received':'undefined','rawLineExtract':extract}},'rootOriginalIsolated':{'receipt':ev(isol+'/receipt.json'),'log':ev(isol+'/run.log'),'metadata':ev(isol+'/artifacts/portal/metadata.json'),'start':receipt['start'],'end':receipt['end'],'command':receipt['command'],'exit':1,'sourceBasis':receipt['sourceBasis'],'tree':receipt['indexTree'],'node':receipt['node'],'browser':meta['browser'],'tests':{'failed':1,'filteredSkipped':54},'artifactsScope':'Two earlier screenshots exist (one-pixel-too-short, registration-pending-opaque). They precede restoration failure; observations array is empty. This subtask did not view or relabel them as failure screenshots.'}},'observedVersusInferred':[
 {'kind':'observed','fact':'Original case reached caller 957 after original open() returned: trigger.click completed and role=menu visible wait passed. optical failed its first quality poll, before its firstFocus and admission assertions.'},
 {'kind':'source-derived','fact':'geometry calls bounds(target) before reading target.dataset.materialQuality. A fulfilled geometry result whose quality is undefined implies the first [data-demo-ref=content] existed for that evaluation and lacked that attribute. It does not prove the queried Content is the visible menu or that only one Content exists.'},
 {'kind':'not-observed','fact':'Failure log does not contain physical parent, material suspension, projection generation, actual view detach, selected node identity or sink acquire/release trace.'},
 {'kind':'source-derived hypothesis','fact':'953 Escape plus 954 aria-expanded=false only observes logical close. WC reconcileIntent may still be waiting for its two-rAF conceal barrier; present=true can cancel conceal and reveal the retained view. If the retained view is the preceding body projection, destination registration restoration suspends that same epoch and cannot grant a new sink. The actual failing run has not yet established this interleaving.'}
],'authority':[
 {**ref('spec/contracts/C-AS-OVERLAY-0001.yaml',9,64),'status':'draft','criteria':['C-AS-OVERLAY-0001-F','C-AS-OVERLAY-0001-K'],'boundary':'Logical open, Presence/ViewIntent and mount facts are distinct; portal/layer final revocation follows view detach; retained instance ancestry and re-entry must remain valid.'},
 {**ref('spec/host-caps/HC-OVERLAY-PORTAL-0001.yaml',24,35),'status':'draft','criteria':['HC-OVERLAY-PORTAL-0001-BINDING','HC-OVERLAY-PORTAL-0001-MATERIAL'],'boundary':'A physical view fixes its destination; relevant policy change suspends material without moving the open view. Only the next physical view with actual projection commit resets suspension. Destination eligibility alone never proves optical admission.'},
 {**ref('spec/modules/M-OVERLAY-0001.yaml',12,23),'status':'draft','criteria':['M-OVERLAY-0001-A','M-OVERLAY-0001-C'],'boundary':'Logical open/view presence/mount are distinct; provider contributions release through their acquiring owner and active mounted view may reconcile current resources.'}
],'sourceChain':[
 {**ref(paths[0],921,957),'fact':'First reopen without registration is explicitly checked at body and source-scope-unavailable. The next restoration reopen waits only for aria-expanded=false before registration and open.'},
 {**ref(paths[1],170,197),'fact':'geometry reads actual first Content, source frame/admission, physical scope membership, data-material attributes and DOM count.'},
 {**ref(paths[1],228,236),'fact':'destination(true/false) uses actual public register/disposer. It does not move the live host or force a Runtime update.'},
 {**ref('packages/adapters/web-component/src/adapt.ts',1184,1234),'fact':'Logical present=false conceals immediately; physical detach is queued and awaits portal conceal. present=true during conceal with owner.hasView reveals the existing epoch and returns.'},
 {**ref('packages/adapters/web-component/src/portal-conceal.ts',1,48),'fact':'Portal conceal waits for two actual rendering opportunities while document is visible; cancellation resolves the barrier.'},
 {**ref('packages/adapters/web-component/src/portal-mount.ts',128,149),'fact':'A live projection keeps its physical parent; changed registration/destination suspends material.'},
 {**ref('packages/adapters/web-component/src/portal-mount.ts',252,288),'fact':'Restore releases material, logical projection marker and old portal contribution; superseded cleanup cannot overwrite a newer projection.'},
 {**ref('packages/adapters/web-component/src/portal-mount.ts',310,334),'fact':'New mount resolves the current registration, begins a suspended material epoch, physically appends, commits admission and sends actual projection notification.'},
 {**ref('packages/adapters/base/src/platform/portal-destination.ts',189,243),'fact':'Suspension is irreversible within one material epoch; public read APIs expose suspended state and projection/suspension generations.'},
 {**ref('apps/www/src/components/PrototypePreviewer/preview-material-provider.ts',61,105),'fact':'Suspended/disconnected or outside-provider host retains ordinary style, with no new material sink. No quality marker is promised by this branch.'},
 {**ref('apps/www/src/components/PrototypePreviewer/preview-material-provider.ts',118,164),'fact':'Actual projection or suspension signal refreshes the proxy; it rebinds only a current eligible provider and retires its acquired sink.'},
 {**ref('packages/adapters/base/src/material/sink.ts',327,373),'fact':'No material slot also invokes ordinary() and clears diagnostics. Thus undefined quality alone is not a unique marker of suspended portal ownership.'},
 {**ref('packages/adapters/base/src/material/sink.ts',1000,1027),'fact':'View sink release clears diagnostics as well as image/resource contributions.'},
 {**ref('packages/modules/overlay/src/impl.ts',265,278),'fact':'Actual unmounting/detached tears down resources; mounted active view reconciles. These source checks require observed phase/epoch facts before attribution to C.'}
],'minimumFailureOnlyObservation':[
 'Keep the exact original input, assertions and timeout. On original rejection only, record capture timestamp and original error; capture errors must not replace it.',
 'Collect fixture.geometry() and fixture.activity() separately with error capture. Include firstFocus, openChangeCount and closeCount; do not use publicPortalSnapshot.firstFocus as this fixture\'s focus observation.',
 'Enumerate all [data-demo-ref=content] and [role=menu], their cross-identity, parent/ancestor classification (body versus data-material-overlay-mount), connectedness, id/ref/role, data-pui-view-detached/pending/revealing and data-material* attributes. One querySelector result is insufficient.',
 'Reuse publicPortalSnapshot for existing actual canvas/scenes/ancestor computed styles, DOM and screenshot. Its window.publicPortalFirstFocus is a different global; standalone fixture uses liquidPortalFixture.activity().firstFocus.',
 'If needed after failure, read exported isWebPortalMaterialSuspended/getWebPortalProjectionGeneration/getWebPortalMaterialSuspensionGeneration from the same actual adapter-base module. These are read-only metadata; do not call begin/commit/notify/suspend or force updates. Post-failure generations alone cannot prove they advanced during reopening.',
 'Optional public getExposes() reads can report Root open and Content open/isPresent/transitionState, using the actual external-handle get method. Do not call complete/enter/update or infer mountEpoch from isPresent.'
],'decisionBoundaries':[
 {'observation':'Content remains body/outside scene and material is suspended; no observed new projection','conclusion':'First split is physical-view admission/restoration, not an optical pixel sampler. Retained-epoch cancellation is a candidate; failed resource restoration is not proved without a real detach/new-mount observation.'},
 {'observation':'A real detach/new epoch is independently observed, but active mounted Content is not projected through the registered current provider','conclusion':'Investigate C Overlay mount/release/owner guard and WC provider acquisition at that first divergence; could establish M-OVERLAY-C / HC-PORTAL-A,K boundary issue.'},
 {'observation':'Exactly one Content in scene, current unsuspended projection, valid source admission, quality still missing','conclusion':'Investigate current Rule material slot/Feedback frame/view and preview provider acquire/release before attributing to shader/sampling. ordinary/no-slot or stale sink retirement remain possible.'},
 {'observation':'Current sink reports unavailable/opaque-fallback with a specific source/style/geometry reason','conclusion':'Use that concrete guard as first divergence; no basis yet for a global C failure or an assumed B/material owner.'}
],'minimumPair':{'rootOwnedCurrentControl':'Exact 84 revision/test/fixture with only Overlay impl temporarily replaced by exact 2b blob, followed by byte restoration. This is not whole-revision 2b execution. Compare original assertion/caller and failure state; a single pair alone cannot establish causality.','afterObservationOnly':'If the suspected retained-view path is observed, a separate condition control may use the same public journey but await actual portal release/projection completion before restoration. Label it as a distinct lifecycle-conditioned control, never as a pass of the unchanged original or as permission to weaken it. Do not add sleep/recovery or trigger an extra close/open.','notExecutedHere':True},'newCDefectEstablished':False,'ownerDisposition':'Unknown pending first-divergence evidence; concrete C, WC view-boundary, preview provider and material Rule alternatives remain separated. No B ownership assignment.','activityBoundary':'No browser, tests, source edits, assertions/timeouts changes, GitHub writes or process interference in this read-only subtask.'}
(O/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
md='''# WC portal registration 恢复：首分歧只读链

准确源码 `84ce84fdce5a15f58f12978d5cea1c24d554f0d8` / tree `ac120a185a1b2d48e4a8961fad526b3399ef7944`。本报告只读，**partial / ABSTAIN**；尚未建立新增 C 缺陷，也没有把失败归给 B。

官方 `38828883938 / 116742738980` 是 779 pass / 4 fail，目标 WC case 在 `demo-liquid-glass-portal.browser.test.ts:957` 调 `optical()`，20 秒后 `quality` 最后值为 undefined。Root 的原 case 隔离执行于 00:39:06–00:40:00 UTC 在 clean 84 上同点失败（1 fail / 54 filtered），Node 24.21.0 / Chrome 155.0.8059.80。原有两张 capture 位于更早的 one-pixel / registration-pending 阶段，不能标成最终失败图。

已通过的动作只包括 `open()` 的真实 trigger click 和 menu visible；失败是 optical 的第一个 quality poll，后面的 firstFocus、scope、source admission 断言尚未执行。`geometry()` 先对选中的 Content 执行 bounds，再读 dataset，所以 undefined 不表示该次查询没有 Content；它表示所选 Content 没有 quality attribute。仍须核对它是否与 visible menu 相同、是否有多个实例。

最小有区分力的失败后快照是：原 `geometry()`、原 `activity()`、全部 content/menu 的交叉 identity 和 physical parent、连接/可见标记、data-material*、现有 `publicPortalSnapshot` 的实际 scene/canvas/祖先 CSS、DOM/PNG。注意 `publicPortalSnapshot.firstFocus` 读另一个 `window.publicPortalFirstFocus`，本独立 fixture 正确的观测入口是 `liquidPortalFixture.activity().firstFocus`。

源码给出一个待证边界：953 Escape 后只等 954 的 aria-expanded=false，立即恢复注册并重新 open。WC 的 false intent 先 conceal，再等待两次 rAF 进行物理 detach；若 present=true 取消尚待决的 conceal，`adapt.ts:1196` 会 reveal 同一 `owner.hasView`。旧 body view 此时遇到注册变化会被永久暂停材质，只有下一物理 view 的真实投射 commit 才 reset。`preview-material-provider.ts:65` 在 suspended/无 provider 时只保留普通 style，可能没有 quality；`sink.ts:370` 的 no-slot 路径或 sink release 同样可清掉该属性，所以不能只据 undefined 判定这一假设。

Authority 是 draft `C-AS-OVERLAY-0001-F/K`、`HC-OVERLAY-PORTAL-0001-BINDING/MATERIAL` 和 `M-OVERLAY-0001-C`：logical close 与 view detach 不等价；每个物理 epoch 固定 destination，下一真实投射才解除 suspension；实际 detach 后必须保留 logical ancestry/re-entry。没有规范依据把 aria-expanded=false 自行提升为新 epoch 已完成。

判别顺序：

1. 若 Content 仍在 body、suspended，先定位真实 detach/reopen 是否发生；这是 physical admission 分歧，尚非 GPU 采样错误。
2. 若真实 detach/new epoch 已观察，却没有通过当前 provider 重新投射，才把首分歧推进到 C Overlay owner/resource 与 WC acquisition。
3. 若 scene、unsuspended、新投射和 source admission 均正确但 quality 缺失，继续核对 Rule material slot / Feedback frame/view / preview provider sink 生命周期。
4. 若 sink 已给具体 unavailable/fallback reason，按该实际 guard 调查，不笼统归因材质。

21 个已检查文件对准确 2b 比较，仅 Overlay impl 有 diff；这是检查范围内的事实，不是全 bundle 输入清单或因果证明。Root 正在做的单 Overlay blob 配对保留原 test/fixture/所有其它 84 输入，不能称整版 2b 对照。若后续确实观测到 retained-epoch 路径，可另做一次等待真实 portal release 的生命周期条件控制，必须单独标记，不得把它算原测试通过或削弱原断言。

完整路径/行、Git blob/SHA256、原 CI 与 isolated receipt/log SHA、观察点和限制见同目录 `report.json`。本子任务没有执行测试/浏览器、修改产品或干预 Root 作业。
'''
(O/'report.md').write_text(md)
for p in [O/'report.json',O/'report.md']:print(p,sha(p.read_bytes()),p.stat().st_size)
