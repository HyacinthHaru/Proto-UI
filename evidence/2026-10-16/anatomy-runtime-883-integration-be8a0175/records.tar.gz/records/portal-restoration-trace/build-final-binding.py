import hashlib,json,subprocess,re
from pathlib import Path
from datetime import datetime,timezone
W=Path('<SOURCE_ROOT>');R=Path('<TASK_STATE>');O=R/'portal-retirement-fix'
H='421208cae540c481ab297aa6d09203c49654f5e5';B='84ce84fdce5a15f58f12978d5cea1c24d554f0d8';T='4feed4f52477a26085b152a9c662465c4766e682';P='apps/www/src/content/docs/zh-cn/demo-liquid-glass-portal.browser.test.ts'
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
def sha(b):return hashlib.sha256(b).hexdigest()
def ev(p):
 b=(R/p).read_bytes();return {'path':p,'sha256':sha(b),'bytes':len(b)}
def entries(rev):
 m={}
 for line in git('ls-tree','-rz',rev).decode().rstrip('\0').split('\0'):
  meta,p=line.split('\t',1);mode,kind,blob=meta.split();m[p]={'mode':mode,'kind':kind,'blob':blob}
 return m
new=entries(H);old=entries(B);assert git('rev-parse',f'{H}^{{tree}}').decode().strip()==T
changed=[p for p in sorted(set(new)|set(old)) if new.get(p)!=old.get(p)];assert changed==[P]
candidate=git('show',f'{H}:{P}');assert sha(candidate)=='06c311a7df13201e33ca9cbce495d3cf71b8c0c354ade63a0ec22e28baf4601c'
assert candidate==(O/'candidate.browser.test.ts').read_bytes()
packageSrc=[p for p in new if p.startswith('packages/') and '/src/' in p];assert all(new[p]==old[p] for p in packageSrc)
binding=json.loads((R/'form-context/observed-source-binding.json').read_text());requested=binding['requestedTracked'];assert len(requested)==744 and len({x['path'] for x in requested})==744
# Read actual final Git object bytes once through cat-file --batch, then hash each observed input.
blobs=list(dict.fromkeys(new[e['path']]['blob'] for e in requested))
proc=subprocess.run(['git','cat-file','--batch'],input=('\n'.join(blobs)+'\n').encode(),stdout=subprocess.PIPE,check=True,cwd=W)
data=proc.stdout;cursor=0;actual={}
for wanted in blobs:
 end=data.index(b'\n',cursor);header=data[cursor:end].decode().split();assert header[0]==wanted and header[1]=='blob';size=int(header[2]);cursor=end+1;content=data[cursor:cursor+size];cursor+=size;assert data[cursor:cursor+1]==b'\n';cursor+=1;actual[wanted]=(sha(content),len(content))
assert cursor==len(data)
rows=[]
for e in requested:
 p=e['path'];entry=new[p];digest,size=actual[entry['blob']]
 matches=entry['mode']==e['mode'] and entry['blob']==e['actualGitBlob']==e['expectedGitBlob'] and digest==e['sha256'] and size==e['bytes']
 assert matches,p
 rows.append({'path':p,'observedURL':e['url'],'actualExecutionHead':binding['actualHead'],'actualExecutionBlob':e['actualGitBlob'],'executedSourceSHA256':e['sha256'],'finalMode':entry['mode'],'finalKind':entry['kind'],'finalBlob':entry['blob'],'finalSourceSHA256':digest,'bytes':size,'exact':True,'executionOverride':e.get('executionOverride')})
fullSource=json.loads((R/'form-context/run-1/tracked-source-before.json').read_text());assert len(fullSource)==6775
fullChanged=[]
for e in fullSource:
 n=new.get(e['path'])
 if not n or n['mode']!=e['mode'] or n['blob']!=e['actualGitBlob']:
  fullChanged.append({'path':e['path'],'historical84Blob':e['actualGitBlob'],'historical84SHA256':e['sha256'],'finalEntry':n,'finalSHA256':sha(git('show',f'{H}:{e["path"]}')) if n else None})
assert len(fullChanged)==1 and fullChanged[0]['path']==P
formRun=json.loads((R/'form-context/run-1/receipt.json').read_text());formReport=json.loads((R/'form-context/report.json').read_text());native=[]
for label in ['field','collapsible']:
 receiptPath=f'combined-validation/{label}/receipt.json';rr=json.loads((R/receiptPath).read_text());p,digest=next(iter(rr['sourceSHA256'].items()));final=git('show',f'{H}:{p}');assert sha(final)==digest
 native.append({'name':label,'receipt':ev(receiptPath),'actualExecutionStart':rr['start'],'actualExecutionEnd':rr['end'],'actualExecutionSourceBasis':rr['sourceBasis'],'actualExecutionTree':rr['indexTree'],'exit':rr['exit'],'countPassed':25 if label=='field' else 36,'testPath':p,'testSHA256':digest,'finalBlob':new[p]['blob'],'finalSHA256':sha(final),'exact':True,'notRerun':True})
vr=subprocess.run(['git','verify-commit',H],cwd=W,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);assert vr.returncode==0
commitRaw=git('cat-file','-p',H).decode();body=commitRaw.split('\n\n',1)[1]
meta=git('show','-s','--format=%H%x00%T%x00%P%x00%an%x00%ae%x00%cn%x00%ce%x00%aI%x00%cI%x00%s',H).decode().strip().split('\0')
assert meta[2]==B and meta[3]==meta[5]=='HyacinthHaru' and meta[4]==meta[6]=='hyacinth@haru.ac'
assert 'Signed-off-by: HyacinthHaru <hyacinth@haru.ac>' in body and not re.search(r'^Co-authored-by:',body,re.I|re.M)
review=json.loads((O/'incremental-source-review.json').read_text());assert review['findings']==[] and review['candidate']['stagedTree']==T
x={'createdAt':datetime.now(timezone.utc).isoformat(),'mode':'human-assisted/current-user','assessment':'partial/ABSTAIN; local read-only final byte binding and bounded candidate review, no submitted review or approval','target':{'head':H,'tree':T,'parent':B,'subject':meta[9],'author':{'name':meta[3],'email':meta[4],'at':meta[7]},'committer':{'name':meta[5],'email':meta[6],'at':meta[8]},'signatureVerified':vr.returncode==0,'signatureType':'SSH ED25519','dcoMatchesAuthor':True,'noCoauthor':True,'pushState':'Not re-read by this subtask; no remote mutation or publication assertion made.'},'delta':{'files':changed,'addedLines':17,'removedLines':2,'testBlob':new[P]['blob'],'testSHA256':sha(candidate),'equalsSavedExecutedCandidate':True,'sameTreeAsReviewedPrecommitCandidate':True,'totalTreeEntries':len(new),'allOtherModeKindBlobEntriesEqual84':len(new)-1,'productionPackagesSrc':{'count':len(packageSrc),'changedPaths':[],'allModeKindBlobExact':True,'listDigestSHA256':sha(('\n'.join(f'{p}\t{new[p]["mode"]}\t{new[p]["kind"]}\t{new[p]["blob"]}' for p in sorted(packageSrc))+'\n').encode())},'scopeLimit':'Exactly one browser test changed. This proves no packages/**/src or other tracked fixture/implementation/test input change; it does not rerun any behavior.'},'formEvidenceRebinding':{'originalBinding':ev('form-context/observed-source-binding.json'),'originalRunReceipt':ev('form-context/run-1/receipt.json'),'originalReport':ev('form-context/report.json'),'actualExecutionHead':binding['actualHead'],'actualExecutionTree':binding['actualTree'],'actualExecutionStart':formRun['startedAt'],'actualExecutionEnd':formRun['completedAt'],'originalPassed':2,'notRerun':True,'observedRequests':binding['requestedPaths'],'trackedObservedPaths':744,'all744FinalGitModeBlobAndSHAExact':True,'rows':rows,'unboundRequests':binding['unboundRequests'],'unboundCount':len(binding['unboundRequests']),'nonGitAndTransformLimit':binding['limit'],'callbackObservation':{'count':sum(e.get('executionOverride') is not None for e in requested),'description':'App-authored onSubmit observer changes one served JS response, not the Git TS input. Original and observed served-module hashes remain in the original report; the exact response override is not represented by the final Git blob.','actualServedCallbackModules':formReport['executableBytes']['actualServedCallbackModules']},'historicalFull6775':{'receipt':ev('form-context/run-1/tracked-source-before.json'),'count':6775,'actualHead':B,'sameFinalModeBlob':6774,'changed':fullChanged,'all6775EqualFinal':False,'limits':'The original full source census and before/after validation remain historical84 facts. The portal test changed at421, though it was not one of the744 actually requested tracked inputs. No relabeling as a new421 execution.'}},'fieldCollapsibleEvidence':native,'reviewEvidence':{'oracle':ev('portal-restoration-trace/oracle-review.json'),'incrementalReview':ev('portal-retirement-fix/incremental-source-review.json'),'targeted4Pass51Filtered':ev('portal-retirement-fix/receipt.json'),'completeFile54Pass1Fail':ev('portal-retirement-fix/full-file-receipt.json'),'typesFirstFailure':ev('portal-retirement-fix/types-receipt.json'),'typesSerialSuccess':ev('portal-retirement-fix/types-serial-retry-receipt.json')},'sourceFindings':[],'remainingValidationBoundaries':['Full55 remains54pass/1fail at681 css-zoom baselineStability; same location existed in prior2b/84, not proof of same cause.','Portal4/51 and full55, as well as serial923-file types, ran on84 plus this exact candidate before421 existed. They now bind byte-for-byte to421; no postcommit rerun claim.','Form ran at84 with explicit private app callback observation. Its744 requested tracked source files are unchanged at421; private served JS and87unbound requests are not silently converted to Git source evidence.','Field25/Collapsible36 ran atphysical26+stagedac120. Their tests and all tracked implementation inputs remain unchanged; do not relabel those executions as84 or421 postcommit runs.','No all-image, visual parity, AT, Apple/native, all Finf, full CI or formal acceptance claim.','No test/browser/build/product change or GitHub mutation by this reviewer.']}
(O/'final-binding-421208ca.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
md=f'''# Portal 修复提交 421208ca：最终字节绑定

**0 个具体源码 finding，partial / ABSTAIN；未提交 GitHub review。** 签名提交 `{H}` / tree `{T}`，parent84ce。SSH签名验证、HyacinthHaru author/committer、DCO及无co-author通过。本子任务没有重新读取远端push结果。

唯一diff是portal浏览器测试17+/2-，最终blob `{new[P]['blob']}`、SHA256 `{sha(candidate)}` 与已执行候选逐字相同。其余 {len(new)-1} 个tree条目的mode/kind/blob均与84一致，其中全部 {len(packageSrc)} 个`packages/**/src/**`文件零变化。

Form实际请求的 **744个tracked路径逐一**比较最终mode/blob及实际Git对象SHA256，744/744相等。原执行仍是84、{formRun['startedAt']}至{formRun['completedAt']}，两React family通过；没有重跑。原6775全源清单中 **6774相等、1个portal test改变**，因此不能称6775全等421。87个未绑定请求、Vite转换/生成依赖和显式app-authored onSubmit旁观的served-JS override保持原限制。

Field25与Collapsible36的原测试hash也逐一等于421。它们实际运行于physical26+staged ac120，而不是84/421提交后；全部tracked实现/fixture/其他测试不变允许源码复用，不产生新的执行事实。

已完成验证按真实来源保留：

- 候选四Runtime恢复case：4pass/51filtered。
- 候选完整55：54pass/1fail；四恢复case与16public Dropdown通过，681 css-zoom诊断仍红。
- types首次generation阶段CLI缺dist失败保留；browser终态后串行重试923files/0errors/0warnings/14hints，exit0。
- 上述portal/types执行均为84+同字节precommit候选，现绑定到421，不标成postcommit运行。

本review只确认这一个测试前置条件与既有HC/C/T映射相符及来源一致。没有runtime实现修复、完整2b对照、所有资源释放、全CI或全视觉/AT准入结论。详细744行映射、原证据SHA和提交字段见`final-binding-421208ca.json`。
'''
(O/'final-binding-421208ca.md').write_text(md)
for p in [O/'final-binding-421208ca.json',O/'final-binding-421208ca.md']:print(p,sha(p.read_bytes()),p.stat().st_size)
print('source counts',len(new),len(packageSrc),'form',len(rows),'historicalFullChanged',len(fullChanged))
