# Form完整正常行为诊断：实际84ce / ac120

一次有界运行：2026-10-16 **00:20:40–00:20:57 UTC**，2case/2pass/exit0。实际已是签名merge后的`84ce84fdce5a15f58f12978d5cea1c24d554f0d8`，tree`ac120a185a1b2d48e4a8961fad526b3399ef7944`；准备阶段的HEAD26+stagedtree不是本次执行HEAD。Node24.21.0、pnpm10.32.1、Chrome155.0.8059.80当场记录；前后6775个tracked候选输入blob完全相同，worktreeclean，port62178结束后无listener。

Shadcn/Brutalist两个真实React页面都走完：空值提交错误/首focus/ARIA→修正五字段提交→quantity/code/channels真实编辑并第二次提交→全部控件reset、validation清除→reset后再非法提交→第三次有效提交。每个case恰3个onSubmit回调，ID为2、3、5，payload按当时已验证的五字段快照匹配；非法提交和reset没有额外submit。第二次值为name/Formbehavior two、quantity3、code1234、level25、channels[email,sms]；最终恢复默认复合值并提交Afterreset。

本次是**独立行为case + app-authored callback观察副本**。原finf视觉测试文件及其formJourney函数没有改断言；这里未执行它并不宣称原visual/officialsuite通过。为了数回调，只有既有demo的report语句前增加旁观detail记录，仍执行原status写入。实际served模块原SHA`35b77e06…b45a`、派生SHA`97410c3b…c45`，两case一致；失配source-map行被移除，actualJS原/派生完整保留。没有fakeGITHUB_ACTIONS/CANDIDATE_SHA、产品flags、validation注入或恢复动作。

页面/console/接线/捕获错误均0；没有再现旧base-field provider错误。不得据此宣布旧错误原因已修。浏览器观察记录18trustedclick以及pointer/input/change，另2个RuntimeTab untrustedclick也保留；不将Playwright当OS原生输入，也未测键盘/IME。

14张原PNG已逐张view_image，DOM/AX终态文件均已读取核对。**两family的Label仍不等于Error颜色、Label也未随invalid变色**；原颜色问题保留，行为通过不能替代视觉gate。reset后status仍显示上一次提交是原demo只在onSubmit更新status的行为；控件值实际已复位，没有把旧status当新提交。末图是viewport，不是完整页面；不主张dark/narrow/光学/AT验收。

这轮没有配置async validator，也没有观察者在callback中触发cancel/retirement/nestedrequest。因此不覆盖异步lease、unmount/dispose/remount、受控reset握手、duplicate names或异常策略；这些仍由既有C authority/Runtime/WC回归与必要后续实证治理。浏览器时钟沿用原固定HostClock，不把observer timeOrigin换算成实际UTC性能证据。

完整SHA、callbackdetail、输入及边界见[report.json](report.json)、[视觉核验](visual-review.json)、[请求源码绑定](observed-source-binding.json)。原始run目录只读保留，没有重跑；未发现需要立即修的新增C实现问题。human-assisted / partial / ABSTAIN。
