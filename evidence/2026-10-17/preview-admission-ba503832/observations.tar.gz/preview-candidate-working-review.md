# Preview 候选独立 working review

固定 main404 加七个当前未提交路径，完整源码快照/hash见JSON。human-assisted/current-user，review-bounded-regression，**partial / ABSTAIN**；不是正式GitHubreview或exact-headCI。

当前 **0个剩余具体源码finding**。发现的 `PREVIEW-REGRESSION-COMPRESSED-001` 已在working源码以共享 `PREVIEW_LIMITS.maxCompressedBytes` 断言修复：原extract/materialize/sanitize链不检查下载层50MiB compressed limit。此前1PASS日志发生在新增断言前，保留此来源界限，尚需最终test字节的结果对账。

两个CSS endpoint调用原generator，参数/selector不变；组件同位置style变link。theme6596B/SHA2e935ff1、code3709B/SHAfd98af5f分别与原baseline inline逐字相同，没有url()/@import相对路径。Astro原生never选项保留样式排序metadata。额外CSSfetch属于实际加载差异，不能称HTML或首帧时序完全不变；实际paint验证另列。

完整ZIP回归位于 canonicalbuild后、upload前；source/admitted/materialized/sanitized全部filename和bytes逐项比较，原bounds/hostilearchive检查不变。当前完整包3836files/21,212,941compressed/104,047,224expanded，剩余810,376B。原main完整build的相同回归真实1FAIL，旧be8官方ZIP实际default listBoundedEntries也拒绝，均保留。

669HTML route集合保留。当前parent初步归一化还有501HTML/335JS comparison差异，不能仅因route数相同就写全部内容/资产等同；多index.* chunk尤其不能只按basename配对。完整资源/DOM对账及当前原生页面检查由parent进行，本审查没有代跑或预判。

最终新test结果、finalsource/build输入绑定、exact-head Actions artifact及真实catalog/page/assets仍是验证欠账。没有平台批准、部署、secrets操作或整个#612关闭声明。
