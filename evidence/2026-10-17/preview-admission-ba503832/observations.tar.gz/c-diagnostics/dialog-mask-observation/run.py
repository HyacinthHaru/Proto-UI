from pathlib import Path
from datetime import datetime,timezone
import subprocess,os,json,hashlib,difflib,re
W=Path('<SOURCE_ROOT>');R=Path(__file__).parent;F=W/'apps/www/src/content/docs/zh-cn/dialog-available-space.browser.test.ts'
sha=lambda b:hashlib.sha256(b).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=W)
original=F.read_bytes();assert original==git('show','404a7417ef8dc22c8c7fe6d9ff9f3c8a5d40a17b:apps/www/src/content/docs/zh-cn/dialog-available-space.browser.test.ts')
old='          expect(data.mask?.x).toBe(0);'
new='''          try {
            expect(data.mask?.x).toBe(0);
          } catch (error) {
            try {
              const observation = await dialog.evaluate((e) => {
                const matches = (n: Element) => n !== e && n.hasAttribute('data-is-present') && n.hasAttribute('data-pui-root') && n.getAttribute('role') !== 'dialog';
                const identity = (n: Element) => ({ tag: n.tagName, attributes: Object.fromEntries(Array.from(n.attributes).map((a) => [a.name, a.value])), display: getComputedStyle(n).display, position: getComputedStyle(n).position });
                const detail = (n: Element) => {
                  const style = getComputedStyle(n);
                  const ancestors = [];
                  for (let p = n.parentElement; p && ancestors.length < 5; p = p.parentElement) ancestors.push(identity(p));
                  return { ...identity(n), connected: n.isConnected, rect: n.getBoundingClientRect().toJSON(), opacity: style.opacity, visibility: style.visibility, pointerEvents: style.pointerEvents, ancestors };
                };
                return { atPage: performance.now(), dialog: detail(e), bodyDirectMatches: Array.from(document.body.children).filter(matches).map(detail), bodyDescendantMatches: Array.from(document.body.querySelectorAll('*')).filter(matches).map(detail), viewport: { width: innerWidth, height: innerHeight }, body: identity(document.body) };
              });
              const dir = process.env.PROTO_UI_MASK_OBSERVATION_DIR!;
              await mkdir(dir, { recursive: true });
              await writeFile(path.join(dir, 'facts.json'), JSON.stringify({ atNode: new Date().toISOString(), family, runtime, width, originalMask: data.mask ?? null, observation }, null, 2));
              await page.screenshot({ path: path.join(dir, 'failure.png') });
              await writeFile(path.join(dir, 'page.html'), await page.content());
            } catch (observationError) {
              console.error('[mask observation error]', observationError);
            }
            throw error;
          }'''
text=original.decode();assert text.count(old)==1;derived=text.replace(old,new).encode();(R/'original.test.ts').write_bytes(original);(R/'diagnostic.test.ts').write_bytes(derived);(R/'diagnostic.patch').write_text(''.join(difflib.unified_diff(text.splitlines(True),derived.decode().splitlines(True),fromfile='a/'+str(F.relative_to(W)),tofile='b/'+str(F.relative_to(W)))))
env=os.environ.copy();env['PATH']='<LOCAL_NODE24_BIN>:'+env.get('PATH','')
for k in list(env):
 if k.startswith(('PROTO_UI_','MATERIAL_')) or k in ['GITHUB_ACTIONS','CANDIDATE_SHA','DEBUG']:env.pop(k)
env['PROTO_UI_MASK_OBSERVATION_DIR']=str(R/'artifacts')
cmd=['node','scripts/test/run-runtime-tests.mjs','--no-file-parallelism',str(F.relative_to(W)),'--reporter=verbose','--maxWorkers=1','--minWorkers=1','-t','^brutalist/react:']
rec={'startedAt':now(),'status':'preparing','head':git('rev-parse','HEAD').decode().strip(),'statusBefore':git('status','--porcelain','--untracked-files=all').decode(),'command':cmd,'originalTestSHA256':sha(original),'diagnosticTestSHA256':sha(derived),'sourceBoundary':'404 plus root preview candidate and one temporary failure-catch-only test derivative. No product/state/input/timeout changes. Original expectedmask.x=0 executes and is rethrown.','node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'pnpm':subprocess.check_output(['corepack','pnpm@10.32.1','--version'],env=env,text=True).strip(),'PATH':env['PATH']}
write(R/'receipt.json',rec)
try:
 F.write_bytes(derived)
 with (R/'run.log').open('wb') as log:
  p=subprocess.Popen(cmd,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);rec.update({'status':'running','pid':p.pid,'processGroup':p.pid});write(R/'receipt.json',rec);print(json.dumps({'started':rec['startedAt'],'pid':p.pid}),flush=True);code=p.wait(timeout=1200)
 rec.update({'status':'completed','exitCode':code,'endedAt':now()})
finally:
 actual=F.read_bytes();rec['beforeRestoreTestSHA256']=sha(actual)
 if actual==derived:F.write_bytes(original);rec['exactOriginalRestored']=F.read_bytes()==original
 else:rec['exactOriginalRestored']=False;rec['restorationRefused']='Test changed unexpectedly; did not overwrite concurrent edits.'
 rec['headAfter']=git('rev-parse','HEAD').decode().strip();rec['statusAfter']=git('status','--porcelain','--untracked-files=all').decode();raw=(R/'run.log').read_bytes();rec['logSHA256']=sha(raw);clean=re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',raw.decode(errors='replace'));rec['summary']=[s.strip() for s in clean.splitlines() if re.search(r'^\s*(Test Files|Tests)\s',s)];write(R/'receipt.json',rec)
print(json.dumps({k:rec.get(k) for k in ['status','exitCode','summary','exactOriginalRestored']}),flush=True)
