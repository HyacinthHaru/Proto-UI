# Preview producer/admission 独立只读 authority review

- main：`404a7417ef8dc22c8c7fe6d9ff9f3c8a5d40a17b`，tree `18354e6bb987f59d445fbf7f732e4ad857a29ec9`；Root live 时间 `2026-10-17T00:58:01.610871+00:00`。
- human-assisted/current-user；unassessed advisory；**partial / ABSTAIN**。非正式 GitHub review。
- 本报告固定读取 main Git 对象；不将旧 be8 工作树或父代理当前未提交修改当作已审 candidate。

## 结论

最小方向在 **apps-www producer 的重复 CSS 输出**，不在 apps/workspace、publisher envelope 或页面删减。实际 workflow 执行 `pnpm --filter apps-www build` 并打包完整 `apps/www/dist/`。apps/workspace 的 React/Vite spec-workspace JSON 不进入这条链。

现行 100 MiB expanded、50 MiB compressed、25 MiB per-file、20k files 及路径/文件类型/身份安全检查应保持。Finf package 的 advisory policy 不适用于此安全 envelope。

[明确 QA 请求](https://github.com/Proto-UI/Proto-UI/pull/888#issuecomment-6219356099) 的旧 be8 ZIP 我仅复核中央目录和 SHA：3791 files、117,995,176 expanded bytes，其中667 HTML合计102,644,277 bytes；比默认限制多13,137,576 bytes。没有解压、serve 或复现 live publisher failure。

## 源头与最小方案

1. `apps/www/astro.config.mjs` 使用 Astro 默认小样式内联。installed Astro5.18.1 原生支持 `build.inlineStylesheets: 'never'`，优先让原构建器提取处理过的 CSS。
2. `SiteLibraryStyle.astro:7-22` 对每个页面输出相同两组 Brutalist CSS；`SiteCopyBootstrap.astro:4-8` 对正文及各 CodePanel/InstallCommandCard 重复输出相同 `codeStartupPaintCss()`。可复用 same-origin 构建期 CSS asset，保留原内容、cascade、family scopes和无JS外观。
3. 既有本地 dist 的未重新绑定诊断读数为669 HTML、20,386,169 inline-style bytes，唯一style内容约332,302 bytes；这只用于选择方向。它不等于旧官方ZIP、不是main新构建、不证明候选已降至100MiB。
4. `PrototypePreviewer.astro:107-116,145-148` 另有各runtime raw code/highlight数据重复；它牵涉代码切换、copy及无JS初始代码，先不扩大到这层。只去掉4.6MB bundle graph不足关闭13.1MB超额，也不是允许删除资产的依据。

## 完整性回归边界

- 同固定head/toolchain完整build → 完整directory/ZIP → 真实默认extract/sanitize入口，不使用放宽limits或精选页面fixture。现有preview suites只有合成小ZIP/安全边界；需补实际producer兼容回归。
- 对账全部HTML路径、index/404、两语言、redirect与trailing slash；保留非目标assets。对内容哈希改名建立原/新asset引用对照，不能只比文件数。
- 校验CSS/JS/fonts/images、CSS url()/@import、lazy chunks、Pagefind、sitemap/LLM等完整本地依赖闭包；不给新共享asset引入跨origin依赖。
- 保留style原级联位置与media/layer等语义。不要把任意style统一搬到head，或用通用正则外置却忽略CSS相对URL基准变化。
- 在实际完整输出上保留无JS初始paint、Shadcn/Brutalist、EN/ZH、light/dark、代码展开/copy/runtime切换和navigation/search；截图只是相应检查，不等于全站/AT验收。
- 原安全负例、stale/closed/superseded/failure、generation不可变全部继续有效。
- exact-head Actions artifact绑定、实际catalog/page/assets仍需各自证据；build成功不是Ready，local admission不是live部署。本审查不访问secret或操作服务。

## 权威与已有工作

[Issue612](https://github.com/Proto-UI/Proto-UI/issues/612)仍开放、无assignee。其原Cloudflare/dcbot机制已被当前 `scripts/preview/README.md` 和 `internal/governance/ci-cd.md` 的独立intranet服务取代；原containment/immutableidentity/failure/race要求仍应保留，不能把本次CSS修复写成整个612关闭。未发现适用的cataloged preview-publisher实体；sandboxed Preview Surface研究是另一App嵌入提案，不能作为本服务新增授权。

当前公开搜索未发现正在进行的同目标preview producer PR；preview词匹配的898/899/900分别是其它Agent/Release/Runtime修复，#532/#817是不同预览主题。私下owner工作未知，不能据此断言无人进行。

既知问题 `PREVIEW-PRODUCER-ADMISSION-001` 保留为历史artifact/当前admission不兼容，尚未验收修复。没有新增全局Runtime/C语义问题，也没有批准任何候选或发布。完整source Git blob/SHA、原始查询和限制见JSON。
