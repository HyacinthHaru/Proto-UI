# Preview / Dialog 最终提交绑定

**0个剩余具体源码finding；partial / ABSTAIN。** 未进行正式GitHub审查或外部写入。

- Preview `ea8e8901b5ca7fc2390292d65e323f2464d680f9`，parent404，8paths。七个已审源文件逐字匹配；第八README新增两句准确描述完整ZIP回归，不冒充trustedpublisher身份/livehead检查。
- Dialog `ba50383230a3ca63da2bc0ae099276cb5226330b`，parentea8，tree `f4f807930483bbdee0ef7545df9e5fd1154e3bc1`，只有一个测试selector表达式变化。
- 两提交均实际SSH ED25519验证通过；Author/Committer为HyacinthHaru `<hyacinth@haru.ac>`，精确DCO且无coauthor。公开ModelTrace只是历史归因，不作为身份认证或本review身份。
- 总计9路径之外全部mode/kind/blob保留；packages/**、spec/**及原C产品实现均未变。

## Dialog修正依据

原选定BrutalistReact用例在mask.x断言收到undefined。失败后真实DOM观测directmatches0、descendantmatches1；唯一可见Mask是`brutalist-dialog-mask`，实际rect0,0,390,900，父节点是Adapter的display:contents portalcontainer。draft HC-OVERLAY-PORTAL-0001-CONTAINER明确不保证body直接子结构。

新表达式只将查询范围从body.children扩到body descendants；除该表达式外整个测试文件字节相同。Mask坐标/宽高、Content几何、长文本/标题/溢出、焦点与关闭恢复、8用例和150秒超时均保留。相同选择实际1PASS/7filtered；这是预提交404+候选运行，经Git字节绑定到新提交，不重标为postcommit运行，也不是8case全过。原首次红的综合sourcehash变化限界与之后固定failure-only观测均保留。

## Preview原生记录的准确范围

8个noJS记录构成4个baseline/candidate pair，computedfacts及各图片bytes均相同；这些记录来自随后readinessprobe失败的run，不能把整次run写成成功。最终16readyrows+localcatalog1独立保留。root报告已逐张查看11图，本review只复核数据/图片字节，没有新增pixels审阅或AT验收。

Shadcn四个实际clipboard controls完成后，初次BrutalistButton页没有代码导致probe失败，该失败保留。后来新BrutalistText真实代码页四个CopyControlruntime均完成nativeclick/clipboard、failures[]；复制的是同一447byte authoredReactexample，不声称四种不同框架代码生成或runtime菜单点击。

最终hostedActions artifact、真实publisher/catalog/page仍需独立接纳证据；localcatalog是明确fixture。Portal别处诊断/修复不包含在本报告，未修改任何产品、原日志或GitHub状态。
