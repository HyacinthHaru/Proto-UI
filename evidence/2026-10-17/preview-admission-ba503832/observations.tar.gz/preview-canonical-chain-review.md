# PR901 canonical preview / actual local publisher 追加核对

准确head `ba50383230a3ca63da2bc0ae099276cb5226330b`、tree `f4f807930483bbdee0ef7545df9e5fd1154e3bc1`。**0个具体新增源码/收据finding；partial / ABSTAIN。** 不构成正式GitHubreview。

## 已独立对账

- 保存的完整分页readback中唯一PR901，authorHyacinthHaru、base404、headba503；实际完整body5799bytes/SHAe6d2e3c5与reconciledreceipt相同。第一次sourceorigin前置拒绝未写入；下一次实际create被ACK后瞬时readbackunknown，随后只回读而未重复创建。
- 官方run38990834138 / job117272659039真实SUCCESS。日志gitcheckout与log-1均为ba503，Ubuntu24.04.5 / Node24.21.0 / pnpm10.32.1。新增完整producergate实际1PASS，3835files /104,045,005expanded /21,207,517testZIPbytes。此处仅previewworkflow，不是全部CI通过。
- GitHubartifact12085151166实际ZIP21,143,347bytes，SHA `a77dc8d0f3ba20806460e84d5c642753b0f8036184e285059a3e68ea1d3c66a4`，逐字计算匹配metadata；669HTML路径仍与已审localcandidate相同。testZIP与GitHubZIP压缩字节不同，未混作同一archive。保留ZIP为publisher执行后的第二次读取，不是Actions重跑或第一次下载SHA测量。
- 实际localpublisher完整扫描4openPR：901 Ready元组绑定ba503/run38990834138/artifact12085151166/attempt1；其余三条仍因原100MiB限制被withheld。没有改限额。3835实际publishedfiles与留存ZIP中央目录的名称/尺寸/CRC32全吻合；这不是逐成员SHA或首次下载rawZIP的替代证明。
- 原server实际读取此publisher生成目录、48191本地generationorigin。真实catalog和Shadcn四runtime、BrutalistText四CopyControlruntime的nativeclick/Clipboard均完成，failures[]。Runtime由preference选择，不声称runtime菜单切换；Brutalist复制同一个447byte源码例子，不声称四种不同框架代码生成。
- current.json未刷新，checkedAt01:30:53.196Z；01:36:22.484229读到真实503 `Preview catalog lease expired`，独立计算329.288229秒。默认lease及旧失败保留。

## 必须保留的限界

这次是**真实GitHub数据驱动的本地actualpublisher/实际localserver**，强于此前手工localcatalogfixture；仍不是远端现有内网服务更新。远端URL/可达性/实际generation还需用户或owner提供真实入口与读取条件，未部署、改service、config或secret。

fcntl锁由root本轮内联Python工具参数实际执行：同.publish.lock持LOCK_EX|LOCK_NB跨整个child，finallyunlock；原receipt/log存在。wrapper没有预先保存.py，因此本报告按root实际工具执行收据加CLI/output对账记录，不伪称原执行文件可审、分布式锁或额外锁测试。

root实际看过catalog+8native共9图；本child仅核图片bytes/metadata，未新增逐像素或AT审阅。既有SSH/DCO/身份sourcebinding沿用已完成报告。新Selectalignment候选及后续head不纳入ba503 artifact结果。整个#612关闭、全CI绿与平台批准均未声明。
