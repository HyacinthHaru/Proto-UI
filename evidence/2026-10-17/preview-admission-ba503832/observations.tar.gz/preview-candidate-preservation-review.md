# Preview 候选完整性独立追加审查

固定404 main + 原七文件working snapshot；sourcehash均未漂移。**partial / ABSTAIN，0个剩余具体源码finding**。这份追加报告保留此前authority/working报告历史，不重标旧结果。

- 压缩bound finding `PREVIEW-REGRESSION-COMPRESSED-001` 已关闭：共享原50MiB限制断言存在，最终完整ZIP原命令实际1PASS。仍是local producer/admission，不是平台Ready。
- 全669HTML路径保留，7残差核清：2Wiki只有源码Math.random衍生card IDs，5Liquid页只有移走CSS后相邻script空白。全部code raw/map/highlights属性逐字相同，未用空白归一化放宽源码payload。
- 2407脚本chunk以facade+moduleIds唯一配对；5406模块记录与moduleRenderInfo完全相同。所有静态/动态依赖Counter相同；prototype-modules的1036条dynamicImports仅metadata顺序改变。2399脚本在准确文件映射后相同，其余8涉及打包import次序/minified alias与preload数组，不声明任意编译JS字节或全部执行顺序等价。
- 全HTML/CSS资源引用没有新增缺失；两边同一个intentionally-missing.png图片夹具，17个原导航缺失逐项相同；全部graph依赖包内存在。旧12CSS、PNG/SVG/font/LLM/sitemap、30Pagefindindex/2wasm原bytes保留。
- Pagefind635URL/正文/metadata全部保留。494fragment变化仅735个来自4个源码generator的随机锚点IDs，位置/文本/语义后缀均相同。不是494页面内容丢失。

**必须准确披露CSS差异：** PostCSS AST对账证明所有669页规则内容/条件的多重集合一致，但636页有规则重排；Astro auto→never改变小样式分组，Starlight Badge/Icon/Steps与siteCSS的相对次序可变化。两个手动theme/codepaint asset内容和替换位置保留。当前没有证据将这项排序变化判为paint回归，也不能写全局CSS序完全不变；实际原生/noJS/首帧样本仍由parent提供。

最终localZIP为3836files、21,212,941compressed、104,047,224expanded，剩810,376B；SHA a4f3947ae7648972272cd7de296ec97ea1bfaed04e228327909577903ae5c329。tightmargin不是未来容量保证。未改变100MiB或任何publisher安全guard。

本审查只读取生成文件、解析数据并写私有报告，没有运行产品测试/build/browser，没有解压原外部artifact、部署、读取secrets或GitHub写入。私有工具的初始解析/性能尝试限界见JSON，不能将工具前提错误当产品失败。最后commit绑定、hostedActionsZIP及真实catalog/page是独立剩余证据。
