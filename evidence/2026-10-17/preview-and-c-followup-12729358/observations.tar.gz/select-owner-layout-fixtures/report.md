准确96d2b8fe28cb7f1f1c35d40fe1514e51d3145cea/treef16943767552c7ded3320353bcfbc30030e113dd上的两份显式fake-layout夹具已最小补齐。各新增15行offsetLeft/offsetWidth，与原BCR同值：Trigger180/180、Value193/50、Surface0/180、ItemText13/50，其它既有fallback0/180。生产Host仍5ba56d96，未改API/spec或其它文件。

`function full`之后所有场景、期待和cleanup字节完全相同；180px期待、timers、timeout没有改变。root原27文件363pass/2fail/2TODO完整日志与收据已复制保留，两失败原始193→180不重标。

当前Host focused2files **43/43 pass**（04:19:25.362–04:19:28.218UTC），Node24.21.0/pnpm10.32.1。相同候选测试字节，private Vite只返回旧d28 Host ad8b153c源码的对照也 **43/43 pass**（04:20:27.836–04:20:31.271UTC）；实际load SHA与ledger已保存，产品Host从未替换。其它输入仍当前96，因此不冒称跑了整个旧revision。

最终Base SHA54876071802db2b33906f9ba79b1641aae2ccf382de0bd80e250e37fcb19ca91；Shadcn SHAd6420f82827eef124d6768a7d94f095be254010c5c3e55308675fbd076c20851。原红、candidate.patch、两次focused命令/日志/源绑定均在本目录。

本轮没有重复27文件组或native，也不将43项通过称为新全量通过。这是注入事实的Runtime/ownership证据，不是浏览器像素布局证明。未commit/push/外部写入；human-assisted partial/ABSTAIN。

后到父代理原27文件组合也已实际终态：04:20:27.642–04:20:35.837UTC，27files/365pass/2TODO/exit0，准确96+同两fixture预提交。原receipt/log另存并绑定；这是父代理的独立原命令执行，没有把本agent的43focused改标为27。
