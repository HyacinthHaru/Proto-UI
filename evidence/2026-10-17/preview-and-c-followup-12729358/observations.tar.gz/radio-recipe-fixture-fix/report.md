唯一测试候选已通过完整原生8case：四个Adapter各initial-entry与interaction均通过，零过滤、零失败。执行于2026-10-17T04:49:10.198114+00:00至2026-10-17T04:49:39.515671+00:00，真实HEAD为EF `ef87095d07736a5bf3cf6355c39ff9904e152582`，只有本测试未提交修改；不是已提交后或官方CI执行。

改动只有2行新增、1行删除：最终dark→light恢复后checked Default alpha期待1，同时增加unchecked Comfortable alpha0。原有输入、case顺序、所有timeout、语义断言、最终value/errors检查与截图逻辑均保留。生产实现和spec未修改。该期待由当前draft P-SHADCN-RADIO-GROUP-ITEM-CURRENT-VISUAL-SURFACE及既有checked→bg-primary实现支持。

原EF官方红仍保留：run39002392480/job117308778260，initial-entry4过、interaction4红，cause line324 expected0/received1。本轮没有为了重复已确证红项再跑原本地文件；Linux原CI与此次macOS候选不是同环境控制。

候选SHA256 `ad7cf43441c2f209bad310e9a48ccb3bc27d2006f31a809e64a4c999a661b5fb`；Git blob `268f4534211b52a109a02310244a4719d0a66019`。原SHA256 `64abd6f29d1f8f97f30f2054da3bb6631c3bc671e994f4e289f70be074d09d60`。完整tracked census 11328项前后零byte变化，唯一未匹配EFcommit的路径始终是授权test。

工具链实测v24.21.0 / pnpm10.32.1，实际browser155.0.8059.80，一worker、原repository harness。runner已终态，server55978无监听；未遗留本runner进程组。八份原sidecar的pageerrors均为空。

原测试生成20张PNG和8份JSON，复制字节完全一致；20张全部逐张view_image查看。桌面帧显示各自选中renderer与checked/focus/disabled状态；窄图三个组纵向排列，Runtime tabstrip在preview右侧裁剪，保留这一视觉限制。原截图中的dark/narrow帧发生在最终light恢复之前，没有重拍最终light图；新alpha1/alpha0由真实已通过断言证明，不能把dark图标成最终light状态。无全页/AT/全光学验收声明。

[report.json](report.json)含执行/来源/限制；[visual-review.json](visual-review.json)含20图逐项SHA和可见事实；[receipt.json](receipt.json)保留原command/时点/进程/源码。候选留在共享产品树供root审查，未stage/commit/push，结束本轮工作。human-assisted/current-user；unassessed/partial/ABSTAIN。
