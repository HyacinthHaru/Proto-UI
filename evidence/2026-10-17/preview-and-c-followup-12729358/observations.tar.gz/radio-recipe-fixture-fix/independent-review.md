最终单文件候选独立审查：**0 项剩余具体 source finding，partial/ABSTAIN**。

候选 `apps/www/src/content/docs/zh-cn/demo-shadcn-radio-group.browser.test.ts` SHA256 为 `ad7cf43441c2f209bad310e9a48ccb3bc27d2006f31a809e64a4c999a661b5fb`。对 EF 原 `64abd6f2…` 的差异恰好是最后 light 回切时，checked Default alpha 从 0 改为 1，并另验 unchecked Comfortable alpha 为 0；将这两行还原后，文件全部字节等于 EF。原 8 cases、输入顺序、selection/focus/navigation/cancel/disabled/geometry/errors 断言、120s case 与既有 polling timeout、180s setup/60s cleanup 均保留。新增了一次有直接判别力的默认 expect.poll，不能描述成没有新增 await 或观察成本完全不变。

依据是现有 draft `P-SHADCN-RADIO-GROUP-ITEM-CURRENT-VISUAL-SURFACE` 的双主题 checked primary fill。原 case 已经通过真实输入把 Default 设为 checked 并断言 `[true,false,false]`，而 `selected` 变量此时只是名为 Comfortable 的未选项。`T-SHADCN-RADIO-GROUP-0001` 的 SURFACES/BROWSER 映射与 P 一致，没有另一个 checked-light 必须透明的要求。Base Item T 明确排除 visual 所有权，也不构成冲突。因此无需扩写规范或升格 draft。原漂移 **PR901-RADIO-LIGHT-ORACLE-001** 在此候选及本地执行范围内关闭。

实际原完整 8 用例：**2026-10-17 04:49:10.198–04:49:39.515 UTC，8 passed / 0 failed / 0 pending，exit 0**。Node 24.21.0、pnpm 10.32.1、macOS 26.7.1 arm64、Chrome 155.0.8059.80。每个 runtime 的 initial-entry 与 interaction 均通过，8 个原 JSON 的 errors 均为空。执行是 **EF + 单 fixture 候选**，不是后续提交后的重新运行，也不是 Linux 对照。原 EF canonical 的 4 项 interaction 失败完整保留。

前后 11,328 条 tracked-source snapshot 完全相同；其 Git mode/kind/blob 与 EF 全树对账，唯一 working 差异就是上述 fixture。这个数量是完整 tracked snapshot，不能说 11,328 文件都被浏览器加载。20 张原 PNG 存在；本审查只核源码、日志和 JSON，没有逐图观察，视觉审阅由 trace/root 的真实回执另列，不称完整视觉或 AT 验收。EF 已冻结 CI/source 材料、产品实现与 spec 字节均未改写；没有外部发布或 GitHub APPROVE。
