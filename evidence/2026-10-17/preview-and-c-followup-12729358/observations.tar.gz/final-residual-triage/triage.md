本轮只读核验没有建立可立即修复的新增 C 源码缺陷；这不表示 C 已无缺陷，也不豁免现存红项。当前源码为 `ef87095d07736a5bf3cf6355c39ff9904e152582`，tree `c42242dfb1b308ddbdeabbd30408a94efb281d6f`，前后 clean。相对 0d4 只有三个测试文件变化，生产源码未变。未运行测试、浏览器或 Actions，未修改产品或 GitHub。模式为 human-assisted / current-user，unassessed / partial / ABSTAIN。

| 残差与真实来源 | 首个可证分歧 | C 判断及最小下一步 |
| --- | --- | --- |
| EF Forms，run39002392479/job117308031019：10过2红 | 原 test597 Label 与 Error 颜色不等；此前 invalid、Error IDREF/文本、首次焦点已通过 | 0d 失败 DOM 进一步显示 Field Root `data-invalid` 与条件 destructive token 均已投射，pageErrors为空。优先查生成 CSS 匹配/层叠。没有新的 Context/lease 失败证据；官方后续正确提交/reset流程尚未执行。EF 原 log 相同首断言不冒充已读 EF DOM。 |
| EF Collapsible，run39002392426/job117307875973：原32过4红；另8诊断过、36原journey过滤 | 原 test584 `right=320.4375 > 320`，四 runtime、320px/200%字体 | 是真实几何不满足，不是本轮60s/trace-data-loss。共享断言尚不能区分 Root/Content 或 light/dark；下一步只需失败后同一节点及祖先的完整尺寸/box-sizing/token事实。不能擅自容差0.5或舍入。当前 Root/Content 明确 material-neutral，不能凭 Liquid 名称归因光学。 |
| 0d ordinary6，job117297522174：165过4红 | Brutalist **Button** consumer reflow test370，Solid main `right206 > contentRight+0.5=182.5` | 不是 Collapsible，也不是文字 Range 断言。优先 demo author surfaceStyle 与 preview shell布局；当前 demo 已声明 wrapping override，不能只见 prototype nowrap 就删掉它。失败后的height/scroll/text-line断言未执行。此任务所见 EF logs 尚无对应普通分片终态，不改标为EF执行。 |
| 0d ordinary4，job117297522183：122过**2红** | S4 zh-cn/en 两项均在 test28 全页 previewer readiness 60s超时；尚未进入 runS4Journey | 指定原 log 不是4个独立失败；重复摘要/报错不累加。全页所有demo的 `inited=1 && .host非空` 谓词缺具体卡住节点；inited在异步render前设置。Matrix默认lazy=false，也不能猜lazy根因。失败后列出nonready demo/runtime/host/startup/error即可区分C与其他owner；现不能称S4生命周期已坏或fixture已证错误。 |

本次 Host 改动的实际入口很窄：[`floating-ui-host.ts:208`](https://github.com/Proto-UI/Proto-UI/blob/ef87095d07736a5bf3cf6355c39ff9904e152582/packages/modules/positioning/src/web/floating-ui-host.ts#L208) 仅在 `targetAlignment` descriptor 存在时进入新测量；其余沿原 edge host。唯一实际原型注册点为 [`select/alignment-controller.ts:232`](https://github.com/Proto-UI/Proto-UI/blob/ef87095d07736a5bf3cf6355c39ff9904e152582/packages/prototypes/base/src/select/alignment-controller.ts#L232)，closed Context 在96–102已返回。Host只给当前浮动 Frame 建立 ownStyles，不给 Field颜色或 Button/Collapsible正文布局写样式。因此目前没有这三种测量直接被 Host 新坐标读取改变的路径证据。页面上的其他 Select/Header以及全Matrix相互作用没有动态采样，不能据此宣称所有间接影响不可能。

权威边界来自 [#883 C/D分工](https://github.com/Proto-UI/Proto-UI/issues/883)：C关注Anatomy/Runtime生命周期；Matrix及其他失败仍需单列，而且原Issue明确不能把日志失败组当独立根因。颜色和几何分别映射当前 draft `P-*-FIELD-LABEL-STYLE`、`P-LIQUID-GLASS-COLLAPSIBLE-VISUAL-SAFETY` / `T-COLLAPSIBLE-PROJECTIONS-0001`、BrutalistButton原生consumer测试；不提升为stable，也不由外观失败直接推断C退休/资源问题。

机器报告 [triage.json](triage.json) 包含32个准确Git blob/SHA、读取日志及0d Form DOM成员SHA、每项来源/未执行后段和下一次最小补证。未采用“main同红所以inherited”的判法，未推断四类同一根因。普通S4 paint分片的另一个click超时是不同断言，没有并入readiness计数。
