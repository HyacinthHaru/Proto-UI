EF ordinary shard5 的 RadioGroup 首个失败可直接定位，**不是仅剩 catch343 的未知断言**。原 log878–887保留完整 cause：test324:83，切回 light 后 checked `first` 的背景 alpha 期待0、实际1。

当前 draft [`P-SHADCN-RADIO-GROUP-ITEM-CURRENT-VISUAL-SURFACE`](https://github.com/Proto-UI/Proto-UI/blob/ef87095d07736a5bf3cf6355c39ff9904e152582/spec/prototypes/P-SHADCN-RADIO-GROUP-ITEM.yaml#L20) 明确 checked 在两种主题均为 `border-primary bg-primary text-primary-foreground`；[实现29–33](https://github.com/Proto-UI/Proto-UI/blob/ef87095d07736a5bf3cf6355c39ff9904e152582/packages/prototypes/shadcn/src/radio-group/item.proto.ts#L29) 也如此，dark专用规则保持checked primary。原test321已确认Value: default，因此324把仍checked的first期待成透明，与当前recipe矛盾。已成立的是测试期待漂移，尚无新的C生产选择/焦点/生命周期缺陷证据。

四项interaction均已越过pointer选择、Tab/focusVisible/ring、六次导航、empty Enter/Space、cancel/disabled、dark样式和narrow几何；四项独立initial-entry也通过。不能宣称完整交互验收：324之后的最终value/errors断言与成功JSON未执行。catch报告Browser errors为空。

最小建议已通知root，未应用：恢复light后保持checked first alpha1，并检查现已unchecked的Comfortable alpha0，保留真正dark→light转换证据。输入、超时、其余语义期待均不需改变；不修改生产实现或新增API。

**S5单列两项未知readiness失败**：zh-cn/en在test29全页previewer60s谓词超时，`runS5Journey`尚未执行。当前没有具体未就绪previewer或其错误快照，不能称Editor/Focus生命周期已坏。下一次若获授权，仅在原失败后保存nonready previewer的demo/runtime/id、inited/startup、host子节点/连接情况与既有pageerror，再定位owner；不改变原谓词/60s。它和此前0d S4两项属于不同执行和suite，不合并为四项同根因。

[官方job117308778260](https://github.com/Proto-UI/Proto-UI/actions/runs/39002392480/job/117308778260) 完整终态：71pass/18fail/15skip；4files failed/5passed/1skipped。18fail=ColorScheme8+LiquidCollapsible4+RadioGroup interaction4+S5 readiness2；overlay-scrollbar原16全部通过。实际checkout9803bb0d的tree `c42242dfb1b308ddbdeabbd30408a94efb281d6f` 与EF严格相等。

只检查已有本地目录，没有下载Actionsartifact12089109677。log声明13,335,492B/172files，但本地无该ZIP/index或Radio失败JSON/PNG；不把未读取内容当不存在。Radio文件写至`/tmp/proto-shadcn-radio-group-dcWezG`，与log上传root不同，是否收录仍需真实index才可判断。无需为了已保留的cause先重跑测试。

[机器补充报告](ef-shard5-addendum.json) 保留原log SHA、精确source/blob、cause片段和范围。EF前后clean，无测试/浏览器/Actions重跑，无源码/外部修改。human-assisted/current-user；unassessed / partial / ABSTAIN，不是正式批准。
