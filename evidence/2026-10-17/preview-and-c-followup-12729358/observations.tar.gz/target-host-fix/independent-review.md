最终冻结8路径已逐项核对，**0 个剩余具体源码 finding；真实 P2 `PR901-TARGET-HOST-SCROLL-001` 在最终候选中关闭**。仍为 human-assisted / unassessed / partial / ABSTAIN；当前是d28上working candidate，不是新commit或GitHub批准。

关键绑定：Host `5ba56d964638e5401927743be8e3631fd2c457ba9a8896c1eff61f2027e093b3`；Host test `1fe098bd879b09ff28c116569fc0679735953d8b4de0a58924d7d119ac048317`；Runtime injected-facts fixture `b1add57b8daa019e2849ab2a10e8674eb7f2aed848dafff20162355a746fa22e`。完整8路径SHA/blob/bytes在JSON，与candidate-freeze逐项一致。

初版80e遗漏actual horizontal scroll已由成对控制证实，不能被原11green掩盖：同1fe测试选中2项，80e实际2fail/11filtered；原ad8单source override实际2pass/11filtered。最终helper沿物理parentElement逐项减去实际signed scrollLeft，不写scroll或改变纯solver；Frame viewport origin的同一归一化保留共享外层位移抵消。原scroll红和source override控制保留。**最终6相关files/58tests真实通过**，包含13Host、pure solver/delivery、association/boundary和Runtime4。

其余核心条件未变：readPlan之后的执行代码与d28逐字一致，包括四次同步验证、<0.01稳定阈值、current/connected/lease、scroll实际readback、style ownership和invalid-geometry关闭。Surface动画没有被移除或手动重置。外部reference/value继续取BCR实测小数；floating offset/width明确采用CSSOM整数事实，actual scroll值不截断。180.25/165.75控制不证明任意fractional floating layout无损，<0.01也不是最终paint误差承诺。

原9个Host用例assertions保留，helper仅补与旧BCR一致的layout数据。Runtime fixture仅新增10行对应offsetLeft/offsetWidth事实，原180等期待和4个用例均保留；调整后fixture在原ad8 Host下亦4/4通过。最初related exit1原件继续保存，没有重标。

3份draft说明与最终Host方向一致：PLAN明确pre-paint layout测量及CSSOM精度限界，BINDING保留actual horizontal scroll与原首帧准入约束，T仅现有HOST实现降为needs-review并说明覆盖。没有新实体/API、criteria激活或生命周期升格。这是有明确来源的Web精度政策修正，不能称所有旧数值事实完全不变。

Homepage两路径仍为已审72d/2b8候选，严格parts/owner/generation和原5case保留；新增option可见前置的独立10s及旧2pass3fail来源另有报告。**当前26native仍在运行，Homepage5及新类型结果尚未计入本报告。** 本reviewer未运行测试、修改产品、提交或外部写入；后续原生失败必须继续独立记录。
