准确 d28 的官方红项已完成只读核对，**本次未建立可直接修改的新增 C 生命周期/Context 缺陷**。两个 job 均实际 checkout `d28b17bc04074213c96045fbcb9e7c29c7b1f0ae`，GitHub Git commit API 与本地对象的 tree 同为 `4375791330915298740fbad38f6ddb014028b764`；不是套用旧 CI，也不是 synthetic checkout。

| 官方执行 | 实际终态 | 首个可见分歧 |
| --- | --- | --- |
| [Collapsible run 38995355538 / job 117286587539](https://github.com/Proto-UI/Proto-UI/actions/runs/38995355538/job/117286587539) | 原 36 项：32 pass、4 fail | Liquid 四 Adapter，原 test:584 的 `geometry.right <= 320`，实际均 320.4375 |
| 同 job 的后置独立 focus 诊断 | 8 pass、36 skipped | 8份errors均空、24个getter均connected/focused/pointer-target一致；不是原36项验收 |
| [Forms run 38995355705 / job 117286588269](https://github.com/Proto-UI/Proto-UI/actions/runs/38995355705/job/117286588269) | 10 pass、2 fail | Shadcn/Brutalist 原 test:597，label 与 error 的颜色不等 |

Collapsible 四项分别耗时 4431/6855/6639/6466ms，**本轮不是60s timeout，也没有trace-data-loss失败**。原运行已经越过 runtime selection、200%字号设置、click、expanded=true；当前geometry目标的width>0与left>=0也通过，首次失败是right越界。此loop包含Root与Content，而日志没有保存当前target身份/完整geometry；失败发生在后面的文本/截图采集前。完整artifact329members里没有任何Liquid 320截图或JSON，所以不补造失败图、不把宽屏正常图当该失败状态。

这是一项真实几何失败；目前记录不能区分父容器尺寸、字体/最小宽度、样式投射或生命周期造成的尺寸问题。四Adapter同值与本地74绿均不足以直接归因或豁免。若继续，应仅在一项原Linux narrow断言失败后记录target索引、rect/style/祖先preview-host、viewport/document边界和connected/presence/expanded，原320谓词、输入和timeout保持；本次没有执行新probe。

Forms 两失败都已建立required error与首个editor焦点：`firstEditorFocused=true`，error ID与文本真实存在，**pageErrors=[]、captureErrors=[]**。Shadcn label `lab(2.75381 0 0)` / error `lab(48.4493 77.4328 61.5452)`；Brutalist label `rgb(0,0,0)` / error `rgb(159,18,57)`。两张官方invalid PNG已逐张view，确实是深色label、红色required message、焦点圈和真实控件。原官方后续有效提交/reset位于597后，不能声称这两项已继续完成；本地私有完整Form流程另列，不替代官方失败。

Collapsible原ZIP **16,596,035B / SHA256 2de3782731f47ee08925279c08ebb5f6af09a2413c8111d8e340dab9fff6832a / 329members**；Forms原ZIP **3,165,111B / SHA256 5ad13718d4ef7fb8930b2309b1eb9d8947f5004e2caa3f71da12ef1fd17e34ec / 72members**。都只下载一次并逐member读取/hash核对，digest匹配官方API。原8trace在官方Actions artifact托管，本次仅私有ZIP保留/成员索引，不公开镜像。这里只视审了2张Forms原图，其余图未称已视审。

官方环境实读Ubuntu24.04、Node24.21.0、pnpm10.32.1；Forms实际Chrome155.0.8059.39。Collapsible未单独记录Chrome版本，不借其它job填值。本地默认无capture、macOS环境与官方capture环境差异保留，不用环境差异直接解释根因。

完整精确源码链接、每个case、原日志SHA、artifact/member映射、两阶段及边界见 [report.json](report.json) 与 [visual-review.json](visual-review.json)。没有修改产品、断言/timeout、Actions重跑/取消或外部写入。human-assisted / partial / ABSTAIN。
