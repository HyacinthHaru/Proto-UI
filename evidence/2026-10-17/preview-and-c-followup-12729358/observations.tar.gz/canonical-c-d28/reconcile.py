from pathlib import Path
import json,hashlib,datetime,re,collections,subprocess
p=Path(__file__).parent;w=Path('<SOURCE_ROOT>');head='d28b17bc04074213c96045fbcb9e7c29c7b1f0ae';tree='4375791330915298740fbad38f6ddb014028b764'
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(n):return json.loads((p/n).read_text())
def fact(n):b=(p/n).read_bytes();return {'path':n,'bytes':len(b),'sha256':sha(b)}
def write(n,x):(p/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
cjob=read('collapsible-job.json');fjob=read('forms-job.json');remote=read('github-git-commit.json');assert cjob['head_sha']==fjob['head_sha']==head and remote['tree']['sha']==tree
logs={label:re.sub(r'\x1b\[[0-9;]*[A-Za-z]','',(p/(label+'-job.log')).read_text())for label in ['collapsible','forms']}
for label in logs:assert 'git log -1 --format=%H' in logs[label] and head in logs[label]
assert '4 failed' in logs['collapsible'] and '32 passed' in logs['collapsible'] and '8 passed' in logs['collapsible'] and '36 skipped' in logs['collapsible']
assert '2 failed' in logs['forms'] and '10 passed' in logs['forms']
sources=[]
for rel in ['apps/www/src/content/docs/zh-cn/demo-collapsible-projections.browser.test.ts','apps/www/src/content/docs/zh-cn/collapsible-focus-path-probe.ts','.github/workflows/collapsible-projections-evidence.yml','apps/www/src/content/docs/zh-cn/finf-representative-features.browser.test.ts']:
 data=subprocess.check_output(['git','show',head+':'+rel],cwd=w);blob=subprocess.check_output(['git','rev-parse',head+':'+rel],cwd=w,text=True).strip();sources.append({'path':rel,'gitBlob':blob,'sha256':sha(data),'bytes':len(data),'url':'https://github.com/Proto-UI/Proto-UI/blob/'+head+'/'+rel})
cmembers=read('collapsible-artifact-members.json');fmembers=read('forms-artifact-members.json')
assert not [m for m in cmembers if 'liquid-glass' in m['path'] and '320' in m['path']]
normal=[]
for f in sorted((p/'collapsible-artifact').glob('*.json')):
 d=json.loads(f.read_text());normal.append({'path':str(f.relative_to(p)),'sourceSha':d.get('sourceSha'),'sourceDirty':d.get('sourceDirty'),'sha256':sha(f.read_bytes())})
assert all(x['sourceSha']==head for x in normal)
diag=[]
for f in sorted((p/'collapsible-artifact/diagnostics').glob('*.json')):
 d=json.loads(f.read_text());samples=[x for x in d['records']if isinstance(x.get('result'),dict)]
 assert d['sourceSha']==head and d['errors']==[] and d['traceSaved']
 assert len(samples)==3 and all(all(x['result'].get(k) is True for k in ['connected','focused','expectedIsPointerTarget','activeIsPointerTarget'])for x in samples)
 diag.append({'path':str(f.relative_to(p)),'sha256':sha(f.read_bytes()),'runtime':d['runtime'],'order':d['order'],'sourceSha':d['sourceSha'],'errors':d['errors'],'traceSaved':d['traceSaved'],'sampleCount':len(samples),'allSamplesConnectedFocusedAndPointerMatched':True,'scope':d['scope']})
assert len(diag)==8
forms=[];visual=[]
for family in ['shadcn','brutalist']:
 path=f'forms-artifact/{family}-form.json';d=read(path);assert d['revision']==head and d['tree']==tree and d['result']=='failed' and d['pageErrors']==[] and d['captureErrors']==[]
 assert ':597:33)' in d['error']['stack']
 shot=next(x for x in d['screenshots']if x['state']=='invalid-submit-first-focus');obs=shot['observation'];assert obs['firstEditorFocused'] is True
 image=f"viewed-images/{shot['file']}";assert fact(image)['sha256']==shot['sha256']
 forms.append({'case':d['case'],'family':family,'runtime':d['runtime'],'result':d['result'],'revision':d['revision'],'tree':d['tree'],'browser':d['browser'],'error':d['error'],'pageErrors':d['pageErrors'],'captureErrors':d['captureErrors'],'firstEditorFocused':obs['firstEditorFocused'],'errorText':obs['errorText'],'errorId':obs['errorId'],'colors':{k:obs[k]['color']for k in ['field','label','editor','error']},'caseReceipt':fact(path),'failureDiagnostics':d['failureDiagnostics']})
 visual.append({**fact(image),'artifactMember':shot['file'],'family':family,'actualHead':head,'actuallyViewed':True,'method':'Original artifact PNG individually viewed with view_image; no edit/reencoding.','visibleFacts':'React selected; empty displayName has visible focus outline and red required message. Label remains dark, matching the failing color equality. Other form controls are present.','limits':'Previewer crop only. No full viewport/AT or full visual acceptance; this is the official invalid state before the subsequent valid-submit path.'})
write('visual-review.json',{'at':now(),'images':visual,'viewedCount':2,'scope':'Only these two official Form invalid PNG were visually reviewed. No Collapsible 320 failure PNG exists in this artifact; other PNG remain unreviewed.'})
allForms=[]
for f in sorted((p/'forms-artifact').glob('*.json')):
 d=json.loads(f.read_text())
 if 'case'in d:allForms.append({'case':d['case'],'result':d['result'],'revision':d['revision'],'tree':d['tree'],'pageErrors':d['pageErrors'],'captureErrors':d['captureErrors']})
assert len(allForms)==12 and collections.Counter(x['result']for x in allForms)=={'passed':10,'failed':2}
collCases=[]
for runtime in ['wc','react','vue','vue2']:
 line=next(x for x in logs['collapsible'].splitlines()if '× liquid-glass' in x and f'> {runtime} preserves padding' in x)
 duration=int(re.search(r'(\d+)ms$',line).group(1));collCases.append({'runtime':runtime,'title':f'liquid-glass Collapsible public browser evidence > {runtime} preserves padding and wraps long text at 320px and 200% type','durationMs':duration,'failedPath':'apps/www/src/content/docs/zh-cn/demo-collapsible-projections.browser.test.ts','line':584,'assertion':'expect(geometry.right).toBeLessThanOrEqual(320)','actual':320.4375,'expectedMaximum':320,'targetIdentity':'Not recorded: loop contains root and Content. No failure-only geometry object or corresponding 320 capture reached.'})
report={'at':now(),'mode':'human-assisted/current-user; advisory/unassessed; partial/ABSTAIN','scope':'Read-only exact d28 official Collapsible and Forms classification; no Actions rerun/cancel, local browser/test, product change or external write.','source':{'head':head,'tree':tree,'checkout':'Both job logs explicitly check out head d28, not a synthetic merge; exact SHA confirmed by git log and artifact source metadata. GitHub Git commit API tree equals local object.','gitHubCommitAPI':fact('github-git-commit.json'),'files':sources},'collapsible':{'runId':38995355538,'jobId':117286587539,'url':cjob['html_url'],'status':cjob['status'],'conclusion':cjob['conclusion'],'jobWindow':{'start':cjob['started_at'],'end':cjob['completed_at']},'originalAcceptance':{'testFiles':1,'passed':32,'failed':4,'total':36,'skipped':0,'failureClass':'320px layout geometry bound','cases':collCases,'notObservedFailureClasses':['60s timeout','trace-data-loss','focus readiness timeout'],'firstDivergenceBoundary':'Original setup/runtime selection/200% font injection/native click/expanded=true complete before the geometry loop. Width>0 and left>=0 pass for the current target; right exceeds 320. That does not establish target identity or CSS/Runtime root cause.','unexecutedAfterFailure':'For each failed case, the current target scrollWidth check and all later text-bounds/padding/capture/closing assertions are not reached. The successful state is not inferred from other cases.'},'postFailureDiagnostic':{'passed':8,'skipped':36,'totalRegistered':44,'errors':0,'traceSaved':8,'focusSamples':24,'all24ConnectedFocusedPointerMatched':True,'records':diag,'boundary':'Separate fresh-context diagnostic after the failed original suite; does not replace original acceptance, reproduce its 320 layout or establish the original deadline.'},'artifact':{**read('collapsible-artifact-receipt.json'),'artifactId':12086724575,'extensions':dict(collections.Counter(Path(x['path']).suffix for x in cmembers)),'normalCaptureJSONSourceBindings':len(normal),'allNormalSourceSHAExact':True,'dirtyValues':dict(collections.Counter(str(x['sourceDirty'])for x in normal)),'liquid320Members':0,'rawTraceMembers':len([x for x in cmembers if x['path'].endswith('.trace.json')]),'rawTraceBoundary':'Original 8 traces are in the official hosted artifact and retained inside the downloaded private ZIP; not mirrored to a public packet by this task.'},'sourceBindings':normal,'steps':cjob['steps']},'forms':{'runId':38995355705,'jobId':117286588269,'url':fjob['html_url'],'status':fjob['status'],'conclusion':fjob['conclusion'],'jobWindow':{'start':fjob['started_at'],'end':fjob['completed_at']},'passed':10,'failed':2,'total':12,'cases':forms,'allCaseResults':allForms,'artifact':{**read('forms-artifact-receipt.json'),'artifactId':12086684001,'extensions':dict(collections.Counter(Path(x['path']).suffix for x in fmembers))},'firstDivergenceBoundary':'Both fail original line597 label.color===error.color, after invalid submit/focus/error identity and after invalid-state capture. Both pageErrors and captureErrors arrays are empty; no missing-base-field/provider exception appears in these case receipts.','unexecutedAfterFailure':'Original corrected valid submit/reset path occurs after line597 and was not reached in these two official cases. The separate local complete-flow result is not substituted.','steps':fjob['steps']},'environment':{'os':'Ubuntu 24.04','node':'v24.21.0','pnpm':'10.32.1','chromeFormsActual':'155.0.8059.39','chromeCollapsible':'CHROME_PATH=/usr/bin/google-chrome in log; version not directly recorded in its retained sidecars/log. Do not borrow Forms version as a separate Collapsible measurement.','localControlBoundary':'Local d28 four files 74pass used macOS and default capture off; official Collapsible uses capture env plus its own subsequent diagnostics. Local Form c6 run used private callback observer. Neither overrides this official failure.'},'CJudgment':{'newConcreteLifecycleOrContextDefectEstablished':False,'basis':'The recorded first failures are geometric extent and label/error color equality, with no observed owner/epoch/resource/Context exception at those failure points. This does not prove the issues are unrelated to C or inherited; it limits the current causal evidence.','nextMinimalObservationIfPursued':'One original Linux Liquid narrow case with failure-only observation at the unchanged geometry assertion: record target index (Root or Content), rect/style/min-width/box sizing/overflow, closest adapter/preview host and ancestors, viewport/document extents, connected/presence/expanded state. Preserve original expected 320, input and timeout; do not add epsilon/wait or rerun to seek green. No new run authorized/executed here.','notProposed':'No paint/Compiler/Material implementation takeover and no source patch based solely on cross-Adapter count or local green.'},'evidence':{n:fact(n)for n in ['collapsible-job.json','collapsible-job.log','collapsible-run.json','collapsible-artifact-members.json','collapsible-artifact-receipt.json','forms-job.json','forms-job.log','forms-artifact-members.json','forms-artifact-receipt.json','visual-review.json']}}
write('report.json',report)
md=f'''准确 d28 的官方红项已完成只读核对，**本次未建立可直接修改的新增 C 生命周期/Context 缺陷**。两个 job 均实际 checkout `{head}`，GitHub Git commit API 与本地对象的 tree 同为 `{tree}`；不是套用旧 CI，也不是 synthetic checkout。

| 官方执行 | 实际终态 | 首个可见分歧 |
| --- | --- | --- |
| [Collapsible run 38995355538 / job 117286587539]({cjob['html_url']}) | 原 36 项：32 pass、4 fail | Liquid 四 Adapter，原 test:584 的 `geometry.right <= 320`，实际均 320.4375 |
| 同 job 的后置独立 focus 诊断 | 8 pass、36 skipped | 8份errors均空、24个getter均connected/focused/pointer-target一致；不是原36项验收 |
| [Forms run 38995355705 / job 117286588269]({fjob['html_url']}) | 10 pass、2 fail | Shadcn/Brutalist 原 test:597，label 与 error 的颜色不等 |

Collapsible 四项分别耗时 4431/6855/6639/6466ms，**本轮不是60s timeout，也没有trace-data-loss失败**。原运行已经越过 runtime selection、200%字号设置、click、expanded=true；当前geometry目标的width>0与left>=0也通过，首次失败是right越界。此loop包含Root与Content，而日志没有保存当前target身份/完整geometry；失败发生在后面的文本/截图采集前。完整artifact329members里没有任何Liquid 320截图或JSON，所以不补造失败图、不把宽屏正常图当该失败状态。

这是一项真实几何失败；目前记录不能区分父容器尺寸、字体/最小宽度、样式投射或生命周期造成的尺寸问题。四Adapter同值与本地74绿均不足以直接归因或豁免。若继续，应仅在一项原Linux narrow断言失败后记录target索引、rect/style/祖先preview-host、viewport/document边界和connected/presence/expanded，原320谓词、输入和timeout保持；本次没有执行新probe。

Forms 两失败都已建立required error与首个editor焦点：`firstEditorFocused=true`，error ID与文本真实存在，**pageErrors=[]、captureErrors=[]**。Shadcn label `lab(2.75381 0 0)` / error `lab(48.4493 77.4328 61.5452)`；Brutalist label `rgb(0,0,0)` / error `rgb(159,18,57)`。两张官方invalid PNG已逐张view，确实是深色label、红色required message、焦点圈和真实控件。原官方后续有效提交/reset位于597后，不能声称这两项已继续完成；本地私有完整Form流程另列，不替代官方失败。

Collapsible原ZIP **16,596,035B / SHA256 2de3782731f47ee08925279c08ebb5f6af09a2413c8111d8e340dab9fff6832a / 329members**；Forms原ZIP **3,165,111B / SHA256 5ad13718d4ef7fb8930b2309b1eb9d8947f5004e2caa3f71da12ef1fd17e34ec / 72members**。都只下载一次并逐member读取/hash核对，digest匹配官方API。原8trace在官方Actions artifact托管，本次仅私有ZIP保留/成员索引，不公开镜像。这里只视审了2张Forms原图，其余图未称已视审。

官方环境实读Ubuntu24.04、Node24.21.0、pnpm10.32.1；Forms实际Chrome155.0.8059.39。Collapsible未单独记录Chrome版本，不借其它job填值。本地默认无capture、macOS环境与官方capture环境差异保留，不用环境差异直接解释根因。

完整精确源码链接、每个case、原日志SHA、artifact/member映射、两阶段及边界见 [report.json](report.json) 与 [visual-review.json](visual-review.json)。没有修改产品、断言/timeout、Actions重跑/取消或外部写入。human-assisted / partial / ABSTAIN。
'''
(p/'report.md').write_text(md)
print(json.dumps({'report':fact('report.json'),'markdown':fact('report.md'),'visual':fact('visual-review.json'),'normalSidecars':len(normal),'formsAllPageErrors':sum(len(x['pageErrors'])for x in allForms)},indent=2))
