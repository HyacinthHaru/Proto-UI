准确 **0d4dae32 / tree395404c2** 的指定 canonical 对账已终态。唯一collector7024自然结束；没有rerun/cancel/dispatch或产品改动。结论仍 **human-assisted / partial / ABSTAIN**，不是平台批准。

普通CI run38998718075实际 **22 jobs：12success / 10failure**。全部22份原job日志已取得，实际checkout均为`7014058a29141fb4d52b4e80dec704b2fc601d25`，官方tree精确等0d4。原8browser结果：

| 分片 | 实际结果 |
| --- | --- |
| 1 | 原900s外层exit124，无完整Vitest汇总 |
| 2 | 原900s外层exit124，无完整Vitest汇总 |
| 3 | 58pass / 3fail |
| 4 | 122pass / 2fail |
| 5 | 63pass / 26fail / 15skip |
| 6 | 165pass / 4fail |
| 7 | 原900s外层exit124，无完整Vitest汇总 |
| 8 | 原900s外层exit124，无完整Vitest汇总 |

只有完整3/4/5/6可合计 **408pass / 35fail / 15skip（458reported tests）**，不能构造全8分片总数。general在`check:public-docs`的78条诊断处终止，顺序逐条等d28，Vitest未启动。Package新canonical实际47/47build、47manifests，九项 **4PASS / 5ADVISORY**；显式Finf advisory成功不代表五项超预算严格通过。实际LinuxNode24.21.0/zlib1.3.2.1-motley-8002e91/esbuild0.25.12，九项gzip/minified/hash完整保存在JSON。

当前实证阳性：Runtime layout/loading14、productionretry6、alignment/group12、portal8、Field25、Dialogcandidate8和严格历史classifier均通过；Field含workflow原3Liquid opt-in trace，非25全untraced。Homepage原5在ordinary6全过；portal原8也在ordinary4通过。先前修复前head结果没有冒充这些新执行。

剩余红项明确保留：Coll原36=32pass4个320.4375>320几何失败，另外8focus诊断通过不覆盖该红；Forms10pass2labelcolor红，当前官方两JSON实际pageErrors=[]/captureErrors=[]。Forms后段仍被原colorassertion挡住，不能据此称全流程canonical通过或旧provider原因已关闭。ordinary5的8个Select scrollbar仍使用edgegap4前提而当前Homepage是完整item-aligned，profile修复另在评估，不在0d4里称已解决。Shadow等待/click、color/reflow/Radio以及超时分片中的局部观察均保留，不因main红或测试名称自动归因C/非C。

末次完整head分页：38workflow全部终态（25success/13failure），109check runs全部终态（67success/42failure）；DCOsuccess，独立Vercelstatus是Authorization required to deploy。Finf18jobs=11success/7failure，但本审只对Forms取了细节，其余feature仅状态，不猜失败机制。

冻结111文件清单及其中所有原件保持不变。此terminal报告是后到增补，不把旧checkpoint改写为终态；当前公开包若只纳先前checkpoint，应明确截止时间与完整CI非全绿。
