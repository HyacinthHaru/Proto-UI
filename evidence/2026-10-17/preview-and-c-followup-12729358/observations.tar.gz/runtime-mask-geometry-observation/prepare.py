from pathlib import Path
import subprocess,json,hashlib,difflib,os
p=Path(__file__).parent;old=p.parent/'runtime-mask-failure-only';w=Path('<SOURCE_ROOT>');host='packages/modules/positioning/src/web/target-alignment-host.ts';test='apps/www/src/content/docs/zh-cn/runtime-loading-mask.browser.test.ts'
base=(w/host).read_text();assert base==subprocess.check_output(['git','show','d28b17bc04074213c96045fbcb9e7c29c7b1f0ae:'+host],cwd=w,text=True);(p/'original-host.ts').write_text(base)
needle='    const owned = ownStyles(frame);'
helper='''    const diagnosticStore = ((view as any).__puiTargetAlignmentObservation ??= {
      rows: [], nodeIds: new WeakMap(), nextNodeId: 1,
    });
    let diagnosticPosition = 0;
    let diagnosticPass = -1;
    let diagnosticStage = 'start';
    const diagnosticNode = (node: HTMLElement) => {
      let id = diagnosticStore.nodeIds.get(node);
      if (!id) { id = diagnosticStore.nextNodeId++; diagnosticStore.nodeIds.set(node, id); }
      return { id, tag: node.tagName, domId: node.id, connected: node.isConnected,
        owner: node.getAttribute('data-projection-owner'), generation: node.getAttribute('data-projection-generation'),
        prototype: node.getAttribute('data-projection-prototype'), ref: node.getAttribute('data-demo-ref'),
        inlineStyle: node.getAttribute('style'), transition: node.getAttribute('data-transition-state'),
        detached: node.hasAttribute('data-pui-view-detached'), parentTag: node.parentElement?.tagName };
    };
    const diagnosticObserve = (kind: string, details: unknown) => {
      diagnosticStore.rows.push(JSON.parse(JSON.stringify({ kind, at: view.performance.now(),
        timeOrigin: view.performance.timeOrigin, request, position: diagnosticPosition,
        pass: diagnosticPass, stage: diagnosticStage, frame: diagnosticNode(frame),
        targets: Object.fromEntries(keys.map((key) => [key, diagnosticNode(targets[key])])), details,
      }, (_key, value) => typeof value === 'number' && !Number.isFinite(value)
        ? { observationNonFinite: String(value) } : value)));
    };
    const diagnosticSolve = (input: Parameters<typeof solveTargetAlignment>[0], constraints: Parameters<typeof solveTargetAlignment>[1]) => {
      const result = solveTargetAlignment(input, constraints);
      diagnosticObserve('solve', { input, constraints, result });
      return result;
    };
    diagnosticObserve('start', {});
'''
assert base.count(needle)==1;s=base.replace(needle,helper+needle)
s=s.replace('      const result = solveTargetAlignment(\n        {','      const result = diagnosticSolve(\n        {');assert s.count('const result = diagnosticSolve(')==1
needle='      const text = targets.inlineTarget.getBoundingClientRect();';assert s.count(needle)==1;s=s.replace(needle,needle+"\n      diagnosticObserve('existing-rects', { reference: reference.toJSON(), value: value.toJSON(), surface: surface.toJSON(), text: text.toJSON() });")
needle="      if (result.kind !== 'plan') {\n        report({ status: 'unavailable', reason: 'invalid-geometry' });";assert s.count(needle)==1;s=s.replace(needle,"      if (result.kind !== 'plan') {\n        diagnosticObserve('solver-non-plan', { result });\n        report({ status: 'unavailable', reason: 'invalid-geometry' });")
needle='      let stable = false;\n      try {';assert s.count(needle)==1;s=s.replace(needle,"      let stable = false;\n      diagnosticPosition += 1; diagnosticPass = -1; diagnosticStage = 'initial';\n      diagnosticObserve('position-begin', { applied, requestedSpan, previousScroll });\n      try {")
needle='        for (let pass = 0; pass < 4; pass++) {';assert s.count(needle)==1;s=s.replace(needle,needle+"\n          diagnosticPass = pass; diagnosticStage = 'inline-constraints';\n          diagnosticObserve('pass-begin', { candidate });")
needle='          const constrained = readPlan();';assert s.count(needle)==1;s=s.replace(needle,"          diagnosticStage = 'constrained';\n"+needle)
needle='          const settled = readPlan();';assert s.count(needle)==1;s=s.replace(needle,"          diagnosticStage = 'settled';\n"+needle)
needle='          if (equivalent(candidate, constrained) && equivalent(constrained, settled)) {';assert s.count(needle)==1;s=s.replace(needle,"          diagnosticObserve('verification', { candidate, constrained, settled });\n"+needle)
needle="      if (!stable) {\n        report({ status: 'unavailable', reason: 'invalid-geometry' });";assert s.count(needle)==1;s=s.replace(needle,"      if (!stable) {\n        diagnosticObserve('nonconverged', { plan, requestedSpan, previousScroll });\n        report({ status: 'unavailable', reason: 'invalid-geometry' });")
needle="        report({ status: 'applied' });";assert s.count(needle)==1;s=s.replace(needle,"        diagnosticObserve('applied', { plan, requestedSpan, previousScroll });\n"+needle)
(p/'diagnostic-host.ts').write_text(s)
original=(w/test).read_bytes();assert original==(old/'original.test.ts').read_bytes();(p/'original.test.ts').write_bytes(original)
derived=(old/'diagnostic.test.ts').read_text().replace((old/'capture.mjs').as_uri(),(p/'capture.mjs').as_uri());(p/'diagnostic.test.ts').write_text(derived)
capture=(old/'capture.mjs').read_text();needle='    const result = {';assert capture.count(needle)==1;capture=capture.replace(needle,"    const geometryObservation = (window as any).__puiTargetAlignmentObservation?.rows ?? null;\n"+needle) if False else capture
# This helper is JavaScript; only the post-failure existing evaluate gains an observer-array read.
assert capture.count('const result = {')==1;capture=capture.replace('const result = {','const result = {\n      geometryObservation: window.__puiTargetAlignmentObservation?.rows ?? null,',1);(p/'capture.mjs').write_text(capture)
env=os.environ.copy();env['PATH']='<LOCAL_NODE24_BIN>:'+env['PATH']
subprocess.run(['corepack','pnpm@10.32.1','exec','prettier','--config',str(w/'.prettierrc'),'--write',str(p/'diagnostic-host.ts'),str(p/'diagnostic.test.ts'),str(p/'capture.mjs')],cwd=w,env=env,check=True)
for orig,new,rel in [('original-host.ts','diagnostic-host.ts',host),('original.test.ts','diagnostic.test.ts',test)]:
 (p/(new+'.patch')).write_text(''.join(difflib.unified_diff((p/orig).read_text().splitlines(True),(p/new).read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
print(json.dumps({n:{'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest(),'bytes':(p/n).stat().st_size}for n in ['original-host.ts','diagnostic-host.ts','original.test.ts','diagnostic.test.ts','capture.mjs']},indent=2))
