import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const output = path.join(path.dirname(fileURLToPath(import.meta.url)), 'artifacts');
export async function captureRuntimeFailure(page, meta, originalError) {
  await mkdir(output, { recursive: true });
  const record = {
    meta,
    caughtAt: new Date().toISOString(),
    originalError: {
      name: originalError?.name,
      message: originalError?.message,
      stack: originalError?.stack,
    },
    captures: [],
    captureErrors: [],
  };
  const attempt = async (name, action) => {
    const startedAt = new Date().toISOString();
    try {
      const value = await action();
      record.captures.push({ name, startedAt, completedAt: new Date().toISOString() });
      return value;
    } catch (error) {
      record.captureErrors.push({ name, startedAt, error: String(error) });
      return null;
    }
  };
  record.facts = await attempt('single post-failure evaluate', () =>
    page.evaluate(() => {
      const attrs = (el) =>
        Object.fromEntries(Array.from(el.attributes).map((a) => [a.name, a.value]));
      const shallow = (el) =>
        el
          ? {
              tag: el.tagName,
              id: el.id,
              attrs: attrs(el),
              connected: el.isConnected,
              text: el.textContent?.slice(0, 700),
            }
          : null;
      const sample = (el) => {
        if (!el) return null;
        const style = getComputedStyle(el);
        const ancestors = [];
        for (let parent = el.parentElement; parent; parent = parent.parentElement)
          ancestors.push(shallow(parent));
        return {
          ...shallow(el),
          rect: el.getBoundingClientRect().toJSON(),
          clientRects: Array.from(el.getClientRects()).map((r) => r.toJSON()),
          hidden: el.hidden,
          inert: el.inert,
          parent: shallow(el.parentElement),
          ancestors,
          style: Object.fromEntries(
            [
              'display',
              'visibility',
              'opacity',
              'pointerEvents',
              'position',
              'zIndex',
              'overflow',
              'overflowX',
              'overflowY',
              'contentVisibility',
              'transform',
              'animationName',
              'animationDuration',
              'transitionProperty',
              'transitionDuration',
            ].map((key) => [key, style[key]])
          ),
        };
      };
      const runtimeOwner = document.querySelector('[data-homepage-runtime]');
      const controls = Array.from(
        document.querySelectorAll('[data-homepage-runtime] [data-projection-control="runtime"]')
      );
      const triggers = Array.from(
        document.querySelectorAll(
          '[data-homepage-runtime] [data-projection-control="runtime"] [role="combobox"]'
        )
      );
      const ids = triggers.map((el) => el.getAttribute('aria-controls')).filter(Boolean);
      const controlled = Array.from(document.querySelectorAll('[id]')).filter((el) =>
        ids.includes(el.id)
      );
      const all = Array.from(document.querySelectorAll('*'));
      const roots = all.filter((el) => el.tagName.endsWith('-SELECT-ROOT'));
      const contents = all.filter(
        (el) => el.tagName.endsWith('-SELECT-CONTENT') || el.getAttribute('role') === 'listbox'
      );
      const options = all.filter(
        (el) => el.tagName.endsWith('-SELECT-ITEM') || el.getAttribute('role') === 'option'
      );
      // All DOM/style facts are collected before optional public Expose reads.
      const result = {
        geometryObservation: window.__puiTargetAlignmentObservation?.rows ?? null,
        at: performance.now(),
        timeOrigin: performance.timeOrigin,
        url: location.href,
        viewport: { innerWidth, innerHeight, devicePixelRatio },
        document: {
          rootFontSize: getComputedStyle(document.documentElement).fontSize,
          theme: document.documentElement.dataset.theme,
          darkClass: document.documentElement.classList.contains('dark'),
          activeElement: sample(document.activeElement),
        },
        runtimeOwner: sample(runtimeOwner),
        preferences: Array.from(document.querySelectorAll('[data-site-header-preferences]')).map(
          sample
        ),
        headerMenus: Array.from(
          document.querySelectorAll(
            '[data-site-menu-button], [data-demo-ref="home-menu"], [data-site-header-compact-context]'
          )
        ).map(sample),
        generationHosts: Array.from(
          document.querySelectorAll('[data-projection-generation-state]')
        ).map(sample),
        runtimeControls: controls.map(sample),
        triggers: triggers.map(sample),
        controlledIds: ids,
        controlledContents: controlled.map(sample),
        allSelectRoots: roots.map(sample),
        allContents: contents.map(sample),
        allOptions: options.map(sample),
        bodyChildren: Array.from(document.body.children).map(shallow),
        exposes: [],
      };
      for (const el of [...roots, ...contents]) {
        if (typeof el.getExposes !== 'function') continue;
        try {
          const exposes = el.getExposes();
          const state = {};
          for (const key of [
            'open',
            'value',
            'disabled',
            'alignmentDiagnostic',
            'transitionState',
            'isPresent',
          ]) {
            const handle = exposes[key];
            if (handle && typeof handle.get === 'function') state[key] = handle.get();
          }
          result.exposes.push({ element: shallow(el), state, readAt: performance.now() });
        } catch (error) {
          result.exposes.push({ element: shallow(el), readError: String(error) });
        }
      }
      return result;
    })
  );
  record.pageErrors = await attempt('Playwright retained pageErrors', async () =>
    (await page.pageErrors()).map((error) => ({
      name: error.name,
      message: error.message,
      stack: error.stack,
    }))
  );
  record.consoleErrors = await attempt('Playwright retained consoleMessages', async () =>
    (await page.consoleMessages())
      .filter((message) => message.type() === 'error')
      .map((message) => ({ text: message.text(), location: message.location() }))
  );
  await attempt('DOM', async () =>
    writeFile(path.join(output, 'failure-dom.html'), await page.content())
  );
  await attempt('AX', async () =>
    writeFile(path.join(output, 'failure-aria.txt'), await page.locator('body').ariaSnapshot())
  );
  await attempt('actual viewport PNG', () =>
    page.screenshot({ path: path.join(output, 'failure.png'), timeout: 10_000 })
  );
  record.completedAt = new Date().toISOString();
  record.limit =
    'Only after original rejection; not click-time history. No listener/MO/layout/state sampling before failure. Public getExposes().get() reads occur after DOM sampling; no public setter or private state access. Original error is rethrown by caller.';
  await writeFile(path.join(output, 'failure.json'), JSON.stringify(record, null, 2) + '\n');
}
