一次同原case同步几何观测仍复现 click30000ms 红（1fail/5filtered），已恢复两份临时源码并保留root两份既有dirty。实际02:58:20.915–02:59:14.328UTC，d28/tree437579；Host原ad8b153c→临时cde4e6ef，原test03998d7f→临时1e5077ec，全部raw/patch/hash保留，port62031无listener。原scope中的“failure-only无sampling”仅适用于test catch，不能概括本轮Host同步旁观；独立execution-class-correction已明确，原收据不改。

实际54条记录、17次solver均返回plan，没有solver-non-plan。始终同request1、同frame及六个target物理ID、owner homepage-home-preferences/gen1。position1在preparing经两pass于1496.2ms applied；position2同几何保持稳定。position3进入entering后四轮inline inset为15.5→20.72498→25.68286→30.38831→34.85626，candidate与constrained始终不等，1500.1ms在原host:325 nonconverged分支报告invalid-geometry。

与此同时surface BCR height314→298.30005、text height80→76，而surface clientHeight312/target offsetHeight104/scrollport height312不变。尺寸比例吻合0.95，已读Shadcn Surface visual.ts在entering启用zoom-in-95。事实是paint后的BCR与layout client/offset读数在同一次求解混用并出现反馈漂移；把该比例归到具体动画CSS矩阵仍是源码支持的推断，测量时没有另采computed transform。不是缺targets、不是没发生初始applied、也没有记录到physical identity替换。

已有draft contract规定frame承layout、Surface承paint，并要求四次同步验证与0.01稳定度。不能加pass/epsilon、timer重试或implicit popper压掉原失败。下一最小实现检查应在既有Host fixture上以稳定layout+paint scale重现applied后失效，再确定不混入paint变换的通用测量方式；本轮仅定位，未修生产。

原solver参数AST完全相等，getBoundingClientRect4/getComputedStyle3/readPlan3调用点数不变，没有额外layout读、await/MO或前置RPC；同步记录本身仍可能扰动时序。真实failure PNG已view，展示闭合popup的Header，属于原error30秒之后，不是中间1500ms画面。plan-sequence.json与report.json保留全部首次分歧数据、来源和限界。partial/ABSTAIN。
