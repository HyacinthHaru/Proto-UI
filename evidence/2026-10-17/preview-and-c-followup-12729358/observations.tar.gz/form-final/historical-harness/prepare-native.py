from pathlib import Path
import subprocess,json,hashlib,difflib,datetime
p=Path(__file__).parent;w=Path('<SOURCE_ROOT>');tree='ac120a185a1b2d48e4a8961fad526b3399ef7944';src='apps/www/src/content/docs/zh-cn/finf-representative-features.browser.test.ts';original=subprocess.check_output(['git','show',tree+':'+src],cwd=w,text=True);(p/'original-official.browser.test.ts').write_text(original)
demoPath='apps/www/src/content/docs/form-primitives-demo.shared.ts';demo=subprocess.check_output(['git','show',tree+':'+demoPath],cwd=w);(p/'original-form-demo.ts').write_bytes(demo)
body=original[:original.index('beforeAll(async () => {')]
body=body.replace("let baseUrl = '';", "let baseUrl = '';\nlet localPhase = 'created';\nconst localErrors: unknown[] = [];\nconst requestedPaths = new Set<string>();\nconst callbackModules: unknown[] = [];\nconst candidateWorkingTree = '"+tree+"';")
old="  page.on('pageerror', (error) => pageErrors.push(error.message));"
new=r'''  await page.addInitScript(() => {
    (window as any).__formBehaviorCallbacks = [];
    (window as any).__formBehaviorInputs = [];
    for (const type of ['pointerdown', 'pointerup', 'click', 'input', 'change', 'keydown', 'keyup'])
      document.addEventListener(type, (event) => {
        const target = event.target as Element | null;
        (window as any).__formBehaviorInputs.push({
          type, trusted: event.isTrusted, at: performance.now(), timeOrigin: performance.timeOrigin,
          key: (event as KeyboardEvent).key ?? null,
          target: target ? { tag: target.tagName, role: target.getAttribute('role'),
            ref: target.getAttribute('data-demo-ref'), label: target.getAttribute('aria-label') } : null,
        });
      }, { capture: true, passive: true });
  });
  page.on('pageerror', (error) => {
    pageErrors.push(error.message);
    localErrors.push({ kind: 'pageerror', case: testCase.id, phase: localPhase, receivedNode: performance.now(),
      nodeTimeOrigin: performance.timeOrigin, name: error.name, message: error.message, stack: error.stack });
  });
  page.on('console', (message) => {
    if (message.type() === 'error') localErrors.push({ kind: 'console.error', case: testCase.id,
      phase: localPhase, receivedNode: performance.now(), text: message.text(), location: message.location() });
  });'''
assert body.count(old)==1;body=body.replace(old,new)
body=body.replace("await context.route('**/*', (request) => {", "await context.route('**/*', async (request) => {")
needle='    const url = new URL(request.request().url());';addition=r'''
    if (url.origin === new URL(baseUrl).origin) requestedPaths.add(url.pathname);
    if (url.origin === new URL(baseUrl).origin && url.pathname.endsWith('/form-primitives-demo.shared.ts')) {
      const response = await request.fetch();
      const raw = await response.text();
      const marker = 'refs.status.textContent = JSON.stringify(detail.values);';
      if (raw.split(marker).length !== 2) {
        localErrors.push({ kind: 'fixture-wiring', url: url.pathname, status: response.status(), markerMatches: raw.split(marker).length - 1 });
        await request.abort();
        return;
      }
      const observer = 'globalThis.__formBehaviorCallbacks.push({ at: performance.now(), timeOrigin: performance.timeOrigin, detail: structuredClone(detail) }); ';
      const observed = raw.replace(marker, observer + marker).replace(/\/\/# sourceMappingURL=.*$/gm, '');
      const index = callbackModules.length;
      await writeFile(path.join(output, `callback-module-${index}-original.js`), raw);
      await writeFile(path.join(output, `callback-module-${index}-observed.js`), observed);
      callbackModules.push({ case: testCase.id, path: url.pathname, status: response.status(),
        originalSHA256: createHash('sha256').update(raw).digest('hex'),
        observedSHA256: createHash('sha256').update(observed).digest('hex'),
        transformation: 'Only app-authored onSubmit report observation added before original status write; stale source map removed. These are actual served module bytes.' });
      await request.fulfill({ response, body: observed });
      return;
    }'''
assert body.count(needle)==1;body=body.replace(needle,needle+addition)
body=body.replace("    const response = await page.goto(`${baseUrl}${route}`, { waitUntil: 'networkidle' });", "    localPhase = testCase.id + ':navigation';\n    const response = await page.goto(`${baseUrl}${route}`, { waitUntil: 'networkidle' });")
needle='    await writeJson(`${testCase.id}.json`, {'
extra=r'''    const privateObservation = await page.evaluate(() => ({
      callbacks: (window as any).__formBehaviorCallbacks,
      nativeInputs: (window as any).__formBehaviorInputs,
    })).catch((error) => ({ captureError: String(error) }));
    await writeFile(path.join(output, `${testCase.id}-terminal-dom.html`), await page.content()).catch(() => {});
    await writeFile(path.join(output, `${testCase.id}-terminal-aria.txt`), await page.locator('body').ariaSnapshot()).catch(() => {});
'''
assert body.count(needle)==1;body=body.replace(needle,extra+needle+"\n      candidateWorkingTree, physicalHead: revision, physicalHeadTree: tree, privateObservation,\n      evidenceClass: 'private behavioral driver + app-authored callback observation, not original official/visual execution',")
behavior=r'''
async function formBehaviorJourney({ page, previewer, family, capture }: Journey) {
  localPhase = `${family}:select-react`;
  await selectRealRuntime(page, previewer, 'react', '[data-demo-ref="form"]', 1);
  expect(callbackModules.length, 'private callback module actually intercepted').toBeGreaterThan(0);
  const form = previewer.locator('[data-demo-ref="form"]');
  const editor = form.getByRole('textbox', { name: 'displayName', exact: true });
  const label = form.getByText('displayName', { exact: true });
  const field = label.locator('..');
  const quantity = form.getByRole('spinbutton', { name: 'Quantity · 数量', exact: true });
  const code = form.getByRole('textbox', { name: 'Code · 验证码', exact: true });
  const level = form.getByRole('slider', { name: 'Level · 等级', exact: true });
  const email = form.getByRole('checkbox', { name: 'Email · 邮件', exact: true });
  const sms = form.getByRole('checkbox', { name: 'SMS · 短信', exact: true });
  const submit = form.getByRole('button', { name: /Validate and submit/ });
  const reset = form.getByRole('button', { name: /Reset values/ });
  const callbacks = () => page.evaluate(() => (window as any).__formBehaviorCallbacks as Array<{ detail: { values: unknown; submissionId: number } }>);
  const callbackValues = (name: string, count = 2, otp = '12', channels = ['email']) => ({ displayName: name, quantity: count, code: otp, level: 25, channels });
  const assertSubmitted = async (expected: unknown, count: number) => {
    await expect.poll(() => editor.getAttribute('aria-invalid')).not.toBe('true');
    await expect.poll(() => editor.getAttribute('aria-errormessage')).toBe(null);
    await expect.poll(async () => JSON.parse((await previewer.locator('[data-demo-ref="status"]').textContent())!)).toEqual(expected);
    await expect.poll(async () => (await callbacks()).length).toBe(count);
    const events = await callbacks();
    expect(events[count - 1].detail.values).toEqual(expected);
    expect(Number.isInteger(events[count - 1].detail.submissionId)).toBe(true);
    expect(events[count - 1].detail.submissionId).toBeGreaterThan(0);
    if (count > 1) expect(events[count - 1].detail.submissionId).toBeGreaterThan(events[count - 2].detail.submissionId);
  };
  const assertInvalid = async (expectedCallbacks: number) => {
    await expect.poll(() => editor.getAttribute('aria-invalid')).toBe('true');
    await expect.poll(() => hasFocus(editor)).toBe(true);
    const errorId = await editor.getAttribute('aria-errormessage');
    expect(errorId).toBeTruthy();
    const error = form.locator(`[id=${JSON.stringify(errorId)}]`);
    expect(await error.isVisible()).toBe(true);
    expect(await error.textContent()).toMatch(/required/i);
    expect(await editor.getAttribute('aria-labelledby')).toBe(await label.getAttribute('id'));
    expect((await callbacks()).length).toBe(expectedCallbacks);
    return error;
  };
  expect(await editor.inputValue()).toBe('');
  expect(await quantity.inputValue()).toBe('2');
  expect(await code.inputValue()).toBe('12');
  expect(await level.getAttribute('aria-valuenow')).toBe('25');
  expect(await email.getAttribute('aria-checked')).toBe('true');
  expect(await sms.getAttribute('aria-checked')).toBe('false');
  const rest = { editor: await paint(editor), label: await paint(label) };
  await capture('behavior-rest', rest, previewer);
  localPhase = `${family}:invalid-submit`;
  await submit.click();
  const error = await assertInvalid(0);
  expect((await previewer.locator('[data-demo-ref="status"]').textContent())!).not.toContain('"displayName"');
  const invalid = { field: await paint(field), label: await paint(label), editor: await paint(editor), error: await paint(error) };
  await capture('behavior-invalid', { ...invalid, colorAcceptance: 'observed only; original visual gate remains separate', originalColorPredicates: { labelEqualsField: invalid.label.color === invalid.field.color, labelEqualsError: invalid.label.color === invalid.error.color, labelChanged: invalid.label.color !== rest.label.color, editorUnchanged: invalid.editor.color === rest.editor.color } }, previewer);
  localPhase = `${family}:corrected-submit`;
  await editor.fill('Form behavior one');
  await submit.click();
  await assertSubmitted(callbackValues('Form behavior one'), 1);
  await capture('behavior-corrected-submit', { callbacks: await callbacks() }, previewer);
  localPhase = `${family}:edit-composite-values`;
  await editor.fill('Form behavior two');
  await form.getByRole('button', { name: '+', exact: true }).click();
  await expect.poll(() => quantity.inputValue()).toBe('3');
  await code.fill('1234');
  expect(await code.inputValue()).toBe('1234');
  await sms.click();
  await expect.poll(() => sms.getAttribute('aria-checked')).toBe('true');
  await submit.click();
  await assertSubmitted(callbackValues('Form behavior two', 3, '1234', ['email', 'sms']), 2);
  await capture('behavior-composite-submit', { callbacks: await callbacks() }, previewer);
  localPhase = `${family}:reset`;
  await reset.click();
  await expect.poll(() => editor.inputValue()).toBe('');
  await expect.poll(() => quantity.inputValue()).toBe('2');
  await expect.poll(() => code.inputValue()).toBe('12');
  expect(await level.getAttribute('aria-valuenow')).toBe('25');
  await expect.poll(() => email.getAttribute('aria-checked')).toBe('true');
  await expect.poll(() => sms.getAttribute('aria-checked')).toBe('false');
  expect(await editor.getAttribute('aria-invalid')).not.toBe('true');
  expect(await editor.getAttribute('aria-errormessage')).toBe(null);
  expect((await callbacks()).length).toBe(2);
  await capture('behavior-reset', { callbacks: await callbacks() }, previewer);
  localPhase = `${family}:invalid-after-reset`;
  await submit.click();
  await assertInvalid(2);
  localPhase = `${family}:fresh-submit-after-reset`;
  await editor.fill('After reset');
  await submit.click();
  await assertSubmitted(callbackValues('After reset'), 3);
  await capture('behavior-after-reset-submit', { callbacks: await callbacks(), phase: localPhase }, previewer);
}
const behaviorCases = selectedCases.filter((c) => ['shadcn-form', 'brutalist-form'].includes(c.id)).map((c) => ({ ...c, run: formBehaviorJourney }));
if (behaviorCases.length !== 2) throw new Error('Exactly two independent Form behavior cases required.');
beforeAll(async () => {
  await mkdir(output, { recursive: true });
  await writeJson('source.json', { physicalHead: revision, physicalHeadTree: tree, candidateWorkingTree,
    actualTrackedStatus: execFileSync('git', ['status', '--porcelain=v1']).toString(),
    evidenceClass: 'private local behavior + callback observation; no official-only env spoofing',
    visualGate: 'Original formJourney paint assertions unmodified in source; this separate behavior function does not claim those pass.' });
  baseUrl = await startServer('/');
  if (!['127.0.0.1', 'localhost', '[::1]'].includes(new URL(baseUrl).hostname)) throw new Error('Loopback repository server required.');
  browser = await chromium.launch({ executablePath: await chromeExecutable(), headless: true,
    chromiumSandbox: true, args: ['--disable-dev-shm-usage'] });
  await writeJson('local-runtime.json', { baseUrl, chrome: browser.version(), node: process.version, nodeTimeOrigin: performance.timeOrigin, pid: process.pid });
}, 180_000);
afterAll(async () => { await browser?.close(); await stopServer(); }, 30_000);
describe('Private complete Form behavior, separate from visual acceptance', () => {
  for (const testCase of behaviorCases) it(testCase.id + ' React complete behavior', async () => {
    try { await runCase(testCase); }
    finally { await writeJson('observer-ledger.json', { phase: localPhase, errors: localErrors, callbackModules, requestedPaths: [...requestedPaths], candidateWorkingTree }); }
  }, 120_000);
});
'''
new=body+behavior;(p/'local.browser.test.ts').write_text(new);(p/'original-to-private.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True),fromfile='candidate-ac120/original-official',tofile='private-behavior')))
oldConfig=Path('<PRIVATE_STATE>/continue-20261015T045918Z/form-context/native-react/local.config.ts').read_text();oldConfig=oldConfig.replace('<PRIVATE_STATE>/continue-20261015T045918Z/form-context/native-react/local.browser.test.ts',str(p/'local.browser.test.ts'));(p/'local.config.ts').write_text(oldConfig)
(p/'preparation.json').write_text(json.dumps({'candidateTree':tree,'physicalHeadExpected':'26feceeb769ed9688ad652262631bc953cc43b9a','originalTestSHA256':hashlib.sha256(original.encode()).hexdigest(),'originalDemoSHA256':hashlib.sha256(demo).hexdigest(),'override':'Private Nodebehavior entry andoneHTTPserved appcallback observer, actualraw/observedJSrecorded;originaltrackedfilesunchanged','bounds':'twoReactfamilies,original120s cases/180s startup/30s cleanup,300s outer','uncovered':['asyncvalidator/cancel/retirement reentry','invalid/reset outwardcallback listeners','originalvisualinkacceptance','allAdapter/AT']},indent=2)+'\n')
print('prepared',str(p))
