from pathlib import Path
from urllib.parse import unquote
from html.parser import HTMLParser
import collections, datetime, hashlib, json, re, subprocess
p=Path(__file__).parent; o=p/'run-1'; a=o/'artifacts'; w=Path('<SOURCE_ROOT>')
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(name,data): (p/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def fact(path):
 b=path.read_bytes(); return {'path':str(path.relative_to(p)),'bytes':len(b),'sha256':sha(b)}
r=json.loads((o/'receipt.json').read_text()); ledger=json.loads((a/'observer-ledger.json').read_text())
before=json.loads((o/'tracked-source-before.json').read_text()); after=json.loads((o/'tracked-source-after.json').read_text())
assert r['exit']==0 and before==after and all(x['matchesCandidate'] for x in before)
assert r['physicalHeadBefore']==r['physicalHeadAfter']==r['candidateCommit']
assert r['physicalTreeBefore']==r['physicalTreeAfter']==r['candidateTree']
assert r['physicalStatusBefore']==r['physicalStatusAfter']=='' and not ledger['errors']
bm={x['path']:x for x in before}; requested=[]; unbound=[]
for url in ledger['requestedPaths']:
 decoded=unquote(url); rel=None
 if decoded.startswith('/@fs/'):
  try:rel=str(Path(decoded[4:]).relative_to(w))
  except ValueError:pass
 elif decoded.startswith('/src/'):rel='apps/www'+decoded
 if rel in bm: requested.append({'url':url,**bm[rel],'executionOverride':'App-authored onSubmit observation in served JS; original and observed bytes retained separately.' if rel=='apps/www/src/content/docs/form-primitives-demo.shared.ts' else None})
 else: unbound.append(url)
source={'at':now(),'actualHead':r['candidateCommit'],'actualTree':r['candidateTree'],'sourceCleanBeforeAfter':True,'trackedCensusCount':len(before),'unchangedCensusCount':len(before),'requestURLCount':len(ledger['requestedPaths']),'requestedTrackedCount':len(requested),'requestedTracked':requested,'unboundRequests':unbound,'unboundRequestCount':len(unbound),'censusBefore':fact(o/'tracked-source-before.json'),'censusAfter':fact(o/'tracked-source-after.json'),'limits':['Census is selected tracked source files, not proof every file was loaded.','Request URL plus before/after Git byte binding is not an emitted bundle metafile.','Installed dependencies, generated CSS and Vite transforms are not all Git-bound.','One served app callback module is explicitly observed by HTTP response replacement.']}
write('observed-source-binding.json',source)
original=(p/'original-official.browser.test.ts').read_text(); derived=(p/'local.browser.test.ts').read_text(); historical=(p/'historical-harness/local.browser.test.ts').read_text()
normalized=historical.replace('candidateWorkingTree','sourceWorkingTree').replace('ac120a185a1b2d48e4a8961fad526b3399ef7944',r['candidateTree'])
assert normalized==derived
start=original.index('async function formJourney('); end=original.index('\nasync function ',start+5)
assert original[start:end] in derived
modules=[]
marker='refs.status.textContent = JSON.stringify(detail.values);'
observer='globalThis.__formBehaviorCallbacks.push({ at: performance.now(), timeOrigin: performance.timeOrigin, detail: structuredClone(detail) }); '
for i,m in enumerate(ledger['callbackModules']):
 raw=(a/f'callback-module-{i}-original.js').read_text(); observed=(a/f'callback-module-{i}-observed.js').read_text()
 assert raw.count(marker)==1 and observed==re.sub(r'//# sourceMappingURL=.*$','',raw.replace(marker,observer+marker),flags=re.M)
 assert sha(raw.encode())==m['originalSHA256'] and sha(observed.encode())==m['observedSHA256']
 modules.append({**m,'original':fact(a/f'callback-module-{i}-original.js'),'observed':fact(a/f'callback-module-{i}-observed.js')})
class DOMFacts(HTMLParser):
 def __init__(self):super().__init__();self.forms=[];self.refs=collections.Counter();self.ids={};self.inputCount=0
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if d.get('data-demo-ref'):self.refs[d['data-demo-ref']]+=1
  if d.get('id'):self.ids[d['id']]={'tag':tag,'role':d.get('role')}
  if d.get('role')=='form' or tag=='form':self.forms.append({'tag':tag,**d})
  if tag=='input':self.inputCount+=1
stage={
 'behavior-rest':'React tab selected; empty displayName, quantity 2, code 12, level 25; Email selected, SMS clear; submit/reset controls visible.',
 'behavior-invalid':'Empty displayName has visible focus outline and red required error; its label remains dark. All other defaults remain visible.',
 'behavior-corrected-submit':'Form behavior one appears; default composite values and matching five-field JSON status visible; required error is absent.',
 'behavior-composite-submit':'Form behavior two, quantity 3, code 1234 and both Email/SMS are visible; status shows the second payload.',
 'behavior-reset':'Editor is empty and defaults are restored; status still shows the prior submit payload, consistent with the original callback-only status writer. This is not a new submission.',
 'behavior-after-reset-submit':'After reset is visible with default composite values; status displays the third current payload.',
 'final':'Actual full viewport shows the final React Form; lower prose and dev toolbar are partly outside/at the viewport edge. This is not a full-page visual or AT acceptance.'}
visual=[]; cases=[]; allCounts=collections.Counter()
for family in ['shadcn','brutalist']:
 d=json.loads((a/f'{family}-form.json').read_text())
 assert d['result']=='passed' and d['pageErrors']==[] and d['captureErrors']==[]
 for key in ['revision','physicalHead']: assert d[key]==r['candidateCommit']
 for key in ['tree','physicalHeadTree','sourceWorkingTree']: assert d[key]==r['candidateTree']
 events=d['privateObservation']['callbacks']; ids=[e['detail']['submissionId'] for e in events]
 assert len(events)==3 and ids==sorted(set(ids)) and all(x>0 for x in ids)
 expected=[{'displayName':'Form behavior one','quantity':2,'code':'12','level':25,'channels':['email']},{'displayName':'Form behavior two','quantity':3,'code':'1234','level':25,'channels':['email','sms']},{'displayName':'After reset','quantity':2,'code':'12','level':25,'channels':['email']}]
 assert [e['detail']['values'] for e in events]==expected
 counts=collections.Counter((x['type'],x['trusted']) for x in d['privateObservation']['nativeInputs']); allCounts.update(counts)
 untrusted=[x for x in d['privateObservation']['nativeInputs'] if not x['trusted']]
 color=next(x['observation']['originalColorPredicates'] for x in d['screenshots'] if x['state']=='behavior-invalid')
 html=(a/f'{family}-form-terminal-dom.html').read_text(); ax=(a/f'{family}-form-terminal-aria.txt').read_text()
 parsed=DOMFacts();parsed.feed(html)
 assert len(parsed.forms)==1 and 'form "Profile form · 资料表单"' in ax and 'text: After reset' in ax
 assert 'tab "React" [selected]' in ax and 'checkbox "Email · 邮件" [checked]' in ax and 'checkbox "SMS · 短信"' in ax
 for shot in d['screenshots']:
  image=a/shot['file']; b=image.read_bytes();assert sha(b)==shot['sha256']
  visual.append({'family':family,'runtime':'react','state':shot['state'],**fact(image),'dimensions':[int.from_bytes(b[16:20],'big'),int.from_bytes(b[20:24],'big')],'actuallyViewed':True,'method':'Each original PNG individually opened through view_image; no editing, montage or reencoding.','visibleFacts':stage[shot['state']],'sourceHead':r['candidateCommit'],'sourceTree':r['candidateTree'],'executedPrivateBehaviorAndCallbackObserver':True,'limitations':['Light desktop capture only; no dark/narrow/all-Adapter/OS/AT claim.','Cropped state images omit surrounding docs; full viewport final image does not cover the entire document.']})
 cases.append({'family':family,'runtime':'react','result':d['result'],'callbackIds':ids,'callbacks':events,'inputCounts':[{'type':k[0],'isTrusted':k[1],'count':v} for k,v in sorted(counts.items())],'untrustedRuntimeTabEvents':untrusted,'pageErrors':d['pageErrors'],'captureErrors':d['captureErrors'],'originalColorPredicatesObservedNotPassed':color,'terminalDOM':{**fact(a/f'{family}-form-terminal-dom.html'),'formCount':len(parsed.forms),'dataDemoRefs':dict(parsed.refs),'inputElementCount':parsed.inputCount,'boundary':'HTML serialization does not preserve every live DOM property; current values separately asserted by Playwright and reflected in AX.'},'terminalAX':fact(a/f'{family}-form-terminal-aria.txt'),'screenshots':len(d['screenshots'])})
assert len(visual)==14 and len(list(a.glob('*.png')))==14
write('visual-review.json',{'at':now(),'sourceHead':r['candidateCommit'],'sourceTree':r['candidateTree'],'images':visual,'actuallyViewedCount':len(visual),'totalPNG':14,'scope':'All 14 current-run original PNG individually viewed; no image synthesis or old-run relabeling. Colors remain observations, not original official visual gate passes.'})
ps=subprocess.run(['ps','-axo','pid=,pgid=,args='],capture_output=True,text=True,check=True)
owned=[]
for line in ps.stdout.splitlines():
 parts=line.strip().split(None,2)
 if len(parts)>=2 and (int(parts[0]) in [r['childPid'],r['runtime']['pid']] or int(parts[1])==r['processGroup']):owned.append(line)
port=r['runtime']['baseUrl'].rsplit(':',1)[1];check=subprocess.run(['lsof','-nP','-iTCP:'+port,'-sTCP:LISTEN'],capture_output=True,text=True)
cleanup={'at':now(),'recordedChildPID':r['childPid'],'recordedWorkerPID':r['runtime']['pid'],'recordedProcessGroup':r['processGroup'],'remainingMatchingProcesses':owned,'port':int(port),'lsofExit':check.returncode,'lsofOutput':check.stdout,'action':'No additional kill needed; test afterAll and owned child completed. No unrelated processes touched.'}
write('process-receipt.json',cleanup)
report={'schemaVersion':1,'kind':'Current Form normal-path native behavior verification','at':now(),'mode':'human-assisted/current-user; advisory/unassessed; partial/ABSTAIN','actualSource':{'head':r['candidateCommit'],'tree':r['candidateTree'],'sourceCleanBeforeAfter':True,'changedInputs':r['sourceByteChanges'],'inputCensusCount':len(before),'historicalExpectedE757ReplacedWithActualC6BeforeRun':True,'browserHarnessDirtyAtTaskAssignmentWasCommittedBeforeRun':True},'run':{'start':r['startedAt'],'end':r['completedAt'],'exit':r['exit'],'files':1,'passed':2,'failed':0,'command':r['command'],'node':r['node'],'pnpm':r['pnpm'],'chrome':r['runtime']['chrome'],'toolchainVersionsActuallyRecorded':True,'macOSLocalNotCI':True,'officialEnvSpoofed':False,'timeoutsSeconds':{'case':120,'startup':180,'cleanup':30,'outer':300},'receipt':fact(o/'receipt.json'),'log':fact(o/'run.log')},'driver':{'originalOfficial':fact(p/'original-official.browser.test.ts'),'privateExecuted':fact(p/'local.browser.test.ts'),'config':fact(p/'local.config.ts'),'demoSource':fact(p/'original-form-demo.ts'),'sameBehaviorAsHistoricalDriver':True,'changesFromHistoricalDriver':'Only current tree metadata value/name; exact normalized byte comparison passes.','originalFormJourneyUnmodifiedButNotRun':True,'actualCallbackModuleOverrides':modules},'completedFlow':['Initial named five-field values and selection','Invalid submit: first editor focus, invalid/error/label ARIA associations, visible required message, no submit callback','Corrected five-field submission','Native quantity increment, code fill and SMS selection followed by second five-field submission','Reset restores controls and clears validation without a submit callback','Invalid submit after reset still emits no submit','Fresh valid submit after reset emits the third current payload'], 'cases':cases,'errors':{'page':0,'console':0,'capture':0,'fixtureWiring':0,'ledger':ledger['errors']},'nativeEventCounts':[{'type':k[0],'isTrusted':k[1],'count':v}for k,v in sorted(allCounts.items())],'nativeInputBoundary':'Playwright dispatched native input events; 2 Runtime tab clicks are untrusted semantic events and are explicitly retained. This is not proof of OS or human input. No keyboard/IME claim.','clockBoundary':'Original fixed HostClock fixture retained. Observer performance/timeOrigin is fixture-clock affected; it is not aligned to Node UTC receipt times and supplies no latency claim.','sourceBinding':fact(p/'observed-source-binding.json'),'visualReview':fact(p/'visual-review.json'),'processCleanup':fact(p/'process-receipt.json'),'visualBoundary':'Both families retain labelEqualsError=false and labelChanged=false during invalid state. They do not pass the original color expectation. All 14 current images viewed; no full visual/AT acceptance.','conclusion':'No new C failure observed in these two complete synchronous React normal flows. Current Context-dependent controls and valid submission/reset behavior completed without page provider errors. This does not diagnose or erase earlier CI failures.','uncovered':['Async validator/cancel/resolve lease','Retirement/unmount/dispose/remount or nested callback mutation','Controlled reset handshake, duplicate names or exception policy','Direct outward invalid/reset event subscriber semantics','Other Adapters, keyboard Enter, IME, assistive technology, dark/narrow, all Finf acceptance'],'sideEffects':'No product source, index, commit or GitHub mutation by this verification. Original historical raw evidence unchanged.'}
write('report.json',report)
md=f'''Form 两组完整正常行为已在准确 clean `{r['candidateCommit']}` / tree `{r['candidateTree']}` 上重新执行：**2/2 pass，exit 0**。实际时间为 **{r['startedAt']} 至 {r['completedAt']}**；Node {r['node']}、pnpm {r['pnpm']}、Chrome {r['runtime']['chrome']} 均在本次记录。任务下发时的 e757 与两份 harness dirty 没有冒充本次来源：开始前它们已提交为 c6a17，本次前后 HEAD/tree/clean 状态一致，{len(before)} 个 tracked census 输入逐一匹配 Git blob，执行期间零字节变化。

Shadcn 与 Brutalist 的真实 React 页面均完成：默认五字段 → 空值提交错误与首个编辑器焦点/ARIA 关联 → 修正提交 → 修改 quantity/code/channels 后再提交 → reset 全部值和 validation → reset 后再次非法提交 → 再次有效提交。每个 family 实际 `onSubmit` ID 为 {cases[0]['callbackIds']}，共六次回调；每个五字段 payload 与当时状态精确匹配。非法提交和 reset 没有额外 submit。页面、console、接线、capture 错误均为零。

这是沿用原私有行为 driver 的**独立行为执行**，保留其原输入、断言、120s case/180s startup/30s cleanup/300s outer 参数；本次只替换来源元数据与路径。真实公共 route/renderer/current source 正常使用，但既有 app-authored `onSubmit` report 前插入旁观记录，仍执行原 status 写入；所以不是未改官方 demo/official visual suite 的通过证明。实际 served JS 原/派生字节与 SHA 均保存。旧官方 `formJourney` 原颜色断言保留在副本中，本次没有执行它，更没有删除或弱化官方断言。

两 family 各 3 次提交为 `Form behavior one`（默认复合值）、`Form behavior two`（quantity 3、code 1234、Email+SMS）、`After reset`（复合值复位）。终态 DOM/AX 的 React selection、表单名、五字段及状态 JSON 已核对。输入缓冲实际共 18 trusted click、18 pointerdown、18 pointerup、8 input、8 change，另有 2 个 Runtime tab 的 untrusted semantic click；不能把它们统称 OS 输入。沿用原固定 HostClock，因此不把浏览器 observer 时钟与 UTC 作性能换算。

**14/14 张本轮原 PNG 已逐张 view_image，未编辑或重编码。** 两 family 的 invalid `labelEqualsError=false`、`labelChanged=false`，可见 required 文本为红而 label 仍深色；这不是颜色验收通过。reset 图中的 status 保留上次提交是原 demo 只在 onSubmit 更新 status，实际控件已复位、没有额外 submit。状态图裁切到 previewer；终态图是 viewport，底部正文/dev toolbar 处于视口边缘，不是 full-page、dark/narrow、AT 或全面视觉验收。

本轮没有观察到新的正常流程 C 失败；没有复现 provider 错误也不能证明旧 CI 根因已关闭。async validation、cancel/resolve、retirement/nested callback、受控 reset、异常策略及其它 Adapter 均未在这两 case 中覆盖。请求 URL 中 {len(requested)}/{len(ledger['requestedPaths'])} 条绑定了实际 tracked 输入；其余 {len(unbound)} 条依赖/生成/虚拟请求原样列出，不冒充完整 bundle 闭包。自有进程组及端口 {port} 已无残留，无额外 kill 或他人进程操作。

原始 [运行收据](run-1/receipt.json)、[报告](report.json)、[视觉逐图收据](visual-review.json)、[实际请求源绑定](observed-source-binding.json)、[清理核对](process-receipt.json) 全部在本新目录；旧 raw 未改。human-assisted / partial / ABSTAIN，无外部批准或发布声明。
'''
(p/'report.md').write_text(md)
print(json.dumps({'report':fact(p/'report.json'),'visual':fact(p/'visual-review.json'),'sourceBinding':fact(p/'observed-source-binding.json'),'process':cleanup,'trackedRequests':len(requested),'unboundRequests':len(unbound)},indent=2))
