Form 两组完整正常行为已在准确 clean `c6a17f849542b450d25aac14fee2b77ba4009aa3` / tree `b904a7417e668872ca7c99d5ad07417fcdd889b9` 上重新执行：**2/2 pass，exit 0**。实际时间为 **2026-10-17T02:29:03.800405+00:00 至 2026-10-17T02:29:19.476662+00:00**；Node v24.21.0、pnpm 10.32.1、Chrome 155.0.8059.80 均在本次记录。任务下发时的 e757 与两份 harness dirty 没有冒充本次来源：开始前它们已提交为 c6a17，本次前后 HEAD/tree/clean 状态一致，6891 个 tracked census 输入逐一匹配 Git blob，执行期间零字节变化。

Shadcn 与 Brutalist 的真实 React 页面均完成：默认五字段 → 空值提交错误与首个编辑器焦点/ARIA 关联 → 修正提交 → 修改 quantity/code/channels 后再提交 → reset 全部值和 validation → reset 后再次非法提交 → 再次有效提交。每个 family 实际 `onSubmit` ID 为 [2, 3, 5]，共六次回调；每个五字段 payload 与当时状态精确匹配。非法提交和 reset 没有额外 submit。页面、console、接线、capture 错误均为零。

这是沿用原私有行为 driver 的**独立行为执行**，保留其原输入、断言、120s case/180s startup/30s cleanup/300s outer 参数；本次只替换来源元数据与路径。真实公共 route/renderer/current source 正常使用，但既有 app-authored `onSubmit` report 前插入旁观记录，仍执行原 status 写入；所以不是未改官方 demo/official visual suite 的通过证明。实际 served JS 原/派生字节与 SHA 均保存。旧官方 `formJourney` 原颜色断言保留在副本中，本次没有执行它，更没有删除或弱化官方断言。

两 family 各 3 次提交为 `Form behavior one`（默认复合值）、`Form behavior two`（quantity 3、code 1234、Email+SMS）、`After reset`（复合值复位）。终态 DOM/AX 的 React selection、表单名、五字段及状态 JSON 已核对。输入缓冲实际共 18 trusted click、18 pointerdown、18 pointerup、8 input、8 change，另有 2 个 Runtime tab 的 untrusted semantic click；不能把它们统称 OS 输入。沿用原固定 HostClock，因此不把浏览器 observer 时钟与 UTC 作性能换算。

**14/14 张本轮原 PNG 已逐张 view_image，未编辑或重编码。** 两 family 的 invalid `labelEqualsError=false`、`labelChanged=false`，可见 required 文本为红而 label 仍深色；这不是颜色验收通过。reset 图中的 status 保留上次提交是原 demo 只在 onSubmit 更新 status，实际控件已复位、没有额外 submit。状态图裁切到 previewer；终态图是 viewport，底部正文/dev toolbar 处于视口边缘，不是 full-page、dark/narrow、AT 或全面视觉验收。

本轮没有观察到新的正常流程 C 失败；没有复现 provider 错误也不能证明旧 CI 根因已关闭。async validation、cancel/resolve、retirement/nested callback、受控 reset、异常策略及其它 Adapter 均未在这两 case 中覆盖。请求 URL 中 744/833 条绑定了实际 tracked 输入；其余 89 条依赖/生成/虚拟请求原样列出，不冒充完整 bundle 闭包。自有进程组及端口 57645 已无残留，无额外 kill 或他人进程操作。

原始 [运行收据](run-1/receipt.json)、[报告](report.json)、[视觉逐图收据](visual-review.json)、[实际请求源绑定](observed-source-binding.json)、[清理核对](process-receipt.json) 全部在本新目录；旧 raw 未改。human-assisted / partial / ABSTAIN，无外部批准或发布声明。
