四份原始 browser 测试文件在 **`d28b17bc04074213c96045fbcb9e7c29c7b1f0ae` / tree `4375791330915298740fbad38f6ddb014028b764`** 上一次执行，**4 files / 74 tests 全通过，exit 0**。时间为 2026-10-17T02:33:34.655127+00:00 至 2026-10-17T02:37:15.917812+00:00，Node v24.21.0、pnpm 10.32.1，单 worker，外层 watchdog 600s 未触发。

| 原始文件 | 实际结果 |
| --- | --- |
| `demo-field-family.browser.test.ts` | 25 pass |
| `demo-collapsible-projections.browser.test.ts` | 36 pass |
| `demo-base-collapsible.browser.test.ts` | 5 pass |
| `overlay-portal-direction.browser.test.ts` | 8 pass |

没有 `-t` 过滤、断言/输入/有效 timeout 修改、重试或额外恢复动作。可选 screenshot/trace 环境均未设置，没有额外截图控制或新图。本次原用例中的四 Adapter 和几何/焦点/lease/重开断言按原文件执行；不将通过扩张成光学、AT 或全面项目验收。

任务分配时指定 c6a17；启动前 root 已提交 d28b17，二者仅 `scripts/test/check-dialog-baseline-evidence.mjs` 的 2hash+comment（3+/3-）有差异。此次实际运行从开始到结束都是 clean d28b17；**11328 个 tracked tree 条目的 mode/kind/blob 与工作字节一致且前后零变化**，四份 original test 字节另有副本及 SHA。Form 两 case 的历史执行仍是 c6a17，只另做 d28 源码复用绑定，不改其时间或 HEAD。

运行分类校正：启动 scope 曾写“共享 docs server”，但该 repo runner 接收显式路径时走 `runtime-test-plan.mjs:330 needsServer=false`。实际是一个 worker 顺序执行，**每份原 suite 自己启动/停止 server**，不是普通完整 browser phase 的共用 server。原启动收据不覆盖，另存 [execution-class-correction.json](execution-class-correction.json) 明确更正。四个实际端口 58238, 58786, 59296, 59542 结束后均无 listener，原 PID/PGID 亦已消失，无额外 kill 或其他会话操作。

本次没有新的失败；此结论只属于这一次 macOS 默认原文件组合，不能抹掉既有 Linux/官方失败或主张全 canonical 通过。没有重跑全量，也没有本 agent 产品、index 或外部写入。完整实际命令、每 case 结果、源码 hash 与边界见 [report.json](report.json)、[原运行收据](receipt.json)、[原日志](run.log)、[Vitest JSON](vitest.json)。human-assisted / partial / ABSTAIN。
