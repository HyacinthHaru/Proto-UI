from pathlib import Path
import subprocess,os,json,datetime,hashlib,signal,re,platform
p=Path(__file__).parent;w=Path('<SOURCE_ROOT>')
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=w,text=True).strip()
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');assert head=='d28b17bc04074213c96045fbcb9e7c29c7b1f0ae' and not git('status','--porcelain=v1')
assert git('diff','--name-only','c6a17f849542b450d25aac14fee2b77ba4009aa3',head)=='scripts/test/check-dialog-baseline-evidence.mjs'
env=os.environ.copy();env['PATH']='<LOCAL_NODE24_BIN>:'+env['PATH']
remove=['GITHUB_ACTIONS','CANDIDATE_SHA','CI','PROTO_UI_BROWSER_BASE_URL','PROTO_UI_RUNTIME_PHASE','PROTO_UI_RUNTIME_SHARD','PROTO_UI_RUNTIME_EVIDENCE_DIR','PROTO_UI_FIELD_SCREENSHOT_DIR','PROTO_UI_COLLAPSIBLE_SCREENSHOT_DIR','PROTO_UI_PORTAL_DIRECTION_SCREENSHOT_DIR','PROTO_UI_COLLAPSIBLE_FOCUS_PATH_DIAGNOSTIC','PROTO_UI_FIELD_ASYNC_TRACE','DEBUG','MATERIAL_EVIDENCE_DIR']
removed={k:env.pop(k) for k in remove if k in env}
# No optional capture/trace environment remains; keep installed default executable selection.
extra=[k for k in env if k.startswith('PROTO_UI_') or k.startswith('PUI_')]
assert not extra,extra
entries=[]
for raw in subprocess.check_output(['git','ls-tree','-r','-z',tree],cwd=w).split(b'\0'):
 if not raw:continue
 meta,name=raw.split(b'\t',1);mode,kind,blob=meta.decode().split();entries.append((name.decode(),mode,kind,blob))
def snapshot():
 rows=[]
 for name,mode,kind,blob in entries:
  f=w/name
  if kind!='blob':rows.append({'path':name,'mode':mode,'kind':kind,'gitBlob':blob,'status':'not a file'});continue
  b=os.readlink(f).encode() if mode=='120000' else f.read_bytes()
  actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
  rows.append({'path':name,'mode':mode,'kind':kind,'gitBlob':blob,'workingBlob':actual,'sha256':sha(b),'bytes':len(b),'matchesCommit':blob==actual})
 return rows
def write(n,x):(p/n).write_text(json.dumps(x,indent=2)+'\n')
before=snapshot();assert all(x.get('matchesCommit',True) for x in before);write('source-before.json',before)
files=['apps/www/src/content/docs/zh-cn/'+n for n in ['demo-field-family.browser.test.ts','demo-base-collapsible.browser.test.ts','demo-collapsible-projections.browser.test.ts','overlay-portal-direction.browser.test.ts']]
originals=p/'original-tests';originals.mkdir(exist_ok=False)
for name in files:(originals/Path(name).name).write_bytes((w/name).read_bytes())
command=['node','scripts/test/run-runtime-tests.mjs','--no-file-parallelism',*files,'--reporter=verbose','--reporter=json','--outputFile='+str(p/'vitest.json'),'--maxWorkers=1','--minWorkers=1']
r={'status':'running','startedAt':now(),'actualHeadBefore':head,'actualTreeBefore':tree,'statusBefore':git('status','--porcelain=v1'),'sourceBeforeSHA256':sha((p/'source-before.json').read_bytes()),'sourceCensusEntries':len(before),'requestedSourceAtAssignment':'c6a17f849542b450d25aac14fee2b77ba4009aa3','actualSourceDifferenceFromAssignment':['scripts/test/check-dialog-baseline-evidence.mjs'],'runtimeInputsUnchangedFromAssignment':True,'command':command,'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'pnpm':subprocess.check_output(['corepack','pnpm@10.32.1','--version'],env=env,text=True).strip(),'platform':platform.platform(),'PATH':env['PATH'],'removedEnvironment':removed,'optionalCaptureAndTrace':'unset; original default path; no extra capture/observer','scope':'Four entire original suites, no test-name filter or assertion/input/timeout modification; one Vitest worker and one shared docs server via repository runner.','outerBudgetSeconds':600,'suiteFiles':[{**next(x for x in before if x['path']==name)} for name in files]}
write('receipt.json',r)
with (p/'run.log').open('w') as log:
 c=subprocess.Popen(command,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r.update(childPID=c.pid,processGroup=c.pid);write('receipt.json',r);print(json.dumps({k:r[k] for k in ['startedAt','actualHeadBefore','actualTreeBefore','childPID','processGroup','sourceCensusEntries','command']}),flush=True)
 try:r['exit']=c.wait(timeout=600)
 except subprocess.TimeoutExpired:
  r['outerWatchdogExpired']=True;os.killpg(c.pid,signal.SIGTERM)
  try:r['exit']=c.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(c.pid,signal.SIGKILL);r['exit']=c.wait(timeout=10)
after=snapshot();write('source-after.json',after);bm={x['path']:x for x in before};am={x['path']:x for x in after}
r.update(status='completed',completedAt=now(),actualHeadAfter=git('rev-parse','HEAD'),actualTreeAfter=git('rev-parse','HEAD^{tree}'),statusAfter=git('status','--porcelain=v1'),sourceAfterSHA256=sha((p/'source-after.json').read_bytes()),sourceByteChanges=[k for k in bm if bm[k]!=am[k]],allAfterMatchStartingCommit=all(x.get('matchesCommit',True)for x in after),logSHA256=sha((p/'run.log').read_bytes()))
text=(p/'run.log').read_text();r['summaryLines']=[s.strip() for s in text.splitlines() if re.search(r'(Test Files|\bTests\s+)',s)]
r['ports']=sorted({int(x)for x in re.findall(r'http://127\.0\.0\.1:(\d+)',text)})
r['listeningAfter']=[]
for port in r['ports']:
 check=subprocess.run(['lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN'],capture_output=True,text=True);r['listeningAfter'].append({'port':port,'exit':check.returncode,'output':check.stdout})
if (p/'vitest.json').exists():r['vitestSHA256']=sha((p/'vitest.json').read_bytes())
write('receipt.json',r);print(json.dumps({k:r.get(k) for k in ['status','completedAt','exit','summaryLines','sourceByteChanges','actualHeadAfter','statusAfter','listeningAfter']}),flush=True)
