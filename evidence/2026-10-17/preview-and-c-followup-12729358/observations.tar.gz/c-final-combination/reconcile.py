from pathlib import Path
import collections,datetime,hashlib,json,subprocess
p=Path(__file__).parent;w=Path('<SOURCE_ROOT>')
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(n,v):(p/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def fact(n):b=(p/n).read_bytes();return {'path':n,'bytes':len(b),'sha256':sha(b)}
r=json.loads((p/'receipt.json').read_text());v=json.loads((p/'vitest.json').read_text());before=json.loads((p/'source-before.json').read_text());after=json.loads((p/'source-after.json').read_text())
assert r['exit']==0 and before==after and r['statusBefore']==r['statusAfter']=='' and r['actualHeadBefore']==r['actualHeadAfter']
assert v['success'] and v['numTotalTests']==v['numPassedTests']==74 and v['numFailedTests']==v['numPendingTests']==v['numTodoTests']==0
assert len(v['testResults'])==4
suites=[]
for suite in v['testResults']:
 rel=str(Path(suite['name']).relative_to(w)); row=next(x for x in before if x['path']==rel); saved=p/'original-tests'/Path(rel).name
 assert row['sha256']==sha(saved.read_bytes()) and suite['status']=='passed'
 suites.append({'path':rel,'gitBlob':row['gitBlob'],'sha256':row['sha256'],'originalTestSnapshot':str(saved.relative_to(p)),'result':suite['status'],'counts':dict(collections.Counter(x['status']for x in suite['assertionResults'])),'firstCaseStartUnixMs':suite['startTime'],'lastCaseEndUnixMs':suite['endTime'],'actualTests':[{'title':x['fullName'],'status':x['status'],'durationMs':x.get('duration'),'failureMessages':x.get('failureMessages',[])}for x in suite['assertionResults']]})
correction={'at':now(),'appliesTo':'receipt.json scope and run.py descriptive string only; actual command unchanged','originalWording':'one Vitest worker and one shared docs server via repository runner','corrected':'One Vitest worker; explicit CLI paths use createRuntimeTestPlan needsServer=false, so each original suite starts and stops its own repository docs server sequentially. No external base URL was configured.','source':{'path':'scripts/test/runtime-test-plan.mjs','line':330,'gitBlob':next(x['gitBlob']for x in before if x['path']=='scripts/test/runtime-test-plan.mjs')},'actualObservedPorts':r['ports'],'originalReceiptPreserved':True,'notNewExecution':True}
write('execution-class-correction.json',correction)
ps=subprocess.run(['ps','-axo','pid=,pgid=,args='],capture_output=True,text=True,check=True);own=[]
for line in ps.stdout.splitlines():
 x=line.strip().split(None,2)
 if len(x)>1 and (int(x[0])==r['childPID'] or int(x[1])==r['processGroup']):own.append(line)
ports=[]
for port in r['ports']:
 q=subprocess.run(['lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN'],capture_output=True,text=True);ports.append({'port':port,'exit':q.returncode,'stdout':q.stdout})
cleanup={'at':now(),'childPID':r['childPID'],'processGroup':r['processGroup'],'remainingOriginalProcessGroup':own,'ports':ports,'action':'No additional signal needed; only exact owned PID/group and ports inspected; unrelated sessions untouched.'}
write('process-receipt.json',cleanup)
report={'schemaVersion':1,'at':now(),'mode':'human-assisted/current-user; advisory/unassessed; partial/ABSTAIN','executionWindow':{'start':r['startedAt'],'end':r['completedAt']},'actualSource':{'head':r['actualHeadBefore'],'tree':r['actualTreeBefore'],'headAndTreeUnchanged':True,'cleanBeforeAfter':True,'trackedTreeEntries':len(before),'trackedByteChanges':[],'trackedModeKindBlobAllMatch':True,'assignmentSource':r['requestedSourceAtAssignment'],'assignmentToExecutionChangedPaths':r['actualSourceDifferenceFromAssignment'],'boundary':'Assignment initially named c6a17. Before this run root committed only the Dialog evidence classifier registration; execution occurred after d28b17 commit. No runtime implementation or these suite bytes changed between those heads.'},'result':{'exit':r['exit'],'testFiles':4,'passed':74,'failed':0,'skipped':0,'todo':0,'fileCounts':[{k:x[k]for k in ['path','counts']}for x in suites],'vitestNestedSuiteCounter':{'numTotalTestSuites':v['numTotalTestSuites'],'meaning':'Vitest JSON includes describe nesting; the original terminal file count is four, not ten.'}},'execution':{'command':r['command'],'node':r['node'],'pnpm':r['pnpm'],'platform':r['platform'],'workerCount':1,'originalTestBytes':True,'testNameFilter':None,'assertionsInputAndTimeoutsUnmodified':True,'outerWatchdogSeconds':600,'optionalCaptureOrTraceEnabled':False,'privateInstrumentationAdded':False,'serverMode':correction['corrected'],'browserVersionBoundary':'The four original default suites did not separately print browser.version in these logs. The earlier independent Form run recorded Chrome 155.0.8059.80; that is not relabeled as a separate version query in this run.'},'suites':suites,'evidence':{n:fact(n)for n in ['receipt.json','run.log','vitest.json','source-before.json','source-after.json','run.py','execution-class-correction.json','process-receipt.json']},'scope':'This local macOS combination validates the four entire current original browser files, including all four Adapters in their named journeys. No extra screenshot/trace control was performed; no new images or visual review are claimed here.','limits':['Not a GitHub canonical/Linux result and does not close independently failing canonical cases.','No full repository test suite, entire project readiness, optical acceptance or AT claim.','Source census binds tracked repository bytes, not all installed dependencies or generated runtime artifacts.','Original test input/geometry policies remain as authored; no new recovery input or increased timeout.','Earlier failures and private diagnostics remain historical evidence unchanged.'],'noNewFailureObserved':True,'productWritesByThisAgent':False,'externalWritesByThisAgent':False}
write('report.json',report)
md=f'''四份原始 browser 测试文件在 **`{r['actualHeadBefore']}` / tree `{r['actualTreeBefore']}`** 上一次执行，**4 files / 74 tests 全通过，exit 0**。时间为 {r['startedAt']} 至 {r['completedAt']}，Node {r['node']}、pnpm {r['pnpm']}，单 worker，外层 watchdog 600s 未触发。

| 原始文件 | 实际结果 |
| --- | --- |
| `demo-field-family.browser.test.ts` | 25 pass |
| `demo-collapsible-projections.browser.test.ts` | 36 pass |
| `demo-base-collapsible.browser.test.ts` | 5 pass |
| `overlay-portal-direction.browser.test.ts` | 8 pass |

没有 `-t` 过滤、断言/输入/有效 timeout 修改、重试或额外恢复动作。可选 screenshot/trace 环境均未设置，没有额外截图控制或新图。本次原用例中的四 Adapter 和几何/焦点/lease/重开断言按原文件执行；不将通过扩张成光学、AT 或全面项目验收。

任务分配时指定 c6a17；启动前 root 已提交 d28b17，二者仅 `scripts/test/check-dialog-baseline-evidence.mjs` 的 2hash+comment（3+/3-）有差异。此次实际运行从开始到结束都是 clean d28b17；**{len(before)} 个 tracked tree 条目的 mode/kind/blob 与工作字节一致且前后零变化**，四份 original test 字节另有副本及 SHA。Form 两 case 的历史执行仍是 c6a17，只另做 d28 源码复用绑定，不改其时间或 HEAD。

运行分类校正：启动 scope 曾写“共享 docs server”，但该 repo runner 接收显式路径时走 `runtime-test-plan.mjs:330 needsServer=false`。实际是一个 worker 顺序执行，**每份原 suite 自己启动/停止 server**，不是普通完整 browser phase 的共用 server。原启动收据不覆盖，另存 [execution-class-correction.json](execution-class-correction.json) 明确更正。四个实际端口 {', '.join(map(str,r['ports']))} 结束后均无 listener，原 PID/PGID 亦已消失，无额外 kill 或其他会话操作。

本次没有新的失败；此结论只属于这一次 macOS 默认原文件组合，不能抹掉既有 Linux/官方失败或主张全 canonical 通过。没有重跑全量，也没有本 agent 产品、index 或外部写入。完整实际命令、每 case 结果、源码 hash 与边界见 [report.json](report.json)、[原运行收据](receipt.json)、[原日志](run.log)、[Vitest JSON](vitest.json)。human-assisted / partial / ABSTAIN。
'''
(p/'report.md').write_text(md)
print(json.dumps({'report':fact('report.json'),'markdown':fact('report.md'),'correction':fact('execution-class-correction.json'),'process':cleanup},indent=2))
