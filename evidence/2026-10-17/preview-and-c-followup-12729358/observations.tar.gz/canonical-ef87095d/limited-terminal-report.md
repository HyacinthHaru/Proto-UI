准确 EF 的有限 canonical 跟进已完成，结论仍为 **partial/ABSTAIN**。只读采集进程自然 exit 0；未 rerun、cancel 或 dispatch Actions，未运行新本地测试。

head `ef87095d07736a5bf3cf6355c39ff9904e152582`，tree `c42242dfb1b308ddbdeabbd30408a94efb281d6f`。type/package/ordinary shard 5 实际 checkout `9803bb0d7b9c0bb19821ff8a68059b44f0204100`，Git 对象 tree 精确相同；专项直接 checkout EF。

最关键的新证据：ordinary shard 5 的 `overlay-scrollbar-geometry.browser.test.ts` 原完整 **16/16 passed**，04:39:28 原日志 line 716，83,262 ms。其中为明确的 Brutalist popper Select 8 项和原 Dialog 8 项。未修改的 classic > 0、geometry、nested scroll 和 timeout 断言已实际通过；具体滚动条宽度没有输出，不捏造数值，也不将这 8 项重新称为 Shadcn item-aligned 的五状态覆盖。

整个 shard 5 仍为 **71 passed / 18 failed / 15 skipped**，共 104 tests；files 为 5 passed / 4 failed / 1 skipped。残留分别为 colorScheme 8、Liquid Collapsible 窄屏 geometry 4、RadioGroup 4、Shadow S5 两 locale 初始 previewer readiness 2。Shadow 两项停在 line 29 的原 60s wait，尚未进入 editing 旅程。ColorScheme 四 lifetime cases 在 paint alpha 断言停住，不能把后续 lifetime identity 断言当作已执行。当前 18 个失败标题都曾出现在 0d4 shard 5；这只是标题对比，不是继承原因证明或免验。

Types：934 files / 0 errors / 0 warnings / 14 hints。Package：实际 47/47 builds、47 manifests；九预算 **4 PASS + 5 ADVISORY**，gzip 尺寸、minified 尺寸和 SHA 与 96/0d4 对账相同。Linux x64 / Node 24.21.0 / zlib 1.3.2.1-motley-8002e91 / esbuild 0.25.12 是记录的工具链与平台，不称完整环境等同。

EF 专项原日志另已冻结：Runtime 主 14 + production retry 6；Select alignment/group 12；Portal 8；Field 25；Dialog candidate 8 均通过。Dialog historical control 是保留 7 geometry failures + 1 not-offered 的严格分类成功。Collapsible 原 36 仍 32/4（320.4375 > 320），后置 8 focus 诊断不抵消原红；Forms 原 12 仍 10/2 label-color。本轮未下载新的 Forms artifact，pageErrors/captureErrors 数组不借用旧头。

General 仍在 Vitest 前被 check:public-docs 的 78 条有序诊断阻断，已独立逐条等同 0d4。最后有限快照 mainCI 仍 in_progress、可见 21 jobs；没有收集其余 7 个 ordinary shard 或宣称全 22-job 全局终态。0d4 与取消的 96 原始结果保持各自来源。
