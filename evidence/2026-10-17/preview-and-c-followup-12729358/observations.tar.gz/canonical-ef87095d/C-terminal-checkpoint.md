EF 已完成专项与类型/文档前置门禁的只读对账，结论维持 **partial/ABSTAIN**。这是所列终态 job 的独立原日志核对，不是整个新 head 的全 CI 通过或 GitHub 批准。

准确 head `ef87095d07736a5bf3cf6355c39ff9904e152582`，tree `c42242dfb1b308ddbdeabbd30408a94efb281d6f`。专项直接 checkout EF；type/general 实际 checkout `9803bb0d7b9c0bb19821ff8a68059b44f0204100`，GitHub Git commit 对象的 tree 与 EF 精确相同。历史 Dialog baseline 的 subject 明确保留 `15d864de`，只其 probe closure 来自 EF。

| 范围 | 实际终态 | 限界 |
|---|---|---|
| Runtime layout/mask/Accordion | 3 files / 14 passed | 单独 production retry 另 6 passed |
| Select alignment/group | 2 files / 12 passed | 原专项范围 |
| Portal | 8 passed | 原专项范围 |
| Field | 25 passed | 3 个 Liquid runtime 有专属 async trace；其余 22 无该 trace |
| Collapsible | 原 36：32 passed / 4 failed | 4 项均为 Liquid 窄屏 200% 的 320.4375 > 320；后置诊断 8 passed / 36 filtered 不加回原 36 |
| Dialog historical control | 严格原 classifier 成功 | 3 inset + 4 Title geometry failures + 1 not-offered，不能称 baseline 8 journeys 通过 |
| Dialog candidate | 8 passed | 准确 EF candidate |
| Finf Forms job | 10 passed / 2 failed | Shadcn / Brutalist label-color；本轮未读 artifact 的 pageErrors/captureErrors |
| Types | 934 files / 0 errors / 0 warnings / 14 hints | 准确合成 checkout 同树 |
| General | check:public-docs 78 diagnostics，pre-Vitest exit 1 | 与 0d4 原 78 条逐条有序相等；不等于 general 测试已跑 |

这些日志打印 Ubuntu 24.04、Node 24.21.0，pnpm 10.32.1。当前 Chrome 实际版本没有在所审原日志中打印，保留未知，不借用旧头或本机版本。没有重新运行测试、Actions 或浏览器，没有下载新的图片和 trace 包。此检查点冻结，后到 package 和 ordinary shard 5 将另写增补。
