from pathlib import Path
import subprocess,json,hashlib,os,datetime
p=Path(__file__).parent;w=Path('<SOURCE_ROOT>');src='apps/www/src/content/docs/zh-cn/runtime-loading-mask.browser.test.ts';original=(w/src).read_text();(p/'original-runtime-mask.test.ts').write_text(original)
helpers=original[original.index('async function choose('):original.index('async function capture(')]
body=r'''// @vitest-environment node
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import type { Browser, Page } from 'playwright-core';
import { afterAll, beforeAll, expect, it } from 'vitest';
import { launchBrowser, startServer, stopServer } from './browser-harness';
import { revealHeaderPreferences } from './site-header-browser';
let browser: Browser;
let baseUrl: string;
const output = process.env.PUI_RUNTIME_MASK_EVIDENCE_DIR!;
beforeAll(async () => { await mkdir(output, { recursive: true }); baseUrl = await startServer('/en/'); browser = await launchBrowser(); }, 150_000);
afterAll(async () => { await browser?.close(); await stopServer(); }, 60_000);
'''+helpers+r'''
async function snapshot(page: Page) {
  return page.evaluate(() => {
    const attrs = (element: Element) => Object.fromEntries(Array.from(element.attributes).map((attribute) => [attribute.name, attribute.value]));
    const read = (element: Element | null) => {
      if (!element) return null;
      const el = element as HTMLElement;
      const css = getComputedStyle(el);
      let exposed: unknown = { unavailableOnDOM: true };
      if (typeof (el as any).getExposes === 'function') {
        try {
          const handles = (el as any).getExposes(); const values: Record<string, unknown> = {};
          for (const key of ['open', 'value', 'alignmentDiagnostic', 'transitionState', 'isPresent']) if (typeof handles[key]?.get === 'function') values[key] = handles[key].get();
          exposed = values;
        } catch (error) { exposed = { readError: String(error) }; }
      }
      return { tag: el.tagName, id: el.id, attrs: attrs(el), text: el.textContent?.slice(0, 800), connected: el.isConnected, rect: el.getBoundingClientRect().toJSON(), layout: { offsetLeft: el.offsetLeft, offsetTop: el.offsetTop, offsetWidth: el.offsetWidth, offsetHeight: el.offsetHeight, clientLeft: el.clientLeft, clientTop: el.clientTop, clientWidth: el.clientWidth, clientHeight: el.clientHeight, scrollLeft: el.scrollLeft, scrollTop: el.scrollTop }, paint: { display: css.display, visibility: css.visibility, opacity: css.opacity, transform: css.transform, transformOrigin: css.transformOrigin, scale: css.scale, animationName: css.animationName, animationDuration: css.animationDuration, transitionProperty: css.transitionProperty, transitionDuration: css.transitionDuration }, parent: el.parentElement ? { tag: el.parentElement.tagName, attrs: attrs(el.parentElement) } : null, exposed };
    };
    const owner = document.querySelector('[data-homepage-runtime]');
    const control = document.querySelector('[data-homepage-runtime] [data-projection-generation-state="active"] [data-projection-control="runtime"]');
    const trigger = control?.querySelector('[role="combobox"]') ?? null;
    const root = control?.querySelector('[data-projection-prototype$="-select-root"]') ?? null;
    const id = trigger?.getAttribute('aria-controls');
    const content = id ? document.getElementById(id) : null;
    const surface = content?.querySelector('[data-projection-prototype$="-select-surface"]') ?? null;
    const viewport = content?.querySelector('[data-projection-prototype$="-select-viewport"]') ?? null;
    return { at: performance.now(), timeOrigin: performance.timeOrigin, url: location.href, viewport: { width: innerWidth, height: innerHeight, devicePixelRatio }, rootFont: getComputedStyle(document.documentElement).fontSize, dark: document.documentElement.classList.contains('dark'), owner: read(owner), root: read(root), trigger: read(trigger), content: read(content), surface: read(surface), scrollport: read(viewport), options: Array.from(content?.querySelectorAll('[role="option"]') ?? []).map(read), active: read(document.activeElement), demo: read(document.querySelector('[data-home-showcase]')) };
  });
}
it('shows the real enlarged compact Runtime popup and commits React', async () => {
  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, colorScheme: 'dark', reducedMotion: 'reduce' });
  const errors: unknown[] = []; const failedRequests: unknown[] = []; const actions: unknown[] = []; const captures: unknown[] = [];
  let stage = 'setup'; let result = 'running'; let failure: unknown = null;
  page.on('pageerror', (error) => errors.push({ kind: 'pageerror', stage, at: new Date().toISOString(), name: error.name, message: error.message, stack: error.stack }));
  page.on('console', (message) => { if (message.type() === 'error') errors.push({ kind: 'console.error', stage, at: new Date().toISOString(), text: message.text(), location: message.location() }); });
  page.on('requestfailed', (request) => failedRequests.push({ stage, at: new Date().toISOString(), url: request.url(), failure: request.failure() }));
  const capture = async (name: string) => {
    const facts = await snapshot(page);
    await writeFile(path.join(output, name + '.json'), JSON.stringify(facts, null, 2) + '\n');
    await writeFile(path.join(output, name + '-dom.html'), await page.content());
    await writeFile(path.join(output, name + '-aria.txt'), await page.locator('body').ariaSnapshot());
    await page.screenshot({ path: path.join(output, name + '.png'), fullPage: false });
    captures.push({ name, at: new Date().toISOString(), facts });
    return facts;
  };
  try {
    await setup(page, 'shadcn', 'dark');
    await page.evaluate(() => { document.documentElement.style.fontSize = '200%'; });
    stage = 'reveal-compact-preferences';
    await revealHeaderPreferences(page);
    const trigger = page.locator('[data-homepage-runtime] [data-projection-generation-state="active"] [data-projection-control="runtime"] [role="combobox"]');
    stage = 'open-runtime';
    actions.push({ action: 'trigger.click()', startedAt: new Date().toISOString() });
    await trigger.click();
    const id = await trigger.getAttribute('aria-controls'); expect(id).toBeTruthy();
    const option = page.locator(`[id=${JSON.stringify(id)}]`).getByRole('option', { name: 'React', exact: true });
    await option.waitFor({ state: 'visible' });
    stage = 'normal-hover-visible-option';
    await option.hover();
    actions.push({ action: 'React option.waitFor(visible) then normal hover()', completedAt: new Date().toISOString() });
    const shown = await capture('runtime-popup-visible');
    expect(shown.trigger?.attrs['aria-expanded']).toBe('true');
    expect(shown.options.some((entry) => entry?.text?.trim() === 'React')).toBe(true);
    stage = 'click-react';
    actions.push({ action: 'React option.click()', startedAt: new Date().toISOString() });
    await option.click();
    await ready(page, 'react', 'shadcn');
    actions.push({ action: 'real owner and demo ready(react, shadcn)', completedAt: new Date().toISOString() });
    stage = 'committed-react';
    const committed = await capture('react-committed-ready');
    expect(committed.owner?.attrs['data-runtime']).toBe('react');
    expect(committed.demo?.attrs['data-runner-runtime']).toBe('react');
    expect(committed.demo?.attrs['data-runner-state']).toBe('ready');
    result = 'passed';
  } catch (error) {
    result = 'failed'; failure = { name: (error as Error).name, message: (error as Error).message, stack: (error as Error).stack };
    try { await capture('failure'); } catch (captureError) { errors.push({ kind: 'capture', error: String(captureError) }); }
    throw error;
  } finally {
    await writeFile(path.join(output, 'journey.json'), JSON.stringify({ result, failure, stage, actions, errors, failedRequests, captures, browser: browser.version(), node: process.version, scope: 'Independent public popup visibility and commit control, copied current mask setup/ready helpers plus real revealHeaderPreferences. Real native Playwright pointer actions without force; app source unmodified. Explicit localStorage WC/dark and 200% document font are the original authored setup inputs. No network delay/failure injection, callback override, private app flag, first-visible-frame or full optical/AT claim.' }, null, 2) + '\n');
    await page.close();
  }
}, 90_000);
'''
(p/'local.browser.test.ts').write_text(body)
config=(p.parent/'form-final/local.config.ts').read_text().replace(str(p.parent/'form-final/local.browser.test.ts'),str(p/'local.browser.test.ts')).replace('PUI_FINF_FEATURE_EVIDENCE_DIR','PUI_RUNTIME_MASK_EVIDENCE_DIR').replace('explicit-private-local-form-diagnostic','private-public-runtime-popup-control').replace('finf-representative-features.browser.test.ts','runtime-loading-mask.browser.test.ts');(p/'local.config.ts').write_text(config)
env=os.environ.copy();env['PATH']='<LOCAL_NODE24_BIN>:'+env['PATH'];subprocess.run(['corepack','pnpm@10.32.1','exec','prettier','--config',str(w/'.prettierrc'),'--write',str(p/'local.browser.test.ts'),str(p/'local.config.ts')],cwd=w,env=env,check=True)
files=[src,'apps/www/src/content/docs/zh-cn/site-header-browser.ts','apps/www/src/content/docs/zh-cn/browser-harness.ts','packages/modules/positioning/src/web/target-alignment-host.ts'];sha=lambda b:hashlib.sha256(b).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=w,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=w,text=True),'sources':[{'path':f,'sha256':sha((w/f).read_bytes()),'gitBlob':subprocess.check_output(['git','rev-parse','HEAD:'+f],cwd=w,text=True).strip()}for f in files],'privateFiles':[{'path':f,'sha256':sha((p/f).read_bytes())}for f in ['prepare.py','local.browser.test.ts','local.config.ts','original-runtime-mask.test.ts']],'copiedHelpersExact':helpers in body,'noProductWrites':True};(p/'preparation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
