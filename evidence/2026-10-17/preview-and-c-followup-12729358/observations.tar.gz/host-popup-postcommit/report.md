准确提交0d4dae3223db7d1f6c36e7e5fb82c9ba866c9035/tree395404c2221a9093811971f2ba0ab7c9337deb26上的一次独立可见popup控制已通过，1pass/exit0，03:33:14.591–03:33:27.178UTC；11,328个tracked输入前后与Git一致、worktree clean。私有driver仅复用当前原mask的choose/ready/setup原函数及实际browser-harness/revealHeaderPreferences，产品源码与callback未注入。

390×844、dark、200%字号（实读32px）、reduce。真实Header菜单→点击Runtime Trigger→等React option可见→normal hover→第一张fullviewport原图。此时Root公开open=true/value=wc；Content open=true、isPresent=true、transitionState=entered、alignmentDiagnostic空。四个option标签都可见，React hover rect为x50/y633/w297.4375/h64，完全在viewport内。Surface实际paint transform=matrix(1,0,0,1,0,0)、animationName=pui-enter/0.15s；实际BCR width315.4375与CSSOM offsetWidth315分别原样记录，没有声称消除浏览器layout小数。

随后normal click React，原ready谓词确认Header及demo均runtime=react、generation2、ready，第二张图显示真实React Trigger且popup关闭。React DOM不提供getExposes时明确记录不可用，没有套用WC getter。浏览器无pageerror/failed-request，保留一条React hreflang→hrefLang console warning，不写error-free。

2/2 PNG已逐张view，未编辑/重拍。第一图确实可见popup；第二图的主demo仍被compact Header覆盖，实际commit由原ready与DOM属性另行证明。下方Page library/DevToolbar受viewport裁切。hover后的entered图不是first-visible-frame或全光学/AT验收。

原JSON的dark=false只采集了.dark class；保存HTML实际data-theme=dark、color-scheme:dark，源码字段含义在wrapper明确而不改raw。完整源/脚本SHA、命令、phase/paint/layout、DOM/AX/PNG与错误见report.json及visual-review.json。port65407与自有PGID已结束，无product/GitHub写入；human-assisted partial/ABSTAIN。
