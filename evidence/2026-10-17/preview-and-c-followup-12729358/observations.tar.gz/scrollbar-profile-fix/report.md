单文件最终候选已留下，SHA8fc15390ec8f76550295533217d918762854c435acc3c93afde7a95d59aaa7ae。实际physical0d4/tree395404+仅overlay-scrollbar-geometry.browser.test.ts dirty，production不变。原CI8Select的gap43红及首候选1237的14环境+2动画中宽度红完整保留。

改动使用真实Header family combobox/Brutalist option，等待实际Homepage与demo同runtime/familyready；case名明确Brutalist popper。该消费者实际align=start且w/min-w来自anchor，新增resolvedstart与严格等宽断言，不能谎称distinctcenter。原center-collision公式、gap4、1px、4Runtime×2dir×5state、scroll前置、90s、Chrome flags和后8Dialog函数字节均保留。

第二次也是最后一次本地完整16执行：04:00:49.325–04:01:45.498UTC，exit1/16fail，全部第一失败现在是classic scrollbar实际0（8Select+8Dialog）。**并非16通过。** 40/40 Select实际Brutalist/start/250=250，已逐组执行原几何期待并通过gap4/collisionDelta0/固定portal条件，才到classic前置红。nested-after均实录scrollTop48，但其显式比较位于classic之后并未执行；Dialog也不声称后续三个补偿场景全部通过。

React首轮classic样本仍有0.987scale与宽246.76，第二候选仅把原settled从loop前移到每个state的pair前，复用原动画predicate/defaultpoll，不是sleep或等数值变绿。当前40样本均稳定，仍保留所有classic红等待Ubuntu ordinary shard5自然执行，未改系统、断言或发Actions操作。

本轮capture是原optional evidence环境的明确capture-enabled本地控制，56PNG只实际view3（WC/ltr none、React/ltr classic、React/rtl classic），余53未视审；首轮另3/56，图未改/重拍。全部11328tracked工作字节执行前后不变，自有PID98567与port51693已结束。无commit/push或其它source/spec编辑。report.json包含命令、两版来源、firstfailure分类、40真实facts、图SHA及未执行边界。human-assisted partial/ABSTAIN。
