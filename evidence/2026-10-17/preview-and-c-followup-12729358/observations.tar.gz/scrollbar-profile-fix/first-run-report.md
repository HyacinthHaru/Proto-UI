第一版单文件profile候选已完成一次原完整16（capture-enabled原选项），03:56:04–03:57:00UTC，exit1/16fail；physical0d4+唯一test1237acb2 dirty，11328tracked前后相同，自有port51036已结束。原CI8Select的gap43红与originaltest0d03ab54已保留。

候选通过真实Header选择Brutalist并等待实际Homepage/demo同runtime+familyready；原4Runtime×2direction×5state、gap4/1px、scroll前置、90s以及后8Dialog函数全部保留。实测40个Select样本均family=brutalist、resolvedalign=start，38/40严格等宽250、gap4且collisionDelta0。该消费者是start等宽，不能称独立center对齐测试或继续覆盖Shadcn item-aligned。

不能称16项都只有环境红：6Select+8Dialog共14项停classicScrollbar实际0；React两Select先在classic样本严格宽度断言红，popup246.769/246.759而anchor250，matrix scale≈.987/translateY≈−2.07，gap≈2.7076/2.7038。随后restored/nested采样回250/gap4，但这两case的assertion循环没有执行到后续样本。

根因边界是原settled只在五state循环之前调用；React classic测到了实际动画中paint。最小建议是仅把同一settled调用移至每个state的pair前，保持原predicate/timeout，没有数值poll-to-green、sleep或放宽几何。此建议尚未应用或再次运行，本次原红不覆盖。

56张原PNG中只实际view3（WC/ltr none、React/ltr classic、React/rtl classic），其余53未评估。图为数值采样之后的viewport，不能当精确同瞬间几何；React样本确有半透明paint。所有输出与SHA见first-run-report.json/visual-review-first.json。无production/spec/系统设置/外部写入，partial/ABSTAIN。
