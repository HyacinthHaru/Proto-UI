最终两路径 working candidate 已读回，**0 个剩余具体 finding；首版 P2 `PR901-HOMEPAGE-PRESS-ORACLE-001` 已修正**。报告为 human-assisted / unassessed / partial / ABSTAIN，不代表 GitHub approval 或尚未执行的 native 测试通过。

准确绑定：

- `prototype-projection-scope.browser.test.ts` SHA256 `a5312037e3b5619fc4b480e7c84fcefbf373d2d63b192c1b8ccae0507c7db0ec`，Git blob `fe63828a8c2dc04a59bee7eb0c7c3968e3145d31`。
- `P-SHADCN-SELECT-TRIGGER.yaml` SHA256 `2b8b448e20db817db80457aa4e6366f79cc5fdc216d0eee8810dee30b51edee4`，Git blob `6ac4b9049c4a4d3f91529927ee0fdd3cc17f46ce`。

Shadcn inventory严格补ItemText3/Surface1/Viewport1与unique40，Brutalist原值保持；没有用实际DOM反向生成期望，全部原coordinate、owner、portal与后续journey断言保留。原文件仍为**5个cases**，所有显式timeout表达式逐项相同。

两个pressed几何检查现在均与当前draft P/T的default无位移一致。后半段原`data-pressed=true`等待、10000ms、precision3、x不变、finally mouse.up及released=false验证全部保留；因此没有只靠立即为真的negative token检查冒充真实pressed期间几何。首版遗漏的Shadcn+1px及旧注释已更正，首版report/receipt保留。

P文件仅97–98两行双语openQuestion的现行说明变化；criteria、draft status、历史revisions均逐字保持。原历史采用1px的revision不删除，不伪造语义新版本，也不将draft升格。此方案依据明确现行P/T和已声明的合法composition，未修改生产Runtime/Adapter/Select行为。

本次仅只读源码/差异核验，没有执行浏览器或测试。原完整5case native执行仍由root完成；后续原断言若暴露新失败，应继续保留，不得以本静态0finding替代执行结果。
