from pathlib import Path
from datetime import datetime,timezone
import subprocess,os,json,hashlib,re,time
W=Path('<SOURCE_ROOT>');R=Path('<PRIVATE_STATE>/continue-20261017T005751Z/c-diagnostics/portal-native-candidate');H='ba50383230a3ca63da2bc0ae099276cb5226330b'
def now():return datetime.now(timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=W)
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def source():
 head=git('rev-parse','HEAD').decode().strip();assert head==H
 status=git('status','--porcelain','--untracked-files=all').decode();dirty=[]
 for line in status.splitlines():
  p=line[3:];f=W/p
  if f.is_file():
   b=f.read_bytes();dirty.append({'status':line[:2],'path':p,'sha256':sha(b),'bytes':len(b),'gitBlob':sha(b'') if False else hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
 paths=['apps/www/src/content/docs/zh-cn/dialog-available-space.browser.test.ts','apps/www/src/content/docs/zh-cn/overlay-portal-direction.browser.test.ts','packages/modules/overlay/src/impl.ts','packages/prototypes/base/src/select/content.proto.ts','packages/prototypes/base/src/select/alignment-controller.ts','packages/prototypes/base/src/field/root.proto.ts','packages/prototypes/base/src/form/root.proto.ts','pnpm-lock.yaml']
 fixed=[]
 for p in paths:
  b=(W/p).read_bytes();base=git('show',H+':'+p);assert b==base,p
  fixed.append({'path':p,'sha256':sha(b),'gitBlob':git('rev-parse',H+':'+p).decode().strip(),'equals404':True})
 return {'head':head,'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'status':status,'dirtyOrUntrackedFiles':dirty,'fixedInputs':fixed,'baseTreeEntriesSHA256':sha(git('ls-tree','-r','-z','HEAD')),'bindingBoundary':'PhysicalHEADba503 plus one Select alignment lifecycle source change and one new integration test; preview/Dialog are committedbase; not a committedCcandidate. Node_modules/ignoredgeneratedruntimeinputs are not independently content-bound.'}
env=os.environ.copy();env['PATH']='<LOCAL_NODE24_BIN>:'+env.get('PATH','')
removed={}
for k in list(env):
 if k.startswith(('PROTO_UI_','MATERIAL_')) or k in ['GITHUB_ACTIONS','CANDIDATE_SHA','DEBUG']:
  removed[k]=env.pop(k)
envnote={'at':now(),'node':subprocess.check_output(['node','--version'],env=env,cwd=W,text=True).strip(),'pnpm':subprocess.check_output(['corepack','pnpm@10.32.1','--version'],env=env,cwd=W,text=True).strip(),'platform':os.uname().sysname,'machine':os.uname().machine,'PATH':env['PATH'],'removedEnvironmentKeys':sorted(removed),'workerCount':1,'sourceObservationOnly':True,'captures':'Original optional capture environment unset. No private instrumentation, added listener or pre-action sampler.'}
write(R/'environment.json',envnote)
initial=source();write(R/'source-initial.json',initial)
assert len(initial['dirtyOrUntrackedFiles'])==2,initial['status']
for d in initial['dirtyOrUntrackedFiles']:
 p=R/'preview-inputs'/d['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((W/d['path']).read_bytes())
base=['node','scripts/test/run-runtime-tests.mjs','--no-file-parallelism']
plans=[('portal-direction-all8',base+['apps/www/src/content/docs/zh-cn/overlay-portal-direction.browser.test.ts','--reporter=verbose','--maxWorkers=1','--minWorkers=1'])]
receipts=[]
for name,cmd in plans:
 out=R/name;out.mkdir(exist_ok=False);before=source();write(out/'source-before.json',before)
 if before!=initial:raise RuntimeError('Source changed before requested run; no second run launched')
 started=now();receipt={'status':'running','startedAt':started,'command':cmd,'cwd':str(W),'sourceBeforeSHA256':sha((out/'source-before.json').read_bytes()),'sourceHead':H,'sourceDirty':True,'scope':'Original portaltest/config/input/predicates/timeouts, all8cases no-t, no capture/observer; localMac ba503 plus source-bound Ccandidate.'}
 with (out/'run.log').open('wb') as log:
  p=subprocess.Popen(cmd,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);receipt['pid']=p.pid;receipt['processGroup']=p.pid;write(out/'receipt.json',receipt);print(json.dumps({'started':name,'pid':p.pid,'at':started}),flush=True)
  try:code=p.wait(timeout=1200)
  except subprocess.TimeoutExpired:
   receipt.update({'status':'external-bound-reached','endedAt':now(),'externalBoundSeconds':1200,'processMayBeRunning':True});write(out/'receipt.json',receipt);raise
 after=source();write(out/'source-after.json',after);raw=(out/'run.log').read_bytes();text=re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',raw.decode(errors='replace'))
 receipt.update({'status':'completed','endedAt':now(),'exitCode':code,'logSHA256':sha(raw),'logBytes':len(raw),'sourceAfterSHA256':sha((out/'source-after.json').read_bytes()),'sourceUnchanged':before==after,'testSummary':[s.strip() for s in text.splitlines() if re.search(r'^\s*(Test Files|Tests)\s',s)],'filteredBoundary':'All8originalportal cases; no filters, no altered predicates/timeouts/input.'})
 write(out/'receipt.json',receipt);receipts.append(receipt);print(json.dumps({'completed':name,'exitCode':code,'summary':receipt['testSummary'],'sourceUnchanged':before==after}),flush=True)
 if before!=after:raise RuntimeError('Source changed during run; retain evidence and stop before next run')
write(R/'pair-receipt.json',{'at':now(),'runs':receipts,'environmentSHA256':sha((R/'environment.json').read_bytes()),'allRequestedProcessesTerminal':True,'sourceUnchanged':source()==initial,'runDoesNotEditProduct':True})
