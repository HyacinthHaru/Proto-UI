from pathlib import Path
from datetime import datetime,timezone
import subprocess,os,json,hashlib,difflib,re
W=Path('<SOURCE_ROOT>');R=Path(__file__).parent;rel='apps/www/src/content/docs/zh-cn/overlay-portal-direction.browser.test.ts';F=W/rel
sha=lambda b:hashlib.sha256(b).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=W)
def inputs():
 rows=[]
 for line in git('status','--porcelain','--untracked-files=all').decode().splitlines():
  p=line[3:];f=W/p
  if f.is_file():rows.append({'path':p,'status':line[:2],'sha256':sha(f.read_bytes())})
 return rows
original=F.read_bytes();assert original==git('show','404a7417ef8dc22c8c7fe6d9ff9f3c8a5d40a17b:'+rel)
s=original.decode();old="        await reopened.waitFor({ state: 'visible' });"
new="""        try {
          await reopened.waitFor({ state: 'visible' });
        } catch (error) {
          phaseTimes.push({ phase: 'reopened-visible-rejected', nodeMs: performance.now(), nodeUTC: new Date().toISOString() });
          try {
            const facts = await page.evaluate(() => {
              const info = (n: Element) => {
                const st = getComputedStyle(n);
                const ancestor = [];
                for (let p = n.parentElement; p && ancestor.length < 6; p = p.parentElement) ancestor.push({ tag: p.tagName, attrs: Object.fromEntries(Array.from(p.attributes).map((a) => [a.name, a.value])), display: getComputedStyle(p).display, inert: (p as HTMLElement).inert });
                return { tag: n.tagName, attrs: Object.fromEntries(Array.from(n.attributes).map((a) => [a.name, a.value])), connected: n.isConnected, bodyContains: document.body.contains(n), inert: (n as HTMLElement).inert, hidden: (n as HTMLElement).hidden, rect: n.getBoundingClientRect().toJSON(), display: st.display, visibility: st.visibility, opacity: st.opacity, pointerEvents: st.pointerEvents, transform: st.transform, ancestor };
              };
              const anchors = Array.from(document.querySelectorAll('[data-demo-ref="settings-view-trigger"]'));
              const ids = anchors.map((a) => a.getAttribute('aria-controls')).filter((id): id is string => !!id);
              return { pageUTC: new Date().toISOString(), pageMs: performance.now(), anchors: anchors.map(info), controlled: ids.map((id) => ({ id, matches: Array.from(document.querySelectorAll(`[id=${JSON.stringify(id)}]`)).map(info) })), listboxes: Array.from(document.querySelectorAll('[role="listbox"]')).map(info), portalContainers: Array.from(document.querySelectorAll('[data-pui-portal-mount]')).map(info), activeElement: document.activeElement ? info(document.activeElement) : null, viewport: { width: innerWidth, height: innerHeight } };
            });
            const dir = process.env.PROTO_UI_PORTAL_OBSERVATION_DIR!;
            await mkdir(dir, { recursive: true });
            await writeFile(path.join(dir, 'facts.json'), JSON.stringify({ atNode: new Date().toISOString(), runtime, bodyDirection, phaseTimes, originalSamples: observations, facts }, null, 2));
            await page.screenshot({ path: path.join(dir, 'failure.png') });
            await writeFile(path.join(dir, 'page.html'), await page.content());
          } catch (observationError) { console.error('[portal observation error]', observationError); }
          throw error;
        }"""
assert s.count(old)==1;s=s.replace(old,new)
oldpage="      const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });"
assert s.count(oldpage)==1;s=s.replace(oldpage,oldpage+"\n      const phaseTimes: { phase: string; nodeMs: number; nodeUTC: string }[] = [];")
oldseq="""        await page.keyboard.press('Escape');
        await popup.waitFor({ state: 'hidden' });
        await anchor.click();"""
newseq="""        phaseTimes.push({ phase: 'close-start', nodeMs: performance.now(), nodeUTC: new Date().toISOString() });
        await page.keyboard.press('Escape');
        phaseTimes.push({ phase: 'escape-returned', nodeMs: performance.now(), nodeUTC: new Date().toISOString() });
        await popup.waitFor({ state: 'hidden' });
        phaseTimes.push({ phase: 'popup-hidden-returned', nodeMs: performance.now(), nodeUTC: new Date().toISOString() });
        await anchor.click();
        phaseTimes.push({ phase: 'reopen-click-returned', nodeMs: performance.now(), nodeUTC: new Date().toISOString() });"""
assert s.count(oldseq)==1;s=s.replace(oldseq,newseq);derived=s.encode();(R/'original.test.ts').write_bytes(original);(R/'diagnostic.test.ts').write_bytes(derived);(R/'diagnostic.patch').write_text(''.join(difflib.unified_diff(original.decode().splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
env=os.environ.copy();env['PATH']='<LOCAL_NODE24_BIN>:'+env.get('PATH','')
for k in list(env):
 if k.startswith(('PROTO_UI_','MATERIAL_')) or k in ['GITHUB_ACTIONS','CANDIDATE_SHA','DEBUG']:env.pop(k)
env['PROTO_UI_PORTAL_OBSERVATION_DIR']=str(R/'artifacts')
cmd=['node','scripts/test/run-runtime-tests.mjs','--no-file-parallelism',rel,'--reporter=verbose','--maxWorkers=1','--minWorkers=1','-t','^react/ltr:']
rec={'startedAt':now(),'status':'preparing','head':git('rev-parse','HEAD').decode().strip(),'inputsBefore':inputs(),'command':cmd,'originalTestSHA256':sha(original),'diagnosticTestSHA256':sha(derived),'sourceBoundary':'404 plus root preview candidate and authorizedDialogfixturefix; portaltest temporarily derived with synchronousNodephase markers and failure-only DOM/PNG capture. No productstate/input/timeout/recoverychanges. Originalvisiblefailure rethrown.','timingLimit':'Nodeawait-return markers are not browser event timestamps. Instrumentation can perturb timing; no added success-pathawait/DOMquery/listener.','node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'pnpm':subprocess.check_output(['corepack','pnpm@10.32.1','--version'],env=env,text=True).strip()};write(R/'receipt.json',rec)
try:
 F.write_bytes(derived)
 with (R/'run.log').open('wb') as log:
  p=subprocess.Popen(cmd,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);rec.update({'status':'running','pid':p.pid,'processGroup':p.pid});write(R/'receipt.json',rec);print(json.dumps({'started':rec['startedAt'],'pid':p.pid}),flush=True);code=p.wait(timeout=1200)
 rec.update({'status':'completed','exitCode':code,'endedAt':now()})
finally:
 actual=F.read_bytes();rec['beforeRestoreTestSHA256']=sha(actual)
 if actual==derived:F.write_bytes(original);rec['exactOriginalRestored']=F.read_bytes()==original
 else:rec['exactOriginalRestored']=False;rec['restorationRefused']='Unexpected concurrent testchange; preserved instead of overwrite.'
 rec['headAfter']=git('rev-parse','HEAD').decode().strip();rec['inputsAfter']=inputs();raw=(R/'run.log').read_bytes();rec['logSHA256']=sha(raw);clean=re.sub(r'\x1b\[[0-9;]*[a-zA-Z]','',raw.decode(errors='replace'));rec['summary']=[s.strip() for s in clean.splitlines() if re.search(r'^\s*(Test Files|Tests)\s',s)];write(R/'receipt.json',rec)
print(json.dumps({k:rec.get(k) for k in ['status','exitCode','summary','exactOriginalRestored']}),flush=True)
