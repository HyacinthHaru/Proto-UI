# Portal 二次投射修复收据

当前 C 候选基于 `ba50383230a3ca63da2bc0ae099276cb5226330b`，尚未提交。最终生产改动只有 `packages/prototypes/base/src/select/alignment-controller.ts` 的5行：正常 view 退休后重走结构完成准入，同时保留 blocked admission 的原有显式修复路径；使旧 request 失效并清除上个 view 的 cache key。没有改 Runtime/Transition/Adapter 调度、paint、Compiler、API、native 输入或 timeout。**human-assisted / unassessed / partial / ABSTAIN**。

实际默认原 portal 文件已经 **8/8 PASS**，无额外等待、capture 或 source observer。随后单独打开原 capture 开关的 React/ltr 控制 **1 PASS / 7 filtered**；它不替代前一个默认8绿。最终相关 unit 命令为 **11 files / 54 PASS**。未由本代理执行最终 C 候选的全量 types/build/general/CI；这些与正式批准仍分开。

原完整8case为2 WC pass /6 framework fail。完整栈明确它们均已越过 Escape 和原 hidden 等待，React/Vue2失败于第二次 visible 等待172，Vue3失败于第二次click168。React失败后 Root保持open，但控制ID无目标、portal容器0；HTML仍有同owner的detached/pending Content壳。旧物理popup已断开后的有据控制仍红，所以没有采用“再加retirement等待”修绿。

两个真实首分歧分开保留：

1. React真实renderer unit先entered、再closed，第二次产生epoch循环，在mount.phase mounted后立刻unmount，未到authored mount.mounted。现有diagnostics和有界setPresent栈定位为重注册的瞬态parts被旧settled标记判为invalid，进而leave。
2. Vue2实际native的第二epoch mount/commit/mounted/update全交付，所有目标connected且有非零真实rect，但alignment仍是上个view的id1/request1/valid。旧applied已清、lastKey却仍命中，因此没有新binding释放当前preparing。真实Runtime/WC公共fixture保持Rootopen并退役/重建view，同一最终测试先在freshbinding断言146红，再绿。

正式无诊断 React 测试 SHA `ab60596bad8223f4370195c27665ec6e87289e82cfcb424374d5351ccac6d304`：精确ba原source上1fail3filtered；当前4case全部绿。精确阶段/循环来自另存的诊断run，不把诊断日志当作正式测试字节。新controller regression在红项断言之后的检查没有被追认成baseline已执行。

保留了所有失败候选：store.run guard无效；无条件settled=false引入两项原WC修复恢复失败；alignmentHidden reset未修nativeVue2；上述均已撤回。原WC owner基线5/5与最终blocked恢复覆盖仍在。Vue2私有positive2case不伪称新负例，已移出产品候选。工具wrapper预检失败/首个期间无关previewunit字节变化以及复制metadata标签校正也有独立收据，raw未改。

最终源码 SHA `38f6e1d0a304c937f4a4393ad1ff2094d36a69225fe86c7549692602c5de89a5`；新controller测试 SHA `9c3e37d539e2bc098636b62c6b73366e72dd1684391a7d3ba1d3743b2aa9d40e`。三个实际产品路径、原生每次命令/时点/返回码、所有unit日志SHA见 `final-repair-report.json`。没有提交、push、GitHub写入或新增认领。

实际恢复图为 `portal-native-react-capture/artifacts/react-ltr-opposite-reopened.png`，已用view_image查看：RTL菜单可见、3个选项及邮件选中标记存在；原DOM事实body=ltr、author/popup/options=rtl、expanded=true、portalled=true。它是原reopened采样时刻，不是额外settled-paint验收。该capture产生12PNG，仅此1张在本轮选为恢复图并视审，其余11张未评估。跨全部diagnostic选定的5原图及SHA/来源范围在 `visual-review-final.json`，没有改图或拼图。

Dialog的独立fixture修复已由root提交到ba503：原body直接子查找漏掉合法display-contents容器内唯一Mask，实际同owner/gen与0,0,390,900几何证实。只扩查询范围、原断言不动，同case红→绿；其它7Dialogcase未据此宣称通过。

现有 `T-BASE-SELECT-CONTENT-0001` 已登记controller测试及 `CASE-ALIGNMENT-ADMISSION`。私有 `catalog-mapping-v2.patch` 仅建议把新React路径加到同一case、status needs-review；spec尚未编辑，不新增实体或扩大准入。另原Direction native case继续承接真实四框架方向/重开证据。
