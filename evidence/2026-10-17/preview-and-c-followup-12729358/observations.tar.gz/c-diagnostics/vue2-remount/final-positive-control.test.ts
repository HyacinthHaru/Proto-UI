import { expect, it, vi } from 'vitest';
import * as parts from '../../../prototypes/base/src/select';
import { createVue2Adapter } from '../src';
import { Vue2Any, Vue2RuntimeAny, flushVue2 } from './utils/vue2';

it.each(['popper', 'item-aligned'] as const)(
  'reopens retained Vue2 %s Select after its portal view retires',
  async (position) => {
    // Happy DOM has no layout. Supply bounded geometry for the alignment owner;
    // native geometry remains covered by the original browser journeys.
    vi.spyOn(HTMLElement.prototype, 'getBoundingClientRect').mockImplementation(function (
      this: HTMLElement
    ) {
      const name = this.className;
      const rect: [number, number, number, number] = name.includes('retained-trigger')
        ? [180, 240, 180, 36]
        : name.includes('retained-value')
          ? [193, 248, 50, 20]
          : name.includes('retained-surface')
            ? [0, 0, 180, 106]
            : name.includes('retained-item-text')
              ? [13, 37, 50, 20]
              : [0, 0, 180, 32];
      return new DOMRect(...rect);
    });
    vi.spyOn(HTMLElement.prototype, 'offsetHeight', 'get').mockImplementation(function (
      this: HTMLElement
    ) {
      return this.className.includes('retained-viewport')
        ? 104
        : this.className.includes('retained-surface')
          ? 106
          : 32;
    });
    vi.spyOn(HTMLElement.prototype, 'clientHeight', 'get').mockReturnValue(104);
    vi.spyOn(HTMLElement.prototype, 'scrollHeight', 'get').mockReturnValue(104);
    vi.spyOn(HTMLElement.prototype, 'offsetTop', 'get').mockImplementation(function (
      this: HTMLElement
    ) {
      return this.className.includes('retained-item') ? 4 : 0;
    });
    const events: unknown[] = [];
    const adapt = createVue2Adapter(Vue2RuntimeAny);
    const Root = adapt(parts.selectRoot),
      Trigger = adapt(parts.selectTrigger),
      Value = adapt(parts.selectValue);
    const Content = adapt(parts.selectContent, {
      diagnostics: {
        onLifecycleEvent(event) {
          if (events.length < 100) events.push(event);
        },
      },
    });
    const Surface = adapt(parts.selectSurface),
      Viewport = adapt(parts.selectViewport),
      Item = adapt(parts.selectItem),
      ItemText = adapt(parts.selectItemText);
    const App = Vue2Any.extend({
      render(h: any) {
        const el = (
          component: any,
          name: string,
          attrs: any = {},
          children: any[] = [],
          style?: any
        ) =>
          h(
            component,
            { ref: name, attrs, props: { hostClass: 'test-select-retained-' + name }, style },
            children
          );
        return el(Root, 'root', { defaultValue: 'alpha' }, [
          el(Trigger, 'trigger', {}, [el(Value, 'value')]),
          el(Content, 'content', { position, enterDuration: 0, leaveDuration: 0 }, [
            el(
              Surface,
              'surface',
              {},
              [
                el(
                  Viewport,
                  'viewport',
                  {},
                  [
                    el(Item, 'item', { value: 'alpha', textValue: 'Alpha' }, [
                      el(ItemText, 'item-text', {}, ['Alpha']),
                    ]),
                  ],
                  { padding: '4px' }
                ),
              ],
              { border: '1px solid black', padding: '0px' }
            ),
          ]),
        ]);
      },
    });
    const host = document.createElement('div');
    document.body.append(host);
    const vm = new App().$mount();
    host.append(vm.$el);
    const phase = () => vm.$refs.content.getExposes().transitionState.get();
    const request = async (open: boolean) => {
      const accepted = vm.$refs.root
        .getExposes()
        .requestOpen({ open, reason: 'programmatic', focusReason: 'programmatic' });
      await flushVue2();
      expect(accepted).toBe(true);
    };
    try {
      await flushVue2();
      await request(true);
      await expect.poll(phase, { message: 'initial entry' }).toBe('entered');
      await request(false);
      await expect.poll(phase, { message: 'closed entry' }).toBe('closed');
      await request(true);
      expect(vm.$refs.root.getExposes().open.get()).toBe(true);
      expect(vm.$refs.content.getExposes().open.get()).toBe(true);
      await expect.poll(phase, { message: 'reopened entry' }).toBe('entered');
      expect(document.querySelector('.test-select-retained-content')?.getAttribute('role')).toBe(
        'listbox'
      );
    } finally {
      console.info('[Vue2 retained-entry events]', position, JSON.stringify(events));
      vm.$destroy();
      await Vue2Any.nextTick();
      host.remove();
      vi.restoreAllMocks();
    }
  }
);
