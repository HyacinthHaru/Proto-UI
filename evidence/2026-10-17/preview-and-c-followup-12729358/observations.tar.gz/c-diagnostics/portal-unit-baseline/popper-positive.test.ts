import * as React from 'react';
import { act } from 'react';
import { createPortal } from 'react-dom';
import { createRoot } from 'react-dom/client';
import { describe, expect, it, vi } from 'vitest';
import * as base from '../../../prototypes/base/src/select';
import * as shadcn from '../../../prototypes/shadcn/src/select';
import { createReactAdapter } from '../src';

(globalThis as any).IS_REACT_ACT_ENVIRONMENT = true;

for (const [family, prototypes] of Object.entries({ base, shadcn })) {
  describe(`React ${family} Select retained presence`, () => {
    it('reopens the retained Content after its prior portal view retires', async () => {
      vi.useFakeTimers();
      const adapt = createReactAdapter({ ...React, createPortal });
      const Root = adapt(prototypes.selectRoot);
      const Trigger = adapt(prototypes.selectTrigger);
      const Content = adapt(prototypes.selectContent);
      const Item = adapt(prototypes.selectItem);
      const refs: Record<string, any> = {};
      const host = document.createElement('div');
      document.body.append(host);
      const root = createRoot(host);
      const settle = async () => {
        await act(async () => {
          await vi.advanceTimersByTimeAsync(0);
        });
      };
      const content = () =>
        document.querySelector<HTMLElement>('.test-select-retained-content');
      const request = async (open: boolean) => {
        let accepted = false;
        await act(async () => {
          accepted = refs.root.getExposes().requestOpen({
            open,
            reason: 'programmatic',
            focusReason: 'programmatic',
          });
        });
        await settle();
        expect(accepted).toBe(true);
      };
      try {
        await act(async () => {
          root.render(
            React.createElement(
              Root,
              { ref: (value: any) => (refs.root = value), defaultValue: 'alpha' },
              React.createElement(Trigger, null, 'Choose'),
              React.createElement(
                Content,
                {
                  ref: (value: any) => (refs.content = value),
                  hostClassName: 'test-select-retained-content',
                  position: 'popper',
                  enterDuration: 0,
                  leaveDuration: 0,
                },
                React.createElement(Item, { value: 'alpha', textValue: 'Alpha' }, 'Alpha')
              )
            )
          );
        });
        await settle();
        await request(true);
        expect(content()?.getAttribute('role')).toBe('listbox');
        expect(refs.content.getExposes().transitionState.get()).toBe('entered');
        expect(document.querySelectorAll('[data-pui-portal-mount]')).toHaveLength(1);

        await request(false);
        expect(refs.content.getExposes().transitionState.get()).toBe('closed');
        expect(document.querySelectorAll('[data-pui-portal-mount]')).toHaveLength(0);

        await request(true);
        expect(refs.root.getExposes().open.get()).toBe(true);
        expect(refs.content.getExposes().open.get()).toBe(true);
        expect(refs.content.getExposes().transitionState.get()).toBe('entered');
        expect(content()?.getAttribute('role')).toBe('listbox');
        expect(document.querySelectorAll('[data-pui-portal-mount]')).toHaveLength(1);
      } finally {
        await act(async () => root.unmount());
        host.remove();
        vi.useRealTimers();
      }
    });
  });
}
