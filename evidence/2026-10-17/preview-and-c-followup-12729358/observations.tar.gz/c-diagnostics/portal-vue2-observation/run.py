from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,sys
W=Path('<SOURCE_ROOT>');R=Path(__file__).parent
sources={}
for rel in ['packages/prototypes/base/src/select/alignment-controller.ts','packages/adapters/vue2/src/adapt.ts']:
 p=W/rel;a=p.read_bytes();s=a.decode()
 if rel.endswith('alignment-controller.ts'):
  s=s.replace("  let phase: SelectPresentationPhase = 'unsettled';", "  let phase: SelectPresentationPhase = 'unsettled';\n  let observedRoot = '';\n  const observe = (fact: unknown) => { if (typeof window !== 'undefined') { const g = globalThis as any; const rows = (g.__selectPortalCTrace20261017 ??= []); if (rows.length < 500) rows.push({ kind: 'alignment', rootId: observedRoot, ms: performance.now(), fact }); } };")
  s=s.replace('    phase = next;','    observe({ event: \'notify\', next, reason, mounted, settled, structureVersion, request });\n    phase = next;')
  s=s.replace('    if (!ctx) return;','    if (!ctx) return;\n    observedRoot = ctx.rootId;',1)
  s=s.replace('      onAlignment(status) {','      onAlignment(status) {\n        observe({ event: \'status\', status, id, request, phase, mounted, settled });')
 else:
  old='function trackFocusIngress(vm: any, event: RuntimeLifecycleEvent) {'
  new=old+"\n  if (typeof window !== 'undefined' && String(vm.$options?.name).includes('select-content')) { const g = globalThis as any; const rows = (g.__selectPortalCTrace20261017 ??= []); if (rows.length < 500) rows.push({ kind: 'lifecycle', uid: vm.$uid, component: vm.$options?.name, owner: getRootElement(vm)?.getAttribute('data-projection-owner'), ms: performance.now(), event }); }"
  assert s.count(old)==1;s=s.replace(old,new)
 b=s.encode();sources[rel]=(a,b);(R/(p.name+'.original')).write_bytes(a);(R/(p.name+'.observer')).write_bytes(b)
receipt={'startedAt':datetime.now(timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'scope':'One originalVue2/ltrcase; existingRuntimeLifecycleEvents andalignmentnotify/status passivelycopied toboundedobserverarray; no productstate/input/assertion/timeout change. Failedhiddenresetcandidatewithdrawn.','sources':[{'path':p,'originalSHA256':hashlib.sha256(a).hexdigest(),'observerSHA256':hashlib.sha256(b).hexdigest()} for p,(a,b) in sources.items()]}
try:
 for rel,(a,b) in sources.items(): (W/rel).write_bytes(b)
 pr=subprocess.Popen([sys.executable,str(R/'run-test.py')],cwd=W);print('WRAPPER_PID',pr.pid,flush=True);receipt['wrapperExit']=pr.wait(timeout=1200)
finally:
 receipt['restored']={}
 for rel,(a,b) in sources.items():
  p=W/rel
  if p.read_bytes()==b:p.write_bytes(a);receipt['restored'][rel]=True
  else:receipt['restored'][rel]=False
 receipt['endedAt']=datetime.now(timezone.utc).isoformat();(R/'source-observation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt,flush=True)
