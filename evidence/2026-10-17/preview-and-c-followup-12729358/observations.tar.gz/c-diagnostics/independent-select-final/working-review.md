# Select alignment retirement 独立working review

**当前4路径0个具体finding；partial / ABSTAIN。** 基线ba503，未提交候选，非GitHubAPPROVE。精确4SHA和私有快照在JSON。

仅Controller.unmounted增加5行：普通view撤回后settled=false，使新同步组合重新结算；三个blockedphase保留settled，让原有显式结构/representedvalue/poppermodes修复在无view时仍可工作。++request令旧onAlignment在readContext/notify/deliver前失效，清lastKey避免同logicalRootfacts沿用旧binding；applied清理仍在。没有修改Rootopen/selection、Content/Transition/Adapters/Overlay或paint。新代码不新增outwardcallback，避免把退休处理扩大成新的重入/异常策略。

WC控制使用真实Runtime/Anatomy及testowner公开setPresent，保持controlledRootopen=true。它验证旧callback在retire/remount两阶段均无效，freshbinding不同且可应用；定位status是刻意synthetic，不宣称nativegeometry。原collectionrevision控制正文完整。React4case实际组合Base/Shadcn与popper/item-aligned，publicrequestOpen/Transition/portal1→0→1；HappyDOM几何mock明确，real timers与cleanup保留。

T仅给现有Admissioncase增加needs-review的requiredReactimplementation，9行，不改criterion或draft生命周期。符合P-BASE-SELECT-CONTENT的current-request与presentationadmission现有方向。

证据必须分开：

- exactba+最终Reactfixture正式红只选Baseitem-aligned：1fail/3filtered，原5s不变。不是四个独立红。
- 新WCrequestepoch红在此前settlement-only31c75候选：1controlpass/1fail，停freshbindingidentity；不可声称之后的断言已跑。
- 最终38f6源码是`green-epoch-request-final.log` 11files54pass；早先名含final-candidate的12/55仍是失败方案历史。
- 扩大27files365pass/2既有TODO、types934/0errors/0warnings/14hints。
- 原portal完整8case，02:05:17–02:05:38，实际8PASS，无capture/observer/CLI过滤或timeout修改；绑定ba503+最终3源码/测试dirtybytes，Tmetadata后加不冒充已执行。
- React/ltr原capture控制另1PASS/7filtered，不合并成9个全矩阵nativecase。

原2WCpass/6frameworkred、simpleguard无效、unconditionalreset导致2WC红、hiddenresetunit55绿但Vue2native红，以及初期fixture/preflight/metadata纠正均保留。没有用最后8/8重写这些事实；NativeVue2Rootfalse通知时间线也未被虚构。

最终签名head、新CI和新组合Form等仍待后续；Mac结果不等于Linuxcanonical/全Finf/AT验收。没有执行新测试/browser、修改source或外写。
