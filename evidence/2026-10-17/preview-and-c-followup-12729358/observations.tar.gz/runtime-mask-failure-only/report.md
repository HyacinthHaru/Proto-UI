一次原路径 failure-only 诊断复现同一 React option click 30000ms timeout（1fail/5filtered）。实际 d28+仅诊断catch执行；finally 已恢复原 SHA03998d7f，11328 tracked条目恢复后与前快照完全相同，worktree clean，port61312无listener。

失败后 Root 公开 open=true/value=wc，Trigger expanded=true/controls=pui-select-1-content；同ID Content connected=true但display:none、data-pui-view-detached，公开 open=true/transitionState=closed/isPresent=false/alignmentDiagnostic=select.geometry.invalid-geometry。React option仍在DOM、role=option、connected，因隐藏祖先得到零rect，不是作者item不存在。pageErrors/consoleErrors/captureErrors均空。

实际viewport PNG已逐张查看：dark/200% compact Header菜单展开，Web Components Trigger有焦点，未见runtime选项popup，底部Page library区域受viewport裁切。截图和DOM在原timeout之后，不是假造点击瞬间或测量输入。

现有draft P-BASE-SELECT-CONTENT-PRESENTATION-ADMISSION明确允许geometry-unavailable终结presentation而保留Root逻辑open；当前两状态并存本身不证明C错误。Host仅在solver非plan（target-alignment-host.ts:257）或最多4passes不收敛（:325）产生该reason。下一判别证据是原同步测量输入/plan/pass/分支，不是加等待、force或放宽几何contract。报告与原字节/完整截图/DOM/AX均在本目录，human-assisted partial/ABSTAIN。
