from pathlib import Path
import subprocess,os,json,hashlib,datetime,difflib,signal,re
p=Path(__file__).parent;w=Path('<SOURCE_ROOT>');rel='apps/www/src/content/docs/zh-cn/runtime-loading-mask.browser.test.ts';test=w/rel;head='d28b17bc04074213c96045fbcb9e7c29c7b1f0ae'
sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*x):return subprocess.check_output(['git',*x],cwd=w,text=True).strip()
def write(n,x):(p/n).write_text(json.dumps(x,indent=2)+'\n')
assert git('rev-parse','HEAD')==head and not git('status','--porcelain=v1')
original=test.read_bytes();assert sha(original)=='03998d7f005cc07895f36a0e0ee84efe9a0ab2cc1e56e5215b41d877d9df1147';(p/'original.test.ts').write_bytes(original)
needle="        } finally {\n          release?.();";assert original.decode().count(needle)==1
added="""        } catch (error) {
          try {
            const { captureRuntimeFailure } = await import(%s);
            await captureRuntimeFailure(page, { family, scenario, sourceHead: %s }, error);
          } catch (captureError) {
            console.error('[private failure-only capture]', captureError);
          }
          throw error;
        } finally {
          release?.();""" % (json.dumps((p/'capture.mjs').as_uri()),json.dumps(head))
(p/'diagnostic.test.ts').write_text(original.decode().replace(needle,added))
env=os.environ.copy();env['PATH']='<LOCAL_NODE24_BIN>:'+env['PATH']
removed={k:env.pop(k)for k in list(env)if k.startswith('PUI_')or k.startswith('PROTO_UI_')or k in ['GITHUB_ACTIONS','CANDIDATE_SHA','CI','DEBUG']}
subprocess.run(['corepack','pnpm@10.32.1','exec','prettier','--config',str(w/'.prettierrc'),'--write',str(p/'diagnostic.test.ts'),str(p/'capture.mjs')],cwd=w,env=env,check=True,capture_output=True)
derived=(p/'diagnostic.test.ts').read_bytes();(p/'original-to-diagnostic.patch').write_text(''.join(difflib.unified_diff(original.decode().splitlines(True),derived.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
entries=[]
for raw in subprocess.check_output(['git','ls-tree','-r','-z','HEAD'],cwd=w).split(b'\0'):
 if not raw:continue
 meta,name=raw.split(b'\t',1);mode,kind,blob=meta.decode().split();entries.append((name.decode(),mode,kind,blob))
def snapshot():
 rows=[]
 for name,mode,kind,blob in entries:
  if kind!='blob':continue
  f=w/name;b=os.readlink(f).encode()if mode=='120000'else f.read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();rows.append({'path':name,'mode':mode,'gitBlob':blob,'workingBlob':actual,'sha256':sha(b),'bytes':len(b)})
 return rows
before=snapshot();assert all(x['gitBlob']==x['workingBlob']for x in before);write('source-original-before.json',before)
a=p/'artifacts';a.mkdir(exist_ok=False);env['PUI_RUNTIME_MASK_EVIDENCE_DIR']=str(a)
command=['corepack','pnpm@10.32.1','exec','vitest','run',rel,'--maxWorkers=1','--minWorkers=1','-t','shadcn native regional runtime mask.*narrow-dark-text200','--reporter=verbose','--reporter=json','--outputFile='+str(p/'vitest.json')]
r={'status':'prepared','head':head,'tree':git('rev-parse','HEAD^{tree}'),'originalSHA256':sha(original),'executedDiagnosticSHA256':sha(derived),'helperSHA256':sha((p/'capture.mjs').read_bytes()),'command':command,'removedEnvironment':removed,'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'pnpm':subprocess.check_output(['corepack','pnpm@10.32.1','--version'],env=env,text=True).strip(),'outerBudgetSeconds':300,'scope':'Same original config/path/selected case/input/assertion/timeout. Added only catch before original finally; dynamic helper imports after rejection and then rethrows original error. No pre-failure listeners/sampling. Existing optional mask output env retained like parent original control.','sourceEntryCount':len(before)}
write('receipt.json',r)
try:
 test.write_bytes(derived);r['executedStatus']=git('status','--porcelain=v1');assert git('diff','--name-only')==rel
 during=snapshot();write('source-executed-before.json',during);assert [x['path']for x in during if x['gitBlob']!=x['workingBlob']]==[rel]
 r.update(status='running',startedAt=now());write('receipt.json',r)
 with (p/'run.log').open('w')as log:
  c=subprocess.Popen(command,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r.update(childPID=c.pid,processGroup=c.pid);write('receipt.json',r);print(json.dumps({k:r[k]for k in ['startedAt','head','tree','childPID','processGroup','executedDiagnosticSHA256','helperSHA256','command']}),flush=True)
  try:r['exit']=c.wait(timeout=300)
  except subprocess.TimeoutExpired:
   r['outerWatchdogExpired']=True;os.killpg(c.pid,signal.SIGTERM)
   try:r['exit']=c.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(c.pid,signal.SIGKILL);r['exit']=c.wait(timeout=10)
 r['completedAt']=now();r['logSHA256']=sha((p/'run.log').read_bytes())
finally:
 if test.read_bytes()==derived:test.write_bytes(original);r['restoredOriginal']=True
 else:r['restoredOriginal']=False;r['restoreError']='Unexpected third-party bytes; did not overwrite.'
 after=snapshot();write('source-after-restoration.json',after);r.update(status='completed',statusAfter=git('status','--porcelain=v1'),headAfter=git('rev-parse','HEAD'),sourceByteChangesAfterRestoration=[x['path']for x,y in zip(before,after)if x!=y],restoredSHA256=sha(test.read_bytes()))
 if (p/'run.log').exists():
  text=(p/'run.log').read_text();r['summaryLines']=[x.strip()for x in text.splitlines()if re.search(r'(Test Files|\bTests\s+)',x)];r['ports']=sorted({int(x)for x in re.findall(r'http://127\.0\.0\.1:(\d+)',text)});r['listeningAfter']=[]
  for port in r['ports']:
   q=subprocess.run(['lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN'],capture_output=True,text=True);r['listeningAfter'].append({'port':port,'exit':q.returncode,'output':q.stdout})
 write('receipt.json',r);print(json.dumps({k:r.get(k)for k in ['status','exit','summaryLines','restoredOriginal','statusAfter','sourceByteChangesAfterRestoration','listeningAfter']}),flush=True)
