准确 d28 的普通 **browser6** 已完成：**10 files = 8 pass / 2 fail；169 tests = 161 pass / 8 fail，exit1**。这不是全8分片总数。原日志已一次只读下载，job117287506784，SHA `2c7afb00deaadc6c5c5003a6b1d2a027ba5f0d2eaad7a900a62de4535103a4df`。实际checkout `47d7e2ad21a9794c66df9ab865748e22391d1136` 的官方Git tree为 `4375791330915298740fbad38f6ddb014028b764`，精确等于d28；parents是404+d28。报告仍 human-assisted / unassessed / partial / ABSTAIN。

失败可以归为3个具体首分歧，不能按8个测试名计作8个C根因：

1. **Homepage三例先被 inventory oracle 挡住**。`prototype-projection-scope.browser.test.ts:475` 实收102、预期97，恰好多出 `shadcn-select-item-text`×3、`shadcn-select-surface`×1、`shadcn-select-viewport`×1。当前 acceptedmain404 的 Homepage recipe明确实例化这5个part；resolver只为Shadcn提供这3类。draft `P-BASE-SELECT-ALIGNMENT-PARTS` 和 `P-SHADCN-SELECT-CONTENT-CURRENT-VISUAL-SURFACE`也明确承认其真实part/所有权。这是固定预期清单遗漏，不能说Anatomy凭空多建或旧owner泄漏。最小方案是Shadcn精确补3+1+1及unique kinds37→40、Brutalist原值保留，继续所有owner/generation/portal断言；不要改成读取实际DOM来生成期望。这三例尚未走到后续theme/原子seal断言，不能称它们通过。
2. **Homepage WC Select fingerprint 在line570期待旧pressed motion**。原1000ms poll期待 `translate-y-px`；但当前draft P的`STATE-DRIVEN-STYLES`64–65行明确 default/ghost均无pressed displacement，T的CASE标题和实现说明也一致。故最小方案应保留mouse hover/down/up与后续open路径，改验当前default无translation/无位移，而非单纯删断言。P的openQuestion97–98仍残留“current adopted translate-y-px”，需要同步这段现行描述；历史revision139不应删除。这一判断来自P/T+recipe，不是因为实现少一条规则就改绿。
3. **Brutalist Button四runtime的真实320px/200%几何红**。首错都在line370：`Solid main`右边界206超过canvas内容右边界容差182.5。原文件先校验右边界，后面的height/text/scrollWidth与page overflow断言尚未到达。直接观测属于consumer reflow/paint几何；此日志没有建立Context、Anatomy或退休owner异常链。测试源与404相同只证明源保留，不能等同成对基线复现或归因“继承”。不建议放宽边界/timeout来处理。

原Homepage“restores semantic control focus and disconnects the replaced generation portal”例在同job真实通过；Dialog8、FocusIntentRetries90、ContrastProbe46也真实通过。这些阳性不能替代前三个被inventory挡住的后续生命周期路径。该shard没有选择Form/Field/Collapsible family文件，不能据它推这些scope状态。

已逐blob核对这两份失败test、Homepage recipe/resolver、ShadcnTrigger实现以及相关P/T共10路径，**404→d28全部相同**。CI环境日志明确Node24.21.0；没有据该日志独立建立Chrome具体版本，未套用专项Dialog环境。未跑测试、未改产品、未取其它7分片或大型ZIP。完整失败名、原日志行、source hashes和最小方案在同名JSON。
