目标对齐 Host 的可审候选已完成：原错误由 Surface 的 paint 缩放进入浮动 inline BCR，而同一次布局读又使用未缩放的 client/offset 事实。候选按现有layoutTop模式建立inline layout事实，以中立Frame视口原点定位，并保留实际signed scrollLeft；reference/value依然读真实分数BCR。原solver、parseInt、4passes、0.01、lease/current检查、scrollTop展开及painted交互边界均未变，没有fallback/API/延时或组件名分支。

精度明确：floating offsetLeft/offsetWidth采用CSSOM整数layout精度，不能宣称保留原painted BCR小数；Frame/reference/value实际分数和scrollLeft数值不额外取整。根代理的三份draft来源说明/测试映射另列，不声称stable准入。

真实验证链全部保留：正式Host原9pass2fail→同test首候选11pass；相关6files初55pass1fail（Runtime fakegeometry缺offset事实）→等价事实补齐56pass，旧provider+新fixture另4pass且180期待未改；独审横向scroll控制实证首候选2fail/11filtered，旧provider同test2pass/11filtered。最终Host补实际signed scroll扣除后，最终Host13项包含在6相关files **58/58 pass**中。没有将不同版本测试计数混成单一baseline。

原生串行一次全部 **26/26 pass**：完整runtime-mask6（03:18:46–03:19:09）、portal8（03:19:09–03:19:30）、alignment4+group8（03:19:31–03:19:40）。原input/assertion/timeout未改，无私有source/test observer；mask使用原optional截图环境，其它截图关闭。真实来源是d28+8个working dirty，Host SHA5ba56d964638e5401927743be8e3631fd2c457ba9a8896c1eff61f2027e093b3；全11328 tracked工作字节前后完全相同。PID/端口已回收，未提交/推送。

12张mask原PNG已逐张view，desktop显示真实loading/cancel/error/retry状态；narrowdark200四图被compact Header菜单遮住区域，mask本体未在viewport内可见，不能写全面视觉验收，Brutalist单词跨三行亦保留。原retry故意abort模块，相关ERR_FAILED/retained错误与React hreflang warning原样保留，不写error-free。

本结果是macOS本地未提交候选验证。原官方Collapsible320geometry/Form颜色红不被此修复抹去，旧d28四suite74pass不是本候选执行。完整源码、same-test红绿、原生命令、每图SHA和source边界见report.json与visual-review.json；types/父级组合/正式review由根代理另核。human-assisted partial/ABSTAIN。
