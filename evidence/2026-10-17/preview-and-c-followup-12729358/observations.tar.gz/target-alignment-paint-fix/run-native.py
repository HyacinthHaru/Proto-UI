from pathlib import Path
import subprocess,os,json,hashlib,datetime,signal,re
p=Path(__file__).parent;out=p/'native';out.mkdir(exist_ok=False);w=Path('<SOURCE_ROOT>');head='d28b17bc04074213c96045fbcb9e7c29c7b1f0ae';sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*x):return subprocess.check_output(['git',*x],cwd=w,text=True).strip()
def write(path,x):path.write_text(json.dumps(x,indent=2)+'\n')
freeze=json.loads((p/'candidate-freeze.json').read_text());assert git('rev-parse','HEAD')==head
for x in freeze['dirtyInputs']:assert sha((w/x['path']).read_bytes())==x['sha256'],x['path']
assert set(git('diff','--name-only').splitlines())=={x['path']for x in freeze['dirtyInputs']}
entries=[]
for raw in subprocess.check_output(['git','ls-tree','-r','-z','HEAD'],cwd=w).split(b'\0'):
 if not raw:continue
 meta,name=raw.split(b'\t',1);mode,kind,blob=meta.decode().split();entries.append((name.decode(),mode,kind,blob))
def snapshot():
 rows=[]
 for name,mode,kind,blob in entries:
  if kind!='blob':continue
  f=w/name;b=os.readlink(f).encode()if mode=='120000'else f.read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();rows.append({'path':name,'mode':mode,'gitBlob':blob,'workingBlob':actual,'sha256':sha(b),'bytes':len(b)})
 return rows
env=os.environ.copy();env['PATH']='<LOCAL_NODE24_BIN>:'+env['PATH'];removed={k:env.pop(k)for k in list(env)if k.startswith('PUI_')or k.startswith('PROTO_UI_')or k in ['GITHUB_ACTIONS','CANDIDATE_SHA','CI','DEBUG']};env['CHROME_PATH']='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';assert Path(env['CHROME_PATH']).is_file()
versions={'node':subprocess.check_output(['node','--version'],env=env,text=True).strip(),'pnpm':subprocess.check_output(['corepack','pnpm@10.32.1','--version'],env=env,text=True).strip(),'chromeExecutable':env['CHROME_PATH'],'chromeVersionCommand':subprocess.check_output([env['CHROME_PATH'],'--version'],text=True).strip(),'removedEnvironment':removed,'PATH':env['PATH']};write(out/'environment.json',versions)
initial=snapshot();write(out/'source-before.json',initial);record={'status':'running','start':now(),'head':head,'tree':git('rev-parse','HEAD^{tree}'),'statusBefore':git('status','--porcelain=v1'),'sourceEntries':len(initial),'candidateFreezeSHA256':sha((p/'candidate-freeze.json').read_bytes()),'steps':[]};write(out/'receipt.json',record)
steps=[('runtime-mask',['apps/www/src/content/docs/zh-cn/runtime-loading-mask.browser.test.ts'],True),('portal-direction',['apps/www/src/content/docs/zh-cn/overlay-portal-direction.browser.test.ts'],False),('target-alignment',['packages/web-conformance/test/select-target-alignment.browser.test.ts','packages/web-conformance/test/select-group.browser.test.ts'],False)]
for label,files,maskCapture in steps:
 before=snapshot()
 if before!=initial:
  record['stoppedBeforeNextSuiteForSourceChange']=label;break
 step=out/label;step.mkdir();art=step/'artifacts';art.mkdir();ee=env.copy()
 if maskCapture:ee['PUI_RUNTIME_MASK_EVIDENCE_DIR']=str(art)
 cmd=['corepack','pnpm@10.32.1','exec','vitest','run',*files,'--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=verbose','--reporter=json','--outputFile='+str(step/'vitest.json')]
 r={'name':label,'status':'running','start':now(),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'workingStatus':git('status','--porcelain=v1'),'command':cmd,'originalTests':True,'privateSourceOverride':False,'capture':'Original optional PUI_RUNTIME_MASK_EVIDENCE_DIR enabled, same as original selected failure control.'if maskCapture else'Optional evidence capture unset; default original path.','outerBudgetSeconds':600,'sourceBeforeSHA256':sha(json.dumps(before,sort_keys=True).encode()),'testSources':[next(x for x in before if x['path']==f)for f in files]}
 write(step/'receipt.json',r);record['steps'].append(r);write(out/'receipt.json',record)
 with(step/'run.log').open('w')as log:
  c=subprocess.Popen(cmd,cwd=w,env=ee,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r.update(childPID=c.pid,processGroup=c.pid);write(step/'receipt.json',r);write(out/'receipt.json',record);print(json.dumps({k:r[k]for k in ['name','start','childPID','head','command']}),flush=True)
  try:r['exit']=c.wait(timeout=600)
  except subprocess.TimeoutExpired:
   r['outerWatchdogExpired']=True;os.killpg(c.pid,signal.SIGTERM)
   try:r['exit']=c.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(c.pid,signal.SIGKILL);r['exit']=c.wait(timeout=10)
 text=(step/'run.log').read_text();after=snapshot();r.update(status='completed',end=now(),sourceUnchanged=before==after,logSHA256=sha((step/'run.log').read_bytes()),summaryLines=[x.strip()for x in text.splitlines()if re.search(r'(Test Files|\bTests\s+)',x)],headAfter=git('rev-parse','HEAD'),statusAfter=git('status','--porcelain=v1'))
 ports=sorted({int(x)for x in re.findall(r'http://127\.0\.0\.1:(\d+)',text)});r['listeningAfter']=[]
 for port in ports:
  q=subprocess.run(['lsof','-nP',f'-iTCP:{port}','-sTCP:LISTEN'],capture_output=True,text=True);r['listeningAfter'].append({'port':port,'exit':q.returncode,'output':q.stdout})
 write(step/'receipt.json',r);write(out/'receipt.json',record);print(json.dumps({k:r[k]for k in ['name','end','exit','summaryLines','sourceUnchanged','listeningAfter']}),flush=True)
 if r['exit']!=0 or not r['sourceUnchanged']:record['stoppedAfter']=label;break
final=snapshot();write(out/'source-after.json',final);record.update(status='completed',end=now(),headAfter=git('rev-parse','HEAD'),statusAfter=git('status','--porcelain=v1'),allSourceBytesUnchanged=initial==final,sourceByteChanges=[x['path']for x,y in zip(initial,final)if x!=y]);write(out/'receipt.json',record);print(json.dumps({'allDone':len(record['steps'])==3,'allSourceBytesUnchanged':record['allSourceBytesUnchanged'],'results':[(x['name'],x.get('exit'))for x in record['steps']]}),flush=True)
