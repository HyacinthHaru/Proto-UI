import base from '<SOURCE_ROOT>/vitest.config.ts';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
const worktree = '<SOURCE_ROOT>';
const evidence =
  '<PRIVATE_STATE>/continue-20261017T005751Z/target-alignment-paint-fix';
const original = fs.readFileSync(path.join(evidence, 'original-target-alignment-host.ts'), 'utf8');
export default {
  ...base,
  root: worktree,
  cacheDir: path.join(evidence, 'old-host-control-cache'),
  plugins: [
    {
      name: 'single-source-original-target-host-control',
      enforce: 'pre',
      load(id: string) {
        if (
          id.split('?')[0] !==
          path.join(worktree, 'packages/modules/positioning/src/web/target-alignment-host.ts')
        )
          return null;
        fs.appendFileSync(
          path.join(evidence, 'original-host-loaded.jsonl'),
          JSON.stringify({
            at: new Date().toISOString(),
            path: id,
            sha256: createHash('sha256').update(original).digest('hex'),
          }) + '\n'
        );
        return original;
      },
    },
    ...(base.plugins ?? []),
  ],
};
