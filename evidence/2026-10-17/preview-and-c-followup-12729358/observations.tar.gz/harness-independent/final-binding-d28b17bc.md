本次只读增量审查已绑定准确 `d28b17bc04074213c96045fbcb9e7c29c7b1f0ae` / tree `4375791330915298740fbad38f6ddb014028b764`。**0 个剩余具体源码 finding；结论仍为 human-assisted / unassessed / partial / ABSTAIN，未提交 GitHub review。**

`c6a17f84` 的两个 harness 文件逐字等于此前独立审查的 snapshot。修复仅将 scope 查询收窄到唯一 `.host`；页面上独立 Copy projection 不再污染被演示 host 的计数，同一 host 内 0/N scope 和其它原有 readiness 条件继续拒绝。新单测是合成 Copy-shaped DOM 对 serialized predicate 的控制，不能称实际 Copy 原生集成；原 110 cases 保留。实际日志是原 harness **1 failed / 110 filtered**，新 harness **111 passed**；同候选类型结果 **934 files / 0 errors / 0 warnings / 14 hints**。

`d28b17bc` 仅更新两项精确 PROBE_HASHES，并将注释的 “Calibrated against” 改为 “Geometry oracle from”。我从父 commit 重放这三个文本替换，结果与 commit 文件逐字相等；baseline 常量、全部严格数值、geometry/PNG/runner predicates、原 workflow/timeout/测试断言均未改变。两提交 Author、Committer 均为 `HyacinthHaru <hyacinth@haru.ac>`，DCO 一致、无 Co-authored-by；本地 `git verify-commit` 均验证已有 SSH ED25519 签名成功。相对 e757，完整树仅这 3 路径 mode/kind/blob 改变，其余 **11325** 项保留，Select 4 路径亦逐项不变。

历史 Mac 对照没有改成绿：固定 subject `15d864de` + c6a 完整三文件 probe，原 8 tests 全失败，分别 3 个 zero-inset、4 个 Title overlap 504、1 个 Vue2 not-offered；runner 实际正常收尾。hash-only classifier 原始红停在首个 glyph width `170.8125` 对 `170.828125`，不能声称后续 predicates 实际通过。c6a 当前产品另一份原完整 8-case 运行是 **8/8 pass**，也是 Mac 单独执行。

Mask 对照仅是一条历史 Brutalist/React journey：3 次 measure/facts 内的只读取样均为同一节点、唯一 descendant、两个 rect 均 `(0,0,390,900)`；原 Title overlap 504 断言依然失败，结果 **1 failed / 7 filtered**。这是原断言前的 measurement-time observer，不是 catch-only/failure-only observer。原 receipt 不重写；新增 `baseline-calibration/observation-boundary-correction.json` 已准确纠正该措辞和 classifier 首错中止范围。

随后到达的官方 [matched run 38995355607](https://github.com/Proto-UI/Proto-UI/actions/runs/38995355607) 提供了新的、不同于 Mac 的实际证明。我只读了已下载原日志与两份原 ZIP，未重新下载或运行：

- Baseline artifact `12086688715`：2,270,054 bytes，SHA256 `4e98c34dbdcd2807cc02a6b18c2dc0f29d6db156faa38859965a99478606a628`，40 members；subject=15d，probe=d28。原产品 8 failed / exit1，被**未放宽** classifier 精确接受为 3 inset + 4 Title + 1 not-offered，7 product journeys 全停在第一处 390px 检查，0 completed journeys。
- Candidate artifact `12086713903`：7,630,933 bytes，SHA256 `41b9d3ee0ebaa820fcb4be4944e66745a309cc84a1f9f5d6580c712fc27368ef`，130 members；subject/probe=d28，原 8 cases 全过 / exit0。
- 两 ZIP 的官方 digest/大小、目录安全性、已抽取关键记录与 ZIP 原成员、三项 probe SHA 与 Git blobs、report SHA、各 observation source 均相符。两个 runner 均 `process-exit`、`finishedCalls=1`、`closeFinished=true`、无 timeout/cancel/runner/unhandled errors。两端原件都记录 Chrome `155.0.8059.39`；日志记录 Node `24.21.0` / pnpm `10.32.1` / Ubuntu24，字体原件记录 Noto CJK 安装版本。前置 unit summaries 都为 117 pass。

因此 `PR901-DIALOG-CALIBRATION-CLOSURE-001` 的**当前 closure 官方匹配执行欠账已在该工作流范围关闭**；这不把旧 ba503 两个 prebrowser 红、Mac 字形红或历史未到达的后续 assertions 改写为成功。局部记录措辞项 `PR901-DIALOG-MEASUREMENT-SCOPE-002` 也已由新增 correction 关闭。

另已读 d28 官方 preview build log：run38995355640/job117286588085 实际完整 artifact test **1 pass / 3,835 files / 21,207,576 compressed test-ZIP bytes / 104,045,125 expanded bytes**。此处只增加日志 checkpoint，不重做 bundle 审查，也不声明新的远端部署或实际 publisher 验收。

仍保留范围限制：本轮没有逐像素视审、AT 或全部 PR/跨组件验收；早先 Select portal8 运行使用旧 c8cd harness，不能标成当前 c6a/d28 全输入原样重跑。完整逐文件 hash、父子/签名及各原始证据 SHA 见同名 JSON；此前 working review 与所有原始失败均保留。
