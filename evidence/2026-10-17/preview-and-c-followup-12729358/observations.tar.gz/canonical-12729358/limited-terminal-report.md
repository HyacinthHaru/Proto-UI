12729358 的有限 canonical 跟进完成，**partial/ABSTAIN**。三个选定 target 都已终态；collector 自然 exit0，没有 rerun/cancel/dispatch、测试或源码修改。

准确 head `12729358cc89dff007fb2e6d84a98401d66f5ff2`、tree `9788c9eb76cf486a6213d7b599738c678a374576`。三个 job 原日志都 checkout `fb910c9786cdba60e1704204dc5dc3ff732d3fd9`，Git tree 与 head 精确相同。

- Type：934 files / 0 errors / 0 warnings / 14 hints。
- Package：47/47 builds、47 manifests；9 项为4 PASS + 5 ADVISORY，gzip尺寸/minified尺寸/SHA与EF相同，不能称9项严格预算全过。
- ordinary shard5 job117313108153：目标 **RadioGroup8/8**（05:03:24、41,065ms）及 **scrollbar16/16**（05:04:44、79,539ms）实际通过。Radio原输入/semantics/deadline保留；checked-light与unchecked-light的最终校正断言有此官方执行证据。scrollbar保留classic>0、geometry及nestedscroll断言，仍只声称明确的Brutalist popper8 + 原Dialog8。

整个分片仍为 **75 passed / 14 failed / 15 skipped**（104tests），files为6passed/3failed/1skipped。残留colorScheme8、Collapsible窄屏geometry4、ShadowS5两locale初始ready2。ColorScheme四lifetime项停在paint alpha，后续identity尚未执行；S5停在原60s previewer wait，未到editing。没有把相同历史名称认定为继承原因。Radio旧EF4红保留，PR901-RADIO-LIGHT-ORACLE-001现有准确头8pass支持其限定关闭。

最后mainCI元数据仍in_progress、可见21jobs；不扩等或收集其他7普通分片、其他专项，不制造全CI总数。v4冻结04:58的pending事实保持不动，本报告作为后到终态增补。原EF/0d4专项、本地candidate native和图片保留原head/时间，不能重标为127新执行。
