准确 12729358 / tree 9788c9eb 的 type/package 已终态，保留 **partial/ABSTAIN**。

Type job 117313068891：934 files / 0 errors / 0 warnings / 14 hints。Package job 117313102362：47/47 builds、47 manifests；4 PASS + 5 ADVISORY。九项 gzip 尺寸、minified 尺寸和 SHA 与 EF 精确相同，记录工具链 Linux x64 / Node 24.21.0 / zlib 1.3.2.1-motley-8002e91 / esbuild 0.25.12；不称全部九项严格预算通过或完整环境等同。

两者原日志 checkout `fb910c9786cdba60e1704204dc5dc3ff732d3fd9`，Git tree 精确等于 `9788c9eb76cf486a6213d7b599738c678a374576`。

本冻结时点使用 04:58:45 UTC 的实际快照：shard 5 job 117313108153 为 in_progress，目标 scrollbar16 + Radio8 尚无该头终态，后到结果另写增补。未重读其余 7 分片或任何旧专项，不能用这份检查点宣布全 CI 通过。
