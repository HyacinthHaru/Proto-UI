本项存在明确的原 oracle 漂移：**PR901-RADIO-LIGHT-ORACLE-001**。`P-SHADCN-RADIO-GROUP-ITEM-CURRENT-VISUAL-SURFACE` 当前 draft 明确 checked 在明暗主题都使用 primary 填充，unchecked light 是透明，unchecked dark 是 input/30。相关 P、T、实现、浏览器原 fixture 和迁移记录均已对账 EF 与接受基线 404 的 Git 对象；实际逐项相等结果见 JSON。

原 interaction 已用真实输入把 Default 选中，并断言 `[true,false,false]` 和 `Value: default`，随后 dark/narrow 变化不改变选中项。最终 light 段仍将 Default 的 alpha 期待为 0，与上述 draft 冲突；同一个 case 开始段已按 checked/unchecked 区分 alpha 1/0。最小修正是 Default 期待 1，同时另验未选中的 Comfortable 透明 0，从而保留主题回切的透明恢复验证。不得删除输入、semantic/value/errors 断言、提高 timeout 或据此接受其他 paint 行为。

这是候选到达前的只读 authority 分析，候选字节及实际 8-case 终态另绑。保持 human-assisted/current-user、advisory、partial/ABSTAIN，不作稳定 spec 激活或 GitHub APPROVE。
