const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const startedAt = new Date().toISOString();
const root = '<SOURCE_ROOT>';
const requireSource = createRequire(path.join(root, 'package.json'));
const { chromium } = createRequire(path.join(root, 'apps/www/package.json'))('playwright-core');
const { transformSync } = require(path.join(root, 'node_modules/.pnpm/esbuild@0.25.12/node_modules/esbuild'));
const probe = fs.readFileSync(path.join(root, 'apps/www/src/content/docs/zh-cn/dialog-available-space.browser.test.ts'), 'utf8');
const source = probe.slice(probe.indexOf('async function facts('), probe.indexOf('\nasync function renderedDialogFonts'));
const facts = new Function(transformSync(source, { loader: 'ts' }).code + ';return facts;')();
const coordinate = 'data-projection-owner="o" data-projection-family="shadcn" data-projection-runtime="react" data-projection-generation="2"';
const html = `<div data-is-present data-pui-root role="listbox" data-projection-owner="site-search" style="display:none"></div><div data-projection-generation-state="active" data-projection-owner-host="o" data-projection-generation-host="2"><div data-projection-scope="o" data-projection-family="shadcn" data-projection-runtime="react" data-projection-generation="2" data-projection-state="ready"><div data-pui-root ${coordinate} data-projection-prototype="shadcn-dialog-root"><button ${coordinate} aria-haspopup="dialog" aria-controls="controlled-content">Open</button></div></div></div><div data-pui-portal-mount style="display:contents"><div id="mask" data-pui-root data-is-present ${coordinate} data-projection-prototype="shadcn-dialog-mask" style="position:fixed;inset:0"></div></div><div id="controlled-content" role="dialog" data-pui-root data-is-present ${coordinate} data-projection-prototype="shadcn-dialog-content" style="position:fixed;left:16px;top:100px;width:358px;height:200px"></div>`;
const mutations = [
 ['unrelated-first-present-root', ()=>{}, 'resolved', 390],
 ['other-owner-full-mask', ()=>{ const n=document.getElementById('mask').cloneNode(true);n.id='other-owner-mask';n.setAttribute('data-projection-owner','other');document.body.prepend(n); }, 'resolved',390],
 ['old-generation-full-mask', ()=>{ const n=document.getElementById('mask').cloneNode(true);n.id='old-mask';n.setAttribute('data-projection-generation','1');document.body.prepend(n); }, 'resolved',390],
 ['mask-without-presence', ()=>document.getElementById('mask').removeAttribute('data-is-present'), 'unresolved',null],
 ['missing-mask', ()=>document.getElementById('mask').remove(), 'unresolved',null],
 ['duplicate-mask', ()=>{ const n=document.getElementById('mask').cloneNode(true);n.id='duplicate';document.body.append(n); }, 'unresolved',null],
 ['duplicate-dialog-root', ()=>{ const n=document.querySelector('[data-projection-prototype="shadcn-dialog-root"]').cloneNode(false);document.body.append(n); }, 'unresolved',null],
 ['wrong-generation-host', ()=>document.querySelector('[data-projection-generation-host]').setAttribute('data-projection-generation-host','1'), 'unresolved',null],
 ['wrong-controls', ()=>document.querySelector('button').setAttribute('aria-controls','another-content'), 'unresolved',null],
 ['real-mask-zero-rect', ()=>{const n=document.getElementById('mask');n.style.width='0px';n.style.height='0px';}, 'resolved',0],
];
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROME_PATH,headless:true,args:['--disable-dev-shm-usage','--no-sandbox']});
 const rows=[];
 try {
  const page=await browser.newPage({viewport:{width:390,height:900}});
  for(const [name,mutation,status,width] of mutations){
   await page.setContent(html);await page.evaluate(mutation);const observed=await facts(page.locator('#controlled-content'));
   assert.equal(observed.maskIdentity.status,status,name);assert.equal(observed.mask?.width??null,width,name);
   if(name==='unrelated-first-present-root')assert.equal(observed.maskIdentity.originalRect.width,0);
   if(name==='real-mask-zero-rect')assert.throws(()=>assert.equal(observed.mask.width,390));
   rows.push({name,passed:true,status:observed.maskIdentity.status,width:observed.mask?.width??null,originalWidth:observed.maskIdentity.originalRect?.width,maskCount:observed.maskIdentity.maskCount,rootCount:observed.maskIdentity.rootCount});
  }
  fs.writeFileSync(process.argv[2],JSON.stringify({startedAt,finishedAt:new Date().toISOString(),node:process.version,scriptSha256:crypto.createHash('sha256').update(fs.readFileSync(__filename)).digest('hex'),startedFromExactProbeSha256:crypto.createHash('sha256').update(probe).digest('hex'),factsSourceSha256:crypto.createHash('sha256').update(source).digest('hex'),browser:browser.version(),kind:'isolated synthetic DOM identity controls using the actual facts callback, not a real product journey',rows},null,2)+'\n');
  console.log(`${rows.length}/${mutations.length} controls passed`);
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
