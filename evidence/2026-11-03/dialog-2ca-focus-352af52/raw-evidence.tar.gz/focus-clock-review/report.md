# Clock repair and actual continuous failures

**The four clock qualifications are a correct narrow fixture repair; both continuous product executions still fail.** Disposition is partial / ABSTAIN, not formal approval or native acceptance. No test, browser, source edit or network call was performed by this reviewer.

Exact head `352af52c42780af46c39d7732fba3f2d8c9e91a8`, tree `893e8f8e864a46e4caef989495241a723aeec895`, parent `78637f03ac92292c5f0b9742b4b20197bc4efdfe`; source SHA-256 `3bad8782fc81f3e577c1fc0c770996de31a8d840ee71a870fda502c2474fa9ba`. Full-file reconstruction proves exactly four `performance.now()` → `globalThis.performance.now()` replacements plus formatter expansion of one object literal. Prefix23,542B and suffix19,209B, commands, arguments, waits40/100/400, all assertions and product sources are otherwise unchanged.

The old bare references capture the later enclosing `const performance = await page.evaluate(...)` (current line1110). This binding is in its TDZ when the blur action wrapper starts. In both original source/packed runs at78637, the action failed before invoking `main.mouse.down`; its operations array was empty and both cleanup action wrappers failed at the same clock. The preceding native capture flows had run, so this is not a zero-execution suite. The previous narrow static review did not catch this inherited enclosing-scope issue; that report is retained as historical, not retrospectively upgraded.

## Actual epochs

| Epoch | Source ordinary / continuous | Packed ordinary / continuous | Result scope |
|---|---|---|---|
|78637,12:57:26–12:58:05UTC|exit0 / exit1|exit0 / exit1|WC default action TDZ before its down invocation|
|352af,13:12:53–13:13:35UTC|exit0 / exit1|exit0 / exit1|Numeric clocks work; separate real original assertions now fail|

Both epochs record Node24.21.0 and browser155.0.8059.39; all per-step receipt tracked statuses are clean at their respective exact heads. Build/ordinary success is separate from continuous failure.

On corrected **source default WC arm**, the actual trace contains matching trusted down/up, a native click and one outward CustomEvent, with no window blur. The original default rest getter failed **release != rest**. Session7 ends by up at browser sample12460.200ms. Existing rAF DOM samples later show release at12550.100 and rest at13077.700; post-failure state is also rest. Those later facts cannot overwrite the original getter or prove permanent stuck state. rAF callback timestamps and actual sampledAt are retained separately; no Node/browser clock mapping is claimed.

On corrected **packed default WC arm**, the default checks passed, no blur was captured, and the count changed4→5. On the following **disabled WC arm**, both false CDP commands fulfilled. Actual browser trace is down12658.300 → window-target trusted blur12720.300 → matching up12841.700 → native click12842.000 → outward CustomEvent12842.100. Contact session8 independently ends **active=false / reason=blur at12725.100**; its later frame and failure state are rest. The original failure is **blur must not activate:6 != 5**, not missing up or missing blur. No later runtime focus arms or remaining continuous flows are established.

The corrected focus rows have zero cleanupErrors. The main true restore fulfilled; the already closed auxiliary target is explicitly skipped, not called restored. `mainClosed:false` in the per-arm row precedes outer cleanup and alone does not show a resource leak.

## Ownership and next discriminating question

Draft `C-FEEDBACK-MATERIAL-0001-CONTACT` (lines46–49) requires visual cancellation and explicitly does not acquire activation ownership. Draft `C-EVENT-TYPE-0002-D/E` separates valid commit from canceled intent. The current router ends contact and emits press.cancel on blur (web-event-router.ts:512–514), while its admitted later native click path can emit press.commit (:628–647); Button emits the outward click on that commit (button.proto.ts:133–136). Thus these records establish that visual cancellation was delivered and the no-activation oracle failed. They do not yet settle the canceled activation-cycle requirement or authorize a material-level suppression change.

Pinned Playwright1.58.2 `crInput.js:134–146` sends `Input.dispatchMouseEvent(type=mouseReleased)` through the original page's CDP client. The original test does so while its auxiliary page has been brought frontmost. `isTrusted` in the captured result is real, but is not proof that the operating system routed that release to its currently active window. This is an input-prerequisite question to resolve with the existing continuous/input owner; it is not a proven engine cause.

Keep the original assertions,40/100/400 waits and deadlines. The narrow next observation, if separately authorized, is same-flow focus/visibility and native→press.cancel/press.commit→consumer callback provenance at existing ingress, including pointerId/runtime/control/session, without new input or waits. For the source release sample, preserve the failed getter and compare a timestamp around that original read with existing sampledAt phase records. No changed oracle, timeout increase, product fix or new run is proposed as already accepted.
