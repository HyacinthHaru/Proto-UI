const t="bold",_=a=>a.path({d:"M6 12h9a4 4 0 0 1 0 8H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h7a4 4 0 0 1 0 8"});export{_ as LUCIDE_BOLD_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,_ as default};
