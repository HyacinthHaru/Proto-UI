const t="circle-equal",C=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"M7 10h10"}),c.path({d:"M7 14h10"})];export{C as LUCIDE_CIRCLE_EQUAL_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,C as default};
