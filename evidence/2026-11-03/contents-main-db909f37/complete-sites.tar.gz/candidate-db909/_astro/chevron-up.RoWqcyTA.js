const t="chevron-up",C=_=>_.path({d:"m18 15-6-6-6 6"});export{C as LUCIDE_CHEVRON_UP_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,C as default};
