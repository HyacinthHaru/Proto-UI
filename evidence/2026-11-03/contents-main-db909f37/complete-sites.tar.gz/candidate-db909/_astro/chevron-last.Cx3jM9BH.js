const _="chevron-last",a=t=>[t.path({d:"m7 18 6-6-6-6"}),t.path({d:"M17 6v12"})];export{a as LUCIDE_CHEVRON_LAST_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
