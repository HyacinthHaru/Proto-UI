const C="circle-check",E=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"m9 12 2 2 4-4"})];export{E as LUCIDE_CIRCLE_CHECK_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,E as default};
