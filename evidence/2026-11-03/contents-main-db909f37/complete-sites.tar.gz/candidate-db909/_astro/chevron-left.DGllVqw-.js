const E="chevron-left",_=t=>t.path({d:"m15 18-6-6 6-6"});export{_ as LUCIDE_CHEVRON_LEFT_SHAPE_FACTORY,E as LUCIDE_ICON_NAME,_ as default};
