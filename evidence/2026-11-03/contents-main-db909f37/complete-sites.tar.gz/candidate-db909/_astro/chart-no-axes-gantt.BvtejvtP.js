const a="chart-no-axes-gantt",_=t=>[t.path({d:"M6 5h12"}),t.path({d:"M4 12h10"}),t.path({d:"M12 19h8"})];export{_ as LUCIDE_CHART_NO_AXES_GANTT_SHAPE_FACTORY,a as LUCIDE_ICON_NAME,_ as default};
