const _="arrow-left-to-line",a=t=>[t.path({d:"M3 19V5"}),t.path({d:"m13 6-6 6 6 6"}),t.path({d:"M7 12h14"})];export{a as LUCIDE_ARROW_LEFT_TO_LINE_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
