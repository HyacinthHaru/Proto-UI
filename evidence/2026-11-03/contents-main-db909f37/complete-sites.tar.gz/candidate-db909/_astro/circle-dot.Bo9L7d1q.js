const r="circle-dot",C=c=>[c.circle({cx:12,cy:12,r:10}),c.circle({cx:12,cy:12,r:1})];export{C as LUCIDE_CIRCLE_DOT_SHAPE_FACTORY,r as LUCIDE_ICON_NAME,C as default};
