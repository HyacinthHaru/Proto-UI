const c="check-check",t=C=>[C.path({d:"M18 6 7 17l-5-5"}),C.path({d:"m22 10-7.5 7.5L13 16"})];export{t as LUCIDE_CHECK_CHECK_SHAPE_FACTORY,c as LUCIDE_ICON_NAME,t as default};
