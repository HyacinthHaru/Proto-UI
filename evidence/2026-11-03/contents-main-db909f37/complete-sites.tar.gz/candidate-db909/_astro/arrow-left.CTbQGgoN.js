const _="arrow-left",a=t=>[t.path({d:"m12 19-7-7 7-7"}),t.path({d:"M19 12H5"})];export{a as LUCIDE_ARROW_LEFT_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
