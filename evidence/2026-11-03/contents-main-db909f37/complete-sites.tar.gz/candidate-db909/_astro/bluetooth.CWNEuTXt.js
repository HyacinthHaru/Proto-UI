const o="bluetooth",E=t=>t.path({d:"m7 7 10 10-5 5V2l5 5L7 17"});export{E as LUCIDE_BLUETOOTH_SHAPE_FACTORY,o as LUCIDE_ICON_NAME,E as default};
