const _="arrow-up-right",a=t=>[t.path({d:"M7 7h10v10"}),t.path({d:"M7 17 17 7"})];export{a as LUCIDE_ARROW_UP_RIGHT_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
