const _="arrow-up",a=t=>[t.path({d:"m5 12 7-7 7 7"}),t.path({d:"M12 19V5"})];export{a as LUCIDE_ARROW_UP_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
