const _="chart-no-axes-column",a=t=>[t.path({d:"M5 21v-6"}),t.path({d:"M12 21V3"}),t.path({d:"M19 21V9"})];export{a as LUCIDE_CHART_NO_AXES_COLUMN_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
