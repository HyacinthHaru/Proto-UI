const o="book",t=a=>a.path({d:"M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20"});export{t as LUCIDE_BOOK_SHAPE_FACTORY,o as LUCIDE_ICON_NAME,t as default};
