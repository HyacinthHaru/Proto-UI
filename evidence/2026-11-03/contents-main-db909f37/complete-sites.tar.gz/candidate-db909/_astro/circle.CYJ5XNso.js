const C="circle",E=c=>c.circle({cx:12,cy:12,r:10});export{E as LUCIDE_CIRCLE_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,E as default};
