import"./index.BVKZFYvx.js";import{a as m}from"./client.nHzutAOZ.js";import"./index.D5ahegtX.js";export{m as default};
