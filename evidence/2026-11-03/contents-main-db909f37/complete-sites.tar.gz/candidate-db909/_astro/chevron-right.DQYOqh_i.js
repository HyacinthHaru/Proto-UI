const _="chevron-right",C=t=>t.path({d:"m9 18 6-6-6-6"});export{C as LUCIDE_CHEVRON_RIGHT_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,C as default};
