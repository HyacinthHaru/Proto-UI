const t="circle-x",C=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"m15 9-6 6"}),c.path({d:"m9 9 6 6"})];export{C as LUCIDE_CIRCLE_X_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,C as default};
