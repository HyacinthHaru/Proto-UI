const _="chevrons-up",C=t=>[t.path({d:"m17 11-5-5-5 5"}),t.path({d:"m17 18-5-5-5 5"})];export{C as LUCIDE_CHEVRONS_UP_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,C as default};
