const _="arrow-up-left",a=t=>[t.path({d:"M7 17V7h10"}),t.path({d:"M17 17 7 7"})];export{a as LUCIDE_ARROW_UP_LEFT_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
