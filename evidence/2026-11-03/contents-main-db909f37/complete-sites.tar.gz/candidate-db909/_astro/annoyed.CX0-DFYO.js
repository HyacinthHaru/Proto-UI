const a="annoyed",c=t=>[t.circle({cx:12,cy:12,r:10}),t.path({d:"M8 15h8"}),t.path({d:"M8 9h2"}),t.path({d:"M14 9h2"})];export{c as LUCIDE_ANNOYED_SHAPE_FACTORY,a as LUCIDE_ICON_NAME,c as default};
