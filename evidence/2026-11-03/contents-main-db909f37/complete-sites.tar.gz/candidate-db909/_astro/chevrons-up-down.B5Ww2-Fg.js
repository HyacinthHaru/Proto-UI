const t="chevrons-up-down",o=_=>[_.path({d:"m7 15 5 5 5-5"}),_.path({d:"m7 9 5-5 5 5"})];export{o as LUCIDE_CHEVRONS_UP_DOWN_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,o as default};
