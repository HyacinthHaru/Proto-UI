import{i as t}from"./site-shadcn-controls.CjOg1IYn.js";t(document);document.addEventListener("astro:page-load",()=>t(document));
