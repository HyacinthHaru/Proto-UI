const _="arrow-right",a=t=>[t.path({d:"M5 12h14"}),t.path({d:"m12 5 7 7-7 7"})];export{a as LUCIDE_ARROW_RIGHT_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
