const t="chevrons-down-up",o=_=>[_.path({d:"m7 20 5-5 5 5"}),_.path({d:"m7 4 5 5 5-5"})];export{o as LUCIDE_CHEVRONS_DOWN_UP_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,o as default};
