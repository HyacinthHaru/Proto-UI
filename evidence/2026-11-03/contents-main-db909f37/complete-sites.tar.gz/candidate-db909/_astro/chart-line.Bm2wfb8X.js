const a="chart-line",_=t=>[t.path({d:"M3 3v16a2 2 0 0 0 2 2h16"}),t.path({d:"m19 9-5 5-4-4-3 3"})];export{_ as LUCIDE_CHART_LINE_SHAPE_FACTORY,a as LUCIDE_ICON_NAME,_ as default};
