const o="chevron-down",t=_=>_.path({d:"m6 9 6 6 6-6"});export{t as LUCIDE_CHEVRON_DOWN_SHAPE_FACTORY,o as LUCIDE_ICON_NAME,t as default};
