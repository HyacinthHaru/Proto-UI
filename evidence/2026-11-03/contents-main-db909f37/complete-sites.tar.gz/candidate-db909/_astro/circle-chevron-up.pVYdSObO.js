const C="circle-chevron-up",_=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"m8 14 4-4 4 4"})];export{_ as LUCIDE_CIRCLE_CHEVRON_UP_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,_ as default};
