const h="captions",C=t=>[t.rect({width:18,height:14,x:3,y:5,rx:2,ry:2}),t.path({d:"M7 15h4M15 15h2M7 11h2M13 11h4"})];export{C as LUCIDE_CAPTIONS_SHAPE_FACTORY,h as LUCIDE_ICON_NAME,C as default};
