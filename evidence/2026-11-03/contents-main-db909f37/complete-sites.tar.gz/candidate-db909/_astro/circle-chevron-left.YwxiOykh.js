const C="circle-chevron-left",E=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"m14 16-4-4 4-4"})];export{E as LUCIDE_CIRCLE_CHEVRON_LEFT_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,E as default};
