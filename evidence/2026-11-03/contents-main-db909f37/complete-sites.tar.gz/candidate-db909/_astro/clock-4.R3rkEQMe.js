const C="clock-4",_=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"M12 6v6l4 2"})];export{_ as LUCIDE_CLOCK_4_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,_ as default};
