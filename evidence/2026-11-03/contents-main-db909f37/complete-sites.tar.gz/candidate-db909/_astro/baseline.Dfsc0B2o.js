const a="baseline",E=t=>[t.path({d:"M4 20h16"}),t.path({d:"m6 16 6-12 6 12"}),t.path({d:"M8 12h8"})];export{E as LUCIDE_BASELINE_SHAPE_FACTORY,a as LUCIDE_ICON_NAME,E as default};
