const E="chevrons-left",_=t=>[t.path({d:"m11 17-5-5 5-5"}),t.path({d:"m18 17-5-5 5-5"})];export{_ as LUCIDE_CHEVRONS_LEFT_SHAPE_FACTORY,E as LUCIDE_ICON_NAME,_ as default};
