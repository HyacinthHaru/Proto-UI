const _="battery-low",a=t=>[t.path({d:"M22 14v-4"}),t.path({d:"M6 14v-4"}),t.rect({x:2,y:6,width:16,height:12,rx:2})];export{a as LUCIDE_BATTERY_LOW_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
