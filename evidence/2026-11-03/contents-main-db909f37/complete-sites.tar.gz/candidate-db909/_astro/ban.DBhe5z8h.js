const t="ban",_=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"M4.929 4.929 19.07 19.071"})];export{_ as LUCIDE_BAN_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,_ as default};
