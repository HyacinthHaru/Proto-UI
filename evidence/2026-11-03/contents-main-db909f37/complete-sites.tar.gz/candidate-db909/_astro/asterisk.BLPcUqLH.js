const a="asterisk",E=t=>[t.path({d:"M12 6v12"}),t.path({d:"M17.196 9 6.804 15"}),t.path({d:"m6.804 9 10.392 6"})];export{E as LUCIDE_ASTERISK_SHAPE_FACTORY,a as LUCIDE_ICON_NAME,E as default};
