const e="battery",E=t=>[t.path({d:"M 22 14 L 22 10"}),t.rect({x:2,y:6,width:16,height:12,rx:2})];export{E as LUCIDE_BATTERY_SHAPE_FACTORY,e as LUCIDE_ICON_NAME,E as default};
