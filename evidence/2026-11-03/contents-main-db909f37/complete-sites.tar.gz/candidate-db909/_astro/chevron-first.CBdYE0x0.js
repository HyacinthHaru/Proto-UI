const _="chevron-first",C=t=>[t.path({d:"m17 18-6-6 6-6"}),t.path({d:"M7 6v12"})];export{C as LUCIDE_CHEVRON_FIRST_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,C as default};
