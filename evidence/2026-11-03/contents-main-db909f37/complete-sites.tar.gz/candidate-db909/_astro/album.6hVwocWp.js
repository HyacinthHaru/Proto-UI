const e="album",o=t=>[t.rect({width:18,height:18,x:3,y:3,rx:2,ry:2}),t.polyline({points:"11 3 11 11 14 8 17 11 17 3"})];export{o as LUCIDE_ALBUM_SHAPE_FACTORY,e as LUCIDE_ICON_NAME,o as default};
