const C="circle-slash",_=c=>[c.circle({cx:12,cy:12,r:10}),c.line({x1:9,x2:15,y1:15,y2:9})];export{_ as LUCIDE_CIRCLE_SLASH_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,_ as default};
