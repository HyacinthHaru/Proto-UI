const _="arrow-down-right",a=t=>[t.path({d:"m7 7 10 10"}),t.path({d:"M17 7v10H7"})];export{a as LUCIDE_ARROW_DOWN_RIGHT_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
