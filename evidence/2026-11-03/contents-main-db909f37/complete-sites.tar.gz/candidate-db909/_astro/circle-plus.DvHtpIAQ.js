const t="circle-plus",C=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"M8 12h8"}),c.path({d:"M12 8v8"})];export{C as LUCIDE_CIRCLE_PLUS_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,C as default};
