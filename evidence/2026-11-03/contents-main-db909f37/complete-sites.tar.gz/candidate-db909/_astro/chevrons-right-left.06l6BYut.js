const _="chevrons-right-left",E=t=>[t.path({d:"m20 17-5-5 5-5"}),t.path({d:"m4 17 5-5-5-5"})];export{E as LUCIDE_CHEVRONS_RIGHT_LEFT_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,E as default};
