const _="circle-arrow-up",r=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"m16 12-4-4-4 4"}),c.path({d:"M12 16V8"})];export{r as LUCIDE_CIRCLE_ARROW_UP_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,r as default};
