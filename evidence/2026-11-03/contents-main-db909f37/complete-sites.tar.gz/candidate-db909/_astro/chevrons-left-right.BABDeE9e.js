const _="chevrons-left-right",E=t=>[t.path({d:"m9 7-5 5 5 5"}),t.path({d:"m15 7 5 5-5 5"})];export{E as LUCIDE_CHEVRONS_LEFT_RIGHT_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,E as default};
