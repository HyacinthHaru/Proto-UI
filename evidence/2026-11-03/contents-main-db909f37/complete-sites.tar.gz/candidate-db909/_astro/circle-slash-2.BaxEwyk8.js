const _="circle-slash-2",C=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"M22 2 2 22"})];export{C as LUCIDE_CIRCLE_SLASH_2_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,C as default};
