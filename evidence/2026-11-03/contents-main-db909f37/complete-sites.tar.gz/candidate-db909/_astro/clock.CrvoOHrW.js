const C="clock",t=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"M12 6v6l4 2"})];export{t as LUCIDE_CLOCK_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,t as default};
