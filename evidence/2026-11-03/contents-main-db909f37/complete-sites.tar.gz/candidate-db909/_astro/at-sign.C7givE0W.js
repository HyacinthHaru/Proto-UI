const c="at-sign",t=a=>[a.circle({cx:12,cy:12,r:4}),a.path({d:"M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8"})];export{t as LUCIDE_AT_SIGN_SHAPE_FACTORY,c as LUCIDE_ICON_NAME,t as default};
