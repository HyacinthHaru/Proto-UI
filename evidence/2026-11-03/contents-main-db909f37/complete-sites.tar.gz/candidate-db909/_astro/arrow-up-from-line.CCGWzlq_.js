const t="arrow-up-from-line",a=_=>[_.path({d:"m18 9-6-6-6 6"}),_.path({d:"M12 3v14"}),_.path({d:"M5 21h14"})];export{a as LUCIDE_ARROW_UP_FROM_LINE_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,a as default};
