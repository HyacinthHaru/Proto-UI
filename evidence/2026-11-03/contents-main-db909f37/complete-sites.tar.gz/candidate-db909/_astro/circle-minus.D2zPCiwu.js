const C="circle-minus",_=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"M8 12h8"})];export{_ as LUCIDE_CIRCLE_MINUS_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,_ as default};
