# 补记：纯 main796 与 db909 的两个实际对照

本补记补充了先前尚未取得的纯 main 生产构建、原准入及窄屏几何对照。此前的 `report.md` 和 `graph-report.json` 保留原字节与其当时观察范围。

| 实际产物 | 源对象 | producer | 完整文件与字节 | 原生产 bundle gate |
| --- | --- | --- | --- | --- |
| 纯 main | `7969265c2104464acac2ac761b46906e7570f320` / tree `e0d909f63bd13467c3d56c77f342370155a0d1ef` | `docs:build` exit 0，655 页 | 3,981 文件，112,943,844 B | exit 1，51 条 |
| #1212 合并组合 | `db909f378c978aae024b5658631208dfb031c6a5` / tree `ae306ec4172a5e959b746aa1e683f35c192c756b` | `docs:build` exit 0，655 页 | 3,981 文件，112,943,869 B | exit 1，51 条 |

纯 main 安装按主代理的实际执行记录使用 offline/frozen，安装日志记录 lockfile 已是当前版本、跳过 resolution、338ms 完成。此次离线审阅分别按每棵树的完整 manifest 复算全部实际文件摘要，核对了两份 build log 和各自两条预览路由的原 HTML。两棵树各自的 graph SHA-256 为 `dc8cd4f1f67916b0a13ebedffbb8f56cc8867cbb15c0d5831fe1fc96a899db25`、`de47cb7bc7799327d88a1853d446cde50657d79f904d4504d7dbe61e720740e4`。两份 graph 的 5,757 个 resolved module/import 记录逐项相等。完整输出目录净差 25 B，不能按此推成相同产物。两份已执行的原 gate 日志则逐字相同，均为 17,613 B，SHA-256 `f6785f159327ac1ce78162bba85a3f8a3934339b38315af60a56e7185d6d6d9e`。因此本次 51 条原准入失败在未加五行 CSS 的纯 main 上同样存在。

## 同一个窄屏行为脚本

两个 native 对照均使用 `probe.cjs` SHA-256 `69b33f7f14db1917a8fce12794d842fb40c7ff6937d658245730d64985de1c6c`、Chrome 155.0.8059.39、390×844 / DPR1。两族 × 四 runtime 的每份原测量单独与 summary 反查。每次运行读取的是自己产物的真实 served HTML，所有 context 的记录均绑定各自 clean head/tree。

| 对照 | 首次闭合 mount / 标题 y | 实际执行范围 | 图和事件 |
| --- | --- | --- | --- |
| 纯 `7969265c` | 八组均 28px / 108px | 0/8 通过。八组都在首个 `closed-narrow` 的 `28 !== 0` 停止，只生成 closed-narrow 和失败记录 | 16 原 PNG，pageerror 与 requestfailed 记录均 0 |
| `db909f37` | 八组均 0px / 80px | 8/8 通过，均跑完九阶段，包括两轮真实开关/还焦、内部滚轮、1440×960 归还及窄屏重开。八组内部 scrollTop 均实际增加 400px，body scrollY 保持 0 | 72 原 PNG，pageerror 与 requestfailed 记录均 0 |

88 个 PNG 已按各自原 JSON 文件名核对存在性、尺寸与全文件 chunk CRC。这是采集文件核对，不增加新的像素审阅声明。相同 main 的源码差异只有 `PageFrame.astro` 五行，实测结果支持该 CSS 对闭合挂载区 28px 留白的修复。该补充脚本的九阶段成功与原浏览器断言必须分开：`db909` 上原 `homepage-dogfood.browser.test.ts:954` 的立即 sidebar count 仍为 0 对 1，实际 1 fail / 8 filtered。两组几何结果亦不改变上表的生产 bundle gate。

## 两条待 owner 评审的登记

我另用 Node 24.21 在内存加载原 checker 与只添加两条精确集合成员的变体，对两份已冻结的实际 graph 独立重放。两棵树的原 checker SHA 都是 `c3271e1f86a9b739fc50b9c82993a10f37799fab175964574a64bd504730d9a7`，两项联合提案文本 SHA 为 `53cad2c65ce6c523240086c57ebc8fa5a45061fac1bf1d72eed206bed07ac72f`。四臂结果在两份图上完全一致。

| 分类输入 | 每个图上的 issue 数 |
| --- | ---: |
| 原规则 | 51 |
| 仅将 Adapter 的 `events/pointer-sample.ts` 加入现有 WC bridge 的有限叶集合 | 3 |
| 仅将 `command-no-addon.astro?astro&type=script&index=0&lang.ts` 加入现有 demonstration facade 集合 | 49 |
| 两项同时加到内存副本 | 2 |

联合重放留下的两项是 `liquid-tint-stage-diagnostic.astro`、`liquid-visible-refraction-diagnostic.astro` 对五个低层 optics 模块的真实静态到达。提案的第一项只涉及 #1190/#1132 的单个无依赖物理 getter helper 与三个已知 Adapter 调用者。第二项只涉及 #1183/#989 的无 addon Command 测试路由及其现有码以 renderer 动态取得的四 Runtime 边界。可将这两项及其独立负控交 #420 消费墙 owner 评审。源 checker、allowlist、工作流与冻结图都保持其实际绑定，两种正式 gate 的状态仍为失败。该内存分类没有生成新的通过、校准或所有权批准。

完整来源为 `addendum-796-controls.json` 与 `addendum-counterfactual.json`。本次为只读审阅，partial / ABSTAIN。
