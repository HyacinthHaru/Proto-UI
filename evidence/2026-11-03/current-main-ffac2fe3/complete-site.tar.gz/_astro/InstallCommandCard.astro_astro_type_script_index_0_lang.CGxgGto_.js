import{i as t}from"./site-shadcn-controls.76uBI95_.js";t(document);document.addEventListener("astro:page-load",()=>t(document));
