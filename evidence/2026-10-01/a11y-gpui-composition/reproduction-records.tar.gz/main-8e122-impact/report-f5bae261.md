# main f5bae261 与已批准 17a2cff9 的组合影响

本次只读审计将先前 #711 的风险更新到最新 main `f5bae261491368b586959f1d8b353cf372775221`（#712，parent `8e122e27b93015c91fe22e3b7ccebc6206f7f0c0`）。已批准 feature 仍为 `17a2cff98080eb57f9070a6f45d89b58d3a72c3f`，工作树干净。本 Agent 未运行测试、构建、fetch、merge 或 GitHub 写入。

**风险在最新 main 仍存在。** #711/#712 从共同 base `0e455a38ea1397c225e6a72d2d43b5f76da02cdc` 共改变 13 个路径，#688 共改变 47 个路径，两组路径交集为空。`host_hub.rs`、`hub.rs` 和相关 model/serde 定义在 8e 与 f5 的 blob 完全相同；无直接文本重叠不能排除 fixture 的运行时消费关系。

- feature fixture 的 enabled 序列从 13 条变为 14 条，在 zero-based index 4（JSON 第 49–51 行）新增 `a11y.snapshot`、`viewEpoch: 0`；disabled 从 14 条变为 15 条，在 index 5（第 303–305 行）新增同类消息。
- 移除且仅移除这两条新 envelope 后，新旧 fixture 的**整个 JSON 对象深度相等**。已有 lifecycle/expose 消息、projection.install transaction、install/activate epoch、lease ID、ready surfaces 以及所有其他字段均不变。main fixture 与共同 base 字节相同。
- [host_hub.rs:26–37](https://github.com/Proto-UI/Proto-UI/blob/f5bae261491368b586959f1d8b353cf372775221/native/gpui/crates/proto-ui-gpui/tests/host_hub.rs#L26-L37) 完整反序列化 enabled 序列，不过滤早期 snapshot。[messages.rs:244–250](https://github.com/Proto-UI/Proto-UI/blob/f5bae261491368b586959f1d8b353cf372775221/native/gpui/crates/proto-ui-host-protocol/src/messages.rs#L244-L250) 的 `view_epoch` 是 [u64](https://github.com/Proto-UI/Proto-UI/blob/f5bae261491368b586959f1d8b353cf372775221/native/gpui/crates/proto-ui-host-protocol/src/wire.rs#L17)，因此 0 正常解码；不是 serde 格式失败。
- 新 session 的 [current_epoch 初始化为 None](https://github.com/Proto-UI/Proto-UI/blob/f5bae261491368b586959f1d8b353cf372775221/native/gpui/crates/proto-ui-host-protocol/src/model.rs#L130-L135)。[hub.rs:302–309](https://github.com/Proto-UI/Proto-UI/blob/f5bae261491368b586959f1d8b353cf372775221/native/gpui/crates/proto-ui-gpui/src/hub.rs#L302-L309) 对 epoch 0 留下 `SnapshotRefused { session_id: "button-enabled", view_epoch: 0, installed: None }`。
- [成功安装](https://github.com/Proto-UI/Proto-UI/blob/f5bae261491368b586959f1d8b353cf372775221/native/gpui/crates/proto-ui-gpui/src/hub.rs#L474-L485) 和 activate 不清 notes；`take_outbox()` 也不清 notes，只有 [take_notes()](https://github.com/Proto-UI/Proto-UI/blob/f5bae261491368b586959f1d8b353cf372775221/native/gpui/crates/proto-ui-gpui/src/hub.rs#L397-L400) 会清。因此源码预测失败断言是 [host_hub.rs:247](https://github.com/Proto-UI/Proto-UI/blob/f5bae261491368b586959f1d8b353cf372775221/native/gpui/crates/proto-ui-gpui/tests/host_hub.rs#L228-L248) 的 `assert!(hub.notes().is_empty());`。

最小组合命令（由 root 在隔离树执行；本 Agent 不执行）：

```sh
cargo test --manifest-path native/gpui/Cargo.toml -p proto-ui-gpui --test host_hub the_recorded_install_is_acknowledged_with_the_surfaces_it_needs -- --exact
```

root 已另行报告实际执行：原 f5 fixture 对照 1 pass / exit 0，仅换为精确 17a fixture 后 1 fail / exit 101，位置正是第 247 行。执行事实应引用 [root 独立收据](../main-f5-composition/receipt.json)，不能把本静态审计冒称执行结果。

旧六项浏览器探针确实在 17a 执行；其 315 个 tracked bundle inputs（340 个不同 bundle 输入中的已跟踪部分） 与 main 新增的 13 个改动路径交集为空。这说明新的 GPUI host_hub/T0 路径不在这些浏览器证据的覆盖中，不能据此把完整组合头宣称为已验证。

完整 blob、SHA-256、字节数、全部 fixture 顺序、路径比较和源读取命令保存在 [facts-f5bae261.json](./facts-f5bae261.json)。该审计不判定拒绝行为或测试期望哪一侧应修改，不弱化既有 retired-view snapshot/null 拒绝覆盖，也不作合并许可或完整 #711/#712 审查结论。
