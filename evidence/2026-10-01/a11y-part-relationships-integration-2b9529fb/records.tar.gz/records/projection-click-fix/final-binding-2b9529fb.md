# 最终提交 2b9529fb 的只读源码绑定

**全部核对通过。** 新提交 `2b9529fb8236b6051128d857cf4a1309bed91b84` / tree `a6236e383f9e902c64f5a2356a7ccc39db10d4ae` 的唯一 parent 是 `8595a59165635be05cf83c610904859442cc58a8`。工作树读取前后干净稳定；本轮没有运行 test/build/browser，也没有 GitHub 写入。

相对 parent 仅改 `apps/www/src/content/docs/zh-cn/prototype-projection-scope.browser.test.ts` 一行：`await option.click({ force: true });` → `await option.click();`。实际 diff 为 1 insertion / 1 deletion，无其他变化。新测试 blob 为 **`2dd3d4eb07a2e06e2cdce6144c5816cb2eb9d213`**，SHA-256 为 **`0ccd09ca92bb3356ac4b123460573b46d6e35ebbe45fa77894b0e9a705eb2d35`**；root 保存的 candidate 和 native-control 保存的 candidate 两份原字节都与提交完全相同。

| 对账范围 | 结果 |
| --- | --- |
| 8595 既有 Web tracked bundle inputs | 315/315 blob 与 SHA-256 相同 |
| 原 #549 的非 fixture 文件 | 46/46 与 8595／已批准 17a blob 相同 |
| GPUI session/test/generated fixture 三文件 | 3/3 blob、SHA-256 相同 |
| 相对 f5 的净路径 | 实际 49，准确等于旧 48 路径加本次浏览器测试路径 |

`git verify-commit --raw` 返回 0，确认 SSH ED25519 签名，signer `hyacinth@haru.ac`。Author 和 Committer 均为 `HyacinthHaru <hyacinth@haru.ac>`；DCO trailer 准确匹配，无 co-author trailer。提交时间 `2026-10-02T03:14:23+08:00`，标题 `test(www): wait for projection option actionability`。

**19:11 的 native-control 是提交前运行。** 其实际时间为 `2026-10-01T19:11:34.992097+00:00` 至 `2026-10-01T19:12:27.828743+00:00`，当时 HEAD 为 8595，工作区候选 SHA 为 0ccd，并临时加入已保存的输入诊断源码。现在只是把保存的 candidate 原字节绑定到 2b；实际 diagnostic-test SHA 另存，不能把图片/事件重标为提交后运行。原图 SHA `ff0b9df18f23d321f081f5b3ce26b1c6f078f459d17bc21e4a131d65545b8e2a` 与已有视觉审阅仍一致。

9 月 29 日六 Web probes、57 PNG、132 AX 同样保留原 17a 运行来源。315 个产品输入相同不包含那 21 个第三方依赖与 4 个外部 fixture，也不构成新提交上的新浏览器运行。完整测试、CI 和独立批准依其各自收据，本绑定不代替它们。

逐路径对照、准确 commands、身份/签名结果和 precommit 来源在 [final-binding-2b9529fb.json](final-binding-2b9529fb.json)。
