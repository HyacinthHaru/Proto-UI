# 无 force 候选的原生输入对照

**本次唯一运行 5 passed，exit 0；Brutalist Switch 和 Select 的真实输入均命中对应 option，并产生对应 valueChange。** 使用原路径/config/五 case 顺序、原断言与 timeout；输入监听块与原红控制逐字一致。唯一动作改动是 `option.click()` 去掉 force。最终图/DOM/AX/controller 只在 case2 全部原动作断言结束后采集。

源为 8595 产品加 root 的一行测试候选，candidate SHA `0ccd09ca92bb3356ac4b123460573b46d6e35ebbe45fa77894b0e9a705eb2d35`。实际执行时间 **2026-10-01 19:11:34.992–19:12:27.828 UTC**，case2 4030 ms。

| 输入 | 原生实际目标 | 后续语义事件 |
| --- | --- | --- |
| gen5 Switch，2939.7 ms，(1061,336) | `WC-BRUTALIST-SELECT-ITEM` / option / Switch | 2960.6 ms：valueChange switch |
| gen6 Select，3325.4 ms，(1061,496) | `WC-BRUTALIST-SELECT-ITEM` / option / Select | 3335.4 ms：valueChange select |

总计 61 条记录：18 个可信 pointerdown、18 pointerup、18 click，以及 7 个非可信 WC valueChange。与红控制中最后点击落在 Button 内容 DIV、没有后续记录值事件的链形成明确对照；不把具体 animation/flip 几何原因称为已测。

最终 controller 为 WC/Brutalist generation 7、ready，唯一 content 为 Select。已实际查看 [success.png](../../../screenshots/projection-click-fix/native-control/capture/success.png) 并核对 DOM/AX：Select/Paper 已显示，Paper/Ink popup 处在关闭淡出帧，不写成稳定打开菜单；原 dev toolbar 保留。图片 SHA：`ff0b9df18f23d321f081f5b3ce26b1c6f078f459d17bc21e4a131d65545b8e2a`。

执行后逐字恢复的是 **0ccd 候选**，没有回滚旧 8eab；仍只有 root 的预期一行测试 diff。exec 84204 / PID 58870 及对应 server 已结束，重资源已释放。没有追加运行。详见 [summary.json](summary.json)、[execution-receipt.json](execution-receipt.json)、[capture/positive-input-events.json](capture/positive-input-events.json) 与 [run.log](run.log)。本对照不代替后续完整未诊断验收、CI 或独立批准。
