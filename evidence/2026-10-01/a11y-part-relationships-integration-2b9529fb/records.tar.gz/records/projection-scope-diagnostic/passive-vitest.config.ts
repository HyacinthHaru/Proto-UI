import { mergeConfig } from '/__SOURCE_ROOT__/node_modules/vitest/dist/config.js';
import base from '/__SOURCE_ROOT__/vitest.config.ts';
export default mergeConfig(base, {
  root: '/__SOURCE_ROOT__',
  test: {
    include: [
      '/__EVIDENCE_ROOT__/peer-snapshot-fix/projection-scope-diagnostic/passive-case2.browser.test.ts',
    ],
  },
});
