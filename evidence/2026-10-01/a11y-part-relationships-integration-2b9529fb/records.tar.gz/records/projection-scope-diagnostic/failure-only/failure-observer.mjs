import fs from 'node:fs/promises';
import path from 'node:path';

const output = process.env.PROJECTION_FAILURE_OUTPUT;
const pages = new WeakMap();

export async function startFailureObserver(page, readIntent) {
  const record = {
    startedAt: new Date().toISOString(),
    consoleErrors: [],
    pageErrors: [],
    networkErrors: [],
  };
  pages.set(page, record);
  page.on('console', (message) => {
    if (message.type() !== 'error' && message.type() !== 'warning') return;
    record.consoleErrors.push({
      at: Date.now(),
      intent: { ...readIntent() },
      type: message.type(),
      text: message.text(),
      location: message.location(),
    });
  });
  page.on('pageerror', (error) =>
    record.pageErrors.push({
      at: Date.now(),
      intent: { ...readIntent() },
      message: error.message,
      stack: error.stack,
    })
  );
  page.on('requestfailed', (request) =>
    record.networkErrors.push({
      at: Date.now(),
      intent: { ...readIntent() },
      type: 'requestfailed',
      url: request.url(),
      error: request.failure()?.errorText,
    })
  );
  page.on('response', (response) => {
    if (response.status() >= 400)
      record.networkErrors.push({
        at: Date.now(),
        intent: { ...readIntent() },
        type: 'http-error',
        url: response.url(),
        status: response.status(),
      });
  });
  await page.addInitScript(() => {
    const keys = [
      'id',
      'role',
      'aria-label',
      'data-demo-ref',
      'data-value',
      'data-collection-index',
      'data-collection-total',
      'data-projection-runtime',
      'data-projection-family',
      'data-projection-generation',
      'data-projection-prototype',
      'data-projection-id',
      'data-projection-owner',
      'aria-expanded',
      'aria-controls',
    ];
    const shallow = (node) => {
      if (!(node instanceof Element)) return null;
      return {
        tag: node.tagName,
        attrs: Object.fromEntries(
          keys.map((key) => [key, node.getAttribute(key)]).filter(([, value]) => value !== null)
        ),
      };
    };
    const evidence = { timeOrigin: performance.timeOrigin, events: [] };
    window.__puiFailureOnlyEventEvidence = evidence;
    for (const type of [
      'pointerdown',
      'pointerup',
      'mousedown',
      'mouseup',
      'click',
      'valueChange',
    ]) {
      document.addEventListener(
        type,
        (event) => {
          evidence.events.push({
            timeStamp: event.timeStamp,
            type: event.type,
            isTrusted: event.isTrusted,
            clientX: event.clientX,
            clientY: event.clientY,
            button: event.button,
            buttons: event.buttons,
            detailValue: event instanceof CustomEvent ? event.detail?.value : undefined,
            target: shallow(event.target),
            path: event
              .composedPath()
              .filter((node) => node instanceof Element)
              .slice(0, 6)
              .map(shallow),
          });
        },
        { capture: true, passive: true }
      );
    }
  });
}

async function finalState(page, failed) {
  return page.evaluate((full) => {
    const outer = document.querySelector('.home-demo-previewer[data-home-demo-options]');
    const describe = (element) => {
      const attributes = Object.fromEntries([...element.attributes].map((a) => [a.name, a.value]));
      const result = {
        tag: element.tagName,
        attrs: attributes,
        connected: element.isConnected,
        inert: element.inert,
      };
      if (full) {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        Object.assign(result, {
          text: element.textContent,
          rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
          style: {
            display: style.display,
            visibility: style.visibility,
            opacity: style.opacity,
            pointerEvents: style.pointerEvents,
            transform: style.transform,
          },
        });
      }
      return result;
    };
    return {
      evidence: window.__puiFailureOnlyEventEvidence,
      observedAt: Date.now(),
      fullFailureCollection: full,
      outer: outer ? describe(outer) : null,
      runnerState: outer?.getAttribute('data-runner-state'),
      projectionComponent: outer?.getAttribute('data-projection-component'),
      ariaBusy: outer?.getAttribute('aria-busy'),
      statusText: document.querySelector('[data-home-demo-status]')?.textContent,
      controllerSnapshot: full ? outer?.__homeProjection__?.getSnapshot() : undefined,
      scopes: [...document.querySelectorAll('[data-projection-scope]')].map(describe),
      generationHosts: [...document.querySelectorAll('[data-projection-generation-host]')].map(
        describe
      ),
      contents: [...document.querySelectorAll('[data-projection-content]')].map(describe),
      controls: [...document.querySelectorAll('[data-projection-control]')].map((element) => ({
        surface: describe(element),
        triggers: [...element.querySelectorAll('[role="combobox"]')].map(describe),
      })),
    };
  }, failed);
}

export async function collectOutcome(page, intent, intentHistory, error) {
  const failed = Boolean(error);
  const record = pages.get(page);
  const name = failed ? 'failure' : 'success';
  await fs.mkdir(output, { recursive: true });
  Object.assign(record, {
    finishedAt: new Date().toISOString(),
    outcome: name,
    intent: { ...intent },
    intentHistory,
    error: failed ? { message: String(error), stack: error.stack } : null,
  });
  const observations = await finalState(page, failed);
  await fs.writeFile(
    path.join(output, `${name}-observations.json`),
    JSON.stringify({ ...record, observations }, null, 2) + '\n'
  );
  if (failed) {
    await fs.writeFile(path.join(output, 'failure.html'), await page.content());
    const client = await page.context().newCDPSession(page);
    try {
      await client.send('Accessibility.enable');
      await fs.writeFile(
        path.join(output, 'failure-ax.json'),
        JSON.stringify(await client.send('Accessibility.getFullAXTree'), null, 2) + '\n'
      );
    } finally {
      await client.detach();
    }
    await page.screenshot({ path: path.join(output, 'failure.png'), fullPage: true });
  }
}

export async function recordCollectionError(error) {
  await fs.mkdir(output, { recursive: true });
  await fs.writeFile(
    path.join(output, 'collection-error.json'),
    JSON.stringify({ message: String(error), stack: error?.stack }, null, 2) + '\n'
  );
}
