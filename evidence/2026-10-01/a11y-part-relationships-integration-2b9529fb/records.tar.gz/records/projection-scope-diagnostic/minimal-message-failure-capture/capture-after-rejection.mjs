import fs from 'node:fs/promises';
import path from 'node:path';

export async function captureAfterRejection({
  page,
  componentId,
  diagnosticLabel,
  error,
  caughtAt,
}) {
  const output = process.env.PROJECTION_POLL_FAILURE_OUTPUT;
  await fs.mkdir(output, { recursive: true });
  const metadata = {
    caughtAt,
    helperStartedAt: new Date().toISOString(),
    requestedComponent: componentId,
    diagnosticLabel,
    error: {
      message: String(error),
      stack: error?.stack,
      cause: error?.cause ? String(error.cause) : null,
    },
    limitation:
      'All observations occur after the original 30000ms poll rejected. They are not samples of the actual click or its last poll, and no earlier input events were observed.',
  };
  await fs.writeFile(
    path.join(output, 'failure-start.json'),
    JSON.stringify(metadata, null, 2) + '\n'
  );
  const state = await page.evaluate((requestedComponent) => {
    const scopes = [...document.querySelectorAll('[data-projection-scope]')];
    const node = (element) => {
      if (!(element instanceof Element)) return null;
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      const scope = element.closest('[data-projection-scope]');
      return {
        tag: element.tagName,
        attributes: Object.fromEntries(
          [...element.attributes].map((attr) => [attr.name, attr.value])
        ),
        connected: element.isConnected,
        hidden: element.hidden,
        inert: element.inert,
        text: element.textContent,
        closestScopeIndex: scopes.indexOf(scope),
        rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
        style: {
          display: style.display,
          visibility: style.visibility,
          opacity: style.opacity,
          pointerEvents: style.pointerEvents,
          transform: style.transform,
          transitionProperty: style.transitionProperty,
          transitionDuration: style.transitionDuration,
          animationName: style.animationName,
          animationDuration: style.animationDuration,
        },
      };
    };
    const exposure = (element) => {
      if (!element || typeof element.getExposes !== 'function') return { available: false };
      try {
        const exposed = element.getExposes();
        return Object.fromEntries(
          ['value', 'open', 'disabled'].map((name) => {
            const value = exposed?.[name];
            if (value && typeof value.get === 'function') {
              try {
                return [name, { available: true, value: value.get() }];
              } catch (error) {
                return [name, { available: true, readError: String(error) }];
              }
            }
            return [name, { available: false }];
          })
        );
      } catch (error) {
        return { available: true, readError: String(error) };
      }
    };
    const option = (element) => ({
      ...node(element),
      selected: element.getAttribute('aria-selected'),
      disabled: element.getAttribute('aria-disabled'),
      hovered: element.hasAttribute('data-hovered'),
      pressed: element.hasAttribute('data-pressed'),
    });
    const requestedSelector = `[data-projection-content][data-projection-id=${JSON.stringify(requestedComponent)}]`;
    return {
      sampledAt: new Date().toISOString(),
      performanceTimeOrigin: performance.timeOrigin,
      performanceNow: performance.now(),
      requestedSelector,
      firstLocatorScopeIndex: scopes.length ? 0 : null,
      firstLocatorScopeOwner: scopes[0]?.getAttribute('data-projection-scope'),
      firstScopeRequestedCountAfterRejection:
        scopes[0]?.querySelectorAll(requestedSelector).length ?? 0,
      wholePageRequestedCountAfterRejection: document.querySelectorAll(requestedSelector).length,
      outers: [...document.querySelectorAll('.home-demo-previewer[data-home-demo-options]')].map(
        (element) => ({
          ...node(element),
          runnerState: element.getAttribute('data-runner-state'),
          projectionComponent: element.getAttribute('data-projection-component'),
          ariaBusy: element.getAttribute('aria-busy'),
          statusText: element.querySelector('[data-home-demo-status]')?.textContent,
          controllerSnapshot: element.__homeProjection__?.getSnapshot(),
        })
      ),
      scopes: scopes.map((element, index) => ({
        ...node(element),
        index,
        requestedCount: element.querySelectorAll(requestedSelector).length,
        contents: [...element.querySelectorAll('[data-projection-content]')].map(node),
      })),
      generationHosts: [...document.querySelectorAll('[data-projection-generation-host]')].map(
        node
      ),
      allContents: [...document.querySelectorAll('[data-projection-content]')].map(node),
      componentControls: [
        ...document.querySelectorAll('[data-projection-control="component"]'),
      ].map((surface) => ({
        surface: node(surface),
        roots: [
          ...surface.querySelectorAll('[data-demo-ref="__pui_projection__component_root"]'),
        ].map((element) => ({ node: node(element), publicExposes: exposure(element) })),
        triggers: [...surface.querySelectorAll('[role="combobox"]')].map((trigger) => {
          const id = trigger.getAttribute('aria-controls');
          const portal = id ? document.getElementById(id) : null;
          return {
            node: node(trigger),
            controlledId: id,
            controlledPortal: node(portal),
            options: portal ? [...portal.querySelectorAll('[role="option"]')].map(option) : [],
          };
        }),
      })),
      allListboxes: [...document.querySelectorAll('[role="listbox"]')].map((element) => ({
        node: node(element),
        options: [...element.querySelectorAll('[role="option"]')].map(option),
      })),
      activeElement: node(document.activeElement),
    };
  }, componentId);
  await fs.writeFile(
    path.join(output, 'failure-state.json'),
    JSON.stringify({ ...metadata, state }, null, 2) + '\n'
  );
  const domCapturedAt = new Date().toISOString();
  await fs.writeFile(path.join(output, 'failure.html'), await page.content());
  const client = await page.context().newCDPSession(page);
  let axCapturedAt;
  try {
    await client.send('Accessibility.enable');
    axCapturedAt = new Date().toISOString();
    await fs.writeFile(
      path.join(output, 'failure-ax.json'),
      JSON.stringify(await client.send('Accessibility.getFullAXTree'), null, 2) + '\n'
    );
  } finally {
    await client.detach();
  }
  const screenshotStartedAt = new Date().toISOString();
  await page.screenshot({ path: path.join(output, 'failure.png'), fullPage: true });
  await fs.writeFile(
    path.join(output, 'capture-timing.json'),
    JSON.stringify(
      {
        caughtAt,
        helperStartedAt: metadata.helperStartedAt,
        stateSampledAt: state.sampledAt,
        domCapturedAt,
        axCapturedAt,
        screenshotStartedAt,
        finishedAt: new Date().toISOString(),
        limitation: metadata.limitation,
      },
      null,
      2
    ) + '\n'
  );
}
