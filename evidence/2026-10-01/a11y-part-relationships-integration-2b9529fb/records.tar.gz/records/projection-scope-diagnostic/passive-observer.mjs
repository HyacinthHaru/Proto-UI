import fs from 'node:fs/promises';
import path from 'node:path';

const output = process.env.PROJECTION_DIAGNOSTIC_OUTPUT;
const pages = new WeakMap();

export function passiveEnabled(page) {
  return pages.has(page);
}

export async function setupPassive(page) {
  const record = {
    startedAt: new Date().toISOString(),
    stage: 'navigation',
    console: [],
    pageErrors: [],
    requests: [],
    checkpoints: [],
    captures: [],
  };
  pages.set(page, record);
  page.on('console', (message) =>
    record.console.push({
      at: new Date().toISOString(),
      stage: record.stage,
      type: message.type(),
      text: message.text(),
      location: message.location(),
    })
  );
  page.on('pageerror', (error) =>
    record.pageErrors.push({
      at: new Date().toISOString(),
      stage: record.stage,
      message: error.message,
      stack: error.stack,
    })
  );
  page.on('request', (request) =>
    record.requests.push({
      at: new Date().toISOString(),
      stage: record.stage,
      event: 'request',
      url: request.url(),
      method: request.method(),
      type: request.resourceType(),
    })
  );
  page.on('response', (response) =>
    record.requests.push({
      at: new Date().toISOString(),
      stage: record.stage,
      event: 'response',
      url: response.url(),
      status: response.status(),
    })
  );
  page.on('requestfailed', (request) =>
    record.requests.push({
      at: new Date().toISOString(),
      stage: record.stage,
      event: 'failed',
      url: request.url(),
      error: request.failure()?.errorText,
    })
  );
  await page.addInitScript(() => {
    const attributes = (element) =>
      element ? Object.fromEntries([...element.attributes].map((a) => [a.name, a.value])) : null;
    const node = (element, geometry = false) => {
      if (!(element instanceof Element)) return null;
      const result = {
        connected: element.isConnected,
        inert: element.inert,
        tag: element.tagName,
        attrs: attributes(element),
        text: element.textContent?.trim().slice(0, 400),
      };
      if (geometry) {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        Object.assign(result, {
          rect: {
            x: rect.x,
            y: rect.y,
            width: rect.width,
            height: rect.height,
          },
          style: {
            display: style.display,
            visibility: style.visibility,
            opacity: style.opacity,
            pointerEvents: style.pointerEvents,
            transform: style.transform,
            transitionDuration: style.transitionDuration,
            animationName: style.animationName,
          },
        });
      }
      return result;
    };
    const state = () => {
      const outer = document.querySelector('.home-demo-previewer[data-home-demo-options]');
      const scope = document.querySelector('[data-projection-scope]');
      return {
        url: location.href,
        outer: node(outer),
        controllerSnapshot: outer?.__homeProjection__?.getSnapshot(),
        runnerState: outer?.getAttribute('data-runner-state'),
        projectionComponent: outer?.getAttribute('data-projection-component'),
        ariaBusy: outer?.getAttribute('aria-busy'),
        statusText: document.querySelector('[data-home-demo-status]')?.textContent,
        host: node(document.querySelector('[data-home-demo-host]')),
        scope: node(scope, true),
        allScopes: [...document.querySelectorAll('[data-projection-scope]')].map((element) =>
          node(element, true)
        ),
        generationHosts: [...document.querySelectorAll('[data-projection-generation-host]')].map(
          (element) => node(element, true)
        ),
        contents: [...document.querySelectorAll('[data-projection-content]')].map((element) =>
          node(element, true)
        ),
        controls: [...document.querySelectorAll('[data-projection-control]')].map((element) => ({
          surface: node(element),
          trigger: node(element.querySelector('[role="combobox"]')),
        })),
        activeElement: node(document.activeElement),
      };
    };
    const diagnostic = {
      stage: 'navigation',
      events: [],
      mutations: [],
      state,
      node,
    };
    window.__puiProjectionPassiveEvidence = diagnostic;
    for (const name of [
      'pointerdown',
      'pointerup',
      'mousedown',
      'mouseup',
      'click',
      'keydown',
      'keyup',
      'valueChange',
      'proto-adapter:change',
    ]) {
      document.addEventListener(
        name,
        (event) => {
          const point =
            typeof event.clientX === 'number' ? { x: event.clientX, y: event.clientY } : null;
          diagnostic.events.push({
            at: performance.now(),
            stage: diagnostic.stage,
            type: event.type,
            isTrusted: event.isTrusted,
            key: event.key,
            detail: event instanceof CustomEvent ? event.detail : null,
            point,
            target: node(event.target, true),
            path: event
              .composedPath()
              .filter((entry) => entry instanceof Element)
              .slice(0, 6)
              .map((entry) => node(entry)),
            hit: point ? node(document.elementFromPoint(point.x, point.y), true) : null,
            state: state(),
          });
        },
        { capture: true, passive: true }
      );
    }
    let last = '';
    const observer = new MutationObserver((mutations) => {
      const current = state();
      const fingerprint = JSON.stringify(current);
      if (fingerprint === last) return;
      last = fingerprint;
      diagnostic.mutations.push({
        at: performance.now(),
        stage: diagnostic.stage,
        state: current,
        changes: mutations.map((m) => ({
          type: m.type,
          attribute: m.attributeName,
          target: node(m.target),
        })),
      });
    });
    observer.observe(document, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: [
        'data-projection-state',
        'data-projection-runtime',
        'data-projection-family',
        'data-projection-generation',
        'data-projection-component',
        'data-projection-id',
        'data-runner-state',
        'data-value',
        'aria-expanded',
        'aria-controls',
        'aria-busy',
        'data-state',
        'data-pressed',
        'hidden',
        'inert',
        'class',
        'style',
      ],
    });
  });
}

export async function checkpoint(page, stage, target) {
  const record = pages.get(page);
  if (!record) return;
  record.stage = stage;
  const observation = await page.evaluate((label) => {
    const diagnostic = window.__puiProjectionPassiveEvidence;
    diagnostic.stage = label;
    return { at: performance.now(), state: diagnostic.state() };
  }, stage);
  let targetObservation = null;
  if (target) {
    const count = await target.count();
    targetObservation = { count };
    if (count === 1) {
      targetObservation = {
        count,
        ...(await target.evaluate((element) => {
          const diagnostic = window.__puiProjectionPassiveEvidence;
          const rect = element.getBoundingClientRect();
          const center = {
            x: rect.x + rect.width / 2,
            y: rect.y + rect.height / 2,
          };
          return {
            node: diagnostic.node(element, true),
            center,
            elementFromCenter: diagnostic.node(document.elementFromPoint(center.x, center.y), true),
          };
        })),
      };
    }
  }
  record.checkpoints.push({ stage, ...observation, target: targetObservation });
}

export async function capture(page, name, error) {
  const record = pages.get(page);
  if (!record) return;
  await fs.mkdir(output, { recursive: true });
  record.captures.push({
    name,
    at: new Date().toISOString(),
    error: error ? { message: String(error), stack: error.stack } : null,
    stage: record.stage,
  });
  await page.screenshot({
    path: path.join(output, `${name}.png`),
    fullPage: true,
  });
  await fs.writeFile(path.join(output, `${name}.html`), await page.content());
  const client = await page.context().newCDPSession(page);
  try {
    await client.send('Accessibility.enable');
    await fs.writeFile(
      path.join(output, `${name}-ax.json`),
      JSON.stringify(await client.send('Accessibility.getFullAXTree'), null, 2) + '\n'
    );
  } finally {
    await client.detach();
  }
  const browser = await page.evaluate(() => {
    const diagnostic = window.__puiProjectionPassiveEvidence;
    return {
      stage: diagnostic.stage,
      state: diagnostic.state(),
      events: diagnostic.events,
      mutations: diagnostic.mutations,
      timing: { timeOrigin: performance.timeOrigin, now: performance.now() },
    };
  });
  await fs.writeFile(
    path.join(output, `${name}-observations.json`),
    JSON.stringify({ ...record, browser }, null, 2) + '\n'
  );
}

export async function finishPassive(page) {
  const record = pages.get(page);
  if (!record) return;
  record.finishedAt = new Date().toISOString();
  await fs.writeFile(path.join(output, 'node-record.json'), JSON.stringify(record, null, 2) + '\n');
}
