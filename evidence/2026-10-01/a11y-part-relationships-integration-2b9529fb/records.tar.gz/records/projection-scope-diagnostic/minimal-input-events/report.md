# 真实输入链：请求 Switch，原生点击落在 Button 内容区

**本轮复现 `wc/brutalist/switch`：4 passed / 1 failed，exit 1。原生事件证据明确显示这次强制选项点击没有命中目标 option。** 动画、翻转或具体几何原因未被采样，不作为已证实根因。

准确 source 为 `8595a59165635be05cf83c610904859442cc58a8` / tree `cc4546b521d4eb9a58291998f6e688fdd2ef82fc`；时间 2026-10-01 **19:03:47.608–19:04:41.142 UTC**。原路径/config/五 case 顺序、message/count/timeout/force 均保留。仅在 case2 导航前注册一次被动 document capture 监听，浅读取 pointerdown/pointerup/click/valueChange 到内存，无几何、MO、每事件 RPC、每动作 await 或恢复输入。

| 相对页面 timeOrigin 的时间 | 真实事件 | 目标 |
| --- | --- | --- |
| 1569.9 ms | trusted click，(1062, 637) | generation 5 的 component combobox，文本 Button |
| 1585.7 ms | trusted pointerdown，约 (1061, 707.45) | `DIV[data-demo-ref="__pui_projection__content"]`，prototype=`brutalist-button`，generation 5 |
| 1585.8 ms | trusted pointerup，约 (1061, 707.45) | 同一 Button 内容区域 |
| 1585.8 ms | trusted click，(1061, 707) | 同一 Button 内容区域；composed path 不含 option/listbox |

该 click 后缓冲没有 `valueChange`；此前正常的 5 条值事件依次为 button、switch、select、brutalist、button。全部记录为 14 个 trusted pointerdown、14 pointerup、14 click、5 个非 trusted WC valueChange。[input-chain.json](input-chain.json) 给出原缓冲位置、最后六条原事件和各次值事件，可直接对照未改动的 [failure-state.json](capture/failure-state.json)。这不是借 controller 私有记录缺失推断“从无请求”。

30 秒 poll 失败后于 **19:04:33.234 UTC** 进入 catch，`.255` 取得终态：唯一 scope/host 为 WC/Brutalist generation 5、ready；外层 projectionComponent=button、controller phase=ready、状态文字就绪。组件 Root 的公开 value=button、open=false，disabled 未公开；first scope 与全页 requested Switch count 都为 0。这与原生输入落在现有 Button 内容区、没有后续已记录值事件的链相符。

[真实失败 PNG](../../../screenshots/projection-scope-diagnostic/minimal-input-events/capture/failure.png) 已通过 `view_image` 查看，确实呈现 WC / Brutalist / Button 与 Button demo；不是点击瞬间截图。原图 SHA-256：`257c18c37c7442fa2ec64b84f9da0bd5c1c3bb046b4f6a8d6660a50095fd0a88`。保存的 HTML/AX 与终态和画面一致，详见 [visual-review.json](visual-review.json)。原 failure-state SHA-256：`48a5c42d1cee36b8060c0cee0ce84e7577511f34f1fce42c557668e7acb4edfd`。

这只证明本次 miss；不把其他无输入观测的失败统一归因，也不把 animation/flip 等静态推测升级为实测。上一条失败后采集独立运行请求的是 Select、保留的是 Switch，仍保留各自来源。

执行结束 `finally` 已逐字恢复原测试 SHA `8eab04ced23a2d2f53e3cb50eca4b8da4d2a59bb13d31e2957414e028eb675c6`，再次核验准确 8595 clean、无遗留进程后交还重资源槽。exec 22923 / PID 58164 已完成。随后 root 接手的一行 no-force 修复属于独立后续状态，不在本次源绑定中；本 Agent 不再编辑或恢复产品。

完整命令、原/诊断源 hash 与捕获 hash 见 [execution-receipt.json](execution-receipt.json)、[本包状态与来源说明](../../../packet.json)、[source.diff](source.diff)。本轮仅执行一次，未实现修复、commit/push 或 GitHub 写入。
