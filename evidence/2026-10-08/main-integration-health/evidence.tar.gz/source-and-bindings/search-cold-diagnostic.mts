import { mkdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { launchBrowser, startServer, stopServer } from '<source-root>/apps/www/src/content/docs/zh-cn/browser-harness.ts';
import { installSearchStartupTrace, readSearchReadyWithinBudget, searchReadinessWasOnTime } from '<source-root>/apps/www/src/content/docs/zh-cn/site-search-evidence.ts';
const output = '<private-evidence-root>/phase4-cold-diagnostic';
await mkdir(output, { recursive: true });
const source = { head: execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(), diffSHA256:createHash('sha256').update(execFileSync('git',['diff','--binary','--full-index','HEAD'])).digest('hex') };
let browser: Awaited<ReturnType<typeof launchBrowser>> | undefined;
const results: unknown[] = [];
const startedAt = new Date().toISOString();
try {
 const baseUrl = await startServer(['/zh-cn/ui-libraries/shadcn/button/','/zh-cn/ui-libraries/brutalist/components/button/']);
 browser = await launchBrowser();
 for (const rate of [1,4]) for (let round=1;round<=3;round++) for (const family of ['shadcn','brutalist']) for (const theme of ['light','dark']) for (const width of [390,1440]) {
  const id=`cpu${rate}-r${round}-${family}-${theme}-${width}`;
  const context=await browser.newContext({viewport:{width,height:960},colorScheme:theme as 'light'|'dark'});
  const page=await context.newPage();const cdp=await context.newCDPSession(page);
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await page.addInitScript((theme)=>localStorage.setItem('starlight-theme',theme),theme);
  await page.addInitScript(installSearchStartupTrace);
  await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});
  await cdp.send('Emulation.setCPUThrottlingRate',{rate});
  await cdp.send('Profiler.enable');await cdp.send('Profiler.start');
  const navigationStartedAt=Date.now();
  try {
   const response=await page.goto(`${baseUrl}/zh-cn/ui-libraries/${family}/${family==='brutalist'?'components/':''}button/`,{waitUntil:'networkidle',timeout:30000});
   const stageStartedAt=Date.now();
   const evidence=await page.evaluate(readSearchReadyWithinBudget,{startedAt:stageStartedAt});
   const onTime=searchReadinessWasOnTime(evidence);
   let lateReady:boolean|null=null;
   if(!onTime) lateReady=await page.waitForFunction(()=>document.querySelector('site-search [data-projection-generation-state="active"] [data-open-modal]')?.getAttribute('aria-disabled')==='false',undefined,{timeout:10000}).then(()=>true,()=>false);
   const trace=await page.evaluate(()=>((window as any).__puiSearchStartup?.snapshot()??null));
   const {profile}=await cdp.send('Profiler.stop');
   const screenshot=`${output}/${id}.png`;await page.screenshot({path:screenshot});
   const record={id,source,diagnosticOnly:true,cpuThrottlingRate:rate,profilerEnabled:true,coldClientContext:true,browserCacheDisabled:true,serverReused:true,httpStatus:response?.status(),navigationStartedAt,stageStartedAt,evidence,onTime,lateReady,errors,trace,profile,screenshot};
   await writeFile(`${output}/${id}.json`,JSON.stringify(record));
   results.push({id,onTime,httpStatus:record.httpStatus,stageElapsedMs:evidence.completedAt-evidence.startedAt,readyOffsetMs:evidence.observedReadyAt===null?null:evidence.observedReadyAt-evidence.startedAt,errorCount:errors.length,longTasks:trace?.longTasks});
   console.log(JSON.stringify(results.at(-1)));
  } catch(error) {const record={id,source,error:String(error),navigationStartedAt,diagnosticOnly:true};await writeFile(`${output}/${id}-error.json`,JSON.stringify(record));results.push(record);console.log(JSON.stringify(record));}
  finally {await cdp.detach().catch(()=>{});await context.close();}
 }
} finally {await browser?.close();await stopServer();await writeFile(`${output}/summary.json`,JSON.stringify({startedAt,endedAt:new Date().toISOString(),source,scope:'diagnostic only, fixed 3 rounds each CPU1/CPU4, two families/two themes/two viewports; no deadline assertion changes; profiled observations separate from unmodified acceptance run',results},null,2));}
