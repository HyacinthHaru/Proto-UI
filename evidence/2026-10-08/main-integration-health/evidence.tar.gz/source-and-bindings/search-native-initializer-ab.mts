import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { launchBrowser, startServer, stopServer } from '<source-root>/apps/www/src/content/docs/zh-cn/browser-harness.ts';
import { installSearchStartupTrace, readSearchReadyWithinBudget, searchReadinessWasOnTime } from '<source-root>/apps/www/src/content/docs/zh-cn/site-search-evidence.ts';
const output = '<private-evidence-root>/phase4-native-initializer-ab';
await mkdir(output, { recursive: true });
const source = { head: execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(), diffSHA256:createHash('sha256').update(execFileSync('git',['diff','--binary','--full-index','HEAD'])).digest('hex') };
let browser: Awaited<ReturnType<typeof launchBrowser>> | undefined;
const results: unknown[] = [];
const startedAt = new Date().toISOString();
const interventionPath='<source-root>/apps/www/src/components/override/SocialIcons.astro';
const original=await readFile(interventionPath,'utf8');
const before='release = initSiteNativeControls(document);';
if(original.split(before).length!==2) throw new Error('exact single initializer site required');
const restoredManifest:unknown[]=[];
try {
 browser = await launchBrowser();
 for(let pair=1;pair<=5;pair++) for(const mode of (pair%2?['A-original','B-no-native-initializer']:['B-no-native-initializer','A-original'])) {
 await writeFile(interventionPath,mode==='A-original'?original:original.replace(before,'release = () => {};'));
 const variantSource={...source, mode, socialIconsSHA256:createHash('sha256').update(await readFile(interventionPath)).digest('hex'),diffSHA256:createHash('sha256').update(execFileSync('git',['diff','--binary','--full-index','HEAD'])).digest('hex')};
 const baseUrl = await startServer(['/zh-cn/ui-libraries/shadcn/button/','/zh-cn/ui-libraries/brutalist/components/button/']);
 const rate=4,round=pair;
 for (const family of ['shadcn','brutalist']) for (const theme of ['light','dark']) for (const width of [390,1440]) {
  const id=`p${pair}-${mode}-cpu${rate}-${family}-${theme}-${width}`;
  const context=await browser.newContext({viewport:{width,height:960},colorScheme:theme as 'light'|'dark'});
  const page=await context.newPage();const cdp=await context.newCDPSession(page);
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await page.addInitScript((theme)=>localStorage.setItem('starlight-theme',theme),theme);
  await page.addInitScript(installSearchStartupTrace);
  await cdp.send('Network.enable');await cdp.send('Network.setCacheDisabled',{cacheDisabled:true});
  await cdp.send('Emulation.setCPUThrottlingRate',{rate});
  await cdp.send('Profiler.enable');await cdp.send('Profiler.start');
  const navigationStartedAt=Date.now();
  try {
   const response=await page.goto(`${baseUrl}/zh-cn/ui-libraries/${family}/${family==='brutalist'?'components/':''}button/`,{waitUntil:'networkidle',timeout:30000});
   const stageStartedAt=Date.now();
   const evidence=await page.evaluate(readSearchReadyWithinBudget,{startedAt:stageStartedAt});
   const onTime=searchReadinessWasOnTime(evidence);
   let lateReady:boolean|null=null;
   if(!onTime) lateReady=await page.waitForFunction(()=>document.querySelector('site-search [data-projection-generation-state="active"] [data-open-modal]')?.getAttribute('aria-disabled')==='false',undefined,{timeout:10000}).then(()=>true,()=>false);
   const enhanced=await page.locator('[data-site-link-enhanced]').count();
   const trace=await page.evaluate(()=>((window as any).__puiSearchStartup?.snapshot()??null));
   const {profile}=await cdp.send('Profiler.stop');
   const screenshot=`${output}/${id}.png`;await page.screenshot({path:screenshot});
   const record={id,source:variantSource,enhanced,diagnosticOnly:true,cpuThrottlingRate:rate,profilerEnabled:true,coldClientContext:true,browserCacheDisabled:true,serverReusedWithinVariant:true,newServerPerVariant:true,httpStatus:response?.status(),navigationStartedAt,stageStartedAt,evidence,onTime,lateReady,errors,trace,profile,screenshot};
   await writeFile(`${output}/${id}.json`,JSON.stringify(record));
   results.push({id,mode,enhanced,onTime,httpStatus:record.httpStatus,stageElapsedMs:evidence.completedAt-evidence.startedAt,readyOffsetMs:evidence.observedReadyAt===null?null:evidence.observedReadyAt-evidence.startedAt,errorCount:errors.length,longTasks:trace?.longTasks});
   console.log(JSON.stringify(results.at(-1)));
  } catch(error) {const record={id,source:variantSource,error:String(error),navigationStartedAt,diagnosticOnly:true};await writeFile(`${output}/${id}-error.json`,JSON.stringify(record));results.push(record);console.log(JSON.stringify(record));}
  finally {await cdp.detach().catch(()=>{});await context.close();}
 }
 await stopServer();
 }
} finally {await browser?.close();await stopServer();await writeFile(interventionPath,original);restoredManifest.push({path:interventionPath,restored:(await readFile(interventionPath,'utf8'))===original,sha256:createHash('sha256').update(original).digest('hex')});await writeFile(`${output}/summary.json`,JSON.stringify({startedAt,endedAt:new Date().toISOString(),source,restoredManifest,scope:'diagnostic only, fixed 5 paired AB/BA rounds CPU4, two families/two themes/two viewports; B disables exactly one initializer call only as diagnostic intervention, not a product repair; unchanged1000ms deadline; fresh server per variant, cold client/cache each case; source restored finally',results},null,2));}
