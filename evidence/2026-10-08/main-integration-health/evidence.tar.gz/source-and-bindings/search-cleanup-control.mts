import { readFile, writeFile } from 'node:fs/promises';
import { startServer, stopServer } from '<source-root>/apps/www/src/content/docs/zh-cn/browser-harness.ts';
const file='<source-root>/apps/www/src/components/override/SocialIcons.astro';
const before=await readFile(file);let active=false;let stopped=false;
try {const base=await startServer('/zh-cn/ui-libraries/shadcn/button/');active=true;await stopServer();active=false;stopped=true;console.log(JSON.stringify({base,stopped,control:'caller stops its owned server exactly once; no measurement or source intervention'}));}
finally {try {if(active)await stopServer();}finally {if(!(await readFile(file)).equals(before))throw new Error('source changed during cleanup-only control');await writeFile('<private-evidence-root>/cleanup-only-control.json',JSON.stringify({stopped,sourceUnchanged:true,scope:'cleanup caller control only; original80-case process remains exit1'}));}}
