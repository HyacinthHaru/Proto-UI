const _="tally-1",a=t=>t.path({d:"M4 4v16"});export{_ as LUCIDE_ICON_NAME,a as LUCIDE_TALLY_1_SHAPE_FACTORY,a as default};
