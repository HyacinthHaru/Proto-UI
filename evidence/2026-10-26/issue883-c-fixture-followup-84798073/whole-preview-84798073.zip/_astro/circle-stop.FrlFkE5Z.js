const t="circle-stop",e=c=>[c.circle({cx:12,cy:12,r:10}),c.rect({x:9,y:9,width:6,height:6,rx:1})];export{e as LUCIDE_CIRCLE_STOP_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,e as default};
