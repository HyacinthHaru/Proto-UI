const a="bed",d=t=>[t.path({d:"M2 4v16"}),t.path({d:"M2 8h18a2 2 0 0 1 2 2v10"}),t.path({d:"M2 17h20"}),t.path({d:"M6 8v9"})];export{d as LUCIDE_BED_SHAPE_FACTORY,a as LUCIDE_ICON_NAME,d as default};
