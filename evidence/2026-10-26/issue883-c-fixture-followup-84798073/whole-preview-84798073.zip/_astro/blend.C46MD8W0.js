const e="blend",r=c=>[c.circle({cx:9,cy:9,r:7}),c.circle({cx:15,cy:15,r:7})];export{r as LUCIDE_BLEND_SHAPE_FACTORY,e as LUCIDE_ICON_NAME,r as default};
