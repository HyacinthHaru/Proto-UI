const _="fish-symbol",t=s=>s.path({d:"M2 16s9-15 20-4C11 23 2 8 2 8"});export{t as LUCIDE_FISH_SYMBOL_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,t as default};
