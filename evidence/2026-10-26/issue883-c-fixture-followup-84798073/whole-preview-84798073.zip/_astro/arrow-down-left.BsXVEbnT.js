const _="arrow-down-left",a=t=>[t.path({d:"M17 7 7 17"}),t.path({d:"M17 17H7V7"})];export{a as LUCIDE_ARROW_DOWN_LEFT_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
