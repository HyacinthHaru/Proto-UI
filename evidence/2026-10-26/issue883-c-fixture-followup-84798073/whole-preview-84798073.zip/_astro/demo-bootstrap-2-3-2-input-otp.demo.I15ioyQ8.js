import{c as t}from"./numeric-input-demo.shared.63ecZFH3.js";const p=t("bootstrap-2-3-2","input-otp");export{p as default};
