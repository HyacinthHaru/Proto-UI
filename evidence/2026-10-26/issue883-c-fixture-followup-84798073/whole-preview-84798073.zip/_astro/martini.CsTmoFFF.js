const a="martini",I=t=>[t.path({d:"M8 22h8"}),t.path({d:"M12 11v11"}),t.path({d:"m19 3-7 8-7-8Z"})];export{a as LUCIDE_ICON_NAME,I as LUCIDE_MARTINI_SHAPE_FACTORY,I as default};
