import{c as e}from"./field-demo.shared.DyfIfEGN.js";const a=e("base");export{a as default};
