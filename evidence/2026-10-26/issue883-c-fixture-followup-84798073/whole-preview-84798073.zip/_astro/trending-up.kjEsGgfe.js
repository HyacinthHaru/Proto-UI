const _="trending-up",E=t=>[t.path({d:"M16 7h6v6"}),t.path({d:"m22 7-8.5 8.5-5-5L2 17"})];export{_ as LUCIDE_ICON_NAME,E as LUCIDE_TRENDING_UP_SHAPE_FACTORY,E as default};
