import{c as e}from"./range-readout-demo.shared.Dc_CljyO.js";const o=e("liquid-glass","progress");export{o as default};
