const n="navigation-2",t=o=>o.polygon({points:"12 2 19 21 12 17 5 21 12 2"});export{n as LUCIDE_ICON_NAME,t as LUCIDE_NAVIGATION_2_SHAPE_FACTORY,t as default};
