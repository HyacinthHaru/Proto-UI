const _="text-align-justify",a=t=>[t.path({d:"M3 5h18"}),t.path({d:"M3 12h18"}),t.path({d:"M3 19h18"})];export{_ as LUCIDE_ICON_NAME,a as LUCIDE_TEXT_ALIGN_JUSTIFY_SHAPE_FACTORY,a as default};
