import{c as e}from"./numeric-input-demo.shared.63ecZFH3.js";const o=e("base","input-otp");export{o as default};
