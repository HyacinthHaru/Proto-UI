const e="tablet",x=t=>[t.rect({width:16,height:20,x:4,y:2,rx:2,ry:2}),t.line({x1:12,x2:12.01,y1:18,y2:18})];export{e as LUCIDE_ICON_NAME,x as LUCIDE_TABLET_SHAPE_FACTORY,x as default};
