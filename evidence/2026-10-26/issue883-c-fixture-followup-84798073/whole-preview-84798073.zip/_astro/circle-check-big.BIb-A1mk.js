const _="circle-check-big",c=C=>[C.path({d:"M21.801 10A10 10 0 1 1 17 3.335"}),C.path({d:"m9 11 3 3L22 4"})];export{c as LUCIDE_CIRCLE_CHECK_BIG_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,c as default};
