const _="tally-2",a=t=>[t.path({d:"M4 4v16"}),t.path({d:"M9 4v16"})];export{_ as LUCIDE_ICON_NAME,a as LUCIDE_TALLY_2_SHAPE_FACTORY,a as default};
