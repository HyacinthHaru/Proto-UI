const t="command",C=a=>a.path({d:"M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3"});export{C as LUCIDE_COMMAND_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,C as default};
