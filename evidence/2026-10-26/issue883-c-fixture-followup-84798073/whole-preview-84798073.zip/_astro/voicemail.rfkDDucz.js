const e="voicemail",i=c=>[c.circle({cx:6,cy:12,r:4}),c.circle({cx:18,cy:12,r:4}),c.line({x1:6,x2:18,y1:16,y2:16})];export{e as LUCIDE_ICON_NAME,i as LUCIDE_VOICEMAIL_SHAPE_FACTORY,i as default};
