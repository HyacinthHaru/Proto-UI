import{o as oe,v as H,s as Q,d as le,e as ce,f as we,g as ye,c as be,b as xe,h as Te}from"./program.CG2NV99b.js";/*!
MIT License

Copyright (c) NaughtyDuk

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

Exclusion of Assets

The MIT License above applies only to the source code of this project (the
contents of the `scripts/` and `package/` directories). It does NOT apply to
the contents of the `assets/` directory (including but not limited to the
audio files under `assets/audio/` and `assets/fonts/`), which are provided
for demonstration purposes only and may not be copied, redistributed, or
reused outside of this repository without separate permission from their
respective rights holders.

---

Support Open Source

If this project has been useful to you, please consider supporting its
continued open-source development at https://liquidgl.naughtyduk.com

*/const P=Object.freeze({head:"2b8757f4516da60d3a3b31e9ec4df7401b3d3195",tree:"bf899df185407f326a43dca40f2a65f9a20dcab0",static:Object.freeze({profile:"pui-regular-style-tint-4",bytes:10692,sha256:"1ad0356cc23940e6f50d6e63db167588ace5750e83638ead5ae7506597312e7d"}),contact:Object.freeze({profile:"pui-regular-style-tint-contact-4",bytes:10945,sha256:"83cacf5404ddefb6680b0b9efa7818c21de42252561a85b4a539833744e453cb"})}),ee=`
        #ifdef GL_FRAGMENT_PRECISION_HIGH
        precision highp float;
        #else
        precision mediump float;
        #endif
        varying vec2 v_uv;
        uniform sampler2D u_tex;
        uniform vec2  u_resolution;
        uniform vec2  u_textureResolution;
        uniform vec4  u_bounds;
        uniform float u_refraction;
        uniform float u_aberration;
        uniform float u_bevelDepth;
        uniform float u_bevelWidth;
        uniform float u_frost;
        uniform float u_radius;
        uniform float u_time;
        uniform bool  u_specular;
        uniform float u_revealProgress;
        uniform int   u_revealType;
        uniform float u_tiltX;
        uniform float u_tiltY;
        uniform float u_magnify;
        uniform vec2  u_subpixel;
        uniform vec2  u_boxSize;
        uniform vec4  u_tint;
        uniform sampler2D u_stack;
        uniform vec4 u_stackMapping;
        uniform vec4 u_stackRegion;
        uniform vec4 u_interaction;
        uniform float u_interactionRadius;
        uniform sampler2D u_shadow;
        uniform vec4 u_shadowMapping;

        vec4 sampleSource(vec2 uv) {
          vec4 background = texture2D(u_tex, uv);
          vec2 screenUV = u_stackMapping.xy + uv * u_stackMapping.zw;
          if (u_stackRegion.z > 0.0 &&
              all(greaterThanEqual(screenUV, u_stackRegion.xy)) &&
              all(lessThanEqual(screenUV, u_stackRegion.xy + u_stackRegion.zw))) {
            vec4 lower = texture2D(u_stack, vec2(screenUV.x, 1.0 - screenUV.y));
            return lower + background * (1.0 - lower.a);
          }
          return background;
        }

        float udRoundBox( vec2 p, vec2 b, float r ) {
          return length(max(abs(p)-b+r,0.0))-r;
        }

        vec2 cornerNormal( vec2 p, vec2 b, float r, vec2 fallback ) {
          vec2 q = abs(p) - b + r;
          vec2 m = max(q, 0.0);
          float l = length(m);
          if (l <= 0.0) return fallback;
          float w = smoothstep(0.0, max(r * 0.5, 1.0), min(m.x, m.y));
          if (w <= 0.0) return fallback;
          vec2 s = vec2(p.x < 0.0 ? -1.0 : 1.0, p.y < 0.0 ? -1.0 : 1.0);
          return normalize(mix(fallback, s * (m / l), w));
        }

        float random(vec2 st) {
          return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
        }

        vec2 deformPoint(vec2 point) {
          if (u_interactionRadius <= 0.0) return point;
          vec2 centre = (vec2(u_interaction.x, 1.0 - u_interaction.y) - 0.5) * u_boxSize;
          float reach = u_interactionRadius * min(u_boxSize.x, u_boxSize.y);
          float influence = 1.0 - smoothstep(0.0, reach, length(point - centre));
          return point - vec2(u_interaction.z, -u_interaction.w) * u_boxSize * influence;
        }

        float edgeFactor(vec2 p_px, vec2 b_px, float radius_px){
          float d = -udRoundBox(p_px, b_px, radius_px);
          float bevel_px = u_bevelWidth * min(u_boxSize.x, u_boxSize.y);
          return 1.0 - smoothstep(0.0, bevel_px, d);
        }

        uniform float u_styleTintLightForeground;
        uniform float u_styleTintLuminanceBound;
        vec3 styleTintLinear(vec3 value) {
          return mix(value / 12.92, pow((value + 0.055) / 1.055, vec3(2.4)),
                     step(vec3(0.04045), value));
        }
        vec3 styleTintSrgb(vec3 value) {
          return mix(value * 12.92, 1.055 * pow(value, vec3(1.0 / 2.4)) - 0.055,
                     step(vec3(0.0031308), value));
        }
        void main(){
          vec2 lensUV = (v_uv * u_resolution - u_subpixel) / u_boxSize;
          vec2 originalPoint = (lensUV - 0.5) * u_boxSize;
          vec2 p_px = deformPoint(originalPoint);
          vec2 b_px = 0.5 * u_boxSize;
          vec2 p = p_px / u_boxSize.y;
          float dmask = udRoundBox(p_px, b_px, u_radius);
          float inShape = 1.0 - smoothstep(-0.5, 0.5, dmask);
          float shadowAlpha = 0.0;
          if (u_shadowMapping.z > 0.0 && inShape < 1.0) {
            vec2 shadowUV = u_shadowMapping.xy + vec2(lensUV.x, 1.0 - lensUV.y) * u_shadowMapping.zw;
            shadowAlpha = texture2D(u_shadow, shadowUV).r * 0.1 * (1.0 - inShape);
            if (u_revealType == 1) shadowAlpha *= u_revealProgress;
            float noise = fract(52.9829189 * fract(dot(floor(gl_FragCoord.xy), vec2(0.06711056, 0.00583715))));
            shadowAlpha = floor(shadowAlpha * 255.0 + noise) / 255.0;
          }
          if (inShape <= 0.0) {
            gl_FragColor = vec4(0.0, 0.0, 0.0, shadowAlpha);
            return;
          }

          float edge = edgeFactor(p_px, b_px, u_radius);
          float min_dimension = min(u_resolution.x, u_resolution.y);
          float offsetAmt = (edge * u_refraction + pow(edge, 10.0) * u_bevelDepth);
          float centreBlend = smoothstep(0.15, 0.45, length(p));
          vec2 refractDir = cornerNormal(p_px, b_px, u_radius, normalize(p + vec2(0.000001)));
          if (u_interactionRadius > 0.0) {
            vec2 gradient = vec2(
              udRoundBox(deformPoint(originalPoint + vec2(0.5, 0.0)), b_px, u_radius) - udRoundBox(deformPoint(originalPoint - vec2(0.5, 0.0)), b_px, u_radius),
              udRoundBox(deformPoint(originalPoint + vec2(0.0, 0.5)), b_px, u_radius) - udRoundBox(deformPoint(originalPoint - vec2(0.0, 0.5)), b_px, u_radius)
            );
            if (length(gradient) > 0.0001) refractDir = normalize(mix(refractDir, normalize(gradient), min(length(p_px - originalPoint), 1.0)));
          }
          vec2 offset = refractDir * offsetAmt * centreBlend;

          float tiltRefractionScale = 0.05;
          vec2 tiltOffset = vec2(tan(radians(u_tiltY)), -tan(radians(u_tiltX))) * tiltRefractionScale;

          vec2 localUV = (lensUV - 0.5) / u_magnify + 0.5;
          vec2 flippedUV = vec2(localUV.x, 1.0 - localUV.y);
          vec2 mapped = u_bounds.xy + flippedUV * u_bounds.zw;
          vec2 refracted = mapped + offset - tiltOffset;

          float oob = max(max(-refracted.x, refracted.x - 1.0), max(-refracted.y, refracted.y - 1.0));
          float blend = 1.0 - smoothstep(0.0, 0.01, oob);
          vec2 sampleUV = mix(mapped, refracted, blend);

          vec4 baseCol   = sampleSource(mapped);

          vec2 texel = 1.0 / u_textureResolution;
          vec4 refrCol;

          vec2 chroma = offset * u_aberration;

          if (u_frost > 0.0) {
              float radius = u_frost * 4.0;
              vec4 sum = vec4(0.0);
              const int SAMPLES = 16;

              for (int i = 0; i < SAMPLES; i++) {
                  float angle = random(v_uv + float(i)) * 6.283185;
                  float dist = sqrt(random(v_uv - float(i))) * radius;
                  vec2 foff = vec2(cos(angle), sin(angle)) * texel * dist;
                  if (u_aberration > 0.0) {
                      sum.r += sampleSource(sampleUV + foff - chroma).r;
                      sum.g += sampleSource(sampleUV + foff).g;
                      sum.b += sampleSource(sampleUV + foff + chroma).b;
                      sum.a += sampleSource(sampleUV + foff).a;
                  } else {
                      sum += sampleSource(sampleUV + foff);
                  }
              }
              refrCol = sum / float(SAMPLES);
          } else {
              refrCol = sampleSource(sampleUV);
              refrCol += sampleSource(sampleUV + vec2( texel.x, 0.0));
              refrCol += sampleSource(sampleUV + vec2(-texel.x, 0.0));
              refrCol += sampleSource(sampleUV + vec2(0.0,  texel.y));
              refrCol += sampleSource(sampleUV + vec2(0.0, -texel.y));
              refrCol /= 5.0;

              if (u_aberration > 0.0) {
                  refrCol.r = sampleSource(sampleUV - chroma).r;
                  refrCol.b = sampleSource(sampleUV + chroma).b;
              }
          }

          if (refrCol.a < 0.1) {
              refrCol = baseCol;
          }

          float diff = clamp(length(refrCol.rgb - baseCol.rgb) * 4.0, 0.0, 1.0);

          float antiHalo = (1.0 - centreBlend) * diff;

          vec4 final    = refrCol;

          // The opt-in style tint is applied after all lighting below.

          if (u_specular) {
            vec2 lp1 = vec2(sin(u_time*0.2), cos(u_time*0.3))*0.6 + 0.5;
            vec2 lp2 = vec2(sin(u_time*-0.4+1.5), cos(u_time*0.25-0.5))*0.6 + 0.5;
            float h = 0.0;
            h += (1.0 - smoothstep(0.0,0.4,distance((p_px + b_px) / u_boxSize, lp1)))*0.1;
            h += (1.0 - smoothstep(0.0,0.5,distance((p_px + b_px) / u_boxSize, lp2)))*0.08;
            final.rgb += h;
          }


          // Retain the admitted optical source's spatial tone and chroma.
          // The safe bound is luminance, not a narrow per-channel solid-fill band.
          vec3 styleTintDetail = clamp(final.rgb, 0.0, 1.0);
          vec3 styleTintBase = styleTintLinear(u_tint.rgb);
          vec3 styleTintWeights = vec3(0.2126, 0.7152, 0.0722);
          float styleTintTone = dot(styleTintDetail, styleTintWeights);
          vec3 styleTintHue = mix(styleTintBase, styleTintLinear(styleTintDetail), 0.25);
          float styleTintBoundCode = styleTintSrgb(vec3(u_styleTintLuminanceBound)).r;
          float styleTintTargetCode = mix(
            styleTintBoundCode + (1.0 - styleTintBoundCode) * styleTintTone,
            styleTintBoundCode * styleTintTone, u_styleTintLightForeground);
          float styleTintTarget = styleTintLinear(vec3(styleTintTargetCode)).r;
          // 2^-12 remains normal at the inherited minimum mediump precision.
          // Both branches must stay finite, including black/white endpoints.
          vec3 styleTintDark = styleTintHue *
            (styleTintTarget /
             max(dot(styleTintHue, styleTintWeights), 0.000244140625));
          vec3 styleTintComplement = vec3(1.0) - styleTintHue;
          vec3 styleTintLight = vec3(1.0) - styleTintComplement *
            ((1.0 - styleTintTarget) /
             max(dot(styleTintComplement, styleTintWeights), 0.000244140625));
          // Gamut clipping only moves farther onto the foreground-safe side:
          // down in luminance for light text, up for dark text. Readback guards
          // still reject any finite-precision or near-opaque contrast failure.
          final.rgb = styleTintSrgb(clamp(mix(styleTintLight, styleTintDark,
                                             u_styleTintLightForeground), 0.0, 1.0));

          if (u_revealType == 1) {
              final.rgb *= u_revealProgress;
              final.a  *= u_revealProgress;
          }

          final.rgb *= inShape;
          final.a = final.a * inShape + shadowAlpha;

          gl_FragColor = final;
        }`,q=`
        #ifdef GL_FRAGMENT_PRECISION_HIGH
        precision highp float;
        #else
        precision mediump float;
        #endif
        varying vec2 v_uv;
        uniform sampler2D u_tex;
        uniform vec2  u_resolution;
        uniform vec2  u_textureResolution;
        uniform vec4  u_bounds;
        uniform float u_refraction;
        uniform float u_aberration;
        uniform float u_bevelDepth;
        uniform float u_bevelWidth;
        uniform float u_frost;
        uniform float u_radius;
        uniform float u_time;
        uniform float u_contactShape;
        uniform bool  u_specular;
        uniform float u_revealProgress;
        uniform int   u_revealType;
        uniform float u_tiltX;
        uniform float u_tiltY;
        uniform float u_magnify;
        uniform vec2  u_subpixel;
        uniform vec2  u_boxSize;
        uniform vec4  u_tint;
        uniform sampler2D u_stack;
        uniform vec4 u_stackMapping;
        uniform vec4 u_stackRegion;
        uniform vec4 u_interaction;
        uniform float u_interactionRadius;
        uniform sampler2D u_shadow;
        uniform vec4 u_shadowMapping;

        vec4 sampleSource(vec2 uv) {
          vec4 background = texture2D(u_tex, uv);
          vec2 screenUV = u_stackMapping.xy + uv * u_stackMapping.zw;
          if (u_stackRegion.z > 0.0 &&
              all(greaterThanEqual(screenUV, u_stackRegion.xy)) &&
              all(lessThanEqual(screenUV, u_stackRegion.xy + u_stackRegion.zw))) {
            vec4 lower = texture2D(u_stack, vec2(screenUV.x, 1.0 - screenUV.y));
            return lower + background * (1.0 - lower.a);
          }
          return background;
        }

        float udRoundBox( vec2 p, vec2 b, float r ) {
          return length(max(abs(p)-b+r,0.0))-r;
        }

        vec2 cornerNormal( vec2 p, vec2 b, float r, vec2 fallback ) {
          vec2 q = abs(p) - b + r;
          vec2 m = max(q, 0.0);
          float l = length(m);
          if (l <= 0.0) return fallback;
          float w = smoothstep(0.0, max(r * 0.5, 1.0), min(m.x, m.y));
          if (w <= 0.0) return fallback;
          vec2 s = vec2(p.x < 0.0 ? -1.0 : 1.0, p.y < 0.0 ? -1.0 : 1.0);
          return normalize(mix(fallback, s * (m / l), w));
        }

        float random(vec2 st) {
          return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
        }

        vec2 deformPoint(vec2 point) {
          if (u_interactionRadius <= 0.0) return point;
          vec2 centre = (vec2(u_interaction.x, 1.0 - u_interaction.y) - 0.5) * u_boxSize;
          float reach = u_interactionRadius * min(u_boxSize.x, u_boxSize.y);
          float influence = 1.0 - smoothstep(0.0, reach, length(point - centre));
          return point - vec2(u_interaction.z, -u_interaction.w) * u_boxSize * influence;
        }

        float edgeFactor(vec2 p_px, vec2 b_px, float radius_px){
          float d = -udRoundBox(p_px, b_px, radius_px);
          float bevel_px = u_bevelWidth * min(u_boxSize.x, u_boxSize.y);
          return 1.0 - smoothstep(0.0, bevel_px, d);
        }

        uniform float u_styleTintLightForeground;
        uniform float u_styleTintLuminanceBound;
        vec3 styleTintLinear(vec3 value) {
          return mix(value / 12.92, pow((value + 0.055) / 1.055, vec3(2.4)),
                     step(vec3(0.04045), value));
        }
        vec3 styleTintSrgb(vec3 value) {
          return mix(value * 12.92, 1.055 * pow(value, vec3(1.0 / 2.4)) - 0.055,
                     step(vec3(0.0031308), value));
        }
        void main(){
          vec2 lensUV = (v_uv * u_resolution - u_subpixel) / u_boxSize;
          vec2 originalPoint = (lensUV - 0.5) * u_boxSize;
          vec2 p_px = deformPoint(originalPoint);
          float dilation = 1.0 + 0.045 * clamp(u_contactShape, 0.0, 1.0);
          vec2 b_px = 0.5 * u_boxSize * dilation;
          float shapeRadius = min(u_radius * dilation, min(b_px.x, b_px.y));
          vec2 p = p_px / u_boxSize.y;
          float dmask = udRoundBox(p_px, b_px, shapeRadius);
          float inShape = 1.0 - smoothstep(-0.5, 0.5, dmask);
          float shadowAlpha = 0.0;
          if (u_shadowMapping.z > 0.0 && inShape < 1.0) {
            vec2 shadowUV = u_shadowMapping.xy + vec2(lensUV.x, 1.0 - lensUV.y) * u_shadowMapping.zw;
            shadowAlpha = texture2D(u_shadow, shadowUV).r * 0.1 * (1.0 - inShape);
            if (u_revealType == 1) shadowAlpha *= u_revealProgress;
            float noise = fract(52.9829189 * fract(dot(floor(gl_FragCoord.xy), vec2(0.06711056, 0.00583715))));
            shadowAlpha = floor(shadowAlpha * 255.0 + noise) / 255.0;
          }
          if (inShape <= 0.0) {
            gl_FragColor = vec4(0.0, 0.0, 0.0, shadowAlpha);
            return;
          }

          float edge = edgeFactor(p_px, b_px, shapeRadius);
          float min_dimension = min(u_resolution.x, u_resolution.y);
          float offsetAmt = (edge * u_refraction + pow(edge, 10.0) * u_bevelDepth);
          float centreBlend = smoothstep(0.15, 0.45, length(p));
          vec2 refractDir = cornerNormal(p_px, b_px, shapeRadius, normalize(p + vec2(0.000001)));
          if (u_interactionRadius > 0.0) {
            vec2 gradient = vec2(
              udRoundBox(deformPoint(originalPoint + vec2(0.5, 0.0)), b_px, shapeRadius) - udRoundBox(deformPoint(originalPoint - vec2(0.5, 0.0)), b_px, shapeRadius),
              udRoundBox(deformPoint(originalPoint + vec2(0.0, 0.5)), b_px, shapeRadius) - udRoundBox(deformPoint(originalPoint - vec2(0.0, 0.5)), b_px, shapeRadius)
            );
            if (length(gradient) > 0.0001) refractDir = normalize(mix(refractDir, normalize(gradient), min(length(p_px - originalPoint), 1.0)));
          }
          vec2 offset = refractDir * offsetAmt * centreBlend;

          float tiltRefractionScale = 0.05;
          vec2 tiltOffset = vec2(tan(radians(u_tiltY)), -tan(radians(u_tiltX))) * tiltRefractionScale;

          vec2 localUV = (lensUV - 0.5) / u_magnify + 0.5;
          vec2 flippedUV = vec2(localUV.x, 1.0 - localUV.y);
          vec2 mapped = u_bounds.xy + flippedUV * u_bounds.zw;
          vec2 refracted = mapped + offset - tiltOffset;

          float oob = max(max(-refracted.x, refracted.x - 1.0), max(-refracted.y, refracted.y - 1.0));
          float blend = 1.0 - smoothstep(0.0, 0.01, oob);
          vec2 sampleUV = mix(mapped, refracted, blend);

          vec4 baseCol   = sampleSource(mapped);

          vec2 texel = 1.0 / u_textureResolution;
          vec4 refrCol;

          vec2 chroma = offset * u_aberration;

          if (u_frost > 0.0) {
              float radius = u_frost * 4.0;
              vec4 sum = vec4(0.0);
              const int SAMPLES = 16;

              for (int i = 0; i < SAMPLES; i++) {
                  float angle = random(v_uv + float(i)) * 6.283185;
                  float dist = sqrt(random(v_uv - float(i))) * radius;
                  vec2 foff = vec2(cos(angle), sin(angle)) * texel * dist;
                  if (u_aberration > 0.0) {
                      sum.r += sampleSource(sampleUV + foff - chroma).r;
                      sum.g += sampleSource(sampleUV + foff).g;
                      sum.b += sampleSource(sampleUV + foff + chroma).b;
                      sum.a += sampleSource(sampleUV + foff).a;
                  } else {
                      sum += sampleSource(sampleUV + foff);
                  }
              }
              refrCol = sum / float(SAMPLES);
          } else {
              refrCol = sampleSource(sampleUV);
              refrCol += sampleSource(sampleUV + vec2( texel.x, 0.0));
              refrCol += sampleSource(sampleUV + vec2(-texel.x, 0.0));
              refrCol += sampleSource(sampleUV + vec2(0.0,  texel.y));
              refrCol += sampleSource(sampleUV + vec2(0.0, -texel.y));
              refrCol /= 5.0;

              if (u_aberration > 0.0) {
                  refrCol.r = sampleSource(sampleUV - chroma).r;
                  refrCol.b = sampleSource(sampleUV + chroma).b;
              }
          }

          if (refrCol.a < 0.1) {
              refrCol = baseCol;
          }

          float diff = clamp(length(refrCol.rgb - baseCol.rgb) * 4.0, 0.0, 1.0);

          float antiHalo = (1.0 - centreBlend) * diff;

          vec4 final    = refrCol;

          // The opt-in style tint is applied after all lighting below.

          if (u_specular) {
            vec2 point = (p_px + b_px) / u_boxSize;
            vec2 contact = vec2(u_interaction.x, 1.0 - u_interaction.y);
            float localLight = 1.0 - smoothstep(0.0, 0.42, distance(point, contact));
            float rimLight = pow(clamp(edge, 0.0, 1.0), 2.0);
            float active = clamp(u_interactionRadius, 0.0, 1.0);
            final.rgb += vec3(0.035 + localLight * active * (0.075 + rimLight * 0.10));
          }


          // Retain the admitted optical source's spatial tone and chroma.
          // The safe bound is luminance, not a narrow per-channel solid-fill band.
          vec3 styleTintDetail = clamp(final.rgb, 0.0, 1.0);
          vec3 styleTintBase = styleTintLinear(u_tint.rgb);
          vec3 styleTintWeights = vec3(0.2126, 0.7152, 0.0722);
          float styleTintTone = dot(styleTintDetail, styleTintWeights);
          vec3 styleTintHue = mix(styleTintBase, styleTintLinear(styleTintDetail), 0.25);
          float styleTintBoundCode = styleTintSrgb(vec3(u_styleTintLuminanceBound)).r;
          float styleTintTargetCode = mix(
            styleTintBoundCode + (1.0 - styleTintBoundCode) * styleTintTone,
            styleTintBoundCode * styleTintTone, u_styleTintLightForeground);
          float styleTintTarget = styleTintLinear(vec3(styleTintTargetCode)).r;
          // 2^-12 remains normal at the inherited minimum mediump precision.
          // Both branches must stay finite, including black/white endpoints.
          vec3 styleTintDark = styleTintHue *
            (styleTintTarget /
             max(dot(styleTintHue, styleTintWeights), 0.000244140625));
          vec3 styleTintComplement = vec3(1.0) - styleTintHue;
          vec3 styleTintLight = vec3(1.0) - styleTintComplement *
            ((1.0 - styleTintTarget) /
             max(dot(styleTintComplement, styleTintWeights), 0.000244140625));
          // Gamut clipping only moves farther onto the foreground-safe side:
          // down in luminance for light text, up for dark text. Readback guards
          // still reject any finite-precision or near-opaque contrast failure.
          final.rgb = styleTintSrgb(clamp(mix(styleTintLight, styleTintDark,
                                             u_styleTintLightForeground), 0.0, 1.0));

          if (u_revealType == 1) {
              final.rgb *= u_revealProgress;
              final.a  *= u_revealProgress;
          }

          final.rgb *= inShape;
          final.a = final.a * inShape + shadowAlpha;

          gl_FragColor = final;
        }`,y=Object.freeze({version:"tint4-stage-continuous-tone-1",candidateGeneralTransfer:"rejected-analytically",expectedCompleteDiagnosticStatus:"diagnostic-rejected-on-continuous-tone",productAccepted:!1,executionScope:"historical-profile4-replay-on-current-profile5-host",currentProductValidation:!1,statistic:"same-frame GPU postlighting clamped encoded luma; exact inShape == 1; includes foreground backing",packing:"round(value / range * 65535) in RG bytes, B exact shape-opaque, A finite in-range; top-down PNG",packedToneRange:1,packedPostlightRange:2,toneError:.5/65535+2**-16,targetError:.5/65535+2**-16,minimumHighpPrecision:23,maximumCarrierPixels:65536,maximumSourcePixels:131072,maximumFrames:60,rampDomains:[[0,255],[16,80],[224,254]],originalHead:"2b8757f4516da60d3a3b31e9ec4df7401b3d3195",originalTree:"bf899df185407f326a43dca40f2a65f9a20dcab0",shaderSha256:{static:"1ad0356cc23940e6f50d6e63db167588ace5750e83638ead5ae7506597312e7d",contact:"83cacf5404ddefb6680b0b9efa7818c21de42252561a85b4a539833744e453cb"}});function ne(e,r){for(const o of Object.keys(r))if(e[o]!==r[o])throw new Error(`tint-stage-stale-${o}`)}const Se=(e,r=0,o=1)=>Math.max(r,Math.min(o,e)),Ee=e=>e<=.0031308?e*12.92:1.055*e**(1/2.4)-.055;function ue(e,r,o,t){if(![e,r,o].every(Number.isFinite)||e<0||e>1||r<0||r>1||o<=0||o>=1)throw new Error("tint-stage-invalid-transfer-input");const s=t?0:o,l=t?o:1,c=t?o*e:o+(1-o)*e,g=(t?o*r:o+(1-o)*r)+(e-r);return{baseline:c,raw:g,candidate:Se(g,s,l),low:g<s,high:g>l}}function X(e,r){if(e.length%4!==0||!(r>0))throw new Error("tint-stage-invalid-packed-data");const o=[],t=[];for(let s=0;s<e.length;s+=4){if(![0,255].includes(e[s+2]))throw new Error("tint-stage-nonbinary-shape-mask");const l=e[s+2]===255;if(l&&e[s+3]!==255)throw new Error("tint-stage-packed-overflow");o.push((e[s]*256+e[s+1])/65535*r),t.push(l)}return{values:o,mask:t}}function Re(e,r){if(e.length!==r.length||!r.some(Boolean))throw new Error("tint-stage-empty-or-stale-mask");let o=0,t=0;return e.forEach((s,l)=>{if(r[l]){if(!Number.isFinite(s)||s<0||s>1)throw new Error("tint-stage-invalid-tone");o+=s,t++}}),{value:Math.fround(o/t),samples:t,error:y.toneError+2**-24}}function Z(e,r,o,t,s){const l=ue(e.tone,r,o,t),c=s==="low"?t?0:o:t?o:1,g=s==="low"?c-l.raw:l.raw-c;return e.opaque&&e[s]&&g>2*y.toneError+y.targetError&&Math.abs(e.newTarget-c)<=y.targetError}function Ce(e,r,o,t,s){if(e.some(d=>![d.tone,d.oldTarget,d.newTarget].every(Number.isFinite)))throw new Error("tint-stage-invalid-veto-sample");const l=y.toneError,c=y.targetError;let g=0;const a=[],m=e.filter(d=>d.opaque),v=m.length?Math.max(...m.map(d=>d.tone))-Math.min(...m.map(d=>d.tone)):0,b=m.length?Math.max(...m.map(d=>d.oldTarget))-Math.min(...m.map(d=>d.oldTarget)):0,u={toneSpan:v,oldTargetSpan:b,samples:m.length,direction:s};if(v<=2*l||b<=2*c)return{verdict:"inconclusive-precision",intervals:a,unresolved:1,observation:u};if(m.some((d,p)=>p>0&&(s*(d.tone-m[p-1].tone)<-2*l||s*(d.oldTarget-m[p-1].oldTarget)<-2*c)))return{verdict:"inconclusive-unordered-observation",intervals:a,unresolved:1,observation:u};for(const d of["low","high"]){let p=-1;const n=i=>{if(p>=0&&i>p){const h=e[p],f=e[i],x=s*(f.tone-h.tone),w=s*(f.oldTarget-h.oldTarget);x>2*l&&w>2*c?a.push({start:p,end:i,side:d,toneSpan:x,oldSpan:w}):g++}p=-1};e.forEach((i,h)=>{const f=Z(i,r,o,t,d);(!f||p>=0&&s*(i.tone-e[h-1].tone)<-2*l||p>=0&&s*(i.oldTarget-e[h-1].oldTarget)<-2*c)&&n(h-1),f&&p<0&&(p=h)}),n(e.length-1)}return{verdict:a.length?"rejected-continuous-tone":g?"inconclusive-precision":"no-confirmed-veto-in-this-ramp",intervals:a,unresolved:g,observation:u}}function Ae(e,r){if(e.length<2||!e.every(Number.isFinite)||!e.some(o=>o!==e[0])||e.some((o,t)=>t>0&&r*(o-e[t-1])<0))throw new Error("tint-stage-invalid-monotonic-control")}const J="        void main(){",z="          vec3 styleTintDetail = clamp(final.rgb, 0.0, 1.0);",j=`          float styleTintTargetCode = mix(
            styleTintBoundCode + (1.0 - styleTintBoundCode) * styleTintTone,
            styleTintBoundCode * styleTintTone, u_styleTintLightForeground);`,L="          float styleTintTarget = styleTintLinear(vec3(styleTintTargetCode)).r;";function M(e,r,o){if(e.split(r).length!==2)throw new Error("tint-stage-shader-anchor-drift");return e.replace(r,o)}const Pe=`
        uniform float u_tintStageMean;
        vec4 tintStagePack(float value, float range, float shape) {
          float integer = floor(clamp(value / range, 0.0, 1.0) * 65535.0 + 0.5);
          return vec4(floor(integer / 256.0), mod(integer, 256.0), shape == 1.0 ? 255.0 : 0.0,
                      (value >= 0.0 && value <= range) ? 255.0 : 0.0) / 255.0;
        }
`,Ue=`          float tintStageRaw = mix(
            styleTintBoundCode + (1.0 - styleTintBoundCode) * u_tintStageMean,
            styleTintBoundCode * u_tintStageMean, u_styleTintLightForeground) + (styleTintTone - u_tintStageMean);
          float tintStageLow = mix(styleTintBoundCode, 0.0, u_styleTintLightForeground);
          float tintStageHigh = mix(1.0, styleTintBoundCode, u_styleTintLightForeground);
          float styleTintTargetCode = clamp(tintStageRaw, tintStageLow, tintStageHigh);`,Be=["baseline","postlight-r","postlight-g","postlight-b","tone","input-clamp","old-target","new-target","target-clamp","candidate"];function fe(e,r=!0){if(!Be.includes(e))throw new Error("tint-stage-unknown-stage");let o=r?q:ee;for(const t of[J,z,j,L])if(o.split(t).length!==2)throw new Error("tint-stage-shader-anchor-drift");return e==="baseline"?o:(o=M(o,J,Pe+J),e.startsWith("postlight-")?M(o,z,`          gl_FragColor = tintStagePack(final.${e.slice(-1)}, 2.0, inShape); return;
`+z):e==="input-clamp"?M(o,z,`          gl_FragColor = vec4(any(lessThan(final.rgb, vec3(0.0))) ? 1.0 : 0.0, any(greaterThan(final.rgb, vec3(1.0))) ? 1.0 : 0.0, inShape == 1.0 ? 1.0 : 0.0, 1.0); return;
`+z):e==="tone"?M(o,j,`          gl_FragColor = tintStagePack(styleTintTone, 1.0, inShape); return;
`+j):e==="old-target"||(o=M(o,j,Ue),e==="new-target")?M(o,L,`          gl_FragColor = tintStagePack(styleTintTargetCode, 1.0, inShape); return;
`+L):e==="target-clamp"?M(o,L,`          gl_FragColor = vec4(tintStageRaw < tintStageLow ? 1.0 : 0.0, tintStageRaw > tintStageHigh ? 1.0 : 0.0, inShape == 1.0 ? 1.0 : 0.0, 1.0); return;
`+L):o)}async function S(e){const r=typeof e=="string"?new TextEncoder().encode(e):e;return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",new Uint8Array(r))),o=>o.toString(16).padStart(2,"0")).join("")}function de(e,r,o){const t=new Uint8Array(r*o*4);if(e.readPixels(0,0,r,o,e.RGBA,e.UNSIGNED_BYTE,t),e.getError()!==e.NO_ERROR||e.isContextLost())throw new Error("tint-stage-readback-failed");return t}function De(e,r,o){const t=new Uint8Array(e.length);for(let s=0;s<o;s++)t.set(e.subarray(s*r*4,(s+1)*r*4),(o-1-s)*r*4);return t}function W(e,r,o){const t=document.createElement("canvas");return t.width=r,t.height=o,t.getContext("2d").putImageData(new ImageData(new Uint8ClampedArray(e),r,o),0,0),t.toDataURL("image/png")}async function $(e){if(!e.startsWith("data:image/png;base64,"))throw new Error("tint-stage-nonlocal-png");const r=new Image;r.src=e,await r.decode();const o=document.createElement("canvas");o.width=r.width,o.height=r.height;const t=o.getContext("2d");return t.drawImage(r,0,0),{image:r,canvas:o,width:r.width,height:r.height,data:new Uint8Array(t.getImageData(0,0,r.width,r.height).data)}}function G(e){return Uint8Array.from(atob(e.split(",")[1]),r=>r.charCodeAt(0))}function Me(e,r,o){if(e.length!==r.length||e.some((t,s)=>t!==r[s]))throw new Error(o)}function ie(e,r,o){const t=ce(r,o);let s=0,l=1/0;for(let c=0;c<e.length;c+=4){const g=e[c+3];if(g===255&&s++,!(g<250))for(const a of g===255?[0]:[0,1]){const m=[e[c]/255+(1-g/255)*a,e[c+1]/255+(1-g/255)*a,e[c+2]/255+(1-g/255)*a,1],v=we(m,t.worstForeground);if(l=Math.min(l,v),m.slice(0,3).some(b=>b>1)||v<4.5||ye(m,t.worstForeground)!==t.lightForeground)throw new Error("tint-stage-rendered-contrast-unsafe")}}if(!s)throw new Error("tint-stage-empty-opaque-output");return{minimumContrast:l,opaqueSamples:s,worstForeground:t.worstForeground,polarity:t.lightForeground?"light":"dark",luminanceBound:t.luminanceBound}}function Fe(e,r=!0){const o=r?"pui-regular-style-tint-contact-5":"pui-regular-style-tint-5",t=r?q:ee,s=c=>[...c.matchAll(/\buniform\s+(?:(?:lowp|mediump|highp)\s+)?\w+\s+\w+(?:\s*\[[^\]]+\])?\s*;/g)].map(g=>g[0].replace(/\s+/g," ")).sort();if(e.profile!==o||e.fragment===t)throw new Error("tint-stage-current-host-profile-drift");if(JSON.stringify(s(e.fragment))!==JSON.stringify(s(t)))throw new Error("tint-stage-historical-uniform-schema-drift");const l={vertex:0,fragment:0};return{source(c,g){if(c!=="vertex"&&c!=="fragment")throw new Error("tint-stage-unexpected-shader-type");if(g!==e[c]||l[c]!==0)throw new Error(`tint-stage-current-${c}-source-or-count-drift`);return l[c]++,c==="fragment"?t:g},complete(){if(l.vertex!==1||l.fragment!==1)throw new Error("tint-stage-historical-substitution-count-drift");return{vertexSources:l.vertex,fragmentReplacements:l.fragment}}}}function Le(e){if(!e||e.scope!==y.executionScope||e.currentProductValidation!==!1||e.currentAdapter?.profile!=="pui-regular-style-tint-contact-5"||!/^[a-f0-9]{64}$/.test(e.currentAdapter.requestedFragmentSha256)||e.currentAdapter.requestedFragmentSha256===P.contact.sha256||e.compiledKernel?.profile!==P.contact.profile||e.compiledKernel.fragmentSha256!==P.contact.sha256||e.compiledKernel.head!==P.head||e.compiledKernel.tree!==P.tree||!/^[a-f0-9]{64}$/.test(e.vertexSha256)||e.vertexSources!==1||e.fragmentReplacements!==1)throw new Error("tint-stage-not-historical-profile4-evidence")}function Ve(e){const r=Fe({profile:e.contact?le:Te,fragment:e.contact?Q:xe,vertex:H},!!e.contact),o=document.createElement("canvas"),t=o.getContext("webgl",{alpha:!0,premultipliedAlpha:!0,preserveDrawingBuffer:!0,antialias:!1});if(!t)throw new Error("tint-stage-webgl-unavailable");const s=new Map,l={};let c=null,g=t.TEXTURE0,a=0,m=0;const v=[],b=[],u=[],d=(n,i,h)=>{const f=t[n];t[n]=function(...x){h?.(x);const w=f.apply(t,x);return i(x,w),w},u.push(()=>{t[n]=f})};d("getUniformLocation",(n,i)=>{i&&s.set(i,n[1])}),d("activeTexture",n=>{g=n[0]}),d("shaderSource",n=>v.push(n[1]),n=>{const i=t.getShaderParameter(n[0],t.SHADER_TYPE);if(i!==t.VERTEX_SHADER&&i!==t.FRAGMENT_SHADER)throw new Error("tint-stage-unexpected-shader-type");b.push(n[1]),n[1]=r.source(i===t.VERTEX_SHADER?"vertex":"fragment",n[1])}),d("drawArrays",()=>{},()=>{r.complete()}),d("readPixels",()=>{a++}),d("texImage2D",n=>{n[8]instanceof Uint8Array&&(m+=n[8].byteLength),g===t.TEXTURE0&&n.length===9&&n[3]===e.source.width&&n[4]===e.source.height&&n[8]instanceof Uint8Array&&(c=new Uint8Array(n[8]))});for(const n of["uniform1f","uniform1i","uniform2fv","uniform4fv"])d(n,i=>{const h=s.get(i[0]);h&&(l[h]={method:n,value:(typeof i[1]=="number"?[i[1]]:Array.from(i[1])).map(f=>n==="uniform1i"?f:Math.fround(f))})});const p=be(o);try{const n=p.render(e),i=r.complete(),h=a;if(!c)throw new Error("tint-stage-missing-actual-prefilter");const f=t.getParameter(t.CURRENT_PROGRAM);for(const[x,w]of s){const B=l[w];if(!B)continue;const C=t.getUniform(f,x),R=typeof C=="number"||typeof C=="boolean"?[Number(C)]:Array.from(C);if(JSON.stringify(R)!==JSON.stringify(B.value))throw new Error(`tint-stage-upload-readback-mismatch-${w}`)}return{canvas:o,gl:t,png:n,pixels:de(t,o.width,o.height),prepared:c,uniforms:l,shaders:v,requestedShaders:b,replacementCounts:i,metrics:p.inspect(),productionInternalReadbacks:h,captureReadbacks:a-h,uploadedBytes:m,dither:t.isEnabled(t.DITHER),dispose:()=>p.dispose()}}catch(n){const i={};try{o.width&&o.height&&(i["production-failed-carrier"]=o.toDataURL("image/png"))}catch{}c&&(i.prepared=W(c,e.source.width,e.source.height));const h=n instanceof Error?n:new Error(String(n));throw Object.assign(h,{tintStagePartial:{stagePngs:i,uniformUploads:l,requestedShaderSources:b,submittedShaderSources:v,productionMetrics:p.inspect(),productionDimensions:[o.width,o.height]}}),p.dispose(),h}finally{for(const n of u.reverse())n()}}function ke(e,r,o){(r==="baseline"||r==="candidate")&&o?e.enable(e.DITHER):e.disable(e.DITHER)}function Oe(e,r,o,t,s,l,c){const g=document.createElement("canvas");g.width=e,g.height=r;const a=g.getContext("webgl",{alpha:!0,premultipliedAlpha:!0,preserveDrawingBuffer:!0,antialias:!1});if(!a)throw new Error("tint-stage-webgl-unavailable");const m=a.getShaderPrecisionFormat(a.FRAGMENT_SHADER,a.HIGH_FLOAT);if(!m||m.precision<y.minimumHighpPrecision)throw new Error(`tint-stage-inconclusive-highp-precision:${JSON.stringify(m?{precision:m.precision,rangeMin:m.rangeMin,rangeMax:m.rangeMax}:null)}`);const v=[a.RED_BITS,a.GREEN_BITS,a.BLUE_BITS,a.ALPHA_BITS].map(i=>a.getParameter(i));if(v.some(i=>i!==8))throw new Error(`tint-stage-inconclusive-framebuffer-format:${JSON.stringify(v)}`);const b=a.createBuffer(),u=[],d=new Map;a.bindBuffer(a.ARRAY_BUFFER,b),a.bufferData(a.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),a.STATIC_DRAW);for(let i=0;i<3;i++){const h=a.createTexture();u.push(h),a.activeTexture(a.TEXTURE0+i),a.bindTexture(a.TEXTURE_2D,h);for(const f of[a.TEXTURE_MIN_FILTER,a.TEXTURE_MAG_FILTER])a.texParameteri(a.TEXTURE_2D,f,a.LINEAR);for(const f of[a.TEXTURE_WRAP_S,a.TEXTURE_WRAP_T])a.texParameteri(a.TEXTURE_2D,f,a.CLAMP_TO_EDGE);a.pixelStorei(a.UNPACK_ALIGNMENT,1),a.texImage2D(a.TEXTURE_2D,0,a.RGBA,i?1:o,i?1:t,0,a.RGBA,a.UNSIGNED_BYTE,i?new Uint8Array(4):s)}function p(i,h=0){let f=d.get(i);if(!f){f=a.createProgram();for(const[C,R]of[[a.VERTEX_SHADER,H],[a.FRAGMENT_SHADER,fe(i)]]){const E=a.createShader(C);if(a.shaderSource(E,R),a.compileShader(E),!a.getShaderParameter(E,a.COMPILE_STATUS))throw new Error(`tint-stage-compile-${i}: ${a.getShaderInfoLog(E)}`);a.attachShader(f,E),a.deleteShader(E)}if(a.linkProgram(f),!a.getProgramParameter(f,a.LINK_STATUS))throw new Error(`tint-stage-link-${i}`);d.set(i,f)}a.viewport(0,0,e,r),a.useProgram(f),a.bindBuffer(a.ARRAY_BUFFER,b);const x=a.getAttribLocation(f,"a_position");a.enableVertexAttribArray(x),a.vertexAttribPointer(x,2,a.FLOAT,!1,0,0);for(const[C,{method:R,value:E}]of Object.entries(l)){const D=a.getUniformLocation(f,C);R==="uniform1f"?a.uniform1f(D,E[0]):R==="uniform1i"?a.uniform1i(D,E[0]):R==="uniform2fv"?a.uniform2fv(D,E):a.uniform4fv(D,E)}const w=a.getUniformLocation(f,"u_tintStageMean");if(a.uniform1f(w,h),w&&a.getUniform(f,w)!==Math.fround(h))throw new Error("tint-stage-stale-mean-upload");ke(a,i,c),a.clearColor(0,0,0,0),a.clear(a.COLOR_BUFFER_BIT),a.disable(a.BLEND),a.drawArrays(a.TRIANGLE_STRIP,0,4);const B=de(a,e,r);return{raw:B,top:De(B,e,r),png:g.toDataURL("image/png")}}const n=a.getExtension("WEBGL_debug_renderer_info");return{draw:p,metadata:{precision:{precision:m.precision,rangeMin:m.rangeMin,rangeMax:m.rangeMax},renderer:a.getParameter(n?n.UNMASKED_RENDERER_WEBGL:a.RENDERER),vendor:a.getParameter(n?n.UNMASKED_VENDOR_WEBGL:a.VENDOR),version:a.getParameter(a.VERSION),shadingLanguage:a.getParameter(a.SHADING_LANGUAGE_VERSION),drawingBuffer:[a.drawingBufferWidth,a.drawingBufferHeight],format:"RGBA/UNSIGNED_BYTE",channelBits:v,productionDither:c,packedStageDither:!1,opticalArithmeticError:"not proven; exact baseline replay and native target interval checks required",stageSemantics:"finite shader derivatives; early returns may change compiler optimization; not hidden registers of the production compiled program",admissionScope:"frozen owned OpticalFrame only; DOM/provider admission not rerun"},dispose(){d.forEach(i=>a.deleteProgram(i)),u.forEach(i=>a.deleteTexture(i)),a.deleteBuffer(b),a.getExtension("WEBGL_lose_context")?.loseContext()}}}function Ie(e,r,o,t,s,l){if(e.length!==r*o||t.length!==r*o*4||s.length!==t.length)throw new Error("tint-stage-stale-texture-mask");const c=e.map(n=>n.opaque&&(n.low||n.high)),g=(n,i,h)=>[0,1,2].every(f=>n[i*4+f]===n[h*4+f]),a=new Set,m=[];let v=0,b=0,u=0,d=0,p=0;return e.forEach((n,i)=>{if(!n.opaque)return;p++;for(const f of[i%r+1<r?i+1:-1,i+r<e.length?i+r:-1])if(!(f<0||!e[f].opaque)&&(!g(t,i,f)&&g(s,i,f)&&v++,c[i]&&c[f]&&n.low===e[f].low)){b++;const x=n.low?"low":"high";Z(n,l.mean,l.bound,l.light,x)&&Z(e[f],l.mean,l.bound,l.light,x)&&Math.abs(n.tone-e[f].tone)>2*y.toneError&&Math.abs(n.oldTarget-e[f].oldTarget)>2*y.targetError?u++:d++}if(!c[i]||a.has(i))return;const h=[i];a.add(i);for(let f=0;f<h.length;f++){const x=h[f];for(const w of[x%r?x-1:-1,x%r+1<r?x+1:-1,x-r,x+r])w>=0&&w<e.length&&c[w]&&!a.has(w)&&e[w].low===n.low&&g(s,i,w)&&(a.add(w),h.push(w))}m.push({size:h.length,firstPixel:i,endpoint:n.low?"low":"high"})}),{domain:"entire exact shape-opaque carrier, 4-connected equal candidate RGB; no ROI selection",newFlatRgbEdgesInterpretation:"raw quantized RGB diagnostic; may include ordinary quantization and is never itself a continuous-tone veto",opaqueSamples:p,lowClipPixels:e.filter(n=>n.opaque&&n.low).length,highClipPixels:e.filter(n=>n.opaque&&n.high).length,newFlatRgbEdges:v,rawClampedEdges:b,resolvedClampedEdges:u,uncertainOrUninformativeClampedEdges:d,observedComponentsAreNotPrecisionVerdicts:!0,components:m,largestPlateau:Math.max(0,...m.map(n=>n.size)),clipMap:Uint8Array.from(e.flatMap(n=>[n.opaque&&n.low?255:0,n.opaque&&n.high?255:0,n.opaque?255:0,255]))}}async function se(e,r){const o=await $(e),t=document.createElement("canvas");t.width=r.raster.clip.width,t.height=r.raster.clip.height;const s=o.width/(r.geometry.width+2*r.outset),l=o.height/(r.geometry.height+2*r.outset);return t.getContext("2d").drawImage(o.image,(r.outset-r.raster.hostOffset.x)*s,(r.outset-r.raster.hostOffset.y)*l,t.width*s,t.height*l,0,0,t.width,t.height),{width:t.width,height:t.height,data:Array.from(t.getContext("2d").getImageData(0,0,t.width,t.height).data),png:t.toDataURL("image/png")}}function Ne(e,r){return{...e,status:"failed",failure:r instanceof Error?r.message:String(r),candidateGeneralTransfer:y.candidateGeneralTransfer,currentProductValidation:!1,productAccepted:!1}}async function ze(e){const r={id:e.frame.id,control:e.frame.control,sourceOrigin:e.frame.sourceOrigin,evidenceKind:e.frame.control==="tinted"?"native-diagnostic":"archived-reference",inputPngs:e.frame.files,stagePngs:{},stageReceipts:{},productAccepted:!1};try{return await Ge(e,r)}catch(o){const t=o?.tintStagePartial;return Ne(t?{...r,...t}:r,o)}}async function Ge(e,r){if(!["archived-first-party-input","predeclared-generated-ramp"].includes(e.frame.sourceOrigin))throw new Error("tint-stage-source-origin-missing");const o=performance.now(),{frame:t,pngs:s}=e;if(t.head!==y.originalHead||t.tree!==y.originalTree)throw new Error("tint-stage-original-source-drift");for(const[d,p]of Object.entries(t.files))if(!s[d]||await S(G(s[d]))!==p.sha256)throw new Error(`tint-stage-input-png-mismatch-${d}`);const l=await $(s.source),c=await S(l.data);if(l.width!==t.source.width||l.height!==t.source.height||c!==t.source.pixelSha256)throw new Error("tint-stage-source-pixel-mismatch");if(l.width*l.height>y.maximumSourcePixels)throw new Error("tint-stage-source-budget");const g=await $(s["source-crop"]),a={width:g.width,height:g.height,data:Array.from(g.data)};if(!oe(t.fill)||!oe(t.foreground))throw new Error("tint-stage-invalid-palette");const m=t.fill,v=t.foreground;if(t.control!=="tinted"){const d=t.control==="neutral"?"interior-plane":"subject",p=await $(s[d]);return{id:t.id,control:t.control,sourceImage:a,material:{width:p.width,height:p.height,data:Array.from(p.data),png:s[d]},sourceOrigin:t.sourceOrigin,originalHead:t.sourceOrigin==="archived-first-party-input"?t.head:null,originalTree:t.sourceOrigin==="archived-first-party-input"?t.tree:null,kernelSource:{head:t.head,tree:t.tree},inputPngs:t.files,status:"historical-own-geometry-reference-not-new-gpu",evidenceKind:"archived-reference",productAccepted:!1,milliseconds:performance.now()-o}}if(t.contactPhase!=="rest")throw new Error("tint-stage-only-frozen-rest");if(t.profile!==P.contact.profile)throw new Error("tint-stage-historical-input-profile-mismatch");if(await S(q)!==y.shaderSha256.contact||await S(ee)!==y.shaderSha256.static)throw new Error("tint-stage-shader-hash-drift");const b={source:{revision:t.source.revision,width:l.width,height:l.height,pixels:l.data,canvas:l.canvas,scope:document.createElement("div")},geometry:{width:t.geometry.width,height:t.geometry.height,radius:Math.min(t.geometry.width,t.geometry.height)/2,paintOutset:t.outset,dpr:1,bounds:[(t.geometry.x-t.source.rect.x)/t.source.rect.width,(t.geometry.y-t.source.rect.y)/t.source.rect.height,t.geometry.width/t.source.rect.width,t.geometry.height/t.source.rect.height]},pressed:!1,contact:{x:.5,y:.5,deltaX:0,deltaY:0,strength:0},variant:"regular",fill:m,foreground:v,...t.control==="tinted"?{tint:"style-fill"}:{}},u=Ve(b);try{const d={scope:y.executionScope,currentProductValidation:!1,currentAdapter:{profile:le,requestedFragmentSha256:await S(Q)},compiledKernel:{profile:P.contact.profile,fragmentSha256:await S(q),head:P.head,tree:P.tree},vertexSha256:await S(H),...u.replacementCounts};Le(d);const p=u.canvas.width,n=u.canvas.height;if(p*n>y.maximumCarrierPixels)throw new Error("tint-stage-carrier-budget");const i=await se(u.png,t),h={id:t.id,control:t.control,sourceOrigin:t.sourceOrigin,originalHead:t.sourceOrigin==="archived-first-party-input"?t.head:null,originalTree:t.sourceOrigin==="archived-first-party-input"?t.tree:null,kernelSource:{head:t.head,tree:t.tree},kernelExecution:d,currentProductValidation:!1,inputPngs:t.files,sourceImage:a,material:i,productAccepted:!1,geometry:b.geometry,sourceRevision:b.source.revision,sourceSha256:c,uniformUploads:u.uniforms,productionMetrics:u.metrics,productionMetricsScope:"current-host-program-with-historical-profile4-fragment",productionReadback:{compiledProfile:P.contact.profile,sha256:await S(u.pixels),width:p,height:n,rowOrder:"bottom-up",format:"RGBA/UNSIGNED_BYTE",alpha:"premultiplied"}};if(Object.assign(r,h),r.stagePngs["production-carrier"]=u.png,u.shaders.length!==2||!u.shaders.includes(q)||!u.shaders.includes(H)||u.requestedShaders.length!==2||!u.requestedShaders.includes(Q)||!u.requestedShaders.includes(H))throw new Error("tint-stage-production-profile-mismatch");const f={prepared:W(u.prepared,l.width,l.height),"production-carrier":u.png},x={};r.stagePngs=f,r.stageReceipts=x;const w=Oe(p,n,l.width,l.height,u.prepared,u.uniforms,u.dither);try{r.gpu=w.metadata;const B=await S(JSON.stringify({id:t.id,revision:t.source.revision,geometry:b.geometry,fill:m,foreground:v,contact:b.contact,profile:t.profile})),C=await S(JSON.stringify(u.uniforms));let R=0;const E=async(_,T=0)=>{const A=w.draw(_,T);return R++,f[_]=["baseline","candidate"].includes(_)?A.png:W(A.top,p,n),x[_]={width:p,height:n,frameSha256:B,uniformSha256:C,sourceSha256:c,dither:_==="baseline"||_==="candidate"?u.dither:!1,shaderSha256:await S(fe(_)),rawBottomUpSha256:await S(A.raw),topDownSha256:await S(A.top),meanUniform:_==="candidate"||_==="new-target"||_==="target-clamp"?Math.fround(T):null},A},D=await E("baseline");Me(u.pixels,D.raw,"tint-stage-baseline-mismatch"),r.baselineReplay="byte-identical-raw-premultiplied-bottom-up";const te=await E("tone"),V=X(te.top,1),pe=Uint8Array.from(V.mask,_=>_?255:0),ge=await S(pe),O={id:t.id,sourceRevision:t.source.revision,sourceSha256:c,preparedSha256:await S(u.prepared),frameSha256:B,uniformSha256:C,maskSha256:ge,profile:t.profile},F={...Re(V.values,V.mask),binding:{...O}};ne(F.binding,O),r.binding=O,r.observedMean=F;const U={tone:te};for(const _ of["postlight-r","postlight-g","postlight-b","input-clamp","old-target","new-target","target-clamp","candidate"]){ne(F.binding,O);const T=await E(_,F.value);if(U[_]=T,_==="candidate")continue;if(X(T.top,_.startsWith("postlight-")?2:1).mask.some((K,Y)=>K!==V.mask[Y]))throw new Error(`tint-stage-mask-drift-${_}`)}const me=X(U["old-target"].top,1).values,he=X(U["new-target"].top,1).values,k=ce(m,v),I=Ee(k.luminanceBound),N=V.values.map((_,T)=>({tone:_,oldTarget:me[T],newTarget:he[T],opaque:V.mask[T],low:U["target-clamp"].top[T*4]===255,high:U["target-clamp"].top[T*4+1]===255}));let re=0;for(const _ of N)if(_.opaque){const T=ue(_.tone,F.value,I,k.lightForeground),A=2*y.toneError+y.targetError;if(Math.abs(T.baseline-_.oldTarget)>A||Math.abs(T.candidate-_.newTarget)>A)throw new Error("tint-stage-target-arithmetic-mismatch");const K=k.lightForeground?0:I,Y=k.lightForeground?I:1;if(Math.abs(T.raw-K)<=A||Math.abs(T.raw-Y)<=A)re++;else if(T.low!==_.low||T.high!==_.high)throw new Error("tint-stage-clamp-flag-mismatch")}const ae=Ie(N,p,n,D.top,U.candidate.top,{mean:F.value,bound:I,light:k.lightForeground});f["whole-shape-clipping-map"]=W(ae.clipMap,p,n);const{clipMap:qe,...ve}=ae,_e=await se(f.candidate,t);return{...h,evidenceKind:"native-diagnostic",status:"collected-native-diagnostic",candidateGeneralTransfer:y.candidateGeneralTransfer,material:i,candidate:_e,binding:O,baselineReplay:"byte-identical-raw-premultiplied-bottom-up",observedMean:F,safety:{baseline:ie(D.raw,m,v),candidate:ie(U.candidate.raw,m,v)},gpu:w.metadata,precision:{toneError:y.toneError,targetError:y.targetError,unresolvedTargetIntervals:re,unresolvedIsNotPass:!0},costs:ve,stagePngs:f,stageReceipts:x,postlightInputClamp:{lowPixels:N.filter((_,T)=>_.opaque&&U["input-clamp"].top[T*4]===255).length,highPixels:N.filter((_,T)=>_.opaque&&U["input-clamp"].top[T*4+1]===255).length},rampObservation:{width:p,height:n,samples:N},boundCode:I,lightForeground:k.lightForeground,diagnosticCost:{stageDraws:R,stageReadbacks:R,productionInternalReadbacks:u.productionInternalReadbacks,captureReadbacks:u.captureReadbacks,totalReadbacks:R+u.productionInternalReadbacks+u.captureReadbacks,preparedBytesPerUpload:u.prepared.length,preparedTextureUploads:2,productionUploadedBytes:u.uploadedBytes,stageUploadedBytes:u.prepared.length+8,totalUploadedBytes:u.uploadedBytes+u.prepared.length+8,maximumLiveWebGLContexts:2,productionDraws:u.metrics.renders,totalDrawsIncludingProduction:R+u.metrics.renders,totalDiagnosticWallMilliseconds:performance.now()-o}}}finally{w.dispose()}}finally{u.dispose()}}const He=y.rampDomains.flatMap(([e,r])=>[1,-1].flatMap(o=>[!0,!1].map(t=>({id:`ramp-${e}-${r}-${o===1?"forward":"reverse"}-${t?"light":"dark"}-foreground`,low:e,high:r,direction:o,lightForeground:t}))));async function Xe(e){const r=He.find(i=>i.id===e.id);if(!r||JSON.stringify(r)!==JSON.stringify(e))throw new Error("tint-stage-unregistered-ramp");const o=256,t=64,s=Array.from({length:o},(i,h)=>Math.round(e.low+(e.high-e.low)*(e.direction===1?h:o-1-h)/(o-1)));Ae(s,e.direction);const l=Uint8Array.from(Array.from({length:t},()=>s.flatMap(i=>[i,i,i,255])).flat()),c=W(l,o,t),g=e.lightForeground?[0,97/255,204/255,1]:[.9,.94,1,1],a=e.lightForeground?[1,1,1,1]:[0,0,0,1],m={id:e.id,sourceOrigin:"predeclared-generated-ramp",control:"tinted",phase:0,theme:"synthetic",part:"kernel",content:"continuous-ramp",head:y.originalHead,tree:y.originalTree,source:{revision:1,width:o,height:t,pixelSha256:await S(l),rect:{x:0,y:0,width:o,height:t}},geometry:{x:0,y:0,width:o,height:t},raster:{clip:{x:0,y:0,width:o,height:t},hostOffset:{x:0,y:0}},cells:[],exclusions:[],outset:0,profile:P.contact.profile,contactPhase:"rest",fill:g,foreground:a,files:{source:{file:`${e.id}-source.png`,sha256:await S(G(c)),bytes:G(c).length},"source-crop":{file:`${e.id}-source.png`,sha256:await S(G(c)),bytes:G(c).length}}},v=await ze({frame:m,pngs:{source:c,"source-crop":c}});if(v.status==="failed")return{...v,ramp:e,sourcePng:c};if(!("rampObservation"in v)||!v.rampObservation||!("observedMean"in v)||!v.observedMean)throw new Error("tint-stage-ramp-incomplete");const b=32,u=33,d=223,p=v.rampObservation.samples.slice(b*o+u,b*o+d),n=Ce(p,v.observedMean.value,v.boundCode,v.lightForeground,e.direction);return{...v,ramp:e,sourcePng:c,registeredObservation:{x:u,y:b,width:d-u,height:1,adjacency:"horizontal immediate neighbors; contiguous intervals; direction predeclared",sourceWidth:o,sourceHeight:t,postlightToneMin:Math.min(...p.map(i=>i.tone)),postlightToneMax:Math.max(...p.map(i=>i.tone))},veto:n}}export{y as T,ze as a,Xe as r,S as t,ie as v};
