const _="move-up",E=t=>[t.path({d:"M8 6L12 2L16 6"}),t.path({d:"M12 2V22"})];export{_ as LUCIDE_ICON_NAME,E as LUCIDE_MOVE_UP_SHAPE_FACTORY,E as default};
