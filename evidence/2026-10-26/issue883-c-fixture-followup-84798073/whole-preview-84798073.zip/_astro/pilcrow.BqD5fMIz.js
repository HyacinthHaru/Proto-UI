const a="pilcrow",p=t=>[t.path({d:"M13 4v16"}),t.path({d:"M17 4v16"}),t.path({d:"M19 4H9.5a4.5 4.5 0 0 0 0 9H13"})];export{a as LUCIDE_ICON_NAME,p as LUCIDE_PILCROW_SHAPE_FACTORY,p as default};
