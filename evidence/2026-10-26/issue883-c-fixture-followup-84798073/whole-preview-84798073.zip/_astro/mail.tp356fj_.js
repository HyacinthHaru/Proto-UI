const a="mail",_=t=>[t.path({d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"}),t.rect({x:2,y:4,width:20,height:16,rx:2})];export{a as LUCIDE_ICON_NAME,_ as LUCIDE_MAIL_SHAPE_FACTORY,_ as default};
