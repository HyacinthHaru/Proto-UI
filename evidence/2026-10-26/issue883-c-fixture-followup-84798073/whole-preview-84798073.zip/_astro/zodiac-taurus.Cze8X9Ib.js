const t="zodiac-taurus",A=c=>[c.circle({cx:12,cy:15,r:6}),c.path({d:"M18 3A6 6 0 0 1 6 3"})];export{t as LUCIDE_ICON_NAME,A as LUCIDE_ZODIAC_TAURUS_SHAPE_FACTORY,A as default};
