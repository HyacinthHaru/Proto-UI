import{c as e}from"./range-readout-demo.shared.Dc_CljyO.js";const o=e("base","meter");export{o as default};
