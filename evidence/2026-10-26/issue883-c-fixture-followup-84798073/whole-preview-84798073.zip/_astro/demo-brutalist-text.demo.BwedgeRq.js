import{c as t}from"./text-atom-demo.UAwOB98E.js";const o=t("brutalist");export{o as default};
