const h="smartphone",e=t=>[t.rect({width:14,height:20,x:5,y:2,rx:2,ry:2}),t.path({d:"M12 18h.01"})];export{h as LUCIDE_ICON_NAME,e as LUCIDE_SMARTPHONE_SHAPE_FACTORY,e as default};
