const C="circle-small",_=c=>c.circle({cx:12,cy:12,r:6});export{_ as LUCIDE_CIRCLE_SMALL_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,_ as default};
