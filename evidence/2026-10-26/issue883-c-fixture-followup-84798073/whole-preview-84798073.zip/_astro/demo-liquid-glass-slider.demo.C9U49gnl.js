import{c as e}from"./numeric-input-demo.shared.63ecZFH3.js";const s=e("liquid-glass","slider");export{s as default};
