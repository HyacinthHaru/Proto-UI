const h="option",o=t=>[t.path({d:"M3 3h6l6 18h6"}),t.path({d:"M14 3h7"})];export{h as LUCIDE_ICON_NAME,o as LUCIDE_OPTION_SHAPE_FACTORY,o as default};
