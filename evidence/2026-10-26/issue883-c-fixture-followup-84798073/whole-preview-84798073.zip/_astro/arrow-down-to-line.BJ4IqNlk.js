const _="arrow-down-to-line",a=t=>[t.path({d:"M12 17V3"}),t.path({d:"m6 11 6 6 6-6"}),t.path({d:"M19 21H5"})];export{a as LUCIDE_ARROW_DOWN_TO_LINE_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
