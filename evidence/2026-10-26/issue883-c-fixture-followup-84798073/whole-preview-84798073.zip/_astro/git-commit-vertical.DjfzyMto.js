const c="git-commit-vertical",_=t=>[t.path({d:"M12 3v6"}),t.circle({cx:12,cy:12,r:3}),t.path({d:"M12 15v6"})];export{_ as LUCIDE_GIT_COMMIT_VERTICAL_SHAPE_FACTORY,c as LUCIDE_ICON_NAME,_ as default};
