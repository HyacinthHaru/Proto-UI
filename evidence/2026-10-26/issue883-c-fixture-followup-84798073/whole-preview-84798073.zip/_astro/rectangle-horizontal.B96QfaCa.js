const e="rectangle-horizontal",E=t=>t.rect({width:20,height:12,x:2,y:6,rx:2});export{e as LUCIDE_ICON_NAME,E as LUCIDE_RECTANGLE_HORIZONTAL_SHAPE_FACTORY,E as default};
