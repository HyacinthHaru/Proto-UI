const C="circle-parking",_=c=>[c.circle({cx:12,cy:12,r:10}),c.path({d:"M9 17V7h4a3 3 0 0 1 0 6H9"})];export{_ as LUCIDE_CIRCLE_PARKING_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,_ as default};
