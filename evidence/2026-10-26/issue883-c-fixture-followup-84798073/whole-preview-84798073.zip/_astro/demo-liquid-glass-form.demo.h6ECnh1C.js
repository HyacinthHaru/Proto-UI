import{c as o}from"./form-primitives-demo.shared.D_0x5a3N.js";const e=o("liquid-glass","form");export{e as default};
