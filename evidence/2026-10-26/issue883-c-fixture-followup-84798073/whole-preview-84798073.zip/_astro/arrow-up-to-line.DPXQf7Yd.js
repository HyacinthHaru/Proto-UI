const _="arrow-up-to-line",a=t=>[t.path({d:"M5 3h14"}),t.path({d:"m18 13-6-6-6 6"}),t.path({d:"M12 7v14"})];export{a as LUCIDE_ARROW_UP_TO_LINE_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
