const _="plus",a=t=>[t.path({d:"M5 12h14"}),t.path({d:"M12 5v14"})];export{_ as LUCIDE_ICON_NAME,a as LUCIDE_PLUS_SHAPE_FACTORY,a as default};
