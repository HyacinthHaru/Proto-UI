const a="move-horizontal",o=t=>[t.path({d:"m18 8 4 4-4 4"}),t.path({d:"M2 12h20"}),t.path({d:"m6 8-4 4 4 4"})];export{a as LUCIDE_ICON_NAME,o as LUCIDE_MOVE_HORIZONTAL_SHAPE_FACTORY,o as default};
