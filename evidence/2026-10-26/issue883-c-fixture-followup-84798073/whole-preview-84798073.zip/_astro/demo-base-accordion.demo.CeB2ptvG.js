import{c as o}from"./accordion-demo.shared.BCzPLs3X.js";const c=o("base");export{c as default};
