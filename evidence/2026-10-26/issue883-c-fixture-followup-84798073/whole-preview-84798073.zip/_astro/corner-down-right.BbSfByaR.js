const _="corner-down-right",a=t=>[t.path({d:"m15 10 5 5-5 5"}),t.path({d:"M4 4v7a4 4 0 0 0 4 4h12"})];export{a as LUCIDE_CORNER_DOWN_RIGHT_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
