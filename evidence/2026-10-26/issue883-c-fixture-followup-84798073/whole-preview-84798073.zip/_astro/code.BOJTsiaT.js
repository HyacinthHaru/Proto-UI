const C="code",E=t=>[t.path({d:"m16 18 6-6-6-6"}),t.path({d:"m8 6-6 6 6 6"})];export{E as LUCIDE_CODE_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,E as default};
