const t="check",E=C=>C.path({d:"M20 6 9 17l-5-5"});export{E as LUCIDE_CHECK_SHAPE_FACTORY,t as LUCIDE_ICON_NAME,E as default};
