const C="search-check",t=c=>[c.path({d:"m8 11 2 2 4-4"}),c.circle({cx:11,cy:11,r:8}),c.path({d:"m21 21-4.3-4.3"})];export{C as LUCIDE_ICON_NAME,t as LUCIDE_SEARCH_CHECK_SHAPE_FACTORY,t as default};
