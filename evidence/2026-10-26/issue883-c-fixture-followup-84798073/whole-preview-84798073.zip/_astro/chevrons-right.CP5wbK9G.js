const _="chevrons-right",C=t=>[t.path({d:"m6 17 5-5-5-5"}),t.path({d:"m13 17 5-5-5-5"})];export{C as LUCIDE_CHEVRONS_RIGHT_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,C as default};
