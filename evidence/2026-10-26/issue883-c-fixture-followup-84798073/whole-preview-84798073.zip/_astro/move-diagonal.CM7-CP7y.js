const t="move-diagonal",_=a=>[a.path({d:"M11 19H5v-6"}),a.path({d:"M13 5h6v6"}),a.path({d:"M19 5 5 19"})];export{t as LUCIDE_ICON_NAME,_ as LUCIDE_MOVE_DIAGONAL_SHAPE_FACTORY,_ as default};
