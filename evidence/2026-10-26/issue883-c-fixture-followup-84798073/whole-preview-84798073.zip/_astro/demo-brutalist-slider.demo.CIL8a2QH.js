import{c as e}from"./numeric-input-demo.shared.63ecZFH3.js";const r=e("brutalist","slider");export{r as default};
