import{c as e}from"./range-readout-demo.shared.Dc_CljyO.js";const r=e("brutalist","progress");export{r as default};
