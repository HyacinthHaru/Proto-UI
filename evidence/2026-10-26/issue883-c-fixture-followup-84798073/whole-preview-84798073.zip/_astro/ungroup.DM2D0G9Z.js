const e="ungroup",h=t=>[t.rect({width:8,height:6,x:5,y:4,rx:1}),t.rect({width:8,height:6,x:11,y:14,rx:1})];export{e as LUCIDE_ICON_NAME,h as LUCIDE_UNGROUP_SHAPE_FACTORY,h as default};
