const _="arrow-down",a=t=>[t.path({d:"M12 5v14"}),t.path({d:"m19 12-7 7-7-7"})];export{a as LUCIDE_ARROW_DOWN_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,a as default};
