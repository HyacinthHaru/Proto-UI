const a="power",E=t=>[t.path({d:"M12 2v10"}),t.path({d:"M18.4 6.6a9 9 0 1 1-12.77.04"})];export{a as LUCIDE_ICON_NAME,E as LUCIDE_POWER_SHAPE_FACTORY,E as default};
