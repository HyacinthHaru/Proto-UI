const a="undo",_=t=>[t.path({d:"M3 7v6h6"}),t.path({d:"M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13"})];export{a as LUCIDE_ICON_NAME,_ as LUCIDE_UNDO_SHAPE_FACTORY,_ as default};
