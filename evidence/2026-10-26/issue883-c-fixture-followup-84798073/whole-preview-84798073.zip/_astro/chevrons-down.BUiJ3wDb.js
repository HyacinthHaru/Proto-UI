const _="chevrons-down",o=t=>[t.path({d:"m7 6 5 5 5-5"}),t.path({d:"m7 13 5 5 5-5"})];export{o as LUCIDE_CHEVRONS_DOWN_SHAPE_FACTORY,_ as LUCIDE_ICON_NAME,o as default};
