const C="check-line",E=t=>[t.path({d:"M20 4L9 15"}),t.path({d:"M21 19L3 19"}),t.path({d:"M9 15L4 10"})];export{E as LUCIDE_CHECK_LINE_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,E as default};
