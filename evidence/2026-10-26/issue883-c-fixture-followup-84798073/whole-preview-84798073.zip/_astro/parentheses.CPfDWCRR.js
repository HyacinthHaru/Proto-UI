const E="parentheses",s=t=>[t.path({d:"M8 21s-4-3-4-9 4-9 4-9"}),t.path({d:"M16 3s4 3 4 9-4 9-4 9"})];export{E as LUCIDE_ICON_NAME,s as LUCIDE_PARENTHESES_SHAPE_FACTORY,s as default};
