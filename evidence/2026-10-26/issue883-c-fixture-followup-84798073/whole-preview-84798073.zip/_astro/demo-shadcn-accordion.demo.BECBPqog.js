import{c as o}from"./accordion-demo.shared.BCzPLs3X.js";const d=o("shadcn");export{d as default};
