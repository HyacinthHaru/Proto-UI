import{c as a}from"./calendar-demo.shared.B1ZDDaFF.js";import"./caption-composition.CDeYNojy.js";const d=a("shadcn");export{d as default};
