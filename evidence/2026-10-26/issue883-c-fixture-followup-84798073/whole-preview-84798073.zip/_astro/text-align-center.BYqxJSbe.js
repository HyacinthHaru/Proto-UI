const E="text-align-center",_=t=>[t.path({d:"M21 5H3"}),t.path({d:"M17 12H7"}),t.path({d:"M19 19H5"})];export{E as LUCIDE_ICON_NAME,_ as LUCIDE_TEXT_ALIGN_CENTER_SHAPE_FACTORY,_ as default};
