const C="egg",E=t=>t.path({d:"M12 2C8 2 4 8 4 14a8 8 0 0 0 16 0c0-6-4-12-8-12"});export{E as LUCIDE_EGG_SHAPE_FACTORY,C as LUCIDE_ICON_NAME,E as default};
