const a="type",h=t=>[t.path({d:"M12 4v16"}),t.path({d:"M4 7V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2"}),t.path({d:"M9 20h6"})];export{a as LUCIDE_ICON_NAME,h as LUCIDE_TYPE_SHAPE_FACTORY,h as default};
