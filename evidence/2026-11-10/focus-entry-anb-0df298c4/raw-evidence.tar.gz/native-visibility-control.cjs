const { createRequire } = require('node:module');
const { resolve } = require('node:path');
const { chromium } = createRequire(resolve('apps/www/package.json'))('playwright-core');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH });
  try {
    const page = await browser.newPage();
    const result = await page.evaluate(() => {
      const cases = [
        { display: 'block', cv: 'visible' },
        { display: 'block', cv: 'hidden' },
        { display: 'inline', cv: 'hidden' },
        { display: 'contents', cv: 'hidden' },
        { display: 'contents', cv: 'visible' },
        { display: 'none', cv: 'visible' },
        { display: 'block', cv: 'hidden', topLayer: true },
        { display: 'none', cv: 'visible', topLayer: true },
      ];
      const results = [];
      for (const { display, cv, topLayer } of cases) {
        const outer = document.createElement('div');
        outer.style.display = display;
        outer.style.contentVisibility = cv;
        const middle = document.createElement('div');
        if (topLayer) middle.popover = 'manual';
        const button = document.createElement('button');
        button.textContent = 'Focus entry target';
        middle.append(button);
        outer.append(middle);
        document.body.append(outer);
        if (topLayer) {
          try { middle.showPopover(); }
          catch (error) { results.push({ display, cv, topLayer, error: String(error) }); outer.remove(); continue; }
        }
        const parent = getComputedStyle(outer);
        results.push({
          display, cv, topLayer: !!topLayer, computedDisplay: parent.display,
          computedCv: parent.contentVisibility, nativeVisible: button.checkVisibility(),
          rects: button.getClientRects().length,
        });
        outer.remove();
      }
      const computed = getComputedStyle(document.body);
      const chain = [];
      for (let prototype = Object.getPrototypeOf(computed); prototype; prototype = Object.getPrototypeOf(prototype)) {
        const descriptor = Object.getOwnPropertyDescriptor(prototype, 'display');
        chain.push({ name: prototype.constructor?.name, ownDisplay: !!descriptor,
                     getter: descriptor?.get?.toString(), setter: descriptor?.set?.toString() });
      }
      return { cases: results, computedPrototypeChain: chain };
    });
    console.log(JSON.stringify({ browser: browser.version(), ...result }, null, 2));
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
