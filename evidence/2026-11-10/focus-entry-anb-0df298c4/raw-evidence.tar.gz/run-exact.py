import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
from zoneinfo import ZoneInfo

root = pathlib.Path('<checkout>')
state = pathlib.Path(__file__).parent
kind, expected, name = sys.argv[1:]
assert kind in ('contents', 'dialog')
assert datetime.datetime.now(ZoneInfo('Asia/Singapore')).time() < datetime.time(10, 50)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == expected
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
out = state / name
out.mkdir()
probe = pathlib.Path('apps/www/src/content/docs/zh-cn') / (
    'homepage-dogfood.browser.test.ts' if kind == 'contents' else 'dialog-available-space.browser.test.ts'
)
env = os.environ.copy()
env['PATH'] = '<task-state>/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:/opt/homebrew/bin:' + env['PATH']
env['CHROME_PATH'] = '<task-state>/proto-ui-883/continue-20261023T123632Z/browser-source/cache/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'
env.update(
    PROTO_UI_DIALOG_INTEGRITY_PATH=str(out/'runner-integrity.json'),
    PROTO_UI_DIALOG_JSON_PATH=str(out/'vitest.json'),
    PROTO_UI_RUNTIME_EVIDENCE_DIR=str(out),
    CANDIDATE_SHA=head,
)
if kind == 'dialog':
    env.update(PROTO_UI_DIALOG_PROBE_SHA=head, PROTO_UI_DIALOG_SUBJECT='candidate')
command = ['corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run', '--no-file-parallelism', str(probe)]
if kind == 'contents':
    command += ['-t', 'uses real family Contents Buttons']
command += [
    '--reporter=./scripts/test/dialog-run-integrity-reporter.mjs',
    '--reporter=default', '--reporter=json', '--outputFile='+str(out/'vitest.json'),
]
source = (root/probe).read_bytes()
(out/'executed-test.ts').write_bytes(source)
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
r = dict(
    startedAt=now(), command=command, head=head,
    tree=subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip(),
    sourceSha256=hashlib.sha256(source).hexdigest(), originalAssertionsAndDeadlines=True,
    node=subprocess.check_output(['node','--version'], env=env, text=True).strip(),
    browser=subprocess.check_output([env['CHROME_PATH'], '--version'], env=env, text=True).strip(),
)
(out/'receipt.json').write_text(json.dumps(r, indent=2)+'\n')
with (out/'browser.log').open('w') as log:
    try:
        r['exitCode'] = subprocess.run(command, cwd=root, env=env, stdout=log,
                                      stderr=subprocess.STDOUT, timeout=420).returncode
    except subprocess.TimeoutExpired:
        r['outerTimeout'] = True
r['finishedAt'] = now()
r['endHead'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
r['endClean'] = not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
(out/'receipt.json').write_text(json.dumps(r, indent=2)+'\n')
print(json.dumps(r))
sys.exit(r.get('exitCode', 124))
