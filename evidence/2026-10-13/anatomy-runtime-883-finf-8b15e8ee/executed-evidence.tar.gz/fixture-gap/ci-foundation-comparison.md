这是一份 **历史checkpoint 67eb84e4 对精确foundation 53327519** 的只读CI比较。父代理已报告 #872 又推进至3ce1b6ac，并在另行同步；本报告没有比较或认证该新组合，不称latest，不称目标完成。没有启动新run、build、browser或下载第二份日志，原始CI材料未修改。

来源分别是 #872 run38327699078（head533，synthetic checkout2143d59f，tree5db67982）和 #884 run38334879543（head67，synthetic checkoutd68b94f4，tree170211c2）。两个checkout分别已被原收据绑定为对应head的完全相同tree。读取的raw log SHA均与原下载/checkout收据一致。

四个具有完整Vitest总结的browser分片1/3/4/5，两次都是305pass、37fail、15skip；这只是四分片子集，不是八分片总计。逐标题匹配结果是37/37完全相同，涉及9个失败测试文件，这9个文件在533/67的Gitblob也完全相同。然而：

- 只有35/37个首行错误message逐字相同。React colorScheme initial-dark失败仍是Switch expected alpha0.075、actual0.12，但记录帧数由12变11；Vue同项仍是Button expectedalpha0.2，11帧数量相同，但前六个background alpha样本不同（例如0.0913033与0.0912263），后面均有0.2。
- 只移除CI时间戳和ANSI后，完整错误body有29/37相同、8份不同。除上述2个frames message外，5处错误body包含不同projection owner id及HTML截断细节；S4 paint的旧call log还有“performing click action”，67的相应日志止于“done scrolling”。因此不能声称实际click进展或完整错误字节完全一致。
- Tooltip分片5的唯一失败正文相同；其余共同失败覆盖S4 paint、colorScheme、RadioGroup、S5、overlay scrollbar、Liquid Glass Collapsible、Dialog available-space与Homepage projection scope。JSON保留每一失败标题、原日志行号、两份完整message/body和实际diff。

这些是同一断言上的观测重合，不是相同rootcause证明，也不证明全部失败“继承所以可忽略”、没有新增退化、或C/A完整接受。相同测试blob不意味着其Runtime、模块、宿主、网络、cache和调度条件相同。

| 完整分片 | 两次实际结果 | 失败标题对账 |
| --- | --- | --- |
| 1/8 | 46pass／1fail | 1个相同标题，S4paint call-log进度不同 |
| 3/8 | 38pass／22fail | 22个相同标题，2个frames message及2个owner-id body不同 |
| 4/8 | 150pass／13fail | 13个相同标题，3个owner-id body不同 |
| 5/8 | 71pass／1fail／15skip | 1个相同标题和相同错误body |

分片2/6/7/8在两次run均以124结束，没有完整Vitest总结。已打印的失败标题和简短message集合各自相同：2为overlay direction的6行；6为native links的2行；7为shadow-closeout与home-runtime的6行；8为Brutalist/homepage的9行。这些仅是deadline前已经输出的失败行，不是分片总失败数。7/8的停止位置并不相同：533末尾到Docs shadcn320px，而67已到390px。完整partial suite rows、stage headings及两边特有heading均保留；没有把未打印结果视为通过，也不把partial行加成八分片总计。

两个test-general均在Vitest之前被public-docs的78项drift挡住，逐条错误列表相同。这个对账没有创造任何general通过数。

九个package entry的gzip、minified、SHA、ceiling、overBudget和PASS/ADVISORY均从两份canonical raw log独立解析，并与两份producer JSON逐字段复核。环境的五个记录字段完全相同：Node `v24.21.0`、zlib `1.3.2.1-motley-8002e91`、esbuild `0.25.12`、Linux、x64。策略JSON也相同；两次都是47/47build、47manifests，4PASS／5ADVISORY，ceilings不变。

| Entry | 533 gzip → 67 gzip | gzip差值 | minified差值 | minified SHA |
| --- | ---: | ---: | ---: | --- |
| lucide/icons/x | 1737 → 1737 | +0 | +0 | 相同 |
| lucide root | 635777 → 635777 | +0 | +0 | 相同 |
| core root | 8037 → 8037 | +0 | +0 | 相同 |
| runtime root | 86131 → 86175 | +44 | +56 | 变化，原值均保留 |
| adapter-react root | 129638 → 129650 | +12 | +71 | 变化，原值均保留 |
| adapter-vue root | 129378 → 129403 | +25 | +62 | 变化，原值均保留 |
| adapter-web-component root | 155456 → 155502 | +46 | +63 | 变化，原值均保留 |
| prototypes-base/button | 3946 → 3946 | +0 | +0 | 相同 |
| prototypes-shadcn/button | 4927 → 4927 | +0 | +0 | 相同 |

变化仅见于四个测量entry：Runtime gzip+44/minified+56；React+12/+71；Vue+25/+62；WC+46/+63。另五项连同minified SHA均相同。这里不重新构建、不把gzip按文件或entry相加归因、不声称全局最优或预算批准。记录环境字段相同也不能证明所有runner/cache状态相同；预算job成功仍使用Finf advisory，不是九项strictPASS。

完整内容、日志SHA、源码blob和方法见 `ci-foundation-comparison.json`；只读解析脚本为 `ci-foundation-compare.py`。当前结论保持human-assisted/current-user、unassessed、partial/ABSTAIN，新3ce组合必须用自身实际验证另行记录。
