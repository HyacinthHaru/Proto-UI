三次专属原生证据workflow均已终态failure。本报告只读取新run metadata、完整分页jobs和每job一次下载的原始log；未启动测试、build、浏览器、CI重跑或main collector。

三次run各1完整page／1job／attempt1。实际checkout日志分别直接打印 `67eb84e47d5e7ef8d0846328dbf8432f1e274685`，不是synthetic SHA。三个run API的head_commit.tree_id与本地Git67tree均为 `170211c2ca52fe9b72b8ef604f9fdaf0a10607f1`。这绑定初始checkout，不能额外声称已审计所有untracked/generated/cache或finaldirty状态。

| 新run与job | 实际执行结果 | 首失败／未执行边界 |
| --- | --- | --- |
| [Field38334879542 /115092600114](https://github.com/Proto-UI/Proto-UI/actions/runs/38334879542/job/115092600114) | 1file，25tests：22pass、3fail、0skip | Liquid Glass React首先在Label点击后的focus poll219失败；Vue/Vue2同点失败，WC过。失败case后续Tab/validity/edit等未执行。 |
| [Bootstrap38334879564 /115092599933](https://github.com/Proto-UI/Proto-UI/actions/runs/38334879564/job/115092599933) | 前置Node边界测试9/9pass；preset检查失败；browser没有启动 | Shadcn483tokens与Brutalist437tokens先通过，draft-family generator17随后报bootstrap-2-3-2 unsupported physicalstyle token。Collect realfour-runtimeevidence step被skip。 |
| [Collapsible38334879569 /115092600784](https://github.com/Proto-UI/Proto-UI/actions/runs/38334879569/job/115092600784) | 1file，36tests：32pass、4fail、0skip | Liquid Glass WC首先在focused helper78/caller302失败，React/Vue/Vue2同点失败；其余32项过。失败case后续open capture／Space／lifecycle旅程未执行。 |

上述Field22/3与Collapsible32/4是各新log独立解析的实际结果，即使与旧计数相同也未复用旧证据。两种failure都为1000ms poll未取得true；Field诊断保留pending attempt，Collapsible只读诊断也timeout，没有据此推断实际activeElement值、共同根因或flake。

Bootstrap专属workflow计划给browser step设置 `PROTO_UI_BOOTSTRAP_BROWSER_EVIDENCE=1`，但前置失败使该step根本未启动。其四个计划文件（Bootstrap controls、native-editor oracle、disabled-paint oracle、15case browser suite）均未执行。不能把它写成默认CI未opt-in时的“15个Vitest skips”，也不是15个browser failed assertions。日志未说明具体unsupported token，未做额外根因调查或修复。

CI环境均实报Node `v24.21.0`、pnpm `10.32.1 --frozen-lockfile`、Ubuntu24.04.5（runner image ubuntu24/20261004.327）、Chrome路径 `/usr/bin/google-chrome`；确切Chrome版本未在这些原job log中打印，不推测。Astro devToolbar配置步骤均成功。Field与Collapsible实际worker1/1；Field为default+JSON reporter，job25min／native step20min；Collapsiblejob25min。Bootstrapjob20min，plannedworker1/1没有执行。完整命令、env、源workflowblob在JSON。

每个run的 `dedicated/<run>/run.json`、`jobs-pages.json`、`job-<id>.log`为实际raw材料；clean.log仅去除ANSI，不改变raw。artifact metadata与官方digest也已保留，但没有下载或视阅artifactZIP/PNG，不作新视觉验收声明。该receipt不替代父代理唯一main CI collector66954，也不预判全部C／A／Finf交付或独立批准。
