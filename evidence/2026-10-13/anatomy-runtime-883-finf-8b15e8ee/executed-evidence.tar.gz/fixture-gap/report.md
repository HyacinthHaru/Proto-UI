已准备2文件私有修复，不修改生产源码、产品树或index。补丁为 `candidate.patch`（1983 bytes，SHA256 `97d29f019516a07651d7a660570d0d4c94ac674a0727a544c8131b621bbaa681`），`git apply --check` 已对私有949原字节快照通过；没有实际应用。

两份目标文件在533与949均逐blob相同：

- `packages/spec/fixtures/src/lifecycle/callback-order.ts`：`38fb1772414f53a9be3a4489d2636a139d450edd`。
- `spec/tests/T-LIFECYCLE-0001.yaml`：`86eb9b8570ca8962036e93c8a8aaad974060fa0f`。

因此这是上游已存在的静态登记缺口。T-LIFECYCLE-0001（draft）已有 `T-LIFECYCLE-0001-CASE-FAILED-CREATED-TERMINAL-CLEANUP`，明确covers G/J与 expectation `failed-created-primary-preserved-acquired-resources-terminally-released`；fixture union、数据数组和fixture implementation consumesCases没有登记。原覆盖测试会检查所有catalog case都有fixture，以及consumesCases与catalog cases相等，补丁完整修复两个缺口。

callback-order.ts仅增加该expectation字面量和一个case，covers与expectation逐字跟随T，notes明确数据fixture只记录portable expectation、实际资源和Delay执行证据由Runtime测试提供。没有增加expectedOrder或伪造执行trace。YAML只在既有fixture consumesCases下增加同id；T case、criteria、lifecycle状态和原测试断言均不改变。

静态对账为catalog8cases、fixture由7补到8、consumesCases由7补到8，补后集合相等，见 `static-alignment.json`。这不是执行通过声明。父代理报告949原general有11865pass/362fail/36TODO及此具体漏登记失败；本子任务未重跑general或focused测试，原focused红、应用后验证与独审由父代理执行。533官方general此前在public-docs阶段退出，本报告不声称它实际执行过这个失败unit。

baseline/candidate两文件完整快照、SHA256/Gitblob在 `candidate-change.json`；权限及权威链在 `authority-map.json`。当前结论为human-assisted/current-user、unassessed、partial/ABSTAIN，只交付候选，无GitHub批准。
