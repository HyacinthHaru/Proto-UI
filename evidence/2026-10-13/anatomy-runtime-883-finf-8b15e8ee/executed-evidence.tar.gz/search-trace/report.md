Search 普通选项重复值缺陷已在固定合并候选中实际复现，并提供私有三文件最小修复。结论为 human-assisted、unassessed、partial/ABSTAIN；这是实现贡献与局部验证，不是独立审批。

输入是尚未提交的 Git tree `485bf5f498c0d92f132afc670e269c5bf22650ed`，由 #884 parent `b1e62928c205e318da615a77b4e457f1736fd7de` 与 #872 foundation `533275191fe08aa0de679c764592721c1aa3720c` 合并。`source-history.json` 显示三个目标文件在 tree485 与 b1e 相同；533 的 Search family/draft 与 b1e 不同，故没有将纯533或旧b1e测试冒充组合测试。完整源码从固定 Git tree 导出，现有依赖仅通过链接复用；产品工作树和 index 未由本子任务修改。

[反馈4252722844](https://github.com/Proto-UI/Proto-UI/pull/872#discussion_r4252722844) 原为待验证指控。期望先于修复建立：三份公开 Search 文档第19行已有 duplicate-valued choices rejected 投影；10/10 record 记载 Combobox existing enabled unique key，但记录非规范。现有 `internal/contracts/prototype-base/search-selection-completion.v0.md` 是 uncataloged draft，原本只固定 completion/retirement。本轮先在该 draft 增加 bounded admission：同 Root 中全部当前已注册选项按 value 精确匹配必须唯一，再要求唯一项 visible/enabled；filter=false 不豁免唯一性；不引入新的 Autocomplete free-text duplicate-key 政策。没有升级任何 draft 为 active。

生命周期和宿主边界保持原链：draft C-ANATOMY-0008-B 约束 partsOf 只返回当前 domain 的实际 same-family parts；draft C-LIFECYCLE-0002-I 的 authored 同 checkpoint FIFO 和 J 的 created-failure cleanup 不定义 Search 唯一性；draft HC-CONTEXT-ANCESTRY-0001-E 负责 owner ancestry 优先级，WC 无 owner facts 的物理 ancestry fallback 仍由 Adapter 提供；active C-LIFECYCLE-0008 区分 L1 epoch 与 terminal dispose。现有 Search 的 viewEpoch、selectionSequence、State/Context 后重验和 Command inline 行为全部未改。

`itemsOf`（baseline family.ts73–83）读取同 domain 的所有 registered item metadata；`visibleItems`（143–147）随后只按 query/text/keywords 过滤。原 select（216–222）在 visibleItems 上计算 matching.length，因此过滤后的单个可见项被误当作逻辑唯一。私有修复只将既有 free-text 判定提前，并在非 free-text 时加一个 full-items exact-value count guard；原 visible/enabled、controlled proposals、intent 与 continuation 路径保留。

| 最终同字节测试运行 | 收集 | 通过 | 失败 | 实际结论 |
| --- | ---: | ---: | ---: | --- |
| `run-baseline-final-minimal-diff` | 25 | 16 | 9 | 三种 family 的 hidden duplicate、hidden disabled duplicate、controlled duplicate 均错误接受并发出 intent |
| `run-candidate-final-minimal-diff` | 25 | 25 | 0 | 仅覆盖 Search family 源码修复后全部通过 |

基线 Combobox 的 Alpha/Beta 两项均保留 value shared，query Alpha 只显示第一项；select(shared) 返回 true，提交 shared，清空 query 后两项 selected 均为 true。Autocomplete 错误提交 Alpha；Command 错误发出 execute(shared)。controlled 变体在 owner 不改变 value 的情况下也错误发出 ambiguous proposal。`filter=false` 的双可见重复拒绝、唯一但隐藏/disabled 的拒绝、正常唯一项的模式特定提交、受控 owner refusal、既有 keyboard/IME/readOnly 行为与 unmatched Autocomplete free text 控制均通过。

测试复用实际公开 WC Adapter、实际 Runtime 和三种实际 Search family，使用 `setElementProps` 完整作者快照及公开 Root `getExposes().select/setInputValue`。原文件9项测试保留，新增16项直接覆盖。旧 input/keyboard 事件仍是 Happy DOM synthetic dispatch；新增选择由公开 Expose 调用。没有真实 Chrome、trusted native input、像素、AT 或其它 Adapter 运行声明。未额外验证 nested Root isolation、free-text 与 duplicate key 同字符串的新政策或全面生命周期矩阵；这些不被本局部通过替代。每项沿用已有 created/dispose 计数清理断言，无新增 timer 或恢复更新。

最终命令在两个 run 目录的 `receipt.json` 中逐字保存，均为 pinned Node24.21.0 执行现有 Vitest2.1.9，原 tree485 Vite aliases 加私有 test 路径映射，worker1，Happy DOM15.11.7、Vite5.4.21；每次约1.1秒。私有 config 不更改原断言或时间参数，避免收集整个仓库。`final-executed-source-binding.json` 对实际记录的 transform 输入逐一核对：基线366个 tracked input 全部等于485 Git blobs；候选365个相同输入加1个明确的 family override，另1个私有测试。两次测试和 config 字节完全一致，前后输入哈希不变。外部预打包依赖没有冒充 Git 输入或完整依赖哈希证明。

保留全部尝试，不能只报最终绿：首次配置路径错误没有收集测试；第一版夹具误把 `setElementProps` 当增量更新，导致作者快照丢字段；完整快照修正后9个核心 red 保留。首轮 candidate 的2个残余失败是错误要求 Command active-selected=false，已按 Command 既有 active-selected 语义纠正，核心 reject/no-intent 断言未放宽。最后去除两个原测试格式变化后再次绑定最终同字节 red/green；所有更早日志、执行源码与收据均保留。

可应用材料是 `candidate.patch`（3文件、10,443 bytes、SHA256 `18eb29e619d7cc2244fc227b992870ffeffc56e5730ff969bd7473ce10488f23`）。`git apply --check` 已对485私有快照通过；未实际应用到产品。`candidate-files.json` 给出三个 baseline/final Git blob 与 SHA256。父代理需在自己的合并提交后应用、运行整合验证并由另一 reviewer 独立复审；本报告不宣称 #884 可合并或 GitHub 已批准。
