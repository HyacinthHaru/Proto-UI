import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import base from "./source-485bf5f4/vitest.config";
import { mergeConfig } from "./source-485bf5f4/node_modules/vitest/config";

const sourceRoot = path.resolve(__dirname, "source-485bf5f4");
const testPath = path.resolve(
  __dirname,
  "candidate/final/packages/prototypes/base/test/navigation-overlays/search.test.ts",
);
const familyPath = path.join(
  sourceRoot,
  "packages/prototypes/base/src/search-primitives/family.ts",
);
const outputDir = process.env.SEARCH_PROBE_OUTPUT!;
const inputs = new Map<string, unknown>();

export default mergeConfig(base, {
  root: sourceRoot,
  cacheDir: path.join(outputDir, "vite-cache"),
  plugins: [
    {
      name: "fixed-search-probe-source",
      enforce: "pre",
      resolveId(id, importer) {
        if (
          importer?.split("?")[0] === testPath &&
          /^\.\.\/\.\.\/src\//.test(id)
        ) {
          return path.join(
            sourceRoot,
            "packages/prototypes/base/src",
            id.slice("../../src/".length),
            "index.ts",
          );
        }
      },
      load(id) {
        if (id === familyPath && process.env.SEARCH_PROBE_FAMILY_OVERRIDE) {
          return fs.readFileSync(
            process.env.SEARCH_PROBE_FAMILY_OVERRIDE,
            "utf8",
          );
        }
      },
      transform(code, id) {
        const file = id.split("?")[0];
        if (!file.startsWith(sourceRoot + path.sep) && file !== testPath)
          return;
        if (!fs.existsSync(file)) return;
        const actual =
          file === familyPath && process.env.SEARCH_PROBE_FAMILY_OVERRIDE
            ? process.env.SEARCH_PROBE_FAMILY_OVERRIDE
            : file;
        const bytes = fs.readFileSync(actual);
        inputs.set(file, {
          resolved: file,
          actual,
          sha256: crypto.createHash("sha256").update(bytes).digest("hex"),
          transformedInputSha256: crypto
            .createHash("sha256")
            .update(code)
            .digest("hex"),
          bytes: bytes.length,
        });
      },
      closeBundle() {
        fs.mkdirSync(outputDir, { recursive: true });
        fs.writeFileSync(
          path.join(outputDir, "loaded-inputs.json"),
          JSON.stringify([...inputs.values()], null, 2) + "\n",
        );
      },
    },
  ],
  test: {
    include: [testPath],
    fileParallelism: false,
    maxWorkers: 1,
    minWorkers: 1,
    reporters: ["verbose", "json"],
    outputFile: { json: path.join(outputDir, "vitest.json") },
  },
});
