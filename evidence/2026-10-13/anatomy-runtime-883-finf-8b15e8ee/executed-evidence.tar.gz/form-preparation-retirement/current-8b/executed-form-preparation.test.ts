import { afterAll, afterEach, expect, it } from 'vitest';
import { writeFileSync } from 'node:fs';
import path from 'node:path';
import { definePrototype } from '@proto.ui/core';
import { formRoot, FORM_FAMILY } from '@proto.ui/prototypes-base/form';
import { createRuntimeSession } from '@proto.ui/runtime';
import {
  ANATOMY_INSTANCE_TOKEN_CAP,
  ANATOMY_PARENT_CAP,
  ANATOMY_GET_PROTO_CAP,
  ANATOMY_ROOT_TARGET_CAP,
} from '@proto.ui/module-anatomy';
import { CONTEXT_INSTANCE_TOKEN_CAP, CONTEXT_PARENT_CAP } from '@proto.ui/module-context';
import { EVENT_ROOT_TARGET_CAP, EVENT_GLOBAL_TARGET_CAP } from '@proto.ui/module-event';
import { EXPOSE_EVENT_SINK_CAP } from '@proto.ui/module-expose-event';
import {
  AS_TRIGGER_INSTANCE_CAP,
  AS_TRIGGER_PARENT_CAP,
  AS_TRIGGER_GET_PROTO_CAP,
} from '@proto.ui/module-as-trigger';
import { EXPOSES_RECORD_SINK_CAP } from '@proto.ui/module-expose-state';

const sessions = new Set<ReturnType<typeof createRuntimeSession>>();
const observations: unknown[] = [];
afterEach(async () => {
  for (const session of [...sessions].reverse()) await session.dispose();
  sessions.clear();
});
afterAll(() =>
  writeFileSync(
    path.join(process.env.FORM_PROBE_OUTPUT!, 'observations.json'),
    JSON.stringify(observations, null, 2) + '\n'
  )
);

function runtimeHarness() {
  const parents = new Map<any, any>(),
    protos = new Map<any, any>();
  let actionCallback = (_name: string) => {};
  const actions: string[] = [];
  const events: Array<{ name: string; payload: unknown }> = [];
  function make(proto: any, parent: any = null, props: any = {}) {
    const listeners = new Map<string, Set<any>>();
    const target = {
      addEventListener(type: string, fn: any) {
        if (!listeners.has(type)) listeners.set(type, new Set());
        listeners.get(type)!.add(fn);
      },
      removeEventListener(type: string, fn: any) {
        listeners.get(type)?.delete(fn);
      },
      dispatchEvent(event: Event) {
        for (const fn of [...(listeners.get(event.type) ?? [])]) fn(event);
        return true;
      },
    } as unknown as EventTarget;
    parents.set(target, parent);
    protos.set(target, proto);
    let exposes: any;
    const session = createRuntimeSession(proto, {
      prototypeName: proto.name,
      getRawProps: () => props,
      schedule: (fn) => fn(),
      scheduleDelay: (ms, fn) => {
        const id = setTimeout(fn, ms);
        return { cancel: () => clearTimeout(id) };
      },
      commit: (_c, s) => s?.done(),
      onRuntimeReady(w) {
        w.attach('anatomy', [
          [ANATOMY_INSTANCE_TOKEN_CAP, target],
          [ANATOMY_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [ANATOMY_GET_PROTO_CAP, (t: any) => protos.get(t)],
          [ANATOMY_ROOT_TARGET_CAP, (t: any) => t],
        ]);
        w.attach('context', [
          [CONTEXT_INSTANCE_TOKEN_CAP, target],
          [CONTEXT_PARENT_CAP, (t: any) => parents.get(t) ?? null],
        ]);
        w.attach('event', [
          [EVENT_ROOT_TARGET_CAP, () => target],
          [EVENT_GLOBAL_TARGET_CAP, () => target],
        ]);
        w.attach('as-trigger', [
          [AS_TRIGGER_INSTANCE_CAP, target],
          [AS_TRIGGER_PARENT_CAP, (t: any) => parents.get(t) ?? null],
          [AS_TRIGGER_GET_PROTO_CAP, (t: any) => protos.get(t)],
        ]);
        w.attach('expose-state', [
          [
            EXPOSES_RECORD_SINK_CAP,
            (x: any) => {
              exposes = x;
            },
          ],
        ]);
        w.attach('expose-event', [
          [
            EXPOSE_EVENT_SINK_CAP,
            (name: string, payload: unknown) => {
              events.push({ name, payload });
              actions.push(name);
              if (
                name === 'valueChange' ||
                name === 'execute' ||
                name === 'openChange' ||
                name === 'validationRequest'
              )
                actionCallback(name);
            },
          ],
        ]);
      },
    });
    sessions.add(session);
    return {
      session,
      target,
      get exposes() {
        return exposes;
      },
    };
  }

  return {
    make,
    actions,
    events,
    setActionCallback(fn: (name: string) => void) {
      actionCallback = fn;
    },
  };
}

for (const point of ['pending-cancel', 'submitted-clear'] as const)
  it.each(['normal', 'unmount', 'dispose', 'remount', 'nested'] as const)(
    `Form preparation ${point} preserves only current authority: %s`,
    async (operation) => {
      const { make, actions, events } = runtimeHarness();
      const form = make(formRoot);
      const calls: number[] = [];
      const fields = [0, 1].map((index) =>
        make(
          definePrototype({
            name: `preparation-${point}-${operation}-${index}`,
            setup(def) {
              def.anatomy.claim(FORM_FAMILY, { role: 'field' });
              const pending = def.state.bool('pending', point === 'pending-cancel');
              def.expose.method('complete', () => pending.set(false, 'field validation complete'));
              def.expose.method('validate', () => calls.push(index));
              def.expose.method('__formField', () => ({
                name: 'field-' + index,
                value: 'valid',
                disabled: false,
                available: true,
                implicitSubmit: false,
                validity: {
                  status: 'valid',
                  invalid: false,
                  pending: pending.get(),
                  dirty: false,
                  touched: false,
                  filled: true,
                  focused: false,
                  flags: [],
                  errors: [],
                },
              }));
            },
          }),
          form.target
        )
      );
      for (const part of [form, ...fields]) await part.session.mount();
      const submit = () => form.session.invokeInCallbackScope(() => form.exposes.requestSubmit());
      const completeFields = () => {
        for (const field of fields)
          field.session.invokeInCallbackScope(() => field.exposes.complete());
      };
      expect(submit()).toBe(true);
      expect(form.exposes.pending.get()).toBe(point === 'pending-cancel');
      expect(form.exposes.submitted.get()).toBe(point === 'submitted-clear');
      calls.length = 0;
      actions.length = 0;
      events.length = 0;
      const pendingPublications: unknown[] = [];
      const stopPending = form.exposes.pending.subscribe((event: any) => {
        if (event.type === 'next') pendingPublications.push(event.next);
      });
      const transitions: Promise<unknown>[] = [];
      const lifecycleErrors: unknown[] = [];
      let observed = false,
        nested: unknown,
        result: unknown,
        thrown: unknown;
      const track = (value: Promise<unknown>) =>
        transitions.push(value.catch((error) => lifecycleErrors.push(error)));
      const state = point === 'pending-cancel' ? 'pending' : 'submitted';
      const stopBoundary = form.exposes[state].subscribe((event: any) => {
        if (event.type !== 'next' || event.next !== false || observed) return;
        observed = true;
        if (operation === 'nested') {
          completeFields();
          nested = submit();
        } else if (operation !== 'normal') {
          track(operation === 'dispose' ? form.session.dispose() : form.session.unmount());
          if (operation === 'remount') track(form.session.mount());
        }
      });
      try {
        result = submit();
      } catch (error) {
        thrown = error;
      }
      await Promise.all(transitions);
      const beforeFresh = {
        point,
        operation,
        observed,
        result,
        nested,
        error: thrown instanceof Error ? { name: thrown.name, message: thrown.message } : thrown,
        lifecycleErrors: lifecycleErrors.map((e: any) => ({ name: e?.name, message: e?.message })),
        instancePhase: form.session.instancePhase,
        mountPhase: form.session.mountPhase,
        pending: operation === 'dispose' ? 'disposed' : form.exposes.pending.get(),
        submitted: operation === 'dispose' ? 'disposed' : form.exposes.submitted.get(),
        calls: [...calls],
        events: [...events],
        pendingPublications: [...pendingPublications],
      };
      observations.push(beforeFresh);
      stopBoundary();
      stopPending();
      expect(thrown).toBeUndefined();
      expect(lifecycleErrors).toEqual([]);
      expect(observed).toBe(true);
      expect(result).toBe(true);
      if (operation === 'dispose') {
        expect(beforeFresh.instancePhase).toBe('disposed');
        expect(beforeFresh.calls).toEqual([]);
        expect(beforeFresh.events).toEqual([]);
        return;
      }
      if (operation === 'normal') {
        expect(beforeFresh.calls).toEqual([0, 1]);
        expect(beforeFresh.pending).toBe(point === 'pending-cancel');
        if (point === 'pending-cancel') {
          completeFields();
          form.session.invokeInCallbackScope(() => form.exposes.__fieldChanged());
        }
        expect(form.exposes.pending.get()).toBe(false);
        expect(events).toEqual([
          {
            name: 'submit',
            payload: { values: { 'field-0': 'valid', 'field-1': 'valid' }, submissionId: 2 },
          },
        ]);
      } else if (operation === 'nested') {
        expect(nested).toBe(true);
        expect(beforeFresh.pending).toBe(false);
        expect(beforeFresh.submitted).toBe(true);
        expect(beforeFresh.calls).toEqual([0, 1]);
        expect(events).toEqual([
          {
            name: 'submit',
            payload: { values: { 'field-0': 'valid', 'field-1': 'valid' }, submissionId: 2 },
          },
        ]);
      } else {
        expect(beforeFresh.pending).toBe(false);
        expect(beforeFresh.calls).toEqual([]);
        expect(beforeFresh.events).toEqual([]);
        if (operation === 'unmount') await form.session.mount();
        expect(form.exposes.pending.get()).toBe(false);
        completeFields();
        form.session.invokeInCallbackScope(() => form.exposes.__fieldChanged());
        expect(events).toEqual([]);
        expect(submit()).toBe(true);
        expect(form.exposes.pending.get()).toBe(false);
        expect(events).toEqual([
          {
            name: 'submit',
            payload: { values: { 'field-0': 'valid', 'field-1': 'valid' }, submissionId: 2 },
          },
        ]);
      }
    }
  );

it.each(['normal', 'throw', 'nested-throw', 'dispose-throw', 'remount-throw'] as const)(
  'Form validation failure ends only its own submission: %s',
  async (operation) => {
    const { make, actions } = runtimeHarness();
    const form = make(formRoot);
    const error = new Error('field validation failed');
    let first = true,
      nested: unknown;
    const calls: number[] = [];
    const fields = [0, 1].map((index) =>
      make(
        definePrototype({
          name: 'throwing-validation-field-' + index,
          setup(def) {
            def.anatomy.claim(FORM_FAMILY, { role: 'field' });
            def.expose.method('__formField', () => ({
              name: 'field-' + index,
              value: 'valid',
              disabled: false,
              available: true,
              validity: {
                status: 'valid',
                invalid: false,
                pending: false,
                dirty: false,
                touched: false,
                filled: true,
                focused: false,
                flags: [],
                errors: [],
              },
            }));
            def.expose.method('validate', () => {
              calls.push(index);
              if (index || !first || operation === 'normal') return;
              first = false;
              if (operation === 'nested-throw') nested = form.exposes.requestSubmit();
              if (operation === 'dispose-throw') void form.session.dispose();
              if (operation === 'remount-throw') {
                void form.session.unmount();
                void form.session.mount();
              }
              throw error;
            });
          },
        }),
        form.target
      )
    );
    for (const part of [form, ...fields]) await part.session.mount();
    actions.length = 0;
    try {
      const submit = () => form.session.invokeInCallbackScope(() => form.exposes.requestSubmit());
      if (operation === 'normal') expect(submit).not.toThrow();
      else expect(submit).toThrow(error);
      if (operation === 'dispose-throw') {
        expect(form.session.instancePhase).toBe('disposed');
        return;
      }
      expect(form.exposes.pending.get()).toBe(false);
      if (operation === 'nested-throw') {
        expect(nested).toBe(true);
        expect(actions).toEqual(['submit']);
        expect(form.exposes.submitted.get()).toBe(true);
      } else if (operation !== 'normal') {
        expect(actions).toEqual([]);
        form.session.invokeInCallbackScope(() => form.exposes.__fieldChanged());
        expect(actions).toEqual([]);
        expect(form.exposes.submitted.get()).toBe(false);
      } else expect(actions).toEqual(['submit']);
    } finally {
      for (const part of [...fields.reverse(), form]) await part.session.dispose();
    }
  }
);
