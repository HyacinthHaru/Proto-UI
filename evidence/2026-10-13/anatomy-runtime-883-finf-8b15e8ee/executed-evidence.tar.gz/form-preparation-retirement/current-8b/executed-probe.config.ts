import base from '[workspace]/vitest.config';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
const repo = '[workspace]';
const revision = '8b15e8ee5d5795ec76bf4c6355a9ad9a9b47a6a6';
const output = process.env.FORM_PROBE_OUTPUT!;
const tracked = new Set(
  execFileSync('git', ['ls-tree', '-r', '--name-only', revision], { cwd: repo, encoding: 'utf8' })
    .trim()
    .split('\n')
);
const loaded = new Map();
const save = () =>
  fs.writeFileSync(
    path.join(output, 'loaded-inputs.json'),
    JSON.stringify([...loaded.values()], null, 2) + '\n'
  );
process.on('exit', save);
export default {
  ...base,
  root: repo,
  cacheDir: path.join(output, 'vite-cache'),
  plugins: [
    {
      name: 'fixed-form-preparation-source',
      enforce: 'pre',
      load(id) {
        const file = id.split('?')[0].replace(/^\/@fs/, '');
        const relative = path.relative(repo, file);
        if (!tracked.has(relative)) return null;
        const source =
          relative === 'packages/prototypes/base/src/form/root.proto.ts' &&
          process.env.FORM_PROBE_OLD_FORM === '1'
            ? '3ce1b6acdab94eee3dff93409dd43dd8ce3702aa'
            : revision;
        const bytes = execFileSync('git', ['show', source + ':' + relative], { cwd: repo });
        loaded.set(relative, {
          path: relative,
          source,
          sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
        });
        save();
        return bytes.toString();
      },
    },
    ...(base.plugins ?? []),
  ],
  test: {
    ...base.test,
    include: [path.resolve(__dirname, 'form-preparation.test.ts')],
    maxWorkers: 1,
    minWorkers: 1,
    fileParallelism: false,
    reporters: ['verbose', 'json'],
    outputFile: { json: path.join(output, 'vitest.json') },
  },
};
