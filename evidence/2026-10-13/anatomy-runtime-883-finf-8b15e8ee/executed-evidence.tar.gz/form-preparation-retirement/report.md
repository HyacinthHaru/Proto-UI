当前 `8b15e8ee5d5795ec76bf4c6355a9ad9a9b47a6a6` 已实际覆盖 [Form新反馈4254178835](https://github.com/Proto-UI/Proto-UI/pull/872#discussion_r4254178835) 的两个准备阶段；没有发现需要新增修复的当前缺陷，未生成source patch、修改产品或重复提交。

评论针对3ce1b6ac。其requestSubmit在cancel和submitted.set(false)之后直接建立waiting/pending。当前旧884实现已经捕获current run、viewEpoch、预期cancellation generation与sequence，并在这两个边界之后检查isCurrent；cancel自身也检查被新generation或退休替代后的Context尾部。权威来自既有Form-completion draft的owner/attempt/epoch规则；notification-completion是上下文，不替代Form专属定义。active C-LIFECYCLE-0008保留instance/view分离，未新增任何稳定准入或API。

| 私有单文件执行 | 结果 | 输入边界 |
| --- | --- | --- |
| current-8b | 15/15 pass，exit0 | 307个实际Vite-loaded产品输入全部逐blob核对8b |
| only-form-3ce | 6pass／9fail，exit1 | 306个同8b输入，只替换FormRoot一个文件为3ce；不是完整3cecheckout运行 |

两次使用完全相同的测试和config字节。10个新定向case是 pending-cancel／submitted-clear 两个点各自normal、unmount、dispose、remount、nested；另5个是原validation-error控制block逐字复用。所有断言都在observer之外；observer仅调用公开请求/生命周期并记录实际值。每项最后清理所有Runtime sessions，无额外timer、全局reentry lock或恢复输入。

当前结果包括：旧请求在退休后不再验证Field或发submit，pending保持false；unmount/remount后不存在旧waiting被后来的Field完成通知复活，新的公开request仍可成功。nested合法新提交保有自己的id，只验证一次、只发一次submit；原validation error、nested newer submit和退休throw规则保持。两个normal控制确认正常等待/完成，而不是fixture全部拒绝。

旧Form单文件对照的9个红项可区分防护缺失：两个点的unmount/dispose/remount/nested共8失败，分别观察到退休pending=true、disposed后的State访问或旧调用继续/重复验证；另外普通validation throw后pending残留。其余6控制通过。完整原始状态在各run observations.json，错误与命令/版本/时间在run.log、vitest.json及receipt.json。旧Form也缺少其它已存在防护，因此不把这当成只删除两行的独立mutation归因。

执行是真实RuntimeSession与真实FormRoot，使用公开Root requestSubmit／external State.subscribe及Runtime owner mount/unmount/dispose。Field是实际definePrototype、State和Anatomy构成的作者rolefixture；不是完整FormField/native editor旅程。pending validity是明示fixture State，complete与__fieldChanged模拟Field完成通知。宿主采用synthetic EventTarget和同步commit/schedule，故只证明允许的同步回调排序，不把DOM removal等同同步退休，也不声称WC四Adapter、nativeinput、AT或视觉验收。

运行环境Node24.21.0、Vitest2.1.9、HappyDOM15.11.7，worker1；两次分别约3.92s与3.85s。`source-binding.json`逐项绑定307输入与唯一差异，`validation-controls-binding.json`证明原5case block字节未改。未操作父代理句柄；general95015在本次Form探针执行前已终态，CI98119当时仍在采集，当前以真实receipt为准；这15项不替代它们的结果。结论仍为human-assisted、unassessed、partial/ABSTAIN；这是已有防护的补充私有实证，不是新修复或独立批准。
