import { describe, expect, it, vi } from 'vitest';
import {
  definePrototype,
  HOST_ELEMENT_CAP,
  tw,
  type EffectsPort,
  type OwnedStateHandle,
  type Prototype,
  type A11ySemanticObjectSnapshot,
} from '@proto.ui/core';
import { A11Y_PROJECT_CAP } from '@proto.ui/module-a11y';
import { asAccessible, asOverlay } from '@proto.ui/hooks';
import { EXPOSE_EVENT_SINK_CAP } from '@proto.ui/module-expose-event';
import { EXPOSES_RECORD_SINK_CAP } from '@proto.ui/module-expose-state';
import { EFFECTS_CAP, type FeedbackPort } from '@proto.ui/module-feedback';
import { RAW_PROPS_SOURCE_CAP } from '@proto.ui/module-props';
import {
  HIT_PARTICIPATION_HOST_BRIDGE_CAP,
  type HitParticipationPort,
} from '@proto.ui/module-hit-participation';
import { OVERLAY_GLOBAL_MOUNT_CAP, OVERLAY_MODAL_CAP } from '@proto.ui/module-overlay';
import { createRuntimeSession, type RuntimeHost } from '../../src';

function createImmediateHost(
  onRuntimeReady?: NonNullable<RuntimeHost<any>['onRuntimeReady']>
): RuntimeHost<any> {
  return {
    prototypeName: 'lifecycle-module-resources',
    getRawProps: () => ({}),
    commit(_children, signal) {
      signal?.done();
    },
    schedule(task) {
      task();
    },
    onRuntimeReady,
  };
}

describe('runtime contract: lifecycle module resource ownership (v1)', () => {
  it('releases a failed created instance while preserving the original failure', () => {
    const failure = new Error('created callback rejected the composition');
    const records: Record<string, unknown>[] = [];
    let retainedRun: any;
    let disposed = 0;
    const proto = definePrototype({
      name: 'lifecycle-failed-created-resource-owner',
      setup(def) {
        const open = def.state.bool('open', false);
        def.expose.state('open', open);
        def.expose.event('change');
        def.lifecycle.onBeforeDispose(() => {
          disposed += 1;
        });
        def.lifecycle.onCreated((run) => {
          retainedRun = run;
          throw failure;
        });
      },
    });
    let thrown: unknown;
    try {
      createRuntimeSession(
        proto,
        createImmediateHost((wiring) => {
          wiring.attach('expose-state', [
            [EXPOSES_RECORD_SINK_CAP, (record: Record<string, unknown>) => records.push(record)],
          ]);
        })
      );
    } catch (error) {
      thrown = error;
    }
    expect(thrown).toBe(failure);
    expect(disposed).toBe(1);
    expect(records.at(-1)).toEqual({});
    expect(() => retainedRun.expose.emit('change')).toThrow();
  });

  it.each(['source', 'watcher'] as const)(
    'preserves the created failure through Props %s and terminal callback failures',
    (preparationFailure) => {
      const createdFailure = new Error('created failure');
      const propsFailure = new Error('Props source failed during terminal preparation');
      const cleanupFailure = new Error('cleanup failure');
      let open!: OwnedStateHandle<boolean>;
      let invalidateRawProps!: () => void;
      let failPropsRead = false;
      let rawSubscriptionReleased = false;
      let disposed = 0;
      const proto = definePrototype({
        name: 'lifecycle-failed-created-and-cleanup-owner',
        setup(def) {
          def.props.define({ step: { type: 'number' } });
          def.props.setDefaults({ step: 0 });
          open = def.state.bool('open', false);
          def.props.watch(['step'], () => {
            if (failPropsRead && preparationFailure === 'watcher') throw propsFailure;
          });
          def.lifecycle.onCreated(() => {
            failPropsRead = true;
            invalidateRawProps();
            throw createdFailure;
          });
          def.lifecycle.onBeforeDispose(() => {
            disposed += 1;
            throw cleanupFailure;
          });
          def.lifecycle.onBeforeDispose(() => {
            disposed += 1;
          });
        },
      });
      let thrown: unknown;
      try {
        createRuntimeSession(
          proto,
          createImmediateHost((wiring) => {
            wiring.attach('props', [
              [
                RAW_PROPS_SOURCE_CAP,
                {
                  get() {
                    if (failPropsRead && preparationFailure === 'source') throw propsFailure;
                    return { step: failPropsRead ? 1 : 0 };
                  },
                  subscribe(listener: () => void) {
                    invalidateRawProps = listener;
                    return () => {
                      rawSubscriptionReleased = true;
                    };
                  },
                },
              ],
            ]);
          })
        );
      } catch (error) {
        thrown = error;
      }
      // C-LIFECYCLE-0002-J: secondary cleanup failures cannot replace the
      // identical initiating value.
      expect(thrown).toBe(createdFailure);
      expect(disposed).toBe(2);
      expect(rawSubscriptionReleased).toBe(true);
      expect(() => open.get()).toThrow();
    }
  );

  it.each([undefined, null, false, 0, ''])(
    'preserves the created failure when cleanup throws %s',
    async (cleanupFailure) => {
      const createdFailure = new Error('created failure');
      let cleanupCalls = 0;
      const proto = definePrototype({
        name: 'lifecycle-failed-created-falsy-cleanup-owner',
        setup(def) {
          def.lifecycle.onCreated(() => {
            throw createdFailure;
          });
          def.lifecycle.onBeforeDispose(() => {
            cleanupCalls += 1;
            throw cleanupFailure;
          });
        },
      });
      let thrown: unknown;
      try {
        createRuntimeSession(proto, createImmediateHost());
      } catch (error) {
        thrown = error;
      }
      expect(thrown).toBe(createdFailure);
      // Allow the shared disposal promise to settle: failed synchronous creation
      // has no returned session from which a caller could observe that promise.
      await Promise.resolve();
      await Promise.resolve();
      expect(cleanupCalls).toBe(1);
    }
  );

  it.each([undefined, null, false, 0, ''])(
    'preserves the initiating created value %s after cleanup fails',
    (failure) => {
      let retained!: OwnedStateHandle<boolean>;
      let cleanupCalls = 0;
      const proto = definePrototype({
        name: 'lifecycle-falsy-created-failure',
        setup(def) {
          retained = def.state.bool('retained', false);
          def.lifecycle.onCreated(() => {
            throw failure;
          });
          def.lifecycle.onBeforeDispose(() => {
            cleanupCalls += 1;
            throw new Error('cleanup failure');
          });
          def.lifecycle.onBeforeDispose(() => {
            cleanupCalls += 1;
          });
        },
      });
      let thrown: unknown;
      let caught = false;
      try {
        createRuntimeSession(proto, createImmediateHost());
      } catch (error) {
        caught = true;
        thrown = error;
      }
      expect(caught).toBe(true);
      expect(thrown).toBe(failure);
      expect(cleanupCalls).toBe(2);
      expect(() => retained.get()).toThrow();
    }
  );

  it.each(['forged-ref', 'throwing-getter'])(
    'releases setup resources when initial associations fail: %s',
    async (mode) => {
      let disposed = 0;
      let created = 0;
      const failure = new Error('association transport failed');
      const records: Record<string, unknown>[] = [];
      const proto = definePrototype({
        name: 'lifecycle-failed-association-owner',
        setup(def) {
          def.expose.state('open', def.state.bool('open', false));
          def.lifecycle.onBeforeDispose(() => {
            disposed += 1;
          });
          def.lifecycle.onCreated(() => {
            created += 1;
          });
        },
      });
      const host = createImmediateHost((wiring) => {
        wiring.attach('expose-state', [
          [EXPOSES_RECORD_SINK_CAP, (record: Record<string, unknown>) => records.push(record)],
        ]);
      });
      host.getInstanceAssociations = () => {
        if (mode === 'throwing-getter') throw failure;
        return { controlLabel: {} } as any;
      };
      expect(() => createRuntimeSession(proto, host)).toThrow(
        mode === 'throwing-getter' ? failure : /opaque reference/
      );
      expect(created).toBe(0);
      expect(disposed).toBe(1);
      expect(records.at(-1)).toEqual({});
      await Promise.resolve();
    }
  );

  it('keeps Expose Event declarations across view epochs and invalidates emit at disposal', async () => {
    const emitted: string[] = [];
    let retainedRun: any;
    const proto = definePrototype({
      name: 'lifecycle-expose-event-resource-owner',
      setup(def) {
        def.expose.event('ready');
        def.lifecycle.onMounted((run) => {
          retainedRun = run;
          run.expose.emit('ready');
        });
        return (run) => run.el('div', 'ok');
      },
    });
    const session = createRuntimeSession(
      proto,
      createImmediateHost((wiring) => {
        wiring.attach('expose-event', [
          [EXPOSE_EVENT_SINK_CAP, (key: string) => emitted.push(key)],
        ]);
      })
    );

    await session.mount();
    await session.unmount();
    await session.mount();

    expect(emitted).toEqual(['ready', 'ready']);

    await session.dispose();
    expect(() => retainedRun.expose.emit('ready')).toThrow();
  });

  it('keeps Feedback logical style state while suppressing detached host flushes', async () => {
    const queued: unknown[] = [];
    const stylesSeenAtCommit: unknown[] = [];
    const effects: EffectsPort = {
      queueStyle: (style) => queued.push(style),
      requestFlush: vi.fn(),
    };
    const proto: Prototype = definePrototype({
      name: 'lifecycle-feedback-resource-owner',
      setup(def) {
        def.feedback.style.use(tw('base-token'));
        return (run) => run.el('div', 'ok');
      },
    });
    const host = createImmediateHost((wiring) =>
      wiring.attach('feedback', [[EFFECTS_CAP, effects]])
    );
    host.commit = (_children, signal) => {
      stylesSeenAtCommit.push(queued.at(-1));
      signal?.done();
    };
    const session = createRuntimeSession(proto, host);

    expect(queued).toEqual([]);
    await session.mount();
    expect(queued.length).toBeGreaterThan(0);
    expect(stylesSeenAtCommit.at(-1)).toMatchObject({
      kind: 'tw',
      tokens: expect.arrayContaining(['base-token']),
    });
    queued.length = 0;

    await session.unmount();
    await session.mount();
    expect(stylesSeenAtCommit.at(-1)).toMatchObject({
      kind: 'tw',
      tokens: expect.arrayContaining(['base-token']),
    });

    queued.length = 0;
    await session.unmount();
    const feedback = session.caps.getPort<FeedbackPort>('feedback')!;
    session.invokeInCallbackScope(() => feedback.patchStyle(tw('detached-token')));
    feedback.applyMergedStyle(tw('stale-view-token'));
    expect(queued).toEqual([]);

    await session.mount();
    expect(stylesSeenAtCommit.at(-1)).toMatchObject({
      kind: 'tw',
      tokens: expect.arrayContaining(['base-token', 'detached-token']),
    });
    expect(queued.at(-1)).toMatchObject({
      kind: 'tw',
      tokens: expect.arrayContaining(['base-token', 'detached-token']),
    });
    const off = feedback.useStyleRuntime(tw('runtime-token'));
    const unsafeOff = feedback.useStyleUnsafe(tw('hover:opacity-50'));
    await session.dispose();
    queued.length = 0;
    off();
    unsafeOff();
    feedback.applyMergedStyle(tw('after-dispose-token'));
    expect(() => feedback.useStyleRuntime(tw('after-dispose-token'))).toThrow();
    expect(() => feedback.useStyleUnsafe(tw('hover:opacity-100'))).toThrow();
    expect(() => feedback.patchStyle(tw('after-dispose-token'))).toThrow();
    expect(queued).toEqual([]);
  });

  it('suspends A11y and ExposeState host projection but publishes latest state on remount', async () => {
    const snapshots: any[] = [];
    const exposes: Record<string, unknown>[] = [];
    let disabled!: OwnedStateHandle<boolean>;
    const proto = definePrototype({
      name: 'lifecycle-projection-resource-owner',
      setup(def) {
        disabled = def.state.bool('disabled', false);
        def.expose.state('disabled', disabled);
        asAccessible().state('disabled', disabled);
        return (run) => run.el('button', 'ok');
      },
    });
    const session = createRuntimeSession(
      proto,
      createImmediateHost((wiring) => {
        wiring.attach('a11y', [
          [A11Y_PROJECT_CAP, (snapshot: A11ySemanticObjectSnapshot) => snapshots.push(snapshot)],
        ]);
        wiring.attach('expose-state', [
          [EXPOSES_RECORD_SINK_CAP, (record: Record<string, unknown>) => exposes.push(record)],
        ]);
      })
    );

    expect(snapshots).toEqual([]);
    expect(exposes.at(-1)).toHaveProperty('disabled');
    const initialExternalHandle = exposes.at(-1)?.disabled;
    await session.mount();
    expect(snapshots.at(-1)?.states.disabled).toBe(false);
    expect(exposes.at(-1)).toHaveProperty('disabled');

    await session.unmount();
    const detachedHandle = exposes.at(-1)?.disabled as { get(): boolean };
    snapshots.length = 0;
    exposes.length = 0;
    session.invokeInCallbackScope(() => disabled.set(true, 'detached update'));
    expect(snapshots).toEqual([]);
    expect(exposes).toEqual([]);
    expect(detachedHandle.get()).toBe(true);

    await session.mount();
    expect(snapshots.at(-1)?.states.disabled).toBe(true);
    expect((exposes.at(-1)?.disabled as { get(): boolean }).get()).toBe(true);
    expect(exposes.at(-1)?.disabled).toBe(initialExternalHandle);
  });

  it('keeps HitParticipation regions detached and re-syncs them on the next mount', async () => {
    const sync = vi.fn();
    const proto = definePrototype({
      name: 'lifecycle-hit-resource-owner',
      setup() {
        return (run) => run.el('div', 'ok');
      },
    });
    const session = createRuntimeSession(
      proto,
      createImmediateHost((wiring) =>
        wiring.attach('hit-participation', [[HIT_PARTICIPATION_HOST_BRIDGE_CAP, { sync }]])
      )
    );

    expect(sync).not.toHaveBeenCalled();
    await session.mount();
    expect(sync).toHaveBeenCalled();

    await session.unmount();
    sync.mockClear();
    const target = { id: 'detached-region' };
    session.caps.getPort<HitParticipationPort>('hit-participation')!.registerRegion(target);
    expect(sync).not.toHaveBeenCalled();

    await session.mount();
    expect(sync).toHaveBeenLastCalledWith(
      expect.objectContaining({ regions: [expect.objectContaining({ target })] })
    );
  });

  it('suspends Overlay host effects while preserving open state across epochs', async () => {
    const hostElement = document.createElement('div');
    const mount = vi.fn();
    const unmount = vi.fn();
    const lock = vi.fn();
    const unlock = vi.fn();
    const proto = definePrototype({
      name: 'lifecycle-overlay-resource-owner',
      setup() {
        const overlay = asOverlay();
        overlay.configure({ defaultOpen: true, portal: true, modal: true });
        return (run) => run.el('div', 'ok');
      },
    });
    const session = createRuntimeSession(
      proto,
      createImmediateHost((wiring) => {
        wiring.attach('overlay', [
          [HOST_ELEMENT_CAP, hostElement],
          [OVERLAY_GLOBAL_MOUNT_CAP, { mount, unmount }],
          [OVERLAY_MODAL_CAP, { lock, unlock }],
        ]);
      })
    );

    expect({ mount: mount.mock.calls.length, lock: lock.mock.calls.length }).toEqual({
      mount: 0,
      lock: 0,
    });
    await session.mount();
    expect(mount).toHaveBeenCalledOnce();
    expect(lock).toHaveBeenCalledOnce();

    await session.unmount();
    expect(unmount).toHaveBeenCalledOnce();
    expect(unlock).toHaveBeenCalledOnce();

    await session.mount();
    expect(mount).toHaveBeenCalledTimes(2);
    expect(lock).toHaveBeenCalledTimes(2);
  });
});
