import {afterAll,it,expect} from 'vitest';
import {writeFileSync} from 'node:fs';
import {definePrototype,delay} from '@proto.ui/core';
import {createRuntimeSession} from '@proto.ui/runtime';
import {RAW_PROPS_SOURCE_CAP} from '@proto.ui/module-props';
const observations:any[]=[];afterAll(()=>writeFileSync(__dirname+'/created-observations.json',JSON.stringify(observations,null,2)));
for(const stage of ['rawProps','associations'] as const)it(`non-created ${stage} with cleanup failure retains prior aggregate shape`,()=>{
 const primary=new Error('non-created-'+stage),secondary=new Error('cleanup-non-created');let created=0,cleanups=0,error:any;const proto=definePrototype({name:'review-non-created-'+stage,setup(def){def.lifecycle.onCreated(()=>{created++;});def.lifecycle.onBeforeDispose(()=>{cleanups++;throw secondary;});}});
 try{createRuntimeSession(proto,{prototypeName:proto.name,getRawProps:()=>{if(stage==='rawProps')throw primary;return{};},getInstanceAssociations:()=>{if(stage==='associations')throw primary;return undefined;},schedule:fn=>fn(),commit:(_c,s)=>s?.done()});}catch(e){error=e;}
 observations.push({kind:'non-created',stage,created,cleanups,aggregate:error instanceof AggregateError,errors:error instanceof AggregateError?error.errors.map((e:any)=>({primary:e===primary,secondary:e===secondary,name:e?.name,message:e?.message})):null,message:error?.message});expect(created).toBe(0);expect(cleanups).toBe(1);expect(error).toBeInstanceOf(AggregateError);expect(error.errors).toEqual([primary,secondary]);
});
it.each([false,true])('created failure cancels queued Delay and survives secondary throws=%s',secondaryThrows=>{
 const original=new Error('queued-created-primary'),secondary=new Error('queued-cleanup-secondary');const tasks:Array<{callback:()=>void;cancelled:number}>=[];let cleanups=0,released=0,diagnostics=0,delivered=0,retained:any,error:any;
 const proto=definePrototype({name:'review-created-delays',setup(def){retained=def.state.bool('retained',false);def.lifecycle.onCreated(()=>{delay(25,()=>delivered++);delay(50,()=>delivered++);throw original;});def.lifecycle.onBeforeDispose(()=>{cleanups++;if(secondaryThrows)throw secondary;});def.lifecycle.onBeforeDispose(()=>{cleanups++;});}});
 try{createRuntimeSession(proto,{prototypeName:proto.name,getRawProps:()=>({}),schedule:fn=>fn(),commit:(_c,s)=>s?.done(),scheduleDelay(_ms,callback){const task={callback,cancelled:0};tasks.push(task);return{cancel(){task.cancelled++;if(secondaryThrows)throw secondary;}};},onRuntimeReady(w){w.attach('props',[[RAW_PROPS_SOURCE_CAP,{get:()=>({}),subscribe:()=>()=>{released++;if(secondaryThrows)throw secondary;}}]]);},onLifecycleEvent(event){if(event.type==='instance.dispose.begin'||event.type==='instance.dispose.done'){diagnostics++;if(secondaryThrows)throw secondary;}}});}catch(e){error=e;}
 for(const task of tasks)task.callback();let invalid=false;try{retained.get();}catch{invalid=true;}
 observations.push({kind:'created-delay-secondary',secondaryThrows,sameOriginal:error===original,errorName:error?.name,cleanups,released,diagnostics,cancellations:tasks.map(x=>x.cancelled),delivered,retainedInvalid:invalid});expect(error).toBe(original);expect(cleanups).toBe(2);expect(released).toBe(1);expect(diagnostics).toBe(2);expect(tasks.map(x=>x.cancelled)).toEqual([1,1]);expect(delivered).toBe(0);expect(invalid).toBe(true);
});
it('ordinary explicit dispose keeps aggregation of terminal callback failures',async()=>{
 const one=new Error('ordinary-one'),two=new Error('ordinary-two');const proto=definePrototype({name:'review-ordinary-dispose',setup(def){def.lifecycle.onBeforeDispose(()=>{throw one;});def.lifecycle.onBeforeDispose(()=>{throw two;});}});const session=createRuntimeSession(proto,{prototypeName:proto.name,getRawProps:()=>({}),schedule:fn=>fn(),commit:(_c,s)=>s?.done()});let error:any;try{await session.dispose();}catch(e){error=e;}observations.push({kind:'ordinary-dispose',aggregate:error instanceof AggregateError,errorCount:error?.errors?.length,disposed:session.instancePhase});expect(error).toBeInstanceOf(AggregateError);expect(error.errors).toEqual([one,two]);expect(session.instancePhase).toBe('disposed');
});
