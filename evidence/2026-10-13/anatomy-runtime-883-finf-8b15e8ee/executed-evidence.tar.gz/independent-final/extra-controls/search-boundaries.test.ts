import {afterAll,it,expect} from 'vitest';
import {writeFileSync} from 'node:fs';
import {definePrototype} from '@proto.ui/core';
import {runtimeHarness} from './runtime-harness';
import * as autocomplete from '[workspace]/packages/prototypes/base/src/autocomplete';
import * as combobox from '[workspace]/packages/prototypes/base/src/combobox';
import * as command from '[workspace]/packages/prototypes/base/src/command';
const observations:any[]=[];afterAll(()=>writeFileSync(__dirname+'/search-observations.json',JSON.stringify(observations,null,2)));
for(const [slug,mod,family] of [['autocomplete',autocomplete,autocomplete.AUTOCOMPLETE_FAMILY],['combobox',combobox,combobox.COMBOBOX_FAMILY],['command',command,command.COMMAND_FAMILY]] as const)
it(`${slug} controlled outer uniqueness is isolated from nested Root duplicates`,async()=>{
 const {make,actions}=runtimeHarness();let focused=0;
 const role=(name:string)=>definePrototype({name:'review-'+slug+'-'+name,setup(def){def.anatomy.claim(family,{role:name});if(name==='input')def.expose.method('focusSelf',()=>focused++);}});
 const root=make((mod as any)[slug+'Root'],null,{value:'owner',inputValue:'',open:true}),input=make(role('input'),root.target),content=make(role('content'),root.target),item=make((mod as any)[slug+'Item'],content.target,{value:'shared',textValue:'Outer'});
 const inner=make((mod as any)[slug+'Root'],content.target),innerContent=make(role('content'),inner.target),a=make((mod as any)[slug+'Item'],innerContent.target,{value:'shared',textValue:'Alpha'}),b=make((mod as any)[slug+'Item'],innerContent.target,{value:'shared',textValue:'Beta'});
 const all=[root,input,content,item,inner,innerContent,a,b];for(const x of all)await x.session.mount();actions.length=0;
 try{const outerAccepted=root.call(()=>root.exposes.select('shared'));const afterOuter=[...actions];const innerAccepted=inner.call(()=>inner.exposes.select('shared'));observations.push({kind:'nested-root',slug,outerAccepted,innerAccepted,afterOuter,actions:[...actions],value:root.exposes.value.get(),inputValue:root.exposes.inputValue.get(),open:root.exposes.open.get(),focused});expect(outerAccepted).toBe(true);expect(innerAccepted).toBe(false);expect(root.exposes.value.get()).toBe('owner');expect(root.exposes.inputValue.get()).toBe('');expect(root.exposes.open.get()).toBe(true);expect(actions.filter(x=>x==='valueChange'||x==='execute')).toEqual([slug==='command'?'execute':'valueChange']);expect(actions).toEqual(afterOuter);}finally{for(const x of all.reverse())await x.session.dispose();}
});
it.each(['Alpha',''])(`Autocomplete preserves explicit free-text duplicate-suggestion commitment query=%s`,async query=>{
 const {make,actions}=runtimeHarness();const family=autocomplete.AUTOCOMPLETE_FAMILY;const contentProto=definePrototype({name:'review-free-content',setup(def){def.anatomy.claim(family,{role:'content'});}});const root=make(autocomplete.autocompleteRoot),content=make(contentProto,root.target),a=make(autocomplete.autocompleteItem,content.target,{value:'shared',textValue:'Alpha'}),b=make(autocomplete.autocompleteItem,content.target,{value:'shared',textValue:'Beta'});const all=[root,content,a,b];for(const x of all)await x.session.mount();root.call(()=>root.exposes.setInputValue(query));actions.length=0;
 try{const accepted=root.call(()=>root.exposes.select('shared','free-text'));const value=root.exposes.value.get();observations.push({kind:'free-text-original-path',query,accepted,value,actions:[...actions]});expect(accepted).toBe(true);expect(value).toBe(query?'Alpha':'shared');expect(actions.filter(x=>x==='valueChange')).toHaveLength(1);}finally{for(const x of all.reverse())await x.session.dispose();}
});
