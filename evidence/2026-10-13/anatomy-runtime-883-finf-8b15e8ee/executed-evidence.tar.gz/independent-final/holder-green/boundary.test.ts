import {afterAll,it,expect} from 'vitest';
import {writeFileSync} from 'node:fs';
import {definePrototype} from '@proto.ui/core';
import {createRuntimeSession} from '@proto.ui/runtime';
import {runtimeHarness} from './runtime-harness';
import {accordionRoot,accordionItem} from '[workspace]/packages/prototypes/base/src/accordion';
import {ACCORDION_CONTEXT} from '[workspace]/packages/prototypes/base/src/accordion/shared';
import {calendarRoot,CALENDAR_CONTEXT} from '[workspace]/packages/prototypes/base/src/calendar';
const observations:any[]=[];afterAll(()=>writeFileSync(__dirname+'/observations.json',JSON.stringify(observations,null,2)));
const err=(e:any)=>e&&({name:e.name,code:e.code,message:e.message,stack:e.stack});
for(const boundary of ['openCount','context'] as const)it.each(['normal','unmount','dispose','remount'] as const)(`Accordion ${boundary} observer %s`,async operation=>{
 const {make,actions}=runtimeHarness();const root=make(accordionRoot);const item=make(accordionItem,root.target,{value:'a'});let armed=false,once=false;const pending:Promise<void>[]=[];
 const retire=()=>{if(!armed||once||operation==='normal')return;once=true;pending.push(root.session[operation==='dispose'?'dispose':'unmount']());if(operation==='remount')pending.push(root.session.mount());};
 const observer=make(definePrototype({name:'review-accordion-context-observer',setup(def){def.context.subscribe(ACCORDION_CONTEXT,(_run,next)=>{if(boundary==='context'&&next.openItems.includes('a'))retire();});}}),root.target);
 for(const p of [root,item,observer])await p.session.mount();root.exposes.openCount.subscribe((e:any)=>{if(boundary==='openCount'&&e.type==='next'&&e.next===1)retire();});armed=true;actions.length=0;let failure:any,accepted:any;
 try{try{accepted=root.call(()=>root.exposes.requestOpen('a',true));}catch(e){failure=e;}await Promise.all(pending);observations.push({kind:'accordion',boundary,operation,accepted,error:err(failure),actions:[...actions],instance:root.session.instancePhase,epoch:root.session.mountEpoch});expect(failure).toBeUndefined();expect(accepted).toBe(true);expect(actions).toEqual(operation==='normal'?['openChange']:[]);}finally{armed=false;for(const p of [observer,item,root])await p.session.dispose();}
});
for(const boundary of ['value','context','monthChange'] as const)it.each(['normal','unmount','dispose','remount'] as const)(`Calendar ${boundary} observer %s`,async operation=>{
 const {make,actions,setActionCallback}=runtimeHarness();const root=make(calendarRoot,null,{defaultMonth:'2026-01',defaultValue:'2026-01-10'});let armed=false,once=false;const pending:Promise<void>[]=[];
 const retire=()=>{if(!armed||once||operation==='normal')return;once=true;pending.push(root.session[operation==='dispose'?'dispose':'unmount']());if(operation==='remount')pending.push(root.session.mount());};
 const observer=make(definePrototype({name:'review-calendar-context-observer',setup(def){def.context.subscribe(CALENDAR_CONTEXT,(_run,next)=>{if(boundary==='context'&&next.value==='2026-02-10')retire();});}}),root.target);
 for(const p of [root,observer])await p.session.mount();root.exposes.value.subscribe((e:any)=>{if(boundary==='value'&&e.type==='next'&&e.next==='2026-02-10')retire();});setActionCallback(name=>{if(boundary==='monthChange'&&name==='monthChange')retire();});armed=true;actions.length=0;let failure:any,accepted:any;
 try{try{accepted=root.call(()=>root.exposes.requestValue('2026-02-10'));}catch(e){failure=e;}await Promise.all(pending);observations.push({kind:'calendar',boundary,operation,accepted,error:err(failure),actions:[...actions],instance:root.session.instancePhase,epoch:root.session.mountEpoch});expect(failure).toBeUndefined();expect(accepted).toBe(true);expect(actions).toEqual(operation==='normal'?['monthChange','valueChange']:boundary==='monthChange'?['monthChange']:[]);}finally{armed=false;for(const p of [observer,root])await p.session.dispose();}
});
it.each([false,true])('Created failure original identity cleanupThrows=%s',cleanupThrows=>{
 const original=new Error('unique-created-error'),cleanup=new Error('unique-cleanup-error');let captured:any,error:any,cleanups=0;
 const proto=definePrototype({name:'review-created-identity',setup(def){captured=def.state.bool('retained',false);def.lifecycle.onCreated(()=>{throw original;});def.lifecycle.onBeforeDispose(()=>{cleanups++;if(cleanupThrows)throw cleanup;});}});
 try{createRuntimeSession(proto,{prototypeName:proto.name,getRawProps:()=>({}),schedule:fn=>fn(),commit:(_c,s)=>s?.done()});}catch(e){error=e;}
 let retainedInvalid=false;try{captured.get();}catch{retainedInvalid=true;}
 observations.push({kind:'created-failure',cleanupThrows,error:err(error),sameOriginal:error===original,aggregateErrors:error instanceof AggregateError?error.errors.map((e:any)=>({sameOriginal:e===original,sameCleanup:e===cleanup,name:e?.name,message:e?.message})):null,cleanups,retainedInvalid});expect(cleanups).toBe(1);expect(retainedInvalid).toBe(true);expect(error).toBe(original);
});
