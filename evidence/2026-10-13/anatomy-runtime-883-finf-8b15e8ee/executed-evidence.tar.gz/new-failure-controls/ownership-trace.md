当前证据支持将这个真实红项暂归 **WC 初始 Shadow acquisition 的错误报告与 mount acknowledgement 交接（#883 A／跨 owner 边界）**。没有证据表明本轮 Runtime created-J 修复违反适用 C criterion；也不能把测试判为过时或因485同样失败而豁免。此结论是只读、human-assisted、unassessed、partial/ABSTAIN，A 范围尚未验收。

父代理的原两文件控制在固定485与949都是6tests、1Shadow fail／5pass；唯一不同loaded TS路径是Runtime session，但Vite之外direct FS读取没有被固定。这组对照仅证明相同失败在两个固定输入组出现，不独立证明其归属或根因。site-native-anchor的full-run失败在这两次控制中未复现，原因仍未知；`site-native-controls.test.ts:46`直接读取browser测试文本，不在396个Vite loaded-input绑定保证内。

父代理随后在67eb84e4执行一次单case诊断，只在原finally、parent.remove前打印原有数组，未修改断言、timeout或同步schedule。实际exit1仍为原line84的not.toContain(mount.mounted)。原test SHA为 `bc7b5204a3bc8e6540c975763413c7e20294d88a2abccc6ea1ba57615ab02531`，派生诊断test SHA为 `464fddf9810de631cff7f5e7d5e2492225dec13d9cd79ff3e6c3a1165a57652d`；376个Git67输入加1个私有test override。原ledger把override的source标签也写67，receipt已按真实字节哈希纠正分类，未覆盖raw ledger。不能把377个路径都称为原Git源码。

真实错误是 `[shadcn-dialog-mask]rule token "hidden":I1 recipe; fix: companion or change/remove token`。原stack经过 `shadow-split-effects.ts:441 prepare` → `adapt.ts:934 project` → `feedback/src/create.ts:439 projectFinalStyle` → `replaceVisualRuntime`。真实diagnostics包含成功的instance.created，随后mount.commit.start/done → mount.mounted → instance.dispose.begin → unmount.begin/done → instance.dispose.done。没有mounted-after-dispose记录，也没有旧epoch证据；原数组只有event.type，不能追加数值epoch证明。

源码给出具体交接路径：

1. `shadow-split-effects.ts:377–441` 对缺少I1 recipe的hidden entry抛错，`queueStyle:535–537`在prepare完成前不存入该style投影。
2. `adapt.ts:928–945` 的project在acquiringProjection期间捕获错误并存入acquisitionError；为保持Rule语义替换并避免独立observer错误，它不立即向调用者抛出。
3. `view-epoch-owner.ts:123–129` 在替换view wiring后直接调用session.mount；它看不到WC的private acquisitionFailed。
4. `runtime/session.ts:127–130` 的WC hostcommit正常提交Template并调用done；Runtime `session.ts:217,342–355`在commit/presence批准后发mount.mounted，且该diagnostic在authored mounted callback循环之前。
5. 等owner.attachView返回，`adapt.ts:1100–1101`才重抛已保存的acquisitionError。外层connectedCallback `369–376`随后执行initial terminal retirement并重新抛出原错误。

观察到的stack与事件序列支持这条WC错误延后路径。第一处inner catch的实际时刻未单独采样，具体Rule何时首次激活hidden也未记录，因此不把完整内部微时序或样式根因写成已经测量。最小owning layer候选是WC projection-acquisition完成与Adapter view-epoch mount准入之间；不能为满足这个测试去搬动通用Runtime diagnostic、扩大created错误策略或新增公共生命周期语义。

适用定义与边界：

- draft **C-LIFECYCLE-0002-D** 要求mounted callback晚于commit并拒绝已unmount epoch。本次commit.done先于mounted，未见此前unmount，尚无明确矛盾。
- draft **C-LIFECYCLE-0002-J** 只治理同步authored created抛错的原值保持与可达资源cleanup。本次instance.created已经成功，错误来自后续view/style acquisition，因此不应套用J。485→949的Runtime diff也只涉及created失败holder/cleanup注释，mount流程没有改变。
- draft **C-LIFECYCLE-0004-B/D/E** 使diagnostic事件具有真实验证价值，不能称其无关debug输出；目前顺序未显示retirement后mounted，且没有完整epoch字段可据以证明或否定所有stale completion。
- draft **D-FEEDBACK-STYLE-ROLE-RESOLUTION-0001-K** 与 **D-WEB-COMPONENT-SHADOW-STYLE-0001-N/P** 直接治理完整effect的I1拒绝、target mutation原子性和初始化失败资源撤销。现有 `T-FEEDBACK-STYLE-ROLE-RESOLUTION-0001` 将这个真实Dialog Mask旧companion测试登记为required、passing的SPLIT-ATOMIC实现；当前执行已红，不能无依据删除或放宽其nomounted断言。

需要保留一个重要未验证点：原测试在line84就失败，随后environmentListeners、getExposes、color-scheme/root-style markers、shadow children的85–90行断言没有执行。已看到instance.dispose.done不等于这些完整cleanup后置条件全部已过。此次只读核验不消除这个风险，也不认证style目标原子性。

最小failure-only建议已在 `minimal-observation.json` 给出，父代理已按该边界实际完成上述单次观察；无需为了取得green追加盲目测试。保留原红项、错误和hash，将后续准入交接调查交给既有A／跨owner授权边界；本轮不修改源码、不接管未授权A修复、不扩大A11y/Positioning/Material范围。全部引用、三版本源码blob、真实receipt及log SHA在 `ownership-trace.json`。
