三个新专属 workflow 均已真实终态，均为 attempt1、各1个job、结论failure。已只读下载完整run元数据、全部jobs页及三个完整job原日志；日志checkout均为 `8b15e8ee5d5795ec76bf4c6355a9ad9a9b47a6a6`，GitHub commit元数据tree为 `b4bb8316f9e01b509dbf757fad255cb89172c320`。这次未查询mainCI或重新采集67历史run。

| Workflow | 实际结果 | 首个失败与未执行边界 |
| --- | --- | --- |
| Bootstrap38338357128 / job115103498151 | 前置9fixture+12palette全过；4files44pass1fail；其中实际browser15/15全过 | controls.test.ts:219的源token数组与生成登记相等断言失败；同case下一条renderer断言未执行。旧unsupportedtoken前置阻塞已越过，不能说browser未跑。 |
| Collapsible38338357114 / job115103498246 | 36tests32pass4fail | Liquid WC/React/Vue/Vue2全在首次pointer后的focused检查caller302/helper78失败；后续Space/Enter及生命周期旅程未走完。四次补充focus diagnostic也超时，当前没有focused:true/false快照。 |
| Field38338357205 / job115103499942 | CJK安装成功、76input-surface Node tests通过；25browser tests22pass3fail | Liquid React/Vue/Vue2在labelclick后focus219失败；pending首个evaluate不是false/true样本，后续编辑/validity旅程未执行。失败pipeline后finalinventorychecker未到达。 |

三份日志实际打印Node24.21.0、pnpm10.32.1、Vitest2.1.9。Chrome执行路径是/usr/bin/google-chrome，但日志没有实际Chrome版本输出；Field把版本重定向到未读取的上传artifact，所以版本保持未知。

不从以上focus失败推断C生命周期因果，不以旧头诊断或本地通过替代本次红结果。未下载或视觉验收上传截图；没有AT或全适配器接受声明。root的本地general和Dropdown成对控制是独立材料，未在此回执中重新审查。保持human-assisted/current-user、unassessed、partial/ABSTAIN，无GitHub批准。
