当前证据支持 **A/theme 宿主资源→Rule Meta/Rule/Feedback 更新交界候选，机制未知**；不支持已确认C生命周期回归、继承失败或“flake”。这是human-assisted/current-user、unassessed、partial/ABSTAIN的有界静态归属判断。

实际失败在dropdown-destructive.test.ts:78：初始light的10%和切到dark的20%断言已经通过，移除dark后1000ms内data-pui-style没有恢复plain bg-destructive/10。styleContains只读token属性，不读computedCSS，不执行CLI token renderer。67原5cases全过，8b原1fail4pass；两次386条Vite加载路径/SHA逐项相同、与incoming4CLI路径零交集，但未拦截直接FS读取，也没有失败边界的环境和内部事件样本。

源码链为：Shadcn Item的focused等既有状态+destructive规则产生10%，后声明的dark Meta规则覆盖为20%；默认Web resolver按dark marker→explicitlight→MQL→light fallback读取；共享Document MutationObserver与MQL通知经微任务合并、最终有效值变化判断，再经过WC getter/source wrapper；Rule Meta只在alive/mounted且getter配对时保留租约，通知现有Rule evaluator替换唯一Feedback贡献，最终WC owned token applier改写data-pui-style。

现行draft P-SHADCN-DROPDOWN-MENU-ITEM-DESTRUCTIVE-PALETTE及C-RULE-COLOR-SCHEME-0001 A/E/F/H约束配方、回退及呈现更新；C/D/L同时约束租约与当前view绑定。因此不能仅按文件名把Runtime完全排除。但这条记录没有created失败、dispose/remount/epoch变化、退休回调或旧view写入，无法证明C组J/Delay/Anatomy/退休completion标准矛盾。

尤其移除dark marker并不无条件等于light：还须读取data-theme/其它marker及MQL fallback。本次日志没有失败点的effectivegetter、source通知、租约phase/generation、focused状态与当前完整tokens，不能定位停在哪一层。相同输入哈希只排除了所记录模块的字节差异，不证明相同运行环境或因果。

若后续拥有层继续定位，最小判别信息是失败点root标记/MQL/getter与现有state/tokens，随后沿source notification→lease→Ruleplan/Feedbackframe→当前host记录边界；保留原断言与timeout。本轮没有启动任何测试、浏览器、构建或修改。
