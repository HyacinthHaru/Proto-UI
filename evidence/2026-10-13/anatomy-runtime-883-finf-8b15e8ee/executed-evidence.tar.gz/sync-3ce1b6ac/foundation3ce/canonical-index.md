Form工具链先行补充见 [form-toolchain-provenance.md](form-toolchain-provenance.md)：原launcher当时实测同一绝对Node入口--version为24.21.0，并前置其bin到child PATH；worker process.version未打印，没有pnpm执行或版本实测。

精确3ce的[canonical run38336868700](https://github.com/Proto-UI/Proto-UI/actions/runs/38336868700)已completed/failure，22jobs=12success/10failure。所取6日志实际checkout均89083549；commit API确认tree885f8856801f2eb738704e4b84f5615ab7876583等于3ce headtree。只下载package、general、browser1/3/4/5六个job，一次每job，未取整套22logs。

父代理existing canonical/terminal.json已于03:14:27UTC记录当前8b的[run38338357209](https://github.com/Proto-UI/Proto-UI/actions/runs/38338357209)终态failure，22jobs也为12success/10failure。本索引只读复用其已保存日志，没有新collector或重新下载8b logs；现有ci-checkout-binding确认90cdcef0的tree等于8b tree b4bb8316f9e01b509dbf757fad255cb89172c320。

| 对应范围 | 3ce基础实际结果 | 当前8b实际结果 |
| --- | --- | --- |
| Package | 47build／47manifests，4PASS／5ADVISORY | 47build／47manifests，4PASS／5ADVISORY |
| General | public-docs78项drift，beforeVitest | 同78项错误列表，beforeVitest |
| Browser1/8 | 46pass／1fail | 46pass／1fail |
| Browser3/8 | 38pass／22fail | 38pass／22fail |
| Browser4/8 | 150pass／13fail | 150pass／13fail |
| Browser5/8 | 71pass／1fail／15skip | 71pass／1fail／15skip |

四份完整browser摘要各合计305pass／37fail／15skip，37个失败标题集合相同。这里只做基础索引，不推断错误body或rootcause完全相同，也不称无新增退化。其余4browser在3ce仅有job metadata，本次没取其logs，不能把本子集当八分片总计。

九个package的gzip/minified/SHA/env全部来自这两个准确run原日志，完整值在canonical-index.json。环境均为Node24.21.0、zlib1.3.2.1-motley-8002e91、esbuild0.25.12、Linuxx64。Runtime相对3ce gzip+44/minified+56，React+12/+71，Vue+25/+62，WC+46/+63；其它五项连SHA相同。ceilings未变，5个ADVISORY仍是超预算状态，不能写成9strictPASS；不按文件或entry相加归因。

原始API响应、6个raw logs、只去ANSI的clean logs、下载SHA收据均在此目录；8b材料通过相对路径引用，未复制或改写。没有测试、build、浏览器、GitHub变更，也没有以新版本命令补写Form历史环境。
