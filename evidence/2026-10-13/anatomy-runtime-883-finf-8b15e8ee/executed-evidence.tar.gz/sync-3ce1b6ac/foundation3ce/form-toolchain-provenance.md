Form两次运行的工具链来源已从当时保存的命令、launcher和receipt核对，未运行新的版本命令或测试。

- `current-8b` 当时开始于2026-10-13 03:01:55UTC；`only-form-3ce` 于03:02:30UTC。两份原receipt的command[0]均是绝对路径 `[user]/.codex/task-state/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin/node`，直接执行已安装的Vitest入口。
- 原launcher第11行在每次Popen之前实际执行同一绝对Node路径的 `--version`，并把输出 `v24.21.0` 写入该次receipt.node。这是当时的实测，不只是PATH命名声明，也不是现在补测。
- 原launcher第8行把该Node的bin目录前置到传给Popen的PATH。外层Python命令没有shell `export PATH`，但child env显式前置，而且Node入口为绝对路径。原完整PATH后缀未保存，不能事后填造。
- **Vitest worker内部的process.version与process.execPath当时未打印。** 准确表述是“以当时--version实测为24.21.0的绝对Node入口启动”，不能称有独立worker自报版本证明。
- 两次都没有调用pnpm或Corepack，也没有测pnpm --version。8b的package.json声明 `pnpm@10.32.1`，这只是仓库基线，不能写成两次探针实际经pnpm10.32.1运行。
- Vitest2.1.9既由原launcher读取installed package.json，也在run.log的RUN行打印；HappyDOM15.11.7来自原launcher读取installed package.json，非worker额外打印。

完整原始引用SHA、命令和限界在form-toolchain-provenance.json。原run logs/receipts未改写，未用当前Node版本或其他发布命令环境冒充历史执行环境。

句柄时序也已校正：Form原report把父代理角色状态写成执行期“正在运行”不准确。general95015在02:53:17UTC已结束，Form两次03:01:55／03:02:30UTC才启动；98119当时仍采集，当前以终态收据为准。原report文本已留history，原run receipts/logs不改；详见form-handle-timeline-correction.json。
