本次只读对账确认：[官方 run38327699078](https://github.com/Proto-UI/Proto-UI/actions/runs/38327699078) 对应 #872 精确 head `533275191fe08aa0de679c764592721c1aa3720c`，attempt1，2026-10-13 00:58:39Z 已终态 failure。完整1页共22jobs，12success、10failure；全部jobs metadata 与10个失败job原始日志均已保留。没有重跑测试、浏览器、CI或启动新的collector。

CI 实际 checkout 是 PR merge commit `2143d59f5caaec70a98a28d44648621cda3cc59b`，parents 为 main `ea19727838d85c05af5e4bca8d5fc235cb44e288` 和533。GitHub commit API 的 tree 与 run.head_commit.tree_id 完全相等：`5db67982a93b0564dd7e60bf9b664803928751a3`。因此这些日志确实绑定533的源码内容，不能替换成0ae/b1e或新组合计数。见 `ci-checkout-commit.json`、`jobs-summary.json`。

| Job | ID | 终态 |
| --- | ---: | --- |
| public_package_plan | 115070579914 | success |
| rust-macos | 115070579986 | success |
| lockstep-check | 115070580060 | success |
| rust-interop | 115070580084 | success |
| release-scan | 115070580127 | success |
| rust | 115070580130 | success |
| type-check | 115070580179 | success |
| test-plan | 115070580444 | success |
| cli-smoke | 115071751830 | success |
| release-stage | 115071751839 | success |
| release-consumer-react | 115071751955 | success |
| public_package_build | 115071751957 | success |
| test-browser (2/8, browser-2-of-8) | 115072345715 | failure |
| test-browser (1/8, browser-1-of-8) | 115072345722 | failure |
| test-browser (7/8, browser-7-of-8) | 115072345730 | failure |
| test-browser (5/8, browser-5-of-8) | 115072345757 | failure |
| test-browser (3/8, browser-3-of-8) | 115072345759 | failure |
| test-browser (6/8, browser-6-of-8) | 115072345768 | failure |
| test-browser (8/8, browser-8-of-8) | 115072345774 | failure |
| test-browser (4/8, browser-4-of-8) | 115072345810 | failure |
| test-general | 115072345928 | failure |
| test | 115076947140 | failure |

重点失败/缺口按原日志区分：

- **test-general /115072345928**：`spec-authoring` 已检查353个changed catalog inputs，随后 `check:public-docs` 报78个 unclassified family/export drift并exit1。脚本使用bash -e，后续 `test:public-docs` 和 `test` 尚未进入，日志没有Vitest通过/失败总数。不能把旧general结果套进来。原文见 `job-115072345928.clean.log:1229` 起。
- **Field /browser6/8 /115072345768**：`demo-field-family.browser.test.ts` 确实在selection中，但日志未出现其suite结果或具体失败断言；分片以124退出，无最终Vitest totals。可见先前有site-native-links的2个失败和header-select-elevation截图超时，但不能据此造出Field失败数量，也不能证明Field通过。
- **Collapsible /browser4/8 /115072345810**：`demo-collapsible-projections.browser.test.ts` 明确36tests、32pass、4fail。4fail均为liquid-glass的WC/React/Vue/Vue2，点击后expanded/content-visible检查已过，失败在 `focused(button)` 的document.activeElement equality poll1000ms（helper78，caller302）。4次只读focus诊断也超过1000ms，未提供实际activeElement或根因。Shadcn、Brutalist、Bootstrap各9项全部过，Liquid Glass另5项过。**校正保留：即时消息曾将总数误写25，已依据原日志纠正为36/4；报告不使用25。**
- **Bootstrap state-controls /browser5/8 /115072345757**：`demo-bootstrap-state-controls.browser.test.ts` 是15tests全部skipped，不是failed assertions，也不是passing acceptance。该文件受 `PROTO_UI_BOOTSTRAP_BROWSER_EVIDENCE === '1'` 的显式opt-in控制（source14/221）。别把其它Bootstrap Select/Collapsible suite的通过算成这个15项验收。

其余分片也不能藏入笼统“browser失败”：1/8为46pass/1fail（Dialog S4 paint点击超时）；3/8为38pass/22fail（colorScheme、RadioGroup、S5和overlay scrollbar）；4/8整体150pass/13fail；5/8整体71pass/1fail/15skip（唯一失败Tooltip）。2/6/7/8全部exit124且没有最终Vitest统计，分别已有overlay direction、native links/header、shadow-closeout/home-runtime/site-search、Brutalist/homepage等不同观测。没有可诚实汇总的全部browser test pass/fail总数，不能把partial累计当终态总数。完整断言原文在各job log与 `failure-extracts.json`。

四条反馈已实时读取，正文均仍绑定533，和当前C修复的对应关系如下：

| 反馈 | 当前949状态与证据 | 限界 |
| --- | --- | --- |
| [Search4252722844](https://github.com/Proto-UI/Proto-UI/pull/872#discussion_r4252722844) | 485实际red9/25，私有普通选项全registered唯一性修复后25/25；edfa纳入，949产品source与edfa相同。独立复核另覆盖nested Root和旧free-text路径。 | 这是Happy DOM/Runtime与源码证据，不是native AT或四Adapter验收。 |
| [Accordion4248471221](https://github.com/Proto-UI/Proto-UI/pull/872#discussion_r4248471221) | 533缺少旧884已有的run/epoch recheck；merge485已保留，独立8个真实Root+Item State/Context退休控制在485与最终均过。没有为该反馈追加重复修复。 | 不能拿上游533评论证明当前949仍失败。 |
| [Calendar4250665292](https://github.com/Proto-UI/Proto-UI/pull/872#discussion_r4250665292) | 独立485实际9个退休红项、3个普通控制通过；edfa在value.set、Context publish、requestMonth后检查captured owner/epoch，最终旧红项通过。 | 仅requestValue continuation边界，不是导航activation/AT保证。 |
| [Calendar4253356056](https://github.com/Proto-UI/Proto-UI/pull/872#discussion_r4253356056) | 只读源码能追到Web native click→press.commit，及GPUI AccessibilityClick→activate→HostInput::Click→CoreEvent::PressCommit；Calendar nav已经监听press.commit。未因缺少另一个exposed click listener而重复添加activation。 | 当前反馈尚未实证建立C缺陷；没有真实AT新运行，不将静态桥接等同完整AT验收或GitHub正式dismissal。 |

本地读取时HEAD是 `949ed000bf0d16055fcfb47c8f9f540c95712760`，工作区clean。相对edfa唯一delta是 `packages/runtime/test/contract/delay.v0.contract.test.ts`；产品源码确实相同。已有独立172/433 inputs与focused结果属于此前冻结候选运行，不能改写为949重新执行；父代理已报告其949 binding完成。现有C变更还包含FieldControl和Runtime，因此“533已经失败”既不能证明949相同失败，也不能豁免新的组合验证。

父代理正在独占采集新组合：general session5921、CI run38333642502由collector20913管理。本次不查询/启动第二collector，不预判这些任务的终态，不把局部修复通过写成新组合全绿。后续以父代理的准确949最终收据补入。

只读范围与原始引用见 `read-receipt.json`、`local-source-binding.json`、`feedback-reconciliation.json`、`priority-log-findings.json`。此报告保持human-assisted/current-user、unassessed、partial/ABSTAIN，不是独立批准，也没有扩展A11y/Positioning/Material修复。

补充的canonical package成本基线见 [package-measurements-533.md](package-measurements-533.md) 和 [完整九项JSON](package-measurements-533.json)：47build/47manifest完成，九项4PASS/5ADVISORY，不是9项strict PASS；环境与hash全部绑定同一533内容tree。没有本地重build或预算修改。
