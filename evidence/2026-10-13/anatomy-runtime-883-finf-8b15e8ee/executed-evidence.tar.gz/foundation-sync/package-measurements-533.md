[Canonical package job115071751957](https://github.com/Proto-UI/Proto-UI/actions/runs/38327699078/job/115071751957) 已成功完成47/47 public package builds、47 manifests检查，以及9个package-budget-policy测试。run head为533，实际PRmerge checkout2143d59f；两者tree逐字相同，均为 `5db67982a93b0564dd7e60bf9b664803928751a3`。

环境是Node `v24.21.0`、zlib `1.3.2.1-motley-8002e91`、esbuild `0.25.12`、Linux x64、pnpm `10.32.1`。以下全部直接解析完整原日志，未启动本地build或测量。逐项SHA与原日志行号见 `package-measurements-533.json`。

| Entry | gzip bytes | minified bytes | strict ceiling | excess | 实际状态 |
| --- | ---: | ---: | ---: | ---: | --- |
| lucide/icons/x | 1737 | 4670 | 3000 | 0 | PASS |
| lucide root | 635777 | 4083171 | 700000 | 0 | PASS |
| core root | 8037 | 24978 | 7600 | 437 | ADVISORY |
| runtime root | 86131 | 334977 | 78500 | 7631 | ADVISORY |
| adapter-react root | 129638 | 462305 | 106000 | 23638 | ADVISORY |
| adapter-vue root | 129378 | 460762 | 106000 | 23378 | ADVISORY |
| adapter-web-component root | 155456 | 539453 | 132000 | 23456 | ADVISORY |
| prototypes-base/button | 3946 | 13707 | 6000 | 0 | PASS |
| prototypes-shadcn/button | 4927 | 18035 | 7000 | 0 | PASS |

本job明确使用 `--finf-development` / `finf-development-advisory`：4项PASS、5项ADVISORY且超额仍保留，不能写成9项strict PASS。ledger记录5/68 complete，`completionIsAcceptance=false`。policy测试9/9PASS是检查策略程序的单独测试，不是九个entry预算全过。

另有两个非预算consumer诊断：light-dom button为159897 gzip/557011 minified；direct-shadow button为159900/557022。原始SHA同样保存在JSON，不能并入九项预算计数。

此处只建立精确533可复用成本基线；949或未来组合必须与自身canonical环境、minified SHA逐项对比。整体entry gzip不能按文件简单加减归因，也不提供任何预算调整或独立批准。
