import assert from 'node:assert/strict';
import { writeFile, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { settleFamilyQueryBatch } from '<WORKTREE>/apps/www/src/content/docs/zh-cn/family-query-observer.ts';

// Synthetic Node control only: not the Vitest matcher or a native browser run.
const startedAt = new Date().toISOString();
const rows = [];
for (const budgetMs of [1000, 2000]) {
  const start = performance.now();
  let calls = 0;
  const request = (() => {
    ++calls;
    return new Promise((resolve) => setTimeout(() => resolve('combobox'), 2200));
  })();
  const verdict = await Promise.race([
    request.then((value) => ({ passed: value === 'combobox' })),
    new Promise((resolve) => setTimeout(() => resolve({ passed: false }), 1000)),
  ]);
  const verdictAt = performance.now();
  assert.equal(verdict.passed, false);
  const observation = await settleFamilyQueryBatch([request], budgetMs);
  const observedAt = performance.now();
  assert.equal(observation.complete, budgetMs === 2000);
  assert.equal(calls, 1);
  rows.push({
    budgetMs, originalVerdictBudgetMs: 1000, verdict,
    verdictAfterStartMs: verdictAt - start,
    observationAfterVerdictMs: observedAt - verdictAt,
    originalRequests: calls, observation,
  });
  await request;
}
const helper = '<WORKTREE>/apps/www/src/content/docs/zh-cn/family-query-observer.ts';
const output = {
  startedAt, completedAt: new Date().toISOString(), node: process.version,
  scope: 'Synthetic original-Promise drain control with one timer request per arm. Both modeled 1s verdicts remain false; no actual Vitest/SDK/browser execution or C production cause inferred.',
  helperSHA256: createHash('sha256').update(await readFile(helper)).digest('hex'),
  rows,
};
await writeFile(new URL('./drain-control-receipt.json', import.meta.url), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify(output));
