# CSS-zoom passive probe: bounded result

One authorized private full-case run remained red: **1 failed / 54 filtered**, 18:06:48–18:07:04 UTC. Executed source was c3a3d45a plus the parent-owned retainer change and the temporary private probe, not clean ad9. Source census and extra input hashes were stable; the temporary test was removed and tracked Portal bytes preserved.

The same Liquid Glass Dropdown previewer (id23) and panel (id34) change from **200 to228.75 viewport px** / **160 to183 CSS px**. Main height changes from1546.875 to1575.625. WC generation1 ready projection id46 remains111px high; later document nodes only shift downward. All selected identities/fonts/line heights are stable. The observer retains122 attribute records,0drops,0errors and no font events. FontFaceSet.status is loaded while the listed DM Sans face stays unloaded.

A scene style mutation and canvas height193→229 are delivered at5992.200ms, between original samples5986.300 and5994.100ms. The style string is truncated before minHeight. Scene/mount BCRs and the exact layout invocation were not recorded.

The source has a concrete units mismatch in `preview-material-scene.ts:87–110`: viewport BCR distance plus unscaled CSS padding is written as CSS minHeight. Conditional substitution from adjacent observed panel/projection boxes gives `ceil(699.125−548.125+32)=183`; normalization gives153. This is source-consistent arithmetic, not a directly measured minHeight change. The outer host has a separate10rem floor.

The minimal owning layer is application scene layout. Compute an effective uniform scale from measured scene width and existing computed border-box CSS width, convert the physical bottom difference **including physical contactPaintOutset** before adding CSSpadding, and keep ceil/finite guards. Do not alter contactPaintOutset, lease/source/zoom rejection, budgets, Prototype semantics or any browser assertion. No currentCSSZoom API or integer-offset precision assumption is needed.

Ancestor appearance currently refreshes only; RO→rAF schedules layout. Direct layout→refresh in that existing callback is a separable proposed ordering change, not independently proved causality. It does not directly self-observe minHeight because it watches parent/ancestors, but adds synchronous measurement cost and needs conservative handling of unavailable zero-size geometry. It does not prove webfont settlement or arbitrary transform support.

The unexecuted `unit-proposal-v2` preserves all seven original case bodies and adds only zoom1.25/0.8 plus one real-MO appearance-delivery case. Expected flow/removal reserve104; physical popupoutset31/21 gives CSSreserve437/439; flow100 after appearance must give164 without advancing rAF. V1 nested/fractional scenarios remain private design only. The original full nine-control browser case retains3baseline/6handover frames,1px and90s.

All three relevant catalog entities (HC-OVERLAY-PORTAL-0001, T-WEB-PORTAL-DESTINATION-0001, C-FEEDBACK-MATERIAL-0001) are draft. This report is partial evidence / ABSTAIN and no formal approval.
