最终有限复核：0 个新增 finding，partial / ABSTAIN。

同c7+精确foreign12行生产motion组合：原helper20714于18:41:55–18:42:07真实0pass/1fail/9filtered，wc/dark surface255对own-variable38；helper9f8590于18:44:55–18:45:11真实1pass/9filtered。11376条trackedcensus独立比较，红→绿只有C测试helper文件变化。

foreignButton于18:46:54精确恢复befb（与c7 Git对象一致）。18:46:55–18:47:08同helper再次1pass/9filtered；两次绿之间只有Button从composededd00d恢复befb。目录restored-main-focused不是mainb928实际执行：真实来源是c7+ownhelperdirty。两次绿各有wc/react/vue/vue2四份原canary passed记录，完整六步owner/restamp/restore链、五节点connected和sameNode。

18:47:51–18:48:31同恢复后源码types终态exit0，938files/0errors/0warnings/14hints，before/after稳定，与恢复后focused全部tracked输入一致。

原10case完整源码、125direct expect调用点、原5poll/240s/输入/canary/hover/pressed/restore保留；新增helperpoll2s/20ms。格式后原evaluate不再byteequal，但ASTequal，函数外逐字相同。两次focused不替代全部10case/269、动画曲线、full926、hostedCI或GitHub批准；后续commit另需准确绑定。
