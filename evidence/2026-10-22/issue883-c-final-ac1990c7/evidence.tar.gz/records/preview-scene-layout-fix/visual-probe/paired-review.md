# Paired post-verdict CSS-zoom display

Both original PNGs were individually viewed. The old arm ran18:30:43–18:31:00 UTC and failed1case/54filtered; the normalization-only arm ran18:33:03–18:33:19 and passed1case/54filtered. Both use private test e634… on worktree-candidate epochs at ad9. Full tracked censuses differ only in `preview-material-scene.ts` (b7de…→ece4…). Neither arm is a clean-source claim.

| Later display fact | Old production | Normalization only |
|---|---:|---:|
| First2 / last6 sampled scene minHeight |154 /183 CSSpx|154 /153 CSSpx|
| Scene BCR height |192.5→228.75|192.5→191.25|
| Preview panel height |200→228.75|200 throughout|
| PNG size |1640×1949|1640×1921|

The directly measured scene CSSwidth512, BCRwidth640, flow-bottom minus scene-top151 and padding32 establish scale1.25. Old formula gives183; normalized formula gives `ceil(151/1.25+32)=153`. These are **later controlled display measurements**, not retroactively captured original failure inputs. The new inner scene still changes1.25BCRpx after two samples; it does not prove all zoom frames have zero drift. Its outer panel stays200.

The separate original tracked case at18:32:16–18:32:31 passed1/0 with all nine controls stable; CSSzoom baseline delta0. That result and the later eight-frame display are separate evidence. Original assertions, three/six frames and90s deadline remain intact.

Both displays retain unavailable/opaque-fallback material states, including source-ancestor-compositing-unavailable. The visible documentation, tabs and Open menu/Disabled menu controls are present; striped backdrop captions remain beneath controls. The images do not establish optical correctness, popup interaction, full UI/AT or every page resource. FullPage captured1640px document width against a1440px viewport, which is not an all-overflow acceptance claim. Tool rendering resized the images for inspection; source PNG bytes were not edited or cropped.

Each capture has no diagnostic errors, restores rootstyle exactly to `color-scheme: light;`, and its wrapper CAS-deletes the temporary test while preserving tracked Portal/scene bytes. The capture consumes existing case time without adding grace. There is no new browser/test execution in this review.

Old PNG SHA256: `435ba52c58efcd672c1fa597fc5a056147ac0ee8fe0d62d421cc789081d7f9d9`

New PNG SHA256: `835cde018bf0b589011a0d9b82ed9a649d95241f7473bc7c69f57af2331b3840`

Partial / ABSTAIN; no formal approval or material/optical promotion.
