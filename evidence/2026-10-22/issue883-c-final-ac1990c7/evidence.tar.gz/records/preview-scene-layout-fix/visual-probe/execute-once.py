from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,sys
parser=argparse.ArgumentParser()
parser.add_argument('--label',required=True)
parser.add_argument('--expected-head',required=True)
parser.add_argument('--expected-scene-sha256',required=True)
parser.add_argument('--prepare-only',action='store_true')
a=parser.parse_args()
assert a.label and all(c.isalnum() or c in '-_' for c in a.label)
d=Path(__file__).resolve().parent;r=d.parents[1];w=Path('<WORKTREE>');b=json.loads((d/'binding.json').read_text());sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();git=lambda *x:subprocess.check_output(['git',*x],cwd=w,text=True).strip()
tracked=w/b['trackedPath'];tmp=w/b['temporaryPath'];scene=w/'apps/www/src/components/PrototypePreviewer/preview-material-scene.ts';candidate=d/'candidate.browser.test.ts'
assert git('rev-parse','HEAD')==a.expected_head
assert sha(tracked)==b['trackedSha256']
assert sha(candidate)==b['candidateSha256']
assert sha(scene)==a.expected_scene_sha256
assert not tmp.exists(), 'Temporary source already exists; refusing overwrite'
run=d/'runs'/a.label;run.mkdir(parents=True,exist_ok=False);out=run/'observed'
plan={'workdir':str(w),'nodeToolchainBin':'<HOME>/.codex/task-state/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin','expectedHead':a.expected_head,'expectedSceneSHA256':a.expected_scene_sha256,'files':[b['temporaryPath']],'extraInputPaths':[str(tmp)],'argv':['/usr/bin/env','-u','PROTO_UI_MATERIAL_EVIDENCE_DIR','corepack','pnpm@10.32.1','exec','vitest','run',b['temporaryPath'],'--testNamePattern='+b['caseName'],'--maxWorkers=1','--minWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')],'environmentOverrides':{'PROTO_UI_RUNTIME_EVIDENCE_DIR':str(out/'evidence'),'RUNNER_TEMP':str(out/'runner-temp'),'CHROME_PATH':'<HOME>/.codex/task-state/proto-ui-883/continue-20261022T061410Z/matched-browser/cache/chromium-1208/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing'},'scope':'Private source-derived original nine-control case with post-verdict controlled CSSzoom display; not original test bytes, installed-package validation, original deadline frame or optical zoom admission. Original deadline/assertions/inputs unchanged.','resourceBound':'One worker, one run, no retry; at most8postverdict frames within2s observation budget,5s screenshot timeout; all within original90s case, no grace extension.'}
(run/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(run/'source-before.json').write_text(json.dumps({'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain'),'trackedPortalSHA256':sha(tracked),'sceneSHA256':sha(scene),'candidateSHA256':sha(candidate)},indent=2)+'\n')
if a.prepare_only:
 print(json.dumps({'preparedOnly':True,'plan':str(run/'plan.json'),'executed':False}));raise SystemExit(0)
result=None;cleanup={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
try:
 with tmp.open('xb') as f:f.write(candidate.read_bytes())
 result=subprocess.run([sys.executable,str(r/'run-plan.py'),str(run/'plan.json'),str(out.relative_to(r))])
finally:
 cleanup['runnerExit']=None if result is None else result.returncode
 cleanup['temporaryAfterSHA256']=sha(tmp) if tmp.exists() else None
 cleanup['temporaryRemoved']=False
 if tmp.exists() and cleanup['temporaryAfterSHA256']==b['candidateSha256']:
  tmp.unlink();cleanup['temporaryRemoved']=True
 cleanup.update(trackedPortalAfterSHA256=sha(tracked),trackedPortalUnchanged=sha(tracked)==b['trackedSha256'],sceneAfterSHA256=sha(scene),sceneUnchanged=sha(scene)==a.expected_scene_sha256,headAfter=git('rev-parse','HEAD'),statusAfter=git('status','--porcelain'),endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (run/'cleanup-receipt.json').write_text(json.dumps(cleanup,indent=2)+'\n');print(json.dumps(cleanup),flush=True)
raise SystemExit(result.returncode if result is not None else 1)
