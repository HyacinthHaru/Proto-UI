({
      previewerId,
      expectedCount: count,
      readySelector: selector,
      runtime: selectedRuntime,
      label,
    }) => {
      const roots = document.querySelectorAll<HTMLElement>(
        `[data-previewer-id=${JSON.stringify(previewerId)}]`
      );
      if (roots.length !== 1) return false;
      const root = roots[0]!;
      const hosts = root.querySelectorAll<HTMLElement>('.host');
      const host = hosts.length === 1 ? hosts[0] : null;
      const scopes = host?.querySelectorAll<HTMLElement>('[data-projection-scope]') ?? [];
      const scope = scopes.length === 1 ? scopes[0] : null;
      const fixed = root.dataset.projectionMode === 'fixed-family';
      const content = fixed ? scope?.querySelector<HTMLElement>('[data-projection-content]') : host;
      if (!host || !content) return false;
      if (fixed && (!scope || scope.dataset.projectionState !== 'ready')) return false;
      const generation = scope?.closest<HTMLElement>('[data-projection-generation-state]');
      if (fixed && generation && generation.dataset.projectionGenerationState !== 'active')
        return false;
      if (!fixed && scopes.length) return false;

      const tabsDeclared = root.querySelector(
        '[data-runtime-tabs-mount], [data-runtime-tabs-root], [data-runtime-tabs], [data-runtime-tab]'
      );
      const controls = root.querySelectorAll<HTMLElement>(
        fixed
          ? '[data-projection-scope][data-projection-state="ready"] [data-projection-control="runtime"][data-runtime-tabs]'
          : '[data-runtime-tabs-mount] [data-runtime-tabs-root]'
      );
      let control: HTMLElement | null = null;
      let trigger: HTMLElement | null = null;
      if (tabsDeclared) {
        if (controls.length !== 1) return false;
        control = controls[0]!;
        const selected = control.querySelectorAll<HTMLElement>(
          fixed
            ? '[role="tab"][aria-selected="true"]'
            : '[data-runtime-tab][role="tab"][aria-selected="true"]'
        );
        if (selected.length !== 1) return false;
        trigger = selected[0]!;
        if (
          trigger.textContent?.trim() !== label ||
          (!fixed && trigger.dataset.runtimeTab !== selectedRuntime)
        )
          return false;
      } else if (fixed && root.dataset.projectionToolbar === 'false') {
        // An explicitly toolbarless projection is driven by the real Header Select.
      } else {
        const legacy = root.querySelectorAll<HTMLElement>(
          '[data-projection-control="runtime"] [role="combobox"], [data-adapter-select-root] [role="combobox"]'
        );
        if (legacy.length !== 1) return false;
        trigger = legacy[0]!;
        control = trigger.closest<HTMLElement>(
          '[data-projection-control="runtime"], [data-adapter-select-root]'
        );
        if (!fixed && control?.dataset.value !== selectedRuntime) return false;
      }
      // Ready projected attributes describe the materialized scope; the public
      // controller independently proves that this runtime was actually committed.
      if (fixed && scope?.dataset.projectionRuntime !== selectedRuntime) return false;
      const committed = (
        root as HTMLElement & { __previewer__?: { getCurrentRuntime?: () => string | null } }
      ).__previewer__?.getCurrentRuntime?.();
      if (committed !== selectedRuntime) return false;
      const unavailable = (element: HTMLElement) => {
        if (!element.isConnected) return true;
        for (let node: HTMLElement | null = element; node; node = node.parentElement) {
          if (
            node.inert ||
            node.matches(
              '[inert], [hidden], [aria-hidden="true"], [aria-busy="true"], [aria-disabled="true"], [disabled], [data-previewer-startup-pending], [data-previewer-startup-shell]'
            )
          )
            return true;
          const style = getComputedStyle(node);
          if (style.display === 'none' || style.visibility === 'hidden') return true;
        }
        return false;
      };
      if (
        unavailable(host) ||
        (control && unavailable(control)) ||
        (trigger && unavailable(trigger))
      )
        return false;
      if (
        root.querySelector(
          '[data-previewer-startup-pending], [data-previewer-startup-shell], .proto-previewer__skeleton'
        )
      )
        return false;
      const surfaces = content.querySelectorAll<HTMLElement>(
        '.pui-runtime-preview-surface[data-demo-ref="__website_runtime_preview_surface__"]'
      );
      if (surfaces.length !== 1) return false;
      const surface = surfaces[0]!;
      if (
        unavailable(surface) ||
        !surface.hasAttribute('data-pui-root') ||
        Array.from(content.querySelectorAll('[data-pui-root]')).some(
          (element) => element !== surface && !surface.contains(element)
        )
      )
        return false;
      // RuntimeBox adds one reserved passive boundary; original demo counts stay exact.
      const firstRoot = surface.querySelector<HTMLElement>('[data-pui-root]');
      if (surface.querySelectorAll(selector).length !== count || !firstRoot) return false;
      const framework = firstRoot.tagName.startsWith('WC-')
        ? 'wc'
        : (firstRoot as HTMLElement & { __vue__?: unknown }).__vue__
          ? 'vue2'
          : host.hasAttribute('data-v-app') || firstRoot.closest('[data-v-app]')
            ? 'vue'
            : Object.keys(surface).some((key) => key.startsWith('__reactFiber$'))
              ? 'react'
              : null;
      return framework === selectedRuntime;
    }