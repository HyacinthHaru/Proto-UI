# Exact-ac built page observation: bounded review

The single execution completed19:13:27.078–19:13:31.688UTC. Launcher exit0, tracked and extra source inputs stable, clean ac1990c7 before/after. Actual runtime: Node24.21.0, Playwright1.58.2, Chromium145.0.7632.6. No new execution was performed for this review.

Both fresh contexts (1440×1100 and320×1000) begin with0cookies/0origins and no supplied storageState. They observe light/root16/zoom1, committedWC, ready generation1 and two menu triggers. The owner is the actual **data-projection-scope** value `pp-93ethaellsm`; no data-projection-owner field is invented. Equal identifiers across separate contexts are not shared physical node identity.

Each context records123HTTP200 responses and one308directory redirect. All246body SHA/size/MIME observations were independently compared with the complete manifest; the server/client multisets match248requests. They cover123unique artifact members, not all3837served. Page errors, console errors, local404, off-origin attempts, failed requests, verification/capture errors and pending reads are all0. The complete3837file/669HTML/104,068,290B tree matches the manifest before/after and was rehashed again during this read-only audit.

Both document horizontalDelta values are0. OriginalPNG files were individually viewed and hashes/dimensions rechecked:1440×1328 (250,809B, `6a7659ce35631284f523d95bef61d2e738f6b50d7fbc611a253d8601f1ab2f74`) and320×2187 (175,096B, `3a9894bea08b6d77eb9888f87b1dd3c7fce8caae9233a51c40bf06b25e0e87d5`). Narrow Tabs retain an internal horizontal region; no option-reachability, scrolling or all-visual acceptance is inferred. Source images are unedited and uncropped; the image tool resized the narrow rendition only for display.

Both contexts closed with0pending response reads. Browser.close resolved/disconnected, actual ChromePID17364 exited0 at19:13:31.388UTC, temporary browser directory cleanup completed, HTTPserver closed/notlistening and0sockets remain.

This is plainloopback complete-artifact page observation, **not publisherReady, Search1s/269, all669pages/allAdapters/AT, installed-consumer, optical or motion acceptance**. There were no clicks or style/state injections. Raw browser bodies were hashed during execution rather than duplicated to disk; this audit rechecks the recorded hashes against immutable manifest/server records and makes no second-fetch claim.

No specific source/receipt/transport finding remains. The observer author participated in this execution review: partial/ABSTAIN, not formal independent source approval.
