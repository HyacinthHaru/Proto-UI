# Exact ac1990 preview: read-only verification

Run39834975328 / job120020773260 completed successfully. The actual checkout in producer.log169–190 is `ac1990c78f60acb73661845f6add9d3ff307023e`; GitAPI tree is `14d99b90175d2a23528940218658568f324c9254`. Complete pagination contains1job and2artifacts.

The complete site artifact12450303301 is **21,143,997bytes**, SHA256 `c1d1e292289331c0f161951d736cd9fe7cda679dcd5d0f5c5780224d02c63138`, exactly matching GitHub size/digest. Binding artifact12449713499 is191bytes, SHA256 `97711c4b8e0f77deca684e9ecebec787aff11e7d930757d6728be2337f4a2395`; its binding.txt states PR921 and exact ac head. Each was downloaded once, with original ZIPs/receipts preserved.

All **3,837files /669HTML /104,068,290expanded bytes** were retained, CRC/SHA checked and extracted byte-for-byte. No page/resource pruning, unsupported member type, duplicate or unsafe path was accepted. Producer build reports651pages, a different counter from artifact HTML files.

The original producer log3520–3538 records the real default generated-artifact test:1pass,0fail,0skip, comparing the producer’s own **21,208,080-byte ZIP** with its actual apps/www/dist directory and the admitted/sanitized output. Node24.21.0/pnpm10.32.1 are recorded. The downloaded Actions ZIP is a separately compressed container; its hash/size must not be substituted for the producer-created ZIP.

**No local admission test, browser, build, source edit or CI mutation was executed.** No current main-CI green conclusion follows from this preview. Existing dev-server/precommit PNGs remain separate, and the new built artifact has not been rendered locally by this task. This is partial/ABSTAIN, not formal approval or runtime/optical acceptance.
