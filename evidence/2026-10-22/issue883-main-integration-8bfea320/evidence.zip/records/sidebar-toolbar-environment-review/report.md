最小环境处理应复用仓库已有的 **Astro 项目级 devToolbar preference**，不用修改应用源码、Astro 全局配置或原命中断言。本审查仅只读，partial / ABSTAIN；未执行测试、浏览器或偏好写入。

当前实际安装 Astro **5.18.1**。其 `DevPipeline.headElements` 仅在开发模式页面且 `config.devToolbar.enabled && preferences.get("devToolbar.enabled")` 时注入 Toolbar。这条链没有 CI 自动关闭条件。默认偏好为 true，解析顺序为项目、全局、默认。当前只读项目 `.astro/settings.json` 中 devToolbar 未设置；这不是旧运行时快照，且没有读取全局偏好，因此不据此单独断言旧运行的有效值。

仓库官方 CI 已在浏览器运行前明确执行：

```sh
corepack pnpm@10.32.1 --filter apps-www exec astro preferences disable devToolbar
corepack pnpm@10.32.1 --filter apps-www exec astro preferences get devToolbar.enabled
```

相同做法存在于 `.github/workflows/ci.yml:458–459,537–538` 和 `homepage-visual-evidence.yml:292–293`。命令未带 `--global`，写入 apps-www 根下 Git-ignore 的 `.astro/settings.json`。现有 harness 继承环境启动 dev server，本身不会关闭 Toolbar。安装版本没有可据此使用的专用 ASTRO Toolbar 环境变量；不要伪造 CI 环境。

`2026-10-03-scroll-area-track-corner.md:32–34` 已记录相同类别的真实 Toolbar 遮挡 Thumb 失败，并通过官方 preference/readback 对齐基线和候选；明确不隐藏应用元素、不强制输入、不改数值或 timeout。这是工程先例，不是新规范。

建议 root 保存原失败和当前偏好状态，再复用上述 disable/get 并保存 false 回读，在新 test-owned server 上保持 engine145、原页面资源、center hitIsCurrent、输入和所有原 deadline。这样改变的是工具环境。无需 CSS 删除开发控件、修改页面/scroll/pointer 或降低命中期待。若之后恢复偏好，只恢复原值/文件状态并记录，不动全局或其它项目设置。

安装 Toolbar 确实包含 fixed bottom、高 z-index、可命中的 Shadow DOM hitbox；这支持“可能遮挡”的源码路径，但不是原失败具体 target 的替代证据。root 即将保存的 failure-only pointer 对象才可确定该次 `elementFromPoint` 的实际 host。官方 workflow 的 setup 源码也不能冒充某次旧 CI 已实际执行该步骤。

完整源文件及 SHA、版本、路径与限制见 report.json。
