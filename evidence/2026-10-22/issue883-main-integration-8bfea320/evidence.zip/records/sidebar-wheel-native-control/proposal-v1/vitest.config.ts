import base from '<PRODUCT_ROOT>/vitest.config.ts';
const root = '<R16>/sidebar-wheel-native-control/proposal-v1';
export default { ...base, root, server: { fs: { allow: [root, '<PRODUCT_ROOT>'] } },
  test: { ...base.test, environment: 'node', include: ['wheel.test.ts'], maxWorkers: 1, minWorkers: 1, fileParallelism: false } };
