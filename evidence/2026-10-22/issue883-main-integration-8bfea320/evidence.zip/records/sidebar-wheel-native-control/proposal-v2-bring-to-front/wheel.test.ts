// @vitest-environment node
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { performance } from 'node:perf_hooks';
import { afterAll, beforeAll, expect, it } from 'vitest';
import { launchBrowser } from '<PRODUCT_ROOT>/apps/www/src/content/docs/zh-cn/browser-harness';
const product = '<PRODUCT_ROOT>';
const out = process.env.WHEEL_CONTROL_EVIDENCE_DIR!;
let browser: Awaited<ReturnType<typeof launchBrowser>>;
beforeAll(async () => { fs.mkdirSync(out, { recursive: true }); browser = await launchBrowser(); }, 30_000);
afterAll(async () => { await browser?.close(); });
it('native wheel on the same static sidebar geometry without a wheel listener', async () => {
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage(); const pageErrors: string[] = [];
  page.on('pageerror', error => pageErrors.push(error.message));
  const evidence: any = { sourceKind: 'private pure HTML control, no product bridge', wheelListenerInstalled: false, bringToFrontBeforeMove: true,
    head: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: product, encoding: 'utf8' }).trim(),
    status: execFileSync('git', ['status', '--porcelain'], { cwd: product, encoding: 'utf8' }),
    node: process.version, platform: process.platform, browser: browser.version(), viewport: { width: 1440, height: 900 },
    pointer: { x: 176, y: 883.5 }, wheel: { deltaX: 0, deltaY: -400 }, originalCondition: 'scrollTop < 9021; default Vitest expect.poll1000ms', outcome: 'running' };
  const facts = () => page.evaluate(() => {
    const owner = document.querySelector<HTMLElement>('#owner')!;
    const target = document.querySelector<HTMLElement>('#target')!;
    const hit = document.elementFromPoint(176, 883.5);
    const style = getComputedStyle(owner);
    return { owner: { rect: owner.getBoundingClientRect().toJSON(), scrollTop: owner.scrollTop, scrollHeight: owner.scrollHeight,
      clientHeight: owner.clientHeight, clientWidth: owner.clientWidth, offsetWidth: owner.offsetWidth,
      overflowX: style.overflowX, overflowY: style.overflowY, scrollBehavior: style.scrollBehavior,
      overscrollBehavior: style.overscrollBehavior, touchAction: style.touchAction, pointerEvents: style.pointerEvents },
      target: { rect: target.getBoundingClientRect().toJSON(), connected: target.isConnected },
      hitIsTarget: hit === target, hitTag: hit?.tagName ?? null, hitId: hit?.id ?? null,
      documentY: scrollY, documentHeight: document.documentElement.scrollHeight,
      ua: navigator.userAgent, platform: navigator.platform, dpr: devicePixelRatio, pageURL: location.href, visibilityState: document.visibilityState, documentHasFocus: document.hasFocus() };
  });
  try {
    await page.setContent(`<!doctype html><meta charset="utf-8"><style>
html,body{margin:0;height:900px}#owner{position:fixed;top:65px;left:56px;width:240px;height:835px;overflow-y:auto;overflow-x:hidden;padding:0;border:0;box-sizing:border-box;background:#eee}
#content{position:relative;width:100%;height:10769px}#target{position:absolute;left:8px;top:9823px;width:224px;height:33px;display:block;line-height:33px;color:#111}
</style><nav id="owner"><div id="content"><a id="target" href="#target">Current article</a></div></nav>`);
    await page.locator('#owner').evaluate(node => { node.scrollTop = 9021; });
    evidence.before = await facts();
    expect(evidence.before.owner.rect).toMatchObject({ x: 56, y: 65, width: 240, height: 835 });
    expect(evidence.before.owner.scrollTop).toBe(9021);
    expect(evidence.before.owner.scrollHeight).toBe(10769);
    expect(evidence.before.target.rect).toMatchObject({ top: 867, bottom: 900, height: 33 });
    expect(evidence.before.hitIsTarget).toBe(true);
    evidence.inputStartedNodeMs = performance.now();
    await page.bringToFront();
    await page.mouse.move(176, 883.5);
    await page.mouse.wheel(0, -400);
    evidence.pollStartedNodeMs = performance.now();
    await expect.poll(() => page.locator('#owner').evaluate(node => node.scrollTop)).toBeLessThan(9021);
    evidence.verdictNodeMs = performance.now(); evidence.outcome = 'passed';
  } catch (error) {
    evidence.verdictNodeMs = performance.now(); evidence.outcome = 'failed'; evidence.error = String(error);
    throw error;
  } finally {
    evidence.after = await facts(); evidence.pageErrors = pageErrors;
    await context.close(); evidence.contextCloseSucceeded = true;
    fs.writeFileSync(path.join(out, 'observations.json'), JSON.stringify(evidence, null, 2));
  }
});
