两次纯原生控制均在原默认 1000 ms 轮询上失败，scrollTop 仍为 9021。两臂初始几何、目标命中、可滚动尺寸断言均通过，失败不是 setup 错误。结论为 partial / ABSTAIN，不是产品通过或 GitHub 批准。

| 运行 | 实际时间 UTC | 唯一行为增量 | 结果 | scrollTop |
|---|---|---|---|---|
| arm1-no-listener | 07:33:05.923–07:33:09.332 | 无 | 0 pass / 1 fail | 9021 → 9021 |
| arm2-bring-to-front | 07:37:56.117–07:38:00.178 | move 前 `page.bringToFront()` | 0 pass / 1 fail | 9021 → 9021 |

实际环境是 Node 24.21.0、Vitest 2.1.9、Darwin、Chrome 156.0.8078.47，调用现有 `launchBrowser`。安装的 Playwright Core 1.58.2 在执行后只读核对。nav 是 fixed，(56,65) / 240×835，scrollHeight 10769；目标 rect 为 y=867–900、高 33，实际 (176,883.5) 命中该 A 元素，documentY=0。输入均为原 `mouse.move` 后 `mouse.wheel(0,-400)`；原 `scrollTop < 9021` 断言和默认 1000ms 轮询不变。

第二臂只加入 `bringToFront()`。既有 facts RPC 同时记录 visibility/hasFocus，before 和 after 均为 visible/true；before 在 bringToFront 前，after 在失败后。这不能填补 wheel 派发瞬间的内部状态。两臂均无 DOM wheel listener、产品 bridge、截图或 sleep；`pageErrors=[]`，context.close 成功且 afterAll/browser close 没有 hook 失败，两 Vitest 进程均终态，原生槽已释放。包装脚本正常退出仅表示已写收据，实际子进程都 exit 1。

此纯 HTML 反例表明产品 Sidebar helper 不是产生这类“同条件滚轮后数值不变”失败的必要条件；它不证明产品 helper 正确，也没有识别浏览器/协议/兼容性根因。没有监听 wheel，因此不能声明实际 DOM wheel 已派发或未被阻止。应用使用 sticky/其他祖先结构，并在 wheel 前有两次截图/evaluate capture，本控制使用 about:blank 的 fixed nav 且省略这些 capture，不能声称执行时序相同。纯页只设置 html/body 的 margin 和 height；未重建应用的 sticky 祖先和 body/document overflow 结构，既有 facts 未单独采 body overflow，也不声称两者相等。未采截图，不提供视觉验收。

所有 fixture、config、原日志、Vitest JSON、before/after facts 和各自 SHA 均在 report.json 绑定。源 HEAD d2058a7ce0612b7c0cc08734013867babda4a013 和当时两 Sidebar dirty 路径只用于物理工作树背景；页面来源是私有 HTML，不是该 HEAD 的完整产品行为。没有全 loaded-input 闭包证明。第一臂原件保留，第二臂独立目录，无产品修改、无外部写入。
