# 实际合成tree b97b50f6 的独立保存核验

结论：**0个具体保存finding，partial / ABSTAIN**。目标为已生成的不可变Git tree `b97b50f6fdb5e5b3fda00b9f51705260a114be21`，不是尚未发生的测试或正式批准。

以042f为三方base、6a为C侧、b928为main侧，逐一比较全部mode/type/blob：

- C侧33路径全部与6a相同。
- main侧104路径全部与b928相同。
- 两侧改动路径交集为0，无三方冲突项。
- 其余11238条与base一致。
- 完整预期11375条与实际11375条 **0差异**。

18个关键fixture/helper/router/workflow文件另做了完整字节对比，包括Homepage、Header、Collapsible、Field、Search、Sidebar、settings、color、Shadow、Select、pointer和keyboard owner。所有原断言、输入、deadline与清理代码随完整文件保持；不是只检查若干matcher。Homepage前次已绑定的171matcher对应原文件未改。Keyboard source与event-router-work整个文件未改，原17控制的历史名称清单已附入JSON；这不声称在新tree重跑17个case。hover/prominent-tint routing原planner与workflow也原字节保留。

观察到HEAD=`6a4e2b3db65878da7b5150cdad49eb9d8a1cc9d0`、MERGE_HEAD=`b928a56c6909835771fc2131503b4a7139db738c`；当次index与目标tree一致=true，未合并stage项0，未暂存tracked变动0。这些观察不影响报告的不可变tree绑定。

本次没有测试/浏览器/build/API读取、index/源码修改、提交或外部写入。最新main的共享React/Overlay/available-space变化虽然完整保留，行为仍需root将真实新执行绑定此tree；旧6a结果保留为历史。
