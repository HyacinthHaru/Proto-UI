# R16：最新main整合输入只读审查

准确新main为 **b928a56c6909835771fc2131503b4a7139db738c**，tree **d1ee4b83c3e1c553edcd49e7b636222f3c324113**。

- 自上次f746新增 **6 commits / 11 paths**，为#899与#905合并。
- 自原base042f的完整增量为 **16 commits / 104 paths**，包含#923、#924、#899、#905。
- 两份compare均返回完整提交数，文件数未触300上限；base/f746/b928三棵API递归树均未截断。按mode/type/blob全树重算分别exact11和104路径，非tree条目为11328→11368→11371。

| 实际已合入PR | merged_at（UTC） | merge | 本PR路径数 |
|---|---|---|---:|
| [#923](https://github.com/Proto-UI/Proto-UI/pull/923) | 2026-10-20 19:26:59 | 6ab63d42… | 86 |
| [#924](https://github.com/Proto-UI/Proto-UI/pull/924) | 2026-10-20 21:23:35 | f74660a2… | 7 |
| [#899](https://github.com/Proto-UI/Proto-UI/pull/899) | 2026-10-21 06:34:47 | 6d318afc… | 5 |
| [#905](https://github.com/Proto-UI/Proto-UI/pull/905) | 2026-10-21 09:20:10 | b928a56c… | 6 |

新899/905已本轮实际读REST merged状态、完整commits/files；923/924沿用上轮已核的主平台原件，并由本轮完整compare/tree确认纳入。作者commit日期与main合入日期分开保存；不把分支早期日期当成近期合入时间。

**新增11路径**主要是release子进程异常/信号处理与diagram证据producer。Release前置build不再把null状态当成功，publish异常/信号/null在dry-run例外和rate-limit重试前被拒绝，新增原生子进程控制与双语说明。Diagram新增两个受限profile、精确source/asset命名及实际页面Dialog旅程；改变的是证据工作流，没有修改产品Dialog/Overlay。源代码新增测试不等于它们已在新组合执行。

**完整104路径里仍需重点处理#924共享依赖。** React Portal重开/Document引用、原生Overlay目标准入和available-space Host与C的Portal/Select/Overlay/Focus组合有关。这些输入不能由旧6a CI覆盖。#923的40组声明在新.proto.ts中的Gitblob仍与原index完全相同，但路径/导出/证据图会影响发现与验证输入，不能据此推算catalog或collector已通过。

C head6a相对042f的33条净路径与完整104路径 **交集0**，与最近11路径也交集0。Header、Search、Sidebar和原keyboard-owner17相关文件未被这次incoming delta直接改动。这个结果尚不是root合成tree的保存证明；root提供实际merge tree后才能检查C33和incoming104是否都保留。

**CLI源码边界：** packages/cli/src下31个文件相对042f与f746均mode/type/blob不变，包含prototype-style-tokens、proto-style-css、shadow-style-delivery等。全量唯一CLI变更是finf-components测试；没有Form/Field/Label/Error或conditional-style collector实现修复。因此本次main推进不能自行关闭Form色值/token或collector职责问题。当前CLI issue ACK未由本源审查查询，不能把上轮无ACK当本轮事实。

本次没有fetch/checkout/merge/改产品/跑测试或浏览器/发布/新agent。报告是 **partial / ABSTAIN**，0个来源或清单不一致；整合后的断言、deadline和owner17必须继续按root实际新tree与新执行证明，旧结果全部保持历史来源。
