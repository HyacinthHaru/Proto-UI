# Portal adoption：原Node负例、真实Chrome与局部夹具补偿

结论：当前证据支持这四个Node负例来自 **HappyDOM在新renderer节点插入时未补齐跨Document adoption模型**。不能据此给Adapter添加生产fallback。原四个红断言保留；本报告为 **partial / ABSTAIN**，不是GitHub批准。

- 原整合Node144为1939pass/8fail，其中4个Portal失败都在adoption/suspension与旧host稳定断言之后的close/reopen：原201查foreign target为null。其余4个Form/Checkbox token红保持独立归属。
- 精确b928 Git-loader原4case：0pass/4fail/68filtered，358个实际加载repo输入逐字节等Git。不是仅按测试名字认定main也红。
- 精确23221加单点同步观测：0pass/4fail/68filtered，原201前读取同一已算出的reopened值。四条均host/owner=foreign，但Vue3新span或Vue2新anchor comment仍ownerDocument=original、parentDocument=foreign，目标实际留在original body，foreign0。两Window的Node.prototype和两方法确实共享，0observerError。
- 真实Chrome156.0.8078.47的Vue3/无Fragment/无onUpdated/Vue2私有等价控制 **4/4通过**，20条件每例通过。原生adopt后旧target固定/suspended，close/open后新target在foreign body且logicalparent/setup/changes正确，最后dispose1、两doc0目标。实际bundle361inputs，其中351个repo文件等23221 Git；输入前后稳定。NativeLinks两行dirty被记录且不在bundle输入，不冒称clean工作树。此控制不是原sharedtest、键盘/焦点遍历或视觉验收。

Root局部补偿diff静态 **0具体finding**：只在此case的try内spy共享Node.prototype.appendChild/insertBefore；实际foreign receiver且child跨doc时复用已有deepadopt，再委托原方法。没有指定目标body或篡改owner/open/material，也没有新await。原201与其后Document、parent、唯一性、logicalparent、setup/dispose和changes全部保留。finally在原cleanup前逆序restore，后续cleanup拒绝不会留下正常已装hook。移除新增模型代码和vi import后，整个文件逐字节等原Git。

Root实际focused4已4pass/68filtered；这不是所有6个sharedcontract消费者或145组合通过，后续执行需独立绑定。两个准备失败也原样保留：Gitreader ENOBUFS为0执行；首次Chrome barevue bundle解析失败为0执行/4skip。未把它们计作产品red。

当前candidate SHA256 `a574775bc4a698cd931f6145ce925197da861ac5533519e32f261ab92b392e26`。报告保留全部source与receipt引用；没有改产品；我方Node/browser作业均已终态，root的其它作业不在此状态声明中。
