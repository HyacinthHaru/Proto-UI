import base from '<PRODUCT_ROOT>/vitest.config.ts';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
const product = '<PRODUCT_ROOT>';
const evidence = '<R16>/portal-adoption-review/node-doc-observed-v1';
const revision = '23221b2668f0e71b4d87d6167d73f2808409d81c';
const entries = new Map<string, string>();
for (const line of execFileSync('git', ['ls-tree', '-r', '-z', revision], { cwd: product, maxBuffer: 16 * 1024 * 1024 }).toString().split('\0')) {
  if (!line) continue;
  const [meta, file] = line.split('\t');
  const [, kind, blob] = meta.split(' ');
  if (kind === 'blob') entries.set(file, blob);
}
const recorded = new Set<string>();
export default {
  ...base,
  root: product,
  plugins: [{
    name: 'private-exact-main-git-source-control',
    enforce: 'pre' as const,
    load(id: string) {
      const filename = id.split('?')[0];
      if (!filename.startsWith(product + '/') || filename.includes('/node_modules/')) return null;
      const relative = path.relative(product, filename).split(path.sep).join('/');
      const blob = entries.get(relative);
      if (!blob) {
        if (fs.existsSync(filename)) throw new Error(`Private main control refuses non-main workspace input: ${relative}`);
        return null;
      }
      const original = execFileSync('git', ['cat-file', 'blob', blob], { cwd: product, maxBuffer: 16 * 1024 * 1024 });
      const code = relative === 'packages/adapters/react/test/portal-destination.contract.ts' ? fs.readFileSync(path.join(evidence, 'observed.contract.ts')) : original;
      if (!recorded.has(relative)) {
        recorded.add(relative);
        fs.appendFileSync(path.join(evidence, 'loaded-source.jsonl'), JSON.stringify({
          revision, path: relative, blob, bytes: code.length, privateDiagnosticOverride: !code.equals(original), originalGitSHA256: createHash('sha256').update(original).digest('hex'),
          sha256: createHash('sha256').update(code).digest('hex'),
        }) + '\n');
      }
      return code.toString('utf8');
    },
  }, ...(base.plugins ?? [])],
  test: { ...base.test, environment: 'happy-dom' },
};
