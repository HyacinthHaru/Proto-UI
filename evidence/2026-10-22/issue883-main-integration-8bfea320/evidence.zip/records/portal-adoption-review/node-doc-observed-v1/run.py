import subprocess,json,datetime,hashlib,os
from pathlib import Path
R=Path(__file__).resolve().parent;W=Path('<PRODUCT_ROOT>');REV='23221b2668f0e71b4d87d6167d73f2808409d81c'
NODE='<TOOLCHAIN>/node-v24.21.0-darwin-arm64/bin/node'
files=['packages/adapters/vue/test/portal-destination-lifetimes.integration.test.ts','packages/adapters/vue/test/portal-without-fragment.integration.test.ts','packages/adapters/vue/test/portal-without-updated.integration.test.ts','packages/adapters/vue2/test/portal-destination-lifetimes.integration.test.ts']
def sh(b):return hashlib.sha256(b).hexdigest()
def g(*a):return subprocess.run(['git',*a],cwd=W,capture_output=True,check=True).stdout
keys=files+['packages/adapters/react/test/portal-destination.contract.ts','packages/adapters/vue/src/adapt.ts','packages/adapters/vue2/src/adapt.ts','packages/adapters/vue2/src/runtime/modules.ts','vitest.config.ts','package.json','pnpm-lock.yaml']
before={p:sh((W/p).read_bytes()) for p in keys}
assert (W/'vitest.config.ts').read_bytes()==g('show',REV+':vitest.config.ts')
for p in ['package.json','pnpm-lock.yaml'] :assert (W/p).read_bytes()==g('show',REV+':'+p)
argv=[NODE,str(W/'node_modules/vitest/vitest.mjs'),'run','--config',str(R/'vitest.config.ts'),*files,'-t','suspends a default-body epoch when its connected author is adopted into another document$','--maxWorkers=1','--minWorkers=1','--no-file-parallelism','--reporter=default','--reporter=json','--outputFile',str(R/'vitest.json')]
receipt={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'sourceRevision':REV,'physicalHeadBefore':g('rev-parse','HEAD').decode().strip(),'physicalStatusBefore':g('status','--porcelain').decode(),'configSHA256':sh((R/'vitest.config.ts').read_bytes()),'runnerSHA256':sh(Path(__file__).read_bytes()),'selectedSourceHashesBefore':before,'node':subprocess.run([NODE,'--version'],capture_output=True,text=True,check=True).stdout.strip(),'scope':'Original four cases from exact23221 Git blobs, with one synchronous read-only console record before the original201 assertion in the shared contract; all assertions/awaits unchanged. Installed dependencies reused. Not a full-main checkout or browser execution. No product file is changed.'}
(R/'running.json').write_text(json.dumps(receipt,indent=2)+'\n')
with (R/'run.log').open('wb') as out:
 p=subprocess.run(argv,cwd=W,stdout=out,stderr=subprocess.STDOUT)
receipt.update({'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'physicalHeadAfter':g('rev-parse','HEAD').decode().strip(),'physicalStatusAfter':g('status','--porcelain').decode(),'selectedSourceHashesAfter':{p:sh((W/p).read_bytes()) for p in keys}})
receipt['selectedProductSourceBytesUnchanged']=receipt['selectedSourceHashesAfter']==before
if (R/'vitest.json').exists():
 d=json.loads((R/'vitest.json').read_text());receipt['counts']={k:d.get(k) for k in ['numPassedTests','numFailedTests','numPendingTests','success']}
 receipt['selectedAssertions']=[{'file':f['name'],'name':a.get('fullName'),'status':a.get('status')} for f in d['testResults'] for a in f.get('assertionResults',[]) if a.get('status')!='skipped']
(R/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:receipt.get(k) for k in ['startedAt','finishedAt','exitCode','counts','selectedProductSourceBytesUnchanged']}),flush=True)
