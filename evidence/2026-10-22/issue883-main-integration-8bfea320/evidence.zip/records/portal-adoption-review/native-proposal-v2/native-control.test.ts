// @vitest-environment node
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { build } from 'esbuild';
import { beforeAll, afterAll, it, expect } from 'vitest';
import { launchBrowser } from '<PRODUCT_ROOT>/apps/www/src/content/docs/zh-cn/browser-harness';
const product = '<PRODUCT_ROOT>';
const proposal = '<R16>/portal-adoption-review/native-proposal-v2';
const out = process.env.PORTAL_ADOPTION_EVIDENCE_DIR!;
const head = '23221b2668f0e71b4d87d6167d73f2808409d81c';
const sha = (bytes: Buffer | string) => createHash('sha256').update(bytes).digest('hex');
let browser: Awaited<ReturnType<typeof launchBrowser>>, script: string;
const results: unknown[] = [];
let inputs: { path: string; bytes: number; sha256: string }[] = [];
beforeAll(async () => {
  expect(path.isAbsolute(out)).toBe(true);
  expect(execFileSync('git', ['rev-parse', 'HEAD'], { cwd: product, encoding: 'utf8' }).trim()).toBe(head);
  const physicalStatus = execFileSync('git', ['status', '--porcelain'], { cwd: product, encoding: 'utf8' }).trimEnd();
  expect(physicalStatus).toBe(" M apps/www/src/content/docs/zh-cn/site-native-links.browser.test.ts");
  expect(sha(fs.readFileSync(path.join(product, "apps/www/src/content/docs/zh-cn/site-native-links.browser.test.ts")))).toBe("9717cda9337d4a71b77e319fb5091b5424ccb5f3c6a60a452121274f26737f6e");
  fs.mkdirSync(out, { recursive: true });
  const entry = fs.readFileSync(path.join(proposal, 'entry.ts'), 'utf8');
  const bundle = await build({ stdin: { contents: entry, resolveDir: product, loader: 'ts' }, absWorkingDir: product,
    bundle: true, write: false, metafile: true, format: 'iife', globalName: 'PortalAdoptionControl', platform: 'browser', tsconfig: path.join(product, 'tsconfig.json') });
  script = bundle.outputFiles[0].text;
  inputs = Object.keys(bundle.metafile!.inputs).filter(file => file !== '<stdin>').map(file => {
    const actual = path.resolve(product, file); const bytes = fs.readFileSync(actual); return { path: actual, bytes: bytes.length, sha256: sha(bytes) };
  });
  expect(inputs.some(input => input.path === path.join(product, "apps/www/src/content/docs/zh-cn/site-native-links.browser.test.ts"))).toBe(false);
  fs.writeFileSync(path.join(out, 'metafile.json'), JSON.stringify(bundle.metafile, null, 2));
  fs.writeFileSync(path.join(out, 'source-before.json'), JSON.stringify({ head, physicalStatus, declaredDirty: { path: "apps/www/src/content/docs/zh-cn/site-native-links.browser.test.ts", sha256: "9717cda9337d4a71b77e319fb5091b5424ccb5f3c6a60a452121274f26737f6e", absentFromBundleInputs: true }, tree: execFileSync('git', ['rev-parse', 'HEAD^{tree}'], { cwd: product, encoding: 'utf8' }).trim(), entrySHA256: sha(entry), bundleSHA256: sha(script), inputCount: inputs.length, inputs }, null, 2));
  fs.writeFileSync(path.join(out, 'bundle.js'), script);
  browser = await launchBrowser();
}, 30_000);
afterAll(async () => {
  try { await browser?.close(); } finally {
    const after = inputs.map(input => ({ ...input, afterSHA256: sha(fs.readFileSync(input.path)) }));
    fs.writeFileSync(path.join(out, 'source-after.json'), JSON.stringify({ inputs: after, unchanged: after.every(x => x.sha256 === x.afterSHA256) }, null, 2));
  }
});
for (const variant of ['vue', 'vue-no-fragment', 'vue-no-updated', 'vue2']) {
  it(`native current-document adoption/reopen: ${variant}`, async () => {
    const context = await browser.newContext({ viewport: { width: 1000, height: 700 } });
    const page = await context.newPage(); const pageErrors: string[] = []; const consoleMessages: unknown[] = [];
    page.on('pageerror', error => pageErrors.push(error.message));
    page.on('console', message => consoleMessages.push({ type: message.type(), text: message.text() }));
    let result: any;
    try {
      await page.addScriptTag({ content: script });
      result = await page.evaluate((kind) => (window as any).PortalAdoptionControl.run(kind), variant);
      result.browser = browser.version(); result.pageErrors = pageErrors; result.consoleMessages = consoleMessages;
      results.push(result);
      fs.writeFileSync(path.join(out, `${variant}.json`), JSON.stringify(result, null, 2));
      expect(result.outcome, JSON.stringify(result.error ?? result)).toBe('passed');
      expect(result.cleanupErrors).toEqual([]);
      expect(result.afterDestroy).toEqual({ counts: { setup: 1, disposed: 1 }, originalTargets: 0, foreignTargets: 0 });
      expect(pageErrors).toEqual([]);
    } finally {
      await context.close();
      fs.writeFileSync(path.join(out, 'observations.json'), JSON.stringify(results, null, 2));
    }
  });
}
