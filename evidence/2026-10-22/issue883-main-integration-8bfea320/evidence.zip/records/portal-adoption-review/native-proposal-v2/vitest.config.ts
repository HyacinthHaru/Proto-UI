import base from '<PRODUCT_ROOT>/vitest.config.ts';
const root = '<R16>/portal-adoption-review/native-proposal-v2';
export default { ...base, root,
  server: { fs: { allow: [root, '<PRODUCT_ROOT>'] } },
  test: { ...base.test, environment: 'node', include: ['native-control.test.ts'], maxWorkers: 1, minWorkers: 1, fileParallelism: false },
};
