import * as Vue from 'vue';
import Vue2 from './packages/adapters/vue2/node_modules/vue/dist/vue.esm.js';
import { definePrototype } from '@proto.ui/core';
import { asFocusable, asOverlay } from '@proto.ui/hooks';
import { getWebPortalProjectionGeneration, isWebPortalMaterialSuspended } from '@proto.ui/adapter-base';
import { createVueAdapter } from './packages/adapters/vue/src';
import { createVue2Adapter } from './packages/adapters/vue2/src/adapt';
import { getProtoParent as vueParent } from './packages/adapters/vue/src/platform/instance-tree';
import { getProtoParent as vue2Parent } from './packages/adapters/vue2/src/platform/instance-tree';

export async function run(variant: string) {
  const original = document;
  const scene = document.createElement('section');
  const host = document.createElement('div');
  scene.append(host);
  document.body.append(scene);
  const frame = document.createElement('iframe');
  document.body.append(frame);
  const foreign = frame.contentDocument!;
  const counts = { setup: 0, disposed: 0 };
  const changes: boolean[] = [];
  const report: any = { variant, framework: variant === 'vue2' ? (Vue2 as any).version : Vue.version, outcome: 'running', stages: [], checks: [], cleanupErrors: [] };
  let stage = 'setup';
  const docId = (doc: Document | null) => doc === original ? 'original' : doc === foreign ? 'foreign' : doc ? 'other' : null;
  const facts = (node: Node | null) => node && ({
    nodeName: node.nodeName, connected: node.isConnected, ownerDocument: docId(node.ownerDocument),
    parentName: node.parentNode?.nodeName ?? null, parentDocument: docId(node.parentNode?.ownerDocument ?? null),
    parentIsOriginalBody: node.parentNode === original.body, parentIsForeignBody: node.parentNode === foreign.body,
  });
  let mounted: any;
  let target: HTMLElement | null = null;
  const record = () => report.stages.push({ stage, pageMs: performance.now(), host: facts(host),
    owner: facts(mounted?.owner()), origin: facts(host.querySelector('[data-pui-portal-origin]')),
    originalTargets: [...original.querySelectorAll('.portal-lifetime-target')].map(facts),
    foreignTargets: [...foreign.querySelectorAll('.portal-lifetime-target')].map(facts),
    originalOrigins: [...original.querySelectorAll('[data-pui-portal-origin]')].map(facts),
    foreignOrigins: [...foreign.querySelectorAll('[data-pui-portal-origin]')].map(facts),
    oldTarget: facts(target), oldTargetSuspended: target ? isWebPortalMaterialSuspended(target) : null,
    counts: { ...counts }, changes: [...changes], open: mounted?.actions().isOpen() ?? null });
  const check = (name: string, value: boolean) => { report.checks.push({ stage, name, value }); if (!value) throw new Error(`${stage}: ${name}`); };
  const ownerProto = definePrototype({ name: `native-adopt-owner-${variant}`, setup() { asFocusable(); return r => r.slot(); } });
  const contentProto = definePrototype({ name: `native-adopt-content-${variant}`, setup(def) {
    counts.setup++;
    asFocusable();
    const overlay = asOverlay();
    overlay.configure({ defaultOpen: true, portal: true, entry: 'manual', restore: 'none', closeOnEscape: true, closeOnFocusOutside: false, closeOnOutsidePress: false });
    overlay.open.watch((_run, event) => { if (event.type === 'next') changes.push(event.next); });
    def.expose('actions', { open: () => overlay.openOverlay(), close: () => overlay.close(), isOpen: () => overlay.isOpen() });
    def.lifecycle.onBeforeDispose(() => counts.disposed++);
    return () => 'Destination lifetime content';
  } });
  try {
    if (variant === 'vue2') {
      const V: any = Vue2;
      const adapt = createVue2Adapter({ extend: V.extend.bind(V), nextTick: V.nextTick.bind(V), set: V.set.bind(V), delete: V.delete.bind(V) });
      const Owner = adapt(ownerProto), Content = adapt(contentProto);
      let revision = 0;
      const App = V.extend({ render(h: any) { return h(Owner, { attrs: { 'data-revision': revision } }, [h(Content, { ref: 'content', class: 'portal-lifetime-target', attrs: { 'data-revision': revision } })]); } });
      const vm = new App().$mount();
      host.append(vm.$el);
      const tick = async () => { await Promise.resolve(); await V.nextTick(); await new Promise(resolve => requestAnimationFrame(resolve)); await Promise.resolve(); };
      const flush = async () => { await tick(); await tick(); };
      mounted = { flush, run: async (work: () => void) => { work(); await flush(); }, refresh: async () => { revision++; vm.$forceUpdate(); await flush(); },
        destroy: async () => { vm.$destroy(); host.replaceChildren(); await flush(); }, actions: () => vm.$refs.content.getExposes().actions,
        owner: () => host.querySelector('[data-pui-root]'), parent: vue2Parent };
    } else {
      const { Fragment, ...withoutFragment } = Vue;
      const { onUpdated, ...withoutUpdated } = Vue;
      const runtime = variant === 'vue-no-fragment' ? withoutFragment : variant === 'vue-no-updated' ? withoutUpdated : Vue;
      const adapt = createVueAdapter(runtime);
      const Owner = adapt(ownerProto), Content = adapt(contentProto);
      const ref = Vue.ref<any>(), revision = Vue.ref(0);
      const app = Vue.createApp({ render: () => Vue.h(Owner, { 'data-revision': revision.value }, () => Vue.h(Content, { ref, class: 'portal-lifetime-target', 'data-revision': revision.value })) });
      app.mount(host);
      const flush = async () => { await Vue.nextTick(); await new Promise(resolve => setTimeout(resolve, 0)); await Vue.nextTick(); };
      mounted = { flush, run: async (work: () => void) => { work(); await flush(); }, refresh: async () => { revision.value++; await flush(); },
        destroy: async () => { app.unmount(); await flush(); }, actions: () => ref.value.getExposes().actions,
        owner: () => host.querySelector('[data-pui-root]'), parent: vueParent };
    }
    await mounted.flush();
    stage = 'initial'; target = original.querySelector<HTMLElement>('.portal-lifetime-target'); record();
    check('initial target exists', !!target);
    const oldParent = target!.parentNode, oldDocument = target!.ownerDocument, generation = getWebPortalProjectionGeneration(target!);
    check('initial material not suspended', !isWebPortalMaterialSuspended(target!));
    stage = 'native-adoption';
    await mounted.run(() => { foreign.adoptNode(host); foreign.body.append(host); });
    await mounted.flush(); await mounted.refresh(); record();
    check('old target suspended', isWebPortalMaterialSuspended(target!));
    check('old target identity retained', original.querySelector('.portal-lifetime-target') === target);
    check('old target parent retained', target!.parentNode === oldParent);
    check('old target document retained', target!.ownerDocument === oldDocument);
    check('old target connected', target!.isConnected);
    check('old projection generation retained', getWebPortalProjectionGeneration(target!) === generation);
    check('semantic owner remains open', mounted.actions().isOpen() === true);
    check('one logical setup no dispose', counts.setup === 1 && counts.disposed === 0);
    check('no semantic changes from adoption', changes.length === 0);
    stage = 'closed'; await mounted.run(() => mounted.actions().close()); await mounted.flush(); record();
    stage = 'reopened'; await mounted.run(() => mounted.actions().open()); await mounted.flush(); record();
    const reopened = foreign.querySelector<HTMLElement>('.portal-lifetime-target');
    check('foreign reopened target exists', !!reopened);
    check('reopened ownerDocument foreign', reopened!.ownerDocument === foreign);
    check('reopened parent foreign body', reopened!.parentElement === foreign.body);
    check('no original-document target remains', original.querySelectorAll('.portal-lifetime-target').length === 0);
    check('exactly one foreign-document target', foreign.querySelectorAll('.portal-lifetime-target').length === 1);
    check('logical parent remains author', mounted.parent(reopened!) === mounted.owner());
    check('semantic owner open after reopen', mounted.actions().isOpen() === true);
    check('one setup no dispose after reopen', counts.setup === 1 && counts.disposed === 0);
    check('only close/open semantic changes', JSON.stringify(changes) === '[false,true]');
    report.outcome = 'passed';
  } catch (error) {
    report.outcome = 'failed'; report.error = { stage, message: String(error), stack: error instanceof Error ? error.stack : undefined }; record();
  } finally {
    try { await mounted?.destroy(); } catch (error) { report.cleanupErrors.push(String(error)); }
    report.afterDestroy = { counts: { ...counts }, originalTargets: original.querySelectorAll('.portal-lifetime-target').length, foreignTargets: foreign.querySelectorAll('.portal-lifetime-target').length };
    frame.remove(); scene.remove();
  }
  return report;
}
