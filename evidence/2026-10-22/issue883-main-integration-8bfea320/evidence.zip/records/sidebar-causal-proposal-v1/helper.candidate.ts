/** One route-entry layout request. Article identity remains Starlight's native
 * aria-current=page link; this helper never owns selection, focus or navigation. */
const owners = new WeakMap<HTMLElement, () => void>();

export function nearestSidebarScroller(
  link: HTMLElement,
  boundary: HTMLElement
): HTMLElement | null {
  const view = boundary.ownerDocument.defaultView;
  if (!view || !boundary.contains(link)) return null;
  for (let node = link.parentElement; node && boundary.contains(node); node = node.parentElement) {
    const style = view.getComputedStyle(node);
    if (
      node.clientHeight > 0 &&
      node.scrollHeight > node.clientHeight &&
      /^(auto|scroll|overlay)$/.test(style.overflowY)
    )
      return node;
    if (node === boundary) break;
  }
  return null;
}

export function nearestEdgeScrollTop(input: {
  top: number;
  bottom: number;
  viewportTop: number;
  viewportHeight: number;
  scrollTop: number;
  scrollHeight: number;
}): number {
  const { top, bottom, viewportTop, viewportHeight, scrollTop, scrollHeight } = input;
  const end = viewportTop + viewportHeight;
  const delta =
    top < viewportTop || bottom - top > viewportHeight
      ? top - viewportTop
      : bottom > end
        ? bottom - end
        : 0;
  return Math.max(0, Math.min(Math.max(0, scrollHeight - viewportHeight), scrollTop + delta));
}

export function initSidebarCurrentVisibility(boundary: HTMLElement): () => void {
  const existing = owners.get(boundary);
  if (existing) return existing;
  const document = boundary.ownerDocument;
  const view = document.defaultView;
  if (!view) return () => {};
  let alive = true;
  let current: HTMLAnchorElement | null = null;
  let pending = true;
  let yielded = false;
  let projectionSeen = false;
  let fontsReady = !document.fonts || document.fonts.status === 'loaded';
  let frame: number | undefined;
  let stableFrames = 0;
  let previousGeometry = '';
  let measured = false;
  let expectedScroll: { owner: HTMLElement; top: number } | null = null;
  // Private disposable trace; never consulted by the layout policy.
  const diagnosticKey = Symbol.for('proto-ui.sidebar-visibility.trace.20261022.v1');
  let diagnostic: any = null;
  let diagnosticOwner = 0;
  try {
    const target = view as any;
    diagnostic = target[diagnosticKey] ??= {
      schemaVersion: 1, limit: 512, seen: 0, dropped: 0, errors: 0, owners: 0, events: [],
    };
    diagnosticOwner = ++diagnostic.owners;
  } catch { /* Diagnostic unavailability must not change layout. */ }
  const trace = (stage: string, detail?: () => unknown) => {
    try {
      if (!diagnostic) return;
      const ordinal = ++diagnostic.seen;
      if (diagnostic.events.length >= diagnostic.limit) { diagnostic.dropped++; return; }
      diagnostic.events.push({
        ordinal, owner: diagnosticOwner, stage,
        pageMs: view.performance.now(), timeOrigin: view.performance.timeOrigin,
        alive, pending, yielded, projectionSeen, fontsReady, measured, stableFrames,
        frame: frame ?? null,
        expectedTop: expectedScroll?.top ?? null,
        expectedOwnerIsBoundary: expectedScroll?.owner === boundary,
        detail: detail?.() ?? null,
      });
    } catch {
      try { if (diagnostic) diagnostic.errors++; } catch { /* Retain original flow. */ }
    }
  };
  const currentLink = () =>
    boundary.querySelector<HTMLAnchorElement>('.top-level a[aria-current="page"]');
  const cancelFrame = () => {
    if (frame !== undefined) view.cancelAnimationFrame(frame);
    frame = undefined;
  };
  const yieldToUser = (event?: Event) => {
    trace('yield.before', () => ({ reason: event?.type ?? 'internal', trusted: event?.isTrusted ?? null }));
    yielded = true;
    pending = false;
    cancelFrame();
    trace('yield.after');
  };
  const schedule = () => {
    if (!alive || !pending || yielded || frame !== undefined) {
      trace('schedule.skipped');
      return;
    }
    frame = view.requestAnimationFrame(measure);
    trace('schedule.queued');
  };
  const request = () => {
    trace('request.begin');
    if (current) resize?.unobserve(current);
    current = currentLink();
    if (current) resize?.observe(current);
    pending = true;
    yielded = false;
    measured = false;
    expectedScroll = null;
    stableFrames = 0;
    previousGeometry = '';
    projectionSeen = current?.dataset.siteLinkEnhanced === 'true';
    trace('request.reset');
    if (current) {
      for (
        let node = current.parentElement;
        node && boundary.contains(node);
        node = node.parentElement
      ) {
        if (node instanceof view.HTMLDetailsElement) node.open = true;
        if (node === boundary) break;
      }
    }
    schedule();
  };
  function measure() {
    frame = undefined;
    trace('measure.enter');
    if (!alive || !pending || yielded) { trace('measure.skipped'); return; }
    if (!boundary.isConnected) {
      trace('measure.disconnected');
      destroy();
      return;
    }
    if (!current) {
      pending = false;
      trace('stop-pending.no-current');
      return;
    }
    if (!current.isConnected || current !== currentLink()) {
      trace('measure.current-changed');
      request();
      return;
    }
    const rect = current.getBoundingClientRect();
    // A closed mobile drawer waits for its real opening event, without polling.
    if (rect.width <= 0 || rect.height <= 0 || current.closest('[hidden]')) {
      trace('measure.not-visible', () => ({ width: rect.width, height: rect.height }));
      return;
    }
    const owner = nearestSidebarScroller(current, boundary);
    if (!owner) {
      pending = false;
      trace('stop-pending.no-owner', () => ({ top: rect.top, bottom: rect.bottom }));
      return;
    }
    const viewport = owner.getBoundingClientRect();
    const measurementInput = {
      top: rect.top,
      bottom: rect.bottom,
      viewportTop: viewport.top + owner.clientTop,
      viewportHeight: owner.clientHeight,
      scrollTop: owner.scrollTop,
      scrollHeight: owner.scrollHeight,
    };
    const top = nearestEdgeScrollTop(measurementInput);
    trace('measure.plan', () => ({
      input: measurementInput, targetTop: top, ownerIsBoundary: owner === boundary,
      rowWidth: rect.width, rowHeight: rect.height,
    }));
    measured = true;
    if (Math.abs(top - owner.scrollTop) > 0.5) {
      expectedScroll = { owner, top };
      trace('scroll.write', () => ({ targetTop: top, sampledBefore: measurementInput.scrollTop }));
      owner.scrollTop = top;
      stableFrames = 0;
    }
    const geometryValues = [
      rect.top,
      rect.bottom,
      viewport.top,
      owner.clientHeight,
      owner.scrollHeight,
      owner.scrollTop,
    ];
    const geometry = geometryValues.join('/');
    stableFrames = geometry === previousGeometry ? stableFrames + 1 : 0;
    previousGeometry = geometry;
    const surfacePending =
      current.hasAttribute('data-site-native-link') && !current.querySelector('[data-pui-style]');
    trace('measure.geometry', () => ({
      values: geometryValues, surfacePending, targetTop: top,
      rectTiming: 'rect captured before any scroll write; final scrollTop is the existing later read',
    }));
    if (!fontsReady || surfacePending) { trace('measure.await-font-or-projection'); return; } // actual observations resume work
    if (stableFrames >= 2) {
      pending = false;
      trace('stop-pending.stable');
      return;
    }
    schedule();
  }
  const mutations = new view.MutationObserver((records) => {
    trace('MO.delivery', () => ({
      records: records.length,
      first8: records.slice(0, 8).map((record) => ({ type: record.type, attribute: record.attributeName })),
    }));
    if (!alive) return;
    if (currentLink() !== current) {
      trace('MO.current-changed');
      request();
      return;
    }
    if (yielded) { trace('MO.skipped-yielded'); return; }
    const projected = current?.dataset.siteLinkEnhanced === 'true';
    if (projected && !projectionSeen) {
      projectionSeen = true;
      pending = true;
      stableFrames = 0;
      trace('MO.first-projection');
    }
    schedule();
  });
  mutations.observe(boundary, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ['aria-current', 'open', 'data-site-link-enhanced', 'data-pui-style'],
  });
  const resize =
    typeof view.ResizeObserver === 'function' ? new view.ResizeObserver((entries) => {
      trace('RO.delivery', () => ({
        entries: entries.length,
        first8: entries.slice(0, 8).map((entry) => ({
          boundary: entry.target === boundary, current: entry.target === current,
          width: entry.contentRect.width, height: entry.contentRect.height,
        })),
      }));
      schedule();
    }) : null;
  resize?.observe(boundary);
  const open = () => {
    trace('contents.open');
    if (!yielded) {
      pending = true;
      stableFrames = 0;
      schedule();
    }
  };
  const pageShow = (event: PageTransitionEvent) => {
    trace('pageshow', () => ({ persisted: event.persisted }));
    if (event.persisted) request();
  };
  const keydown = (event: KeyboardEvent) => {
    if (
      ['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End', ' ', 'Tab', 'Enter'].includes(
        event.key
      )
    ) {
      trace('keydown.yield', () => ({ key: event.key, trusted: event.isTrusted }));
      yieldToUser();
    }
  };
  const scroll = (event: Event) => {
    if (!measured || !(event.target instanceof view.HTMLElement)) { trace('scroll.ignored'); return; }
    let sampledScrollTop: number | undefined;
    if (
      expectedScroll?.owner === event.target &&
      Math.abs((sampledScrollTop = event.target.scrollTop) - expectedScroll.top) <= 0.5
    ) {
      trace('scroll.expected', () => ({ actualTop: sampledScrollTop, trusted: event.isTrusted }));
      return;
    }
    trace('scroll.unexpected', () => ({
      targetIsExpected: expectedScroll?.owner === event.target,
      actualTop: sampledScrollTop ?? null,
      actualTopWasReadByOriginalCondition: sampledScrollTop !== undefined,
      trusted: event.isTrusted,
    }));
    yieldToUser();
  };
  function destroy() {
    trace('destroy.enter');
    if (!alive) return;
    alive = false;
    cancelFrame();
    mutations.disconnect();
    resize?.disconnect();
    boundary.removeEventListener('wheel', yieldToUser);
    boundary.removeEventListener('touchstart', yieldToUser);
    boundary.removeEventListener('pointerdown', yieldToUser);
    boundary.removeEventListener('keydown', keydown);
    boundary.removeEventListener('scroll', scroll, true);
    document.removeEventListener('site-contents:open', open);
    document.removeEventListener('astro:before-swap', destroy);
    view?.removeEventListener('pageshow', pageShow);
    owners.delete(boundary);
  }
  boundary.addEventListener('wheel', yieldToUser, { passive: true });
  boundary.addEventListener('touchstart', yieldToUser, { passive: true });
  boundary.addEventListener('pointerdown', yieldToUser, { passive: true });
  boundary.addEventListener('keydown', keydown);
  boundary.addEventListener('scroll', scroll, true);
  document.addEventListener('site-contents:open', open);
  document.addEventListener('astro:before-swap', destroy);
  view.addEventListener('pageshow', pageShow);
  document.fonts?.ready.then(() => {
    trace('fonts.ready');
    if (alive && !yielded) {
      fontsReady = true;
      pending = true;
      stableFrames = 0;
      schedule();
    }
  });
  owners.set(boundary, destroy);
  trace('init');
  request();
  return destroy;
}

export function initSiteSidebarCurrentVisibility(document: Document): void {
  document.querySelectorAll<HTMLElement>('.docs-sidebar').forEach(initSidebarCurrentVisibility);
}
