准确8bfea的五个指定workflow已完成只读对账。主CI 39744816321 **completed / failure**，实际完整分页22 jobs：{'success': 13, 'failure': 9}。这是这些run的终态，不是所有仓库checks或全C验收；结论partial/ABSTAIN。

实际synthetic checkout `81b2b5caceaf0b310e1960ccab9a1202a75994b0`，parents b928+8bfea，tree`954f4fbefd35d3c89b47618dc498ce00820e168a`等于产品。真实plan General1268files、browser[11, 11, 10, 10, 10, 10, 10, 10]、productionExcluded26。

完整分片[3, 4, 5, 6, 7]合计 **549pass/9fail/15skip**；不完整片[1, 2, 8]逐片保留exit/visible results，不构造all8总数。每片全部原summary/首失败/日志行见JSON。

General在spec-authoring1input后，public-docs78项退出，未进Vitest；78行与旧6a逐条相同，不作为统一因果推断。类型937/0error/0warning/14hint。Package实际45/47构建、47manifest、policy9test通过；9measure4PASS/5ADVISORY，非47build或strict9green。

Dialog candidate原8pass；baseline15d严格接受7geometry+1not-offered，二者分源。Portal-direction和Homepage capture在3分钟字体安装setup超时，未执行对应browser。Startup candidate原23pass4fail，四width原30s Value可见性等待失败，artifact88其它records没有四个失败capture；baseline48b原27pass不重标。Search专项20/10，六initial-ready和四role1s红分开，迟到ready不回填。Density8个Shadcn gallery主按钮实际height36对原32±1为红，原metrics已verified保存；未直接改oracle或归因。

主shard2的Homepage实际8pass1Brutalist红，原poll1000.429096ms拒绝，第三query晚78.746911ms返回；boundeddrain78.481018ms完成、pending0。全部时钟括号条件映射writer约778.45–779.41ms、MO897.55–898.41ms，utility自身2括号第三getter约1077.20–1078.32ms，在原deadline之后。不是完整family事务已完成的证明，也不把late返回改判pass。主shard8NativeLinks10/Header16、shard1Shadow111、shard5Coll36/color9分别真实通过，但前两片仍124无总summary。

所有原日志、完整分页及收据、checkout Git对象、actualplan、选中artifact JSON/text的SHA均列于canonical-public-files.json。完整ZIP及PNG不在建议公开集合，不新视审、不声称视觉通过。主CI actual浏览器版本以原件为准；startup实际155与本地matched145不同。未重跑/取消/触发Actions，未改源码或测试。
