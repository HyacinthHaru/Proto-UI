# V2 packed source boundary 增补

结果为 partial / ABSTAIN，没有修改、构建或新增浏览器执行。job119791354119 原log337实际拒绝 `packages/adapters/base/src/material/liquidgl-kernel.generated.ts` 与 `packages/adapters/base/src/material/contact-profile.ts`。

静态可达链是 `build-browser.mjs` 选择 `browser-entry.ts` → 入口直接引用 `preview-material-scene.ts` → scene第8行相对引用 `contact-profile.ts` → 该文件第1行引用generated kernel。packed模式把包名exports与三条diagnostic alias映射到dist，但不会改写scene中的相对src路径。`consumer-boundary.mjs:19–23`只有private LiquidGlass Prototype例外，所以拒绝这两项符合当前wall。

两个实际src模块在main b928、CF、f590的Git blob分别始终为 `d84b08103e2e61c4437a8f8a82f4dde068063db5`（contact）与 `63543476cd7cc3f35556b71e94b81d421871e222`（kernel）。builder/entry/wall也三者相同。scene整文件main不同于CF/f590，但该相对import在main已存在，三者逐字相同。不能因此简单称非C或历史flake。

这是Previewer消费端与Material公共包表面的具体交界。现有 `@proto.ui/adapter-base/web-material` 映射 `dist/material/index.js`，但其index没有导出 `contactPaintOutset`，不能发明可用公共API或放宽src wall。历史record关联#420只提供过去集成背景，不确定当前个人owner。未取完整metafile，不声称完整生成图重建；native window blur红也没有被此import链解释。
