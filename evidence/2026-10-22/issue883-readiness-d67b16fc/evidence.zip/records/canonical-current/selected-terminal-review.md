# f590 指定五个终态 job 只读核对

**partial / ABSTAIN；三个红 workflow 均保留。** 实时读取四个 run 的全部 jobs 分页，5/5目标 job 均已完成；五份原log各下载一次，0读取错误，未下载artifact、未重跑Actions或本地测试。主CI39768955059不在本报告全量结论内。

Git API确认f590的tree为`11c1d93b6a160c2c6ea7fa7f1045ed7889b36c9c`，parent f369。四workflow元数据head均f590；日志记录了实际checkout。

| Workflow / job | 实际结果 | 实际来源与边界 |
|---|---|---|
| Startup candidate119791353474 | 1文件27/27 | f590产品 + f590probe，Node24.21.0 |
| Startup baseline119791354226 | 1文件27/27 | 历史48b产品 + f590probe，Node24.22.1；不是f590产品验证 |
| TOC119791353485 | capture exit1 | f590；continuous-reverse四条失败，非四个测试；Node24.22.1，日志实际Chrome156.0.8078.47 |
| V2 optical119791354119 | workflow失败 | 36单测和初始four-runtime流程已过；后续blur与packed边界失败，Node24.21.0 |
| Bootstrap119791355413 | 四文件44pass/1fail | 实际15个浏览器case全过；失败在source vocabulary，Node24.22.0 |

Startup两个subject先各自build，再拷贝同f590的3个probe closure文件。两个job的浏览器版本日志未记录，不能借用旧155或本地145，也不能称工具链相同。所有job记录pnpm10.32.1、esbuild0.25.12，Ubuntu24.04.5。

TOC首失败原log3547–3550：反向滚动没有满足shared-range target变化、multi-frame插值、document scroll跨度≥500，以及该stage存在instrumented update。对应`motion-contract.mjs:89/91`和`capture-toc-motion.mjs:572/732`。这是实际capture失败，不是setup失败；未读artifact逐帧facts，因此不判输入、scroll默认行为还是shared-range owner原因。后续独立历史411c原件捕获step成功，不将其当f590全流程绿色。

V2首断点为`continuous-browser.test.mjs:639`，原log316记录可信window blur谓词false。之后`consumer-boundary.mjs:23`明确拒绝packed graph里的`liquidgl-kernel.generated.ts`与`contact-profile.ts`两个public源码输入；再后`packed/source.json`缺失是前置打包没有完成，不能算独立生命周期根因。初始36单测及four-runtime阳性不覆盖后续红。

Bootstrap最终原失败为`controls.test.ts:219`：动态`collectProtoStyleTokens`与`DRAFT_FAMILY_STYLE_TOKENS`不相等，完整打印diff有23条expected-only、无received-only。15个浏览器case实际通过；HTTP起服重试不是最终失败原因。此处明确是family/collector/生成闭包边界，尚无C owner失效证据，不能据此接管CLI或放宽断言。

相关workflow/脚本/collector文件与CF均逐字相同，但这只限制本轮三笔测试增量的直接影响，不证明当前红属于历史继承或flake。三个根因仍按缺失证据保留unknown。完整run/job分页、Git对象、原log SHA/argv/时间、首失败行号见selected-terminal-review.json。
