# WC Portal 退役前提复核

结论：**0 个具体未解决 source finding；partial / ABSTAIN**。f590 的单 case 等待符合当前 draft 的物理 epoch 约束，不构成生产修复或 GitHub 批准。

- 原失败来源：clean `f3690a3693f82be0cfb3f76330a00ac5c95e399b` / `ea8e78b819e37e1d5a0dfb2db771b5512ed55ba9`，原 147 文件实际 2084 pass / 5 fail；Portal 的首失败是原 line 122 `host.parentNode === next`。
- 当前来源：`f59007825e2b19468a21d210cbd802d9b47ba76f` / `11c1d93b6a160c2c6ea7fa7f1045ed7889b36c9c`，parent 是 f369。Git 仅 1 路径、2 行插入；去掉新增注释和 wait 后，整份文件逐字节等原件。原输入、flush、case declaration、全部原断言以及 production / early-reopen / keyboard-owner 源均未改变。
- `HC-OVERLAY-PORTAL-0001-BINDING/MATERIAL`、`T-WEB-PORTAL-DESTINATION-0001-CASE-ADAPTER`、`C-LIFECYCLE-0006` 都是 draft。它们要求活 epoch 不搬目的地，detach 后下一 epoch 才选 pending destination；没有稳定发布或全宿主保证的扩大声明。

原 flush 只投递 30 次 microtask 和 0ms timer，并不保证两次 rAF conceal 已完成。`adapt.ts` 在 conceal 中收到新 open 时明确取消 barrier、保留 `owner.hasView`，现有 held-frame 原测试要求 mount 1 / unmount 0。私有 held-rAF 反例实际 1 fail / 9 filtered：close 后仍 portaled、detached、旧 parent、1 queued frame；open 后仍旧 parent、detached false、0 queued frame、setup 1 / disposed 0。该反例证明旧测试前提不足，**不将人工 held-rAF 当成自然红的原始时序**。

新增 `vi.waitFor(() => expect(isWebComponentPortaled(host)).toBe(false))` 只放在原 close/flush 后、原 open 前。已安装 Vitest 2.1.9 默认 timeout 1000ms、interval 50ms；外层 case deadline 未改变。它读取 `activeProjections` 租约状态，false 并不等于所有资源或 paint 已完成；删除发生在剩余同步 restore 之前。这里随后 open 沿既有 reconciliation 串行，原 next-parent / setup / dispose / marker 断言仍会验证最终结果。永不退役仍会失败。

已有执行分别保留：precommit f369 + 同候选的两文件 23/23；clean f590 原 147 文件 2085 pass / 4 fail，其中 body destination 10/10、conceal 13/13、keyboard-owner 17/17。剩余 4 个 CheckboxGroup token 红仍在，不宣称全绿。每次已读 before/after tracked census 均相等，但不是所有加载依赖的闭包证明。

必须保持的负边界：不要把等待加到 early-reopen 保留旧 epoch 用例或全局 flush；不要用宽松 parent/visibility 条件替代原 next；不要改生产 conceal、material、focus 或 owner 策略。没有执行新测试、浏览器、下载或外部写。完整 source/raw SHA 见同目录 report.json。
