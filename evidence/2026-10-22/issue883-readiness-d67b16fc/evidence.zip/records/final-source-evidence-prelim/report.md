# f590 最终源码与现有验证初步核对

**0 个具体未解决 finding；partial / ABSTAIN。** 仅核对源码与已存在的执行原件，没有运行测试、浏览器、下载或外部写，也不构成 GitHub 批准。

最终 `f59007825e2b19468a21d210cbd802d9b47ba76f` / `11c1d93b6a160c2c6ea7fa7f1045ed7889b36c9c` clean；三笔提交依次 ba0830 → f3690 → f5900，父关系从 CF 连续。三笔本地 `git verify-commit` 都 exit0 / SSH G（现有 ED25519 signing key），Author/Committer 均 HyacinthHaru <hyacinth@haru.ac>，各一条 DCO、无 co-author。b928 是最终头真实 ancestor。root 的 push receipt 记录最终 fork/PR head 相同；本审查没有另做远程读取。

按 R16 `final-cf-source-audit.json` 原清单逐项检查，**C33/33 的 mode/type/blob 都保留**。CF 与 f590 各11375条 Git entry，仅3个测试路径改变，其余11372条相同；没有生产或依赖修改。三个最终文件 SHA：

- Dialog reader：`ced26f76ab57f7d0cff911deabee55b140c11b42fd91aaecaf99305cb9750adb`。
- Docs observer：`c801d34f8e933bf379b5f24e370e3a9cfed9f59612a386160a64dc9ad20a6675`。
- WC retirement fixture：`a1613b89c96df7c12a54db461d801674eda631fb72c5c6969cd0452fbcf6527e`。

AST source-only 比对：Dialog 原11个 matcher、Docs 原114个 matcher 的方法和参数不变；WC 原37个全部保留，仅加退役 false predicate。三文件原 case/hook 显式 timeout、原输入/等待调用及 poll options 保留。原 keyboard router 与17-case源码完全不变；两次147 Node执行均实际17/17。

Dialog 只把几何 reader 改为复用既有 direct-body / 一层 Adapter-owned portal mount selector，仍过滤 present root。count2、0.5px、阴影/圆角/层叠/中心命中/resize、mount结构验证、20s等待及300s case 均未弱化；不是任意后代兜底。Docs 保留原 combobox matcher/default1s/180s case 与 trace.then链，只在失败 verdict 冻结后有限 drain 原 getter Promise 引用；单一1000ms是 cooperative 观察预算，不取消请求、不声称后续不会重试或零干扰。WC 等待仅对 detach 后 reopen 的前提；early-reopen 保留旧epoch控制不变。

| 已存在执行 | 实际来源 | 结果 |
|---|---|---|
| Dialog 原失败观测 | CF + 私有失败观测源码 | 1 fail，保留原红 |
| Dialog reader 修正 | CF + 单测试候选 | 1 pass；原case内4runtime循环 |
| Docs 原focused2 | ba0830 + Docs候选 | 2 pass / 28 filtered |
| Docs离线控制 | 同c801候选实际块，假matcher/getter | 4组5臂；原error/throw0/成功均保留，非原生故障复现 |
| f369 clean Node147 | f369 | 2084 pass / 5 fail |
| WC held-rAF反例 | f369 + 私有合法调度控制 | 1 fail / 9 filtered |
| WC两文件修正 | f369 + 两行候选 | 23 pass |
| f590 clean Node147 | f590 | 2085 pass / 4 fail |

最后4红仍是 `form-actions-quality.test.ts:192` 四family CheckboxGroup token。两次147中的名称、源和原 failureMessages 相同；这不是全部失败统一归因的证明。所有列出执行的 before/after tracked census 相同，仍不是完整loaded-input闭包。

**types来源限制：** 原run是 ba0830 + Docs候选，937 / 0 errors / 0 warnings / 14 hints，整份census逐字等 f369。与 f590 只差 WC retirement 新两行，因此它覆盖最终Dialog/Docs字节，但不能写成最终f590已重跑types。

本报告不读取正在运行的 native177，不计为绿；CI 39768955059 未查询，暂无本审查结论。后到终态应另存增补，不回填这些历史来源。完整签名、33项Git对象、原始输入SHA和分源结果见 report.json。
