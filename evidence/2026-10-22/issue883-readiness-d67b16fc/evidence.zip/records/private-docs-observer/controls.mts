import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { performance } from 'node:perf_hooks';
import { EventEmitter } from 'node:events';
import assert from 'node:assert/strict';
import path from 'node:path';
import ts from '<PRODUCT_ROOT>/node_modules/typescript/lib/typescript.js';
import { traceSearchGetter } from '<PRODUCT_ROOT>/apps/www/src/content/docs/zh-cn/site-search-evidence.ts';
import { settleFamilyQueryBatch } from '<PRODUCT_ROOT>/apps/www/src/content/docs/zh-cn/family-query-observer.ts';

const root = '<R17>/private-docs-observer';
const worktree = '<PRODUCT_ROOT>';
const candidate = process.argv[2] ?? path.join(root, 'candidate.browser.test.ts');
const output = process.argv[3] ?? path.join(root, 'controls-execution-v1');
assert(!existsSync(output), 'Preserve any earlier control result; choose a fresh output directory.');
mkdirSync(output, { recursive: true });
const hash = (value: string | Buffer) => createHash('sha256').update(value).digest('hex');
const source = readFileSync(candidate, 'utf8');
const first = source.indexOf('        const roleGetters: SearchGetterSample[] = [];');
const last = source.indexOf('        await revealHeaderPreferences(page);', first);
assert(first >= 0 && last > first);
const block = source.slice(first, last);
const transpiled = ts.transpileModule(block, {
  compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 },
  reportDiagnostics: true,
});
assert.equal(transpiled.diagnostics?.length ?? 0, 0);
const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
const run = new AsyncFunction(
  'expect', 'selector', 'traceSearchGetter', 'settleFamilyQueryBatch',
  'console', 'source', 'family', 'width', 'performance', 'context', transpiled.outputText
);
const binding = {
  preparedCandidate: candidate,
  sourceSHA256: hash(source),
  extractedBlockSHA256: hash(block),
  transpiledSHA256: hash(transpiled.outputText),
  helperSHA256: hash(readFileSync(path.join(worktree, 'apps/www/src/content/docs/zh-cn/family-query-observer.ts'))),
  traceHelperSHA256: hash(readFileSync(path.join(worktree, 'apps/www/src/content/docs/zh-cn/site-search-evidence.ts'))),
  physicalHead: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: worktree, encoding: 'utf8' }).trim(),
  node: process.version,
  method: 'Actual candidate block TypeScript-transpiled and executed with actual existing helpers; explicit fake matcher and getter controls. Not Vitest or Browser execution, not the original acceptance window or an observed natural failure.',
};
writeFileSync(path.join(output, 'binding.json'), JSON.stringify(binding, null, 2) + '\n');

const results: unknown[] = [];
for (const kind of ['late-combobox', 'never-settled', 'late-wrong-new-reference', 'logger-throws-original-zero', 'logger-throws-success']) {
  const logs: Array<{ label: string; value: any }> = [];
  const batches: Array<{ count: number; remainingBudgetMs: number }> = [];
  const context = new EventEmitter();
  let offlineCloseFinallyReached = false;
  let getterCalls = 0;
  let observedPolledCalls = 0;
  let caught: unknown = Symbol('not caught');
  const noError = caught;
  const original = kind === 'logger-throws-original-zero' ? 0 : new Error(`injected original matcher: ${kind}`);
  const loggerError = new Error('injected synchronous recording error');
  const timers: ReturnType<typeof setTimeout>[] = [];
  let resolveFirst!: (value: string | null) => void;
  const firstRequest = new Promise<string | null>((resolve) => { resolveFirst = resolve; });
  const never = new Promise<string | null>(() => {});
  const requests: Promise<string | null>[] = [];
  const selector = {
    getAttribute(name: string) {
      assert.equal(name, 'role');
      getterCalls++;
      const request = kind === 'logger-throws-success'
        ? Promise.resolve('combobox')
        : kind === 'logger-throws-original-zero'
          ? Promise.resolve(null)
          : getterCalls === 1 ? (kind === 'never-settled' ? never : firstRequest) : never;
      requests.push(request);
      return request;
    },
  };
  const expect = {
    poll(read: () => Promise<string | null>) {
      return {
        async toBe(expected: string) {
          observedPolledCalls++;
          const traced = read();
          // The late-reference arm deliberately calls the already supplied callback
          // in a microtask after a wrong result. Actual Vitest uses its own interval;
          // this adversarial schedule tests budget/reference handling only.
          if (kind === 'late-wrong-new-reference') {
            void traced.then((value) => {
              if (value !== expected) {
                observedPolledCalls++;
                void read().catch(() => {});
              }
            }).catch(() => {});
            timers.push(setTimeout(() => resolveFirst('button'), 600));
          } else {
            void traced.catch(() => {});
            if (kind === 'late-combobox') timers.push(setTimeout(() => resolveFirst('combobox'), 20));
          }
          if (kind.startsWith('logger-throws')) {
            const value = await traced;
            if (kind === 'logger-throws-success') { assert.equal(value, expected); return; }
          }
          // Deliberately supplied post-verdict starting point, not a fake claim
          // that this control executed the real 1000ms Vitest matcher.
          throw original;
        },
      };
    },
  };
  const consoleSink = {
    log(label: string, value: string) {
      logs.push({ label, value: JSON.parse(value) });
      if (kind.startsWith('logger-throws')) throw loggerError;
    },
  };
  const settle = <T>(batch: readonly Promise<T>[], remainingBudgetMs: number) => {
    for (const request of batch) assert(requests.includes(request as Promise<string | null>), 'Drain must observe a retained original getter Promise.');
    batches.push({ count: batch.length, remainingBudgetMs });
    return settleFamilyQueryBatch(batch, remainingBudgetMs);
  };
  const startedMs = performance.now();
  let watchdog: ReturnType<typeof setTimeout> | undefined;
  try {
    await Promise.race([
      run(expect, selector, traceSearchGetter, settle, consoleSink,
        { sha: binding.physicalHead, diagnosticControl: true }, 'shadcn', 2048, performance, context),
      new Promise((_, reject) => { watchdog = setTimeout(() => reject(new Error('offline watchdog exceeded')), 4000); }),
    ]);
  } catch (error) {
    caught = error;
  } finally {
    if (watchdog !== undefined) clearTimeout(watchdog);
    for (const timer of timers) clearTimeout(timer);
    // Explicit offline continuation marker only; not a real BrowserContext close.
    context.emit('close');
    offlineCloseFinallyReached = true;
  }
  const elapsedMs = performance.now() - startedMs;
  const readiness = logs.find((entry) => entry.label === '[Docs role readiness]')?.value;
  const settlement = logs.find((entry) => entry.label === '[Docs role settlement]')?.value;
  assert(readiness);
  assert(offlineCloseFinallyReached);
  if (kind === 'logger-throws-success') {
    assert.equal(caught, noError);
    assert.equal(readiness.passed, true);
    assert.equal(batches.length, 0);
  } else {
    assert.equal(caught, original, 'Keep the exact injected original verdict, including primitive 0.');
    assert.equal(readiness.passed, false);
    assert(settlement);
    assert.equal(settlement.budgetMs, 1000);
  }
  if (kind === 'late-combobox') {
    assert.equal(readiness.pending, 1);
    assert.equal(settlement.budgetExpired, false);
    assert.equal(settlement.completeAtDrainPoint, true);
    assert.equal(settlement.outcomes[0].value, 'combobox');
    assert.equal(getterCalls, 1);
  }
  if (kind === 'never-settled') {
    assert.equal(settlement.budgetExpired, true);
    assert.equal(settlement.completeAtDrainPoint, false);
    assert.equal(settlement.pendingRecordedSamples, 1);
    assert.equal(getterCalls, 1);
  }
  if (kind === 'late-wrong-new-reference') {
    assert.equal(getterCalls, 2);
    assert.equal(observedPolledCalls, 2);
    assert.equal(settlement.issuedAfterVerdict, 1);
    assert.equal(settlement.referencesAtDrainPoint, 2);
    assert.equal(settlement.budgetExpired, true);
    assert.equal(settlement.completeAtDrainPoint, false);
    assert.equal(batches.length, 2);
    assert(batches[0].remainingBudgetMs <= 1000);
    assert(batches[1].remainingBudgetMs < 500, 'A new reference must not renew the 1000ms observation budget.');
  }
  if (kind === 'logger-throws-original-zero') {
    assert.equal(caught, 0);
    assert.equal(settlement.observerError, true);
  }
  results.push({ kind, elapsedMs, getterCalls, observedPolledCalls, batches,
    originalVerdictPreserved: kind === 'logger-throws-success' ? caught === noError : caught === original,
    caughtKind: caught === noError ? 'none' : caught === 0 ? 'original primitive0' : caught === original ? 'same original Error object' : 'unexpected',
    offlineCloseFinallyReached, readiness, settlement });
}
const result = { at: new Date().toISOString(), ...binding, groups: 4, arms: results.length, results,
  limits: ['Explicit offline controlled matcher/getter failures; not actual Vitest1000ms or nativebrowser behavior.',
    'Late-wrong followup is adversarial microtask scheduling, not a reproduction of Vitest50ms scheduling.',
    'The source only claims a drain-point snapshot. A further original Vitest callback may be issued after that point; no quiescence or cancellation claim.',
    'Node timers are cooperative; the observation budget is not a hardwall bound on a blocked event loop.'] };
writeFileSync(path.join(output, 'report.json'), JSON.stringify(result, null, 2) + '\n');
process.stdout.write(JSON.stringify({ path: path.join(output, 'report.json'), arms: results.length,
  sha256: hash(readFileSync(path.join(output, 'report.json'))) }) + '\n');
