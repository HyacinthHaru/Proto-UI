# d67 popup-boundaries job — bounded failure review

[Job119806470451 / run39773465425](https://github.com/Proto-UI/Proto-UI/actions/runs/39773465425/job/119806470451) failed on direct checkout **d67b16fcea924538ca9c58829955084ad208f488**. The actual Git commit object binds it to tree `f1e37c12ee9546a31b65b1e4e929bf1059f793a9`, parent f590. The log was downloaded once; no media artifact was downloaded.

The failure is in **“Calibrate paint acceptance and bounded evidence storage”**, before the component browser journey. Its five Node test files report **187 tests, 186 passed, 1 failed, 0 skipped**. The only failed test is `apps/www/scripts/contrast-audit-plan.test.mjs:94`, with the original exact-equality assertion at line107: “normal PR evidence shards cover every current manifest family exactly once.”

The actual matrix has **21 unique families**; the manifest expects **22**, with **`input` missing and no extra family**. The workflow's five lists are at `.github/workflows/brutalist-contrast-evidence.yml:20–31`. The current Brutalist `input` manifest entry is at `projection-families.ts:859–864` and names `P-BASE-INPUT`, `demo-brutalist-input`, and `brutalist-input-root`.

The shell runs the Node calibration before `contrast-probe.browser.test.ts` under bash `-e`; the first command exits1. The next “Observe exact-head popup-boundaries…” step is explicitly **skipped** in actual job metadata. Therefore this job supplies **no contrast-probe Vitest result and no native Dropdown/Select/Dialog predicate result**. The popup-boundaries job name is not evidence of a Portal lifecycle failure.

The relevant workflow, test and manifest blobs are identical across b928, CF, f590 and d67. That is a static source observation, not a prior-main execution or a “flake/inherited” cause classification. This job proves a **QA shard inventory registration gap**; it does not prove a new C production defect. Integration/QA should follow that exact registration issue while preserving the original assertion. This review does not take over Input-family acceptance or the unrelated78 public-docs items.

`popup-failure-review.json` preserves exact raw/source SHA bindings, log lines, metadata and the 21-versus22 lists. The prior non-atomic38-workflow snapshot and main-CI0-jobs boundary remain unchanged. No tests, browser, Actions rerun/cancel, product/E-worktree edit or external comment occurred. Collection is complete and stopped. **Partial / ABSTAIN.**
