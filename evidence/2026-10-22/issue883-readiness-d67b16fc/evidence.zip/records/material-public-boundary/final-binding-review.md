# d67 Material 公共出口最终绑定

**0个具体finding；partial / ABSTAIN。** 实际commit `d67b16fcea924538ca9c58829955084ad208f488` / `f1e37c12ee9546a31b65b1e4e929bf1059f793a9`，parent f590。3个Git blob的SHA逐一等已审候选；SSH G、身份、单DCO、无coauthor核验通过。

CF→d67只有6paths。原C33实际是**32个mode/type/blob原样，加1个scene的已审import迁移**；反向还原import后scene整文件等原C。不能写33blob全相同。原helper/公式/shader、strictconsumer-wall、manifest/lock、keyboardowner与前三测试修复字节保持，d67没有改任何oracle/deadline。

实际基线cleanf59047/47build之后，原packed命令拒绝两个src输入。候选同命令在fresh47/47build后exit0，source.json明确`revision=f590, dirty=true, publicSourceInputs=[]`、420packageinputs、assetSHA实际匹配，仍标`execution=pending-browser-evidence`。生成index.js/index.d.ts均转发原函数，contact-profile.d.ts为`(width:number,height:number):number`；本报告保留当前小文件快照，不冒称pre-runhash或新的运行时调用。

其余真实precommit同候选验证：5files126/0，types937/0/0/14，47manifests。9项预算是**4within/5over严格旧ceiling，Finfdevelopmentadvisory exit0**，不是9PASS；原阈值未改，Node24.21.0/darwinarm64测量不替代Linuxcanonical。所有候选before/after11375trackedcensus相同，并逐项等最终d67字节。

已结束clean d67 Node147为2085pass/4fail，四个CheckboxGrouptoken红保留。新d67 native177/Portal16/canonical仍是本报告待追加范围，不以旧f590结果填充。初次focused/types的metadata index-lock启动失败未执行测试，保留原件并与start2成功分开。没有新测试/build/browser/下载或外部写。
