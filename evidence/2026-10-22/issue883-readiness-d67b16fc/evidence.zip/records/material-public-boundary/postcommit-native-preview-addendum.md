# d67 native177 与实际产物增补

Partial / ABSTAIN。原始报告保持不变。clean d67六文件native177实际177/177、11:50:24–11:59:27UTC；前后11375tracked census相同且等d67 Node147。后者四token红仍保留。

当前官方production artifact12423157802的现有ZIP逐字读取SHA等metadata/admission：c64349d44e34c6f3c0f320bb009efc7876811b63027d43e61df2cb8fa2168399，21143788bytes。完整index3837条，expanded和104067496；原defaultadmission1pass/0fail/0skip。producer独立原测试ZIP21208084bytes，不能与ActionsZIP压缩字节混同；全ZIP/site不入公开选择。

当前Startup job119806472199原log27/27，observations revision=d67、baseline=false、browser155.0.8059.39、92records。root实际view4帧，原PNG SHA全部核对；本审查未另看像素。2048Runtime label帧仍显示DemoBox loading；390Homepage部分正文在viewport下，不写全就绪/全页面/AT。

d67Portal16也已actual16/16、12:00:00–12:01:09UTC，sourcecensus一致；emitted export为独立NodeESM import/typeof smoke，不计入126tests。prefs恢复byte/mode相等，未选择private before内容。当前canonical snapshot明确queued、21jobs=7success/2running/12queued、非原子12:00:41–12:01:56；可供明确progress publication，不能称completed或全绿。未新运行测试、build、browser或下载；现有图像、raw及旧草稿不改。
