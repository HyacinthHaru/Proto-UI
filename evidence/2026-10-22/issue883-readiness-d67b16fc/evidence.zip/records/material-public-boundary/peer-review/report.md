# Material public boundary 三文件候选同行审查

**0 个具体 finding；partial / ABSTAIN，非 GitHub 批准。** 审查对象是 f590 clean 基线之上的三文件未提交候选，实际4插入/1删除。本审查未运行测试、build或browser，也没有修改工作树。

实际 diff 符合所述范围：`material/index.ts`只转发原 `contactPaintOutset`；scene把它并入既有`@proto.ui/adapter-base/web-material` import并删除相对src import；README补充当前draft Web contact profile、CSSpx输入输出和非准入边界。反向还原import后scene全文件等原件；原helper公式、sink、shader、manifest/subpath、strict consumer wall、lock及所有测试未动。

包表面规则要求public入口对应真实dist JS/d.ts，不能把source可达当成已交付。该函数属于adapter-base自有Web profile计算，经已有web-material subpath暴露；并未从具体Module包聚合语义helper或新增Module依赖，因此未发现与module-neutral package规则的直接冲突。这是有限增量出口，不追认此前未声明的public guarantee。

README当前文字没有扩大支持：输入是host bounding rectangle的CSSpx宽高，输出是当前profile的CSSpxpaint outset；明确不授予source、optical或input ownership，也不是其他profile的通用margin。Material/visual sink规范仍draft；另一个fake-host-only的HC-MATERIAL-CONTACT实体不因本出口获得production实现。原sink仍在该计算后独立检查source/carrier，scene没有新增geometry读取或改算法。

已核基线：clean f590原完整build实际47个distinct package记录、47/47、exit0、sourceStable；随后原packed命令actualexit1，仍在consumer-boundary.mjs:23拒绝contact-profile与generatedkernel两src路径。两个before/after11375tracked census均相同。该红不是因为尚未build公共包而伪造的前提。

候选build/packed绿色、声明/原生ESM入口、focused、budget、types本次尚未审为通过。待root实际终态后补精确绑定；不要使用旧基线的47build替代候选验证。原native window blur红仍独立，公开出口修复不能推出光学/输入/全family已验收。

完整candidate SHA、基线原件SHA与最小后续只读绑定清单在report.json。
