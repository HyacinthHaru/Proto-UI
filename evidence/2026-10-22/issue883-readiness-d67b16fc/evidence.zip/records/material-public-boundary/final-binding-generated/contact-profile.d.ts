/** Proto UI-owned derivative, not the unmodified upstream profile. The imported
 * literal and its MIT attribution stay intact. This finite profile paints only
 * inside a bounded expanded paint box: no host transform or Apple parity.
 * Mask and refraction normals share deformPoint and the same inset geometry. */
export declare const contactProfile = "liquidgl-v2-contact-canvas-1";
export declare const contactFragment: string;
/** Includes the maximal 5.5% drag displacement plus 2.25% dilation and AA. */
export declare function contactPaintOutset(width: number, height: number): number;
