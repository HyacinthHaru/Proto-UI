export { createWebMaterialSink, type WebMaterialOptions } from './sink.js';
export { contactPaintOutset } from './contact-profile.js';
export { createCanvasBackdropLease, inspectCanvasBackdrop, type CanvasBackdropLease, type CanvasBackdropFrame, } from './source.js';
export { createWebMaterialPreferences, type WebMaterialPreferences } from './preferences.js';
export { resolveMaterialStyle, resolvePaletteColor, type MaterialPalette, type MaterialPaletteSource, type MaterialPaletteSnapshot, } from './style.js';
