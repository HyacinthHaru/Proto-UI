# WC destination fixture retirement — bounded peer review

Result: **0 concrete findings; partial / ABSTAIN**. This reviewer inspected source and existing receipts only. The reviewer participated in the premise discussion; this is not a formal independent approval.

The candidate at physical `f3690a3693f82be0cfb3f76330a00ac5c95e399b` adds only a comment and `await vi.waitFor(() => expect(isWebComponentPortaled(host)).toBe(false))` after the original close/flush and before the original reopen. Removing those two lines reproduces the complete original test bytes. The original flush, inputs, destination/focus/material/setup/disposal/marker expectations and case declaration are unchanged. Vitest's installed wait defaults are 50 ms polling and a 1000 ms bound; this is an added observed lifecycle precondition, not a claim of identical execution timing or a larger original case deadline.

The original f369 aggregate is **147 files, 2084 pass / 5 fail**. Its new WC failure occurs at original line 122, after reopening, not at the initial mount. The old CF aggregate used byte-identical test/production source and this case passed; that comparison does not diagnose the new failure's scheduling.

Root's held-RAF control is **1 fail / 9 filtered**, using an explicitly visible document and an injected scheduler that holds rAF callbacks. After the unchanged close/flush it records `portaled=true`, `detached=true`, old destination and one queued frame. Reopen cancels that frame and clears detached while retaining the old parent. The original `expect(next)` then fails. This is an intentionally controlled schedule, not the natural scheduling trace of the original 147-file failure.

`adapt.ts:1193–1201` explicitly retains the old mounted epoch when a newer open cancels pending conceal. `portal-conceal.ts:10–45` waits two rendering callbacks for connected visible portals. The existing `portal-conceal.test.ts:237` independently preserves this warm-reopen behavior. Accordingly the destination-change fixture must first observe release of the old physical projection before requiring acquisition at the pending destination.

The actual candidate validation is **2 files / 23 pass**: all 10 destination cases and 13 conceal cases, including the original newer-open retained-epoch and terminal-removal controls. It ran on f369 plus the one dirty fixture, with source stability recorded. It is not a postcommit result or a new complete 147-file validation.

Authority remains bounded: `HC-OVERLAY-PORTAL-0001-BINDING`, `T-WEB-PORTAL-DESTINATION-0001-CASE-ADAPTER`, `C-AS-OVERLAY-0001` and `C-LIFECYCLE-0006` are draft; `A-WEB-COMPONENT-0001` is active. The destination policy fixes the parent for a live physical epoch and selects anew after detach. No authority is promoted, no product lifecycle is changed, and no visual/native/AT acceptance is inferred.

Exact source, authority and raw result hashes, timestamps and the held-control snapshots are in `report.json`. The original failing aggregate and controlled negative remain retained.
