# CF Brutalist artifact timing boundary

The three newly read original artifact JSON files agree exactly on the failure timing and source. They already answer the bounded writer/query/settlement question: one native attribute write returned before the deadline, while the third actual utility getter ran after it and its Node result arrived later. This is not merely a late protocol response. The original rejection stays red.

Actual count is3 Node calls and3 utility reads, values shadcn/shadcn/brutalist, no drops or observer errors; owner/current-root/restoration/detach checks succeeded. The original poll rejected at+1001.415981ms. Query3 was issued at+351.583379ms and returned at+1124.795467ms,123.379486ms after rejection. Post-verdict drain finished in123.178244ms with pending0. Under their recorded clock brackets, writer spans+811.569251…812.594212ms, MO delivery+932.269251…933.194212ms, and native getter3+1123.212296…1124.311499ms.

Those ranges remain conditional on equal stable clock rates, valid RPC brackets, quantization and ordinal matching without protocol call IDs. They do not prove a complete family transaction was ready, or isolate renderer/network/application scheduling cause. Lifecycle records are empty: later runtime reconnect loops were never reached. This hybrid arm cannot inherit a zero-instrumentation-effect claim from older/local mode controls. No extra identical getter probe is needed; any root-authorized next control should answer a new scheduling/observation question with the existing modes and unchanged original inputs/deadline.

No browser/test/download/source mutation was performed. Raw hashes and all seven bracket arithmetic are in `brutalist-artifact-review.json`. Partial / ABSTAIN.
