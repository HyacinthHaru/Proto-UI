// Private unexecuted browser-side source. Inline into the existing viewportRing
// callback; do not serialize a Vite-imported function. No product/native hooks.
function installScrollIdentityObserver(viewport, token) {
  const slot = Symbol.for('@proto-ui/private/scroll-identity/R18');
  const unavailable = reason => ({ available: false, reason,
    noteOriginalMeasurement() {}, collect: () => ({ available: false, reason }),
    stop: () => ({ owned: false, stopped: false, reason }) });
  try {
    const existing = Object.getOwnPropertyDescriptor(window, slot);
    if (existing) return existing.value?.token === token ? existing.value.api : unavailable('foreign-owner');
    const scope = viewport.closest('[data-previewer-id]');
    if (!scope || !token) return unavailable('missing-scope-or-token');
    const ids = new WeakMap(), watched = new Set(), viewports = new Set();
    const eventRows = [], mutationRows = [], listeners = [];
    let nextId = 1, current = viewport, stopped = false, observerError = false;
    let children, attributes;
    const counts = { events: 0, mutations: 0, droppedEvents: 0, droppedMutations: 0,
      mutationRecordsSeen: 0, unprocessedMutationRecords: 0, watchedNodesSkipped: 0 };
    const safe = fn => { try { return fn(); } catch { observerError = true; } };
    const id = node => {
      if (!node || (typeof node !== 'object' && typeof node !== 'function')) return null;
      if (!ids.has(node)) ids.set(node, nextId++);
      return ids.get(node);
    };
    // These are identity/attribute reads only: no layout or scroll getters.
    const identity = node => {
      if (!node) return null;
      const el = node.nodeType === 1 ? node : null;
      return { id: id(node), tag: el?.tagName ?? null, parentId: id(node.parentNode),
        connected: node.isConnected ?? null, ref: el?.getAttribute('data-demo-ref') ?? null,
        owner: el?.getAttribute('data-projection-owner') ?? null,
        generation: el?.getAttribute('data-projection-generation') ?? null };
    };
    const push = (kind, detail = {}) => safe(() => {
      if (stopped) return;
      counts.events++;
      if (eventRows.length >= 256) { counts.droppedEvents++; return; }
      eventRows.push({ kind, at: performance.now(), timeOrigin: performance.timeOrigin,
        active: identity(document.activeElement), current: identity(current),
        hasFocus: document.hasFocus(), visibility: document.visibilityState, ...detail });
    });
    const relevant = record => {
      if (watched.has(record.target)) return true;
      if (record.type === 'attributes') return false;
      for (const node of viewports) {
        if (node.contains(record.target)) return true;
        for (const changed of [...record.removedNodes, ...record.addedNodes])
          if (changed === node || changed.contains?.(node)) return true;
      }
      return false;
    };
    const onMutation = records => safe(() => {
      if (stopped) return;
      for (const record of records) {
        counts.mutationRecordsSeen++;
        if (counts.mutationRecordsSeen > 512) { counts.unprocessedMutationRecords++; continue; }
        if (!relevant(record)) continue;
        counts.mutations++;
        if (mutationRows.length >= 128) { counts.droppedMutations++; continue; }
        const added = [...record.addedNodes], removed = [...record.removedNodes];
        mutationRows.push({ type: record.type, deliveredAt: performance.now(),
          target: identity(record.target), attribute: record.attributeName, oldValue: record.oldValue,
          valueAtDelivery: record.type === 'attributes' ? record.target.getAttribute(record.attributeName) : null,
          added: added.slice(0, 16).map(identity), removed: removed.slice(0, 16).map(identity),
          addedOmitted: Math.max(0, added.length - 16), removedOmitted: Math.max(0, removed.length - 16) });
      }
    });
    const watch = node => safe(() => {
      if (stopped || !node) return;
      current = node; viewports.add(node);
      children.observe(scope, { childList: true, subtree: true });
      for (let depth = 0; node && depth < 24; depth++, node = node.parentNode ?? node.host ?? null) {
        if (watched.has(node)) continue;
        if (watched.size >= 96) { counts.watchedNodesSkipped++; break; }
        watched.add(node);
        if (node !== scope) children.observe(node, { childList: true });
        if (node.nodeType === 1) attributes.observe(node, { attributes: true, attributeOldValue: true,
          attributeFilter: ['style', 'class', 'tabindex', 'inert', 'hidden', 'aria-hidden',
            'data-pui-view-pending', 'data-pui-view-detached', 'data-focused', 'data-focus-visible',
            'data-projection-owner', 'data-projection-generation', 'data-projection-state'] });
      }
    });
    const listen = (target, type, fn, capture = false) => {
      target.addEventListener(type, fn, { passive: true, capture }); listeners.push([target, type, fn, capture]);
    };
    const api = {
      available: true,
      noteOriginalMeasurement(node, measurement, phase = null) {
        safe(() => { watch(node); push('original-measurement', { phase,
          originalScrollTop: measurement.scrollTop, originalScrollLeft: measurement.scrollLeft }); });
      },
      collect(outcome) {
        return safe(() => ({ available: true, outcome, collectedAt: performance.now(),
          timeOrigin: performance.timeOrigin, stopped, observerError, counts: { ...counts },
          current: identity(current), globalQuery: identity(document.querySelector('[data-previewer-id] [data-demo-ref="scrollViewport"]')), scopedQuery: identity(scope.querySelector('[data-demo-ref="scrollViewport"]')), eventRows: JSON.parse(JSON.stringify(eventRows)),
          mutationRows: JSON.parse(JSON.stringify(mutationRows)),
          boundary: 'Delivery timestamps; no exact poll-target identity or native-engine attribution.' }))
          ?? { available: false, observerError: true, reason: 'collection-failed' };
      },
      stop() {
        safe(() => children?.disconnect()); safe(() => attributes?.disconnect());
        for (const [target, type, fn, capture] of listeners) safe(() => target.removeEventListener(type, fn, capture));
        stopped = true;
        safe(() => { if (Object.getOwnPropertyDescriptor(window, slot)?.value?.api === api) delete window[slot]; });
        viewports.clear(); watched.clear();
        return { owned: true, stopped, observerError };
      }
    };
    Object.defineProperty(window, slot, { value: { token, api }, configurable: true });
    safe(() => {
      children = new MutationObserver(onMutation); attributes = new MutationObserver(onMutation); watch(viewport);
      for (const type of ['keydown', 'keyup']) listen(document, type, event => safe(() => {
        if (!['ArrowDown', 'ArrowRight', 'Tab'].includes(event.key)) return;
        const detail = { key: event.key, target: identity(event.target),
          path: event.composedPath().slice(0, 16).map(id), trusted: event.isTrusted,
          cancelable: event.cancelable, defaultPrevented: event.defaultPrevented };
        push(type + ':capture', detail);
        queueMicrotask(() => push(type + ':microtask', { ...detail, defaultPrevented: event.defaultPrevented }));
      }), true);
      for (const type of ['focusin', 'focusout']) listen(document, type, event => safe(() =>
        push(type, { target: identity(event.target), related: identity(event.relatedTarget) })), true);
      for (const type of ['focus', 'blur']) listen(window, type, () => push('window:' + type));
      listen(document, 'visibilitychange', () => push('visibilitychange'));
      for (const type of ['scroll', 'scrollend']) listen(document, type, event => safe(() => {
        if (!viewports.has(event.target)) return;
        // Offset reads are limited to actual native scroll delivery.
        push(type, { target: identity(event.target), trusted: event.isTrusted,
          eventTargetScrollTop: event.target.scrollTop, eventTargetScrollLeft: event.target.scrollLeft });
      }), true);
      push('installed');
    });
    return api;
  } catch { return unavailable('installation-failed'); }
}
