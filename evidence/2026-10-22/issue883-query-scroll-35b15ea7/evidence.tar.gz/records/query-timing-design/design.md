# Docs original-request timing observer — private preparation

The local Playwright 1.58.2 JavaScript SDK is in-process. Its client and dispatcher exchange messages through `setImmediate`; this interval must not be called network delay. The actual protocol message ID becomes `call@id`, and the original `Frame._callOnElementOnceMatches` evaluator already receives that ID.

The frozen helper is `docs-call-timing-observer.v1.mjs`, SHA256 `3991e569767cad97315bd36c18464b2430f532e01a8cfc6c3dd31520b8eeeac9`. It is prepared, not executed. `node --check` and static construction of the source-derived evaluator passed. The original selector invocation and original getter callback each occur once in the prepared evaluator. The complete source hashes and exact entry points are in `static-source-guard.json` and `design.json`.

The helper wraps only the selected page's client/server Frame, selector object, actual injected handle, and connection methods. Original poll calls enter `runOriginalQuery(call, read)`; later journey reads have no scope and are ignored. Each browser batch carries the actual call ID and attempt. This avoids assigning four unrelated utility reads to one request by order alone.

Install synchronously after the original `newPage`, before `goto`. Replace only the original read expression with:

```ts
const request = roleTiming.runOriginalQuery(call, () => selector.getAttribute('role'));
```

It returns the original read Promise. Keep the original `traceSearchGetter`, original `.then`/return chain, one-second matcher, inputs, and deadlines. At the original verdict freeze `roleTiming.freezeVerdict(rolePassed)`. Keep observing while the existing post-verdict drain handles the original promises. After the original context really closes, call `disposeAfterContextClosed(true)` and save `snapshot()`. No hook-ready await or extra query is added between navigation and poll.

Node timestamps separate original call, protocol send, driver receipt, server Frame, selector parse/resolve, reply and caller return. Browser timestamps inside the same original evaluate separate selector resolution from the original getter callback. The browser emits one diagnostic batch in `finally`, and the existing server-side console event carries it; no CDP session, extra evaluate, new world, or prototype hook is installed.

The observer has nonzero overhead: AsyncLocalStorage, Promise reactions, timing reads, logging and an enlarged evaluator. `utility.evaluate.dispatch` is SDK method entry, not a CDP wire-send timestamp. Browser execution and Node receipt use different clocks; retain the same-run clock brackets/assumptions. Getter spans bracket the pinned original JavaScript invocation, not an exact C++ engine entry. Equal recorded timestamps mean zero at recorded resolution; no tick length is measured.

Only an actual original failure with usable same-request stages can resolve the present timing question. Zero/missing batches, errors/drops or incomplete cleanup remain evidence debt. The earlier R17 normal controls are not failure evidence. `mappingCompleteAtSnapshot` is computed from actual request/attempt batches; it is not renderer quiescence, C acceptance or formal approval.

No product or SDK source was edited, and no browser, test, build, Actions action, download or external write was performed. Parent edits/runs after this preparation are separate source epochs. Disposition: partial / ABSTAIN.
