(injected, { info, callbackText: callbackText2, taskData: taskData2, callId, root, __puiTiming }) => {
    const __rows = [];
    let __errors = 0;
    const __record = (stage, facts) => {
      try {
        if (__rows.length < 64) __rows.push({ stage, pageMs: globalThis.performance.now(), timeOrigin: globalThis.performance.timeOrigin, dateNow: Date.now(), ...facts });
      } catch { ++__errors; }
    };
    const __flush = () => {
      try { globalThis.console.debug("STATIC_PARSE_ONLY:" + JSON.stringify({ ...__puiTiming, callId, rows: __rows, diagnosticErrors: __errors })); } catch {}
    };
    try {
  
        const callback = injected.eval(callbackText2);
        const element = (() => {
      __record('selector.enter');
      try {
        const selected = injected.querySelector(info.parsed, root || document, info.strict);
        __record('selector.exit', { found: !!selected });
        return selected;
      } catch (error) {
        __record('selector.throw');
        throw error;
      }
    })();
        if (!element)
          return { success: false };
        const log2 = `  locator resolved to ${injected.previewNode(element)}`;
        if (callId)
          injected.markTargetElements(/* @__PURE__ */ new Set([element]), callId);
        return { log: log2, success: true, value: (() => {
      // The pinned callback is exactly element.getAttribute(data.name). This
      // brackets that original invocation, not an instrumented C++ engine entry.
      let getterNative = null;
      try { getterNative = /\[native code\]/.test(Function.prototype.toString.call(element.getAttribute)); } catch { ++__errors; }
      __record('getter.enter', { getterNative });
      try {
        const result = callback(injected, element, taskData2);
        __record('getter.exit', { value: result });
        return result;
      } catch (error) {
        __record('getter.throw');
        throw error;
      }
    })() };
      
    } finally { __flush(); }
}
