(injected, { info, callbackText: callbackText2, taskData: taskData2, callId, root }) => {
        const callback = injected.eval(callbackText2);
        const element = injected.querySelector(info.parsed, root || document, info.strict);
        if (!element)
          return { success: false };
        const log2 = `  locator resolved to ${injected.previewNode(element)}`;
        if (callId)
          injected.markTargetElements(/* @__PURE__ */ new Set([element]), callId);
        return { log: log2, success: true, value: callback(injected, element, taskData2) };
      }
