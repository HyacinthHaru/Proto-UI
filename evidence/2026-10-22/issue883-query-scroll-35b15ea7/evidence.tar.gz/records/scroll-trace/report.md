本轮源码和原证据复核结论为 partial / ABSTAIN；没有已证实的生产源码缺陷可直接据此修复。未运行测试、浏览器、构建或网络采集，未修改 W/E/R17。当前 HEAD 为 bc600/tree5541；读取时 root 正在修改两个 Search evidence 文件，故不称整个工作树 clean。所有选定 Scroll/renderer/owner 源已逐字对齐 bc600 Git blob。

clean bc600 原203项实际202/1，唯一失败是 Controls1472：ArrowDown 后原10秒 scrollTop > focused.scrollTop。两个更早的 f388 私有失败都在 React/dark/top40；第二份有60rows/0drop/0error，7对受信Arrow键，最后ArrowDown2861.900ms、早期keyupRAF2863.900ms、failurecapture12873.700ms。它们没有真实Node identity或document focus连续账本。零intercepted setter/preventDefault只约束那些API和安装后时段，不证明没有移除/重挂或所有程序行为。

规范链仍为 draft：C-AS-SCROLL-SURFACE、C-SCROLL、HC-SCROLL-SURFACE、P-BASE/BRUTALIST-SCROLL-AREA-VIEWPORT 与 asFocusable/FocusTarget。当前Viewport配置both axes与composed，未配置end-follow或Arrow handler；宿主负责physics与原生输入，默认end-follow为off。React绑定具体root el。owner17中press owner仅Enter/Space，不应为未知Arrow失败放开它。现有预览层有retained内容move及focus恢复路径，但同family主题分支不直接move；源码存在此路径不等于失败时执行。

最小下一arm：在原viewportRing RPC内建立WeakMap对象ID；有界记录childList、少量祖先属性、focus/windowblur/visibility和key/scroll。键capture/microtask不读任何offset/client/extent/BCR/computedstyle；实际scroll事件可读其target偏移，原测量仍原样。第一arm原poll callback也不改。pass和fail均保留ledger，避免只在catch采集而再次失去阳性数据；失败后再读完整CSS/geometry/PNG并保留原错误。MO时间为delivery，当前connected不否定中间remove/add。完整判别表和限制在sampling-plan.json。

两次后续instrumented原case各1pass9filtered，没有失败ledger，不是修复。纯DOM两周期虽通过，但dark起点23/4、终点27/13与前一动画在途重叠，不能证明独立fresh-key因果或排除产品。原输入、10秒进度、240秒case、全部geometry/ring断言及owner17保持；不以sleep、强制focus、CSS或scroll写入改绿。
