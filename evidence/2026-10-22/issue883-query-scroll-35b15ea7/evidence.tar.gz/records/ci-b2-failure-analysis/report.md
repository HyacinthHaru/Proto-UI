# B2 Browser1/5/7/8 — bounded canonical read

All four jobs belong to CI39811742474 and source b2c1fa84. Their checkout is synthetic merge366e3ddea7fa5fa634131c34551e117a65cb5d58. Its GitAPI treefc5148ebefb1b959b88afed360ddbd8c78beb71d equals b2 exactly; parents are b928 and b2.

| Job | Actual termination | Browser evidence |
| --- | --- | --- |
| Browser1 /119944383909 | fonts-noto-cjk install hit3-minute step deadline | Browser step skipped;0 browser tests executed |
| Browser5 /119944383820 | same CJK setup timeout | Browser step skipped;0 browser tests executed |
| Browser7 /119944384016 | same CJK setup timeout | Browser step skipped;0 browser tests executed |
| Browser8 /119944383714 | original900s external budget, exit124 | No complete shard summary |

Browser8 completed NativeLinks10/10, BrutalistControls10/10, QuickStart20/20 and Header16/16. Plainnative modifier/middle/Enter and the corresponding Homepage actions actually passed. The Scroll positive uses b2's completion-before-sampling fixture; it does not cover35's later sampling-order correction.

The first completed test failures are LiquidMaterial light/dark, each with `page.waitForFunction: Timeout20000ms`. That file reports1pass/2fail. The exact b2 source narrows this to `quality(value)` at42–51: exactly four regular targets and all qualities equal the expected value. The helper is called repeatedly and no final stack/call index was emitted, so initialself-optical is only the earliest possible invocation. ShadowS1 later enters withHTTP200 but has no terminal file result beforeSIGTERM.

Browser1 did not execute Search/Docs or its collector. Its setup failure cannot be called a getter/role regression or new same-failure timing evidence. No provable new C production defect follows from this bounded subset. No partial totals are presented as whole-shard/wholeCI counts, and no Material/optical owner scope is claimed.

Rawlogs,metadata,fetchreceipts and exact hashes are retained. No media download, browser/test run or external mutation occurred. Disposition: partial / ABSTAIN. Current35 source and its local203 run remain separate.
