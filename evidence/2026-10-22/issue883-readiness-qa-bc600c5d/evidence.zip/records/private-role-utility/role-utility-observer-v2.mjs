import { randomUUID } from 'node:crypto';
import { performance as nodePerformance } from 'node:perf_hooks';

// Private diagnostic only. Starting this work must never gate the original goto or poll.
const utilityPrefix = '__playwright_utility_world_';
const slotName = 'proto-ui.private.role-utility-observation';
const selector = '[data-docs-site-header] [data-adapter-select] [data-site-select-trigger]';

// Serialized into one already-observed utility context; no outer variables are used.
function installInObservedUtility(config) {
  const { ownerToken, bindingName, contextUniqueId, selector, slotName } = config;
  const key = Symbol.for(slotName);
  if (Object.prototype.hasOwnProperty.call(globalThis, key))
    return { available: false, reason: 'observation-slot-already-owned' };
  const prototype = Element.prototype;
  const original = Object.getOwnPropertyDescriptor(prototype, 'getAttribute');
  const matches = prototype.matches;
  const binding = globalThis[bindingName];
  if (!original || typeof original.value !== 'function' || typeof matches !== 'function')
    return { available: false, reason: 'native-descriptor-unavailable' };
  if (typeof binding !== 'function')
    return { available: false, reason: 'binding-not-installed-in-this-context' };
  const native = original.value;
  const apply = Reflect.apply;
  const now = globalThis.performance.now.bind(globalThis.performance);
  const dateNow = Date.now.bind(Date);
  const stringify = JSON.stringify;
  const ids = new WeakMap();
  let serial = 0, totalReads = 0, droppedAtLeast = 0, observerErrors = 0;
  let overflowReported = false;
  const controller = { ownerToken };
  const emit = (data) => {
    try {
      binding(stringify({ ownerToken, contextUniqueId, observerErrors, ...data }));
    } catch { observerErrors++; }
  };
  const textError = (error) => {
    try { return String(error); } catch { return 'diagnostic error could not be stringified'; }
  };
  const read = (node, attribute) => apply(native, node, [attribute]);
  const targetFacts = (target) => {
    if (!ids.has(target)) ids.set(target, ++serial);
    let owner = target;
    let ownerFacts = null;
    for (let depth = 0; owner && depth < 8; depth++, owner = owner.parentElement) {
      const hostOwner = read(owner, 'data-projection-owner-host');
      const viewOwner = read(owner, 'data-projection-owner');
      if (hostOwner !== null || viewOwner !== null) {
        ownerFacts = { depth, hostOwner, viewOwner,
          generationHost: read(owner, 'data-projection-generation-host'),
          generation: read(owner, 'data-projection-generation') };
        break;
      }
    }
    return { ref: ids.get(target), tag: target.tagName, id: read(target, 'id'),
      connected: target.isConnected, owner: ownerFacts };
  };
  const observed = {
    getAttribute(name) {
      // No argument coercion: the original native call receives exactly this/arguments once.
      let matching = false, beforeMs = null, beforeDateMs = null;
      try {
        matching = name === 'role' && apply(matches, this, [selector]);
        if (matching) { beforeMs = now(); beforeDateMs = dateNow(); }
      } catch { observerErrors++; }
      let value, originalError, threw = false;
      try { value = apply(native, this, arguments); }
      catch (error) { threw = true; originalError = error; }
      try {
        if (matching) {
          const afterMs = now(), afterDateMs = dateNow();
          totalReads++;
          if (totalReads <= 64) {
            emit({ kind: 'read', ordinal: totalReads, timeOrigin: globalThis.performance.timeOrigin,
              beforeMs, afterMs, beforeDateMs, afterDateMs,
              outcome: threw ? 'threw' : 'returned',
              ...(threw ? { error: textError(originalError) } : { value }),
              target: targetFacts(this),
              slotStillOwned: Object.getOwnPropertyDescriptor(globalThis, key)?.value === controller,
              wrapperStillOwned: Object.getOwnPropertyDescriptor(prototype, 'getAttribute')?.value === observed });
          } else {
            droppedAtLeast++;
            if (!overflowReported) {
              overflowReported = true;
              emit({ kind: 'overflow', totalReadsAtLeast: totalReads, droppedReadsAtLeast: droppedAtLeast,
                exactFinalDropCount: false });
            }
          }
        }
      } catch { observerErrors++; }
      if (threw) throw originalError;
      return value;
    }
  }.getAttribute;
  try {
    Object.defineProperty(globalThis, key, { configurable: true, value: controller });
    Object.defineProperty(prototype, 'getAttribute', { ...original, value: observed });
  } catch (error) {
    if (Object.getOwnPropertyDescriptor(globalThis, key)?.value === controller) delete globalThis[key];
    return { available: false, reason: 'install-failed', error: textError(error) };
  }
  const facts = { available: true, timeOrigin: globalThis.performance.timeOrigin, installedMs: now(),
    installedDateMs: dateNow(), observerErrors,
    descriptor: { configurable: original.configurable, enumerable: original.enumerable, writable: original.writable },
    nativeFunctionSource: Function.prototype.toString.call(native) };
  emit({ kind: 'installed', ...facts });
  return facts;
}

export function roleUtilityInstallExpression(config) {
  return `(${installInObservedUtility.toString()})(${JSON.stringify(config)})`;
}

/** Start before the original goto, without awaiting this diagnostic or its installation. */
export function startRoleUtilityReadObservation(page) {
  const ownerToken = randomUUID();
  const bindingName = `__pui_role_read_${ownerToken.replaceAll('-', '')}`;
  const records = new Map();
  const report = {
    kind: 'private-role-utility-observation', executionStatus: 'started-not-yet-observed',
    nodeTimeOrigin: nodePerformance.timeOrigin, startedNodeMs: nodePerformance.now(),
    selector, captureCap: 64, contexts: [], rows: [], queries: [], verdicts: [], errors: [],
    errorCount: 0, ignoredBindingEvents: 0, contextCapExceeded: false, queryDrops: 0,
    rowDropsAtLeast: 0, exactFinalDropCount: false, observerErrorsReportedAtLeast: 0,
    prototypeRestorationAttempted: false, prototypeRestored: false,
    transportComplete: false, oneToOneQueryMappingProved: false,
  };
  let session, mainFrameId, utilityName, bindingStarted = false, bindingReady = false, stopped = false;
  const error = (phase, value) => {
    report.errorCount++;
    if (report.errors.length < 8) {
      let message;
      try { message = String(value); } catch { message = 'diagnostic error could not be stringified'; }
      report.errors.push({ phase, message, nodeMs: nodePerformance.now() });
    }
  };
  const candidates = () => [...records.values()].filter((c) =>
    c.active && c.frameId === mainFrameId && c.name.startsWith(utilityPrefix) &&
    c.name.length > utilityPrefix.length && c.isDefault === false);
  const install = (context) => {
    if (stopped || !bindingReady || context.install || !context.active) return;
    context.install = { nodeStartedMs: nodePerformance.now(), acknowledged: false };
    // This command races normally with navigation/query work. It is never awaited by the caller.
    void session.send('Runtime.evaluate', {
      expression: roleUtilityInstallExpression({ ownerToken, bindingName,
        contextUniqueId: context.uniqueId, selector, slotName }),
      uniqueContextId: context.uniqueId, returnByValue: true, silent: true,
    }).then((result) => {
      if (stopped) return;
      context.install.nodeAckMs = nodePerformance.now();
      context.install.acknowledged = true;
      context.install.exceptionDetails = result.exceptionDetails ?? null;
      context.install.facts = result.result.value ?? null;
      if (result.exceptionDetails)
        error('install-exception', result.result.description ?? result.exceptionDetails.text);
    }).catch((reason) => { if (!stopped) error('install', reason); });
  };
  const consider = () => {
    if (stopped || !session || !mainFrameId) return;
    const current = candidates();
    if (current.length !== 1) { report.lastCandidateCount = current.length; return; }
    const context = current[0];
    if (utilityName && context.name !== utilityName) { error('utility-name-changed', context.name); return; }
    if (!utilityName) utilityName = context.name; // Only the observed full name, never an invented world.
    if (!bindingStarted) {
      bindingStarted = true;
      report.binding = { name: bindingName, executionContextName: utilityName, nodeStartedMs: nodePerformance.now() };
      void session.send('Runtime.addBinding', { name: bindingName, executionContextName: utilityName })
        .then(() => {
          if (stopped) return;
          bindingReady = true; report.binding.nodeAckMs = nodePerformance.now(); consider();
        }).catch((reason) => { if (!stopped) error('add-binding', reason); });
    } else if (bindingReady) install(context);
  };
  const onCreated = ({ context }) => {
    if (stopped || typeof context?.uniqueId !== 'string' || !context.uniqueId ||
        !context.name?.startsWith(utilityPrefix) || context.auxData?.isDefault !== false) return;
    if (records.has(context.uniqueId)) return;
    if (records.size >= 16) { report.contextCapExceeded = true; return; }
    const row = { id: context.id, uniqueId: context.uniqueId, name: context.name,
      origin: context.origin, frameId: context.auxData?.frameId, isDefault: context.auxData?.isDefault,
      createdNodeMs: nodePerformance.now(), active: true };
    records.set(row.uniqueId, row); report.contexts.push(row); consider();
  };
  const onDestroyed = ({ executionContextId, executionContextUniqueId }) => {
    if (stopped) return;
    for (const context of records.values()) {
      if (context.id === executionContextId && (!executionContextUniqueId || context.uniqueId === executionContextUniqueId)) {
        context.active = false; context.destroyedNodeMs = nodePerformance.now();
      }
    }
  };
  const onCleared = () => {
    if (stopped) return;
    for (const context of records.values()) { context.active = false; context.clearedNodeMs = nodePerformance.now(); }
  };
  const onBinding = (event) => {
    if (stopped || event.name !== bindingName) return;
    try {
      const value = JSON.parse(event.payload);
      const context = records.get(value.contextUniqueId);
      if (value.ownerToken !== ownerToken || !context || context.id !== event.executionContextId ||
          context.frameId !== mainFrameId || context.name !== utilityName) {
        report.ignoredBindingEvents++; return;
      }
      const receivedNodeMs = nodePerformance.now(), receivedNodeDateMs = Date.now();
      report.observerErrorsReportedAtLeast = Math.max(report.observerErrorsReportedAtLeast, value.observerErrors ?? 0);
      if (value.kind === 'installed') {
        context.installedBinding = { receivedNodeMs, receivedNodeDateMs, facts: value };
      } else if (value.kind === 'overflow') {
        report.rowDropsAtLeast = Math.max(report.rowDropsAtLeast, value.droppedReadsAtLeast);
      } else if (value.kind === 'read') {
        if (report.rows.length < 64) report.rows.push({ ...value, executionContextId: event.executionContextId,
          contextActiveAtDelivery: context.active, receivedNodeMs, receivedNodeDateMs });
        else report.rowDropsAtLeast++;
      }
    } catch (reason) { error('binding-delivery', reason); }
  };
  void (async () => {
    session = await page.context().newCDPSession(page);
    if (stopped) return;
    session.on('Runtime.executionContextCreated', onCreated);
    session.on('Runtime.executionContextDestroyed', onDestroyed);
    session.on('Runtime.executionContextsCleared', onCleared);
    session.on('Runtime.bindingCalled', onBinding);
    report.runtimeEnableStartedMs = nodePerformance.now();
    await session.send('Runtime.enable');
    if (stopped) return;
    report.runtimeEnableAckMs = nodePerformance.now();
    report.frameTreeStartedMs = nodePerformance.now();
    const { frameTree } = await session.send('Page.getFrameTree');
    if (stopped) return;
    report.frameTreeAckMs = nodePerformance.now();
    report.mainFrame = { id: frameTree.frame.id, url: frameTree.frame.url, loaderId: frameTree.frame.loaderId };
    mainFrameId = frameTree.frame.id;
    consider();
  })().catch((reason) => { if (!stopped) error('setup', reason); });

  return {
    noteOriginalQuery(call) {
      try {
        const nodeMs = nodePerformance.now(), current = candidates();
        const context = current.length === 1 ? current[0] : null;
        const install = context?.install;
        const row = { call, nodeMs, nodeDateMs: Date.now(), contextUniqueId: context?.uniqueId ?? null,
          installAckBeforeQuery: !!(install?.acknowledged && install.facts?.available && install.nodeAckMs <= nodeMs),
          bindingInstallMessageBeforeQuery: !!(context?.installedBinding && context.installedBinding.receivedNodeMs <= nodeMs) };
        if (report.queries.length < 64) report.queries.push(row); else report.queryDrops++;
      } catch (reason) { error('note-query', reason); }
    },
    noteVerdict(passed) {
      try { if (report.verdicts.length < 4) report.verdicts.push({ passed, nodeMs: nodePerformance.now(), nodeDateMs: Date.now() }); }
      catch (reason) { error('note-verdict', reason); }
    },
    finishAfterContextClosed(contextCloseSucceeded) {
      // No Runtime.evaluate, pending-query drain, restore or other RPC after the original close.
      stopped = true;
      report.finishedNodeMs = nodePerformance.now();
      report.contextCloseSucceeded = contextCloseSucceeded;
      try { report.pageClosed = page.isClosed(); } catch (reason) { error('page-closed-read', reason); }
      try {
        session?.off('Runtime.executionContextCreated', onCreated);
        session?.off('Runtime.executionContextDestroyed', onDestroyed);
        session?.off('Runtime.executionContextsCleared', onCleared);
        session?.off('Runtime.bindingCalled', onBinding);
        report.nodeListenersRemoved = true;
      } catch (reason) { error('remove-listeners', reason); report.nodeListenersRemoved = false; }
      report.sessionDetachRequested = false;
      report.sessionBoundary = 'Original context.close owns target retirement; no separate session-detach or prototype-restoration acknowledgement is claimed.';
      report.executionStatus = 'capture-ended';
      report.captureAvailable = report.rows.length > 0;
      report.ackBeforeEveryRecordedQuery = report.queries.length > 0 && report.queries.every((q) => q.installAckBeforeQuery);
      report.evidenceDebt = [];
      if (!report.mainFrame) report.evidenceDebt.push('main-frame-not-observed');
      if (!report.rows.length) report.evidenceDebt.push('zero-matching-reads');
      if (!report.ackBeforeEveryRecordedQuery) report.evidenceDebt.push('install-ack-not-proved-before-every-original-query');
      if (report.contextCapExceeded || report.queryDrops || report.rowDropsAtLeast) report.evidenceDebt.push('bounded-capture-truncated');
      if (report.errorCount || report.observerErrorsReportedAtLeast) report.evidenceDebt.push('diagnostic-error-reported');
      if (!contextCloseSucceeded || !report.pageClosed) report.evidenceDebt.push('context-retirement-not-confirmed');
      return JSON.parse(JSON.stringify(report));
    },
  };
}
