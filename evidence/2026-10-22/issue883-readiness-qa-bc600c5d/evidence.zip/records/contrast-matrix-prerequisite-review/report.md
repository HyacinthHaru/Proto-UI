# Contrast matrix 覆盖登记前置复核

结论：把已存在的`input`加入既有`passive-and-editors` CSV，可作为当前C Dialog/Select/Portal QA共同校准前置的最小修复；这是登记遗漏恢复，不是新family实现或任务认领。Partial / ABSTAIN，不是批准。

原manifest实际22个family，matrix21个、无重复，唯一缺input。原contrast-audit-plan.test.mjs94要求全manifestexactonce，并保留fail-fast=false/max-parallel2等配置。每个matrixjob都先跑此全局校准，之后才跑nativejourneys。建议仅31行增加`input,`，其余权限contents:read、45分钟、所有assertions与顺序不变。

但有一个必须披露的现有coverage gap：audit-brutalist-contrast.mts的primary()没有inputselector，input也不是passive。它的plannedstates是rest/hover/keyboard-focus；若执行至rest后，会按2366原guard报`input: no planned physical target; unsupported interaction coverage`。因此单CSV修复可解除共同校准阻挡，不能称Inputcontrastjourney已经支持或所有shard会绿。不得把input塞入passive、放宽guard或用FieldControl替代。

Input产品和route确已存在：manifest859绑定P-BASE-INPUT/demo-brutalist-input/brutalist-input-root；英文原页面显式引用该recipe，recipe有editable、disabled、readOnly三实例。P-BRUTALIST-INPUT仍draft、Base-owned单editor，浏览器/Compiler/原生接受仍待独立证据。源引入commit9ba2c0d1fe707ddddf53456bbbc3f1f741f0b72d已是mainb928祖先；这只证明源历史，不借此捏造旧实际运行。

小diff提议见suggested-registration-only.patch，未apply。缺selector应作为单独真实覆盖边界留给当前owner/后续有界评估；不因它而删掉本来必须登记的family，也不为登记顺手实现family。此修复不涉及78catalog分类或Compiler/CLI/API。没有运行测试、CI、browser或修改产品。
