# Brutalist Tabs 选择状态 reader scope 复核

Partial / ABSTAIN。静态源码支持存在Runtime picker污染的可能；尚无本审查新增DOM证据，不能把scope提议当成原CI根因。

原case747–752对整个document查询`[data-previewer-id] [role="tab"]:nth-of-type(2)`，而Details点击来自所选previewer。当前projected-previewer-client明确runtime presentation=tabs，projection-composition生成同family真实Tabs controls，放在contentNode之前。`nth-of-type`按各父节点下元素类型计数，不能把它当成演示第二个tab。legacy runtime-tabs.ts仅是另一条embed路径，不拿它替代当前投射源码。

官方BrutalistTabs recipe确有Overview/Details两个相同prototype的trigger、defaultoverview，value分别overview/details；没有额外显式triggerref。现有Root几何读取和browser-harness readiness已经用`[data-projection-content] .pui-runtime-preview-surface[data-demo-ref="__website_runtime_preview_surface__"]`，且helper要求该surface内恰2个tab。因此给原selector加同scope是当前合理最小建议；原Details click、nth-of-type(2)、aria-selected谓词、0.5px x/width几何、默认wait deadline和90scase均保持。

注意该原case的RUNTIMES仅wc/react/vue三种，不是四种。source-only提议已保存为suggested-scope-only.patch，未apply。根的failureDOM还需确认originalquery节点是否是runtimecontrol、Details是否已selected、scopedquery是否指向该同一Details。若出现多previewer/多livegeneration等不同事实，再据实际owner做更窄处理，不先添加宽松fallback。

全部绑定取d67 Git对象，不借根可能正在执行的私有observer源码；未运行浏览器、测试、CI或外部写。
