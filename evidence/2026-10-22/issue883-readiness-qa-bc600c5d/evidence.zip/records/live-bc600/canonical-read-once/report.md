# bc600 package CI — bounded read

[Main CI39788572923](https://github.com/Proto-UI/Proto-UI/actions/runs/39788572923) was **in progress** at the single run/jobs read. The complete page contained **21 materialized jobs:13 success,1 failure and7 in progress**. The seven running jobs were browser shards; browser6 had success metadata, and General had failure metadata. This review does not infer their runtime counts or General's cause and does not fill an expected22-job total.

[Package job119858274482](https://github.com/Proto-UI/Proto-UI/actions/runs/39788572923/job/119858274482) had completed successfully. Its actual checkout is **39d611432551b9bd46d6254df63a7672c024affd**. The Git API object binds tree **5541cbe423f6c64ea09f64057077cec649049e5d**, exactly bc600, with b928/bc600 parents.

The original changed-from-b928 command emitted47 distinct per-package build rows and **47/47 public packages complete**. It checked **47 public manifests**. The package-budget policy controls were **9/9 passed**. These numbers are read from this job, not copied from earlier selected builds.

The nine whole-entry measurements are **4 within strict ceilings and5 strictly over**, with the latter reported as advisory by the explicit `--finf-development` mode:

| Entry | Gzip bytes | Strict limit | Excess | Reported disposition |
| --- | ---: | ---: | ---: | --- |
| lucide/icons/x | 1,737 | 3,000 | 0 | PASS |
| lucide root | 635,749 | 700,000 | 0 | PASS |
| core root | 8,940 | 7,600 | 1,340 | ADVISORY |
| runtime root | 90,651 | 78,500 | 12,151 | ADVISORY |
| adapter-react root | 143,381 | 106,000 | 37,381 | ADVISORY |
| adapter-vue root | 142,838 | 106,000 | 36,838 | ADVISORY |
| adapter-web-component root | 170,063 | 132,000 | 38,063 | ADVISORY |
| prototypes-base/button | 3,948 | 6,000 | 0 | PASS |
| prototypes-shadcn/button | 4,952 | 7,000 | 0 | PASS |

Toolchain recorded by the actual budget command: **Node24.22.0, zlib1.3.2.1-motley-285e94b, esbuild0.25.12, Linux x64**; installation used pnpm10.32.1 and the frozen lockfile. Raw minified byte counts and SHA values are retained in `report.json`.

The active policy scope is the existing nine Finf entries. Its stored ledger reports5/68 completions and explicitly says completion is not acceptance. Advisory exit treatment does not make the five strict overages pass, change any ceiling, waive invalid measurements/build errors, or establish runtime/native acceptance.

Run/jobs/log/Git-object reads have separate timestamps in `read-receipt.json` and `checkout-binding.json`; the main-run status is not silently refreshed by the later tree lookup. No tests, browser, Actions mutation, source/E edit, media download or external comment occurred. No second poll follows. **Partial / ABSTAIN.**
