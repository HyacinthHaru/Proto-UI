import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile, access } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { launchBrowser } from '<PRODUCT_ROOT>/apps/www/src/content/docs/zh-cn/browser-harness.ts';

const output = process.argv[2];
if (!output || !process.env.CHROME_PATH) throw new Error('Usage: CHROME_PATH=<exact browser> node --import tsx driver.mts <new output directory>');
const out = resolve(output);
try { await access(out); throw new Error(`Output exists: ${out}`); } catch (error) { if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error; }
await mkdir(out, { recursive: true });
const html = await readFile(new URL('./control.html', import.meta.url), 'utf8');
const report: any = { startedAt: new Date().toISOString(), kind: 'plain-DOM native keyboard scroll discriminator',
  node: process.version, platform: process.platform, arch: process.arch, chromePath: process.env.CHROME_PATH,
  htmlSHA256: createHash('sha256').update(html).digest('hex'),
  driverSHA256: createHash('sha256').update(await readFile(new URL(import.meta.url))).digest('hex'),
  cycles: [], pageErrors: [], cleanupErrors: [], operations: [], contextClosed: false, browserClosed: false,
  boundary: 'No product page, renderer, Proto owner, JS scrolling, synthetic key events, preventDefault or scroll setter interception. CSS scrollbar-width:none matches the composed host policy. Absolute plain layout omits product ancestors, document scroll and toolbar. A pass or fail is not product acceptance or a universal browser conclusion.' };
let browser: Awaited<ReturnType<typeof launchBrowser>> | undefined;
let context: Awaited<ReturnType<NonNullable<typeof browser>['newContext']>> | undefined;
let failed = false;
let originalFailure: unknown;
try {
  browser = await launchBrowser();
  report.browser = browser.version();
  context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();
  page.on('pageerror', error => report.pageErrors.push(String(error)));
  await page.setContent(html, { waitUntil: 'load' });
  const facts = () => page.evaluate(() => {
    const v = document.getElementById('viewport')!;
    const rect = v.getBoundingClientRect(), s = getComputedStyle(v);
    return { epoch: Date.now(), at: performance.now(), timeOrigin: performance.timeOrigin,
      hasFocus: document.hasFocus(), visibility: document.visibilityState,
      active: document.activeElement?.id ?? document.activeElement?.nodeName,
      nativeFocusVisible: v.matches(':focus-visible'), top: v.scrollTop, left: v.scrollLeft,
      clientWidth: v.clientWidth, clientHeight: v.clientHeight, scrollWidth: v.scrollWidth, scrollHeight: v.scrollHeight,
      maxTop: v.scrollHeight-v.clientHeight, maxLeft: v.scrollWidth-v.clientWidth,
      rect: {x:rect.x,y:rect.y,width:rect.width,height:rect.height}, direction:s.direction,
      overflowX:s.overflowX,overflowY:s.overflowY,scrollBehavior:s.scrollBehavior,scrollbarWidth:s.scrollbarWidth,
      viewport:{width:innerWidth,height:innerHeight}, language:navigator.language,
      timezone:Intl.DateTimeFormat().resolvedOptions().timeZone, tape:(window as any).__plainScrollTape };
  });
  const waitGreater = (property: 'scrollTop'|'scrollLeft', previous: number) => page.waitForFunction(
    ({ property, previous }) => ((document.getElementById('viewport') as HTMLElement | null)?.[property] ?? 0) > previous,
    { property, previous }, { timeout: 10_000 }
  );
  report.initial = await facts();
  assert.deepEqual([report.initial.clientWidth,report.initial.clientHeight,report.initial.scrollWidth,report.initial.scrollHeight],[316,188,532,528], 'Exact plain control geometry precondition');
  for (const theme of ['light','dark'] as const) {
    const cycle: any = { theme, phase:'theme-and-focus' }; report.cycles.push(cycle);
    try {
      await page.emulateMedia({ colorScheme: theme });
      await page.mouse.click(5,5);
      await page.keyboard.press('Tab');
      await page.waitForFunction(() => document.activeElement === document.getElementById('viewport') && document.getElementById('viewport')!.matches(':focus-visible'), undefined, { timeout:10_000 });
      const focused = await facts(); cycle.before = focused;
      cycle.phase='ArrowDown'; report.operations.push({key:'ArrowDown',phase:'issued',epoch:Date.now(),at:performance.now()});
      await page.keyboard.press('ArrowDown');
      await waitGreater('scrollTop',focused.top);
      cycle.phase='ArrowRight'; report.operations.push({key:'ArrowRight',phase:'issued',epoch:Date.now(),at:performance.now()});
      await page.keyboard.press('ArrowRight');
      await waitGreater('scrollLeft',focused.left);
      cycle.after = await facts(); cycle.phase='passed';
      await page.mouse.click(5,5);
    } catch(error) {
      cycle.error=String(error); cycle.stack=error instanceof Error ? error.stack : null;
      try { cycle.afterFailure=await facts(); } catch(captureError) {cycle.captureError=String(captureError);}
      try { await page.screenshot({path:resolve(out,'failure.png')}); } catch(captureError) {cycle.screenshotError=String(captureError);}
      throw error;
    }
  }
  report.final=await facts(); report.result='passed';
} catch(error) { failed=true;originalFailure=error;report.result='failed';report.error=String(error); }
finally {
  try { if(context){await context.close();report.contextClosed=true;} } catch(error){report.cleanupErrors.push(String(error));}
  try { if(browser){await browser.close();report.browserClosed=true;} } catch(error){report.cleanupErrors.push(String(error));}
  report.finishedAt=new Date().toISOString();
  try { await writeFile(resolve(out,'report.json'),JSON.stringify(report,null,2)+'\n'); } catch(error){if(!failed){failed=true;originalFailure=error;}}
}
if(failed) throw originalFailure;
if(report.cleanupErrors.length) throw new Error(report.cleanupErrors.join('\n'));
console.log(JSON.stringify({result:report.result,browser:report.browser,cycles:report.cycles.map((c:any)=>({theme:c.theme,phase:c.phase,before:[c.before?.top,c.before?.left],after:[c.after?.top,c.after?.left]})),contextClosed:report.contextClosed,browserClosed:report.browserClosed}));
