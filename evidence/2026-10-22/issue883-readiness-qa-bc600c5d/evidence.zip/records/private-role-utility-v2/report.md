# Utility V2 and Dropdown24 — bounded reconciliation

**No new concrete finding; partial / ABSTAIN.** This agent authored the private helper, so this is raw/source/arithmetic reconciliation rather than formal independent approval. No new browser, tests or product edits were performed for this review.

V1 remains retained: both originalDocs cases passed, but hook installation failed with the Vite `__vite_ssr_import_1__` ReferenceError and captured0rows. V2 fixes browserclock references to `globalThis.performance`, aliases the Nodeclock import, and counts installation exceptionDetails as diagnostic errors. V2 actually ran **13:31:48–13:32:05 UTC**, physical `bc600c5d` plus the private probe: **2 passed /28 filtered**, sourceStable/exit0. HelperSHA `860ea66b…`, probeSHA `9ce6e0fb…`, originalSHA `c801d34f…`; the original source was restored.

Both realmain-frame utilitycontexts installed before the originalNode query. Each captured4 matchingrole reads and1 originalNode query, allreturning `combobox`, with0 reportederrors/drops and matchingwrapper/slot ownership. Only the first row is within the initialquery/verdict interval; three laterrows occur during the restof thejourney. There is no protocolrequest ID and no one-to-one mapping claim.

| Case | Install ACK lead before Node query | Conditional firstgetter after Node query | Sampled nativegetter span | Node binding delivery after query |
| --- | ---: | ---: | ---: | ---: |
| brutalist | 1139.817 ms | 22.779–23.583 ms | 0.000 ms | 23.848 ms |
| shadcn | 1167.998 ms | 171.625–174.402 ms | 0.200 ms | 174.169 ms |

The getter interval uses the single install send/browser-sample/ACK bracket, assuming approximately equal clock rate and constant offset over the short interval. Epoch-origin point estimates alone are less defensible. Binding delivery is not getter execution; neither figure isolates network, selector-resolution or rendererqueue time. A measured0ms means equal sampled timestamps, not zero CPU cost. These localpositive captures do not explain the historicalCI failures.

Actualcontext.close succeeded, pageclosed and listener-removal flags are true. No prototype restoration was attempted; no transport completeness, session-detach ACK or quiescence is claimed. Backgroundsetup was not awaited, and its recordedframe URLs already name the targetDocspages. The method therefore does not claim setup completed beforegoto; the actual ACK-before-query comparison is the relevant evidence. The probe has nonzeroCDP/wrapper/bookkeeping cost.

ForDropdown, a read-onlyAST traversal finds **24** authored `kind=proto` descendants: Root1,Trigger1,Content1,Group3,Label1,Item9,Shortcut5,Separator3. The old8f1c recipe had5; the accepted991cc/mainb928/f388 recipe already has24 with identical bytes. The actualWC postfailure snapshot shows ready/active/committedWC, no startup shell, one surface, no roots outside it, and exactly24 descendants with the same identity multiset. This is a stalefixture premise, not a newfamily definition.

Commit `0f66e9d713411a85c1a46cf87ac8ae4158614e59` changes only the existing expectedCount5→24. Removing that one replacement recovers all otherfilebytes, including original20s readiness,90s case, geometry tolerance andhover/press expectations. The actualprecommit originalcase passed1/9filtered and traverses WC/React/Vue; it is not3tests orVue2 admission. The reservedRuntimeBox boundary andtoolbar are excluded fromthe descendant count. ApplicableDropdown P/T entities remain draft; the2026-10-10 website-admission record is contextual, not normative.

Exact source/rawSHA bindings and timings are in `report.json`; static per-node counts are in `dropdown-source-count.json`. No furtherprobe orsource design is proposed here.
