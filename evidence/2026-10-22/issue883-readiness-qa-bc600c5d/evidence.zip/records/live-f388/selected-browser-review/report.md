# f388 Browser1/8 — bounded terminal-log review

Both requested original logs were downloaded once and bind to synthetic checkout **efd79cdb05717f0c439a2aa150bef8bfaef588cf**. The actual Git API object has tree **9d9a4ff1b994967d398896534e9dae33a519beae**, exactly f388, and parents b928/f388. This is not the earlier b66f PR merge metadata and is not current bc600 execution.

The provided complete snapshot records main CI39781130610 **22 jobs,13 success/9 failure**. Browser1 and8 both exited **124 without a full summary**. Completed-file outcomes below are not added into shard or all-eight totals.

- Browser1: Search30 completed **21 pass/9 fail**. Four Shadcn initial-readiness failures first entered the browser at+1093,+1307,+1097,+1450ms, after the original1s deadline, with commandCount0 at that first sample. These readings do not describe the earlier unobserved interval.
- Its five Docs role failures are all Shadcn widths320/390/1280/1440/2048. Each froze one originalPromise pending. All five later batches observed `combobox`, with post-verdict drain durations approximately94.172,82.976,322.333,320.966,374.776ms. There were no reported observer errors, drops or budget expiries; the original failures stayed failures. All five Brutalist Docs cases passed. No utility-world getter execution timestamps were collected by this canonical observer.
- Browser8: Brutalist controls10 completed **9 pass/1 fail**. **The original Tabs bounds case is explicitly passed** (log505). The remaining Dropdown failure is its original20s runtime-readiness wait. This head still expected5; the later exact24 correction is a different source epoch.
- Header16/16 and NativeLinks10/10 are explicit completed-file positives. Portal55 is54/1, with the sole css-zoom diagnostic red; home-runtime11 is10/1 with the React dark-style predicate red. Material3 is1/2 with20s timeouts. Missing final stacks do not establish new production/optical causes.
- Dialog reader is included in the shard1 selection but has no completed case/file output before124. This review reports neither canonical pass nor failure for it.

The f388 snapshot's V2 and Popup are inspected only as metadata. V2 failed its two continuous steps. Popup calibration is successful and its actual observation step failed, so it is no longer the prior pre-calibration missing-input gap. No raw predicate or counts are invented for either; their large logs were not fetched in this task.

`docs-role-extract.json` retains actual JSON objects and log line numbers; `report.json` binds all raw/source hashes. The local private utility V2 two-case capture, current bc600 validations and old d67 public packet remain separate. No tests/browser/source changes/Actions mutations/media download or fresh live poll occurred. **Partial / ABSTAIN.**
