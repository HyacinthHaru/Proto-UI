Search观测v2：SEARCH-OBS-FINALLY-001 已关闭，0 open finding，partial/ABSTAIN。

仅finally记录块加nonthrowingtry/catch，原poll仍在外层，不catch或替换原异常，不增加等待/第二I/O。真实sourceblock注入控制4臂保留：v1成功/失败都被记录error覆盖；v2失败保留同一matcher对象、成功继续成功。这是明确故障注入，不是声称真实Vitest/Browser发生过该故障。

helper相对v1仅新样本字段expired→timerSample，原expired参数/1000ms/判据未动；unit全文等v1。Docs wrapper替回原poll行可全文恢复原8bfea文件。复用traceSearchGetter仍是.then新Promise，不称同identity/零干扰。

实际v2两文件unit129pass、types937/0error/0warning/14hint，before/aftercensus等且三个reviewSHA吻合。均为precommit8bfea+4dirty来源（另一个Startupfixture不纳本审查），不冒新head或hosted通过。v1local30pass不套v2，也不抹hosted20/10红。原v1report/finding保留。

精确3hash、原件与控制边界见report.json；本review无新运行或外写。
