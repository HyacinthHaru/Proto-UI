Search观测v1静态审查：partial/ABSTAIN。

P3 SEARCH-OBS-FINALLY-001：Docs原poll之后finally里的记录块未隔离，记录侧抛错可能替代原verdict。仅记录块nonthrowing即可，不catch原poll、不加等待或fallback。当前原生9778仍运行，未声称此路径实际发生。

三个source SHA及保存原件/patch见JSON。原commands文件替回唯一poll行可全文恢复；原unit完整前缀不变。原1000ms/onTime/所有后续输入不变，无新DOM查询/RPC；序列化函数无新runtime外部引用。新增样本有计时/分配开销，复用traceSearchGetter仍返回.then新Promise，不称同identity/零干扰。expired仅原timer参数，不是按deadline算的过期状态，建议字段明确timerSample。

等待root终态后v2最小修正，不编辑当前运行源码、不新增测试。
