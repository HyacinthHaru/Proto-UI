# Startup Runtime label candidate peer review

**No specific source finding; partial / ABSTAIN.** The candidate changes only the obsolete target, labels the text-range measurement, records the separate control height, and adds a positive-height check. Reconstructing the original with these four declared replacements produces the exact candidate bytes; all remaining bytes, original text poll, numeric tolerances, width condition and90s case timeout match.

- Original SHA: `4a77c0e2d4fcff82faec2c689a14618b8e265ee8b65d5482cf26c50400ba8206`.
- Candidate SHA: `845f4a5ff91bfccb780f47eeff00ada440d0db75cd859de1e0408015a9eb6181`, matching the reviewed worktree file.
- `runtimeSelectTrigger(first previewer)` retains the helper's strict result; no trailing `.first()` masks ambiguity. Existing Tabs markers prohibit legacy fallback.
- Both checks use the same `facts.height` Range result: new `>0` applies at every width, while original `<= lineHeight+1` remains conditional on `!baseline && width!==320`. The original width/scrollWidth condition remains in that same branch. At320 the upper/overflow predicates were not executed, even though the recorded values happen to satisfy them.

Both actual arms served the same complete8bfea production artifact12411107426 at the same local origin, with Chrome145.0.7632.6. The ZIP SHA matches `2bca18d…e4d6`; its extraction receipt lists3,837 files/104,068,215 bytes and the original default admission log records1pass/0skip. This is a readback of admission evidence, not an additional admission execution or a new artifact produced by the test edit.

Original clean8bfea selected2048 failed after the original30s locator wait:1fail/26filtered; no metric record was reached. Candidate execution at8bfea+one dirty test was source-stable and passed all four selected widths:4pass/23filtered. Each record contains `Web Components`, rendered text height18, actual Tab controlHeight34, lineHeight24, control width132.203125 and scrollWidth132. The control's legitimate padding/border is therefore retained as separate evidence rather than mistaken for line wrapping. Original assertions and time limits were not relaxed.

The four PNG file hashes match the sidecars, but this reviewer did not inspect their pixels. The remaining23 cases were filtered, and the later three Search diagnostic files are outside this review. No whole27-case, newcommit, canonical browser, AT or full-page acceptance follows. The reviewer participated in the proposal; this is a bounded peer review, not formal independent approval. No tests, browser, source edits, download or external write were performed.
