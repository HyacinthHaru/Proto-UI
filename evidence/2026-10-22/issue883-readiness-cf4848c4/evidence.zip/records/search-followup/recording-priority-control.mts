import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import ts from '<PRODUCT_ROOT>/node_modules/typescript/lib/typescript.js';
import { traceSearchGetter } from '<PRODUCT_ROOT>/apps/www/src/content/docs/zh-cn/site-search-evidence.ts';
const root='<R16>';
const prod='<PRODUCT_ROOT>/apps/www/src/content/docs/zh-cn/site-search-commands.browser.test.ts';
const hash=(b:string)=>createHash('sha256').update(b).digest('hex');
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const results=[];
for(const [version,file]of [['v1',root+'/search-followup/v1-frozen/site-search-commands.browser.test.ts'],['v2',prod]]){
 const source=readFileSync(file,'utf8');const start=source.indexOf('        const roleGetters:');const end=source.indexOf('        await revealHeaderPreferences(page);',start);assert(start>=0&&end>start);const block=source.slice(start,end);
 const output=ts.transpileModule(block,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022},reportDiagnostics:true});assert.equal(output.diagnostics?.length??0,0);
 const run=new AsyncFunction('expect','selector','traceSearchGetter','console','source','family','width',output.outputText);
 for(const succeeds of [false,true]){
  const original=new Error('injected original matcher verdict');const recording=new Error('injected console failure');let caught:unknown;
  const expectMock={poll:(read:()=>Promise<string|null>)=>({toBe:async(expected:string)=>{const value=await read();if(!succeeds)throw original;assert.equal(value,expected);}})};
  try{await run(expectMock,{getAttribute:()=>Promise.resolve(succeeds?'combobox':null)},traceSearchGetter,{log(){throw recording;}},{sha:'8bfea32042ab12acdcb821ca7a3c77e1ab1946de',dirty:true},'shadcn',320);}catch(e){caught=e;}
  const preserved=succeeds?caught===undefined:caught===original;
  assert.equal(preserved,version==='v2');
  results.push({version,succeeds,sourceSHA256:hash(source),extractedBlockSHA256:hash(block),transpiledSHA256:hash(output.outputText),recordingFailureInjected:true,pollVerdictPreserved:preserved,caught: caught===original?'same injected matcher object':caught===recording?'same injected recording object':caught===undefined?'none':'other'});
 }
}
const report={at:new Date().toISOString(),method:'Actualsourceblock extracted and TypeScript-transpiled; actualtraceSearchGetter; injected matcher/console failures, not realVitest/Browser or occurrenceproof',results};writeFileSync(root+'/search-followup/recording-priority-control.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
