CF当前Search首分歧审查：partial/ABSTAIN，不能给生产根因或GitHub批准。

专项119733778541在依赖/字体安装5分钟setup超时，0个Search case、新字段0条，不是新的20/10或观测失败。实际新字段来自主shard1：Search30中28pass2fail。

唯一initial-ready红是shadcn dark1440。BrowserEntry在runner stage+966ms，余名义34ms；7次采样+966/973/977/981/984/987/1006全部activecommandCount0，disabled/owner/gen均null、timerSamplefalse、0drop，页面+1006完成，Node+1009返回。现在可区分这些采样点的零active匹配与“有节点缺属性”；不能声称前966ms全程无target。timerSamplefalse只表示不是timer参数，不表示未过deadline。

已有startupTrace的定义/投射观察给出defined约+798.9、staging-open delivery约+1006.4、active-ready delivery约+1075.3ms；依赖共同hostepoch/稳定时钟，都是MO回调交付时间，不是生产setter时刻。随后capture ready和6mslate-ready不改变原onTime=false。下一步只需有界检查已留startup/resource/longtask阶段，不因晚ready延长1000或注入activation。

另一红是Docs Shadcn2048：原一次getAttribute(role)在+1001ms拒绝快照仍pending1、无返回值/错误。不能称role曾返回错误，也没有迟到结算数据。其它9个Docs快照返回combobox并通过。若继续，仅需相同原Promise的有界postverdict结算，保留原失败/关闭；必要时复用ownership-safe utility时间观察，不能在原poll前塞新等待/RPC。

CFStartup27/27是独立已执行成功；并未闭合以上两个不同失败。当前没有新wrongowner/context/retirement证据，不应仅由这些时间记录直接改生产。来源/head/hash与完整原件在JSON；旧8b及local145与hosted结果互不重标。

新增来源闭合：root现有GitAPI对象df44已实核parentsb928+CF、tree严格等d9fa；早期未取得对象的initial报告另存，不改旧8b。
