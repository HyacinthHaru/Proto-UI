CF准确canonical已完成缓存只读对账：主39751754024 **22jobs=12success/10failure**。全部mainlog实际checkoutdf44，GitAPI对象parentsb928+CF、tree严格等产品d9fa。结论partial/ABSTAIN，不是GitHub批准或全C验收。

完整仅1/4/5：分别227/13、122/2、88/2/15skip，合 **437pass17fail15skip**。2/7/8原124无summary；3/6在CJK字体3分钟setup超时，未进入Vitest。不能构造all8总数。

Search专属119733778541是5分钟依赖/字体setup失败，0执行；真正新字段来自main1的Search28/2。唯一initial-ready红BrowserEntry在stage+966ms，7次active查询点+966…+1006均count0，nulldisabled/owner/gen、timerSamplefalse/0drop；只证明这7点，没有前966ms全程事实。唯一Docs红Shadcn2048是原一次query在+1001ms冻结时仍pending，没有返回值/错误，不是已观察到错误role。晚ready不补原deadline；仍缺生产/调度因果，不能直接改1000ms。

Startup新CF candidate官方27/27；历史48bbaseline另27/27，保持分源。Dialogcandidate8通过、historicalbaseline7geometry+1notOffered接受分开；Portal专项fontsetup红。NativeLinks主片10/10及专项10/10、Header主片16/16、Shadow111、Coll36真实通过，但这些局部成功不使超时片或全CI变绿。Homepage本轮仍8/1，Brutalist原poll1001.415981ms拒绝，第三query1124.795467ms返回；原boundeddrain123.178244ms完成，晚返回不修改原红。

类型937/0error/0warning/14hint；General78public-docs退出preVitest，keyboardowner17/四token未在General执行。Package实际45/47构建、47manifest、9policy，4PASS5ADVISORY；真实Node24.22.0/zlib1.3.2.1-motley-285e94b，不能写旧8b环境。九measuregzip/minified/hash逐条同8b，但不是环境相同。

root当地147/176/16、完整生产artifact27以及1339单case阳性另留来源；1339原175/1不由无catch执行的私有1pass闭合。旧8b全部不动，无新API/下载/测试/浏览器/源码/Actions操作。raw清单只明确选37rootjoblogs、各收据、分页和本审查资料，排除fullsnapshot/comments/privateMT/auth/ZIP/PNG。
