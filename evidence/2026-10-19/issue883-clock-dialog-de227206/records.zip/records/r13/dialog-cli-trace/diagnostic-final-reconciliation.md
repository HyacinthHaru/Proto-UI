# Dialog诊断：自然红仍未归因，隔离宿主缺陷已实证

目前必须分开两条结论：**原8c与clean dd的129/max2自然红仍是original57 content.isConnected=true，根因未闭合；installedHappyDOM15.11.7的WeakRef回调失活已被独立forced-GC宿主探针复现。** 二者不能合成“原红就是GC”或“已修”。

保留的实际arms：8c original1291802/5、isolated2/0、serial1291803/4、privatecatch1291803/4无failure快照；dd original1291802/5；同private3 JSON-only1803/4但console传输失败；default+JSON同3source1803/4并得到142/154条完整阳性事件。误套run-check的0tests setup退出单列，不算测试失败，准备命令缺陷及修正不洗历史。

低干预单test391又真实1802/5。原失败后before368.878625、Promise后369.112292、HappyDOMcomplete后370.431083ms，均Rootdisconnected、Content/Mask仍BODY/connected/portaled、overflowhidden。这否定该次“再等taskcomplete便完成”的修复方向。最后仅catch检查WeakRef列表的5e5a候选却是1803/4、只有两张passed marker JSON，未进入失败inventory；没有自然red WeakRefalive/dead证据。原test已恢复1ba48973、收据clean。

root的实际Node24 --expose-gc宿主探针使用realWindow/realMutationObserver，无mock、无Adapter：ESM与CJS均先SPAN交付1；跨setImmediate显式GC后新增B未交付，仍1；显式disconnect后再加EM仍1，两个模式exit1。原probe明确定义期待1→2→2，sourceSHA4bebf7b7；observer在GC后仍实际调用disconnect。afterDisconnect的基线1不能单独当完整cleanup证明，因为此前已失去delivery；后续green需要同probe对照。

已有primary上游#2264由#2272于2026-08-07T15:46:18Z合入576a8bcf关闭，修的是同一reportbridge强引用#listenerCallback并destroy置null。上游其余microtask实现是版本背景，不得连带移入15.11.7。可审版本不升的受控backport；必须核源生成/ESM-CJS一致和sameGCfixture红绿，再看原组合。当前没有本代理运行新测试、修改依赖或Adapter。partial/ABSTAIN，不是formalapproval。
