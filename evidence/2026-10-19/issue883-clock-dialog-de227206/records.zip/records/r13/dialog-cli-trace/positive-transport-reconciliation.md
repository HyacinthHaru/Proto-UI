# Dialog private transport：真实阳性轨迹

同dd56+三文件私有观察，default+JSON的真实执行为129files1803pass/4tokenfail；两个Dialog均过。原stdout2marker与traces.json逐对象相等，false142events、true154events，0drop/observerError。此前JSON-only阳性没有可取轨迹，以及误套run-check的0tests setup失败，都分别保留；不能填回本次数据。

| 以before-root-remove标记为0 | shadow=false | shadow=true |
| --- | ---: | ---: |
| Root disconnect checkpoint | 0.219291ms | 0.103000ms |
| Root retire finally | 2.678666ms | 0.875542ms |
| Content onMutation | 3.013458ms | 1.029167ms |
| Content restore end | 3.112500ms | 1.084834ms |
| Content retire finally | 4.119958ms | 1.590417ms |
| 原20ms flush后标记 | 21.354166ms | 20.821417ms |

false的Root ID1/token13，Content7/lease8/marker12，Mask4/lease5/marker10，BODY11。Content在移入Shadow后的观察树已重绑[Shadow17,Document3]，比remove早20.460375ms。true的Root1/token14，Content8/lease9/marker13，Mask4/lease5/marker11，BODY12；已重绑[Shadow18,outerShadow3,Document6]，Content重绑比remove早20.425583ms。这些ID是每case独立WeakMap身份编号，不是Runtime epoch数字或Chrome原生NodeID。

两个case在root.remove刚返回时，Root已断开但Content/Mask仍在BODY且connected；之后各当前Portal观察到parentConnected=false、marker仍属于Root、stillOwned=true，恢复到同一断开的Root，activefalse/errors0。原57断言之前两者已断开；剩余原parent/overflow、重连重开、carrierremove断言均通过。Root terminal cleanup先于子Portal观察/物理归还，是本次正常路径的真实顺序，不证明原红时同样交付。

原clean8c和clean新dd的两次129/max2仍各1802/5、同57红；其它resource/private阳性不抹掉它们。本次无失败时刻的lease/observer轨迹，不能断言worker、GC、flaky或已修；没有新增production修复。三源exact restore及clean由真实receipt核对。

下一低干预控制已另备于post-failure-settlement-files/，尚未apply/run：原try和20ms不动、JSON-only；仅catch在原失败后依次存before→Promise checkpoint→after-microtask→真实HappyDOM task-manager completion→after-complete，并重抛原error。这个API同仓已有真实用法，不是abort/cancel/getTaskCount。若case仍阳性只记passed marker；若completion导致false，只说明该次原断言前尚未完成交付，不能把原红改绿或直接推广根因。

partial/ABSTAIN，peer分析；本代理只读现有终态，没有重测、外写或源码更动。
