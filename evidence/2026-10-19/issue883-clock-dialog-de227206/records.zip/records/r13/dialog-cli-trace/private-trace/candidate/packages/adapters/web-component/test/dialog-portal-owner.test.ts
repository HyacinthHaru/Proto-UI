import { describe, expect, it } from 'vitest';
import { AdaptToWebComponent, setElementProps } from '../src';
import {
  dialogRoot,
  dialogMask,
  dialogContent,
  dialogTrigger,
} from '../../../prototypes/base/src/dialog';

// A-WEB-COMPONENT G/I + C-AS-OVERLAY E/F/K: physical portal projection
// must not orphan a descendant when its logical origin leaves the document.
describe('WC portal origin ownership', () => {
  it.each([false, true])(
    'reclaims open portals after origin removal (shadow origin=%s)',
    async (shadow) => {
      const parts: Record<string, any> = {};
      for (const [key, proto] of Object.entries({
        root: dialogRoot,
        mask: dialogMask,
        content: dialogContent,
        trigger: dialogTrigger,
      })) {
        const C = AdaptToWebComponent(proto, { registerAs: `portal-owner-${shadow}-${key}` });
        parts[key] = new C();
      }
      const { root, mask, content, trigger } = parts;
      const carrier = document.createElement('div');
      const origin = shadow ? carrier.attachShadow({ mode: 'open' }) : carrier;
      const parent = document.createElement('section');
      origin.append(parent);
      parent.append(root);
      root.append(trigger, mask, content);
      setElementProps(root, { open: true });
      document.body.append(carrier);
      const flush = async () => {
        await new Promise((resolve) => setTimeout(resolve, 20));
      };
      // Private observation only; no sink exists outside these two original cases.
      const traceKey = Symbol.for('proto-ui.private.dialog-origin-trace.20261019');
      const hadSink = Object.prototype.hasOwnProperty.call(globalThis, traceKey);
      const previousSink = (globalThis as any)[traceKey];
      const events: unknown[] = [];
      const ids = new WeakMap<object, number>();
      let nextId = 0, dropped = 0, observerError = false;
      const describe = (value: any): unknown => {
        if (Array.isArray(value)) return value.map(describe);
        if (value && (typeof value === 'object' || typeof value === 'function')) {
          if (!ids.has(value)) ids.set(value, ++nextId);
          return value instanceof Node
            ? { id: ids.get(value), name: value.nodeName, type: value.nodeType, connected: value.isConnected }
            : { id: ids.get(value) };
        }
        return value;
      };
      const record = (el: HTMLElement, phase: string, facts: Record<string, unknown>) => {
        try {
          if (phase === 'trace:observer-error') observerError = true;
          if (events.length === 512) { dropped++; return; }
          events.push({ atMs: performance.now(), phase, target: describe(el), facts: Object.fromEntries(Object.entries(facts).map(([key, value]) => [key, describe(value)])) });
        } catch { observerError = true; }
      };
      (globalThis as any)[traceKey] = record;
      const mark = (phase: string) => {
        try { record(root, phase, { rootConnected: root.isConnected, rootParent: root.parentNode, rootTree: root.getRootNode(), contentConnected: content.isConnected, contentParent: content.parentNode, maskConnected: mask.isConnected, maskParent: mask.parentNode }); }
        catch { observerError = true; }
      };
      const dump = (outcome: string, error?: unknown) => {
        try { console.error('[WC_PORTAL_ORIGIN_TRACE]', JSON.stringify({ shadow, outcome, clock: 'test realm performance.now milliseconds', events, dropped, observerError, error: error === undefined ? null : String(error) })); }
        catch { /* The original assertion or cleanup error must win. */ }
      };
      try {
        mark('test:before-initial-flush');
        await flush();
        mark('test:after-initial-flush');
        expect(content.parentElement).toBe(document.body);
        // A synchronous move does not disconnect logical ownership at settlement.
        const destination = document.createElement('div');
        origin.append(destination);
        destination.append(root);
        await flush();
        expect(content.parentElement).toBe(document.body);
        expect(content.getExposes().open.get()).toBe(true);
        // Rebind liveness observation when a sync move changes containing roots.
        const other = document.createElement('div');
        origin.append(other);
        const otherTree = other.attachShadow({ mode: 'open' });
        mark('test:before-shadow-move');
        otherTree.append(root);
        mark('test:after-shadow-move');
        await flush();
        mark('test:after-shadow-move-flush');
        expect(content.parentElement).toBe(document.body);
        mark('test:before-root-remove');
        root.remove();
        mark('test:after-root-remove');
        await flush();
        mark('test:after-root-remove-flush');
        expect(content.isConnected).toBe(false);
        expect(mask.isConnected).toBe(false);
        expect(content.parentElement).toBe(root);
        expect(document.body.style.overflow).toBe('');
        setElementProps(root, { open: false });
        parent.append(root);
        await flush();
        setElementProps(root, { open: true });
        await flush();
        expect(content.parentElement).toBe(document.body);
        carrier.remove();
        await flush();
        expect(content.isConnected).toBe(false);
        expect(document.body.style.overflow).toBe('');
        dump('passed');
      } catch (error) {
        mark('test:assertion-rejected');
        dump('failed', error);
        throw error;
      } finally {
        try {
          carrier.remove();
          mask.remove();
          content.remove();
          await flush();
        } finally {
          if (hadSink) (globalThis as any)[traceKey] = previousSink;
          else delete (globalThis as any)[traceKey];
        }
      }
    }
  );
});
