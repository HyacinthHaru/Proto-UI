#!/usr/bin/env python3
"""Root-invoked only. No action is performed by importing/preparing this file."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
O=Path(__file__).resolve().parent
W=Path('<PRODUCT_ROOT>')
M=json.loads((O/'prepared.json').read_bytes())
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=W).decode()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snapshot():
    names=set(git('diff','--name-only').splitlines()+git('diff','--cached','--name-only').splitlines())
    return {'at':now(),'head':git('rev-parse','HEAD').strip(),'tree':git('rev-parse','HEAD^{tree}').strip(),'status':git('status','--porcelain=v1'),'dirtySHA256':{p:sha((W/p).read_bytes()) for p in sorted(names) if (W/p).is_file()},'threeFiles':{x['path']:sha((W/x['path']).read_bytes()) for x in M['entries']}}
def write_receipt(name,data):
    p=O/name
    assert not p.exists(), 'Refuse to overwrite an execution receipt: '+str(p)
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def apply():
    assert not (O/'apply-receipt.json').exists(), 'Existing apply receipt; refuse repeat'
    before=snapshot();assert before['head']==M['head'],'HEAD changed'
    for x in M['entries']:
        assert sha((O/'original'/x['path']).read_bytes())==x['originalSHA256']
        assert sha((O/'candidate'/x['path']).read_bytes())==x['candidateSHA256']
        assert before['threeFiles'][x['path']]==x['originalSHA256'],'Unexpected dirty target: '+x['path']
    applied=[]
    try:
        for x in M['entries']:
            (W/x['path']).write_bytes((O/'candidate'/x['path']).read_bytes());applied.append(x)
    except BaseException:
        for x in applied:
            assert sha((W/x['path']).read_bytes())==x['candidateSHA256'],'Concurrent target edit; no force restore'
            (W/x['path']).write_bytes((O/'original'/x['path']).read_bytes())
        raise
    after=snapshot();write_receipt('apply-receipt.json',{'before':before,'after':after,'privateOverride':True,'notCleanHeadExecution':True})
    return before
def restore():
    assert not (O/'restore-receipt.json').exists(), 'Existing restore receipt; refuse repeat'
    before=snapshot();assert before['head']==M['head'],'HEAD changed; refuse automatic restore'
    for x in M['entries']:
        assert sha((O/'original'/x['path']).read_bytes())==x['originalSHA256']
        assert before['threeFiles'][x['path']] in [x['originalSHA256'],x['candidateSHA256']],'Unexpected target bytes; no force restore: '+x['path']
    for x in M['entries']:
        if before['threeFiles'][x['path']]==x['candidateSHA256']:(W/x['path']).write_bytes((O/'original'/x['path']).read_bytes())
    after=snapshot();assert all(after['threeFiles'][x['path']]==x['originalSHA256'] for x in M['entries'])
    write_receipt('restore-receipt.json',{'before':before,'after':after,'restoredThreeOriginalBytes':True,'otherSourceChangesRemainAsObserved':True})
    return after
if __name__=='__main__':
    action=sys.argv[1] if len(sys.argv)>1 else ''
    if action=='apply': apply()
    elif action=='restore': restore()
    elif action=='run':
        assert not any((O/n).exists() for n in ['apply-receipt.json','restore-receipt.json','run-receipt.json']), 'Fresh execution receipts required'
        command=sys.argv[2:];assert command,'Supply root-owned original129/max2 command with NEW output paths'
        start=now();before=apply();exit_code=None;error=None
        try:
            exit_code=subprocess.run(command,cwd=W,env=os.environ.copy()).returncode
        except BaseException as e:
            error=repr(e);raise
        finally:
            after=restore()
            untouched={p:h for p,h in before['dirtySHA256'].items() if p not in before['threeFiles']}
            assert all(sha((W/p).read_bytes())==h for p,h in untouched.items()),'Unrelated dirty bytes changed during run'
            write_receipt('run-receipt.json',{'start':start,'end':now(),'command':command,'exit':exit_code,'wrapperError':error,'before':before,'after':after,'privateDiagnostic':True,'repeatedAutomatically':False})
        sys.exit(exit_code)
    else: raise SystemExit('Usage: apply-restore.py apply | restore | run <root command argv...>')
