from pathlib import Path
import subprocess,json,datetime,hashlib,os,sys
r=Path(__file__).parent;out=r/sys.argv[1];out.mkdir();w=Path('<PRODUCT_ROOT>');env=os.environ.copy();env['PATH']='<TOOLCHAIN>/node-v24.21.0-darwin-arm64/bin:'+env['PATH'];env.update(json.loads(sys.argv[2]));args=sys.argv[3:];now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();git=lambda a:subprocess.check_output(['git',*a],cwd=w).decode().strip();row={'start':now(),'argv':args,'environmentOverrides':json.loads(sys.argv[2]),'head':git(['rev-parse','HEAD']),'tree':git(['rev-parse','HEAD^{tree}']),'diffBefore':git(['diff','--stat']),'node':subprocess.check_output(['node','-v'],env=env).decode().strip()}
with (out/'run.log').open('x')as log:p=subprocess.run(args,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
row.update(end=now(),exit=p.returncode,diffAfter=git(['diff','--stat']));(out/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row));raise SystemExit(p.returncode)
