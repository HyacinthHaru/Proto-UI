import { createRequire } from 'node:module';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { setImmediate } from 'node:timers/promises';
const [root, mode] = process.argv.slice(2);
if (!['esm', 'cjs'].includes(mode) || typeof globalThis.gc !== 'function') throw new Error('Real exposed GC and an explicit module mode are required');
const require = createRequire(path.join(root, 'package.json'));
const manifest = require('happy-dom/package.json');
const packageRoot = path.dirname(require.resolve('happy-dom/package.json'));
const entry = manifest.exports['.'][mode === 'esm' ? 'import' : 'require'];
const loaded = mode === 'esm' ? await import(pathToFileURL(path.join(packageRoot, entry)).href) : require(path.join(packageRoot, entry));
const window = new loaded.Window();
const target = window.document.createElement('div');
window.document.body.append(target);
const records = [];
const observer = new window.MutationObserver((batch) => records.push(...batch));
try {
  observer.observe(target, { childList: true });
  target.append(window.document.createElement('span'));
  await window.happyDOM.waitUntilComplete();
  const beforeGC = records.length;
  await setImmediate();
  globalThis.gc();
  await setImmediate();
  target.append(window.document.createElement('b'));
  await window.happyDOM.waitUntilComplete();
  const afterGC = records.length;
  observer.disconnect();
  target.append(window.document.createElement('em'));
  await window.happyDOM.waitUntilComplete();
  const afterDisconnect = records.length;
  const result = { mode, entry, version: manifest.version, node: process.version, beforeGC, afterGC, afterDisconnect, added: records.flatMap((record) => Array.from(record.addedNodes, (node) => node.nodeName)), explicitNativeGC: true, observerUsedAfterGC: true };
  console.log(JSON.stringify(result));
  if (beforeGC !== 1 || afterGC !== 2 || afterDisconnect !== 2) process.exitCode = 1;
} finally {
  observer.disconnect();
  await window.happyDOM.close();
}
