# Prepared only. Root owns execution. No unfiltered publisher scan or download retry.
from pathlib import Path
from datetime import datetime, timezone
import argparse, fcntl, hashlib, http.server, json, os, signal, subprocess, threading

R = Path(__file__).resolve().parent
W = Path('<PRODUCT_ROOT>')
NODE_DIR = '<TOOLCHAIN>/node-v24.21.0-darwin-arm64/bin'
now = lambda: datetime.now(timezone.utc).isoformat()
sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=W, text=True).strip()
def save(output, name, value):
    with (output / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--tuple', type=Path, default=R / 'target-tuple.json')
    args = parser.parse_args()
    if not args.execute:
        print('Prepared only. Root must deliberately pass --execute; no admission or native run occurred.')
        return
    tuple_path = args.tuple.resolve()
    assert tuple_path.parent == R
    target = json.loads(tuple_path.read_text())
    assert target['status'] == 'frozen-final-target' and target['pr'] == 921
    HEAD = target['head']
    assert isinstance(HEAD, str) and len(HEAD) == 40 and all(c in '0123456789abcdef' for c in HEAD)
    assert git('rev-parse', 'HEAD') == HEAD and git('rev-parse', 'HEAD^{tree}') == target['tree'] and not git('status', '--porcelain')
    binding_path = (R / target['sourceBindingFile']).resolve()
    assert binding_path.parent == R
    binding = json.loads(binding_path.read_text())
    assert binding['head'] == HEAD and binding['tree'] == target['tree']
    for item in binding['files']:
        assert sha((W / item['path']).read_bytes()) == item['sha256'], item['path']
    output = R / f"execution-{HEAD[:12]}-r{target['run']}"
    output.mkdir(exist_ok=False)  # Existing output requires reconciliation, never an automatic rerun.
    env = os.environ.copy(); env['PATH'] = NODE_DIR + ':' + env.get('PATH', '')
    assert env.get('GITHUB_ACTIONS') != 'true', 'This is a local control, not an official workflow.'
    save(output, 'execution-source.json', {'at': now(), 'head': HEAD, 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain'), 'files': binding['files'], 'scriptSHA256': sha(Path(__file__).read_bytes()), 'admissionScriptSHA256': sha((R / 'admit-one.mjs').read_bytes()), 'method': 'Existing exported single-target admission functions; not the unfiltered publisher CLI.'})
    # Native macOS flock equivalent, held for the whole admission child lifetime.
    lock_path = output / '.publish.lock'
    with lock_path.open('a+') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        admission_env = env.copy(); admission_env['PUI_PREVIEW_NATIVE_LOCK_HELD'] = '1'
        with (output / 'admission.log').open('x') as log:
            admission = subprocess.run(['node', str(R / 'admit-one.mjs'), str(tuple_path), str(output)], cwd=W, env=admission_env, pass_fds=(lock.fileno(),), stdout=log, stderr=subprocess.STDOUT, timeout=300)
    save(output, 'admission-process-receipt.json', {'at': now(), 'exit': admission.returncode, 'lock': str(lock_path), 'serialization': 'fcntl LOCK_EX|LOCK_NB held for the complete child process lifetime; real descriptor inherited; no distributed-lock claim'})
    if admission.returncode:
        raise SystemExit(admission.returncode)
    admitted = json.loads((output / 'admission-receipt.json').read_text())
    assert admitted['readyForLocalNativeControl'] and admitted['sourceHead'] == HEAD
    assert admitted['downloadCalls'] == 1
    site = Path(admitted['directory']); assert site == output / 'site'
    assert git('rev-parse', 'HEAD') == HEAD and not git('status', '--porcelain')
    server_log = (output / 'server.log').open('x')
    class Handler(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **kw): super().__init__(*a, directory=str(site), **kw)
        def log_message(self, fmt, *a):
            server_log.write(fmt % a + '\n'); server_log.flush()
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    base_url = f'http://127.0.0.1:{server.server_address[1]}'
    evidence = output / 'evidence'; evidence.mkdir()
    native_env = env.copy(); native_env['PROTO_UI_BROWSER_BASE_URL'] = base_url; native_env['PROTO_UI_RUNTIME_EVIDENCE_DIR'] = str(evidence)
    pattern = 'switches every registered homepage group through real adapters, preserving native anchors and theme|uses real family Contents Buttons through all four Docs runtimes with keyboard and exact-source visual evidence|completes the settings task|retains brutalist preference owners and portals through real breakpoint reconnects'
    command = ['corepack', 'pnpm@10.32.1', 'exec', 'vitest', 'run', 'apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts', 'apps/www/src/content/docs/zh-cn/home-demo-runtime.browser.test.ts', '--testNamePattern=' + pattern, '--maxWorkers=1', '--minWorkers=1', '--reporter=json', '--outputFile=' + str(output / 'vitest.json')]
    started = now(); result = None; error = None; native_process = None; cleanup = []
    try:
        with (output / 'native.log').open('x') as log:
            native_process = subprocess.Popen(command, cwd=W, env=native_env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            save(output, 'native-process.json', {'at': now(), 'pid': native_process.pid, 'pgid': native_process.pid, 'argv': command, 'cwd': str(W), 'outerWaitLimitSeconds': 1200, 'boundary': 'Process cleanup bound only; original suite assertions and timeouts unchanged.'})
            native_process.wait(timeout=1200)
            result = native_process
    except BaseException as exc:
        error = {'name': type(exc).__name__, 'message': str(exc)}
        raise
    finally:
        if native_process is not None:
            try:
                os.killpg(native_process.pid, 0)
                os.killpg(native_process.pid, signal.SIGTERM)
                cleanup.append({'ownedPGID': native_process.pid, 'signal': 'SIGTERM', 'reason': 'Owned native process group remained after completion or exception'})
                try: native_process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(native_process.pid, signal.SIGKILL); native_process.wait(timeout=10)
                    cleanup.append({'ownedPGID': native_process.pid, 'signal': 'SIGKILL'})
            except ProcessLookupError:
                cleanup.append({'ownedPGID': native_process.pid, 'noRemainingGroup': True})
        server.shutdown(); server.server_close(); thread.join(timeout=10); server_log.close()
        counts = None
        if (output / 'vitest.json').exists():
            value = json.loads((output / 'vitest.json').read_text())
            counts = {k: value.get(k) for k in ['numPassedTests', 'numFailedTests', 'numPendingTests', 'numTotalTests']}
        save(output, 'native-receipt.json', {'start': started, 'end': now(), 'head': HEAD, 'tree': binding['tree'], 'argv': command, 'exit': result.returncode if result else None, 'error': error, 'servedBinding': admitted['binding'], 'baseURL': base_url, 'site': str(site), 'counts': counts, 'expectedSelected': 4, 'expectedFiltered': 16, 'serverClosed': not thread.is_alive(), 'ownedProcessCleanup': cleanup, 'gitAfter': {'head': git('rev-parse', 'HEAD'), 'status': git('status', '--porcelain')}, 'boundary': 'Original Homepage/Contents/settings journeys plus complete Brutalist preference-owner journey on the freshly admitted exact-target official bytes. Temporary plain localhost static server, not remote hosting/CSP or publisher lease-serving acceptance. No71-case matrix rerun.'})
    if result.returncode:
        raise SystemExit(result.returncode)
    assert counts and counts['numPassedTests'] == 4 and counts['numFailedTests'] == 0 and counts['numPendingTests'] == 16, counts
    assert git('rev-parse', 'HEAD') == HEAD and not git('status', '--porcelain')
    print(json.dumps({'nativePassed': 4, 'filtered': 16, 'head': HEAD, 'output': str(output), 'serverClosed': True}))

if __name__ == '__main__':
    main()
