# 准确8c14本地执行／官方产物对账

本次只读核验0个具体来源finding，partial/ABSTAIN；参与诊断提案的peer reconciliation，不是正式独立审批。

| 来源与时期 | 实际结果 | family-commit原poll区间 |
| --- | --- | --- |
| 67+候选，预提交focused，12:22:22–12:22:41UTC，test-owned dev | 1pass/8filtered | 422.384250ms，3RPC：shadcn→shadcn→brutalist |
| clean8c，12:27:36–12:29:17UTC，test-owned dev完整两file | 120pass/0fail | 400.262292ms，3RPC：shadcn→shadcn→brutalist |
| clean8c测试＋exact8c官方产物，12:34:23–12:35:21UTC，plainlocalhost | 4pass/16filtered | 26.681167ms，1RPC：brutalist |

这些数值是Node performance.now原poll开始到完成，不是click-to-commit或页面实际提交时刻。各次40Brutalist记录覆盖四Runtime每个10项；ringFailures/pageErrors均空。两次dev consoleErrors仍有React hreflang→hrefLang warning；official数组空，不把它写成源码修复。三种环境、时间不可混并，当前阳性不能解释此前Linux1s红。

官方run39252002967/artifact12185508935的单次实际下载记录为21,139,555bytes/SHA3c9b5ac0。准入12:33:57–12:34:23UTC；此审计只读已保留ZIP，重新逐成员比较3835文件、669HTML、104,046,139bytes与原记录和servedsite全部相等，没有下载或extract。真实local lock、embedded现有admission函数与plainlocalhost服务器有明确来源；不是unfilteredpublisherCLI/远程hosting/CSP准入。native收据exit0、serverClosed和无残留PG均在案。

root已逐张view的8张当前Contents原PNG，字节/大小/尺寸逐一对账一致；本审计没有再看图，不声称allpage/光学/AT通过，ShadcnVue2稀疏安装区限制保留。

CLI actual四source控制仍2pass2fail，nested invalid主体unresolved；它不是完整package/runtime/当前nativeForm验收。旧0ec原生颜色与67的0CSSvariant证据不重标8c。Node四条件仍分开：原cleanmax2=1802/5；isolated2=2/0；clean129max1=1803/4；privatecatch129max2=1803/4且无取证snapshot。原Portal失败未解释，不称已修/flake/inherited。

没有新增测试、build、browser、下载、CI查询、产品或外部写入。
