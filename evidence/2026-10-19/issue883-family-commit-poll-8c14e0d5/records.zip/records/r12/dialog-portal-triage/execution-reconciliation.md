# Dialog Portal origin：追加执行对账

准确8c14保留四种执行条件，不能合并成一次“原max2通过”：

| 条件 | 实际结果 | Portal两项 |
| --- | --- | --- |
| clean原129/max2 | 1802pass / 5fail | false分支原57行红，true过 |
| clean原完整两项/max1 | 2pass | 两项过 |
| clean原129/max1 | 1803pass / 4CLI fail | 两项过 |
| physical8c + 私有catch稿，129/max2 | 1803pass / 4CLI fail | 两项过，取证分支未触发 |

最后一次由root在12:40:58–12:41:28UTC执行，实际诊断test SHA8f4fdcbd；原try body、20msflush、输入/断言和finally保持。原log/result中 WC_PORTAL_ORIGIN_FAILURE 与 CAPTURE_FAILED均0，因此**没有失败DOM/lease快照**，不能叙述为已捕获并解释原红。它是带诊断源的条件控制，不是原未修改max2通过。

原test已逐字恢复SHA1ba48973，与8c Git和保存的original一致；收据gitAfter为空，当前只读gitstatus亦clean。生产未改。旧准备报告的not-applied/not-run保留为历史，本追加记录承接真正执行结果。

原1802/5红仍真实且原因未明：不称修复、flaky、preexisting，也不据max1阳性归因worker。C未知支线保持登记，不继续盲重试。四个CLI token失败仍红；native120和producer阳性不能替换该Node结果。

只读核验，partial/ABSTAIN；没有新测试、build、browser、CI查询或外部写。
