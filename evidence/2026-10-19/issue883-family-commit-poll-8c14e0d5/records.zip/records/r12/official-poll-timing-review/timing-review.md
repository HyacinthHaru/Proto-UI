官方8c轮询时序已完成核对，结论为 **partial / ABSTAIN**。没有发现数据绑定或记录完整性问题；原family-commit行为失败仍保留，底层原因尚未闭合。

来源为run39252003235／job118059224444，原checkout`02f6ff42e92e019033c3a64683b021817e5269c6`；既有source-package-binding记录其tree`3ddd326b`与产品8c一致。原stdout第444行、failureJSON和lifecycleJSON的时序对象逐字段完全一致，source-sha也一致。Homepage原9case为8pass／1fail；整个分片最终exit124，没有完整分片测试汇总，不能扩大总数。

以记录的poll start为0，全部单位为Node performance时钟的**毫秒**：

| 原调用 | 发起 | 返回 | 调用历时 | 返回值 | 拒绝快照中状态 |
| --- | ---: | ---: | ---: | --- | --- |
| 1 | 0.334574 | 7.002007 | 6.667433 | shadcn | 已返回旧值 |
| 2 | 57.776985 | 314.327669 | 256.550684 | shadcn | 已返回旧值 |
| 3 | 364.825557 | 1134.289297 | 769.463740 | brutalist | 仍在途，无returned/value |

catch入口在相对 **1001.650426ms** 观察到原matcher拒绝。此时第三个原getAttribute Promise已在途636.824869ms，之后再过 **132.638871ms** 才返回Brutalist。没有丢弃调用，observerError=false。记录的start略早于Vitest内部安装计时器，因而1.650426ms不能直接当作内部计时器误差。

可证结论是：原期限内已返回的两次采样均为旧值，第三次在拒绝时尚未返回。这里没有DOM属性写入时刻、浏览器utility实际读取时刻或各进程调度／传输耗时，不能推断页面一定在一秒后才提交，也不能断言Portal重连／owner生命周期出错、用迟到ready改判通过或称flake。没有据此提出生产修改或增加timeout。

原stage仍family-commit，records与ringFailures为空，后续runtime／breakpoint／owner循环未进入。后置DOM快照显示Brutalist／WC／generation2 ready，transaction一致、portal=null、page／console errors为空；这些是catch后读取。capturedAt为12:39:13.369Z，在后置DOM读取之后、截图之前，不等于原断言时刻。

Root唯一下载的artifact12187263780实际58,270,570字节，SHA`5d4b18f5192f7d64e5bda3ca3042d94d6044d51e118dfd88059c590c7c8201e6`与官方digest和收据一致。中央目录实际231成员；4选件逐字匹配ZIP与selected收据。本代理没有下载或重新执行。

已实际查看390×844原PNG：展开的蓝色Brutalist Header中WC／Brutalist选中，导航、语言和社区控制及上部gallery可见；未见可见错误banner或展开options。下方card被viewport底缘截断，只能说明截图范围，不能当新布局缺陷。该图不是一秒时刻、首帧、全页或AT验收。

未修改产品、测试、白名单或公开包；没有新浏览器、测试、下载或外部写入。
