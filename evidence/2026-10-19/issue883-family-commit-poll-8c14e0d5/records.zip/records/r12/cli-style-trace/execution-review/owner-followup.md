# Form invalid selector：实际源采集控制

Root于2026-10-19 12:31:01–12:31:03 UTC在clean8c14运行新current driver，Node24.21.0，1文件4项实际2pass/2fail。Shadcn/Brutalist FormField缺少 data-[invalid]:text-destructive / data-[invalid]:text-destructive-ink；仍采到plain ink。实际scanner均报 field.stateHandles!.invalid unresolved(reason=subject)。两个plain Error控制均通过。

三collector源与四原型输入逐字等于8c14、67和固定拷贝；实际driver相对原未执行prepare仅换manifest/result路径，config仅换include filename。没有把旧67准备driver写成已执行。七个明确输入不是完整加载依赖闭包；source collector不执行原型，也不是当前nativeForm或完整package import证明。

现有#906是Form组合验收承接，不代表collector已认领或已修。该具体反例应交既有Compiler/CLI语义source解释owner，连同旧0ec真实invalid/token/CSS观测及67官方50CSS缺selector记录；不重标旧时间，不加Form名字白名单、手写CSS、state扁平化或第二invalid owner。Owner修复应再用generic alias/嵌套capture/声明身份反例证明适用范围，而非只匹配这两个组件名字。

原4Checkbox token失败和原Form颜色断言保留。本审阅由probe提案参与者进行，partial/ABSTAIN，不是正式独审；没有新执行或外部写入。
