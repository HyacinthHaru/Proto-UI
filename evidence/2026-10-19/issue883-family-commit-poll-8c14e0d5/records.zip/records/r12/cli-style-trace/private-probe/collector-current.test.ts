import { expect, it } from 'vitest';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { collectProtoStyleTokensFromFiles } from '<PRODUCT_ROOT>/packages/cli/src/services/prototype-style-tokens.ts';
import { scanRuleStateReads } from '<PRODUCT_ROOT>/packages/cli/src/services/lowered-hook-coverage.ts';
const root = "<PRODUCT_ROOT>";
const out = "<R12>/cli-style-trace/private-probe/results-current";
const manifest = JSON.parse(await readFile("<R12>/cli-style-trace/private-probe/inputs-current.json", 'utf8'));
const digest = (value: Buffer | string) => createHash('sha256').update(value).digest('hex');
if (execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim() !== manifest.head)
  throw new Error('Source head differs from the prepared collector control.');
for (const source of manifest.collectorSources)
  if (digest(await readFile(root + '/' + source.path)) !== source.sha256)
    throw new Error('Collector source changed: ' + source.path);
for (const row of manifest.cases) {
  it(row.name, async () => {
    const input = await readFile(row.input, 'utf8');
    expect(digest(input)).toBe(row.sha256);
    const tokens = await collectProtoStyleTokensFromFiles([row.input]);
    const scan = scanRuleStateReads(input, row.sourcePath);
    await mkdir(out, { recursive: true });
    await writeFile(out + '/' + row.name + '.json', JSON.stringify({ capturedAt: new Date().toISOString(), node: process.version, sourceHead: manifest.head, sourcePath: row.sourcePath, inputSHA256: row.sha256, workingStatus: execFileSync('git', ['status', '--short'], { cwd: root, encoding: 'utf8' }), tokens, scan, expected: row.expected, scope: 'Isolated actual source input; does not execute Prototype or establish complete package import resolution/Runtime behavior.' }, null, 2) + '\n');
    expect(tokens).toContain(row.expected);
  });
}
