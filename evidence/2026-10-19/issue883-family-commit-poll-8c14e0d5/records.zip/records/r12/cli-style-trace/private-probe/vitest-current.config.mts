import { defineConfig } from '<PRODUCT_ROOT>/node_modules/vitest/dist/config.js';
export default defineConfig({
  root: "<PRODUCT_ROOT>",
  test: {
    include: ["<R12>/cli-style-trace/private-probe/collector-current.test.ts"],
    environment: 'node',
    maxWorkers: 1,
    minWorkers: 1,
    fileParallelism: false,
    pool: 'forks',
    testTimeout: 30000,
    hookTimeout: 30000,
  },
});
