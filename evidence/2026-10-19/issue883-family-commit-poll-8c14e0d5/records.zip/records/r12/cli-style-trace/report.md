# Form invalid CSS：当前 main / #921 只读对账

main仍042f1e57，#921仍67d8f62b；这23个选定实现/定义/记录输入在main与head逐字相同。没有新的collector修复被合入当前组合。最近相关2aa11fd9仅补asFormSubmit/asFormReset命令状态映射，不覆盖asFormField→getAsHookHandle('as-field-root')→invalid。当前collector的known-hook表与source scanner都没有该嵌套解析入口；这是静态事实，不冒称本轮新跑的红。

旧0ec私有Form执行仍为2颜色红/2continuation绿，invalid/token/Label parent确实存在而loaded exact conditional selector为0；现有67官方产物50CSS扫描仍缺同两variant。二者各有原时点/来源，未重跑或重标。67的四Checkbox Group token断言也仍红，但不能仅凭相同collector包或计数断言同一精确根因。

任务关联已实时读取：[#906](https://github.com/Proto-UI/Proto-UI/issues/906) open、无assignee，承接Form组合验收，唯一评论指向[#890](https://github.com/Proto-UI/Proto-UI/issues/890)；#890保留Compiler/IR/WASM专责。当前[#883](https://github.com/Proto-UI/Proto-UI/issues/883)的C仍是Anatomy/Runtime生命周期，CLI失败需另列。#889 HT.G4是import-stat异常归unresolved，不能混为本nested-handle缺口，也不能把其五类已确认问题当已修。限定搜索未发现精确修复carrier或CLI标题的openPR；搜索不能证明不存在其它标题/private work，不据此认领。

维护者[6252777045](https://github.com/Proto-UI/Proto-UI/pull/921#issuecomment-6252777045)只关闭Vue2/17owner缺执行证据这一项，明确四CLI失败和CI红保留，没有formal APPROVE、collector实现结果或owner转交。公共dot声明不会改变本任务human-assisted/current-user模式。

现有draft C-AS-HOOK-0006/0007要求child capture与声明state identity，不允许为静态工具扁平化嵌套state；Rule style与T-RULE-EXPOSE-STATE-WEB只支持已映射部分，不能推为完整compiler等价。现有原型应保持单Field owner、真实borrowed handle和原颜色断言，不加Form名字白名单、手写CSS或第二invalid状态来绕过问题。

`private-probe/`仅准备未执行：四个真实源码Git快照（两FormField、两plainError），复用现有collector与scanner，经Vitest/Vite解析源中.js→.ts依赖。它在断言前保存actualtokens/scan，pin67与collector哈希；是最小采集定位控制，不是全package导入能力或native证明。若owner要修，应进一步做generic重命名/relative import/child lookup身份控制，不能照抄当前有限名字表当规范。

建议下一步是把上述精确输入与现有整产物缺失证据交给既有CLI/Compiler owner，关联#906/#890；本C组继续独立定位Brutalist poll，不以颜色缺CSS解释其deadline。只有出现invalid/token/真实Context首分歧才回到C生产修复。

本次没有运行测试、collector、browser/build，未修改产品、认领或外部写。partial/ABSTAIN，不是正式独立审批。
