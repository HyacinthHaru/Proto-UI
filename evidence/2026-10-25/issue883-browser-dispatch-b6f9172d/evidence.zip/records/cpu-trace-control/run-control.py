from pathlib import Path
import subprocess,hashlib,json,datetime
r=Path(__file__).parent;w=Path('<WORKTREE>');b=json.loads((r/'binding.json').read_text());sha=lambda v:hashlib.sha256(v).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();f=w/b['callerPath'];original=(r/'original.browser.test.ts').read_bytes();candidate=(r/'candidate.browser.test.ts').read_bytes();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==b['head'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=w);assert sha(f.read_bytes())==sha(original)==b['callerOriginalSHA256'];assert sha(candidate)==b['callerCandidateSHA256'];assert sha((r/'query-dispatch-trace.mjs').read_bytes())==b['helperCandidateSHA256'];pref=w/'apps/www/.astro/settings.json';old=pref.read_bytes();candidatePref=json.dumps({**json.loads(old),'devToolbar':{'enabled':False}},indent='\t').encode();(r/'preferences-original.private.json').write_bytes(old);(r/'applied.json').write_text(json.dumps({'at':now(),'head':b['head'],'originalCallerSHA256':sha(original),'privateCallerSHA256':sha(candidate),'originalPrefSHA256':sha(old),'privatePrefSHA256':sha(candidatePref),'privateOnly':True},indent=2)+'\n');f.write_bytes(candidate);pref.write_bytes(candidatePref);res=None
try:res=subprocess.run(['python3',str(r.parent/'run-plan.py'),str(r/'plan.json'),str(r/'launcher')])
finally:
 sc=sha(f.read_bytes())==sha(candidate);pc=sha(pref.read_bytes())==sha(candidatePref)
 if sc:f.write_bytes(original)
 if pc:pref.write_bytes(old)
 (r/'restoration.json').write_text(json.dumps({'at':now(),'callerCAS':sc,'prefCAS':pc,'restoredCallerSHA256':sha(f.read_bytes()),'restoredPrefSHA256':sha(pref.read_bytes()),'worktreeStatus':subprocess.check_output(['git','status','--porcelain'],cwd=w,text=True)},indent=2)+'\n')
raise SystemExit(res.returncode if res else 1)
