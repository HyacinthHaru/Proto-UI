from pathlib import Path
import subprocess,json,hashlib,datetime
r=Path(__file__).parent;w=Path('<WORKTREE>');c=json.loads((r/'candidate-v3.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
assert all(sha((w/p).read_bytes())==h for p,h in c['files'].items())
p=w/'apps/www/.astro/settings.json';original=p.read_bytes();candidate=json.dumps({**json.loads(original),'devToolbar':{'enabled':False}},indent='\t').encode();(r/'preferences-original.private.json').write_bytes(original);p.write_bytes(candidate);result=None
try:result=subprocess.run(['python3',str(r.parent/'run-plan.py'),str(r/'browser-plan.json'),str(r/'browser-launcher')])
finally:
 cas=sha(p.read_bytes())==sha(candidate)
 if cas:p.write_bytes(original)
 (r/'browser-restoration.json').write_text(json.dumps({'at':now(),'prefCAS':cas,'originalSHA256':sha(original),'testSHA256':sha(candidate),'restoredSHA256':sha(p.read_bytes()),'candidateStable':all(sha((w/f).read_bytes())==h for f,h in c['files'].items())},indent=2)+'\n')
raise SystemExit(result.returncode if result else 1)
