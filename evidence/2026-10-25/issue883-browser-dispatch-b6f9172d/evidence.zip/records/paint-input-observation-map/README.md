# Paint first-click observation map

**Prepared map only — partial / ABSTAIN.** Accurate b6 is unchanged. This map is for a possible private same-phase control only if newCI again fails the original firstlight click. It is not an input-method repair or an execution request.

```mermaid
flowchart TD
  Setup[Existing marker setup evaluate, lines 50–77] --> Passive[Passive document pointerdown / pointerup / click ledger]
  Locator[Original first light locator.click, line90] --> Frame[Driver Frame.click: original progress call ID]
  Frame --> Pre[Original scroll / point / hit-test / interceptor steps]
  Pre --> Mouse[Original Page.mouse.click]
  Mouse --> Raw[CRPage.rawMouse._client]
  Raw --> CDP[Same connection + session + Input CDP ID]
  CDP --> Browser[Browser input handling: unmeasured until actual native event]
  Browser --> Passive
  CDP --> Reply[Original session response callback]
  Passive --> Cleanup[Existing cleanup evaluate, lines169–173]
```

Use the pinned in-process lookup already used by docs-query-timing: `page.mainFrame()._connection.toImpl(clientFrame)` gives the driverFrame; `driverFrame._page.delegate.rawMouse._client` is the actual originalInput session. Verify it is the same client as `_mainFrameSession._client`. The paint helper's existing `newCDPSession(page)` is a different session used for screencast; hooking it alone would miss the originalInput messages.

The read-only observer points are the owned driverFrame.click instance for the exact firstselector/progressID, the existingtransport.send and actualsession._onMessage. Each wrapper forwards originalthis/arguments once, returns the originalPromise/result and rethrows the sameerror. Anyreaction/loggingcost is explicit. Do notserialize input: pinnedMouse.click withoutdelay putsmove/down/up inPromise.all, soresponses neednot arrivein order. IDs are uniqueperCRConnection, notglobally, and are distinct fromAPIcall@id orDOMpointerId.

ForDOMfacts, reuse the existingsetup evaluate ratherthan adding anRPC. The NativeLinks listener pattern is useful for retainedEvent references andlaterprevented/connectivity reads, but itsanchorfilter andelementFromPoint are unsuitablehere, and itsinstall/savefunctions addRPCs. Add only boundedpassivecapture listeners forpointerdown/up/click; preservewrong-target events and a boundedcomposedpath ofpublicmarkers. NoBCR/style/elementFromPoint/offset/client/scrollread,focus orpreventDefault. Streamonlyboundedimmutablecapturerows ifneeded tosurvivecontextclose. LaterdefaultPrevented is adifferentobservation fromcapturedefaultPrevented.

Reuse the existingfinallycleanup evaluate forfinalprojection andremovingownedlisteners, withoutchangingoriginalcleanup order. Ifdetach/contextclosure preventsitsreturn,finalfieldsremainmissing; do notadd a rescueevaluate orfabricateemptyjournal. Nodehooksrestoreonlyiftheyarestillowned, neverdetachtheoriginalrawMouse session. Newdiagnosticerrorscannotreplacetheoriginalactionorcleanupresult.

The oldhostedlastline “done scrolling” precedes clickable-point computation, instrumentation, framehit-test andutilityinterceptor setup. It doesnotproveInputwasissued. ConverselyInputACK isnotproof theDocumentlistener orCactivationgateran; andtrustedDOMclick isnotproofDialogopened/painted. Preserve clocksseparately,phase/caps/error/sourcebinding andoriginal30s/150s/assertions. NativePopupandContentsresultsfromanothercaseare notusedtopaintanexplanation.
