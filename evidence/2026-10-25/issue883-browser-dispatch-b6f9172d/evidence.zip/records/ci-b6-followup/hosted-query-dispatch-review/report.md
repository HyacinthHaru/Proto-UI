This is the **actual b6 hosted original Docs Shadcn1440 failure**, run40191179866/job121162906226, artifact12598479134. Synthetic checkout`38b4e6ec4e417bb8f089a64e8f87c79cf0f232d2` has the same tree6326cbb9a3e3a558113bc69be6a6c3f381555194 as b6. The original1s verdict is false and remains false; the same original request later returns`combobox`. Search's file summary is12pass/18fail; the shard exits124 without a whole-shard summary.

The trace has26,496,901 bytes, SHA`6d382541f998ff71657510d8e6dba01f92a1260220cfdfe69acb9c6eec595628`,138036 events, EOF/no reported loss. Actual query1/`call@979` sends the305324-character expression SHA730c2ff… as **CDP4272 Runtime.evaluate/context4**. All six expected call_id4272 stages are unique in the trace. Main-frame CommitLoad ties frame`0D3E2A37BA14241B129F5B493926F66C` to renderer8577; Browser PID7317. No Debugger/script-rundown identity or prior local script636 is imported.

| Same-run stage | Observed interval |
|---|---:|
| Browser forwarding start → renderer command entry |2062.575ms|
| Browser forwarding end → renderer entry |2062.071ms|
| Renderer command scope |9.593ms|
| Nested EvaluateScript |8.029ms|
| Largest command-contained CompileCode |5.799ms|
| Its nested ParseProgram |5.443ms|
| Node CDP4272 send-before → response |2077.753061ms|
| Original query return after the frozen failed verdict |1138.696031ms|

The one actual post-verdict clock_sync ts308585845µs is bracketed by Node157174.609907–157176.224279ms. Under the explicitly conditional equal-rate/fixed-offset approximation, Browser parsed HandleCommand maps to3.878758–5.493130ms after NodeCDPsend; renderer entry maps to1067.062544–1068.676916ms after the original failed verdict. JSON export quantization is kept separately. This is not raw pipe receipt, zero-forward delay, or a drift calibration.

The preceding same-main-thread **RunTask1854.235ms** (raw index96894) contains **v8.evaluateModule1814.182ms** (96895). Both have empty args; the module contains zero FunctionCall descendants, so this trace cannot name its module URL/owner. They must not be added together. A separate later `refreshTheme` call has explicit `site-native-controls.ts:102:24` metadata and78.990ms duration, with77.638ms Layout inside it. That separate event does not identify the long module or establish its cause.

The same-run first-role observer's terminal message reached Node181.442959ms before the original query, after observing one connected matching target with rolecombobox. It stops at first-role, so it does not continuously rule out replacement or later role changes. No physical paint or lifetime-owner conclusion follows.

Recorder auxiliary rows are128 retained/**88 dropped**; separate original SDK drops/errors are0 and all original protocol responses are mapped. Context/stream/session closure succeeds without unresolved trace ownership. The failure path ends tracing after original context close, and the actual late renderer/evaluation stages are present. No clean/zero-cost observation or complete whole-shard acceptance is claimed.

**0 evidence-integrity findings; partial/ABSTAIN.** The observed delay is localized to the forwarding-to-renderer-command boundary in this execution. Its empty-args work is not attributed to a C source owner, and no local passing control is substituted for this natural failure. All work here is offline analysis; no rerun, browser, source or API write.
