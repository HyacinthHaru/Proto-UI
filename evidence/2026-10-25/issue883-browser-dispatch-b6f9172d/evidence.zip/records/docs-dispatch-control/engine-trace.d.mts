export function createDocsEngineTrace(page: any, options: {
  directory: string;
  sdkRoot: string;
  label: string;
}): {
  prepare(): Promise<void>;
  markVerdict(snapshot: unknown): void;
  beforeOriginalContextClose(): void;
  finishAfterOriginalContextClose(contextClosed: boolean, snapshot: unknown): Promise<void>;
};
