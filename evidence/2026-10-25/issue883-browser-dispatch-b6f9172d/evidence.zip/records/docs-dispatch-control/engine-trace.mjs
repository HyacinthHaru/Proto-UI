// Private diagnostic arm. No evaluation, sourceURL, compileScript, or query replacement.
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

const categories = [
  'devtools',
  'devtools.timeline',
  'v8.execute',
  'disabled-by-default-devtools.timeline',
  'disabled-by-default-devtools.timeline.frame',
  'disabled-by-default-v8.compile',
  'disabled-by-default-devtools.v8-source-rundown',
];
const clock = () => ({ nodeMs: performance.now(), nodeTimeOrigin: performance.timeOrigin, dateNow: Date.now() });
const digest = (value) => createHash('sha256').update(value).digest('hex');
const reason = (error) => { try { return String(error).slice(0, 1000); } catch { return '[unreadable diagnostic error]'; } };
async function bounded(promise, ms, label) {
  let timer;
  try {
    return await Promise.race([promise, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${label}: observation budget expired`)), Math.max(1, ms));
    })]);
  } finally { clearTimeout(timer); }
}

export function createDocsEngineTrace(page, { directory, sdkRoot, label }) {
  const report = {
    kind: 'private-original-docs-engine-trace-v1', label, preparedAt: clock(),
    categories, sourceTextRundownRequested: false, setup: 'not-started',
    errors: [], dropped: { events: 0, contexts: 0, scripts: 0, errors: 0 },
    rows: [], contexts: [], scripts: [], frameNavigations: [], sourceComparisons: [],
    trace: { complete: false, dataLossOccurred: null, bytes: 0 },
    cleanup: { pageClosed: false, originalContextClosed: false, streamClosed: false,
      pageSessionDetached: false, browserSessionDetached: false },
    originalQueryChanged: false, extraQueryRPC: false, explicitRuntimeEvaluateCalls: 0,
    clocksCalibrated: false, pureCompileTime: false, browserReceivedObserved: false,
  };
  let browserSession, pageSession, traceOwned = false, traceEnd;
  let complete, stream, resolveComplete, verdict, observation, finishCalled = false, tailTimer;
  let mainFrameId, setupDeadline, sourceSettled = 0, directoryOwned = false;
  let traceStartPromise, traceStartState = 'not-sent', setupSettled = false, lateCleanupPromise;
  let lateCleanupRunning = false, lateCleanupAttempts = 0;
  const completePromise = new Promise((resolve) => { resolveComplete = resolve; });
  const listeners = [], sourceWork = new Map(), sources = new Map();
  const note = (stage, facts = {}) => {
    try {
      if (report.rows.length < 256) report.rows.push({ stage, ...clock(), ...facts });
      else report.dropped.events++;
    } catch { /* Diagnostic records cannot replace the original case. */ }
  };
  const error = (stage, value) => { try {
    if (report.errors.length < 64) report.errors.push({ stage, reason: reason(value), ...clock() });
    else report.dropped.errors++;
  } catch {} };
  const listen = (session, event, fn) => {
    const callback = (value) => { try { fn(value); } catch (e) { error(event, e); } };
    session.on(event, callback);
    listeners.push({ session, off: () => session.off(event, callback) });
  };
  const send = (session, method, params = {}, deadline = performance.now() + 2000) => {
    if (performance.now() >= deadline) return Promise.reject(new Error(`${method}: observation deadline already expired`));
    if (method === 'Tracing.start') traceStartState = 'pending';
    note('diagnostic.send', { method });
    let promise;
    try { promise = session.send(method, params); }
    catch (e) { if (method === 'Tracing.start') traceStartState = 'rejected'; error(method, e); return Promise.reject(e); }
    const observed = promise.then((value) => {
      note('diagnostic.return', { method });
      if (method === 'Tracing.start') {
        traceStartState = 'fulfilled'; traceOwned = true; report.trace.startACK = clock();
        if (finishCalled) lateCleanup();
      }
      if (method === 'Tracing.end') report.trace.endACK = clock();
      return value;
    },
      (e) => {
        if (method === 'Tracing.start') { traceStartState = 'rejected'; if (finishCalled) lateCleanup(); }
        error(method, e); throw e;
      });
    if (method === 'Tracing.start') traceStartPromise = observed;
    return bounded(observed, deadline - performance.now(), method);
  };
  const end = () => {
    if (!traceOwned || traceEnd) return traceEnd;
    note('trace.end.request');
    traceEnd = send(browserSession, 'Tracing.end').then(() => true, (e) => {
      error('trace.end', e); return false;
    });
    return traceEnd;
  };
  const removeListeners = (onlyBrowser) => {
    for (const entry of listeners) {
      if (!!(entry.session === browserSession) !== onlyBrowser || entry.removed) continue;
      try { entry.off(); entry.removed = true; } catch (e) { error('listener-remove', e); }
    }
  };
  const lateCleanup = () => {
    if (!report.cleanup.browserSessionDetachDeferred || lateCleanupPromise || lateCleanupRunning ||
      !finishCalled || !setupSettled || traceStartState === 'pending' || lateCleanupAttempts >= 2) return;
    lateCleanupRunning = true;
    const attempt = ++lateCleanupAttempts;
    lateCleanupPromise = (async () => {
      const late = { started: clock(), traceStartState, traceOwned, traceComplete: !!complete,
        streamClosed: false, browserSessionDetached: false, errors: [] };
      try {
        if (traceOwned && !complete) {
          await bounded(end(), 2000, 'late-trace-end');
          await bounded(completePromise, 2000, 'late-trace-complete');
        }
        late.traceComplete = !!complete;
        if (stream) { await send(browserSession, 'IO.close', { handle: stream }); late.streamClosed = true; stream = undefined; }
        if (pageSession && !report.cleanup.pageSessionDetached) {
          try { await bounded(pageSession.detach(), 1000, 'late-page-detach'); late.pageSessionDetached = true; }
          catch (e) { late.errors.push(reason(e)); }
        }
        if (browserSession) { await bounded(browserSession.detach(), 1000, 'late-browser-detach'); late.browserSessionDetached = true; }
        removeListeners(true);
      } catch (e) {
        late.errors.push(reason(e));
        // Keep the owned browser listener/session if completion is still unknown.
        // The original owned Browser close remains the final resource boundary.
      } finally {
        late.ended = clock();
        late.globalTraceOwnershipUnresolved = traceStartState === 'pending' || (traceOwned && !complete);
        if (directoryOwned) {
          try { await bounded(writeFile(path.join(directory, `late-cleanup-${attempt}.json`), JSON.stringify(late, null, 2), { flag: 'wx' }), 1000, 'late-cleanup-write'); }
          catch (e) { error('late-cleanup-write', e); }
        }
        note('late.cleanup', late);
        lateCleanupRunning = false;
      }
    })().catch((e) => { error('late-cleanup', e); });
  };
  const requestSources = () => {
    if (!verdict || !pageSession || report.cleanup.pageClosed || performance.now() >= verdict.nodeMs + 2000) return;
    // Hashes are supplied by the existing observer's POST-verdict snapshot.
    const expressions = observation?.expressionBindings ?? [];
    for (const expression of expressions) {
      if (expression.characters !== 305324 || typeof expression.sha256 !== 'string') continue;
      const matches = report.scripts.filter((script) => script.hash === expression.sha256 &&
        script.length === expression.characters && script.executionContextId === expression.contextId &&
        script.executionContextAuxData?.frameId === mainFrameId);
      if (matches.length !== 1) continue;
      const script = matches[0], key = `${script.executionContextId}:${script.scriptId}`;
      if (sourceWork.has(key)) continue;
      if (sourceWork.size >= 4) { report.sourceCandidateCapReached = true; continue; }
      const task = send(pageSession, 'Debugger.getScriptSource', { scriptId: script.scriptId }, verdict.nodeMs + 2000)
        .then((result) => {
          const text = result.scriptSource;
          if (typeof text !== 'string' || Buffer.byteLength(text) > 2 * 1024 * 1024)
            throw new Error('Missing or over-cap script source');
          const actualSHA256 = digest(Buffer.from(text, 'utf8'));
          const entry = { scriptId: script.scriptId, executionContextId: script.executionContextId,
            frameId: script.executionContextAuxData.frameId, originalExpression: expression,
            scriptParsedHash: script.hash, sourceSHA256: actualSHA256, characters: text.length,
            sourceMatchesOriginalSHAAndLength: actualSHA256 === expression.sha256 && text.length === expression.characters,
            file: `script-${script.executionContextId}-${script.scriptId}.js`, observed: clock() };
          sources.set(key, text); report.sourceComparisons.push(entry);
        }).catch((e) => { error('post-verdict.source-read', e); }).finally(() => { sourceSettled++; });
      sourceWork.set(key, task);
    }
  };
  const prepare = async () => {
    setupDeadline = performance.now() + 8000;
    report.setup = 'pending';
    try {
      const work = (async () => {
        await mkdir(path.dirname(directory), { recursive: true });
        await mkdir(directory);
        directoryOwned = true;
        const pkg = JSON.parse(await readFile(path.join(sdkRoot, 'package.json'), 'utf8'));
        if (pkg.version !== '1.58.2') throw new Error('Pinned Playwright version mismatch');
        report.sdk = { version: pkg.version, pins: [] };
        for (const file of ['types/protocol.d.ts', 'lib/server/dom.js', 'lib/server/chromium/crExecutionContext.js']) {
          report.sdk.pins.push({ file, sha256: digest(await readFile(path.join(sdkRoot, file))) });
        }
        const alive = () => { if (performance.now() >= setupDeadline) throw new Error('Setup deadline expired'); };
        alive(); browserSession = await page.context().browser().newBrowserCDPSession(); alive();
        listen(browserSession, 'Tracing.tracingComplete', (payload) => {
          complete = payload; stream = payload.stream; note('trace.complete', payload); resolveComplete(payload);
          if (finishCalled && report.cleanup.browserSessionDetachDeferred && !lateCleanupRunning) {
            lateCleanupPromise = undefined; lateCleanup();
          }
        });
        const version = await send(browserSession, 'Browser.getVersion', {}, setupDeadline);
        report.browserVersion = version;
        if (!/^(?:Headless)?Chrome\/155\.0\.8059\.39$/.test(version.product))
          throw new Error('Actual browser does not match run4 CFT155');
        alive(); pageSession = await page.context().newCDPSession(page); alive();
        listen(pageSession, 'Runtime.executionContextCreated', ({ context }) => {
          if (report.contexts.length < 128) report.contexts.push({ ...context, received: clock() });
          else report.dropped.contexts++;
        });
        listen(pageSession, 'Runtime.executionContextDestroyed', (value) => note('context.destroyed', value));
        listen(pageSession, 'Page.frameNavigated', ({ frame }) => {
          if (!frame.parentId) { mainFrameId = frame.id; report.frameNavigations.push({ id: frame.id, url: frame.url, received: clock() }); }
        });
        listen(pageSession, 'Debugger.scriptParsed', (script) => {
          if (report.scripts.length < 2048) report.scripts.push({
            scriptId: script.scriptId, executionContextId: script.executionContextId,
            executionContextAuxData: script.executionContextAuxData, hash: script.hash,
            length: script.length, url: script.url, hasSourceURL: script.hasSourceURL,
            isModule: script.isModule, received: clock(),
          }); else report.dropped.scripts++;
          requestSources();
        });
        listen(pageSession, 'Debugger.scriptFailedToParse', (value) => note('script.failed-to-parse', { scriptId: value.scriptId, executionContextId: value.executionContextId }));
        await send(pageSession, 'Page.enable', {}, setupDeadline);
        const frames = await send(pageSession, 'Page.getFrameTree', {}, setupDeadline);
        mainFrameId = frames.frameTree.frame.id;
        report.initialFrame = frames.frameTree.frame;
        await send(pageSession, 'Runtime.enable', {}, setupDeadline);
        await send(pageSession, 'Debugger.enable', {}, setupDeadline);
        // Domain setup is before goto. No context creation, script evaluation, pause, or warm query.
        await send(browserSession, 'Tracing.start', {
          transferMode: 'ReturnAsStream', streamFormat: 'json', streamCompression: 'none',
          traceConfig: { recordMode: 'recordUntilFull', traceBufferSizeInKb: 32768,
            includedCategories: categories, enableSampling: false },
        }, setupDeadline);
        alive(); report.setup = 'fulfilled'; note('setup.fulfilled');
      })().finally(() => { setupSettled = true; if (finishCalled) lateCleanup(); });
      await bounded(work, 8000, 'engine-setup');
    } catch (e) { report.setup = 'unavailable'; error('prepare', e); }
  };
  const closed = () => { report.cleanup.pageClosed = true; note('page.closed'); };
  page.once('close', closed); listeners.push({ session: page, off: () => page.off('close', closed) });
  return {
    prepare,
    markVerdict(snapshot) {
      try {
        verdict = { ...clock(), passed: snapshot?.verdict?.passed ?? null };
        observation = snapshot; report.originalObservationAtVerdict = snapshot;
        report.originalFrozenVerdict = snapshot?.verdict ?? null;
        report.diagnosticVerdictObserved = verdict; report.frameIdAtVerdict = mainFrameId;
        note('diagnostic.observed-already-frozen-verdict', verdict);
        requestSources();
        if (verdict.passed === true) end();
        else tailTimer = setTimeout(() => { note('trace.tail-cap'); end(); }, 2100);
      } catch (e) { error('mark-verdict', e); }
    },
    beforeOriginalContextClose() {
      try { clearTimeout(tailTimer); note('original.context-close.before-call'); end(); }
      catch (e) { error('context-close-marker', e); }
    },
    async finishAfterOriginalContextClose(contextClosed, snapshot) {
      if (finishCalled) return; finishCalled = true;
      const deadline = performance.now() + 8000;
      report.cleanup.originalContextClosed = contextClosed;
      report.originalObservationAfterContextClose = snapshot;
      report.captureStart = clock();
      const parts = [];
      try {
        await bounded(Promise.all([...sourceWork.values()]), Math.min(1500, deadline - performance.now()), 'source-settlement');
        if (traceStartState === 'pending' && traceStartPromise)
          await bounded(traceStartPromise, deadline - performance.now(), 'pending-trace-start');
        if (traceOwned) {
          await bounded(end(), deadline - performance.now(), 'trace.end');
          await bounded(completePromise, deadline - performance.now(), 'trace.complete');
          report.trace.tracingComplete = complete;
          report.trace.dataLossOccurred = complete.dataLossOccurred;
          if (!stream) throw new Error('Trace complete lacked stream');
          let eof = false;
          while (!eof && performance.now() < deadline) {
            const remaining = 32 * 1024 * 1024 - report.trace.bytes;
            const read = await send(browserSession, 'IO.read', { handle: stream, size: Math.min(262144, remaining + 1) }, deadline);
            const bytes = Buffer.from(read.data, read.base64Encoded ? 'base64' : 'utf8');
            parts.push(bytes.subarray(0, remaining)); report.trace.bytes += Math.min(bytes.length, remaining);
            if (bytes.length > remaining) { report.trace.byteCapExceeded = true; throw new Error('Trace exceeded 32MiB; retained prefix is incomplete'); }
            eof = read.eof;
          }
          report.trace.complete = eof;
          if (!eof) throw new Error('Trace read did not reach EOF within capture budget');
        }
      } catch (e) { error('capture', e); }
      finally {
        clearTimeout(tailTimer);
        if (stream) {
          try { await send(browserSession, 'IO.close', { handle: stream }); report.cleanup.streamClosed = true; }
          catch (e) { error('stream-close', e); }
        }
        const deferBrowser = !setupSettled || traceStartState === 'pending' || (traceOwned && !complete);
        report.cleanup.globalTraceOwnershipUnresolved = traceStartState === 'pending' || (traceOwned && !complete);
        report.cleanup.setupStillPending = !setupSettled;
        report.cleanup.browserSessionDetachDeferred = deferBrowser;
        report.trace.startStateAtCapture = traceStartState;
        removeListeners(false);
        if (!deferBrowser) removeListeners(true);
        for (const [session, key] of [[pageSession, 'pageSessionDetached'], [browserSession, 'browserSessionDetached']]) {
          if (!session) continue;
          if (session === browserSession && deferBrowser) continue;
          try { await bounded(session.detach(), 1000, key); report.cleanup[key] = true; }
          catch (e) { error(key, e); }
        }
        report.captureEnd = clock();
        report.trace.ownershipACK = traceOwned;
        report.pendingSourceObservations = sourceWork.size - sourceSettled;
        try {
          if (!directoryOwned) throw new Error('Output directory ownership was not acquired; no evidence files overwritten');
          const bytes = Buffer.concat(parts); report.trace.sha256 = parts.length ? digest(bytes) : null;
          await bounded((async () => {
            await mkdir(directory, { recursive: true });
            if (parts.length) await writeFile(path.join(directory, 'trace.json'), bytes);
            for (const [key, text] of sources) {
              const [contextId, scriptId] = key.split(':');
              await writeFile(path.join(directory, `script-${contextId}-${scriptId}.js`), text);
            }
            report.boundaries = [
              'Real original Docs case and request; Debugger/Tracing setup changes the environment and adds cost.',
              'Setup before goto; no extra await or query RPC between goto and original role poll.',
              'Source retrieval only after the frozen verdict and may perturb late settlement. No original promise/return/error is replaced.',
              'Actual expression SHA/length/context comes from existing same-call observer, not a synthetic expression or predicted wire ID.',
              'Trace is page navigation through query verdict/its bounded tail, not an otherwise idle renderer.',
              'Node callbacks and trace timestamps are different clocks; no clock calibration or BrowserReceived is claimed.',
              'ScriptCatchup can bind script/context/isolate/process. Empty-args compile/evaluate spans remain unbound; no pure compile duration.',
              'Observation timeouts do not cancel underlying protocol or file operations; pending/cleanup failures remain debt.',
              'Original frozen verdict and later diagnostic observation clocks are separate. A detached session is not proof of a completed global trace.',
              'Pending setup/Tracing.start retains owned browser listener/session for at most two event-driven late cleanup attempts; immutable late-cleanup-N.json does not rewrite this snapshot.',
            ];
            await writeFile(path.join(directory, 'report.json'), JSON.stringify(report, null, 2));
          })(), 2000, 'write-evidence');
        } catch (e) { error('write-evidence', e); }
        try { console.log('[Docs engine trace]', JSON.stringify({ label, setup: report.setup, trace: report.trace, cleanup: report.cleanup, errors: report.errors.length, dropped: report.dropped })); } catch {}
        if (report.cleanup.browserSessionDetachDeferred) lateCleanup();
      }
    },
  };
}
