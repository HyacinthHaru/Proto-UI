The four hosted Brutalist JSON files describe the same original **family-commit rejection**, on synthetic checkout `b670e5872a6e13c3fda248939aee1c4614e4a930`. The now-fetched local Git objects independently confirm its tree `6e56e93b71b51f18957aa7053088ec95e358b624` equals head `1a66399f9bb593717e4b9b70ac4bc0ec36fc510f`. Four selected archive members and their CRC/SHA/bytes match the extracted originals; all ten pinned SDK source hashes match the installed Playwright1.58.2 files. No PNG was read.

Using only the three post-verdict calibration RPC brackets gives a conditional Node-minus-browser offset intersection of **[117341.779462,117346.338399]ms**. This applies a constant-offset/equal-rate approximation backward into the query window; it is not a complete drift calibration or physical-paint measurement.

| Observation | Conditional Node interval, ms | Relative to observed rejection |
|---|---:|---:|
| Original dataset writer bracket, browser3583.2–3583.3 | 120924.979462–120929.638399 | 145.758903–150.417840ms before |
| MO delivery, browser3717.5 | 121059.279462–121063.838399 | 11.558903–16.117840ms before |
| Third utility original getter observation, browser3917.9 | 121259.679462–121264.238399 | 184.282160–188.841097ms after |

The measured rejection timestamp is **121075.397302ms**. Outer start+1000 is **121075.001180ms**, a separate reference, not a captured internal matcher timer deadline. Ledger freeze and SDK verdict observation are later samples and are preserved separately.

The three original values are `shadcn`, `shadcn`, then `brutalist`. Original query3 starts at120462.329836 and returns at121265.412020ms: **803.082184ms elapsed**, **190.014718ms after rejection**. Exact mapping is query3→`call@2044`→attempt1→`Runtime.callFunctionOn`7873. Its injected-script cache is already present; observed resolve-enter→fulfilled is0.173092ms, including patch through exit0.185315ms. Captured requests contain three callFunctionOn calls and no Runtime.evaluate injection.

For request7873, Node send-before→response is **801.213969ms**; local transport send-return is **0.155720ms** and matched complete-frame queued→callback is **0.466498ms**. Both write calls returned true with zero Node writableLength/no drain needed. These are Node boundary observations, not browser receipt, pure network/pipe time or engine queue/compile attribution. Browser selector work samples0.5ms. SDK getter work samples0.1ms but `getterNative=false` because it forwards through the existing utility observer; the utility observer's original native read has equal sampled timestamps. Neither measurement establishes zero cost or a clock tick length.

All three same-call mappings complete, with zero recorded drops/errors, no extra original query RPC, the utility descriptor restored/session detached, dataset writer restored and SDK disposed. The source's conservative **transportComplete=false** remains unchanged. The later failure snapshot shows generation2/Brutalist ready, but cannot be backdated or promoted to visual/whole-transaction acceptance.

**0 specific findings; partial / ABSTAIN.** This supports the stated conditional ordering and request identity. It does not identify the Chromium cause, prove complete drift calibration, or change the original1s failure verdict. No API, test, browser, source edit, new probe or image review was performed.
