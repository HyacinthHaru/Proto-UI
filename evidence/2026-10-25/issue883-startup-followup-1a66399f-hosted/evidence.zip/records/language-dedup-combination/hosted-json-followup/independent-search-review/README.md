# Exact1a hosted Search timing review

**Partial / ABSTAIN.** The selected shard2 originals bind synthetic `b670e587` to tree `6e56e93b` and parents main357 plus product1a. They are a new canonical run. The tables do not import local-positive or older718 timing.

Ten Docs records contain **9 original failed verdicts and 1 passed verdict (Brutalist390)**. Each has one original query/call, one matching browser attempt, three matched CDP exchanges and actual `combobox` getter output. Source guards pass, selected instruments report no drops/errors, and all contexts/observer disposal are recorded complete.

| Docs case | Original verdict | Verdict from query ms | First injected evaluate send→response ms | Original return minus verdict ms | First-role Node receipt minus query ms | Browser selector/getter sampled ms |
|---|---|---:|---:|---:|---:|---:|
| brutalist-1280 | FAIL | 999.707 | 1272.223 | +291.729 | -328.845 | 3.700 / 0.000 |
| brutalist-1440 | FAIL | 1000.544 | 1218.158 | +235.012 | -328.391 | 4.100 / 0.000 |
| brutalist-2048 | FAIL | 1000.840 | 1499.310 | +519.647 | -318.675 | 3.200 / 0.000 |
| brutalist-320 | FAIL | 999.868 | 1292.481 | +383.866 | -327.662 | 4.100 / 0.100 |
| brutalist-390 | pass | 969.376 | 949.100 | -0.057 | -327.872 | 4.500 / 0.000 |
| shadcn-1280 | FAIL | 1000.037 | 2073.438 | +1137.574 | -221.558 | 5.100 / 0.000 |
| shadcn-1440 | FAIL | 1000.279 | 2043.376 | +1104.005 | -208.497 | 4.800 / 0.000 |
| shadcn-2048 | FAIL | 999.611 | 2099.348 | +1160.162 | -222.669 | 5.200 / 0.000 |
| shadcn-320 | FAIL | 1000.405 | 1985.202 | +1053.183 | -217.047 | 5.900 / 0.000 |
| shadcn-390 | FAIL | 1000.050 | 1680.947 | +734.271 | -236.537 | 5.300 / 0.000 |

All nine failures freeze while the first305324-character injected-script evaluation is still awaiting its matched Node response. Frame/context acquisition and selector parsing have already returned; subsequent utility-script/getter operations occur after that first response. The large expression SHA is730c2ff1… in every record. Native getter sample spans do not account for the1s matcher failures. The per-CDP JSON table records both original write returns, any matching whole-stream drain, response-completion chunk, scheduler call, callback and response callback.

| Failed Docs case | First evaluate transport→last write ms | Last write→matching response completion chunk ms | Frame scheduler→callback ms | Whole-stream drain after last write ms |
|---|---:|---:|---:|---:|
| brutalist-1280 | 1.294 | 1270.788 | 0.035 | 0.862 |
| brutalist-1440 | 3.531 | 1214.506 | 0.033 | not observed; writes returned true |
| brutalist-2048 | 1.323 | 1497.869 | 0.031 | 0.675 |
| brutalist-320 | 2.665 | 1289.544 | 0.056 | 3.564 |
| shadcn-1280 | 1.169 | 2072.164 | 0.026 | 0.888 |
| shadcn-1440 | 1.840 | 2041.406 | 0.036 | 0.701 |
| shadcn-2048 | 1.654 | 2097.593 | 0.024 | 0.542 |
| shadcn-320 | 1.589 | 1983.152 | 0.050 | 0.827 |
| shadcn-390 | 1.197 | 1679.568 | 0.036 | 0.690 |

These are Node observations, not browser receipt or pure engine time. A drain is not a command ACK; the recorded read chunk contains the matching response delimiter but is not necessarily its first byte. Nested SDK intervals must not be added together. Extra taps/reactions/logging have cost. Browser clocks are separate, and zero sampled duration means equal ticks.

| Readiness case | Entry minus original deadline ms | First exact target observation minus deadline ms | First fully-ready observation minus deadline ms | Original target/getter sample |
|---|---:|---:|---:|---|
| brutalist-dark-1440 | 371 | 435 | 435 | 0 targets; getter timestamps null |
| brutalist-dark-390 | 95 | 157 | 157 | 0 targets; getter timestamps null |
| brutalist-light-1440 | 343 | 398 | 398 | 0 targets; getter timestamps null |
| brutalist-light-390 | 17 | 69 | 69 | 0 targets; getter timestamps null |
| shadcn-dark-1440 | 1243 | 1405 | 1405 | 0 targets; getter timestamps null |
| shadcn-dark-390 | 736 | 906 | 906 | 0 targets; getter timestamps null |
| shadcn-light-1440 | 1084 | 1254 | 1254 | 0 targets; getter timestamps null |
| shadcn-light-390 | 1221 | 1341 | 1341 | 0 targets; getter timestamps null |

All eight readiness cases remain false under their original1000ms windows. The post-failure/late journals agree on firstTarget and firstFullyReady, with current owner/generation checked and no recorded target-journal drops/errors. These are observer-delivery samples under the existing DateNow epoch convention, not calibrated physical mutation/paint times. The late observations cannot fill the earlier original window.

The retained ZIP hash was recomputed and the42 analyzed JSON files were individually compared with their original ZIP members and CRCs. Media/CPU profiles were not read or extracted. The complete370-member CRC claim remains the prior download receipt's scope. No new test, browser, API, product change or public write occurred; no production root cause is established.
