# Actual a9 screencast/screenshot control review

**Partial / ABSTAIN.** The actual launcher ran the private driver against clean tracked head `a9cafe3a`, tree `f7cb33cb`, and ended with exit 1. Source and extra-input snapshots remained stable. The six critical sources match immutable Git objects. This review did not run a browser or test.

| Arm | Screencast | Recorded screenshot budget (ms) | Observed budget wait (ms) | PNG returned |
|---|---|---:|---:|---|
| 1 | on | 20000.000 | 20000.628 | No |
| 2 | off | 20000.000 | 20002.133 | No |
| 3 | off | 20000.000 | 20000.041 | No |
| 4 | on | 14573.325 | 14574.283 | No |

The fourth arm had only 14,573.325 ms remaining in the global work budget. It was not a fourth equally timed 20-second trial. The control uses a 225-second work budget, 15-second cleanup reserve and 240-second hard limit; these are separate from the original S4 test’s 150-second deadline.

All four arms completed the first light/default trigger and Switch/Checkbox prefix, then waited in `page.screenshot`. DEBUG reported fonts loaded in each arm. The records do not identify the subsequent internal capture, rendering, encoding or IPC stage. All four screenshot Promises later rejected during context cleanup; no screenshot PNG returned or was saved. The 78 and 74 screencast frame events in the two enabled arms are separate observations, not returned screenshot images.

Both disabled arms also failed to return a screenshot within 20 seconds. This gives no evidence that screencast alone explains the non-return, or that removing it fixes the screenshot. It does not exclude a contribution from screencast or establish the disabled outcome at the original 150-second deadline. The browser and dev server were shared across the sequential fresh contexts.

Every context close event and return was confirmed. The enabled arms stopped screencast; browser close/disconnection and server stop were recorded. Both tracked child processes exited: corepack/server through SIGTERM and Chrome with code 0. There is no recorded SIGKILL request, kill error or hard-limit event. The final owned-child sweep was invoked, but the records show no forced kill was needed. This is not a global process or socket leak audit.

The 24 page errors in each arm and all negative results remain preserved. This control exercises only the first prefix, not the original 24-path paint acceptance journey.
