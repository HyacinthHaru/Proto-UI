// Private 4-context control, not the original 24-path S4 acceptance suite.
import { createRequire, syncBuiltinESMExports } from 'node:module';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { dirname, join, resolve, basename } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const directory = dirname(fileURLToPath(import.meta.url));
const plan = JSON.parse(readFileSync(join(directory, 'source-plan.json'), 'utf8'));
const workdir = plan.workdir;
const output = resolve(process.argv[2] || join(directory, 'observed'));
if (!output.startsWith(directory + '/') || existsSync(output)) throw new Error('Fresh private output required');
mkdirSync(output, { recursive: true });
const require = createRequire(pathToFileURL(join(workdir, 'apps/www/package.json')));
const cp = require('node:child_process');
const sha = (data: string | Buffer) => createHash('sha256').update(data).digest('hex');
const now = () => ({ at: new Date().toISOString(), nodeMs: performance.now(), nodeTimeOrigin: performance.timeOrigin });
const startMs = performance.now();
const hardDeadline = startMs + 240_000;
const workDeadline = hardDeadline - 15_000;
const report: any = { kind: 'private-s4-screencast-screenshot-control', start: now(), bounds: { screenshotMs: 20_000, operationMs: 30_000, hardMs: 240_000, cleanupReserveMs: 15_000 }, order: ['on', 'off', 'off', 'on'], arms: [], events: [], ownedChildren: [], scope: 'Full original Demo Matrix and first light/default prefix; not original24-path acceptance, no oracle repair.', errors: [] };
let stopping = false;
let activeContext: any;
let browser: any;
let stopServer: any;
let lateResults = 0;
const persist = () => { try { writeFileSync(join(output, 'report.json'), JSON.stringify(publicReport(), null, 2) + '\n'); } catch {} };
const note = (stage: string, extra: any = {}) => { try { const row = { stage, ...now(), ...extra }; report.events.push(row); console.info('[paint-control]', JSON.stringify(row)); } catch {} };
const originalSpawn = cp.spawn;
cp.spawn = function (...args: any[]) {
  if (stopping) throw new Error('Private control is stopping');
  const child = Reflect.apply(originalSpawn, this, args);
  const options = args.findLast((value: any) => value && typeof value === 'object' && !Array.isArray(value));
  const owned: any = { pid: child.pid ?? null, command: basename(String(args[0])), detached: options?.detached === true, exited: false };
  report.ownedChildren.push(owned);
  child.once('exit', (code: any, signal: any) => { owned.exited = true; owned.code = code; owned.signal = signal; persist(); });
  owned.child = child;
  return child;
};
syncBuiltinESMExports();
// Never serialize child objects or environment values.
const publicReport = () => ({ ...report, ownedChildren: report.ownedChildren.map(({ child, ...row }: any) => row) });
const save = () => { try { writeFileSync(join(output, 'report.json'), JSON.stringify(publicReport(), null, 2) + '\n'); } catch {} };
const forceOwned = () => {
  stopping = true;
  for (const owned of report.ownedChildren) {
    if (!owned.pid || owned.exited || owned.child.exitCode !== null || owned.child.signalCode !== null) continue;
    try { process.kill(owned.detached ? -owned.pid : owned.pid, 'SIGKILL'); owned.forceKillRequested = now(); } catch (error) { owned.killError = String(error); }
  }
};
const hardTimer = setTimeout(() => {
  report.hardLimitReached = true;
  note('hard-limit');
  try { void stopServer?.().catch(() => {}); } catch {}
  forceOwned(); save(); process.exit(124);
}, 240_000);
async function bounded<T>(stage: string, run: () => Promise<T>, limit = 30_000, cleanup = false): Promise<T> {
  const remaining = (cleanup ? hardDeadline : workDeadline) - performance.now();
  if (remaining <= 0) throw new Error('Private control deadline reached');
  const budget = Math.min(limit, remaining);
  note(stage + '.begin', { budgetMs: budget });
  let timer: ReturnType<typeof setTimeout>;
  let expired = false;
  const promise = run();
  promise.then(() => { if (expired) { lateResults++; note(stage + '.late-return'); } }, () => { if (expired) { lateResults++; note(stage + '.late-error'); } });
  try {
    const result = await Promise.race([promise, new Promise<never>((_, reject) => { timer = setTimeout(() => { expired = true; reject(new Error(stage + ': control budget expired')); }, budget); })]);
    note(stage + '.return'); return result;
  } catch (error) { note(stage + '.error', { message: String(error), controlBudgetExpired: expired }); throw error; }
  finally { clearTimeout(timer!); }
}
function sourceSnapshot() {
  return plan.sources.map((row: any) => ({ path: row.path, sha256: sha(readFileSync(join(workdir, row.path))) }));
}
let exitCode = 0;
try {
  const head = cp.execFileSync('git', ['rev-parse', 'HEAD'], { cwd: workdir, encoding: 'utf8' }).trim();
  if (head !== plan.expectedHead) throw new Error('Unexpected source HEAD');
  report.head = head; report.sourceBefore = sourceSnapshot();
  for (const row of report.sourceBefore) if (row.sha256 !== plan.sources.find((x: any) => x.path === row.path).expectedSHA256) throw new Error('Restore private producer overrides before this control: ' + row.path);
  report.playwright = require('playwright-core/package.json').version;
  if (report.playwright !== '1.58.2' || process.platform !== 'darwin') throw new Error('Expected pinned local PW1.58.2/macOS control');
  report.node = process.version; report.platform = process.platform;
  const harness = await import(pathToFileURL(join(workdir, 'apps/www/src/content/docs/zh-cn/browser-harness.ts')).href);
  stopServer = harness.stopServer;
  if (process.env.PROTO_UI_BROWSER_BASE_URL) throw new Error('This control requires its own complete dev server');
  const baseUrl = await bounded('server.start', () => harness.startServer('/zh-cn/internal/demo-matrix/'));
  browser = await bounded('browser.launch', () => harness.launchBrowser());
  report.browserVersion = browser.version(); report.baseUrl = baseUrl;
  for (let index = 0; index < 4; index++) {
    const enabled = index === 0 || index === 3;
    const arm: any = { index, screencast: enabled, start: now(), pageErrors: [], consoleErrors: [], prefix: [], screenshot: { invoked: false }, cleanup: {} };
    report.arms.push(arm);
    const label = `arm${index + 1}-${enabled ? 'on' : 'off'}`;
    const armDir = join(output, label); mkdirSync(armDir);
    let context: any; let cdp: any; let onFrame: any; let castStarted = false; let closeObserved = false;
    try {
      context = await bounded(label + '.new-context', () => browser.newContext({ viewport: { width: 1100, height: 900 }, colorScheme: 'light' }));
      activeContext = context; context.on('close', () => { closeObserved = true; arm.cleanup.closeEvent = now(); });
      const page = await bounded(label + '.new-page', () => context.newPage());
      page.setDefaultTimeout(30_000); page.setDefaultNavigationTimeout(30_000);
      page.on('pageerror', (error: any) => { if (arm.pageErrors.length < 64) arm.pageErrors.push(error.message); });
      page.on('console', (message: any) => { if (message.type() === 'error' && arm.consoleErrors.length < 64) arm.consoleErrors.push(message.text()); });
      await bounded(label + '.goto', () => page.goto(`${baseUrl}/zh-cn/internal/demo-matrix/#shadow-split-s4`));
      await bounded(label + '.ready', () => page.locator('[data-shadow-s4][data-ready=true]').waitFor());
      cdp = await bounded(label + '.cdp', () => page.context().newCDPSession(page));
      const frames: any[] = [], paths: any[] = [];
      let activePath: any = null;
      const originalOnFrame = (event) => {
    if (activePath)
      frames.push({
        path: activePath,
        time: event.metadata.timestamp * 1000,
        png: Buffer.from(event.data, 'base64'),
      });
    void cdp.send('Page.screencastFrameAck', { sessionId: event.sessionId }).catch(() => {});
  };
      arm.frameEvents = 0;
      onFrame = (event: any) => { arm.frameEvents++; return originalOnFrame(event); };
      await bounded(label + '.markers', () => page.evaluate(() => {
    window.__s4Paint = { events: [] };
    for (const content of document.querySelectorAll('[data-s4-part=content]')) {
      const marker = document.createElement('span');
      marker.dataset.s4PaintMarker = '';
      marker.setAttribute('aria-hidden', 'true');
      marker.style.cssText =
        'position:absolute;left:26px;top:26px;width:16px;height:16px;background:rgb(255,0,255);pointer-events:none';
      content.append(marker);
    }
    const observer = new MutationObserver((records) => {
      for (const r of records) {
        if (!r.target.matches?.('[data-s4-part=content]')) continue;
        __s4Paint.events.push({
          time: Date.now(),
          profile: r.target.dataset.s4Profile,
          detached: r.target.hasAttribute('data-pui-view-detached'),
          open: r.target.hasAttribute('data-open'),
        });
      }
    });
    observer.observe(document.body, {
      subtree: true,
      attributes: true,
      attributeFilter: ['data-pui-view-detached'],
    });
    __s4Paint.observer = observer;
  }));
      cdp.on('Page.screencastFrame', onFrame);
      if (enabled) {
        await bounded(label + '.start-screencast', () => cdp.send('Page.startScreencast', { format: 'png', maxWidth: 1100, maxHeight: 900, everyNthFrame: 1 }));
        castStarted = true;
      }
      const profile = 'light'; const setting = 'default';
      const part = (key: string) => page.locator(`[data-s4-profile=${profile}][data-s4-part=${key}]`);
      const control = (key: string) => part('content').locator(`[data-s3-component=${key}]`);
      await bounded(label + '.trigger-click', () => part('trigger').click()); arm.prefix.push('trigger.click');
      await page.waitForTimeout(350); arm.prefix.push('original350ms');
      for (const key of ['switch', 'checkbox']) {
        const checked = setting === 'both' || setting === key;
        const value = await bounded(label + '.' + key + '.read', () => control(key).getAttribute('aria-checked'));
        arm.prefix.push({ key, ariaChecked: value, expectedChecked: checked });
        if ((value === 'true') !== checked) { await bounded(label + '.' + key + '.click', () => control(key).click()); arm.prefix.push(key + '.click'); }
      }
      await page.waitForTimeout(250); arm.prefix.push('original250ms');
      for (const key of ['switch', 'checkbox']) {
        const value = await bounded(label + '.' + key + '.retained-read', () => control(key).getAttribute('aria-checked'));
        if (value !== String(setting === 'both' || setting === key)) throw new Error('Original retained Maker input mismatch: ' + key);
      }
      arm.screenshot.invoked = true; arm.screenshot.start = now();
      const png: any = await bounded(label + '.screenshot', () => page.screenshot(), 20_000);
      const file = join(armDir, 'screenshot.png'); writeFileSync(file, png);
      arm.screenshot = { ...arm.screenshot, returned: true, end: now(), path: file, bytes: png.length, sha256: sha(png) };
      arm.outcome = 'screenshot-returned';
    } catch (error) { arm.outcome = 'control-error'; arm.error = String(error); exitCode = 1; }
    finally {
      if (castStarted && cdp) {
        try { await bounded(label + '.stop-screencast', () => cdp.send('Page.stopScreencast'), 2_000, true); arm.cleanup.screencastStopped = true; }
        catch (error) { arm.cleanup.stopError = String(error); }
      }
      if (context) {
        try { await bounded(label + '.context-close', () => context.close(), 4_000, true); arm.cleanup.closeReturned = true; }
        catch (error) { arm.cleanup.closeError = String(error); }
      }
      if (cdp && onFrame) cdp.off('Page.screencastFrame', onFrame);
      arm.cleanup.confirmed = !!(arm.cleanup.closeReturned && closeObserved);
      arm.end = now(); save();
      activeContext = undefined;
    }
    if (!arm.cleanup.confirmed) { report.stoppedAfterUnconfirmedCleanup = index; break; }
    if (performance.now() >= workDeadline) { report.workBudgetExhausted = true; break; }
  }
} catch (error) { exitCode = 1; report.errors.push(String(error)); }
finally {
  stopping = true;
  if (activeContext) { try { await bounded('final.context-close', () => activeContext.close(), 2_000, true); } catch {} }
  if (browser) {
    try { await bounded('browser.close', () => browser.close(), 3_000, true); report.browserCloseReturned = true; }
    catch (error) { report.browserCloseError = String(error); }
    report.browserDisconnected = !browser.isConnected();
  }
  if (stopServer) { try { await bounded('server.stop', () => stopServer(), 6_000, true); report.stopServerReturned = true; } catch (error) { report.stopServerError = String(error); } }
  forceOwned();
  await new Promise((resolve) => setTimeout(resolve, Math.max(0, Math.min(1000, hardDeadline - performance.now()))));
  report.allOwnedChildrenExited = report.ownedChildren.every((row: any) => row.exited || !row.pid);
  report.sourceAfter = sourceSnapshot(); report.criticalSourceStable = JSON.stringify(report.sourceAfter) === JSON.stringify(report.sourceBefore);
  report.lateResults = lateResults; report.end = now(); report.actualArms = report.arms.length;
  report.completeMirroredOrder = report.arms.length === 4 && report.arms.every((arm: any) => arm.cleanup.confirmed);
  if (!report.allOwnedChildrenExited || !report.criticalSourceStable || !report.completeMirroredOrder) exitCode = 1;
  cp.spawn = originalSpawn; syncBuiltinESMExports(); clearTimeout(hardTimer); save();
}
process.exit(exitCode);
