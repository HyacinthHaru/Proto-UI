已完整核对 c08e535c632cb703f096cde16ec20786f9914ead：实际 tree 为 4d407e73ffe43845d3dd9c20ff5d388349ea47d8，双父为 a9cafe3a 与 357068f0。SSH G、HyacinthHaru 身份、DCO、无 co-author 均由实际 Git 对象确认。

准备树 2fc2ccbc 与实际提交树不相等；唯一差异是 internal/compiler/website-demo-migrations.json。完整两份 JSON 均成功解析、无重复 key、deep equal，且移除字符串外的 JSON whitespace 后所有 lexical bytes 完全相等，确认仅格式差异。未运行 generator/formatter。

原 own7 的 mode/type/blob 全等 a9；新 main11 路径除该 inventory 外，其余10（含一个删除）全等357。完整准备树等于两组不相交变更的三方组合；实际树仅多 inventory 格式化这一项。相对357的净差异为 own7 + inventory，共8路径；不是最初预期树成功提交的声明。当前未提交两测试改动独立于这个 Git commit 审计。

原 PublicationUnknown 与历史保留，没有重试 commit/push，没有新执行验证或外部写。partial / ABSTAIN。