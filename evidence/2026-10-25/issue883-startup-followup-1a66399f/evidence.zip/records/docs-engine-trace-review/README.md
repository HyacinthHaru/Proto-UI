最终私有准备稿 helper 2e55162c、caller 59a154fc 已只读复核，初稿两项 P3 在本版本静态关闭，原初稿与 initial-review 保留。结论 partial / ABSTAIN，不是执行或 GitHub 批准。

原 a9 caller bytes 与 Git 对象一致；所有原 matcher、输入/getter、poll/wait、case/timeout 表达式和原 await 顺序保持。只增加 goto 前 setup await 和原 context.close 之后 capture await。原 getAttribute 的参数、Promise、1s matcher、2s failed-query drain 与 180s case 均未改。无 synthetic Runtime.evaluate/warmup/sourceURL。

修订版将原 frozen verdict 与稍后 diagnostic observation clocks 分开。Tracing.start 原 Promise/state 单列；超预算未结算会保留 browser listener/session 并明确债务，迟到事件最多触发两次有界自有清理，另写 immutable late-cleanup receipt。detach 不再等于 trace completed。没有运行过迟到 ACK 控制，实际 cleanup 仍必须以本次记录和 owned Browser 结束对账，不能从静态实现承诺成功。

身份匹配要求原 source SHA/context/frame/process/isolate/script 的明确记录。空 args 编译/evaluate span 不能靠 scriptId 或时序重叠绑定。无 Node/trace 时钟校准或纯 compile/browser-receipt 证明。8s 是主 capture 预算，随后 cleanup/write 和 event-driven late cleanup 分别有界，不是整个尾段 8s hard wall。观察开销、caps、loss、unavailable 与原失败都必须保留。
