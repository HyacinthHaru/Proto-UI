import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { launchBrowser, startServer, stopServer } from '<WORKTREE>/apps/www/src/content/docs/zh-cn/browser-harness.ts';
const out=process.argv[2];
await mkdir(out,{recursive:false});
const report:any={kind:'supplementary-real-nojs-Hero-preview',started:new Date().toISOString(),javaScriptEnabled:false,cases:[],cleanup:{}};
let browser:any,context:any;
const watchdog=setTimeout(()=>{report.error='180sprivatecapturebound';void writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2)).finally(()=>process.exit(2));},180000);
try {
 const base=await startServer('/zh-cn/');
 browser=await launchBrowser();
 for(const viewport of [{width:390,height:844},{width:1440,height:1000}]) {
  context=await browser.newContext({javaScriptEnabled:false,viewport});
  const page=await context.newPage();
  await page.goto(base+'/zh-cn/',{waitUntil:'networkidle',timeout:30000});
  const anchor=page.locator('#homepage-hero-actions [data-homepage-fallback] a[href="#home-demo-previewer"]');
  const facts=await anchor.evaluateAll((anchors)=>anchors.map(a=>({text:a.textContent?.trim(),href:a.getAttribute('href'),variant:a.getAttribute('data-home-action-variant'),icon:a.getAttribute('data-home-action-icon'),svgs:a.querySelectorAll('svg').length,rect:a.getBoundingClientRect().toJSON()})));
  const file=`hero-nojs-${viewport.width}.png`;
  await page.screenshot({path:path.join(out,file),fullPage:true,timeout:15000});
  report.cases.push({viewport,facts,screenshot:file,capturedAt:new Date().toISOString(),applicationJS:false,automationReadViaCDP:true});
  await context.close();context=null;
 }
} catch(e:any) {report.error={name:e.name,message:e.message};process.exitCode=1;}
finally {
 if(context)try{await context.close();report.cleanup.context=true;}catch(e){report.cleanup.context=false;}
 try{await browser?.close();report.cleanup.browser=true;}catch(e){report.cleanup.browser=false;}
 try{await stopServer();report.cleanup.server=true;}catch(e){report.cleanup.server=false;}
 report.finished=new Date().toISOString();await writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');clearTimeout(watchdog);
}
