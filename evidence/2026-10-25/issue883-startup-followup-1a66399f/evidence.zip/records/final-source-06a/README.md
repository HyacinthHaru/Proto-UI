准确06a source/evidence binding已核，0 open finding，partial / ABSTAIN。实际head06a752a861b0ceaaa549f1a019d7b15c5ea4178b、treeb7abb50ab9ac82966c594504e442a1dfef525e22、parentc08e535c。SSH G、HyacinthHaru作者/提交者及允许邮箱、DCO、无co-author均由实际Git对象确认。

提交仅两测试16+/4-，两个committed blob逐字等此前绿色saved candidate（homepage56d91599，home-demoe5446ecf），其它parent文件mode/type/blob不变。对accepted357净10路径，准确分为原own7、已独立核完整JSON语义相等的inventory格式差异、两新C测试；不是忽略hook实际树变化。

同c08父的原始baseline实际0pass3fail17filtered，候选实际3pass17filtered。两次选择case及除outputFile外命令相同，完整tracked census只差这两测试。实际时间顺序是先候选绿06:24:54–06:25:32、后基线红06:27:06–06:27:34，不伪称按红→绿顺序执行。旧a9诊断红与两次c08运行分源。

unit-main357实际8files86/0/0，types-main357实际968/0/0/14，都是c08+两dirty候选的提交前运行。它们与focused candidate完整tracked census相等、两目标文件hash等06a提交内容，但不改标postcommit执行，也不把census说成全部环境/依赖闭包。准确06a完整native、当前CI/preview及Docs私有控制另待实际结果。