The exact clean-c5 full combination ran 2026-10-25T06:53:31.456706+00:00–2026-10-25T07:16:47.046015+00:00 on `c5ed7028d9961672344628acc81445833a820529` / tree `9286d9ed27ebaf377803d2620296e37b219273c5`. Actual result: **14 files,297 tests,294 pass /3 fail /0 skip**, exit1. The three failures are the two S4 locale cases and the paint case, all original150s timeouts. Receipt records clean before/after, sourceStable/extraInputsStable and11,495tracked inputs. These are this run's values, not relabeled a9/candidate43/private-trace results.

Search30 passed, including all10 Docs role cases. Each Docs window has one original call/attempt and three actual CDP pairs; all mappings complete, no captured errors/drops/pending requests, context closed and observer disposed. The ten captured SDK pin sets are identical. The original1s matcher is preserved; this is positive same-run timing evidence rather than a historical failure explanation.

| Docs case | Original query→return Node ms |305324eval send→response Node ms|Browser selector sampled ms|Browser getter sampled ms|
|---|---:|---:|---:|---:|
| brutalist 1280 | 25.069 | 14.852 | 2.700 | 0.100 |
| brutalist 1440 | 22.581 | 13.625 | 2.300 | 0.100 |
| brutalist 2048 | 25.081 | 14.437 | 2.900 | 0.000 |
| brutalist 320 | 24.245 | 13.913 | 3.000 | 0.000 |
| brutalist 390 | 25.846 | 15.359 | 3.000 | 0.000 |
| shadcn 1280 | 205.894 | 195.234 | 1.700 | 0.000 |
| shadcn 1440 | 202.039 | 189.442 | 1.800 | 0.100 |
| shadcn 2048 | 225.510 | 214.663 | 1.800 | 0.000 |
| shadcn 320 | 92.707 | 79.368 | 1.700 | 0.000 |
| shadcn 390 | 97.974 | 86.795 | 1.800 | 0.000 |

The relevant whole-stream drain and actual matching frame queue/callback remain separately recorded in JSON. Neither is a browser ACK or pure engine interval. Browser0ms getter means equal sampled timestamps, not zero work or known clock tick. All8 initial Search readiness records passed the unchanged1s policy, retaining their own starts/deadlines/first getter samples and owner/generation. Earlier ready timestamps are not negative execution duration.

S4 still has bounded startup-only observations:

- zh-cn: 3 startup changes; last recorded firstMissing `pp-e7v4wb0qr46` index1 / react at pageMs32818.700; 24 pageerrors; collectionOutcome=rejected.
- en: 3 startup changes; last recorded firstMissing `pp-6p2ngsvjqo7` index1 / react at pageMs34547.100; 24 pageerrors; collectionOutcome=rejected.

Both streams reached their128-row init cap; final journal collection rejected TargetClosed and no journey phase began. A last sampled missing React host is not a complete state at timeout or a proven loader/CPU cause. The exact per-locale changes, original wait/close timestamps and24-error split remain in JSON.

The paint case has its original150s failure and actual context-close record, but no same-run DEBUG API prefix or phase journal to identify the blocking operation. The separate currently running paint control handle75038 was not read and contributes no result here. Prior screenshot stalls are not backfilled.

**0specific reconciliation findings; partial / ABSTAIN.** No full297green, formal approval, deployment or all-browser claim. No tests/browser/API/W edit or large ZIP/CRC/census scan was performed. Source/input stability is recorded by the original run receipt; this light review checks head and source-tagged sidecars rather than rehashing the complete source census during the active native control.
