本次两份 private diagnostic caller 与准确 a9 原件、preparation.json 哈希一致，未发现具体执行阻断。所有原断言表达式、输入调用、poll/wait、timeout/case 参数与 await 调用序列保留；没有新浏览器 RPC、await、timer 或 sleep，旧失败 oracle 仍在。此为 partial / ABSTAIN，不是执行证明或正式批准。

Homepage 仅加两条已有数据日志，并在原三 control 的同一 evaluate 中增加 computed style/animation 字段。Home demo 仅记录原 evaluate 已返回的 samples。AST 中的计数是调用点而非展开 case/实际运行次数。

观察成本不可省略：每个 control 的 style/animation 读数位于其 BCR 之后、下一个 control 的 BCR 之前，可能触发样式/动画更新并改变采样间隔；原几何与动画字段不是一个原子时刻。console/JSON 也有前置工作。代码未将所有新增观察/输出包成 nonthrowing 边界，所以不能宣称任何诊断异常均不会影响原 verdict；若实际出现需单独保存。该 arm 也没有完整 physical-node/owner/hover/pressed 状态关联，不从现有字段推断完整生命周期。

没有读取正在运行组合的结果，没有修改 W、运行测试/浏览器或网络操作。