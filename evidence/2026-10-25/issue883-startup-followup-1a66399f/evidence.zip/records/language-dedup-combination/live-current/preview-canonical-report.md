The canonical preview job for `1a66399f9bb593717e4b9b70ac4bc0ec36fc510f` completed successfully on 2026-10-25, 08:12:49–08:14:18 UTC. This review fetched its metadata and complete text log once at 08:42:20–08:42:24 UTC, then inspected the immutable checkout source locally. No artifact, media, test, build, browser, or other CI read was performed.

The log prints the exact checkout commit at lines 189–190. That commit resolves to tree `6e56e93b71b51f18957aa7053088ec95e358b624` in the existing local Git object database; the job log does not itself print this tree hash.

The actual canonical producer built **651 Astro pages**. Its original `scripts/preview/generated-artifact.test.mjs` ran **1 test: 1 passed, 0 failed, 0 skipped**, against all **3,853 files**. The producer-created ZIP was **20,431,855 bytes** and the admitted expanded tree was **104,050,479 bytes**. Exact-head source retains the default **100 MiB (104,857,600-byte)** expanded limit, leaving **807,121 bytes**. The test compares admitted and sanitized names and bytes with the actual producer directory; this is observed CI execution, not a test rerun by this review.

The upload action separately packaged `apps/www/dist/`: artifact **12591624396**, **20,328,951 bytes**, logged SHA-256 `12c4c91223a45d75f1637b9066fd29f2317e30614fc76a7a90828798db5bd6ac`. Its size differs from the producer ZIP tested before upload. No uploaded archive was downloaded or independently CRC-checked here.

The raw text log is **749,265 bytes**, SHA-256 `52a8f68e6446ced66cd74875ea76c45bb62a20c8b33c8c65805762349f726653`. `preview-canonical-source-binding.json` binds the exact source and default-limit call chain; `preview-canonical-selected-lines.json` retains narrow, line-numbered excerpts with only ANSI formatting removed.

**0 specific findings; partial / ABSTAIN.** This preview result does not establish primary CI or runtime acceptance, rendered visual QA, S4 completion, or deployment. It also supplies no independent HTML file count. Complete raw metadata/logs and download receipts remain unchanged privately; curated files disclose the narrower observation scope.
