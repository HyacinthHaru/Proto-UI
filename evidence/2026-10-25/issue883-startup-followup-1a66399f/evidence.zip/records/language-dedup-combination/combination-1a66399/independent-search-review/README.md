准确1a已完成Search元数据小审，partial / ABSTAIN。仅10Docs＋8readiness＋对应8progress，未读取增长中的完整组合结果。

10个原Docs verdict均通过；每例query1/callId/attempt1与3个CDP命令配对，共30对，response/pipe frame全部可对账。SDK10pins一致，相关drop/error为0、contextClosed/disposed为true。

| Case | Query→return Node ms | Selector resolve Node ms | Large evaluate send→response Node ms | First-role callback relative query Node ms |
|---|---:|---:|---:|---:|
| brutalist 1280 | 23.271833 | 14.517833 | 13.943167 | -958.022250 |
| brutalist 1440 | 24.757583 | 15.401208 | 14.796792 | -963.239833 |
| brutalist 2048 | 23.313750 | 14.536875 | 14.005292 | -959.775541 |
| brutalist 320 | 24.521333 | 15.094458 | 14.441584 | -858.107417 |
| brutalist 390 | 24.217084 | 14.805750 | 14.180875 | -858.507916 |
| shadcn 1280 | 208.012583 | 197.351708 | 197.171833 | -400.213875 |
| shadcn 1440 | 206.305083 | 195.617500 | 195.420708 | -401.871125 |
| shadcn 2048 | 189.223250 | 179.239542 | 179.041125 | -418.489167 |
| shadcn 320 | 109.474584 | 96.305792 | 95.590708 | -397.720375 |
| shadcn 390 | 97.464291 | 87.903167 | 87.728792 | -402.349167 |

8个原readiness均onTime，原窗口均1000ms，drop=0。日期epoch差仅作粗粒度记录比较，不称发送/送达延迟；0target/null getter表示未读取真实target。

第一表达式SHA均730c2ff1…，305324字符。SDK分段是嵌套/有观察成本的Node区间，不可相加后当纯编译；Writable drain也不是浏览器ACK。浏览器getter同tick不代表零耗时；target/role观察不代表物理mutation/paint时刻。十份阳性记录不关闭旧hosted红，也不替代全14/297终态。
