import runtimeUrls from 'virtual:proto-ui/runtime-retry-urls';
import { retryableModule } from './retryable-module';
import type { RuntimeAPI } from './ids';
import type * as ReactTypes from 'react';
import { claimHostMount, releaseHostMount } from './host-mount';

const importReact = retryableModule(() => import('react'), runtimeUrls.react);
const reactDomModule = retryableModule(() => import('react-dom'), runtimeUrls.reactDom);
const reactDomClientModule = retryableModule(
  () => import('react-dom/client'),
  runtimeUrls.reactDomClient
);

// Keep the React 18 reader runtime, but deliver the pinned pair through
// the application's lazy assets. ReactDOM's peer resolves the same React
// instance; no external CDN is required for a reader's mount.

// Private diagnostic only: first four loadReact calls and twelve shared loader Promises.
const s4ReactImports = {
  calls: 0,
  nextPromise: 0,
  seen: 0,
  dropped: 0,
  errors: 0,
  omittedCallPairs: 0,
  untrackedReturns: 0,
  promises: new WeakMap<object, { id: number; firstCall: number; loader: string; attached: boolean }>(),
};
const s4ReactThen = Promise.prototype.then;

function s4ReactImportReason(value: unknown): string {
  try {
    return String(value).slice(0, 240);
  } catch {
    return '[unreadable rejection reason]';
  }
}

function s4ReactImportRecord(phase: string, fields: Record<string, unknown>) {
  try {
    if (s4ReactImports.seen >= 64) {
      s4ReactImports.dropped++;
      if (s4ReactImports.dropped === 1)
        console.debug('[S4 init observation] ' + JSON.stringify({
          stage: 'react-import-promise-cap',
          moduleURL: import.meta.url,
          seen: s4ReactImports.seen,
          dropped: s4ReactImports.dropped,
          errors: s4ReactImports.errors,
        }));
      return;
    }
    s4ReactImports.seen++;
    console.debug(
      '[S4 init observation] ' +
        JSON.stringify({
          stage: 'react-import-promise',
          phase,
          moduleURL: import.meta.url,
          timeOrigin: globalThis.performance.timeOrigin,
          pageMs: globalThis.performance.now(),
          dateNow: Date.now(),
          seen: s4ReactImports.seen,
          dropped: s4ReactImports.dropped,
          errors: s4ReactImports.errors,
          omittedCallPairs: s4ReactImports.omittedCallPairs,
          untrackedReturns: s4ReactImports.untrackedReturns,
          ...fields,
        })
    );
  } catch {
    s4ReactImports.errors++;
  }
}

function observeS4ReactImport<T>(loader: string, load: () => Promise<T>, call: number): Promise<T> {
  const detailed = call <= 4;
  if (detailed) s4ReactImportRecord('call.begin', { call, loader });
  else s4ReactImports.omittedCallPairs++;
  let promise: Promise<T>;
  try {
    promise = Reflect.apply(load, undefined, []);
  } catch (error) {
    if (detailed) s4ReactImportRecord('call.throw', { call, loader, reason: s4ReactImportReason(error) });
    throw error;
  }
  try {
    let entry = s4ReactImports.promises.get(promise);
    const reused = !!entry;
    if (!entry && s4ReactImports.nextPromise < 12) {
      entry = { id: ++s4ReactImports.nextPromise, firstCall: call, loader, attached: false };
      s4ReactImports.promises.set(promise, entry);
    }
    if (!entry) s4ReactImports.untrackedReturns++;
    if (detailed || !reused) {
      s4ReactImportRecord('call.return', { call, loader, promiseId: entry?.id ?? null, reused });
    }
    if (entry && !entry.attached) {
      entry.attached = true;
      const captured = entry;
      // The observation reaction is separate; Promise.all receives the original Promise below.
      Reflect.apply(s4ReactThen, promise, [
        () => s4ReactImportRecord('promise.fulfilled', { promiseId: captured.id, firstCall: captured.firstCall, firstLoader: captured.loader }),
        (error: unknown) => s4ReactImportRecord('promise.rejected', { promiseId: captured.id, firstCall: captured.firstCall, firstLoader: captured.loader, reason: s4ReactImportReason(error) }),
      ]);
    }
  } catch {
    s4ReactImports.errors++;
  }
  return promise;
}

export async function loadReact(): Promise<{
  React: typeof ReactTypes;
  ReactDOM: any;
}> {
  const s4Call = ++s4ReactImports.calls;
  const [reactModule, reactDOMModule, reactDOMClient] = await Promise.all([
    observeS4ReactImport('importReact', importReact, s4Call),
    observeS4ReactImport('reactDomModule', reactDomModule, s4Call),
    observeS4ReactImport('reactDomClientModule', reactDomClientModule, s4Call),
  ]);
  const React = (reactModule.default ?? reactModule) as unknown as typeof ReactTypes;
  // Client roots do not export commit/portal APIs. Keep the public DOM APIs
  // used by composed demos, with client createRoot/hydrateRoot entry points.
  const ReactDOM = {
    ...(reactDOMModule.default ?? reactDOMModule),
    ...(reactDOMClient.default ?? reactDOMClient),
  };
  return { React, ReactDOM };
}

type ReactRoot = {
  unmount: () => void;
  render: (element: React.ReactElement) => void;
};

/**
 * React 运行时实现：
 * - 懒加载 React 依赖
 * - 使用 Proto UI 的 createReactAdapter() 适配 Prototype
 * - 维护宿主 root 的 mount / unmount 生命周期
 */
export function createReactRuntime(load = loadReact): RuntimeAPI {
  return {
    id: 'react',
    label: 'React',

    async mount(host, prototype, options) {
      const lease = claimHostMount(host);
      const [{ React, ReactDOM }, { createReactAdapter }] = await Promise.all([
        load(),
        import('@proto.ui/adapter-react'),
      ]);
      if (!lease.isCurrent()) return;

      const adapter = createReactAdapter(React as any);
      const Component = adapter(prototype);
      const root = ReactDOM.createRoot(host) as ReactRoot;
      if (!lease.commit(() => root.unmount())) return;

      // 不使用 StrictMode，避免开发模式双重渲染。
      root.render(React.createElement(Component, options?.props ?? {}));
    },

    unmount(host) {
      releaseHostMount(host);
    },
  };
}

export const runtime = createReactRuntime();
