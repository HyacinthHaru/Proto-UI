The complete local run used clean `a9cafe3aeede4450243c405ac734307d697fbb07` / tree `f7cb33cb5e6ddd2361acef5585015556e6b3ca3c` from 2026-10-25T05:51:35.071122+00:00 to 2026-10-25T06:14:42.763070+00:00. It ended exit 1: **14 files, 297 tests, 291 passed / 6 failed / 0 skipped**. Ten files passed and four failed. Vitest's 28 nested suites are not a 28-file count. All 11,490 tracked inputs and the declared extra input were stable before/after. This review reads the terminal a9 run only; current private follow-up edits are not its source.

The six actual failures were: Home React dark staged size-token predicate at `home-demo-runtime.browser.test.ts:520`; Homepage Contents token predicate `border-transparent` at `homepage-dogfood.browser.test.ts:732`; mobile controls exact-y predicate at line814 (9.867769241333008 versus6); two S4 locale case timeouts; and the S4 paint case timeout. These are retained separately. No current production-cause decision is inferred from this reconciliation.

The Search file passed all30 tests, including the10 Docs role cases below. The10 are a subset of30, not additional tests. Every Docs case recorded one original call, one browser attempt and three actual CDP pairs: the305324-character injected expression, a10257-character utility expression, then Runtime.callFunctionOn. All10 source pin sets matched the pinned installed files, mapping completed, contexts closed and observers disposed, with0diagnostic errors/drops/pending captured requests. The large expression SHA is `730c2ff13134a1ef5afdb2584d768787110b548e2653bd4ee9e0c7d543c7bb1a` in each case.

| Original Docs case | Node query→return ms | Large Runtime.evaluate send→response ms | Browser selector sampled ms | Browser getter sampled ms |
| --- | ---: | ---: | ---: | ---: |
| brutalist 1280 | 21.512 | 13.428 | 2.200 | 0.000 |
| brutalist 1440 | 21.749 | 13.506 | 2.200 | 0.000 |
| brutalist 2048 | 25.435 | 14.381 | 3.100 | 0.000 |
| brutalist 320 | 22.523 | 13.967 | 2.500 | 0.000 |
| brutalist 390 | 23.257 | 14.388 | 2.500 | 0.000 |
| shadcn 1280 | 206.024 | 195.307 | 1.800 | 0.000 |
| shadcn 1440 | 208.904 | 197.611 | 1.800 | 0.000 |
| shadcn 2048 | 210.075 | 199.100 | 2.000 | 0.000 |
| shadcn 320 | 97.476 | 83.756 | 1.700 | 0.000 |
| shadcn 390 | 97.952 | 87.318 | 1.900 | 0.000 |

For the large expression, both original writes returned false with needDrain=true. The relevant whole-stream drain followed the final write by0.251–0.773ms. The matched response frame queue→callback bracket was0.008625–0.043666ms. These distinguish observed Node stages; drain is not browser receipt or a per-message ACK. The13.428–199.100ms send→response interval cannot be assigned wholesale to transport, compilation, microtasks or execution. The report retains exact session/id/call/attempt for every pair. Pipe observer lifetime read/frame totals also include other traffic and are not original-query packet counts.

The main-world role observer recorded combobox before the original query in all10 cases:400–403ms earlier for Shadcn and852–967ms earlier for Brutalist at recorded Date precision. Those are MO state observations, separate from the original utility-world getter; owner fields in this target journal are null and no extra owner identity is inferred. The utility getter interval is0ms at the recorded resolution in all10: equal sampled timestamps, not zero work or a measured clock tick. These are positive same-run controls, not explanations of earlier natural CI failures.

All8 family Search readiness records passed the original1s rule with0sample/target-observation drops. Shadcn's first exact active command/fully-ready observation was123,135,263 or271ms after the Node stage start; its immediate preceding no-target samples were5,5,1 or1ms earlier respectively. Brutalist's saved matching owner/generation ready event was519–532ms before this stage began; the actual readiness function entered4–6ms after start and read the already-ready command. Negative ready-minus-start is therefore a saved earlier observation, not negative execution duration. Earlier inert/staging commands remain distinct from the active-selector target. Absent samples have null getter timestamps because no getter ran.

Both S4 locale cases reached their unchanged150s case timeout. Each streamed three firstMissing changes over1056previewers: WC index0 not yet inited; WC index0 inited1/host0; then React index1 inited1/host0. The final streamed transitions occurred at browser pageMs36289.2 for zh-cn (`pp-k23zmbtwcfs`) and35594.5 for en (`pp-erx3rml11s9`). They do not establish a permanent first-root stall or the exact state at timeout. Each retained24pageerrors (Button6, Tabs Trigger18), and each final journal snapshot rejected TargetClosed. Init streams reached cap128, so complete subsequent mutation/drop counters remain unknown. Original wait begin→observed error was144079.677ms and141251.931ms; this records delayed completion at closure without proving a particular SDK abort-await path. No journey phase began.

The paint file records server HTTP200, the original150s case timeout and a context-close event. It has no same-run goto/trigger/settings/screenshot enter-return journal or DEBUG=pw:api in this receipt. Its exact blocked operation is unknown. The earlier A/B screenshot stall and separate on/off control cannot be copied into this clean-a9 run.

The Accordion output environment used a legacy R23 directory. Root's separate reconciliation identifies this run's new a9-prefixed files copied unchanged to the current run; it does not relabel old published evidence. No PNG was opened or visually reviewed here.

Machine details are in `docs-timing.json`, `search-readiness.json`, `s4-and-paint.json` and raw/Git SHA bindings in `report.json`. **Read-only partial / ABSTAIN**; no new test, browser, network action or source edit.
