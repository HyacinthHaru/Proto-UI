The retained06a ZIP's central directory was read without opening or inflating any member payload. Following the original `listBoundedEntries` order, skipping slash-terminated directory entries, the first recorded expanded total above100MiB occurs at **`proto-ui-bundle-graph.json`** (central-directory zero-based index4547; regular-file ordinal3852).

| Derived step | Bytes |
| --- | ---: |
| Cumulative before this member | 102,850,469 |
| This member recorded uncompressed size | 4,652,800 |
| Cumulative after this member | 107,503,269 |
| Original100MiB limit | 104,857,600 |
| Excess at this member | 2,645,669 |

The original code increments `expandedBytes` then checks `> limits.maxExpandedBytes` at lines210–211. The retained original admission log reports exactly `artifact expanded size exceeds104857600bytes` from `listBoundedEntries` line211, consistent with this derived walk. The log did **not** record these variable values or this filename; they are an offline explanation, not a new same-call probe. This member is only the order-dependent crossing witness, not an identified cause of aggregate growth.

The entire old directory records3,853regular files and107,503,910expanded bytes. Its full ZIP SHA`1bf167ff6252ecc3cadd576f9bbf214c91cd1b7982ac36d50b167e17bfb7afbb` references the earlier full CRC/SHA audit; this lightweight read computes a fresh central-directory SHA`7dba0472edb527d4267f0159f3a22b1c7756f993d176a1540da36eacc856501a` only.

The distinct actual c5 receipt records3,853files,651Astro pages/669HTML,107,504,022expanded bytes against128MiB(134,217,728), leaving26,713,706bytes. Its21,526,002-byte ZIP has receipt SHA`d8cb40f5f6a0b9f86025166a21fa3801067cfd919100a994a135010042599eda` and original default-admission exit0. This is not the old ZIP and no cause is inferred for2,474differing path keys. Independent c5 member CRC/inventory verification stays deferred until parent confirms the running native combination terminal.

**Read-only derived walkthrough; partial / ABSTAIN.** No test/browser/API/source mutation or member decompression.
