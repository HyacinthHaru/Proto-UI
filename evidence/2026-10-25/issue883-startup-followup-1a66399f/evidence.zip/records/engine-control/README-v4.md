# Private engine identity control v4 — prepared, not executed

Use the exact argv in plan-v4.json and the fresh run4 directory only after root releases the browser slot. The original control-v3/run3 and earlier failures are unchanged. Syntax-only node --check passed; no browser/network/product execution occurred during preparation.

Two bounded code changes: add the actual V8-source categories disabled-by-default-v8.compile and disabled-by-default-devtools.v8-source-rundown to the four existing SDK categories; expand the post-trace identity parser. The separate source-text-rundown category is not enabled. Categories are requested from primary-source definitions, never represented as advertised by the actual empty getCategories result.

The parser retains explicit frame/processId payloads and also recognizes exact frame/page plus event.pid only when actual process_name metadata calls that process Renderer. This avoids treating browser-process frame references as renderer ownership. Multiple/absent process associations remain unresolved.

Trace identity requires the unique exact Debugger source/context match plus ScriptCatchup in that process with the same scriptId, executionContextId and an observed isolate. Numeric scriptId alone is insufficient. A compile span is bound only if a complete event in the compile category itself carries all matching process/isolate/context/script fields; no time-overlap or containment inference is used. The inspected CompileCode source emits no such identity arguments, so identity may be observed while compilation remains unmatched. That is an honest control outcome, not a script error to bypass.

One explicit 130-character Runtime.evaluate expression, args, getScriptSource verification, raw command/return capture, stream retention, time/byte limits and cleanup are unchanged outside the declared category/parser replacements. No compileScript/runScript/sourceURL/warmup, original Docs run, new dependency or product edit. A trace scope is not pure CPU/compile cost or browser receipt, and Node/trace clocks remain uncalibrated. Partial / ABSTAIN.
