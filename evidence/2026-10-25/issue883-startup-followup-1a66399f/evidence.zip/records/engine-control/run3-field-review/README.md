# Run3 actual trace-field review

Partial / ABSTAIN. Root's actual run3 exits0, source/extra inputs stable, one explicit Runtime.evaluate, no recorded errors/drops, complete950704-byte trace/5115events, dataLossOccurredfalse, allresourcecleanupflags true. No new browser or API run was performed.

Exact expressionSHA/context is proven: Debugger.scriptParsed script3/context1/frameD3747BA6DCE7B5B06853EC813CEF288F has hash7bb2f854..., emptyURL andisModulefalse; Debugger.getScriptSource returns exactlythe130-byteexpression.

The first parser required a processId field inside args and foundnone. Rawtrace nevertheless has27targetframe events, allonpid49028. Event1359 CommitLoad directly contains frame/pageD374..., urlabout:blank andeventpid49028; matching process_name declares Renderer. This is a real observedframe/processassociation, not a fabricatedprocessIdfield.

Crucially, both same-number script3 hits (events4008/4014, v8.compileModule) arepid49026 and explicitly name chrome://omnibox-popup.top-chrome/omnibox_popup.js. They are not thecontrol's script; numeric scriptId isprocess-local evidence, not aglobalidentity. Their rawdur34/276 mustnotbeattributedtotheexpression.

Targetpid49028 has oneEvaluateScript event3881 withargs{}. It hasno scriptId/sourcehash/frame payload establishing theexactexpression. It remains unattributed; do not callitsduration controlcompiletime orBrowserReceived. Thusframeassociationcanbesupplemented, butthe originalscript-spanunmatched conclusion remains.

The pinnedChromiumhandler source explains where frame/processIdfields canbeemitted and thatEmitFrameTree depends onhostWebContents. ActualTracingStartedInBrowser hasargs{}; no claim is madeabouttheunobservedhostbranch. Originalrun3report/trace/journal areunchanged.
