// Private capability control. It is not a Docs query or a performance acceptance test.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { performance } from 'node:perf_hooks';

const args = process.argv.slice(2);
const value = (key) => args[args.indexOf(key) + 1];
for (const key of ['--repo', '--chrome', '--out']) {
  if (!args.includes(key) || !value(key) || value(key).startsWith('--')) {
    throw new Error(`Required explicit argument: ${key}`);
  }
}
const repo = path.resolve(value('--repo'));
const chrome = path.resolve(value('--chrome'));
const out = path.resolve(value('--out'));
const privateRoot = path.dirname(path.resolve(process.argv[1]));
if (!out.startsWith(privateRoot + path.sep)) throw new Error('Output must stay under this private control directory.');
if (fs.existsSync(out)) throw new Error('Output must be a new directory; do not overwrite a run.');
fs.mkdirSync(out, { recursive: true });
const sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const stamp = () => ({ nodeMs: performance.now(), nodeTimeOrigin: performance.timeOrigin, date: new Date().toISOString() });
const errorRecord = (error) => ({ name: error?.name ?? typeof error, message: error?.message ?? String(error), stack: error?.stack ?? null });
const limits = {
  workMs: 60_000,
  rpcMs: 10_000,
  cleanupStepMs: 5_000,
  hardStopMs: 90_000,
  traceBytes: 32 * 1024 * 1024,
  journalBytes: 96 * 1024 * 1024,
  readChunkBytes: 256 * 1024,
  scriptSourceCandidates: 8,
};
const report = {
  kind: 'private-cft155-public-cdp-capability-control',
  started: stamp(),
  limits,
  status: 'running',
  explicitRuntimeEvaluateCalls: 0,
  errors: [],
  cleanupErrors: [],
  pendingCommands: [],
  journalComplete: true,
  journalDroppedRecords: 0,
  trace: { complete: false, bytes: 0 },
  cleanup: { streamClosed: false, pageSessionDetached: false, contextClosed: false, browserSessionDetached: false, browserDisconnected: false, browserCloseReturned: false },
  claims: {
    originalDocsQuery: false,
    browserReceivedObserved: false,
    pureCompileTime: false,
    productAcceptance: false,
    nodeAndTraceClocksCalibrated: false,
    localCommandIndexIsCDPWireId: false,
  },
};
let journalBytes = 0;
let sequence = 0;
const journal = path.join(out, 'protocol.jsonl');
function record(kind, payload) {
  const row = { sequence: ++sequence, ...stamp(), kind, ...payload };
  const bytes = Buffer.from(JSON.stringify(row) + '\n');
  if (journalBytes + bytes.length > limits.journalBytes) {
    report.journalComplete = false;
    report.journalDroppedRecords++;
    return row;
  }
  try {
    fs.appendFileSync(journal, bytes);
    journalBytes += bytes.length;
  } catch (error) {
    report.journalComplete = false;
    report.journalDroppedRecords++;
    (report.recordingErrors ??= []).push(errorRecord(error));
  }
  return row;
}
function saveReport() {
  report.journalBytes = journalBytes;
  fs.writeFileSync(path.join(out, 'report.json'), JSON.stringify(report, null, 2) + '\n');
}
const hardStop = setTimeout(() => {
  report.status = 'hard-time-bound-expired';
  report.errors.push({ stage: 'watchdog', message: 'Process stopped at90s; any unconfirmed cleanup remains false/unknown, not successful.' });
  report.finished = stamp();
  try { saveReport(); } finally { process.exit(2); }
}, limits.hardStopMs);
const workDeadline = performance.now() + limits.workMs;
async function bound(promise, name, ms) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${name}: observation budget expired after ${ms}ms; operation not cancelled`)), ms);
  });
  try { return await Promise.race([promise, timeout]); } finally { clearTimeout(timer); }
}
let commandIndex = 0;
const pending = new Map();
async function send(session, sessionName, method, params = {}, cleanup = false) {
  if (!cleanup && (!report.journalComplete || performance.now() >= workDeadline)) throw new Error('Control work/journal budget exhausted');
  const index = ++commandIndex;
  record('command', { commandIndex: index, session: sessionName, method, params });
  pending.set(index, { commandIndex: index, session: sessionName, method });
  // Exactly one original public CDPSession.send call. The ordinal is local, not a CDP wire id.
  let original;
  try { original = session.send(method, params); } catch (error) {
    pending.delete(index); record('command.throw', { commandIndex: index, error: errorRecord(error) }); throw error;
  }
  const observed = original.then((result) => {
    pending.delete(index); record('response', { commandIndex: index, session: sessionName, method, result }); return result;
  }, (error) => {
    pending.delete(index); record('response.error', { commandIndex: index, session: sessionName, method, error: errorRecord(error) }); throw error;
  });
  const ms = cleanup ? limits.cleanupStepMs : Math.max(1, Math.min(limits.rpcMs, workDeadline - performance.now()));
  return bound(observed, `${sessionName}.${method}`, ms);
}
const contexts = [];
const parsedScripts = [];
const listeners = [];
function listen(session, name, event, keep) {
  const fn = (payload) => {
    const row = record('event', { session: name, event, payload });
    keep?.(payload, row);
  };
  session.on(event, fn);
  listeners.push(() => session.off(event, fn));
}
let browser, context, browserCDP, pageCDP;
let traceStartAttempted = false;
let traceEndPromise;
let stream;
let tracingComplete;
let completeResolve;
const completePromise = new Promise((resolve) => { completeResolve = resolve; });
const endTrace = () => traceEndPromise ??= send(browserCDP, 'browser', 'Tracing.end', {}, true);
async function cleanupStep(name, operation, success) {
  try { await bound(Promise.resolve().then(operation), name, limits.cleanupStepMs); success?.(); }
  catch (error) { report.cleanupErrors.push({ stage: name, ...errorRecord(error) }); }
}
try {
  const require = createRequire(path.join(repo, 'apps/www/package.json'));
  const packageFile = require.resolve('playwright-core/package.json');
  const sdkRoot = path.dirname(packageFile);
  const pkg = JSON.parse(fs.readFileSync(packageFile, 'utf8'));
  if (pkg.version !== '1.58.2') throw new Error(`Expected Playwright1.58.2; actual ${pkg.version}`);
  report.source = {
    script: { path: process.argv[1], sha256: sha(fs.readFileSync(process.argv[1])) },
    node: process.version,
    playwright: pkg.version,
    chromeExecutable: chrome,
    pins: ['types/types.d.ts', 'types/protocol.d.ts', 'lib/server/chromium/crBrowser.js'].map((file) => ({ file, sha256: sha(fs.readFileSync(path.join(sdkRoot, file))) })),
  };
  const { chromium } = require('playwright-core');
  const launchOptions = { executablePath: chrome, headless: true, args: ['--disable-dev-shm-usage', '--no-sandbox'], timeout: 15_000 };
  record('public-api', { method: 'chromium.launch', options: launchOptions });
  // Use the launch API's own timeout/cleanup; the90s watchdog remains the outer process bound.
  browser = await chromium.launch(launchOptions);
  browser.on('disconnected', () => { report.cleanup.browserDisconnected = true; record('browser.disconnected', {}); });
  browserCDP = await bound(browser.newBrowserCDPSession(), 'newBrowserCDPSession', limits.rpcMs);
  listen(browserCDP, 'browser', 'Tracing.tracingComplete', (payload) => { tracingComplete = payload; stream = payload.stream; completeResolve(payload); });
  listen(browserCDP, 'browser', 'Tracing.bufferUsage');
  const version = await send(browserCDP, 'browser', 'Browser.getVersion');
  report.browserVersion = version;
  if (!/^(?:Headless)?Chrome\/155\.0\.8059\.39$/.test(version.product)) throw new Error(`Unexpected actual browser version ${version.product}; no engine substitution`);
  const categories = await send(browserCDP, 'browser', 'Tracing.getCategories');
  // Keep the four SDK-default entries; add only categories defined in the actual DEPS-pinned V8 source.
  // Preserve the actual enumeration (including []) without treating it as a support/admission gate.
  const selected = [
    'devtools.timeline',
    'v8.execute',
    'disabled-by-default-devtools.timeline',
    'disabled-by-default-devtools.timeline.frame',
    'disabled-by-default-v8.compile',
    'disabled-by-default-devtools.v8-source-rundown',
  ];
  report.categories = {
    returnedCategories: categories.categories,
    requestedCategories: selected,
    requestBasis: 'Playwright1.58.2 crBrowser.js defaults plus V8 56832c166a78bd1eb61068ac69876d6880eaabdf compiler.cc/script.cc TRACE_DISABLED_BY_DEFAULT categories',
    getCategoriesUsedAsAdmissionGate: false,
    sourceTextRundownRequested: false,
    boundary: 'Explicit source-bound category experiment, not advertised support or automatic fallback. Actual events/identity fields are required; no compile event or per-request binding is assumed.',
  };
  traceStartAttempted = true;
  await send(browserCDP, 'browser', 'Tracing.start', {
    transferMode: 'ReturnAsStream', streamFormat: 'json', streamCompression: 'none',
    traceConfig: { recordMode: 'recordUntilFull', traceBufferSizeInKb: limits.traceBytes / 1024, includedCategories: selected, enableSampling: false },
  });
  context = await bound(browser.newContext({ viewport: { width: 800, height: 600 } }), 'newContext', limits.rpcMs);
  const page = await bound(context.newPage(), 'newPage', limits.rpcMs);
  // about:blank only. No goto, page.evaluate, compileScript, runScript or sourceURL.
  pageCDP = await bound(context.newCDPSession(page), 'newCDPSession', limits.rpcMs);
  listen(pageCDP, 'page', 'Runtime.executionContextCreated', (payload, row) => contexts.push({ ...payload.context, received: row }));
  listen(pageCDP, 'page', 'Runtime.executionContextDestroyed');
  listen(pageCDP, 'page', 'Debugger.scriptParsed', (payload, row) => parsedScripts.push({ ...payload, received: row }));
  listen(pageCDP, 'page', 'Debugger.scriptFailedToParse');
  await send(pageCDP, 'page', 'Page.enable');
  const frames = await send(pageCDP, 'page', 'Page.getFrameTree');
  await send(pageCDP, 'page', 'Runtime.enable');
  await send(pageCDP, 'page', 'Debugger.enable');
  const frameId = frames.frameTree.frame.id;
  const defaults = contexts.filter((item) => item.auxData?.isDefault === true && item.auxData?.frameId === frameId);
  if (defaults.length !== 1) throw new Error(`Expected one observed default context for exact frame; received ${defaults.length}`);
  const selectedContext = defaults[0];
  const marker = `proto-ui-cft155-api-control:${crypto.randomUUID()}`;
  const expression = `(() => { const marker = ${JSON.stringify(marker)}; return { marker, answer: 6 * 7 }; })()`;
  fs.writeFileSync(path.join(out, 'expression.js'), expression);
  report.control = { marker, expressionSHA256UTF8: sha(Buffer.from(expression)), expressionCharacters: expression.length, context: selectedContext, frameId, sourceURLAdded: false };
  const beforeSequence = sequence;
  report.explicitRuntimeEvaluateCalls++;
  const result = await send(pageCDP, 'page', 'Runtime.evaluate', { expression, contextId: selectedContext.id, returnByValue: true, awaitPromise: false, timeout: 5_000 });
  report.control.result = result;
  report.control.expectedValueObserved = !result.exceptionDetails && result.result?.value?.marker === marker && result.result.value.answer === 42;
  await endTrace();
  await bound(completePromise, 'Tracing.tracingComplete', limits.rpcMs);
  report.trace.tracingComplete = tracingComplete;
  report.trace.dataLossOccurred = tracingComplete.dataLossOccurred;
  if (!stream) throw new Error('Tracing ended without a ReturnAsStream handle');
  const traceFile = path.join(out, 'trace.json');
  fs.writeFileSync(traceFile, Buffer.alloc(0));
  let eof = false;
  while (!eof) {
    const remaining = limits.traceBytes - report.trace.bytes;
    const read = await send(browserCDP, 'browser', 'IO.read', { handle: stream, size: Math.min(limits.readChunkBytes, remaining + 1) });
    const bytes = Buffer.from(read.data, read.base64Encoded ? 'base64' : 'utf8');
    if (bytes.length > remaining) {
      fs.appendFileSync(traceFile, bytes.subarray(0, remaining));
      report.trace.bytes += remaining; report.trace.byteLimitExceeded = true;
      throw new Error('Trace byte limit reached; raw trace is explicitly incomplete');
    }
    fs.appendFileSync(traceFile, bytes); report.trace.bytes += bytes.length; eof = read.eof;
  }
  report.trace.complete = true;
  report.trace.sha256 = sha(fs.readFileSync(traceFile));
  await send(browserCDP, 'browser', 'IO.close', { handle: stream }, true);
  report.cleanup.streamClosed = true; stream = undefined;
  // Source retrieval happens only after the control expression and trace have finished; it does not compile/run anything.
  const candidates = parsedScripts.filter((item) => item.received.sequence > beforeSequence && item.executionContextId === selectedContext.id);
  report.scriptCandidates = { count: candidates.length, maximumSourceReads: limits.scriptSourceCandidates, records: candidates };
  const exact = [];
  if (candidates.length <= limits.scriptSourceCandidates) {
    for (const candidate of candidates) {
      const source = await send(pageCDP, 'page', 'Debugger.getScriptSource', { scriptId: candidate.scriptId });
      const actualSHA256 = sha(Buffer.from(source.scriptSource));
      const record = { scriptId: candidate.scriptId, executionContextId: candidate.executionContextId, scriptParsedHash: candidate.hash, retrievedSourceSHA256UTF8: actualSHA256, exactExpressionBytes: source.scriptSource === expression, scriptParsedHashEqualsUTF8SHA256: candidate.hash === actualSHA256 };
      (report.sourceComparisons ??= []).push(record);
      if (record.exactExpressionBytes) exact.push(record);
    }
  } else report.scriptSourceCandidateCapReached = true;
  report.scriptMatch = { status: exact.length === 1 ? 'unique-exact-source-and-context' : exact.length ? 'ambiguous' : 'unmatched', matches: exact };
  const parsed = JSON.parse(fs.readFileSync(traceFile, 'utf8'));
  const events = Array.isArray(parsed) ? parsed : parsed.traceEvents;
  if (!Array.isArray(events)) throw new Error('Returned JSON has no traceEvents array');
  report.trace.eventCount = events.length;
  report.trace.eventNames = [...new Set(events.map((event) => event.name))].sort();
  function objects(value, at = '$', found = []) {
    if (value && typeof value === 'object') {
      found.push({ at, value });
      for (const [key, child] of Object.entries(value)) if (child && typeof child === 'object') objects(child, `${at}.${key}`, found);
    }
    return found;
  }
  const processNames = new Map();
  events.forEach((event) => {
    if (event.name === 'process_name' && typeof event.args?.name === 'string')
      processNames.set(String(event.pid), event.args.name);
  });
  const frameProcess = [];
  events.forEach((event, index) => {
    for (const item of objects(event.args)) {
      const v = item.value;
      const explicitFrame = v.frame === frameId || v.frameId === frameId;
      if (explicitFrame && v.processId !== undefined) {
        frameProcess.push({ eventIndex: index, name: event.name, argsPath: item.at, frameId, processId: v.processId, eventPid: event.pid, association: 'explicit frame/processId payload', ts: event.ts });
      }
      // A browser-process event can mention a renderer frame. Only observed Renderer process metadata
      // permits this distinct frame/event.pid association; keep its evidence type explicit.
      if ((explicitFrame || v.page === frameId) && processNames.get(String(event.pid)) === 'Renderer') {
        frameProcess.push({ eventIndex: index, name: event.name, argsPath: item.at, frameId, processId: event.pid, eventPid: event.pid, association: 'frame payload and event.pid with observed process_name=Renderer', ts: event.ts });
      }
    }
  });
  const processIds = [...new Set(frameProcess.map((item) => String(item.processId)))];
  const scriptEvents = [];
  if (exact.length === 1) events.forEach((event, index) => {
    for (const item of objects(event.args)) {
      for (const [key, v] of Object.entries(item.value)) if (key.replaceAll('_', '').toLowerCase() === 'scriptid' && String(v) === exact[0].scriptId) {
        scriptEvents.push({ eventIndex: index, name: event.name, category: event.cat, phase: event.ph, pid: event.pid, tid: event.tid, ts: event.ts, dur: event.dur, argsPath: `${item.at}.${key}`, scriptId: v, args: event.args, frameProcessCandidate: processIds.includes(String(event.pid)), sufficientIdentityAlone: false });
      }
    }
  });
  const rundown = [];
  if (exact.length === 1 && processIds.length === 1) events.forEach((event, index) => {
    if (event.name !== 'ScriptCatchup' || !String(event.cat ?? '').split(',').includes('disabled-by-default-devtools.v8-source-rundown') || String(event.pid) !== processIds[0]) return;
    for (const item of objects(event.args)) {
      const data = item.value;
      if (String(data.scriptId) === exact[0].scriptId && data.executionContextId === selectedContext.id && typeof data.isolate === 'string' && data.isolate.length > 0 && data.isModule === false) {
        rundown.push({ eventIndex: index, name: event.name, category: event.cat, phase: event.ph, pid: event.pid, tid: event.tid, ts: event.ts, argsPath: item.at, scriptId: data.scriptId, executionContextId: data.executionContextId, isolate: data.isolate, payload: data });
      }
    }
  });
  const tuples = [...new Set(rundown.map((item) => JSON.stringify([String(item.pid), item.isolate, item.executionContextId, String(item.scriptId)])))];
  const identity = tuples.length === 1 ? rundown[0] : null;
  const compileEvents = [];
  const explicitlyBoundCompileSpans = [];
  events.forEach((event, index) => {
    if (!String(event.cat ?? '').split(',').includes('disabled-by-default-v8.compile')) return;
    const entry = { eventIndex: index, event, explicitIdentityMatches: [] };
    if (identity && String(event.pid) === String(identity.pid)) {
      for (const item of objects(event.args)) {
        const data = item.value;
        if (String(data.scriptId) === String(identity.scriptId) && data.executionContextId === identity.executionContextId && data.isolate === identity.isolate) {
          entry.explicitIdentityMatches.push({ argsPath: item.at, scriptId: data.scriptId, executionContextId: data.executionContextId, isolate: data.isolate });
        }
      }
    }
    compileEvents.push(entry);
    // Neither a reused scriptId nor temporal containment/overlap can create this binding.
    if (entry.explicitIdentityMatches.length && event.ph === 'X' && Number.isFinite(event.dur) && event.dur >= 0)
      explicitlyBoundCompileSpans.push(entry);
  });
  report.traceAssociation = {
    processNames: [...processNames].map(([pid, name]) => ({ pid, name })),
    frameProcessEvidence: frameProcess,
    observedProcessIds: processIds,
    sameScriptIdEventCandidates: scriptEvents,
    scriptRundownIdentityEvidence: rundown,
    identityStatus: exact.length !== 1 ? 'unmatched-debugger-source' : processIds.length !== 1 ? 'unmatched-or-ambiguous-frame-process' : tuples.length === 1 ? 'observed-source-context-script-isolate-process-identity' : tuples.length ? 'ambiguous-rundown-identity' : 'unmatched-rundown-identity',
    compileCategoryEvents: compileEvents,
    explicitlyBoundCompileSpans,
    compileSpanStatus: explicitlyBoundCompileSpans.length ? 'observed-explicit-identity-on-complete-event' : 'unmatched',
    temporalOverlapUsedForBinding: false,
    scriptIdAloneUsedForBinding: false,
    boundary: 'Source hash is established by Debugger/getScriptSource; trace identity additionally requires observed frame/process plus ScriptCatchup script/context/isolate. A compile span must itself carry matching process/isolate/context/script fields. Absent fields stay unmatched even if events overlap. A trace scope is not pure CPU/compile cost or browser receipt.',
  };
  report.status = !identity ? 'unmatched' : explicitlyBoundCompileSpans.length ? 'observed-explicit-identity-and-span' : 'observed-identity-compile-span-unmatched';
} catch (error) {
  report.errors.push({ stage: 'control', ...errorRecord(error) });
  report.status = 'unavailable-or-incomplete';
} finally {
  if (browserCDP && traceStartAttempted && !tracingComplete) {
    await cleanupStep('Tracing.end', endTrace);
    await cleanupStep('Tracing.tracingComplete', () => completePromise);
  }
  if (browserCDP && stream && !report.cleanup.streamClosed) await cleanupStep('IO.close', () => send(browserCDP, 'browser', 'IO.close', { handle: stream }, true), () => { report.cleanup.streamClosed = true; stream = undefined; });
  if (pageCDP) await cleanupStep('page CDPSession.detach', () => pageCDP.detach(), () => { report.cleanup.pageSessionDetached = true; });
  if (context) await cleanupStep('BrowserContext.close', () => context.close(), () => { report.cleanup.contextClosed = true; });
  if (browserCDP) await cleanupStep('browser CDPSession.detach', () => browserCDP.detach(), () => { report.cleanup.browserSessionDetached = true; });
  if (browser) await cleanupStep('Browser.close', () => browser.close(), () => { report.cleanup.browserCloseReturned = true; report.cleanup.browserDisconnected = !browser.isConnected(); });
  for (const remove of listeners) { try { remove(); } catch (error) { report.cleanupErrors.push({ stage: 'remove event listener', ...errorRecord(error) }); } }
  report.pendingCommands = [...pending.values()];
  report.finished = stamp();
  report.boundaries = ['One explicit Runtime.evaluate control, no Docs/prototype/query performance claim.', 'Playwright/browser initialization is not claimed to execute zero internal scripts.', 'Tracing and Debugger alter the observed environment.', 'Debugger.scriptParsed receipt is a Node callback time, not physical parse start/end.', 'No trace timestamps are subtracted from Node clocks.', 'All raw files are private and can contain machine paths, dynamic IDs and process metadata.', 'A watchdog or cleanup timeout leaves explicit resource debt; it is not successful cleanup.'];
  saveReport();
  // If cleanup did not return, keep the hard watchdog alive; do not turn a bounded await into an unbounded process.
  if (!browser || report.cleanup.browserCloseReturned) clearTimeout(hardStop);
  process.exitCode = report.errors.length || report.cleanupErrors.length || !report.journalComplete || !report.cleanup.browserCloseReturned ? 1 : 0;
  console.log(JSON.stringify({ status: report.status, report: path.join(out, 'report.json'), explicitRuntimeEvaluateCalls: report.explicitRuntimeEvaluateCalls, cleanup: report.cleanup, errors: report.errors.length, cleanupErrors: report.cleanupErrors.length }));
}
