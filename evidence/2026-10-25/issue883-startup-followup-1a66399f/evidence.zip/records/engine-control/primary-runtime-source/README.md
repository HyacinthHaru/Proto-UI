# Exact Chrome155 / V8 trace source review

Partial / ABSTAIN. Chrome revision3ff7ac5a9224be9156d7f8703a06e22890aafd34 pins V8 56832c166a78bd1eb61068ac69876d6880eaabdf in its actual DEPS. Five primary-source files were read once with preserved receipts; no browser/control/test was run.

`V8RuntimeAgentImpl::evaluate` line369 emits `EvaluateScript` under `disabled-by-default-devtools.timeline` with no argument payload. Its method covers context setup, global evaluation, microtasks and result handling. This explains the source boundary behind run3's empty-args event; it supplies neither request/script identity nor pure compilation time or browser receipt.

The actual compiler source defines `disabled-by-default-v8.compile` and `V8.CompileCode` / `V8.Compile` / `V8.CompileEval` scopes, but the inspected emissions have no per-script data. V3 did not request this category; no missing duration can be reconstructed from source. Cache/control-path branches also remain actual-execution questions.

A separate source-defined category, `disabled-by-default-devtools.v8-source-rundown`, can emit `ScriptCatchup` with `scriptId`, `executionContextId`, `isolate`, module/sourceURL and URL metadata through Compiler.PostInstantiation→Script.TraceScriptRundown. It is a concrete identity-observation possibility, not a guaranteed event on this control or a compile-duration join. The separate `...-sources` category captures source text and can be expensive/private; it was not enabled and is not proposed as an automatic fallback.

Run3 still has exact Debugger source/context identity but no trace span bound to that script. Its two numeric script3 compileModule hits belong to another process's omnibox module. No cross-clock subtraction, pureCompile, BrowserReceived, originalDocs or currentmain-rootcause inference is made. Source investigation stops here; any further capability experiment requires root's separate bounded decision.
