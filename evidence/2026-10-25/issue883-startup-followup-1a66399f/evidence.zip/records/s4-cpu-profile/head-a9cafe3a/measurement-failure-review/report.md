The original zh-cn S4 case failed at its unchanged 150,000 ms case timeout; en was filtered (0 passed / 1 failed / 1 skipped). This was `a9cafe3aeede4450243c405ac734307d697fbb07` plus one private CPU caller, not clean-head acceptance. All 11,490 tracked entries and listed extra inputs matched before/after. A later receipt records exact caller restoration and a clean worktree at that point.

Profiler setup fulfilled. Start ACK preceded goto by 2.939167 ms. The Node timer requested stop after 95001.617750 ms. Profiler.stop stayed pending 55268.925125 ms until page close, then rejected TargetClosed. Metadata saved successfully, but profile is null and no .cpuprofile exists. No hotspot/source-attribution analysis was run.

The same-case predicate streamed 3 state changes over 1056 previewers:

- raw line 152: browser pageMs 6656.200000; index 0, wc, ID `pp-bbg2gapgi9u`, inited=None, hostChildren=None, mounting=1.
- raw line 328: browser pageMs 10016.800000; index 0, wc, ID `pp-bbg2gapgi9u`, inited=1, hostChildren=0, mounting=None.
- raw line 331: browser pageMs 38135.500000; index 1, react, ID `pp-punz8cie8n`, inited=1, hostChildren=0, mounting=None.

The latter two hosts were startup-pending and inert. This proves progress past WC index0; it does not prove the final React state persisted until timeout. The post-verdict journal snapshot rejected on close. Init console reached ordinal 128; complete later mutation/drop counters are unavailable. The same case retained 24 page errors (6 shadcn-button and 18 shadcn-tabs-trigger transition-all used-value-rounding). No journey phase began.

Raw logs record browserContext.close started/succeeded, page.closed, context close event, browser.close succeeded and metadata write fulfilled. No fresh process enumeration was performed. This is a failed measurement with useful same-case startup observations; it does not establish CPU hotspots, a particular loader cause, or a permanent first-root stall. **partial / ABSTAIN**.
