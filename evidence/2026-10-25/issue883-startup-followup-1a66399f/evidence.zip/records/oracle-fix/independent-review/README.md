当前 c08 + 两测试候选只读审查 0 open finding，partial / ABSTAIN。两个样式 oracle 迁移有 draft P 条目、当前实现与同次原断言红的事实支撑；原 staging/inert/transition、44px、input/owner 与 deadline 不变。

mobile 新增的是 mouse.move 后独立 1000ms 的 resting-transform 前置条件，要求原三控件 computed transform 精确为 none，然后执行原有 BCR 和 exact-y 断言。它改变采样时序并增加只读 polling，不应称所有等待不变；但没有扩大原 case/deadline、放宽几何、写 CSS/offset、sleep 或重放输入。原三控件数量断言保留，因此空集合的 every 真值不能使该 case 通过。原私有诊断明确记录一个 control 的 +3.86779 transform 与运行中150ms动画；data-hover误读的null不作hover状态证据，逐 control 观察成本保留。

实际 focused 候选回执为 c08 + 两 dirty candidates，06:24:54.931806–06:25:32.828976，3pass/17filtered、exit0、source/extras stable；两候选 hash 与前后完整 census 对应相等。不是 postcommit、全20或全297通过。Root 在跑的同c08无诊断基线未读，不能把早先a9红直接合成同整树红绿。