# Docs pipe-observer peer review

0 concrete open source findings in the two-file pipe delta; partial / ABSTAIN. This agent authored earlier Docs instrumentation, so this is not formal independent approval. Actual root seven-file Node84/84 is source-bound to the two current hashes; original nine unit cases remain an exact AST prefix, seven new cases are added. No test/browser/API run by this reviewer.

Original two write calls/arguments/receiver/boolean returns, original Promise and throw object, original framing/JSON.parse and scheduler callback are retained. Restore uses original descriptor and function-identity guard; a foreign owner is not overwritten. Missing pinned pipe methods leave observation unavailable while the original command proceeds. Queued original callbacks still execute after disposal. Expression strings are hashed only after the verdict.

Ten completed current Docs records match root arithmetic exactly, using the same actual sessionId/CDPid and the305324-character injected expression SHA730c2ff1.... All original Docs polls pass and pipe states areavailable/closed with0errors/drops. This is a current positive observation, not closure of old hosted negatives or complete43 evidence.

Key timing limits: transport-entry→last-write-return includes original serialization/writes; write-return→drain is whole-stream backpressure, not messageACK. For a split response, read-dispatch is the chunk with the NUL terminator, not necessarily first-byte arrival. frame.queued is sampled before the original scheduler call, not inside its queue. The callback timestamp precedes original JSON.parse and connection dispatch. Deferred-record array order is not clock order. Global pipe counters include unrelated traffic; per-query association requires actual keys.

All durations are Node-clock spans. Last-write→response-ingress still contains outgoing pipe, Chrome scheduling/evaluation, return path and Node chunk scheduling. It is not pure compile or browserReceipt. No zero-interference claim; inspect pipe counters separately from the pre-existing call/browser mapping flag. The unrelated S4 live-console-array snapshot P3 remains separately recorded.
