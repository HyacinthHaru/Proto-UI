# Private S4 failure capture

A/B are ready for Root review; no source application or browser/test execution occurred. Originals are immutable718 Git bytes. The current Root-owned test diagnostics remain separate; the plan runs the original two locale cases and paint case, preserving inputs, oracles,60s/150s budgets and the original awaits.

A adds only a nonthrow call inside the existing used-value-rounding failure branch before its original throw. It records already-computed entries/current width vectors/applied vector plus actual physical host/surface identity and bounded ancestor metadata. No guard/classifier/prepare or layout is rerun. Up to32 error rows and one cap notice are emitted using the existing S4 console marker.

B selects the firstfour actual roots from the original bootstrap scan without another query. Each selection records its real previewerId/index/declared runtime. Generic Previewer marks original loadDemo/loadPrototypes/renderDemo/surface.ready/setAppearance boundaries, actual runtime/version and host child count. The original12 await expressions across bootstrap/client are byte-equal and no await is added. Use the same-run firstMissing ID to establish relevance; do not infer that index0 is permanent or equate declared and actual runtime. Per-root24/global96 row caps and errors are explicit.

The private host map links existing host references to those four roots for an optional renderer probe; it does not scan or modify DOM. If B identifies renderDemo pending, Root may separately review C. Missing observations/overflow remain debt, not passes. Original rejected/error paths remain unchanged.

Root may apply with apply-restore.py apply --arm AB, execute its own source-bound run-plan using execution-plan.json, then apply-restore.py restore --arm AB. Each apply/restore checks all selected source hashes first. This wrapper never runs tests or other commands. Additional module bytes, synchronous metadata and console work have nonzero cost; this is an instrumented source epoch, not clean718 or a production repair.
