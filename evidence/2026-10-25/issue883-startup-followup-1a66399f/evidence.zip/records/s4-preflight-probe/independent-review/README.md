# S4 AB same-run evidence review

**Partial / ABSTAIN.** Actual04:43:51–04:51:41UTC, source/extrasstable,0pass/3fail. Allthreeoriginal150scasetimeoutsremain. Thisis7181pluscandidateandprivateobservers,notcleanmainacceptance.

| Locale/index/runtime | Actualroot | Lastobservedphase |
|---|---|---|
| zh-cn/0/wc | `pp-oaajzoxl5jc` | surface.ready.begin |
| zh-cn/1/react | `pp-8nur1s6u6qi` | renderDemo.begin |
| zh-cn/2/vue | `pp-1tibh9ekp73` | renderDemo.begin |
| zh-cn/3/vue2 | `pp-63qt86twxab` | surface.ready.begin |
| en/0/wc | `pp-2n3oubze6tn` | surface.ready.begin |
| en/1/react | `pp-28h3kv0ds9g` | renderDemo.begin |
| en/2/vue | `pp-vrh08rudbsf` | surface.ready.begin |
| en/3/vue2 | `pp-2t4tmmq6cvk` | renderDemo.begin |

Bothfirst-missstreams advancefromWCindex0toReactindex1(inited1/hostChildren0/pending+owninerttrue). AllfirstfourloadDemo/loadPrototypesawaitsreturn. WCrenderDemoreturnsinbothlocales; zhVue2andenVuealsoreturnandreachsurface.ready. ReactrenderDemohasnorecordedreturnineitherlocale. Thesearelastobservedboundaries,notpermanentdeadlockproof.

Eachlocalehas24preflightrows(48total):6ShadcnButton+18TabsTrigger,actualpui-s2/s3/s5physicalhosts,directShadowSurface,noPreviewerancestor. Widthsnew[[1],[1],[1],[1]]vsapplied[[0],[0],[0],[0]]triggerexistingtransition-allused-value-roundingrejection. DraftK/O/H1andS2fixed-borderdirectionrequireunsupportedrecipesfailclosed. NoevidencehereauthorizesguardremovalorprovesaCrouting/lifecycledefect;initialbatching/consumercompatibilityandcausallinktothebaseAccordionwaitremainunknown.

Paintfirstlightclicksucceeds04:49:30.488Z. Switch/checkboxrequiredreadsreturn. Screenshotstarts04:49:41.928Z atscriptline109insideopen-markerassertion;fontsloaded04:49:52.460Z. Screenshotstillpendingat150scontextclose04:51:39.090Z,thenfails04:51:39.606Z. Thisisnotclicktimeout. Openmarkerresult,firstcloseandclosedpaintassertionsarenotreached. Innercapture/RAF/IPCstageisnotobservablefromtheseDEBUGlines.

Postverdictlocalejournalcollectionsrejectaftercontextclose;nullisnotfulfilledempty. Originalraw/negative/sourceepochsarepreserved. No newtest/browser/API/sourceedit.
