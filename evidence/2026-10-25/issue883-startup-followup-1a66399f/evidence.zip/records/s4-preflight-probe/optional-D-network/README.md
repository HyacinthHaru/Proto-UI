# Optional runtime import metadata observer

Prepared only. The mjs module passed syntax checking but was not imported or run. It adds owned Node-side request/response/finished/failed listeners before the original goto and reads cached metadata only. It does not fetch, route, read bodies or evaluate page code. Page.on/off can send Playwright subscription commands, so this is not an RPC-free or zero-cost arm.

Use it only if C actually shows a module/runtime import stage pending. The128-row cap and request-object identities are explicit. Only runtime/adapter script URLs are classified; opaque chunks and cached modules remain uncertain. Transfer completion is not module evaluation or import Promise fulfillment, and shared requests are not assigned to a Previewer solely by timestamp.

Keep all original inputs, awaits, deadlines, error priority and context-close order. Emit its snapshot at an existing post-verdict boundary with a nonthrow synchronous wrapper, then remove only owned listeners. Do not add a wait for this observer or claim missing summary means no network activity. The original request timing object is copied to prevent later SDK mutation of historical rows.
