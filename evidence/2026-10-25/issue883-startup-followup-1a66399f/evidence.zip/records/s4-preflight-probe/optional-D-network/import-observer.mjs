// Private Node-side request metadata only. Importing this module starts no work.
import { performance } from 'node:perf_hooks';

export function installRuntimeImportObservation(page, { cap = 128 } = {}) {
  const rows = [];
  const ids = new WeakMap();
  let nextId = 0;
  let seen = 0;
  let dropped = 0;
  let errors = 0;
  let scriptRequests = 0;
  let stopped = false;
  const relevant = (url) => {
    const path = new URL(url).pathname;
    return (
      /\/PrototypePreviewer\/(?:demo-renderer|runtimes\/(?:react|vue|vue2)-runtime)/.test(path) ||
      /\/packages\/adapters\/(?:react|vue|vue2)\//.test(path) ||
      /\/(?:\.vite\/deps|node_modules\/\.pnpm)\/[^/]*(?:react|vue)/.test(path) ||
      /\/(?:react|react-dom|vue|vue2)(?:[./_-]|$)/.test(path)
    );
  };
  const record = (event, request, response) => {
    if (stopped) return;
    try {
      if (request.resourceType() !== 'script') return;
      if (event === 'request') scriptRequests++;
      const url = request.url();
      if (!relevant(url)) return;
      seen++;
      if (rows.length >= cap) { dropped++; return; }
      if (!ids.has(request)) ids.set(request, ++nextId);
      rows.push({
        event,
        requestId: ids.get(request),
        url,
        resourceType: request.resourceType(),
        method: request.method(),
        nodeMs: performance.now(),
        nodeTimeOrigin: performance.timeOrigin,
        dateNow: Date.now(),
        status: response?.status() ?? null,
        contentType: response?.headers()['content-type'] ?? null,
        failure: event === 'requestfailed' ? request.failure() : null,
        timing: event === 'requestfinished' || event === 'requestfailed' ? { ...request.timing() } : null,
      });
    } catch { errors++; }
  };
  const onRequest = (request) => record('request', request);
  const onResponse = (response) => {
    try { record('response', response.request(), response); } catch { errors++; }
  };
  const onFinished = (request) => record('requestfinished', request);
  const onFailed = (request) => record('requestfailed', request);
  const listeners = [
    ['request', onRequest], ['response', onResponse],
    ['requestfinished', onFinished], ['requestfailed', onFailed],
  ];
  let available = false;
  try {
    for (const [name, listener] of listeners) page.on(name, listener);
    available = true;
  } catch {
    errors++;
    for (const [name, listener] of listeners) {
      try { page.off(name, listener); } catch { errors++; }
    }
  }
  return {
    snapshot() {
      return {
        kind: 'private-s4-runtime-import-network-v1', available, stopped,
        scriptRequests, capturedRequestIdentities: nextId, seen, dropped, errors, rows: [...rows],
        subscriptionAckObserved: false,
        subscriptionBoundary: 'Local listeners installed; Playwright may send updateSubscription commands. ACK timing is not measured.',
        boundary: 'SDK event receipt and cached request metadata; no fetch/route/body read. Shared imports cannot be attributed to a previewer solely by time or URL. Finished transfer is not module evaluation or import-Promise fulfillment.',
      };
    },
    dispose() {
      if (stopped) return;
      stopped = true;
      for (const [name, listener] of listeners) {
        try { page.off(name, listener); } catch { errors++; }
      }
    },
  };
}
