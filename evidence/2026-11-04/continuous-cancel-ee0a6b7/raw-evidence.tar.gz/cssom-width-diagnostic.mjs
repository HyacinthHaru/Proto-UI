import fs from 'node:fs';
import { launchBrowser } from '<C_SOURCE_ROOT>/apps/www/src/content/docs/zh-cn/browser-harness.ts';
const browser = await launchBrowser();
const result = { kind: 'Isolated owned CSSOM serialization diagnostic; no application/product or optical acceptance', node: process.version, browser: browser.version(), requestedWidth: 157.609375 };
try {
  const context = await browser.newContext();
  await context.route('**/*', r => r.abort());
  const page = await context.newPage();
  await page.setContent('<style>#geometry{position:absolute;left:0;top:0;width:157.609375px;height:62px;--paint-width:157.609375px}#geometry::before{content:"";position:absolute;left:0;top:0;width:var(--paint-width);height:62px;display:block}</style><div id="geometry"></div>');
  result.cssom = await page.locator('#geometry').evaluate(e => ({ inlineWidth: e.style.width, authoredCustomProperty: getComputedStyle(e).getPropertyValue('--paint-width'), computedWidth: getComputedStyle(e).width, computedPseudoWidth: getComputedStyle(e, '::before').width, physicalElementWidth: e.getBoundingClientRect().width }));
  const cdp = await context.newCDPSession(page);
  const { root } = await cdp.send('DOM.getDocument', { depth: -1, pierce: true });
  const find = n => n.attributes?.includes('geometry') ? n : (n.children ?? []).map(find).find(Boolean);
  const node = find(root);
  const before = node?.pseudoElements?.find(n => n.pseudoType === 'before');
  if (before) {
    result.pseudoBoxModel = (await cdp.send('DOM.getBoxModel', { nodeId: before.nodeId })).model;
    result.pseudoBorderWidth = result.pseudoBoxModel.border[2] - result.pseudoBoxModel.border[0];
  }
  await cdp.detach();
  await context.close();
} finally {
  await browser.close();
  result.cleanupFinished = true;
  fs.writeFileSync('<STATE_ROOT>/cssom-width-diagnostic.json', JSON.stringify(result, null, 2)+'\n');
}
console.log(JSON.stringify(result));
