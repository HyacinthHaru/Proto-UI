70ca 相对 main DD 只保留 PageFrame 原五行 CSS；全部其它 main path/mode/type/blob 相等。70ca parents 为 f20e239c 与 dd621，tree dccebb7c。PageFrame 整份文件与 ffac 逐字相同，site-contents-panel/command/native-content-lease 和原 Contents 测试也均相同。

相关主线增量是 Header 的隐藏 Select presentation Escape-owner 判断。旧 ffac 的补充 8/8 只能作为旧头结果。保存的 09:50 UTC 平台快照为 OPEN、draft=false、mergeable=true/blocked；22 checks 中 5 success、17 skipped，不是全项执行通过。正文仍描述 ffac/Draft，有当前元数据漂移，不能据正文重标结果。

两条维护者 closed-mount 评论分别绑定 #1227 c3bda 和 803347：前者 gallery held→settled +28px，后者仅 +2px，尽管两者隐藏 closed mount 的干预都产生 -28px。评论明确未验收 #1212 新头，未决定即时 handback 契约。

原代码只在 requestedOpen=false、public open=false、public isPresent=false 后归还树，再结束 close barrier；普通 Escape 不等于完整 renderer dispose。原立即 count 的要求与此屏障是否一致仍需维护者决定，不建议加 wait 或改原断言。

如果需要新增事实，最窄观察仍是第一 Shadcn/WC/click：同 owner/lease 的原 public open/isPresent callback 和原 get 返回、tree home/slot 父节点、实际 Content detach 顺序。DOM 属性或 MO delivery 不能冒充 public callback 时点。原失败后才保留 500ms 相邻 trace，原错误重抛，所有成本和 drops 明示。未准备运行/修改源码。

结论：未确立新的五行 CSS 源码缺陷；语义、精确新组合验证和原失败不因此关闭。human-assisted / unassessed advisory / partial ABSTAIN。
