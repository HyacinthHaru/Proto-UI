三次既有执行都保留原 count=0 失败：pristine70ca 和两版私有诊断均0pass/1fail/8filtered，exit1；runner.reportSha 与实际 Vitest 相等，process-exit/cleanup 双true，runner/unhandled errors为空。

两版插桩按新增 observer 逆还原后均与70ca两原文件逐字相同。原 short-circuit getter调用、单次count、1s和180s、输入和assertions保留；诊断只在原错误之后采500ms邻接记录并同对象重抛。实际源回执恢复true，当前诊断工作树clean且两文件原hash相等。

Tagged after18行含16条同owner/slot/gen/runtime/family源phase及2条无owner的marker；first12是after18前缀。close时原getter open=false/present=true@3326.7；原失败后marker@3335.2；public present callback false@3503.4；原present getter false及return-before@3503.5；return-after@3565.7已home=true。保留的Content引用在相关采样及post500都connected，没有捕获真实detach。

这支持该私有同次失败发生在既有leave屏障完成前；不决定即时handback契约，不改原红，不构成四runtime验收。marker不是原count精确时刻，62.2ms归还区间不等于纯insert成本；同步日志有扰动且没有全异常隔离。实际500ms请求的marker间隔为528.3ms。

本次仅私有只读复核与报告写入，无新运行或产品/证据仓库修改。partial/ABSTAIN。
