from pathlib import Path
import subprocess,os,json,hashlib,datetime
root=Path('<CONTENTS_ROOT>');s=Path('<STATE_ROOT>');out=s/'sidebar-70ca-phase';out.mkdir(exist_ok=True)
paths=['apps/www/src/components/site-contents-panel.ts','apps/www/src/content/docs/zh-cn/homepage-dogfood.browser.test.ts'];original={p:(root/p).read_bytes() for p in paths};assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
a=original[paths[0]].decode();anchor='  const restoreTree = (lease: NativeTreeLease) => {'
helper='''  const tracePhase = (phase: string, extra: Record<string, unknown> = {}) => {
    const state = view as typeof view & { __contentsPhaseTrace?: unknown[]; __contentsObservedContent?: Element };
    const rows = state.__contentsPhaseTrace ??= [];
    if (rows.length < 256) rows.push({ phase, at: view.performance.now(), owner,
      treeHome: tree.parentElement === home, treeConnected: tree.isConnected,
      contentConnected: state.__contentsObservedContent?.isConnected ?? null, ...extra });
  };
  const phaseValue = <T>(phase: string, value: T): T => {
    tracePhase(phase, { value });
    return value;
  };
'''
assert a.count(anchor)==1;a=a.replace(anchor,helper+anchor).replace('    if (treeOwner !== lease) return;','    if (treeOwner !== lease) return;\n    tracePhase("tree-return.before");').replace('    restoreHomeScroll();\n  };','    restoreHomeScroll();\n    tracePhase("tree-return.after");\n  };',1)
old='if (requestedOpen || openFact?.get() !== false || presentFact?.get() !== false) return;';assert a.count(old)==1;a=a.replace(old,'if (requestedOpen || phaseValue("finish.open", openFact?.get()) !== false || phaseValue("finish.present", presentFact?.get()) !== false) return;').replace('closeReturnReady = openFact?.get() === false;','closeReturnReady = phaseValue("unwound.open", openFact?.get()) === false;').replace('const offOpen = open.subscribe(afterPublicUpdate);','const offOpen = open.subscribe((event) => { tracePhase("public.open", { event }); afterPublicUpdate(); });').replace('const offPresent = present.subscribe((event) => {','const offPresent = present.subscribe((event) => {\n                  tracePhase("public.present", { event, requestedOpen, closeReturnReady });')
b=original[paths[1]].decode();start=b.index("  it('uses real family Contents Buttons");end=b.index("  it('uses the same mobile shell",start);section=b[start:end]
marker='const metrics = await dialog.evaluate((element) => {';assert section.count(marker)==1;section=section.replace(marker,marker+'\n                Object.assign(window, { __contentsObservedContent: element });')
anchor='''      } finally {
        await context.close();
      }''';assert section.count(anchor)==1
catch='''      } catch (originalError) {
        try {
          const first = await page.evaluate(() => {
            const state = window as typeof window & { __contentsPhaseTrace?: unknown[] };
            (state.__contentsPhaseTrace ??= []).push({ phase: 'verdict-observed-after-original-count', at: performance.now() });
            return state.__contentsPhaseTrace;
          });
          await page.waitForTimeout(500);
          const after = await page.evaluate(() => {
            const state = window as typeof window & { __contentsPhaseTrace?: unknown[]; __contentsObservedContent?: Element };
            (state.__contentsPhaseTrace ??= []).push({ phase: 'post-verdict-500ms', at: performance.now(), contentConnected: state.__contentsObservedContent?.isConnected ?? null });
            return state.__contentsPhaseTrace;
          });
          await writeFile(path.join(directory, 'same-run-public-phase.json'), JSON.stringify({ source, first, after, originalError: String(originalError), originalDeadlineMs: 180000, diagnosticOnly: true, postVerdictWaitMs: 500 }, null, 2));
          await page.screenshot({ path: path.join(directory, 'after-original-verdict.png') });
        } catch (diagnosticError) { console.error('[Contents phase diagnostic]', diagnosticError); }
        throw originalError;
      } finally {
        await context.close();
      }'''
section=section.replace(anchor,catch);b=b[:start]+section+b[end:]
modified={paths[0]:a.encode(),paths[1]:b.encode()};receipt=dict(head='70ca1f1a0a9c8c2ab1223ab13a88d2b3aaff1ee1',startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),kind='Private two-file passive public-callback/getter trace. Original short-circuit getter order/number/values and count/assertion/deadlines preserved; synchronous trace writes can perturb timing. Added500ms only after original verdict; rethrow same error.',bindings={p:dict(originalSha256=hashlib.sha256(original[p]).hexdigest(),diagnosticSha256=hashlib.sha256(modified[p]).hexdigest()) for p in paths})
for p,v in modified.items():(out/(Path(p).name+'.txt')).write_bytes(v)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');env=os.environ.copy();env['PATH']='<TASK_STATE_ROOT>/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:/opt/homebrew/bin:'+env['PATH'];env['CHROME_PATH']='<TASK_STATE_ROOT>/proto-ui-883/continue-20261023T123632Z/browser-source/cache/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing';env.update(PROTO_UI_DIALOG_INTEGRITY_PATH=str(out/'runner-integrity.json'),PROTO_UI_DIALOG_JSON_PATH=str(out/'vitest.json'),CANDIDATE_SHA=receipt['head'],PROTO_UI_RUNTIME_EVIDENCE_DIR=str(out))
args=['corepack','pnpm@10.32.1','exec','vitest','run','--no-file-parallelism',paths[1],'-t','uses real family Contents Buttons','--reporter=./scripts/test/dialog-run-integrity-reporter.mjs','--reporter=default','--reporter=json','--outputFile='+str(out/'vitest.json')];receipt['argv']=args
try:
 for p,v in modified.items():(root/p).write_bytes(v)
 with (out/'browser.log').open('w') as log:
  try:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=450);receipt['exitCode']=r.returncode
  except subprocess.TimeoutExpired:receipt['exitCode']=124;receipt['outerTimeout']=True
finally:
 for p,v in original.items():
  assert (root/p).read_bytes()==modified[p];(root/p).write_bytes(v)
 receipt['restoredOriginalBytes']=all((root/p).read_bytes()==v for p,v in original.items());receipt['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
