# 2ca 官方 Dialog 配对原件复核

结论为 **partial / ABSTAIN**。准确head`2ca069c1aa80d7d798d246d0d1bd3e96e700e7b0`、tree`5e47265c4fe837fb77b821bfb9ac3e6c051ef37a`的官方配对原件已完整取得并核对，**0字节/记录一致性finding**。候选真实8/8通过，baseline真实0/8、exit1且分类器仍拒绝新闭包。本报告不接受校准、不授予APPROVE，也不将父topic合并当作main带入。

| 项目 | Candidate | 固定 baseline |
|---|---|---|
| 官方run |41643601508|41643601508|
| Job |125943046657，success|125943047024，failure|
| Product source |2ca069c1|15d864de + 同三文件probe覆盖|
| Artifact |13240200185|13240700385|
| ZIP字节 |8,025,164|2,310,539|
| ZIP SHA-256 |`2d459212de0c760fa2aeb20432c7bbf6e6d0358fb42a83207fbc909065879858`|`0bb0856b35671e5e0249b5c404b0a165038ee25875bd408f75c4eaa74a53f2e4`|
| 完整成员 / 原PNG |130 /120|40 /29|
| 原Vitest cases |8pass /0fail /0pending|0pass /8fail /0pending|
| 原observation rows |196 =120geometry +24Title +52action|33 =21geometry +4Title +8failure|
| 原product exit |0|1|
| Node |24.22.2|24.22.1|
| Chrome |156.0.8078.79|156.0.8078.47|
| Runner image |20261101.360.1|20261025.353.1|

所有170ZIP成员CRC、唯一安全普通路径、解包逐字SHA，以及全部149PNG在observation中的SHA引用均通过。全部PNG仅做字节核对，本审阅者未看图。两个原ZIP与两个完整joblog均为本次准确head重新下载；没有复用f1db原件。下载于2026-11-04，实际作业执行于2026-11-03。原件索引见`original-index.json`及两份artifact inventory。

两侧probe实际都为`50f13884d5081c13d126f06c5297a6b98c1c185ea2f8b5e0af46187bacd35b0e`（Dialog probe）、`3b425734cfb00602354bdc2b086e70a0434863f7cc3040415631be1627e0c9b6`（browser-harness）、`4bbc332f34ebf8a9c24f0ccc01d53438dd7146e86118a932eacc63d819105fda`（server-readiness），均逐文件等候选Git原字节。baseline是历史产品加明确的三文件测试覆盖；原15d并不含后来新增的Dialog probe。两侧pre-browser Node controls均实际132/132，不能与8个浏览器case或196行观测相加为产品用例数。

所有196/33行的ID集合、source、Mask/Content/Trigger projection坐标、active generation与物理rect均已逐行核对；候选100条原bounded采样的inset/center、24条Title box/text-range及52条action几何按原阈值重新计算，无不一致。动作后的focus、Tab/Shift+Tab、close/reopen/Escape以准确源码及原Vitest终态为证，未在此重新执行。图像在facts之后采集，不能声称像素与前一getter完全同时。

baseline仍为3个Shadcn resize-immediate inset0（要求≥15）、4个Brutalist Title box overlap504（要求0），以及1个Shadcn/Vue2 runtime未提供。它是8个报告失败、7个已进入原生产品journey在首个390阶段失败，剩余1个仅availability边界；没有完成的baseline全journey。四条Title文字Range overlap实际均0，不把box红扩称已证glyph遮挡。后续视口/长文/缩放/关闭/重开没有在这些baseline红后执行。

两份runner-integrity都真实`process-exit`、`finishedCalls=1`、`closeStarted/closeFinished=true`、无runner/unhandled/suite error、未cancel/timeout；reportSha256逐字等各自vitest.json，reporter SHA等候选Git。原afterAll依次记录数据、close browser、stop server，终态没有hook错误。这是runner/hook清理证据，不是另行采样的OS进程清单。

**原分类拒绝保留。** baseline官方完整log第736行`AssertionError [ERR_ASSERTION]: Uncalibrated probe closure`，源checker第109行仍比历史`PROBE_HASHES`；`expected-failure-classification.json`原文件为0B。候选`CURRENT_PROBE_HASHES`只绑定当前输入，未登记新接受闭包。本报告未再执行/修改classifier，也不把独立数据对账当校准接受。

**配对环境并不完全相同。** Node补丁、Chrome补丁和runner image不同；字体包、fontconfig和fc-match记录相同。不能从同三probe直接称等环境，也不能据此反向解释红绿原因。独立校准维护者应据这些真实边界决定尚需哪些验收。

输入PR快照显示#1272于2026-11-04T00:43:45Z合入`dot/select-header-followups-20261102`，merge`ac6812860215709eabf54285cca8a845f0561c15`。本地准确main对象`dd621dd00f77eb1358a13c1ff94419b048deef59`仍是`181f88d9 /d5afee7e /4bbc332f`三输入，2ca不是其祖先。没有宣称当前main适用本配对，也没有在本审阅中再次轮询main。

仅执行只读GitHubGET、不可变Git读取、私有下载/解包/报告及数据算术。没有新测试、浏览器、Actions操作、源码/Git/GitHub写或评论。
