from pathlib import Path
import json,hashlib,re,collections,datetime
D=Path(__file__).parent;H='2ca069c1aa80d7d798f246d0d1bd3e96e700e7b0'
H=json.loads((D/'source/binding.json').read_text())['candidate'];B='15d864de54210c2eebc4f4b2fec6235324989989'
sources=json.loads((D/'source/binding.json').read_text())['sourceFiles'];expectedProbe={'subject/'+r['path']:r['sha256'] for r in sources[:3]};reporter=next(r['sha256'] for r in sources if r['path'].endswith('reporter.mjs'))
errors=[];checks=0

def check(ok,label,detail=None):
 global checks
 checks+=1
 if not ok:errors.append({'check':label,'detail':detail})
def sha(b):return hashlib.sha256(b).hexdigest()
def overlap(a,b):return max(0,min(a['right'],b['right'])-max(a['left'],b['left']))*max(0,min(a['bottom'],b['bottom'])-max(a['top'],b['top']))
def identities():return [(f,r,f+'-'+r) for f in ['shadcn','brutalist'] for r in ['wc','react','vue','vue2']]
summary={}
for arm,subject in [('candidate',H),('baseline',B)]:
 p=D/'extracted'/arm;obs=json.loads((p/'dialog-available-space/observations.json').read_text());rows=obs['observations'];v=json.loads((p/'vitest.json').read_text());ri=json.loads((p/'runner-integrity.json').read_text());ec=int((p/'product-exit-code.txt').read_text())
 check(obs['sourceSha']==subject and obs['probeSha']==H and obs['subject']==arm,arm+' top source identity')
 check((p/'subject-sha.txt').read_text().strip()==subject and (p/'probe-sha.txt').read_text().strip()==H,arm+' shell source identity')
 probe=dict((line.split('  ',1)[1],line.split('  ',1)[0]) for line in (p/'probe-sha256.txt').read_text().splitlines());check(probe==expectedProbe,arm+' exact 3 file probe closure',probe)
 check(ri['reportSha256']==sha((p/'vitest.json').read_bytes()),arm+' runner report bytes');check(ri['reporterSha256']==reporter,arm+' reporter source')
 for k,want in {'phase':'process-exit','finishedCalls':1,'closeStarted':True,'closeFinished':True,'processTimedOut':False,'cancelled':False,'runnerErrors':[],'unhandledErrors':[],'exitCode':ec,'schemaVersion':1,'vitestVersion':'2.1.9'}.items():check(ri.get(k)==want,arm+' runner '+k)
 check(ri['files']==[{'path':'apps/www/src/content/docs/zh-cn/dialog-available-space.browser.test.ts','state':'pass' if arm=='candidate' else 'fail','suiteErrors':[]}],arm+' file/hook state')
 assertions=v['testResults'][0]['assertionResults'];check(len(assertions)==8 and len({c['fullName'] for c in assertions})==8,arm+' exact 8 cases')
 for k,want in {'numTotalTestSuites':1,'numTotalTests':8,'numPassedTests':8 if arm=='candidate' else 0,'numFailedTests':0 if arm=='candidate' else 8,'numPendingTests':0,'numTodoTests':0,'success':arm=='candidate'}.items():check(v.get(k)==want,arm+' Vitest '+k)
 byid={r['id']:r for r in rows};check(len(byid)==len(rows),arm+' unique observations')
 kind=collections.Counter();imageCount=0;maskCount=0;boundedCount=0;originalSelections=collections.Counter();perCase=[]
 for row in rows:
  rid=row['id'];check(row['sourceSha']==subject,arm+' row source '+rid)
  if 'image' in row:
   image=row['image'];f=p/'dialog-available-space'/image['file'];check(image['file']==rid+'.png' and f.is_file() and sha(f.read_bytes())==image['sha256'],arm+' exact image bytes '+rid);imageCount+=1
  if 'data' in row:
   kind['geometry']+=1;d=row['data'];m=d['maskIdentity'];coords=m['coordinates'];family,runtime=rid.split('-')[:2]
   check(m['status']=='resolved' and all(m[k]==1 for k in ['rootCount','contentCount','triggerCount','maskCount']),arm+' unique mask '+rid)
   check(coords['family']==family and coords['runtime']==runtime and bool(coords['owner']) and bool(coords['generation']),arm+' coordinates '+rid)
   for el in [m['content'],*m['masks'],*m['triggers']]:
    attrs=el['attributes'];check(all(attrs.get('data-projection-'+k)==value for k,value in coords.items()),arm+' same projection '+rid)
   check(m['content']['attributes']['role']=='dialog' and m['triggers'][0]['attributes']['aria-controls']==m['content']['attributes']['id'],arm+' controlled content '+rid)
   check(m['masks'][0]['attributes']['data-projection-prototype']==family+'-dialog-mask',arm+' mask prototype '+rid)
   check(m['content']['rect']==d['rect'] and m['masks'][0]['rect']==d['mask'],arm+' physical rect binding '+rid)
   check(m['scope']['data-projection-scope']==coords['owner'] and all(m['scope'].get('data-projection-'+k)==coords[k] for k in ['family','runtime','generation']) and m['scope']['data-projection-state']=='ready',arm+' ready scope '+rid)
   gh=m['generationHost'];check(gh['data-projection-owner-host']==coords['owner'] and gh['data-projection-generation-host']==coords['generation'] and gh['data-projection-generation-state']=='active',arm+' active generation '+rid);maskCount+=1
   orig=m.get('originalFirstMatch');originalSelections[(orig or {}).get('tag','absent')]+=1
   if arm=='candidate':
    phase=rid.removeprefix(family+'-'+runtime+'-')
    boundedPhase=phase not in ['390-immediate','long-action-reachable','320-long-action-reachable']
    if boundedPhase:
     r=d['rect'];vv=d['viewport'];g=d['font'];ds=[r['x']-vv['x'],vv['x']+vv['visibleWidth']-r['right'],r['y']-vv['y'],vv['y']+vv['visibleHeight']-r['bottom']]
     check(all(x>=g-1 for x in ds),arm+' original inset '+rid,ds)
     check(abs(r['x']+r['width']/2-vv['x']-vv['visibleWidth']/2)<=1 and abs(r['y']+r['height']/2-vv['y']-vv['visibleHeight']/2)<=1,arm+' original center '+rid)
     check(d['available']['width']!='',arm+' available width '+rid);boundedCount+=1
    if re.fullmatch(r'(390|430|320|1024)-resize-immediate',phase):check(d['paint']['transitionProperty']!='all',arm+' original immediate transition '+rid)
    if re.fullmatch(r'(390|430|320|1024)-settled',phase):
     check(d['scrollWidth']<=d['clientWidth']+1,arm+' settled overflow '+rid)
     check(all(d['mask'][k]==want for k,want in {'x':0,'y':0,'width':row['viewport']['width'],'height':900}.items()),arm+' original full mask '+rid)
    if phase in ['long-font200','320-long-font200','scale2']:check(d['scrollWidth']<=d['clientWidth']+1,arm+' stress overflow '+rid)
    if phase=='long-font200':check(d['overflowY']=='auto' and d['scrollHeight']>d['clientHeight'],arm+' actual long scroll region '+rid)
  elif rid.endswith('-title-clearance'):
   kind['title']+=1;f=row['fact'];check(not f['missing'] and f['titleVisible'] and f['closeVisible'] and f['text']=='Neo-Brutalist modal',arm+' title existence '+rid)
   check(all(f[o][dim]>0 for o in ['title','close'] for dim in ['width','height']),arm+' title dimensions '+rid)
   check(f['titleOverlapArea']==overlap(f['title'],f['close']),arm+' recomputed title overlap '+rid)
   check(f['titleOverlapArea']==(0 if arm=='candidate' else 504),arm+' observed title overlap '+rid)
   check(len(f['lines'])>0 and all(line['overlapArea']==overlap(line['rect'],f['close'])==0 for line in f['lines']),arm+' text range overlaps '+rid)
  elif '-action-' in rid:
   kind['action']+=1;f=row['fact'];check(f['width']>0 and f['height']>0 and f['hit'] is True,arm+' action hit '+rid)
   check(f['left']>=f['contentLeft']-1 and f['right']<=f['contentRight']+1,arm+' action inline region '+rid)
   if rid.startswith('shadcn-') and not f['closeIcon']:
    check(f['semanticParent']=={'style':None,'role':None,'tabIndex':-1},arm+' action semantic parent '+rid)
    check(all(f['layout'][k]==vv for k,vv in {'prototype':False,'role':None,'tabIndex':-1,'minWidth':'0px','maxWidth':'100%'}.items()),arm+' passive layout '+rid)
    check(f['layout']['left']>=f['contentLeft']-1 and f['layout']['right']<=f['contentRight']+1 and f['whiteSpace']=='normal' and f['scrollWidth']<=f['clientWidth']+1,arm+' label layout '+rid)
  elif rid.endswith('-failure'):kind['failure']+=1
  else:errors.append({'check':'unknown observation type','detail':rid})
 for family,runtime,prefix in identities():
  case=next(x for x in assertions if x['fullName'].startswith(family+'/'+runtime+':'))
  cr=[r for r in rows if r['id'].startswith(prefix+'-')];expectedIds=[]
  if arm=='candidate':
   phases=['390-immediate']+[str(w)+'-'+phase for w in [390,430,320,1024] for phase in ['resize-immediate','settled']]+['long-font200','long-action-reachable']+(['320-long-font200','320-long-action-reachable'] if family=='shadcn' else [])+['scale2','restored','reopened']
   expectedIds=[prefix+'-'+x for x in phases]
   if family=='brutalist':expectedIds += [prefix+'-'+x+'-title-clearance' for x in ['390-settled','430-settled','320-settled','1024-settled','long-font200','scale2']]
   for phase in (['long-font200','320-long-font200','scale2'] if family=='shadcn' else ['long-font200','scale2']):expectedIds += [prefix+'-'+phase+'-action-'+str(i) for i in range(3 if family=='shadcn' else 2)]
   check(case['status']=='passed' and case['failureMessages']==[],arm+' successful exact case '+prefix)
  else:
   expectedIds=[prefix+'-failure'] if prefix=='shadcn-vue2' else [prefix+'-'+x for x in ['390-immediate','390-resize-immediate','390-settled']]+([prefix+'-390-settled-title-clearance'] if family=='brutalist' else [])+[prefix+'-failure']
   first=case['failureMessages'][0].split('\n')[0];want=('Error: RuntimeNotOffered:shadcn/vue2:["wc","react","vue"]' if prefix=='shadcn-vue2' else 'AssertionError: CloseIcon must not cover the Title box: expected 504 to be +0 // Object.is equality' if family=='brutalist' else 'AssertionError: expected 0 to be greater than or equal to 15')
   check(case['status']=='failed' and len(case['failureMessages'])==1 and first==want and byid[prefix+'-failure']['error']==want,arm+' exact failure '+prefix)
   if prefix!='shadcn-vue2':
    for phase in ['390-resize-immediate','390-settled']:
     d=byid[prefix+'-'+phase]['data'];check(d['rect']['x']==0 and d['rect']['width']==390 and d['rect']['right']==390 and d['font']==16 and d['transition']=='entered',arm+' zero inset facts '+prefix+'-'+phase)
   else:check(json.loads(byid[prefix+'-failure']['setup']['offeredRuntimes'])==['wc','react','vue'],arm+' actual unavailable runtime')
  check(sorted(x['id'] for x in cr)==sorted(expectedIds),arm+' complete case observation set '+prefix)
  perCase.append({'identity':family+'/'+runtime,'status':case['status'],'rowCount':len(cr),'firstFailure':case['failureMessages'][0].split('\n')[0] if case['failureMessages'] else None})
 check(kind==({'geometry':120,'title':24,'action':52} if arm=='candidate' else {'geometry':21,'title':4,'failure':8}),arm+' full row scope',dict(kind))
 summary[arm]={'sourceSha':subject,'probeSha':H,'caseCounts':{k:v[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']},'rowCounts':dict(kind),'rows':len(rows),'uniqueResolvedMaskRows':maskCount,'reviewedStoredBoundedGeometryRows':boundedCount,'allImageReferencesVerified':imageCount,'originalFirstMatchTags':dict(originalSelections),'cases':perCase,'runner':ri,'browser':obs['browser'],'fontEnvironment':(p/'font-environment.txt').read_text(),'probeHashes':probe,'observationsSha256':sha((p/'dialog-available-space/observations.json').read_bytes()),'vitestSha256':sha((p/'vitest.json').read_bytes())}
result={'scope':'Independent offline read-only arithmetic/hash reconciliation of actual archived records. No repository verifier/test/browser rerun; no acceptance or calibration registration.','computedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'mismatches':errors,'arms':summary,'limits':['Focus/Tab/Shift+Tab/Escape and teardown assertions are supported by successful exact-source Vitest completion, not by independent browser replay here.','The recorded first immediate image/facts may be an entering animation and is not treated as a settled bounded sample.','Title text-range overlap zero is not pixel inspection;149PNG were byte-hashed, not viewed.','Historical classifier rejected the new closure before its geometry classification; this arithmetic review does not change that result.']}
(D/'observation-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checks':checks,'mismatches':errors,'summaries':{a:{k:s[k] for k in ['caseCounts','rowCounts','rows','uniqueResolvedMaskRows','reviewedStoredBoundedGeometryRows','allImageReferencesVerified','originalFirstMatchTags']} for a,s in summary.items()}},indent=2))
