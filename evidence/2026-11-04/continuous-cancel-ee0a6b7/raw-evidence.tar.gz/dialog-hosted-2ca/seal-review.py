from pathlib import Path
import json,hashlib,re,datetime,collections
D=Path(__file__).parent;R=D.parent;H='2ca069c1aa80d7d798d246d0d1bd3e96e700e7b0'
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(p):
 b=p.read_bytes();return {'path':str(p.relative_to(D)) if p.is_relative_to(D) else str(p),'bytes':len(b),'sha256':sha(b)}
def load(p):return json.loads(p.read_text())
run=load(D/'metadata/run.json');jp=load(D/'metadata/jobs-pages.json');ap=load(D/'metadata/artifacts-pages.json');jobs=[j for p in jp for j in p['jobs']];artifacts=[a for p in ap for a in p['artifacts']];audit=load(D/'observation-audit.json');source=load(D/'source/binding.json');pr=load(R/'final-live-1272.json');assert not audit['mismatches']
assert len(jobs)==jp[0]['total_count']==2 and len(artifacts)==ap[0]['total_count']==2
assert run['head_sha']==H and all(a['workflow_run']['head_sha']==H for a in artifacts)
arms={}; excerpts={}
for arm,jid,aid in [('candidate',125943046657,13240200185),('baseline',125943047024,13240700385)]:
 p=D/'extracted'/arm;log=D/'logs'/f'{arm}-{jid}.log';lines=log.read_text().splitlines();clean=[re.sub(r'\x1b\[[0-9;]*m','',x) for x in lines]
 ex=[]
 for i,l in enumerate(clean,1):
  if i<22 or 'git log -1 --format=%H' in l or any(x in l for x in ['node: v','ℹ tests','ℹ pass','ℹ fail','ℹ cancelled','ℹ skipped','ℹ todo','Test Files','Tests ','Uncalibrated probe closure']):
   ex.append({'line':i,'text':l})
   if 'git log -1 --format=%H' in l and i<len(clean):ex.append({'line':i+1,'text':clean[i]})
 excerpts[arm]={'rawLog':ref(log),'excerpts':ex}
 node=next(re.search(r'node: (v\S+)',l).group(1) for l in clean if 'node: v' in l)
 img=next(re.search(r'Version: (\S+)',l).group(1) for l in clean[15:22] if 'Version:' in l)
 count={m.group(1):int(m.group(2)) for l in clean if (m:=re.search(r'ℹ (tests|pass|fail|cancelled|skipped|todo) (\d+)',l))};assert count=={'tests':132,'pass':132,'fail':0,'cancelled':0,'skipped':0,'todo':0}
 inventory=load(D/'artifacts'/f'{arm}-inventory.json');a=next(a for a in artifacts if a['id']==aid);j=next(j for j in jobs if j['id']==jid)
 assert inventory['archiveSha256']==a['digest'].removeprefix('sha256:') and inventory['archiveBytes']==a['size_in_bytes']
 arms[arm]={'job':{k:j.get(k) for k in ['id','name','html_url','status','conclusion','started_at','completed_at']},'artifact':{k:a.get(k) for k in ['id','name','size_in_bytes','digest','created_at','updated_at','expired']},'archiveVerification':{k:v for k,v in inventory.items() if k not in ['inventory','archive']},'archivePath':str(Path(inventory['archive']).relative_to(D)),'originalLog':ref(log),'originalReport':ref(p/'vitest.json'),'originalObservations':ref(p/'dialog-available-space/observations.json'),'runnerIntegrity':ref(p/'runner-integrity.json'),'environment':{'node':node,'browser':audit['arms'][arm]['browser'],'ubuntu':'24.04.5','runnerImage':img,'fontEnvironment':(p/'font-environment.txt').read_text()},'preBrowserNodeControls':count,'productExitCode':int((p/'product-exit-code.txt').read_text()),'caseCounts':audit['arms'][arm]['caseCounts'],'observationCounts':audit['arms'][arm]['rowCounts'],'cases':audit['arms'][arm]['cases'],'runnerReportSha256Verified':True,'runnerReporterSourceSha256Verified':True,'processExitSealed':True,'cleanupScope':'Actual reporter phase=process-exit, finishedCalls=1, closeStarted/closeFinished true, processTimedOut/cancelled false, runnerErrors/unhandledErrors/suiteErrors empty. This is runner and hook evidence, not a separate OS process inventory.'}
classifier=D/'source/candidate/scripts/test/check-dialog-baseline-evidence.mjs';text=classifier.read_text();oldblock=text.split('export const PROBE_HASHES = {',1)[1].split('};',1)[0];curblock=text.split('export const CURRENT_PROBE_HASHES = {',1)[1].split('};',1)[0]
pat=r"'([^']+)':\s*'([a-f0-9]{64})'";historical=dict(re.findall(pat,oldblock));current=dict(re.findall(pat,curblock));actual=audit['arms']['baseline']['probeHashes'];assert actual==current and actual!=historical
rejected=D/'extracted/baseline/expected-failure-classification.json';assert rejected.stat().st_size==0
rejection=[x for x in excerpts['baseline']['excerpts'] if 'Uncalibrated probe closure' in x['text']];assert len(rejection)==1
notes=[{'id':'ENVIRONMENT-NOT-IDENTICAL','kind':'verification-boundary','facts':{'candidate':arms['candidate']['environment'],'baseline':arms['baseline']['environment']},'meaning':'The workflow pairs the same three probe bytes with two source subjects, but actual runner image, Node patch and Chrome patch differ. No pure-source causal effect, equal browser environment, or environment-caused failure is inferred.'},{'id':'CALIBRATION-STILL-REJECTED','kind':'unresolved-acceptance','meaning':'The original classifier rejected the new complete closure at its historical PROBE_HASHES check. Independent raw-record arithmetic is not calibration registration, approval or changing a guard.'},{'id':'MAIN-NOT-THIS-CLOSURE','kind':'scope','meaning':'PR1272 merged into its parent topic. The exact locally inspected main object dd621 still has181f/d5afee/4bbc; candidate2ca is not its ancestor. Current public-main compatibility is not certified.'},{'id':'NO-PIXEL-REVIEW','kind':'outside-scope','meaning':'All149PNG are byte-hashed and matched to observation references; none was opened by this reviewer. No full visual, optical or physical keyboard/notch acceptance is claimed.'}]
report={'schemaVersion':1,'kind':'Exact-head official Dialog paired raw-evidence review','executionMode':'human-assisted','modeSource':'current-user','reviewSkill':'pui-review','reviewDisposition':'partial/ABSTAIN','formalApproval':False,'calibrationAccepted':False,'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewedHead':H,'reviewedTree':source['commits'][0]['tree'],'fixedBaseline':source['baseline'],'run':{k:run.get(k) for k in ['id','name','html_url','head_sha','status','conclusion','event','path','created_at','updated_at']},'pagination':{'jobsPages':len(jp),'jobsActualTotal':len(jobs),'jobsDeclaredTotal':jp[0]['total_count'],'artifactsPages':len(ap),'artifactsActualTotal':len(artifacts),'artifactsDeclaredTotal':ap[0]['total_count'],'complete':True},'collectionTimes':{'runMetadataReceipt':load(D/'metadata/run-receipt.json'),'jobMetadataReceipt':load(D/'metadata/jobs-pages-receipt.json'),'artifactMetadataReceipt':load(D/'metadata/artifacts-pages-receipt.json')},'arms':arms,'probeClosure':{'actual':actual,'candidateCurrentBinding':current,'historicallyCalibrated':historical,'sameExactThreeFilesAcrossBothArms':True,'allActualThreeHashesEqualImmutableCandidateGit':True,'baselineOverlay':'Historical15d product with three candidate-owned probe files copied by workflow. The original15d Git tree has no Dialog probe file; this overlay is explicit.'},'baselineClassifier':{'source':ref(classifier),'rejectAtSourceLine':109,'originalJobRejection':rejection[0],'classificationOutput':ref(rejected),'actualResult':'Uncalibrated probe closure; no accepted classification JSON produced','notRunAgainByReviewer':True},'fullObservationReconciliation':{'report':ref(D/'observation-audit.json'),'checkedComparisons':audit['checks'],'mismatchCount':len(audit['mismatches']),'candidateRows':196,'baselineRows':33,'candidateAll120MaskIdentitiesResolvedAndConsistent':True,'baselineAll21MaskIdentitiesResolvedAndConsistent':True,'all149PNGReferencesShaMatch':True,'candidateBoundedStoredRowsRecomputed':100,'candidateTitleRowsRecomputed':24,'candidateActionRowsChecked':52,'baselineNativeFailurePartition':{'reportedFailedTests':8,'nativeProductJourneysFailedAtFirst390Phase':7,'shadcnZeroInsetAssertions':3,'brutalistTitleBoxOverlapAssertions':4,'runtimeNotOfferedEntries':1,'completedProductJourneys':0},'baselineTitleBoxOverlapArea':504,'baselineTextRangeOverlapAreas':[0,0,0,0],'focusAndCloseLimit':'Final native pass records support execution of exact-source focus, Tab/Shift+Tab, close/reopen/Escape assertions. Stored numeric rows alone are not an independent replay of those interactions.'},'sourceBinding':ref(D/'source/binding.json'),'mainAndMergeScope':{'inputSnapshot':ref(R/'final-live-1272.json'),'snapshotObservedAt':pr['observedAt'],'pr':1272,'head':pr['pull']['head']['sha'],'merged':pr['pull']['merged'],'mergedAt':pr['pull']['merged_at'],'mergeCommit':pr['pull']['merge_commit_sha'],'baseRef':pr['pull']['base']['ref'],'baseSha':pr['pull']['base']['sha'],'reportedMainObject':source['reportedMain'],'candidateAncestorOfReportedMain':False,'mainOriginalClosure':source['commits'][2]['originalSubjectFiles'],'mainNotFreshlyPolledByReviewer':True},'byteOrRecordFindings':[],'acceptanceLimitations':notes,'previousEpochBoundary':'No f1db ZIP, row, job result or classifier acceptance was substituted. All reviewed artifacts have2ca in GitHub metadata and matching raw probe records. Prior f1db report remains historical only.','reviewerActions':{'readonlyGithubGET':True,'localPrivateDownloadsAndReports':True,'newTestsOrBrowser':False,'repositoryVerifierRerun':False,'sourceGitGithubWrites':False,'pngVisualInspection':False},'priorReadPreparationError':ref(D/'source/first-binding-read-error.json'),'commandsScope':'GET exact run/jobs/artifacts and two completed logs/two ZIPs; local Git show/cat-file/ancestry reads; offline ZIP CRC/SHA and recorded JSON arithmetic. No Action mutation, repository modification, calibration update or publication.'}
(D/'log-excerpts.json').write_text(json.dumps(excerpts,indent=2)+'\n')
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
md=f'''# 2ca 官方 Dialog 配对原件复核

结论为 **partial / ABSTAIN**。准确head`{H}`、tree`{report['reviewedTree']}`的官方配对原件已完整取得并核对，**0字节/记录一致性finding**。候选真实8/8通过，baseline真实0/8、exit1且分类器仍拒绝新闭包。本报告不接受校准、不授予APPROVE，也不将父topic合并当作main带入。

| 项目 | Candidate | 固定 baseline |
|---|---|---|
| 官方run |41643601508|41643601508|
| Job |125943046657，success|125943047024，failure|
| Product source |2ca069c1|15d864de + 同三文件probe覆盖|
| Artifact |13240200185|13240700385|
| ZIP字节 |8,025,164|2,310,539|
| ZIP SHA-256 |`2d459212de0c760fa2aeb20432c7bbf6e6d0358fb42a83207fbc909065879858`|`0bb0856b35671e5e0249b5c404b0a165038ee25875bd408f75c4eaa74a53f2e4`|
| 完整成员 / 原PNG |130 /120|40 /29|
| 原Vitest cases |8pass /0fail /0pending|0pass /8fail /0pending|
| 原observation rows |196 =120geometry +24Title +52action|33 =21geometry +4Title +8failure|
| 原product exit |0|1|
| Node |24.22.2|24.22.1|
| Chrome |156.0.8078.79|156.0.8078.47|
| Runner image |20261101.360.1|20261025.353.1|

所有170ZIP成员CRC、唯一安全普通路径、解包逐字SHA，以及全部149PNG在observation中的SHA引用均通过。全部PNG仅做字节核对，本审阅者未看图。两个原ZIP与两个完整joblog均为本次准确head重新下载；没有复用f1db原件。下载于2026-11-04，实际作业执行于2026-11-03。原件索引见`original-index.json`及两份artifact inventory。

两侧probe实际都为`50f13884d5081c13d126f06c5297a6b98c1c185ea2f8b5e0af46187bacd35b0e`（Dialog probe）、`3b425734cfb00602354bdc2b086e70a0434863f7cc3040415631be1627e0c9b6`（browser-harness）、`4bbc332f34ebf8a9c24f0ccc01d53438dd7146e86118a932eacc63d819105fda`（server-readiness），均逐文件等候选Git原字节。baseline是历史产品加明确的三文件测试覆盖；原15d并不含后来新增的Dialog probe。两侧pre-browser Node controls均实际132/132，不能与8个浏览器case或196行观测相加为产品用例数。

所有196/33行的ID集合、source、Mask/Content/Trigger projection坐标、active generation与物理rect均已逐行核对；候选100条原bounded采样的inset/center、24条Title box/text-range及52条action几何按原阈值重新计算，无不一致。动作后的focus、Tab/Shift+Tab、close/reopen/Escape以准确源码及原Vitest终态为证，未在此重新执行。图像在facts之后采集，不能声称像素与前一getter完全同时。

baseline仍为3个Shadcn resize-immediate inset0（要求≥15）、4个Brutalist Title box overlap504（要求0），以及1个Shadcn/Vue2 runtime未提供。它是8个报告失败、7个已进入原生产品journey在首个390阶段失败，剩余1个仅availability边界；没有完成的baseline全journey。四条Title文字Range overlap实际均0，不把box红扩称已证glyph遮挡。后续视口/长文/缩放/关闭/重开没有在这些baseline红后执行。

两份runner-integrity都真实`process-exit`、`finishedCalls=1`、`closeStarted/closeFinished=true`、无runner/unhandled/suite error、未cancel/timeout；reportSha256逐字等各自vitest.json，reporter SHA等候选Git。原afterAll依次记录数据、close browser、stop server，终态没有hook错误。这是runner/hook清理证据，不是另行采样的OS进程清单。

**原分类拒绝保留。** baseline官方完整log第736行`AssertionError [ERR_ASSERTION]: Uncalibrated probe closure`，源checker第109行仍比历史`PROBE_HASHES`；`expected-failure-classification.json`原文件为0B。候选`CURRENT_PROBE_HASHES`只绑定当前输入，未登记新接受闭包。本报告未再执行/修改classifier，也不把独立数据对账当校准接受。

**配对环境并不完全相同。** Node补丁、Chrome补丁和runner image不同；字体包、fontconfig和fc-match记录相同。不能从同三probe直接称等环境，也不能据此反向解释红绿原因。独立校准维护者应据这些真实边界决定尚需哪些验收。

输入PR快照显示#1272于2026-11-04T00:43:45Z合入`dot/select-header-followups-20261102`，merge`ac6812860215709eabf54285cca8a845f0561c15`。本地准确main对象`dd621dd00f77eb1358a13c1ff94419b048deef59`仍是`181f88d9 /d5afee7e /4bbc332f`三输入，2ca不是其祖先。没有宣称当前main适用本配对，也没有在本审阅中再次轮询main。

仅执行只读GitHubGET、不可变Git读取、私有下载/解包/报告及数据算术。没有新测试、浏览器、Actions操作、源码/Git/GitHub写或评论。
'''
(D/'report.md').write_text(md)
# Index only already retained original materials, never self-hash the index.
records=[]
for base in ['metadata','logs','artifacts','extracted','source']:
 for p in sorted((D/base).rglob('*')):
  if p.is_file():records.append(ref(p))
index={'reviewedHead':H,'files':records,'fileCount':len(records),'rawArchivesRetained':True,'repacked':False,'allExtractedMembersCoveredByArchiveInventories':True,'noPixelReview':True}
(D/'original-index.json').write_text(json.dumps(index,indent=2)+'\n')
selection=[]
for p in [D/'report.json',D/'report.md',D/'observation-audit.json',D/'source/binding.json',D/'log-excerpts.json',D/'original-index.json',D/'metadata/run.json',D/'metadata/jobs-pages.json',D/'metadata/artifacts-pages.json',D/'artifacts/candidate-inventory.json',D/'artifacts/baseline-inventory.json',*(D/'logs').glob('*.log')]:selection.append({'kind':'metadata-or-text-original',**ref(p)})
for p in (D/'artifacts').glob('*.zip'):selection.append({'kind':'complete-original-zip','requiresSanitizationOfWrappersOnly':True,**ref(p)})
for p in (D/'extracted').rglob('*'):
 if p.is_file() and p.suffix!='.png':selection.append({'kind':'original-artifact-text','sourceIsNew2caEpoch':True,**ref(p)})
(D/'public-inputs.json').write_text(json.dumps({'preparedOnly':True,'uploadedOrPublished':False,'warning':'Original joblogs/artifactJSON include runner paths. Any public sanitized projection must retain raw/public byte mapping; no image modification or calibration claim. FullZIPs remain untouched.','inputs':selection},indent=2)+'\n')
print(json.dumps({'report':ref(D/'report.json'),'markdown':ref(D/'report.md'),'originalIndex':ref(D/'original-index.json'),'publicInputs':ref(D/'public-inputs.json'),'byteRecordFindings':0,'acceptanceDisposition':'partial/ABSTAIN','noCalibrationAcceptance':True},indent=2))
