import pathlib,subprocess,json,os,datetime,hashlib
root=pathlib.Path('<C_SOURCE_ROOT>');s=pathlib.Path('<STATE_ROOT>');env=os.environ.copy();env['PATH']='<TASK_STATE_ROOT>/proto-ui-pr822/toolchain/node-v24.21.0-darwin-arm64/bin:/opt/homebrew/bin:'+env['PATH'];report=dict(base='dd621dd00f77eb1358a13c1ff94419b048deef59',startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),steps=[])
def run(name,args,timeout=600):
 row=dict(name=name,argv=args,startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());report['steps'].append(row)
 with (s/(name+'.log')).open('w') as log:
  try:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout);row['exitCode']=r.returncode
  except subprocess.TimeoutExpired:row['exitCode']=124;row['outerTimeout']=True
 row['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(s/'candidate-validation-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(name,row['exitCode'],flush=True);return row['exitCode']
path=root/'packages/adapters/base/src/events/web-event-router.ts';candidate=path.read_bytes();original=subprocess.check_output(['git','show',report['base']+':packages/adapters/base/src/events/web-event-router.ts'],cwd=root);test=root/'packages/adapters/base/test/window-blur-activation.test.ts';testsha=hashlib.sha256(test.read_bytes()).hexdigest()
try:
 path.write_bytes(original)
 code=run('normalized-main-red',['corepack','pnpm@10.32.1','exec','vitest','run','--no-file-parallelism','packages/adapters/base/test/window-blur-activation.test.ts','--reporter=default','--reporter=json','--outputFile='+str(s/'normalized-main-red.json')]);assert code==1
finally:path.write_bytes(candidate)
assert hashlib.sha256(test.read_bytes()).hexdigest()==testsha
report['sourceBindings']={'routerSha256':hashlib.sha256(candidate).hexdigest(),'testSha256':testsha,'mainRouterSha256':hashlib.sha256(original).hexdigest(),'sameFormattedTestForMainRedAndFinalGreen':True}
for name,args in [('consumer-types-final',['node','experiments/material-v2/typecheck.mjs']),('package-build-final',['corepack','pnpm@10.32.1','build:packages','--package','@proto.ui/cli','--package','@proto.ui/prototypes-base','--package','@proto.ui/adapter-web-component','--package','@proto.ui/adapter-react','--package','@proto.ui/adapter-vue','--package','@proto.ui/adapter-vue2']),('package-manifests-final',['corepack','pnpm@10.32.1','check:package-manifests']),('types-final',['corepack','pnpm@10.32.1','check:types'])]:run(name,args)
report['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();assert path.read_bytes()==candidate and hashlib.sha256(test.read_bytes()).hexdigest()==testsha;(s/'candidate-validation-receipt.json').write_text(json.dumps(report,indent=2)+'\n')
