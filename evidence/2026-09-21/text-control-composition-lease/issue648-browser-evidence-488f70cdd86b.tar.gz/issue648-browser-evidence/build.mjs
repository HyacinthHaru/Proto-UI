import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const directory = path.dirname(fileURLToPath(import.meta.url));
const [sourceArgument, outputArgument] = process.argv.slice(2);
if (!sourceArgument || !outputArgument) {
  throw new Error('Usage: node build.mjs SOURCE_CHECKOUT OUTPUT_DIRECTORY');
}
const source = path.resolve(sourceArgument);
const output = path.resolve(outputArgument);
const requireFromSource = createRequire(path.join(source, 'package.json'));
const esbuild = requireFromSource('esbuild');
const sha256 = (content) => createHash('sha256').update(content).digest('hex');
const git = (...args) => execFileSync('git', args, { cwd: source, encoding: 'utf8' }).trim();
await mkdir(output, { recursive: true });
const result = await esbuild.build({
  absWorkingDir: source,
  entryPoints: [path.join(directory, 'api-entry.ts')],
  bundle: true,
  format: 'iife',
  globalName: 'TextControlEvidence',
  platform: 'browser',
  target: 'es2022',
  minify: true,
  sourcemap: false,
  metafile: true,
  write: false,
  alias: {
    '@proto.ui/core': path.join(source, 'packages/core/src/index.ts'),
    '@proto.ui/module-base': path.join(source, 'packages/modules/base/src/index.ts'),
    '@proto.ui/module-text-control/caps': path.join(source, 'packages/modules/text-control/src/caps.ts'),
    '@proto.ui/module-text-control/create': path.join(source, 'packages/modules/text-control/src/create.ts'),
    '@proto.ui/module-text-control/declaration': path.join(source, 'packages/modules/text-control/src/declaration.ts'),
    '@proto.ui/module-text-control/web': path.join(source, 'packages/modules/text-control/src/web.ts'),
  },
});
const inputs = [];
for (const name of Object.keys(result.metafile.inputs).sort()) {
  const absolute = path.resolve(source, name);
  const relative = path.relative(source, absolute);
  const publicName = relative.startsWith('..') ? `harness/${path.basename(name)}` : relative;
  inputs.push({ path: publicName, sha256: sha256(await readFile(absolute)) });
}
const bundle = result.outputFiles[0].contents;
await writeFile(path.join(output, 'module.js'), bundle);
const manifest = {
  schemaVersion: 1,
  repository: 'https://github.com/Proto-UI/Proto-UI',
  sourceCommit: git('rev-parse', 'HEAD'),
  sourceDiffSha256: sha256(git('diff', 'HEAD', '--', 'packages')),
  sourceTreeClean: git('status', '--porcelain', '--', 'packages') === '',
  builtAt: new Date().toISOString(),
  node: process.version,
  esbuild: esbuild.version,
  buildFlags: { bundle: true, format: 'iife', platform: 'browser', target: 'es2022', minify: true, sourcemap: false },
  bundleSha256: sha256(bundle),
  inputs,
};
await writeFile(path.join(output, 'source-manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(JSON.stringify({ sourceCommit: manifest.sourceCommit, sourceTreeClean: manifest.sourceTreeClean, bundleSha256: manifest.bundleSha256, inputCount: inputs.length }));
