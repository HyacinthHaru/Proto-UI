# Issue #648: Text Control composition lease browser evidence

This packet executes the repository's actual Text Control Module and Web Host against real Chromium `input` and `textarea` elements. The four interrupted-composition cases fail on baseline `c473eae3fe6b66354f5e689fcc1d01241946ed7f` and pass on candidate `488f70cdd86bef0109eb3faab8fc4cfe0e86f95c`. Both uninterrupted-composition controls pass on both revisions. The fixture and all 109 assertions are identical between the final baseline and candidate runs.

The Agent's public paraphrase of [Issue #648](https://github.com/Proto-UI/Proto-UI/issues/648) is: preserve the logical text control's value and value ownership when a physical host lease is replaced during composition, and prevent revoked leases from affecting their successors.

## Observed result

| Scenario, for both input and textarea | Baseline | Candidate |
| --- | --- | --- |
| Same provider: detach, replace DOM target, remount | New DOM target is empty; Module snapshot still says `composing: true` | New DOM target contains the retained controlled value; Module snapshot says `composing: false` |
| New provider: replace DOM target, attach changed host capability while mounted | New DOM target is empty; Module snapshot still says `composing: true` | New DOM target contains the retained controlled value; Module snapshot says `composing: false` |
| Uninterrupted composition | Draft remains while composing; accepted controlled value restores after `compositionend` | Same passing behavior |

The baseline's 14 failing assertions belong to the four interrupted cases; its other two cases pass. The candidate passes all six cases and 109 assertions. Both runs have zero browser page errors. The tests also observe that an event dispatched to the removed old target does not reach Module listeners, stable controlled mode survives replacement, and ordinary input on the current lease still restores the controlled value.

### Component captures

These are unaltered Playwright captures of the running native controls, not rendered assertion cards. The first two sections contain the affected controls; the third is the uninterrupted control.

- `baseline-run/01-initial.png` and `candidate-run/01-initial.png`: original controls display their initial controlled values.
- `baseline-run/02-composition.png` and `candidate-run/02-composition.png`: all six controls display their draft values while the logical controlled values have advanced to `accepted input` or `accepted\ntextarea`.
- `baseline-run/03-replacement.png`: all four replacement controls are visibly blank while the uninterrupted controls still show their drafts.
- `candidate-run/03-replacement.png`: all four replacement controls display the accepted controlled values while the uninterrupted controls still show their drafts.
- `baseline-run/04-compositionend.png` and `candidate-run/04-compositionend.png`: uninterrupted controls restore their accepted values after their normal boundary. Baseline replacement controls remain blank because they have not received a new edit.

Each PNG has its SHA-256 in the adjacent `result.json`. `trace.json` contains every observed DOM value, Module snapshot, real Web Host snapshot, connection patch, provider/lease identity, lifecycle transition, DOM event and normalized Module event. `assertions.log` is searchable and includes expected/observed values for failures.

## Procedure and ownership

1. Declare a single-line or multiline plain-text control through `createTextControlModule`. Initialize its stable controlled value before mounting a `createWebTextControlHost` lease.
2. Dispatch `compositionstart`, write a deliberately different draft into the real DOM control, then dispatch composing `input`. Synchronize a new accepted logical value while composition is active. Assert that the DOM draft is retained while the logical value changes.
3. For the same-provider path, call the real `detached` Module hook, observe immediately, replace the DOM target, and call `mounted` for epoch 2. The provider identity stays unchanged. For the changed-provider path, replace the DOM target and use real `CapsVault.attach` to replace the host capability while the Module remains mounted.
4. Observe the new lease before any event on the new target. This is the discriminating assertion: the replacement must receive the retained logical controlled value and must not inherit the former target's composition fact.
5. Dispatch a late `compositionend` on the removed old target, sample again, and assert that the new target, Module snapshot and listener count do not change.
6. Finish the uninterrupted controls normally and observe restoration after a real browser microtask boundary. Finally, dispatch a noncomposing input proposal on each current target and observe its controlled restoration.

Expected ownership follows the current cataloged direction in [M-TEXT-CONTROL-0001-A/B](https://github.com/Proto-UI/Proto-UI/blob/c473eae3fe6b66354f5e689fcc1d01241946ed7f/spec/modules/M-TEXT-CONTROL-0001.yaml), [HC-TEXT-CONTROL-0001-A](https://github.com/Proto-UI/Proto-UI/blob/c473eae3fe6b66354f5e689fcc1d01241946ed7f/spec/host-caps/HC-TEXT-CONTROL-0001.yaml), and [C-TEXT-CONTROL-0001](https://github.com/Proto-UI/Proto-UI/blob/c473eae3fe6b66354f5e689fcc1d01241946ed7f/spec/contracts/C-TEXT-CONTROL-0001.yaml), which are draft entities. The active [C-LIFECYCLE-0008-I](https://github.com/Proto-UI/Proto-UI/blob/c473eae3fe6b66354f5e689fcc1d01241946ed7f/spec/contracts/C-LIFECYCLE-0008.yaml) separates persistent logical state from native editing state. The evidence does not promote these draft entities to stable guarantees.

## Reproduce

Use Node.js 22, Corepack pnpm 10.32.1, repository dependencies installed from the lockfile, and Chrome/Chromium. The recorded environment is macOS arm64, Node v22.23.2, Chromium 153.0.8010.48, Playwright Core 1.58.2, and esbuild 0.25.12. `CHROME_PATH` may point to a different installed Chrome/Chromium executable; otherwise the existing repository `launchBrowser` helper searches its standard locations. Rendering may differ on another operating system or browser version.

Place the packet outside a disposable Proto-UI source checkout. From the packet directory, run the following, replacing `/path/to/proto-ui-source` with that checkout:

```sh
export PROTO_UI_EVIDENCE_SOURCE=/path/to/proto-ui-source
git -C "$PROTO_UI_EVIDENCE_SOURCE" checkout --detach c473eae3fe6b66354f5e689fcc1d01241946ed7f
corepack pnpm@10.32.1 --dir "$PROTO_UI_EVIDENCE_SOURCE" install --frozen-lockfile
node build.mjs "$PROTO_UI_EVIDENCE_SOURCE" rebuilt-baseline
node run.mjs "$PROTO_UI_EVIDENCE_SOURCE" rebuilt-baseline reproduced-baseline
```

The baseline command intentionally exits **1**, with **4 failing cases / 14 failing assertions**. It still writes the screenshots, complete trace, assertion log and result manifest. An import failure, missing browser, page error or startup timeout is not the expected red result.

```sh
git -C "$PROTO_UI_EVIDENCE_SOURCE" checkout --detach 488f70cdd86bef0109eb3faab8fc4cfe0e86f95c
node build.mjs "$PROTO_UI_EVIDENCE_SOURCE" rebuilt-candidate
node run.mjs "$PROTO_UI_EVIDENCE_SOURCE" rebuilt-candidate reproduced-candidate
```

The candidate command exits **0**, with **6 passing cases / 109 passing assertions**. A source checkout at the recorded revision is required for a rebuild. `build.mjs` bundles repository TypeScript directly, resolving the core and module-base workspace imports to their source files. `run.mjs` reuses the repository's real Chrome launch helper and serves the fixture and bundle on an ephemeral loopback port. It closes the browser and HTTP server when done. It does not depend on a docs server, published package build, external web service or arbitrary timing sleep.

The frozen `baseline/module.js` and `candidate/module.js` bundles can also be rerun by passing `baseline` or `candidate` as the second argument to `run.mjs`. In that mode the explicit source checkout supplies only the recorded browser launch helper and installed dependencies; the product code comes from the integrity-checked frozen bundle. `source-manifest.json` records the source commit, bundle SHA-256 and SHA-256 of all 48 build input files. `result.json` records the fixture/runner hashes, browser helper hash, actual environment and observation time. Baseline and candidate differ in only `packages/modules/text-control/src/impl.ts` among the bundle's input files.

## Scope and limitations

Evidence is complete for the six Module + Web Host cases above. The native controls and browser rendering are real. Test code deliberately supplies `SystemCaps`, lifecycle transitions and capability rebinding; it also writes draft DOM values and dispatches synthetic `CompositionEvent` / `InputEvent` objects. Every recorded DOM event has `isTrusted: false`. This is **not an operating-system IME test**, and no native IME cancel sequence is claimed.

This fixture does not exercise full Prototype or Adapter journeys, browser-specific IME ordering, selection/caret behavior, accessibility, uncontrolled ownership, final instance disposal, or the listener-reentrant stale-microtask regression. Those require separate evidence; repository unit/integration checks are reported separately by the contribution. The DOM instrumentation delegates to the real Web Host and records values; it does not inject the expected accepted value into replacement controls.

`startup-failure.json` preserves two launcher preparation failures before any browser fixture executed. The final commands correct the Playwright external ESM import. Those failures are infrastructure history, not product regression evidence. Preliminary captions/captures are retained locally outside this public packet; only the clean baseline and committed candidate are included here. This directory contains sanitized fixture source and local captures; publication/upload status is recorded separately by the parent contribution.
