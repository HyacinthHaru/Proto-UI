export { CapsVault, SYS_CAP } from '@proto.ui/module-base';
export {
  TEXT_CONTROL_HOST_CAP,
  TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
} from '@proto.ui/module-text-control/caps';
export { createTextControlModule } from '@proto.ui/module-text-control/create';
export { declareTextControl } from '@proto.ui/module-text-control/declaration';
export { createWebTextControlHost } from '@proto.ui/module-text-control/web';
