/* Deterministic Module + Web Host harness; SystemCaps/lifecycle are test-driven. */
const {
  CapsVault,
  SYS_CAP,
  TEXT_CONTROL_HOST_CAP,
  TEXT_CONTROL_RUN_IN_CALLBACK_CAP,
  createTextControlModule,
  declareTextControl,
  createWebTextControlHost,
} = TextControlEvidence;

const cases = [];
const clone = (value) => JSON.parse(JSON.stringify(value));
const eventTypes = ['input', 'change', 'compositionstart', 'compositionupdate', 'compositionend'];

function createCase(scenario, kind) {
  const id = `${scenario}-${kind}`;
  const initialValue = kind === 'input' ? 'approved input' : 'approved\ntextarea';
  const acceptedValue = kind === 'input' ? 'accepted input' : 'accepted\ntextarea';
  const draftValue = kind === 'input' ? 'draft input' : 'draft\ntextarea';
  const trace = [];
  const normalizedEvents = [];
  let phase = 'setup';
  let mountPhase = 'detached';
  let mountEpoch = 0;
  let providerNumber = 0;
  let leaseNumber = 0;
  let activeLease;
  let oldTarget;
  const run = { update() {} };
  const callback = (task) => {
    const before = phase;
    phase = 'callback';
    try { return task(); } finally { phase = before; }
  };
  const ensurePhase = (expected) => {
    if (![].concat(expected).includes(phase)) throw new Error(`Invalid harness phase: ${phase}`);
  };
  const sys = {
    execPhase: () => phase,
    domain: () => phase === 'setup' ? 'setup' : 'runtime',
    protoPhase: () => 'mounted',
    instancePhase: () => 'alive',
    mountPhase: () => mountPhase,
    isDisposed: () => false,
    ensureNotDisposed() {},
    ensureExecPhase: (_op, expected) => ensurePhase(expected),
    ensureSetup: () => ensurePhase('setup'),
    ensureRuntime: () => ensurePhase('callback'),
    ensureCallback: () => ensurePhase('callback'),
    getCallbackCtx: () => phase === 'callback' ? run : undefined,
    deferAfterCallback: (task) => queueMicrotask(task),
  };
  const label = document.createElement('label');
  label.textContent = kind === 'input' ? 'Single line · input' : 'Multiline · textarea';
  document.querySelector(`[data-scenario="${scenario}"] .fields`).append(label);
  function makeTarget(epoch) {
    const element = document.createElement(kind);
    if (kind === 'input') element.type = 'text';
    element.id = id;
    element.dataset.targetEpoch = String(epoch);
    element.spellcheck = false;
    for (const type of eventTypes) {
      element.addEventListener(type, (event) => {
        trace.push({
          operation: 'dom-event', targetEpoch: epoch, type,
          isTrusted: event.isTrusted, isComposing: event.isComposing ?? null,
          data: event.data ?? null, inputType: event.inputType ?? null,
          domValue: element.value, connected: element.isConnected,
          provenance: 'test-dispatchEvent',
        });
      });
    }
    return element;
  }
  let target = makeTarget(1);
  label.append(target);
  const vault = new CapsVault();
  vault.attachBase([[SYS_CAP, sys], [TEXT_CONTROL_RUN_IN_CALLBACK_CAP, callback]]);

  // The wrapper records real host connections without implementing a fake lease.
  function makeProvider() {
    const providerId = ++providerNumber;
    const webHost = createWebTextControlHost(() => target);
    return {
      attach(connection) {
        const leaseId = ++leaseNumber;
        const attachedTarget = target;
        trace.push({ operation: 'host-attach', providerId, leaseId, targetEpoch: target.dataset.targetEpoch, patch: clone(connection.patch) });
        const lease = webHost.attach({
          patch: connection.patch,
          onEvent(event) {
            trace.push({ operation: 'host-event', providerId, leaseId, event: clone(event) });
            connection.onEvent(event);
          },
        });
        activeLease = { lease, providerId, leaseId, target: attachedTarget, patch: connection.patch };
        return {
          update(patch) {
            trace.push({ operation: 'host-update', providerId, leaseId, patch: clone(patch) });
            activeLease.patch = patch;
            lease.update(patch);
          },
          snapshot: () => lease.snapshot(),
          dispose() {
            trace.push({ operation: 'host-dispose', providerId, leaseId, snapshot: clone(lease.snapshot()) });
            lease.dispose();
            if (activeLease?.leaseId === leaseId) activeLease = undefined;
          },
        };
      },
    };
  }
  const initialProvider = makeProvider();
  vault.attach([[TEXT_CONTROL_HOST_CAP, initialProvider]]);
  const module = createTextControlModule({
    init: {
      prototypeName: 'text-control-composition-evidence',
      declarations: [declareTextControl({ content: 'plain-text', lineMode: kind === 'input' ? 'single' : 'multiline', engine: 'host' })],
    },
    caps: vault,
    deps: {
      requireFacade() { throw new Error('No dependency expected'); },
      requirePort() { throw new Error('No dependency expected'); },
      tryFacade: () => undefined,
      tryPort: () => undefined,
    },
  });
  const control = module.facade.declare();
  for (const type of eventTypes) control.on(type, (_run, event) => normalizedEvents.push(clone(event)));
  callback(() => control.sync({ valueMode: 'controlled', value: initialValue }));
  function mount(next, epoch) {
    mountPhase = next;
    mountEpoch = epoch;
    trace.push({ operation: 'mount-phase', phase: next, epoch, provenance: 'test-driven-module-hook' });
    module.hooks.onMountPhase(next, epoch);
  }
  function state() {
    return clone({
      id, scenario, kind, initialValue, acceptedValue, draftValue,
      domValue: target.value, targetTag: target.localName, connected: target.isConnected,
      targetEpoch: Number(target.dataset.targetEpoch),
      moduleSnapshot: control.snapshot(), hostSnapshot: activeLease?.lease.snapshot() ?? null,
      providerId: activeLease?.providerId ?? null, leaseId: activeLease?.leaseId ?? null,
      patch: activeLease?.patch ?? null, capsEpoch: vault.epoch, mountPhase, mountEpoch,
      normalizedEventCount: normalizedEvents.length,
    });
  }
  function sample(step) {
    const observation = state();
    trace.push({ operation: 'sample', step, observation });
    return observation;
  }
  const dispatchComposition = (element, type, data) => element.dispatchEvent(new CompositionEvent(type, { bubbles: true, data }));
  const dispatchInput = (element, data, isComposing) => element.dispatchEvent(new InputEvent('input', {
    bubbles: true, data, isComposing, inputType: isComposing ? 'insertCompositionText' : 'insertText',
  }));
  mount('mounted', 1);
  sample('initial');
  return {
    id, scenario, kind, state, sample,
    begin() {
      target.focus();
      dispatchComposition(target, 'compositionstart', '');
      trace.push({ operation: 'test-dom-value-write', value: draftValue, targetEpoch: 1 });
      target.value = draftValue;
      dispatchInput(target, draftValue, true);
      callback(() => control.sync({ value: acceptedValue }));
      return sample('active-composition-after-controlled-sync');
    },
    replace() {
      if (scenario === 'uninterrupted') return sample('lease-held-during-other-replacements');
      oldTarget = target;
      if (scenario === 'same-provider') {
        mount('detached', 1);
        sample('detached-before-replacement');
      }
      const replacement = makeTarget(2);
      oldTarget.replaceWith(replacement);
      target = replacement;
      trace.push({ operation: 'test-dom-target-replacement', oldTargetConnected: oldTarget.isConnected, newTargetConnected: target.isConnected });
      if (scenario === 'same-provider') mount('mounted', 2);
      else {
        trace.push({ operation: 'test-host-provider-rebind', providerId: 2 });
        vault.attach([[TEXT_CONTROL_HOST_CAP, makeProvider()]]);
      }
      return sample('replacement-attached-before-any-new-edit');
    },
    lateOldEvent() {
      if (oldTarget) dispatchComposition(oldTarget, 'compositionend', 'late old composition');
      return sample('after-late-old-target-event');
    },
    finish() {
      if (scenario === 'uninterrupted') dispatchComposition(target, 'compositionend', draftValue);
      return sample('compositionend-before-microtask');
    },
    rejectedInput() {
      trace.push({ operation: 'test-dom-value-write', value: 'rejected input', targetEpoch: Number(target.dataset.targetEpoch) });
      target.value = 'rejected input';
      dispatchInput(target, 'rejected input', false);
      return sample('noncomposing-input-before-microtask');
    },
    export() { return clone({ id, scenario, kind, trace, normalizedEvents }); },
  };
}

for (const scenario of ['same-provider', 'new-provider', 'uninterrupted']) {
  for (const kind of ['input', 'textarea']) cases.push(createCase(scenario, kind));
}
window.probe = {
  configure(label, commit, bundle, clean) { document.getElementById('revision').textContent = `${label} · ${clean ? 'source' : 'base'} ${commit.slice(0, 12)} · bundle ${bundle.slice(0, 12)}`; },
  step(action, title) {
    document.getElementById('phase').textContent = title;
    return cases.map((entry) => entry[action]());
  },
  sample(step) { return cases.map((entry) => entry.sample(step)); },
  export() { return cases.map((entry) => entry.export()); },
};
