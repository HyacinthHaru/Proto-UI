import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { createRequire } from 'node:module';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const directory = path.dirname(fileURLToPath(import.meta.url));
const [sourceArgument, bundleArgument, outputArgument] = process.argv.slice(2);
if (!sourceArgument || !bundleArgument || !outputArgument) {
  throw new Error('Usage: node run.mjs SOURCE_CHECKOUT BUNDLE_DIRECTORY OUTPUT_DIRECTORY');
}
const source = path.resolve(sourceArgument);
const bundleDirectory = path.resolve(bundleArgument);
const output = path.resolve(outputArgument);
const requireFromSource = createRequire(path.join(source, 'package.json'));
const requireFromDocs = createRequire(path.join(source, 'apps/www/package.json'));
const esbuild = requireFromSource('esbuild');
await mkdir(output, { recursive: true });
// Reuse the repository's actual Chrome lookup/launch helper. Its dev-server
// functions are tree-shaken because this harness only serves three local files.
await esbuild.build({
  absWorkingDir: source,
  stdin: { contents: "export { launchBrowser } from './apps/www/src/content/docs/zh-cn/browser-harness.ts';", resolveDir: source, loader: 'ts' },
  bundle: true, format: 'esm', platform: 'node', packages: 'external',
  plugins: [{
    name: 'external-playwright',
    setup(build) {
      build.onResolve({ filter: /^playwright-core$/ }, () => ({ path: path.join(path.dirname(requireFromDocs.resolve('playwright-core/package.json')), 'index.mjs'), external: true }));
    },
  }],
  outfile: path.join(output, 'launch-helper.mjs'),
});
const { launchBrowser } = await import(pathToFileURL(path.join(output, 'launch-helper.mjs')).href);
const sha256 = (value) => createHash('sha256').update(value).digest('hex');
const sourceManifest = JSON.parse(await readFile(path.join(bundleDirectory, 'source-manifest.json'), 'utf8'));
assert.equal(sha256(await readFile(path.join(bundleDirectory, 'module.js'))), sourceManifest.bundleSha256, 'Frozen source bundle integrity');
const assets = new Map([
  ['/', ['text/html', await readFile(path.join(directory, 'index.html'))]],
  ['/fixture.js', ['text/javascript', await readFile(path.join(directory, 'fixture.js'))]],
  ['/module.js', ['text/javascript', await readFile(path.join(bundleDirectory, 'module.js'))]],
]);
const server = createServer((request, response) => {
  const asset = assets.get(request.url);
  if (!asset) { response.writeHead(404); response.end(); return; }
  response.writeHead(200, { 'Content-Type': asset[0], 'Cache-Control': 'no-store' });
  response.end(asset[1]);
});
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
const browser = await launchBrowser();
const page = await browser.newPage({ viewport: { width: 1120, height: 900 }, deviceScaleFactor: 1 });
const errors = [];
const assertions = [];
const observations = {};
const screenshots = [];
page.on('pageerror', (error) => errors.push(error.message));
const check = (id, name, actual, expected) => {
  try {
    assert.deepEqual(actual, expected);
    assertions.push({ case: id, name, outcome: 'pass', actual, expected });
  } catch {
    assertions.push({ case: id, name, outcome: 'fail', actual, expected });
  }
};
const label = path.basename(bundleDirectory);
async function capture(name) {
  await page.locator('#evidence').screenshot({ path: path.join(output, name), animations: 'disabled' });
  screenshots.push({ path: name, sha256: sha256(await readFile(path.join(output, name))) });
}
try {
  await page.goto(`http://127.0.0.1:${server.address().port}/`, { waitUntil: 'load' });
  await page.waitForFunction(() => Boolean(window.probe));
  await page.evaluate(({ label, commit, bundle, clean }) => window.probe.configure(label, commit, bundle, clean), { label, commit: sourceManifest.sourceCommit, bundle: sourceManifest.bundleSha256, clean: sourceManifest.sourceTreeClean });
  observations.initial = await page.evaluate(() => window.probe.sample('runner-initial'));
  for (const state of observations.initial) {
    check(state.id, 'initial controlled DOM projection', state.domValue, state.initialValue);
    check(state.id, 'initial logical snapshot', state.moduleSnapshot, { value: state.initialValue, composing: false });
    check(state.id, 'actual connected native control', [state.targetTag, state.connected], [state.kind, true]);
  }
  await capture('01-initial.png');
  observations.composing = await page.evaluate(() => window.probe.step('begin', 'Composition active · controlled value updated to accepted'));
  for (const state of observations.composing) {
    check(state.id, 'controlled sync preserves active DOM composition', state.domValue, state.draftValue);
    check(state.id, 'logical value updates while composition remains active', state.moduleSnapshot, { value: state.acceptedValue, composing: true });
    check(state.id, 'Web Host measures active composition', state.hostSnapshot, { value: state.draftValue, composing: true });
  }
  await capture('02-composition.png');
  observations.replaced = await page.evaluate(() => window.probe.step('replace', 'Replacement leases attached · before any new edit'));
  for (const state of observations.replaced) {
    const uninterrupted = state.scenario === 'uninterrupted';
    check(state.id, 'replacement projects retained controlled value', state.domValue, uninterrupted ? state.draftValue : state.acceptedValue);
    check(state.id, 'composition fact belongs only to its physical lease', state.moduleSnapshot, { value: state.acceptedValue, composing: uninterrupted });
    check(state.id, 'fresh host lease starts outside composition', state.hostSnapshot, { value: uninterrupted ? state.draftValue : state.acceptedValue, composing: uninterrupted });
    check(state.id, 'provider identity matches replacement path', state.providerId, state.scenario === 'new-provider' ? 2 : 1);
    check(state.id, 'lease identity matches replacement path', state.leaseId, uninterrupted ? 1 : 2);
    check(state.id, 'controlled ownership mode persists', state.patch.valueMode, 'controlled');
  }
  await capture('03-replacement.png');
  observations.stale = await page.evaluate(() => window.probe.step('lateOldEvent', 'Late compositionend on removed targets · leases unchanged'));
  for (const state of observations.stale) {
    const prior = observations.replaced.find((item) => item.id === state.id);
    check(state.id, 'removed target event cannot reach logical listeners', state.normalizedEventCount, prior.normalizedEventCount);
    check(state.id, 'removed target event cannot change new lease state', [state.domValue, state.moduleSnapshot], [prior.domValue, prior.moduleSnapshot]);
  }
  observations.ended = await page.evaluate(() => window.probe.step('finish', 'Normal controls reached compositionend'));
  observations.settled = await page.evaluate(async () => { await Promise.resolve(); return window.probe.sample('after-compositionend-microtask'); });
  for (const state of observations.settled.filter((item) => item.scenario === 'uninterrupted')) {
    check(state.id, 'normal compositionend restores controlled DOM value', state.domValue, state.acceptedValue);
    check(state.id, 'normal compositionend clears composing', state.moduleSnapshot, { value: state.acceptedValue, composing: false });
  }
  await capture('04-compositionend.png');
  observations.newInput = await page.evaluate(() => window.probe.step('rejectedInput', 'New noncomposing input · controlled restoration'));
  observations.restored = await page.evaluate(async () => { await Promise.resolve(); return window.probe.sample('after-new-input-microtask'); });
  for (const state of observations.restored) {
    check(state.id, 'current lease still restores controlled input proposals', state.domValue, state.acceptedValue);
    check(state.id, 'current lease normal input leaves stable logical value', state.moduleSnapshot, { value: state.acceptedValue, composing: false });
  }
  const traces = await page.evaluate(() => window.probe.export());
  for (const entry of traces) {
    check(entry.id, 'event provenance is explicitly synthetic', entry.trace.filter((event) => event.operation === 'dom-event').every((event) => event.isTrusted === false), true);
    if (entry.scenario === 'same-provider') {
      const detached = entry.trace.find((event) => event.operation === 'sample' && event.step === 'detached-before-replacement').observation;
      check(entry.id, 'detach immediately revokes composition fact', detached.moduleSnapshot, { value: detached.acceptedValue, composing: false });
    }
  }
  check('harness', 'no browser page errors', errors, []);
  const failing = assertions.filter((item) => item.outcome === 'fail');
  const caseResults = traces.map(({ id, scenario, kind }) => ({ id, scenario, kind, outcome: failing.some((item) => item.case === id) ? 'fail' : 'pass' }));
  const manifest = {
    schemaVersion: 1,
    label,
    observedAt: new Date().toISOString(),
    source: sourceManifest,
    environment: { node: process.version, platform: process.platform, release: os.release(), arch: process.arch, chromium: browser.version(), playwright: requireFromDocs('playwright-core/package.json').version, viewport: { width: 1120, height: 900 }, deviceScaleFactor: 1, headless: true },
    provenance: { dom: 'actual input and textarea', implementation: 'bundled repository Text Control Module and createWebTextControlHost', input: 'test-written draft DOM values plus synthetic CompositionEvent/InputEvent via dispatchEvent; isTrusted=false', lifecycle: 'test-driven real module hooks and CapsVault provider changes', microtasks: 'real browser queueMicrotask; explicit Promise boundary used for restoration sampling', osIme: 'not tested', adapters: 'not exercised by this module/host fixture' },
    harness: await Promise.all(['api-entry.ts', 'build.mjs', 'index.html', 'fixture.js', 'run.mjs'].map(async (name) => ({ path: name, sha256: sha256(await readFile(path.join(directory, name))) }))),
    browserHelper: { path: 'apps/www/src/content/docs/zh-cn/browser-harness.ts', sha256: sha256(await readFile(path.join(source, 'apps/www/src/content/docs/zh-cn/browser-harness.ts'))) },
    screenshots, caseResults,
    summary: { cases: caseResults.length, passedCases: caseResults.filter((entry) => entry.outcome === 'pass').length, failedCases: caseResults.filter((entry) => entry.outcome === 'fail').length, assertions: assertions.length, failedAssertions: failing.length, browserErrors: errors.length, exitCode: failing.length ? 1 : 0 },
  };
  await writeFile(path.join(output, 'trace.json'), `${JSON.stringify({ observations, traces, assertions }, null, 2)}\n`);
  await writeFile(path.join(output, 'result.json'), `${JSON.stringify(manifest, null, 2)}\n`);
  const log = [JSON.stringify(manifest.summary), ...failing.map((item) => `${item.case}: ${item.name}\n  expected ${JSON.stringify(item.expected)}\n  observed ${JSON.stringify(item.actual)}`)].join('\n');
  await writeFile(path.join(output, 'assertions.log'), `${log}\n`);
  console.log(log);
  process.exitCode = manifest.summary.exitCode;
} finally {
  await browser.close();
  await new Promise((resolve) => server.close(resolve));
}
